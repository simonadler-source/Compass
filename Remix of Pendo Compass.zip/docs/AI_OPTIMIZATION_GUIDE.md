# AI Analysis Pipeline Optimization Guide

## Current Architecture Overview

The transcript analysis pipeline uses a **multi-pass approach** with 5 active passes:

| Pass | Name | Prompt Size | Schema Size | Model Tier |
|------|------|-------------|-------------|------------|
| 1 | Core Extraction | 3,236 chars | 3,799 chars | standard |
| 2 | Stage Assessment | 2,250 chars | 2,323 chars | standard |
| 3 | Activity Signal Detection | 1,614 chars | 2,018 chars | lite |
| 4 | Readiness & Product Tracking | 1,764 chars | 1,542 chars | lite |
| 5 | Account Synthesis | 1,765 chars | 2,118 chars | lite |

**Total prompt/schema overhead per analysis**: ~21,429 characters (~5,300 tokens)

---

## Key Optimization Opportunities

### 1. ✅ Model Tier Selection (Already Implemented)
- **Standard tier** (`gemini-2.5-flash`): Core extraction & stage assessment
- **Lite tier** (`gemini-2.5-flash-lite`): Enrichment passes 3-5

**Savings**: ~40% cost reduction on enrichment passes

### 2. 🔧 Smart Transcript Truncation (Partially Implemented)
Current: `smartTruncate()` in ai-provider.ts caps at 30k chars with keyword prioritization.

**Improvements needed**:
- Apply truncation BEFORE pass 1 (currently only in enrichment)
- Use meeting metadata (duration, attendees) to estimate content density
- Short meetings (<30 min) rarely need full transcript

### 3. 🔧 Conditional Pass Execution
**Current**: All passes run sequentially regardless of content.

**Optimization**: Skip passes based on content type:
- **Email content**: Skip passes 3-5 (no validation tasks, limited readiness data)
- **Short meetings**: Skip account synthesis (pass 5)
- **No prior account data**: Skip account synthesis

### 4. 🔧 Schema Optimization
Current schemas include many optional fields that inflate response tokens.

**Recommendations**:
- Use `additionalProperties: false` to prevent extra fields
- Set `maxItems` on arrays to cap extraction counts
- Remove nullable/optional for required-only extraction

### 5. 🔧 Caching & Deduplication
**Current**: Each transcript is analyzed independently.

**Optimization**:
- Hash transcript content to detect re-analysis
- Cache core extraction results for 24h
- Skip re-analysis if content hash matches

---

## Implementation Priority

### High Impact (Implement Now)

1. **Add max items to arrays** - Prevents runaway token usage
2. **Early truncation** - Apply 30k limit before pass 1
3. **Content type routing** - Skip enrichment for emails

### Medium Impact (Next Phase)

4. **Pass result caching** - Content hash detection
5. **Conditional synthesis** - Only run if meaningful data exists

### Lower Priority

6. **Prompt compression** - Reduce instruction verbosity
7. **Parallel pass execution** - Run independent passes concurrently

---

## Optimized Schema Recommendations

### Example: Core Extraction Array Limits
```json
{
  "technologies": {
    "type": "array",
    "maxItems": 20,
    "items": {...}
  },
  "people": {
    "type": "array", 
    "maxItems": 15,
    "items": {...}
  },
  "nbas": {
    "type": "array",
    "maxItems": 10,
    "items": {...}
  },
  "painPoints": {
    "type": "array",
    "maxItems": 8,
    "items": {...}
  },
  "useCases": {
    "type": "array",
    "maxItems": 8,
    "items": {...}
  }
}
```

---

## Token Usage Estimates

### Current (Per Full Analysis)
- **Input tokens**: ~35,000 (30k transcript + 5k prompts/schemas)
- **Output tokens**: ~3,000-5,000 (varies by content richness)
- **Total per analysis**: ~40,000 tokens

### After Optimization (Projected)
- **Email content**: ~10,000 tokens (2 passes only)
- **Short meeting**: ~25,000 tokens (3 passes, truncated)
- **Full meeting**: ~35,000 tokens (optimized limits)

**Estimated savings**: 20-40% reduction in token usage

---

## Monitoring Recommendations

1. **Track per-pass duration** - Already logging in SSE events
2. **Log input/output token counts** - Add to pass completion logs
3. **Track skip rates** - Monitor conditional execution effectiveness
4. **A/B test prompts** - Use pipeline versioning for comparison

---

## Next Steps

1. Apply schema `maxItems` limits to database passes
2. Implement early truncation in unified-transcript-analysis
3. Add content-type routing to skip enrichment for emails
4. Add token usage logging to pass execution

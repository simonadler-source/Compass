# Analysis Pipeline Data Flow Audit

> **Purpose**: Document ALL data sources feeding into AI analysis prompts, their output destinations, and identify potential conflicts.

---

## Executive Summary

The transcript analysis pipeline has **two main phases** (Sync and Async) with **5 defined passes**. Data flows from multiple sources into AI prompts and outputs to various database tables. This document maps each data source, its usage, and identifies conflict points.

---

## Pipeline Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          USER IMPORTS TRANSCRIPT                         │
└─────────────────────────────────────────────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│              unified-transcript-analysis (SYNC PHASE)                    │
│                                                                          │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  DATA SOURCES INJECTED INTO PROMPTS:                              │  │
│  │                                                                    │  │
│  │  1. HARDCODED TAXONOMIES (prompt-library.ts)                      │  │
│  │     • PAIN_CATEGORIES (5 fixed values)                            │  │
│  │     • BUSINESS_IMPACTS (4 fixed values)                           │  │
│  │     • BUSINESS_THEMES (8 fixed values)                            │  │
│  │                                                                    │  │
│  │  2. FALLBACK_SCHEMAS (prompt-library.ts)                          │  │
│  │     • core_extraction schema                                       │  │
│  │     • stage_assessment schema                                      │  │
│  │                                                                    │  │
│  │  3. DATABASE-DRIVEN PROMPTS (analysis_passes table)               │  │
│  │     • Replaces fallback if pipeline exists                        │  │
│  │                                                                    │  │
│  │  4. CONTEXT FROM PRIOR INTERACTIONS (context-builder.ts)          │  │
│  │     • Recent meetings (last 5)                                    │  │
│  │     • Open NBAs (pending actions)                                 │  │
│  │     • Stakeholder info with trends                                │  │
│  │     • Known pain points and use cases                             │  │
│  │                                                                    │  │
│  │  5. ACCOUNT/OPPORTUNITY IDs (request params)                      │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                          │
│  ┌─────────────────┐    ┌─────────────────┐                             │
│  │ Pass 1: Core    │───▶│ Pass 2: Stage   │                             │
│  │ Extraction      │    │ Assessment      │                             │
│  └─────────────────┘    └─────────────────┘                             │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
                                     │
                                     ▼ (queued for async)
┌─────────────────────────────────────────────────────────────────────────┐
│                    enrich-transcript (ASYNC PHASE)                       │
│                                                                          │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  ADDITIONAL DATA SOURCES FOR ENRICHMENT:                          │  │
│  │                                                                    │  │
│  │  6. DETECTION RULES (detection_rules table)                       │  │
│  │     • Activity Signals tree rules                                 │  │
│  │     • Pendo Products tree rules                                   │  │
│  │     • Competitors tree rules                                      │  │
│  │     • trigger_phrases, context_qualifiers, exclusion_phrases      │  │
│  │     • confirmation_patterns, detection_intent, speaker_context    │  │
│  │                                                                    │  │
│  │  7. DEPLOYMENT TYPES (deployment_types table)                     │  │
│  │     • id, name, description                                       │  │
│  │                                                                    │  │
│  │  8. READINESS QUESTIONS (readiness_template_questions table)      │  │
│  │     • question, category, deployment_type linkage                 │  │
│  │                                                                    │  │
│  │  9. TECHNOLOGY REPOSITORY (technology_repository table)           │  │
│  │     • is_pendo_product products                                   │  │
│  │     • is_competitor products                                      │  │
│  │     • Names used in Pass 4 prompt                                 │  │
│  │                                                                    │  │
│  │  10. CORE EXTRACTION CONTEXT (from Pass 1)                        │  │
│  │      • painPoints, useCases, technologies from first pass         │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                          │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐      │
│  │ Pass 3: Activity│───▶│Pass 3b: Product │───▶│ Pass 4:         │      │
│  │ Signal Detection│    │ Detection       │    │ Readiness       │      │
│  └─────────────────┘    └─────────────────┘    └─────────────────┘      │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Detailed Pass-by-Pass Data Sources

### Pass 1: Core Extraction (unified-transcript-analysis)

| Data Source | Type | Location | Usage in Prompt |
|-------------|------|----------|-----------------|
| PAIN_CATEGORIES | Hardcoded array | prompt-library.ts:25-31 | Constrained enum in schema |
| BUSINESS_IMPACTS | Hardcoded array | prompt-library.ts:34-39 | Constrained enum in schema |
| BUSINESS_THEMES | Hardcoded array | prompt-library.ts:42-51 | Constrained enum in schema |
| Stakeholder types | Hardcoded enum | FALLBACK_SCHEMAS.core_extraction | 7 fixed values (champion, economic_buyer, etc.) |
| Action types | Hardcoded enum | FALLBACK_SCHEMAS.core_extraction | 10 fixed values (poc_setup, etc.) |
| Analysis context | Dynamic (DB) | context-builder.ts | Recent meetings, open NBAs, stakeholders |

**Outputs to:**
- `transcript_reviews.extracted_insights.technologies[]`
- `transcript_reviews.extracted_insights.people[]`
- `transcript_reviews.extracted_insights.nbas[]`
- `transcript_reviews.extracted_insights.painPoints[]`
- `transcript_reviews.extracted_insights.useCases[]`
- `transcript_reviews.extracted_insights.competitorMentions[]`

---

### Pass 2: Stage Assessment (unified-transcript-analysis)

| Data Source | Type | Location | Usage in Prompt |
|-------------|------|----------|-----------------|
| Sales stages | Hardcoded numbers | FALLBACK_SCHEMAS.stage_assessment | 0-7 numeric scale |
| Pre-sales stages | Hardcoded enum | FALLBACK_SCHEMAS.stage_assessment | 9 fixed values |
| SWOT categories | Hardcoded enum | FALLBACK_SCHEMAS.stage_assessment | 4 values |
| Pass 1 results | Dynamic context | Dependency chain | Uses core_extraction output |

**Outputs to:**
- `transcript_reviews.extracted_insights.salesStageAssessment`
- `transcript_reviews.extracted_insights.preSalesStageAssessment`
- `transcript_reviews.extracted_insights.commercialInsights[]`
- `transcript_reviews.extracted_insights.operationalMetrics[]`
- `transcript_reviews.extracted_insights.discoveryQuestions[]`

---

### Pass 3: Activity Signal Detection (enrich-transcript)

| Data Source | Type | Location | Usage in Prompt |
|-------------|------|----------|-----------------|
| Activity Signal rules | DB-driven | detection_rules (tree: f5e4d3c2-...) | Full rule definition injected |
| Deployment types | DB-driven | deployment_types table | ID, name, description |
| Pass 1 context | Dynamic | existingInsights | Pain points, use cases, technologies |

**Prompt Structure:**
```
DETECTION RULES:
Rule "POC Signals" (ID: xxx):
  Intent: IMPLEMENTED
  Speaker: CUSTOMER/PROSPECT must say
  Triggers: proof of concept, POC, pilot
  Context qualifiers: trial, test
  Exclusions: demo, presentation
  Confirmation required: we have, yes, it's working
```

**Outputs to:**
- `detection_rule_matches` table (upsert)
- `signal_occurrences` table (insert)
- Triggers: `detection_rule_actions` processing

---

### Pass 3b: Product Detection (enrich-transcript)

| Data Source | Type | Location | Usage in Prompt |
|-------------|------|----------|-----------------|
| Pendo Products rules | DB-driven | detection_rules (tree: b0000001-...) | trigger_phrases, context, exclusions |
| Competitor rules | DB-driven | detection_rules (tree: c0000001-...) | trigger_phrases, context, exclusions |

**Prompt Structure:**
```
PRODUCT DETECTION RULES:
"Analytics" (ID: xxx, Type: PENDO PRODUCT):
  Triggers: analytics, dashboards, usage data
  Context: reporting, metrics
  Exclusions: google analytics
```

**Outputs to:**
- `detection_rule_matches` table (upsert)
- `product_mentions` table (via database trigger sync)

---

### Pass 4: Readiness & Products (enrich-transcript)

| Data Source | Type | Location | Usage in Prompt |
|-------------|------|----------|-----------------|
| Readiness questions | DB-driven | readiness_template_questions | First 50 questions |
| Pendo products (names) | DB-driven | technology_repository | is_pendo_product=true names |
| Competitor products (names) | DB-driven | technology_repository | is_competitor=true names |
| Pass 1 context | Dynamic | existingInsights | Pain points, use cases, technologies |

**Outputs to:**
- `opportunity_readiness_answers` table (upsert)
- `transcript_reviews.extracted_insights.productMentions[]`

---

## Conflict Analysis

### Conflict 1: Detection Rules vs. Hardcoded Schemas

| Aspect | Hardcoded (prompt-library.ts) | DB-driven (detection_rules) |
|--------|-------------------------------|----------------------------|
| Pain categories | 5 fixed values | None - uses hardcoded |
| Business themes | 8 fixed values | None - uses hardcoded |
| Product detection | Not in Pass 1 | Full control in Pass 3b |
| Activity signals | Not in Pass 1 | Full control in Pass 3 |

**Resolution**: The hardcoded taxonomies constrain Pass 1 output structure, while detection rules control what signals are matched in async passes. **No direct conflict** because they operate in different phases.

**Potential Issue**: If a user adds a new business theme to detection rules, it won't be recognized by Pass 1 schema validation.

---

### Conflict 2: Products vs. Competitors Overlap

| Source | Where Used | Potential Conflict |
|--------|------------|-------------------|
| technology_repository.is_pendo_product | Pass 3b prompt, Pass 4 prompt | Same product can appear in both |
| technology_repository.is_competitor | Pass 3b prompt, Pass 4 prompt | Same product can appear in both |
| detection_rules (Pendo Products tree) | Pass 3b matching | Separate from technology_repository |
| detection_rules (Competitors tree) | Pass 3b matching | Separate from technology_repository |

**Auto-Sync Mechanism**: The trigger `auto_create_technology_detection_rule()` automatically creates detection rules when a technology is marked as `is_pendo_product` or `is_competitor`. This **prevents divergence**.

**Current Flow**:
```
technology_repository (is_pendo_product=true)
         │
         ▼ (trigger: auto_create_technology_detection_rule)
detection_rules (tree: Pendo Products)
         │
         ▼ (Pass 3b AI match)
detection_rule_matches
         │
         ▼ (trigger: sync_detection_match_to_product_mention)
product_mentions
```

---

### Conflict 3: Functional Areas vs. Use Cases

| Source | Definition Location | Used In |
|--------|---------------------|---------|
| Functional areas | functional_areas table | Architecture canvas, reference mapping |
| Business themes (use cases) | BUSINESS_THEMES hardcoded | Pass 1 schema constraint |
| Use case descriptions | AI-extracted | Pass 1 output |

**Conflict Point**: A use case extracted in Pass 1 is tagged with a `businessTheme` from the hardcoded list, but the account may have custom functional areas that don't map.

**Current State**: No automatic mapping between `functional_areas` and `BUSINESS_THEMES`. They are independent taxonomies.

---

## Signal Lineage & Uniqueness

### Current Signal Flow

```
┌─────────────────┐
│  AI Detection   │ (Pass 3, 3b, or 4)
│  with ruleId    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│detection_rule_  │ PRIMARY RECORD
│matches          │ - transcript_id (source)
│                 │ - rule_id (which rule)
│                 │ - matched_phrases (evidence)
│                 │ - speaker_type (who said it)
│                 │ - confidence_score
│                 │ - first_detected_at (meeting date)
└────────┬────────┘
         │
         ├──────────▶ signal_occurrences (historical tracking)
         │
         ▼ (if product/competitor rule)
┌─────────────────┐
│product_mentions │ DERIVED RECORD
│                 │ - Links back to rule via technology
│                 │ - Counts mentions per date
└─────────────────┘
```

### Uniqueness Guarantee

Each signal in `detection_rule_matches` is unique per:
- `transcript_id` (which transcript)
- `rule_id` (which detection rule)

The upsert uses `onConflict: "transcript_id,rule_id"` ensuring:
1. **One record per rule per transcript**
2. If re-analyzed, the record is updated, not duplicated
3. `first_detected_at` preserves original detection date

### Lineage Fields

Every signal record includes:
- `transcript_id`: Source transcript
- `rule_id`: Which rule triggered it
- `matched_phrases[]`: Exact text that matched
- `speaker_type`: internal/external/unknown
- `speaker_name`: Who said it
- `confidence_score`: AI confidence (0-1)

---

## Recommendations

### 1. Taxonomy Alignment
Consider migrating hardcoded taxonomies to database tables:
- `pain_categories` table
- `business_themes` table
- `stakeholder_types` table

This would allow admin customization without code changes.

### 2. Debug Panel Implementation
Add a debug panel showing:
- What data sources were used for this analysis
- The exact prompt sent to AI
- The raw AI response before mapping
- Which rules matched and why

### 3. Conflict Detection
Add validation that warns when:
- A technology_repository product has no detection rule
- A detection rule has no linked technology
- A functional area has no mapping to business themes

---

## Quick Reference: Data Source to Table Mapping

| Data Source | Stored In | Primary Key |
|-------------|-----------|-------------|
| Pain categories | HARDCODED | N/A |
| Business themes | HARDCODED | N/A |
| Stakeholder types | HARDCODED | N/A |
| Detection rules | detection_rules | id |
| Pendo products | technology_repository | id |
| Competitors | technology_repository | id |
| Readiness questions | readiness_template_questions | id |
| Functional areas | functional_areas | id |
| Deployment types | deployment_types | id |
| AI matches | detection_rule_matches | id |
| Signal history | signal_occurrences | id |
| Product mentions | product_mentions | id |
| Readiness answers | opportunity_readiness_answers | opportunity_id + question_id |

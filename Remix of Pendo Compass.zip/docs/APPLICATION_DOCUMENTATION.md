# Pendo TechMap - Complete Application Documentation

## Table of Contents

1. [Application Overview](#application-overview)
2. [Architecture](#architecture)
3. [User Interfaces](#user-interfaces)
4. [Security Architecture](#security-architecture)
5. [Encrypted Field Search](#encrypted-field-search)
6. [AI Analysis Pipeline](#ai-analysis-pipeline)
7. [Prompt Engineering](#prompt-engineering)
8. [Data Flow & Integration](#data-flow--integration)
9. [API Reference](#api-reference)

---

## Application Overview

### Purpose

Pendo TechMap is an enterprise sales intelligence platform designed to:

- **Track customer technology stacks** across sales opportunities
- **Analyze meeting transcripts** to extract strategic insights
- **Identify stakeholder dynamics** using MEDDIC methodology
- **Surface Next Best Actions (NBAs)** for sales teams
- **Manage competitive intelligence** and positioning
- **Generate customer success stories** from engagement data

### Technology Stack

| Layer | Technology |
|-------|------------|
| **Frontend** | React 18, TypeScript, Vite |
| **Styling** | Tailwind CSS, shadcn/ui components |
| **State Management** | TanStack Query (React Query) |
| **Routing** | React Router v7 |
| **Backend** | Supabase (PostgreSQL + Edge Functions) |
| **AI Processing** | Lovable AI Gateway (Gemini models) |
| **Authentication** | Custom PBKDF2 + TOTP MFA |
| **Encryption** | AES-256-GCM at rest |

### Core Entities

```mermaid
erDiagram
    ACCOUNTS ||--o{ OPPORTUNITIES : has
    ACCOUNTS ||--o{ TECHNOLOGIES : uses
    ACCOUNTS ||--o{ CONTACTS : contains
    ACCOUNTS ||--o{ TRANSCRIPTS : linked_to
    OPPORTUNITIES ||--o{ USE_CASES : tracks
    OPPORTUNITIES ||--o{ PAIN_POINTS : identifies
    OPPORTUNITIES ||--o{ NBAS : generates
    TRANSCRIPTS ||--o{ INSIGHTS : extracts
```

---

## Architecture

### High-Level Architecture

```mermaid
flowchart TB
    subgraph Client["Client Layer"]
        UI[React SPA]
        Gateway[API Gateway Client]
    end
    
    subgraph Edge["Edge Functions"]
        APIGateway[api-gateway]
        AnalyzeStream[analyze-transcript-streaming]
        Enrich[enrich-transcript]
        Search[search-meetings]
        Auth[auth-* functions]
    end
    
    subgraph Data["Data Layer"]
        DB[(PostgreSQL)]
        Vault[Supabase Vault]
    end
    
    subgraph AI["AI Layer"]
        LovableAI[Lovable AI Gateway]
        Gemini[Gemini Models]
    end
    
    UI --> Gateway
    Gateway --> APIGateway
    APIGateway --> DB
    APIGateway --> Vault
    AnalyzeStream --> LovableAI
    Enrich --> LovableAI
    LovableAI --> Gemini
```

### Design Patterns

#### 1. Gateway Pattern

All database operations for sensitive data flow through a centralized API Gateway Edge Function that:
- Validates session tokens
- Enforces table allowlists
- Automatically encrypts data on writes
- Automatically decrypts data on reads

```typescript
// Client-side usage
import { gateway } from '@/lib/apiGateway';

const { data, error } = await gateway
  .from('accounts')
  .select('*')
  .eq('id', accountId)
  .execute();
```

#### 2. Multi-Pass Analysis Pipeline

Transcript analysis is split into multiple passes for reliability and cost optimization:

| Pass | Type | Purpose | Model |
|------|------|---------|-------|
| **1** | Real-time | Core extraction (technologies, people, NBAs) | gemini-2.5-flash |
| **2** | Real-time | Stage assessment, commercial insights | gemini-2.5-flash |
| **3** | Async | Detection rule matching | gemini-2.5-flash-lite |
| **4** | Async | Readiness answers, product mentions | gemini-2.5-flash-lite |

#### 3. View-Tab Component Pattern

Complex interfaces follow a hierarchical pattern:
- **Page**: Route entry point (e.g., `AccountsPage`)
- **View**: Main content area (e.g., `AccountDetailView`)
- **Tab**: Domain-specific panels (e.g., `AccountInsightsTab`)

---

## User Interfaces

### Navigation Structure

```
├── /accounts                    # Account list with filtering
│   └── /accounts/:id           # Account detail with tabs
│       ├── Details             # Basic info, owner, stage
│       ├── Insights            # Pain points, themes, metrics
│       ├── Use Cases           # Tracked use cases with priority
│       ├── Architecture        # Technology canvas
│       ├── Priority Radar      # 2D visualization of priorities
│       ├── Actions             # NBAs grouped by status
│       ├── Opportunities       # Linked opportunities
│       ├── Story               # Customer story builder
│       ├── Transcripts         # Linked meeting transcripts
│       ├── Stakeholder Map     # Contact MEDDIC assessment
│       ├── Team                # Internal team members
│       └── Documents           # Attached files
├── /momentum                    # Meeting import queue
├── /nba                         # Cross-account NBA dashboard
├── /manager                     # Team performance dashboard
├── /activity-signals            # Signal detection overview
├── /detection-rules             # Rule configuration
├── /technology-library          # Technology repository
├── /reference-architecture      # Standard architecture layers
├── /customer-stories            # Story library
├── /integrations                # External connections
└── /settings                    # User/system configuration
```

### Key Views

#### Account Detail View
The primary workspace for account management, featuring:
- **11 tabbed sections** for comprehensive account data
- **Real-time data synchronization** via TanStack Query
- **Opportunity drill-down** for deal-specific context

#### Priority Radar
A 2D visualization that plots use cases on:
- **X-axis**: Business Impact (left = operational, right = strategic)
- **Y-axis**: Customer Priority (bottom = nice-to-have, top = critical)

Features:
- Drag-and-drop positioning
- Zoom and pan controls
- Auto-clustering of related items

#### Manager Dashboard
Team visibility showing:
- Activity metrics by team member
- Weekly heatmaps of engagement
- Opportunity alerts (stale, at-risk)
- Pipeline velocity tracking

---

## Security Architecture

### Authentication Flow

```mermaid
sequenceDiagram
    participant User
    participant Client
    participant AuthFn as auth-login
    participant DB
    participant Vault
    
    User->>Client: Enter credentials
    Client->>AuthFn: POST {email, password}
    AuthFn->>DB: Fetch user profile
    AuthFn->>Vault: Get PBKDF2 params
    AuthFn->>AuthFn: Verify hash (310K iterations)
    alt MFA Enabled
        AuthFn->>Client: {requiresMFA: true}
        User->>Client: Enter TOTP code
        Client->>AuthFn: POST {token, totpCode}
        AuthFn->>AuthFn: Verify TOTP (±1 window)
    end
    AuthFn->>DB: Create session
    AuthFn->>Client: {sessionToken, user}
    Client->>Client: Store in localStorage
```

### Password Security

| Parameter | Value |
|-----------|-------|
| Algorithm | PBKDF2-SHA256 |
| Iterations | 310,000 (OWASP 2023) |
| Salt Length | 16 bytes |
| Output Key | 256 bits |
| Min Length | 12 characters |
| Complexity | Upper + Lower + Number + Symbol |

### Session Management

| Parameter | Value |
|-----------|-------|
| Token Length | 384 bits |
| Duration | 7 days |
| Inactivity Timeout | 1 hour |
| Fingerprinting | User-Agent + IP hash |
| Storage | Server-side in `user_sessions` |

### Multi-Factor Authentication

| Parameter | Value |
|-----------|-------|
| Algorithm | TOTP (RFC 6238) |
| Hash | HMAC-SHA1 |
| Digits | 6 |
| Period | 30 seconds |
| Window | ±1 step (clock drift) |

### Brute Force Protection

```
Attempt 1-4: No lockout
Attempt 5:   2 minute lockout
Attempt 6:   4 minute lockout
Attempt 7:   8 minute lockout
...
Attempt N:   min(2^(N-5), 1440) minute lockout
Maximum:     24 hours
```

### Data Encryption

#### Algorithm
- **Cipher**: AES-256-GCM
- **Key Source**: `TRANSCRIPT_ENCRYPTION_KEY` secret
- **IV**: 12 bytes, unique per record

#### Encrypted Tables & Fields

| Table | Encrypted Fields |
|-------|------------------|
| `account_contacts` | name, email, phone, role, notes |
| `account_nbas` | action, notes |
| `account_pain_points` | pain_point, business_impact |
| `account_use_cases` | use_case, description |
| `account_metrics` | metric_value, context |
| `transcript_reviews` | transcript_content |
| `momentum_meetings` | title, host_email, host_name, attendees, transcript_content |
| `customer_stories` | situation, behavior, impact |

#### Encryption Schema Pattern

```sql
-- Each encrypted table follows this pattern:
CREATE TABLE example (
  id UUID PRIMARY KEY,
  
  -- Plaintext column (set to null after encryption)
  sensitive_field TEXT,
  
  -- Encrypted counterpart
  sensitive_field_encrypted TEXT,
  
  -- Encryption metadata
  encryption_iv TEXT,
  is_encrypted BOOLEAN DEFAULT false
);
```

### Row-Level Security (RLS)

All tables have RLS enabled with policies based on:
- **Authentication**: `auth.uid()` for user-specific data
- **Team Hierarchy**: `get_team_members()` function for manager visibility
- **Roles**: `user_roles` table for admin/manager permissions

Example Policy:
```sql
CREATE POLICY "Users can view own team's accounts"
ON accounts FOR SELECT
USING (
  owner_id = auth.uid() OR
  is_in_team(auth.uid(), owner_id) OR
  has_role(auth.uid(), 'admin')
);
```

---

## Encrypted Field Search

### Challenge

Traditional search indexes expose plaintext, violating security requirements. Deterministic encryption enables indexing but is vulnerable to frequency analysis.

### Solution: Ephemeral In-Memory Search

Instead of persistent indexes, we perform **server-side ephemeral search**:

```mermaid
sequenceDiagram
    participant Client
    participant SearchFn as search-meetings
    participant DB
    participant Vault
    
    Client->>SearchFn: POST {query, filters}
    SearchFn->>Vault: Get encryption key
    SearchFn->>DB: SELECT encrypted records (limit 10K)
    loop For each record
        SearchFn->>SearchFn: Decrypt in memory
        SearchFn->>SearchFn: Apply search filters
    end
    SearchFn->>Client: Return matching results
```

### Implementation

```typescript
// supabase/functions/search-meetings/index.ts

// 1. Fetch encrypted records
const { data: meetings } = await supabase
  .from('momentum_meetings')
  .select('id, title_encrypted, host_name_encrypted, ...')
  .eq('status', status)
  .limit(10000);

// 2. Decrypt and filter in memory
for (const meeting of meetings) {
  if (meeting.is_encrypted && meeting.pii_encryption_iv) {
    const title = await decryptValue(meeting.title_encrypted, key, iv);
    
    // 3. Apply search filter
    if (title.toLowerCase().includes(searchQuery)) {
      results.push({ ...meeting, title });
    }
  }
}
```

### Client Usage

```typescript
// src/hooks/useMeetingSearchIndex.ts
export function useMeetingSearchIndex(filters: SearchFilters) {
  return useQuery({
    queryKey: ['meeting-search', filters],
    queryFn: async () => {
      const { data } = await supabase.functions.invoke('search-meetings', {
        body: {
          searchQuery: filters.searchQuery,
          attendeeFilter: filters.attendeeFilter,
          statuses: ['pending', 'ignored'],
        },
      });
      return data.results;
    },
    staleTime: 30000, // Cache 30 seconds
  });
}
```

### Performance Considerations

| Constraint | Value |
|------------|-------|
| Max Records | 10,000 per query |
| Cache Duration | 30 seconds |
| Timeout | 60 seconds |

---

## AI Analysis Pipeline

### Pipeline Architecture

```mermaid
flowchart LR
    subgraph RT["Real-Time (Streaming)"]
        P1[Pass 1: Core Extraction]
        P2[Pass 2: Stage Assessment]
    end
    
    subgraph Async["Async (Background)"]
        P3[Pass 3: Detection Rules]
        P4[Pass 4: Readiness Answers]
    end
    
    Transcript --> P1
    P1 --> P2
    P2 --> |Queue| P3
    P3 --> P4
    P4 --> Database
```

### Pass Details

#### Pass 1: Core Extraction

**Purpose**: Extract foundational entities from transcripts

**Extracts**:
- Technologies (with relationship status: in_use, evaluating, replaced, etc.)
- People (with MEDDIC stakeholder classification)
- Pain Points (categorized by type)
- Use Cases (themed by business objective)
- Next Best Actions
- Competitor Mentions

**Model**: `google/gemini-2.5-flash`

#### Pass 2: Strategic Assessment

**Purpose**: Evaluate opportunity progression and commercial dynamics

**Extracts**:
- Sales Stage (0-6 scale)
- Pre-Sales Stage (Discovery → Technical Win)
- Commercial Insights (SWOT categorized)
- Operational Metrics
- Discovery Questions

**Model**: `google/gemini-2.5-flash`

#### Pass 3: Activity Signal Detection

**Purpose**: Match transcripts against configured detection rules

**Process**:
1. Fetch active detection rules with trigger phrases
2. Smart-truncate transcript to 30K chars focused on keywords
3. AI matches rules and extracts capture fields
4. Store matches in `detection_rule_matches`

**Model**: `google/gemini-2.5-flash-lite` (cost optimization)

#### Pass 4: Technical Readiness

**Purpose**: Extract answers to qualification questions

**Extracts**:
- Readiness Answers (mapped to template questions)
- Product Mentions (owned vs. competitor, with sentiment)

**Model**: `google/gemini-2.5-flash-lite` (cost optimization)

### Cost Optimization Techniques

#### 1. Smart Truncation

For enrichment passes, transcripts are truncated to relevant sections:

```typescript
export function smartTruncate(
  transcript: string,
  maxLength: number = 30000,
  keywords: string[] = []
): string {
  // Split into speaker turns
  const turns = transcript.split(/\n\n(?=[A-Z][a-z]+ [A-Z][a-z]+:)/g);
  
  // Score each turn by keyword matches
  const scoredTurns = turns.map((turn, index) => ({
    turn,
    score: keywords.reduce((acc, kw) => 
      acc + (turn.toLowerCase().includes(kw.toLowerCase()) ? 1 : 0), 0),
    index,
  }));
  
  // Take highest-scoring turns up to maxLength
  scoredTurns.sort((a, b) => b.score - a.score);
  // ...
}
```

#### 2. Content Hash Caching

Transcripts are only re-analyzed if content changes:

```typescript
const contentHash = computeContentHash(transcriptContent);

if (transcript.content_hash === contentHash && 
    transcript.last_enriched_hash === contentHash &&
    transcript.extracted_insights) {
  console.log('[Enrichment] Content unchanged, skipping');
  return;
}
```

#### 3. Tiered Model Selection

```typescript
export async function getAIConfig(tier: ModelTier = 'standard'): Promise<AIConfig> {
  const model = tier === 'lite' 
    ? 'google/gemini-2.5-flash-lite'  // Faster, cheaper
    : 'google/gemini-2.5-flash';       // Higher quality
  
  return {
    endpoint: 'https://ai.gateway.lovable.dev/v1/chat/completions',
    apiKey: LOVABLE_API_KEY,
    model,
  };
}
```

---

## Prompt Engineering

### Design Principles

1. **Structured Output**: All prompts use JSON schema constraints for reliable parsing
2. **Unified Taxonomies**: Consistent category vocabularies across passes
3. **Evidence-Based Scoring**: Scores require specific transcript evidence
4. **Database-Driven**: Prompts stored in `analysis_passes` table for versioning

### Taxonomy Definitions

#### Pain Categories (Type of Pain)

| Category | Description |
|----------|-------------|
| `vendor_relationship` | Support gaps, responsiveness, partnership friction |
| `technical_limitations` | Platform gaps, missing features, integration friction |
| `operational_friction` | Process inefficiencies, manual workarounds |
| `resource_constraints` | Skills, time, budget limitations |
| `strategic_misalignment` | Tool doesn't match business direction |

#### Business Themes (Use Case Objectives)

| Theme | Description |
|-------|-------------|
| `operational_efficiency` | Streamline processes, reduce waste |
| `customer_experience` | Improve user satisfaction |
| `revenue_growth` | Increase sales, expansion |
| `cost_reduction` | Lower expenses |
| `compliance_risk` | Meet regulations, reduce risk |
| `digital_transformation` | Modernize technology |
| `data_insights` | Better analytics, visibility |
| `team_productivity` | Enable employee effectiveness |

#### MEDDIC Stakeholder Types

| Type | Scoring Criteria |
|------|------------------|
| `champion` | Advocates internally + shares intel (both required for score >50) |
| `economic_buyer` | Controls budget, signs off on purchases |
| `decision_criteria_owner` | Defines requirements |
| `coach` | Provides guidance, internal ally |
| `blocker` | Opposes the deal |
| `end_user` | Will use the product |

### Schema Patterns

All AI responses are constrained by JSON schemas:

```typescript
const pass1CoreSchema = {
  type: "object",
  properties: {
    technologies: {
      type: "array",
      items: {
        type: "object",
        properties: {
          name: { type: "string" },
          confidence: { type: "number" },
          relationshipStatus: { 
            type: "string", 
            enum: ["mentioned", "in_use", "evaluating", "considering", "replaced"] 
          },
          suggestedLayer: { 
            type: "string", 
            enum: ["host", "build", "adopt", "growth", "ops"] 
          },
        },
        required: ["name", "confidence", "relationshipStatus", "suggestedLayer"]
      }
    },
    // ... other properties
  },
  required: ["technologies", "people", "painPoints", "useCases", "nbas"]
};
```

### Prompt Library Architecture

```mermaid
flowchart TB
    subgraph DB["Database"]
        Pipelines[analysis_pipelines]
        Passes[analysis_passes]
        Deps[analysis_pass_dependencies]
    end
    
    subgraph Code["Edge Functions"]
        Library[prompt-library.ts]
        Fallbacks[FALLBACK_PROMPTS]
    end
    
    Pipelines --> Passes
    Passes --> Deps
    Library --> |Fetch| Passes
    Library --> |Fallback| Fallbacks
```

### Versioning

Prompts can be updated without code changes:

1. Edit prompt in `analysis_passes` table
2. Increment `version` column
3. Optionally save previous version in `analysis_pass_versions`

---

## Data Flow & Integration

### Momentum Meeting Import

```mermaid
sequenceDiagram
    participant Momentum as Momentum API
    participant Sync as sync-momentum
    participant DB
    participant Import as importMomentumMeeting
    participant Analyze as analyze-transcript-streaming
    participant Enrich as enrich-transcript
    
    Sync->>Momentum: Fetch new meetings
    Sync->>DB: Upsert to momentum_meetings
    
    Note over Import: User clicks Import
    Import->>DB: Match to account
    Import->>Analyze: Stream analysis (Pass 1-2)
    Analyze-->>Import: Return insights
    Import->>DB: Create transcript_reviews
    Import->>DB: Create account_contacts
    Import->>DB: Create account_nbas
    Import->>Enrich: Queue enrichment
    Enrich->>DB: Update with Pass 3-4 results
```

### Account Matching Hierarchy

When importing meetings, accounts are matched in this order:

1. **Salesforce Account ID** (exact match)
2. **Account Name + Domain** (fuzzy match)
3. **Create New Account** (if no match found)

### Data Persistence Patterns

#### Upsert with Conflict Resolution

```typescript
const { data } = await encryptedUpsert('account_contacts', {
  account_id: accountId,
  email: contact.email, // Used as conflict key
  name: contact.name,
  role: contact.role,
  stakeholder_type: contact.stakeholderType,
  influence_level: contact.influenceLevel,
});
```

#### Insight Merging

When new insights are extracted, they're merged with existing data:

```typescript
// Merge new pain points with existing
const existingPains = await gateway.from('account_pain_points')
  .select('*')
  .eq('account_id', accountId)
  .execute();

const mergedPains = deduplicateAndMerge(existingPains.data, newPainPoints);
```

---

## API Reference

### API Gateway

**Endpoint**: `supabase/functions/api-gateway`

**Request Format**:
```typescript
interface GatewayRequest {
  action: 'select' | 'insert' | 'update' | 'upsert' | 'delete';
  table: string;
  data?: Record<string, any> | Record<string, any>[];
  params?: {
    select?: string;
    filters?: Array<{ column: string; operator: string; value: any }>;
    order?: { column: string; ascending?: boolean };
    limit?: number;
    offset?: number;
    single?: boolean;
  };
}
```

**Response Format**:
```typescript
interface GatewayResponse<T> {
  data: T | null;
  error: { message: string; code?: string } | null;
  success: boolean;
}
```

### Authentication Functions

| Function | Purpose |
|----------|---------|
| `auth-register` | Create new user account |
| `auth-login` | Authenticate user |
| `auth-setup-2fa` | Generate TOTP secret |
| `auth-verify-2fa` | Validate TOTP code |
| `auth-change-password` | Update password |
| `auth-forgot-password` | Initiate reset flow |
| `auth-validate-session` | Check session validity |
| `auth-logout` | Invalidate session |

### Analysis Functions

| Function | Purpose | Timeout |
|----------|---------|---------|
| `analyze-transcript-streaming` | Real-time Pass 1-2 | 120s |
| `enrich-transcript` | Async Pass 3-4 | 180s |
| `synthesize-account-insights` | Account-level synthesis | 120s |
| `search-meetings` | Encrypted search | 60s |

### Utility Functions

| Function | Purpose |
|----------|---------|
| `encrypt-transcript` | Encrypt single value |
| `decrypt-transcript` | Decrypt transcript content |
| `encrypt-pii` | Batch encrypt PII fields |
| `decrypt-pii` | Batch decrypt PII fields |

---

## Appendix

### Environment Variables

| Variable | Purpose |
|----------|---------|
| `VITE_SUPABASE_URL` | Supabase project URL |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Supabase anon key |
| `TRANSCRIPT_ENCRYPTION_KEY` | AES-256 encryption key |
| `LOVABLE_API_KEY` | Lovable AI Gateway key |
| `MOMENTUM_API_KEY` | Momentum integration |
| `RESEND_API_KEY` | Email sending |

### Database Functions

| Function | Purpose |
|----------|---------|
| `validate_session(_token)` | Check session validity |
| `get_team_members(_manager_id)` | Recursive team lookup |
| `is_in_team(_manager_id, _user_id)` | Team membership check |
| `has_role(_user_id, _role)` | Role check |
| `is_admin(_user_id)` | Admin check |
| `can_access_page(_user_id, _page_path)` | Page access check |

### Technology Layers

| Layer | Description |
|-------|-------------|
| `host` | Infrastructure, cloud platforms |
| `build` | Development tools, CI/CD |
| `adopt` | Business applications |
| `growth` | Analytics, marketing tech |
| `ops` | Operations, monitoring |

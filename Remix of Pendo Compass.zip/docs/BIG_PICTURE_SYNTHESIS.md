# Meeting Analysis Pipeline & Big Picture Synthesis

## Current State Assessment

### What We Have ✅

#### 1. Per-Meeting Analysis (Strong)
Each transcript is analyzed through a multi-pass pipeline:
- **Core Extraction**: Technologies, stakeholders, pain points, use cases, NBAs, competitors
- **Stage Assessment**: Sales stage (0-6), pre-sales stage, commercial insights, metrics
- **Enrichment**: Activity signals, readiness answers, product mentions

**Verdict**: ✅ Individual meeting analysis is comprehensive

#### 2. Stakeholder Time-Series Tracking (Strong)
- `contact_meeting_snapshots` - Per-meeting stakeholder state captured
- `stakeholder_history` - Database trigger tracks all changes with old/new values
- Weighted aggregation - Recency + meeting type weights for trend analysis
- Trend calculation - Linear regression determines improving/stable/declining

**Verdict**: ✅ Stakeholder evolution tracking exists, but not surfaced in synthesis

#### 3. Account-Level Synthesis (Partial)
- `synthesize-account-insights` consolidates pain points → strategic themes
- Creates executive summary with health indicators
- Stored in `account_exec_summaries` and `account_strategic_themes`

**Verdict**: ⚠️ Point-in-time recalculation, doesn't leverage historical context

---

### What's Missing ❌

#### 1. Cross-Meeting Comparison in AI Prompts
**Current**: Each meeting analyzed in isolation
**Gap**: AI doesn't see "In the last meeting, Sarah was skeptical. What changed?"

**Impact**: Missing narrative continuity and evolution detection

#### 2. Stakeholder Trajectory in Synthesis
**Current**: Synthesis focuses on pain/use case themes
**Gap**: Executive summary doesn't include:
- "Champion engagement declining over 3 meetings"
- "New executive sponsor identified in recent meeting"
- "Key blocker's concerns were addressed"

**Impact**: Missing critical relationship dynamics

#### 3. Opportunity Context During Analysis
**Current**: Transcript analyzed with minimal context
**Gap**: AI doesn't know:
- Existing open NBAs that might be completed
- Prior use cases already identified
- Technologies already documented

**Impact**: Duplicate extraction, missed connections, inconsistent data

#### 4. Incremental vs. Full Recalculation
**Current**: Account synthesis recalculates from scratch each time
**Gap**: Doesn't preserve:
- Manual validations/corrections
- Confidence adjustments from multiple confirmations
- Theme stability indicators

**Impact**: User edits can be overwritten, confidence doesn't compound

---

## Recommended Architecture Changes

### Phase 1: Context-Aware Meeting Analysis

#### A. Pre-Analysis Context Injection
Before analyzing a new transcript, fetch and inject:

```typescript
interface AnalysisContext {
  // From this opportunity
  recentMeetingSummary?: string;  // 2-3 sentence summary of last meeting
  openNBAs: { action: string; status: string; dueDate: string }[];
  knownStakeholders: { name: string; role: string; lastSentiment: number }[];
  identifiedUseCases: { useCase: string; status: string }[];
  
  // From this account  
  accountStage: string;
  strategicThemes: string[];
  championStatus: 'strong' | 'at_risk' | 'none';
  
  // Historical comparison
  stakeholderDeltas?: { name: string; previousSentiment: number; trend: string }[];
}
```

#### B. Enhanced Prompt with Context
Modify `unified-transcript-analysis` to include:

```
PRIOR CONTEXT:
- Last meeting (2 weeks ago): Discussed POC scope, Sarah (VP Eng) was cautiously optimistic
- Open NBAs: "Send integration docs" (due tomorrow, PROSPECT), "Schedule exec briefing" (next week, SE)
- Known stakeholders: Sarah (VP, sentiment 65, stable), Mike (Director, sentiment 80, improving)
- Strategic themes: "Operational efficiency", "Data-driven decisions"

ANALYZE THIS MEETING FOR:
1. Standard extractions (people, technologies, etc.)
2. NBA completions: Did any open NBAs get discussed/completed?
3. Stakeholder changes: How did sentiment/influence shift from last meeting?
4. Theme reinforcement: Did they mention known themes? New themes emerging?
5. Deal progression: What exit criteria were met since last meeting?
```

### Phase 2: Enhanced Synthesis with Trajectories

#### A. Stakeholder Trajectory Analysis
Add to `synthesize-account-insights`:

```typescript
interface StakeholderTrajectory {
  contactId: string;
  name: string;
  role: string;
  trajectory: 'champion_emerging' | 'champion_stable' | 'champion_fading' | 
              'blocker_emerging' | 'neutral_engaged' | 'neutral_disengaged';
  recentTrend: 'improving' | 'stable' | 'declining';
  keyEvidence: string[];
  riskLevel: 'low' | 'medium' | 'high';
}
```

#### B. Narrative Continuity
Executive summary should include:

```
RELATIONSHIP DYNAMICS:
- Sarah (VP Engineering) has moved from skeptical to cautiously optimistic 
  over 3 meetings, now showing champion signals
- Mike remains our strongest advocate, actively selling internally
- New risk: CTO hasn't attended last 2 meetings after initially being engaged

THEME EVOLUTION:
- "Operational efficiency" - Reinforced in 4 of 5 meetings, HIGH confidence
- "Real-time analytics" - First mentioned 2 meetings ago, gaining traction
- "Mobile deployment" - Mentioned once, not reinforced, may be deprioritized

DEAL MOMENTUM:
- 3 weeks ago: Stage 2 (Problem discussion)
- 2 weeks ago: Stage 3 (Solution benefits)
- This week: Stage 3.5 (POC scoping, approaching Stage 4)
- Velocity: Healthy, ~1 stage every 2 weeks
```

### Phase 3: Confidence Compounding

#### A. Validation Count Tracking
When same insight extracted multiple times:
```sql
-- Example: Same use case mentioned in 3 meetings
UPDATE account_use_cases 
SET validation_count = validation_count + 1,
    confidence_score = LEAST(confidence_score + 0.1, 1.0),
    last_validated_at = now()
WHERE account_id = $1 
  AND similarity(use_case, $2) > 0.8;
```

#### B. Merge vs. Create Logic
```typescript
async function handleExtractedInsight(newInsight: PainPoint, existing: PainPoint[]) {
  const match = existing.find(e => 
    similarity(e.pain_point, newInsight.pain_point) > 0.8
  );
  
  if (match) {
    // Reinforce existing - increase confidence, update validation
    await reinforceInsight(match.id, newInsight.confidence);
    return { action: 'reinforced', id: match.id };
  } else {
    // New insight - create with standard confidence
    const id = await createInsight(newInsight);
    return { action: 'created', id };
  }
}
```

---

## Implementation Priority

### High Priority (Do First)
1. **Context injection into transcript analysis** - Biggest impact on quality
2. **NBA completion detection** - Already have the prompt, needs connection
3. **Stakeholder snapshot creation after analysis** - Schema exists, needs automation

### Medium Priority (Phase 2)
4. **Stakeholder trajectory in synthesis** - Leverages existing snapshot data
5. **Deal velocity tracking** - Track stage changes over time
6. **Confidence compounding** - Prevent duplicate insights

### Lower Priority (Phase 3)
7. **Narrative continuity in exec summary** - Requires good trajectory data first
8. **Theme stability indicators** - Nice-to-have once core is solid
9. **Comparison view UI** - Show before/after between meetings

---

## Quick Wins to Implement Now

### 1. Add Account Context to Analysis Endpoint
Modify `unified-transcript-analysis` to accept and use prior context:

```typescript
// Add to input schema
accountContext: z.object({
  recentMeetingSummary: z.string().optional(),
  openNBAs: z.array(z.object({ action: z.string(), dueDate: z.string() })).optional(),
  knownStakeholders: z.array(z.object({ name: z.string(), lastSentiment: z.number() })).optional(),
}).optional()
```

### 2. Trigger Stakeholder Snapshots Automatically
After transcript approval, create snapshots for each extracted stakeholder:

```typescript
// In transcript approval handler
for (const person of extractedPeople) {
  if (!person.isInternal) {
    await createContactSnapshot({
      contact_id: matchedContact.id,
      transcript_id: transcriptId,
      meeting_date: meetingDate,
      sentiment: person.sentiment,
      influence_level: person.influenceLevel,
      champion_score: person.championScore,
    });
  }
}
```

### 3. Include Stakeholder Trends in Synthesis
Add to synthesis context:

```typescript
const stakeholderTrends = await getStakeholderTrends(accountId);
context += `\n\nSTAKEHOLDER TRAJECTORIES:\n${
  stakeholderTrends.map(s => 
    `- ${s.name} (${s.role}): ${s.sentimentTrend} sentiment, ${s.totalMeetings} meetings`
  ).join('\n')
}`;
```

---

## Success Metrics

| Metric | Current | Target |
|--------|---------|--------|
| Duplicate insights created | ~30% | <5% |
| NBA auto-completion rate | 0% | 50%+ |
| Stakeholder trend accuracy | N/A | 80%+ |
| Exec summary includes trajectories | No | Yes |
| Context-aware analysis | No | Yes |

---

## Files to Modify

1. `supabase/functions/unified-transcript-analysis/index.ts` - Add context acceptance
2. `supabase/functions/synthesize-account-insights/index.ts` - Add stakeholder trajectories
3. `src/components/views/AccountTranscriptsTab.tsx` - Trigger snapshot creation
4. `src/hooks/useAccountInsights.ts` (new) - Aggregate cross-meeting intelligence
5. `supabase/functions/_shared/insight-store.ts` - Deduplication/merge logic

# Detection Rules System - Complete Documentation

## Overview

The Detection Rules system is a powerful, reusable pattern-matching engine designed to analyze meeting transcripts, identify specific topics/signals, and trigger automated actions. It provides a hierarchical rule structure that can:

1. **Detect patterns** in text using trigger phrases with context qualifiers and exclusions
2. **Capture structured data** by extracting specific fields from matched content
3. **Trigger automated actions** including Next Best Actions (NBAs) and validation tasks
4. **Map to readiness questions** to auto-populate opportunity qualification data
5. **Surface discovery questions** to guide future conversations

---

## Database Schema

### Core Tables

#### `detection_rule_trees`
Top-level containers that group related rules. Trees can be associated with deployment types for contextual filtering.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid | Primary key |
| `name` | string | Display name (e.g., "Technical Discovery") |
| `description` | string | Optional description |
| `deployment_type_id` | uuid | FK to `deployment_types` - filters when rules apply |
| `is_active` | boolean | Enable/disable entire tree |
| `created_at` | timestamp | Creation time |
| `updated_at` | timestamp | Last update time |

#### `detection_rules`
Individual rules within a tree. Supports hierarchical parent-child relationships for drill-down detection.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid | Primary key |
| `tree_id` | uuid | FK to `detection_rule_trees` |
| `parent_rule_id` | uuid | FK to self - enables rule nesting |
| `name` | string | Rule name (e.g., "Cloud Migration") |
| `description` | string | What this rule detects |
| `trigger_phrases` | string[] | Array of phrases that trigger this rule |
| `context_qualifiers` | string[] | Phrases that must also be present |
| `exclusion_phrases` | string[] | Phrases that prevent triggering |
| `confidence_threshold` | float | 0-1, minimum confidence to trigger |
| `sort_order` | int | Display ordering |
| `is_active` | boolean | Enable/disable rule |
| `validation_task_template_id` | uuid | FK to `validation_task_templates` - auto-creates tasks |
| `created_at` | timestamp | Creation time |
| `updated_at` | timestamp | Last update time |

### Associated Tables

#### `detection_rule_questions`
Discovery questions associated with a rule - prompts for follow-up conversations.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid | Primary key |
| `rule_id` | uuid | FK to `detection_rules` |
| `question_text` | string | The discovery question |
| `is_required` | boolean | Whether question is mandatory |
| `sort_order` | int | Display ordering |

#### `detection_rule_nba_templates`
Next Best Action templates automatically generated when a rule matches.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid | Primary key |
| `rule_id` | uuid | FK to `detection_rules` |
| `action_text` | string | The action to take |
| `action_type` | string | Category (poc_setup, integration_review, etc.) |
| `priority` | string | low/medium/high |
| `sort_order` | int | Display ordering |

#### `detection_rule_capture_fields`
Defines structured data fields to extract when a rule matches.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid | Primary key |
| `rule_id` | uuid | FK to `detection_rules` |
| `field_name` | string | Name of the field (e.g., "Contract End Date") |
| `field_type` | string | text/number/date/boolean/list |
| `description` | string | What to capture |
| `extraction_prompt` | string | AI prompt for extraction |
| `is_required` | boolean | Whether field is mandatory |
| `sort_order` | int | Display ordering |

#### `detection_rule_readiness_mappings`
Maps rules to readiness questions - auto-populates qualification data.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid | Primary key |
| `rule_id` | uuid | FK to `detection_rules` |
| `readiness_question_id` | uuid | FK to `readiness_template_questions` |
| `auto_answer` | string | Static answer to set |
| `auto_answer_json` | jsonb | Complex answer data |

### Match Tracking Tables

#### `detection_rule_matches`
Records when rules match transcripts.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid | Primary key |
| `rule_id` | uuid | FK to `detection_rules` |
| `transcript_id` | uuid | FK to `transcript_reviews` |
| `opportunity_id` | uuid | FK to `opportunities` |
| `matched_phrases` | string[] | Which phrases matched |
| `confidence_score` | float | Match confidence |
| `created_at` | timestamp | When matched |

#### `account_captured_insights`
Stores extracted field values per account.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid | Primary key |
| `account_id` | uuid | FK to `accounts` |
| `capture_field_id` | uuid | FK to `detection_rule_capture_fields` |
| `value` | string | Simple value |
| `value_json` | jsonb | Complex/structured value |
| `confidence_score` | float | Extraction confidence |
| `rule_match_id` | uuid | FK to `detection_rule_matches` |
| `source_transcript_id` | uuid | FK to `transcript_reviews` |
| `extracted_at` | timestamp | When extracted |

---

## Frontend Architecture

### React Hooks (`src/hooks/useDetectionRules.ts`)

#### Data Fetching Hooks

```typescript
// Fetch all rule trees
useDetectionRuleTrees(): DetectionRuleTree[]

// Fetch rules for a specific tree (returns hierarchical structure)
useDetectionRules(treeId: string): DetectionRule[]

// Fetch complete rule details including questions, NBAs, mappings, capture fields
useDetectionRuleDetails(ruleId: string): {
  rule: DetectionRule;
  questions: DetectionRuleQuestion[];
  nbaTemplates: DetectionRuleNBATemplate[];
  readinessMappings: DetectionRuleReadinessMapping[];
  captureFields: DetectionRuleCaptureField[];
}

// Fetch readiness questions available for mapping
useReadinessQuestionsForMapping(): CategoryWithQuestions[]

// Fetch validation task templates for linking
useValidationTaskTemplates(): ValidationTaskTemplate[]

// Fetch captured insights for an account
useAccountCapturedInsights(accountId: string): AccountCapturedInsight[]
```

#### Mutation Hooks

```typescript
// Tree CRUD
useCreateRuleTree()
useUpdateRuleTree()
useDeleteRuleTree()

// Rule CRUD
useCreateRule()
useUpdateRule()
useDeleteRule()

// Question CRUD
useUpsertRuleQuestion()
useDeleteRuleQuestion()

// NBA Template CRUD
useUpsertRuleNBA()
useDeleteRuleNBA()

// Readiness Mapping CRUD
useUpsertReadinessMapping()
useDeleteReadinessMapping()

// Capture Field CRUD
useUpsertCaptureField()
useDeleteCaptureField()
```

### TypeScript Interfaces

```typescript
interface DetectionRuleTree {
  id: string;
  name: string;
  description: string | null;
  deployment_type_id: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  deployment_type?: { id: string; name: string } | null;
}

interface DetectionRule {
  id: string;
  tree_id: string;
  parent_rule_id: string | null;
  name: string;
  description: string | null;
  trigger_phrases: string[];
  context_qualifiers: string[];
  exclusion_phrases: string[];
  confidence_threshold: number;
  sort_order: number;
  is_active: boolean;
  validation_task_template_id: string | null;
  children?: DetectionRule[];  // Populated by useDetectionRules hook
  validation_task_template?: {
    id: string;
    activity: string;
    module: string;
    sub_module: string | null;
  } | null;
}

interface DetectionRuleQuestion {
  id: string;
  rule_id: string;
  question_text: string;
  is_required: boolean;
  sort_order: number;
}

interface DetectionRuleNBATemplate {
  id: string;
  rule_id: string;
  action_text: string;
  action_type: string;
  priority: string;
  sort_order: number;
}

interface DetectionRuleCaptureField {
  id: string;
  rule_id: string;
  field_name: string;
  field_type: string;  // text | number | date | boolean | list
  description: string | null;
  extraction_prompt: string | null;
  is_required: boolean;
  sort_order: number;
}

interface DetectionRuleReadinessMapping {
  id: string;
  rule_id: string;
  readiness_question_id: string;
  auto_answer: string | null;
  auto_answer_json: any | null;
  readiness_question?: {
    id: string;
    question: string;
    field_type: string;
    category?: { id: string; name: string };
  };
}
```

### UI Component (`src/components/views/DetectionRulesView.tsx`)

Three-panel layout:
1. **Trees Panel** (left) - List of rule trees with active/inactive toggle
2. **Rules Panel** (center) - Hierarchical tree view of rules within selected tree
3. **Details Panel** (right) - Tabbed interface for selected rule:
   - **Configuration** - Trigger phrases, linked validation task, discovery questions, NBA templates
   - **Capture Fields** - Define fields to extract from transcripts
   - **Readiness Mapping** - Link rules to readiness questions
   - **Test & Preview** - Live testing of trigger phrases

---

## Backend Processing

### Edge Function: `analyze-transcript`

The primary AI-powered function that processes transcripts and applies detection rules.

#### Input Schema

```typescript
{
  transcript: string;          // The transcript text to analyze
  accounts: Account[];         // Known accounts for matching
  competitors: Competitor[];   // Known competitors to detect
  opportunityId?: string;      // Link to opportunity for readiness extraction
  existingInsights?: {         // Previously captured data (for incremental enrichment)
    technologies: Technology[];
    painPoints: string[];
    useCases: string[];
    competitorMentions: string[];
    metrics: Metric[];
  };
}
```

#### Output Schema

```typescript
{
  technologies: ExtractedTechnology[];
  people: ExtractedPerson[];
  nbas: NextBestAction[];
  discoveryQuestions: ExtractedDiscoveryQuestion[];
  commercialInsights: CommercialInsight[];
  operationalMetrics: ExtractedMetric[];
  suggestedAccountId: string | null;
  suggestedAccountName: string | null;
  suggestedNewAccountName: string | null;
  accountConfidence: number;
  accountExists: boolean;
  insights: {
    painPoints: string[];
    useCases: string[];
    competitorMentions: string[];
  };
  readinessExtraction?: any;  // If opportunityId provided
}
```

#### Processing Flow

1. **Input Validation** - Zod schema validates all inputs
2. **Context Building** - Builds prompt context from:
   - Account list for matching
   - Competitor list (primary/secondary)
   - Existing insights (for deduplication)
3. **AI Analysis** - Calls AI gateway with structured function calling
4. **Account Matching** - Matches suggested account to existing accounts
5. **Readiness Extraction** - If opportunityId provided, triggers separate extraction
6. **Response** - Returns structured analysis result

---

## Usage Patterns

### Pattern 1: Topic Detection with Actions

**Use Case**: Detect when "cloud migration" is discussed and create follow-up tasks.

```sql
-- Tree
INSERT INTO detection_rule_trees (name, description)
VALUES ('Technical Discovery', 'Detect technical topics from calls');

-- Rule
INSERT INTO detection_rules (tree_id, name, trigger_phrases, confidence_threshold)
VALUES (
  '<tree_id>',
  'Cloud Migration Interest',
  ARRAY['cloud migration', 'moving to cloud', 'cloud transformation', 'lift and shift'],
  0.7
);

-- NBA Template
INSERT INTO detection_rule_nba_templates (rule_id, action_text, priority)
VALUES (
  '<rule_id>',
  'Schedule cloud architecture review session',
  'high'
);
```

### Pattern 2: Hierarchical Detection

**Use Case**: Detect general "security" topic, then drill down to specific security areas.

```sql
-- Parent Rule
INSERT INTO detection_rules (tree_id, name, trigger_phrases)
VALUES ('<tree_id>', 'Security Concerns', ARRAY['security', 'compliance', 'SOC2', 'GDPR']);

-- Child Rules
INSERT INTO detection_rules (tree_id, parent_rule_id, name, trigger_phrases)
VALUES 
  ('<tree_id>', '<parent_id>', 'Data Privacy', ARRAY['PII', 'data privacy', 'GDPR', 'CCPA']),
  ('<tree_id>', '<parent_id>', 'Authentication', ARRAY['SSO', 'SAML', 'OAuth', 'MFA']);
```

### Pattern 3: Capture Field Extraction

**Use Case**: Extract contract renewal date when mentioned.

```sql
INSERT INTO detection_rule_capture_fields (
  rule_id, 
  field_name, 
  field_type, 
  extraction_prompt
)
VALUES (
  '<rule_id>',
  'Contract End Date',
  'date',
  'Extract the date when their current contract or agreement ends'
);
```

### Pattern 4: Readiness Auto-Population

**Use Case**: When "Salesforce" is mentioned, mark the Salesforce integration readiness question as "Yes".

```sql
INSERT INTO detection_rule_readiness_mappings (
  rule_id,
  readiness_question_id,
  auto_answer
)
VALUES (
  '<rule_id>',
  '<question_id_for_uses_salesforce>',
  'Yes'
);
```

---

## Reusing This Pattern

### For a New Domain

1. **Create Tables** - Use the same schema pattern:
   - A "trees" table for grouping
   - A "rules" table with trigger logic and parent-child support
   - Associated tables for questions, actions, capture fields

2. **Create Hooks** - Follow the pattern in `useDetectionRules.ts`:
   - Query hooks for trees, rules, and details
   - Mutation hooks for CRUD operations
   - Build hierarchical tree structure in the query

3. **Create UI** - Three-panel layout works well:
   - Left: Container selection
   - Center: Hierarchical item list
   - Right: Detail editing with tabs

4. **Create Processing Function** - Edge function that:
   - Accepts content and context
   - Uses AI with structured function calling
   - Applies rules and generates outputs

### Key Design Decisions

1. **Hierarchical Rules** - Parent-child relationships allow broad-to-specific detection
2. **Multiple Action Types** - Questions, NBAs, capture fields, readiness mappings
3. **Confidence Thresholds** - Allows tuning sensitivity
4. **Context Qualifiers** - Improves accuracy by requiring additional context
5. **Exclusion Phrases** - Prevents false positives
6. **Deployment Type Filtering** - Rules can apply to specific contexts

---

## API Reference

### Create Rule Tree

```typescript
const createTree = useCreateRuleTree();
await createTree.mutateAsync({
  name: 'My Rule Tree',
  description: 'Optional description',
  deployment_type_id: 'uuid-or-undefined'
});
```

### Create Rule

```typescript
const createRule = useCreateRule();
await createRule.mutateAsync({
  tree_id: 'tree-uuid',
  parent_rule_id: null,  // or parent rule UUID
  name: 'Rule Name',
  description: 'What this detects',
  trigger_phrases: ['phrase 1', 'phrase 2'],
  context_qualifiers: ['optional', 'context'],
  exclusion_phrases: ['exclude', 'these'],
  confidence_threshold: 0.7
});
```

### Add Capture Field

```typescript
const upsertField = useUpsertCaptureField();
await upsertField.mutateAsync({
  rule_id: 'rule-uuid',
  field_name: 'Contract Value',
  field_type: 'number',
  description: 'Annual contract value',
  extraction_prompt: 'Extract the total contract or deal value mentioned'
});
```

### Add Readiness Mapping

```typescript
const upsertMapping = useUpsertReadinessMapping();
await upsertMapping.mutateAsync({
  rule_id: 'rule-uuid',
  readiness_question_id: 'question-uuid',
  auto_answer: 'Yes'
});
```

---

## Testing Rules

The UI provides a "Test & Preview" tab where you can:

1. Enter sample text in the input field
2. See which trigger phrases match
3. View match confidence
4. Detect "don't know" phrases that indicate uncertainty

Test phrases like:
- "I don't know"
- "We haven't decided"
- "Still evaluating"
- "Let me get back to you"

Are flagged as uncertainty indicators.

---

## Best Practices

1. **Start Broad, Drill Down** - Create parent rules for general topics, child rules for specifics
2. **Use Context Qualifiers** - Improve accuracy by requiring supporting context
3. **Add Exclusions** - Prevent false positives with exclusion phrases
4. **Test Thoroughly** - Use the preview tab before activating rules
5. **Link to Actions** - Always associate rules with at least one action (NBA, question, capture field)
6. **Review Captured Data** - Regularly review extracted insights for accuracy
7. **Tune Thresholds** - Adjust confidence thresholds based on false positive rates

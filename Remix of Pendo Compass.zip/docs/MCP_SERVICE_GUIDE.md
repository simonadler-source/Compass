# MCP Service — Query & Write Guide

## Overview

The Searchitecture MCP (Model Context Protocol) server exposes your account, opportunity, competitive intelligence, and transcript data to external AI agents, CRMs, and automation tools via a JSON-RPC 2.0 interface.

**Endpoint:**
```
POST https://uxqugehmbqojblirttdy.supabase.co/functions/v1/mcp-server
```

---

## Authentication

Every request requires an API key via **one** of these headers:

| Header | Format |
|--------|--------|
| `x-mcp-api-key` | `mcp_sk_your_key_here` |
| `Authorization` | `Bearer mcp_sk_your_key_here` |

### Generating an API Key

1. Navigate to **Settings → Integrations → MCP Server** tab
2. Click **Generate New Key**
3. Name the key, set permissions (`read`, `read+write`), and optionally restrict to specific tools
4. Copy the key immediately — it is shown only once (stored as SHA-256 hash)

---

## Protocol Flow

The MCP server implements the [MCP Streamable HTTP transport](https://spec.modelcontextprotocol.io/specification/2024-11-05/transport/#streamable-http). A typical session:

### 1. Initialize

```bash
curl -X POST https://uxqugehmbqojblirttdy.supabase.co/functions/v1/mcp-server \
  -H "Content-Type: application/json" \
  -H "x-mcp-api-key: mcp_sk_your_key_here" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "initialize",
    "params": {
      "protocolVersion": "2024-11-05",
      "capabilities": {},
      "clientInfo": { "name": "my-agent", "version": "1.0.0" }
    }
  }'
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "result": {
    "protocolVersion": "2024-11-05",
    "capabilities": { "tools": { "listChanged": false } },
    "serverInfo": { "name": "searchitecture-mcp", "version": "1.0.0" }
  },
  "id": 1
}
```

### 2. List Available Tools

```bash
curl -X POST <endpoint> \
  -H "Content-Type: application/json" \
  -H "x-mcp-api-key: mcp_sk_your_key_here" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/list",
    "params": {}
  }'
```

### 3. Call a Tool

```bash
curl -X POST <endpoint> \
  -H "Content-Type: application/json" \
  -H "x-mcp-api-key: mcp_sk_your_key_here" \
  -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "list_accounts",
      "arguments": { "status": "active", "limit": 10 }
    }
  }'
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "result": {
    "content": [
      {
        "type": "text",
        "text": "[{\"id\":\"...\",\"name\":\"Acme Corp\",\"industry\":\"SaaS\",...}]"
      }
    ]
  },
  "id": 3
}
```

---

## Available Tools Reference

### Read Tools (require `read` permission)

| Tool | Description | Key Parameters |
|------|-------------|----------------|
| `list_accounts` | List accounts with optional filters | `status`, `industry`, `search`, `limit`, `offset` |
| `get_account` | Get a single account by ID | `account_id` (required) |
| `list_opportunities` | List opportunities | `account_id`, `is_archived`, `limit` |
| `get_opportunity` | Get a single opportunity | `opportunity_id` (required) |
| `list_contacts` | List stakeholders (decrypts PII) | `account_id`, `opportunity_id`, `include_ignored` |
| `list_use_cases` | List extracted use cases | `account_id`, `opportunity_id` |
| `list_pain_points` | List extracted pain points | `account_id`, `opportunity_id` |
| `list_nbas` | List Next Best Actions | `account_id`, `opportunity_id`, `status` |
| `list_technologies` | List account tech stack | `account_id` (required), `layer` |
| `list_competitive_insights` | Competitor mentions & objections | `opportunity_id` (required), `competitor_name` |
| `list_competitive_plays` | Attack/defend strategies | `opportunity_id` (required), `play_type` |
| `get_competitive_scorecard` | Maturity scorecard comparison | `vendor_names`, `category` |
| `list_metrics` | Operational metrics from conversations | `account_id`, `metric_category` |
| `list_strategic_themes` | Synthesized strategic themes | `account_id` (required), `theme_type` |
| `list_transcripts` | Transcript metadata (no content) | `account_id`, `opportunity_id`, `status` |
| `get_readiness_answers` | Technical readiness Q&A | `opportunity_id` (required) |
| `list_milestones` | Opportunity milestones | `opportunity_id` (required) |
| `list_activity_signals` | Detection rule matches | `opportunity_id` (required) |
| `get_account_summary` | AI executive summary | `account_id` (required) |
| `list_product_mentions` | Product/competitor mentions | `account_id`, `product_name` |
| `list_validation_tasks` | Validation tasks for an opportunity | `opportunity_id` (required), `status` |
| `list_documents` | Account/opportunity documents | `account_id`, `opportunity_id`, `type` |
| `get_se_updates` | SE weekly updates & risk assessments | `opportunity_id` (required) |
| `list_customer_stories` | SBI customer narratives | `account_id`, `opportunity_id` |
| `list_stage_history` | Stage change history | `opportunity_id` (required), `stage_type` |

### Coaching Tools (require `coaching` permission — sensitive)

| Tool | Description | Key Parameters |
|------|-------------|----------------|
| `list_coaching_scores` | SE coaching scores across transcripts | `account_id`, `opportunity_id`, `se_email` |
| `get_coaching_score` | Detailed coaching score for a transcript | `transcript_id` (required) |

> ⚠️ Coaching tools expose individual SE performance data. They are hidden from `tools/list` and blocked from `tools/call` unless the API key has `coaching: true` in its permissions. Create a dedicated key with coaching access for authorized consumers only.

### Write Tools (require `write` permission)

| Tool | Description | Key Parameters |
|------|-------------|----------------|
| `create_account` | Create a new account | `name` (required), `industry`, `status`, `arr` |
| `update_account` | Update account fields | `account_id` (required), fields to update |
| `update_opportunity` | Update opportunity fields | `opportunity_id` (required), fields to update |
| `create_nba` | Create a Next Best Action | `account_id` (required), `action` (required), `priority`, `due_date` |
| `update_nba_status` | Change NBA status | `nba_id` (required), `status` (required) |
| `trigger_reanalysis` | Re-analyze a transcript | `transcript_id` (required) |

---

## Example Workflows

### Search accounts and drill into opportunities

```json
// Step 1: Find the account
{ "method": "tools/call", "params": { "name": "list_accounts", "arguments": { "search": "Acme" } } }

// Step 2: List its opportunities  
{ "method": "tools/call", "params": { "name": "list_opportunities", "arguments": { "account_id": "<id>" } } }

// Step 3: Get stakeholders
{ "method": "tools/call", "params": { "name": "list_contacts", "arguments": { "account_id": "<id>" } } }
```

### Competitive briefing for a deal

```json
// Get scorecard comparison
{ "method": "tools/call", "params": { "name": "get_competitive_scorecard", "arguments": { "vendor_names": ["Pendo", "Amplitude"] } } }

// Get competitive plays for the opportunity
{ "method": "tools/call", "params": { "name": "list_competitive_plays", "arguments": { "opportunity_id": "<id>" } } }
```

### Create an NBA from an external system

```json
{
  "method": "tools/call",
  "params": {
    "name": "create_nba",
    "arguments": {
      "account_id": "uuid-here",
      "action": "Schedule technical deep-dive on data pipeline integration",
      "priority": "high",
      "due_date": "2026-02-20",
      "assigned_to": "se@company.com"
    }
  }
}
```

---

## Connecting from MCP Clients

### Claude Desktop / Cursor / Windsurf

Add to your MCP config (e.g. `claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "searchitecture": {
      "transport": {
        "type": "streamable-http",
        "url": "https://uxqugehmbqojblirttdy.supabase.co/functions/v1/mcp-server",
        "headers": {
          "x-mcp-api-key": "mcp_sk_your_key_here"
        }
      }
    }
  }
}
```

### Python (using `mcp` SDK)

```python
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

async def main():
    async with streamablehttp_client(
        url="https://uxqugehmbqojblirttdy.supabase.co/functions/v1/mcp-server",
        headers={"x-mcp-api-key": "mcp_sk_your_key_here"}
    ) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            
            # List tools
            tools = await session.list_tools()
            
            # Call a tool
            result = await session.call_tool("list_accounts", {"limit": 5})
            print(result)
```

---

## Error Handling

| HTTP Status | JSON-RPC Code | Meaning |
|-------------|---------------|---------|
| 401 | — | Missing or invalid API key |
| 400 | -32700 | Malformed JSON body |
| 200 | -32601 | Tool not found |
| 200 | -32600 | Permission denied (write required, or tool not allowed) |
| 200 | -32603 | Internal error (database query failed) |

All errors include a human-readable `message` field.

---

## Security Notes

- API keys are stored as **SHA-256 hashes** — the raw key is never persisted
- Keys can be **scoped** to specific tools (e.g. read-only competitive data)
- Keys can have an **expiry date**
- All tool calls are **logged** with execution time, parameters, and status in `mcp_access_logs`
- Encrypted PII (names, emails, notes) is **decrypted server-side** before being returned to authorized consumers
- Monitor access in **Settings → Integrations → MCP Server → Recent Activity**

---

## Monitoring

All MCP tool calls are logged automatically. View recent activity in the MCP Settings tab, or query directly:

```sql
SELECT tool_name, api_key_name, response_status, execution_time_ms, created_at
FROM mcp_access_logs
ORDER BY created_at DESC
LIMIT 50;
```

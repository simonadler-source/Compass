# Momentum Meeting Integration Documentation

This document provides a complete technical specification for replicating the Momentum meeting transcript import system in another application.

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Database Schema](#database-schema)
4. [API Integration](#api-integration)
5. [Sync Edge Function](#sync-edge-function)
6. [Import Pipeline](#import-pipeline)
7. [AI Transcript Analysis](#ai-transcript-analysis)
8. [Frontend Components](#frontend-components)
9. [Configuration & Secrets](#configuration--secrets)

---

## Overview

The Momentum integration synchronizes meeting recordings and transcripts from the [Momentum.io](https://momentum.io) platform into the application. It provides:

- **Automatic syncing** of meetings from the Momentum API
- **Account matching** using Salesforce IDs, company names, or email domains
- **Auto-import** with AI-powered transcript analysis
- **Manual review queue** for unmatched meetings
- **Detection rules** that trigger on specific phrases/topics
- **NBA (Next Best Action) extraction** from conversations
- **Stakeholder assessment** from meeting participants

---

## Architecture

```
┌──────────────────┐     ┌─────────────────────┐     ┌──────────────────┐
│   Momentum API   │────▶│  sync-momentum      │────▶│  momentum_meetings│
│  (External)      │     │  (Edge Function)    │     │  (Database Table) │
└──────────────────┘     └─────────────────────┘     └──────────────────┘
                                   │
                                   │ Auto-import triggered
                                   ▼
                         ┌─────────────────────┐
                         │  analyze-transcript │
                         │  (Edge Function)    │
                         └─────────────────────┘
                                   │
                                   │ AI Analysis Results
                                   ▼
┌──────────────────────────────────────────────────────────────────────┐
│                        Multiple Tables Updated                        │
│  - account_technologies   - account_contacts    - account_nbas       │
│  - transcript_reviews     - opportunities       - detection_rule_matches│
│  - opportunity_readiness_answers  - account_captured_insights        │
└──────────────────────────────────────────────────────────────────────┘
```

---

## Database Schema

### Core Tables

#### `momentum_meetings`
Stores synced meetings from Momentum API.

```sql
CREATE TABLE momentum_meetings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  momentum_id TEXT NOT NULL UNIQUE,        -- Momentum's meeting ID
  title TEXT NOT NULL,
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ,
  host_email TEXT,
  host_name TEXT,
  attendees JSONB,                          -- Array of attendee objects
  transcript_content TEXT,                  -- Full transcript text
  salesforce_account_id TEXT,               -- From Momentum if linked
  salesforce_opportunity_id TEXT,           -- From Momentum if linked
  status TEXT DEFAULT 'pending',            -- pending | queued | processing | imported | ignored
  matched_account_id UUID REFERENCES accounts(id),
  imported_at TIMESTAMPTZ,
  ignored_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

**Status Flow:**
- `pending` - Awaiting manual review/import
- `queued` - Matched to account, queued for auto-import
- `processing` - Currently being imported
- `imported` - Successfully imported and analyzed
- `ignored` - User chose to ignore this meeting

#### `momentum_sync_state`
Tracks sync history for incremental fetching.

```sql
CREATE TABLE momentum_sync_state (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  last_sync_at TIMESTAMPTZ DEFAULT now(),
  meetings_synced INTEGER,
  created_at TIMESTAMPTZ DEFAULT now()
);
```

### Attendee JSON Structure

```typescript
interface MomentumAttendee {
  name: string;
  email: string;
  isInternal: boolean;    // true = your company, false = external/customer
  id?: string;            // Momentum's attendee ID
  salesforceCaseId?: string;
  salesforceLeadId?: string;
}
```

---

## API Integration

### Momentum API

**Base URL:** `https://api.momentum.io/v1`

**Authentication:** API Key via `X-API-Key` header

#### Fetch Meetings Endpoint

```
GET /meetings?pageNumber={n}&pageSize={size}&from={ISO8601}&to={ISO8601}
```

**Response Structure:**
```typescript
interface MomentumMeeting {
  id: string;
  title: string;
  startTime: string;          // ISO8601
  endTime: string;
  host: {
    email: string;
    name: string;
  };
  attendees: MomentumAttendee[];
  transcript: {
    entries: Array<{
      text: string;
      speaker: {
        name: string;
        attendeeId: string;
      };
      timestamp: string;
      timestampSeconds: number;
    }>;
  };
  salesforceAccountId?: string;
  salesforceOpportunityId?: string;
}
```

---

## Sync Edge Function

**Path:** `supabase/functions/sync-momentum/index.ts`

### Trigger Methods

1. **Scheduled (Cron)** - Set up via Supabase dashboard or external scheduler
2. **Manual** - Call the function endpoint directly
3. **Process Pending** - `?action=process-pending` to reprocess failed imports

### Sync Flow

```typescript
// 1. Calculate date range (default: last 4 days, full sync: 30 days)
const syncFromDate = forceFullSync ? fullFrom : regularFrom;

// 2. Paginate through Momentum API
while (hasMorePages) {
  const response = await fetch(`https://api.momentum.io/v1/meetings?...`);
  allMeetings = allMeetings.concat(response.meetings);
}

// 3. Filter duplicates (check existing momentum_id in database)
const existingIds = new Set(/* fetch from database */);

// 4. For each new meeting:
for (const meeting of allMeetings) {
  // Skip if already exists
  if (existingIds.has(meeting.id)) continue;
  
  // Skip internal-only meetings
  if (externalAttendees.length === 0) continue;
  
  // Try to match to account (see matching logic below)
  const matchedAccount = await matchMeetingToAccount(meeting);
  
  if (matchedAccount && shouldAutoImport) {
    // Queue for async import
    EdgeRuntime.waitUntil(processAutoImport(...));
  } else {
    // Insert as pending for manual review
    await insertPendingMeeting(meeting);
  }
}
```

### Account Matching Logic

Three-tier matching hierarchy:

```typescript
// Method 1: Salesforce Account ID (highest priority)
if (meeting.salesforceAccountId) {
  const match = accounts.find(a => 
    a.salesforce_account_id === meeting.salesforceAccountId
  );
  if (match) return match;
}

// Method 2: Company name in title or attendee email domains
for (const account of accounts) {
  const accountNameLower = account.name.toLowerCase();
  
  // Check title
  if (meeting.title.toLowerCase().includes(accountNameLower)) {
    return account;
  }
  
  // Check email domains
  for (const domain of externalDomains) {
    const domainBase = domain.split('.')[0];
    if (accountNameLower.includes(domainBase)) {
      return account;
    }
  }
}

// Method 3: Auto-create if team member is on meeting
if (hasTeamMember && !matchedAccount) {
  const companyName = extractCompanyFromDomain(externalAttendee.email);
  const newAccount = await createAccount({ name: companyName });
  return newAccount;
}
```

### Auto-Import Setting

Accounts have an `auto_import_transcripts` boolean field:
- `true` (default) - Meetings auto-import when matched
- `false` - Meetings go to pending queue for manual review

---

## Import Pipeline

**Path:** `src/features/momentum/import/importMomentumMeeting.ts`

### Main Function: `importMomentumMeetingSteps()`

```typescript
interface ImportParams {
  meeting: MomentumMeetingCore;
  transcript: string;
  accountId: string;
  onStage?: (stage: string) => void;    // Progress callback
  onProgress?: (progress: number) => void;
  log?: ImportLogger;                    // Diagnostic logging
}
```

### Import Steps (Sequential)

| Step | Progress | Description |
|------|----------|-------------|
| 1 | 15% | Mark meeting as `processing` |
| 2 | 20% | Save external attendees to `account_contacts` |
| 3 | 25% | Save internal attendees to `account_team_members` |
| 4 | 35% | Save transcript to `account_documents` |
| 5 | 60% | Call `analyze-transcript` AI function |
| 6 | 80% | Save extracted technologies |
| 7 | 82% | Find or create opportunity |
| 8 | 84% | Link attendees to opportunity |
| 9 | 86% | Create/update `transcript_reviews` record |
| 10 | 88% | Process detection rule matches |
| 11 | 90% | Save extracted NBAs |
| 12 | 92% | Detect completed NBAs from transcript |
| 13 | 95% | Mark meeting as `imported` |

### Attendee Processing

External attendees are upserted to `account_contacts`:
```typescript
const contactRows = externalAttendees.map(attendee => ({
  account_id: accountId,
  name: attendee.name || attendee.email.split('@')[0],
  email: attendee.email.toLowerCase(),
  is_internal: false,
  source: 'momentum'
}));

await supabase
  .from('account_contacts')
  .upsert(contactRows, { onConflict: 'account_id,email' });
```

Internal attendees are upserted to `account_team_members`:
```typescript
const teamRows = internalAttendees.map(attendee => ({
  account_id: accountId,
  team_member_email: attendee.email.toLowerCase(),
  role: 'participant',
  added_from_meeting_id: meeting.id
}));

await supabase
  .from('account_team_members')
  .upsert(teamRows, { onConflict: 'account_id,team_member_email' });
```

### Opportunity Resolution

```typescript
// Priority 1: Match by Salesforce Opportunity ID
if (meeting.salesforce_opportunity_id) {
  const existing = await supabase
    .from('opportunities')
    .select('id')
    .ilike('description', `%${meeting.salesforce_opportunity_id}%`)
    .maybeSingle();
  
  if (existing) return existing.id;
  
  // Create new opportunity with SF ID reference
  const newOpp = await supabase.from('opportunities').insert({
    account_id: accountId,
    name: meeting.title,
    description: `Salesforce Opportunity ID: ${meeting.salesforce_opportunity_id}`,
    pre_sales_stage: analysis?.preSalesStageAssessment?.stage
  });
  return newOpp.id;
}

// Priority 2: Link to most recent opportunity
const recent = await supabase
  .from('opportunities')
  .select('id')
  .eq('account_id', accountId)
  .order('created_at', { ascending: false })
  .limit(1);

return recent?.[0]?.id;
```

---

## AI Transcript Analysis

**Path:** `supabase/functions/analyze-transcript/index.ts`

### Input Schema

```typescript
interface AnalyzeTranscriptInput {
  transcript: string;                    // Max 500,000 chars, truncated to 120k for AI
  accounts?: AccountReference[];         // For account matching
  competitors?: CompetitorReference[];   // For competitive intelligence
  opportunityId?: string;                // Context for readiness questions
  existingInsights?: {                   // Avoid duplicating known info
    technologies: { name: string }[];
    painPoints: string[];
    useCases: string[];
    competitorMentions: string[];
    metrics: { metricName: string; metricValue: string }[];
  };
}
```

### Output Schema

```typescript
interface AnalysisResult {
  // Extracted entities
  technologies: ExtractedTechnology[];
  people: ExtractedPerson[];
  nbas: NextBestAction[];
  discoveryQuestions: ExtractedDiscoveryQuestion[];
  commercialInsights: CommercialInsight[];
  operationalMetrics: ExtractedMetric[];
  
  // Account matching
  suggestedAccountId: string | null;
  suggestedAccountName: string | null;
  suggestedNewAccountName: string | null;
  accountConfidence: number;
  
  // Insights
  insights: {
    painPoints: string[];
    useCases: string[];
    competitorMentions: string[];
  };
  
  // Detection rules
  detectionRuleMatches: DetectionRuleMatch[];
  
  // Sales stage assessment
  salesStageAssessment: SalesStageAssessment | null;
  preSalesStageAssessment: PreSalesStageAssessment | null;
  
  // Deployment types
  detectedDeploymentTypes: DetectedDeploymentType[];
  
  // Readiness answers
  readinessAnswers: ReadinessAnswer[];
}
```

### Technology Extraction

```typescript
interface ExtractedTechnology {
  name: string;
  confidence: number;                    // 0-1
  suggestedLayer: 'host' | 'build' | 'adopt' | 'growth' | 'ops';
  context: string;                       // Quote from transcript
  relationshipStatus: 
    | 'mentioned'     // Just mentioned
    | 'experience'    // Team has experience but not using
    | 'in_use'        // Actively using
    | 'evaluating'    // Currently evaluating
    | 'considering'   // Considering for future
    | 'replaced';     // Previously used, now replaced
  needsReview: boolean;                  // True if confidence < 70%
}
```

### Stakeholder Assessment

```typescript
interface ExtractedPerson {
  name: string;
  role: string | null;
  email: string | null;
  phone: string | null;
  context: string;
  influenceLevel: number;    // 0-100 (C-level: 80-100, Director: 60-80, etc.)
  sentiment: number;         // 0-100 (Enthusiastic: 80-100, Skeptical: 20-40)
  championScore: number;     // 0-100 likelihood to advocate
  isInternal: boolean;       // true = your team, false = customer
}
```

### Detection Rules

The system loads detection rules from the database and instructs the AI to match them:

```typescript
interface DetectionRule {
  id: string;
  name: string;
  trigger_phrases: string[];      // Phrases to look for
  context_qualifiers: string[];   // Additional context required
  exclusion_phrases: string[];    // Exclude if these are present
  confidence_threshold: number;   // Minimum confidence to match
}

interface DetectionRuleMatch {
  ruleId: string;
  ruleName: string;
  matchedPhrases: string[];
  confidence: number;
  context: string;
}
```

When a rule matches:
1. A `detection_rule_matches` record is created
2. Linked validation tasks are auto-created
3. Readiness answers are auto-populated (if mapped)
4. Captured insights are saved

### Commercial Insights (SWOT)

```typescript
interface CommercialInsight {
  insight: string;
  type: 'build_vs_buy' | 'budget_timing' | 'competitive_positioning' | 'stakeholder_dynamics';
  swotCategory: 'strength' | 'weakness' | 'opportunity' | 'threat';
  importance: 'high' | 'medium' | 'low';
  context: string;
}
```

### Sales Stage Assessment

```typescript
// 7-stage sales model (Stage 0-6)
interface SalesStageAssessment {
  stage: number;           // 0-6
  stageName: string;
  phase: 'Pipeline Generation' | 'Visible Opportunity' | 'Value Realization';
  confidence: number;
  reasoning: string;
  exitCriteriaMet: string[];
  exitCriteriaNotMet: string[];
}

// Pre-sales technical stages
interface PreSalesStageAssessment {
  stage: 
    | 'Not Started' 
    | 'Discovery' 
    | 'Demo' 
    | 'Proof - Scoping' 
    | 'Proof' 
    | 'Technical Win' 
    | 'Technical Loss' 
    | 'Stale / Not Active' 
    | 'Unqualified';
  confidence: number;
  reasoning: string;
  evidenceForStage: string[];
}
```

---

## Frontend Components

### Hook: `useMeetingImport`

**Path:** `src/features/momentum/import/useMeetingImport.ts`

```typescript
interface MeetingImportController {
  // Dialog state
  isOpen: boolean;
  meeting: MomentumMeeting | null;
  
  // Account matching
  suggestedAccount: SuggestedAccount;
  matchCandidates: AccountMatchCandidate[];
  derivedAccountName: string | null;
  
  // User selections
  selectedAccountId: string;
  setSelectedAccountId: (val: string) => void;
  createNewAccount: boolean;
  newAccountName: string;
  
  // Import state
  isImporting: boolean;
  importStage: string;      // Current step description
  importProgress: number;   // 0-100
  
  // Diagnostics
  events: ImportEvent[];    // Full event log
  lastError: string | null;
  
  // Actions
  open: (meeting: MomentumMeeting) => void;
  close: () => void;
  runImport: () => Promise<void>;
  canImport: boolean;
}
```

### Import Dialog

The dialog provides:
- Suggested account with confidence indicator
- Dropdown to select different account
- Option to create new account
- Real-time progress bar during import
- Event log for debugging

---

## Configuration & Secrets

### Required Secrets

| Secret Name | Description |
|-------------|-------------|
| `MOMENTUM_API_KEY` | API key from Momentum.io dashboard |
| `SUPABASE_URL` | Auto-configured by Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | Auto-configured by Supabase |
| `GOOGLE_API_KEY` | For Gemini AI transcript analysis |

### Account Settings

```typescript
interface Account {
  // ...other fields
  auto_import_transcripts: boolean;  // Default: true
  salesforce_account_id: string;     // For Salesforce matching
  primary_se_email: string;          // Primary SE assigned
}
```

### AI Provider Configuration

The `analyze-transcript` function uses a shared AI provider configuration:

```typescript
// supabase/functions/_shared/ai-provider.ts
interface AIConfig {
  endpoint: string;   // API endpoint URL
  apiKey: string;     // API key
  model: string;      // Model name (e.g., 'gemini-2.5-pro')
}
```

---

## Error Handling

### Import Failure Recovery

If import fails at any step:
1. Meeting status is reverted to `pending`
2. `matched_account_id` is cleared
3. Error is logged to the event log
4. User can retry the import

```typescript
export async function revertMeetingToPending(meetingId: string) {
  await supabase
    .from('momentum_meetings')
    .update({ status: 'pending', matched_account_id: null })
    .eq('id', meetingId);
}
```

### Timeout Handling

Large transcripts have extended timeouts:
- `< 10k chars`: 60 seconds
- `10k-30k chars`: 90 seconds
- `> 30k chars`: 180 seconds

Transcripts are truncated to 120k characters before AI analysis.

---

## Replication Checklist

To replicate this integration in another application:

1. **Database Setup**
   - [ ] Create `momentum_meetings` table
   - [ ] Create `momentum_sync_state` table
   - [ ] Add `auto_import_transcripts` to accounts table
   - [ ] Add `salesforce_account_id` to accounts table

2. **Edge Functions**
   - [ ] Deploy `sync-momentum` function
   - [ ] Deploy `analyze-transcript` function
   - [ ] Configure AI provider (shared module)

3. **Secrets**
   - [ ] Add `MOMENTUM_API_KEY`
   - [ ] Add AI provider API key

4. **Frontend**
   - [ ] Implement meeting list view
   - [ ] Implement import dialog with account matching
   - [ ] Add progress/status indicators

5. **Scheduling**
   - [ ] Set up cron job for periodic sync (recommended: every 15-30 minutes)

---

## Related Documentation

- [Detection Rules](./DETECTION_RULES.md) - How detection rules work
- Momentum API Documentation: https://docs.momentum.io

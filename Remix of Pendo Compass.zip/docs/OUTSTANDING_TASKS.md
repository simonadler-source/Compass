# Pendo TechMap - Outstanding Tasks & Future Enhancements

## Status Legend
- 🔴 **Critical** - Affects core functionality
- 🟡 **Medium** - Affects user experience
- 🟢 **Low** - Nice to have enhancements

---

## Completed (This Session)

- [x] **index.html branding** - Updated meta tags to Pendo TechMap branding
- [x] **Validation tasks race condition** - Added optimistic updates with rollback
- [x] **Module pricing placeholders** - Cleaned duplicates, set realistic MAU percentages
- [x] **Email redirect fix** - Updated action-update to redirect to sependo.org

---

## Pending Items

### Integrations (🔴 Critical)

#### Salesforce Integration
- **Location**: `src/components/views/IntegrationsView.tsx` (lines 175-318)
- **Status**: UI complete, backend integration pending
- **Work Required**:
  - OAuth flow implementation
  - Account sync logic
  - Opportunity mapping
  - Field mapping configuration

#### Product Analytics (Pendo) Integration
- **Location**: `src/components/views/ProductAnalyticsView.tsx`
- **Status**: Pendo logo/branding present, but connection pending
- **Work Required**:
  - Pendo API integration
  - MAU count sync
  - Usage metrics sync
  - Feature adoption data

---

### Incomplete Features (🟡 Medium)

#### Stakeholder Bubble Chart
- **Location**: `src/components/views/AccountStakeholderMapTab.tsx`
- **Status**: Table view complete, bubble chart visualization pending
- **Work Required**:
  - D3.js or Recharts bubble chart
  - Influence/sentiment axis mapping
  - Interactive drag positioning
  - Champion scoring visualization

#### Visual Architecture Review Workflow
- **Location**: `src/components/canvas/VisualArchitectureCanvas.tsx`
- **Status**: Canvas editing works, review/approval flow pending
- **Work Required**:
  - Version comparison view
  - Approval workflow
  - Change tracking
  - Notification on architecture changes

---

### Technical Debt (🟢 Low Priority)

#### Encrypted Field Placeholders
- **Location**: `supabase/functions/api-gateway/index.ts` (line 284)
- **Issue**: Uses `[Encrypted]` placeholder for NOT NULL fields
- **Fix**: Consider allowing NULL or using more descriptive placeholders

#### Console.error Patterns
- Various files log errors but don't always surface them to users
- Consider implementing centralized error boundary with toast notifications

---

## Future Enhancements

### AI Prompt Optimization
- Review unified-transcript-analysis prompts for token efficiency
- Consider splitting large prompts into focused passes
- Implement prompt versioning A/B testing

### Meeting Analysis Pipeline
- Document the full flow: Meeting → Transcript → Analysis → Insights
- Review how new meeting analysis integrates with existing opportunity data
- Account-level insight synthesis logic review

### Account Health Scoring
- Review algorithm weights
- Consider ML-based scoring model
- Add trend analysis over time

---

## Roadmap - Employee Engagement Features

### 1. Global Search (✅ Implemented)
- Cmd+K command palette
- Search across accounts, opportunities, contacts, transcripts, NBAs
- Quick navigation with keyboard shortcuts

### 2. Gamification & Recognition (🟡 Planned)
- Leaderboards for deal velocity, meeting frequency
- Achievement badges (e.g., "Champion Builder", "Discovery Master")
- Team wins visibility and best practice sharing
- Weekly/monthly recognition highlights

### 3. Slack/Teams Integration (🟡 Planned)
- Post-meeting insight notifications
- Deal alert summaries
- NBA reminder notifications
- Note: Pre-meeting prep blocked (Momentum doesn't provide calendar data)

### 4. Conversational AI Strategy Agent (🟡 Planned - High Priority)
- Natural language queries: "What's happening in Acme Corp?"
- Account/opportunity analytics on demand
- Strategy recommendations based on signals
- "What should I focus on this week?" coaching
- Competitive positioning guidance
- Win/loss pattern analysis

### 5. Pendo Product Health Scoring (🔴 Blocked)
- Requires Pendo API integration
- MAU correlation with engagement signals
- Feature adoption tracking

---

## Notes

Last updated: 2026-02-05
Session: Added Global Search, updated roadmap with AI Strategy Agent

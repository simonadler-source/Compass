# Compass by Pendo — Platform Documentation

## What Is Compass?

Compass is an AI-powered **Sales Engineering Intelligence Platform** purpose-built for Pre-Sales / Solutions Engineering teams. It ingests meeting transcripts, automatically extracts strategic insights using multi-pass AI analysis, and transforms raw conversation data into actionable intelligence — surfacing what matters, who matters, and what to do next.

**In one sentence:** Compass turns every customer conversation into a structured, queryable knowledge base that makes your SE team sharper, faster, and more strategically aligned.

---

## The Problem Compass Solves

### The Pre-Sales Intelligence Gap

Sales Engineering sits at the intersection of deep technical knowledge and commercial awareness. SEs attend dozens of discovery calls, demos, POC reviews, and executive briefings every month. Within those conversations lies the most valuable intelligence in any B2B sales organisation:

- **What technology does the prospect actually use?** (not what their website says)
- **Who are the real decision-makers?** (not just the org chart)
- **What are their genuine pain points?** (not what marketing assumes)
- **Which use cases resonate?** (not which ones we pitch)
- **Where are the competitive threats?** (not what the AE remembers)
- **Is the deal actually progressing?** (not what the CRM says)

**Today, this intelligence lives in peoples' heads.** It leaks out in Slack messages, gets buried in call recordings nobody re-watches, and evaporates when team members change territories. Sales leaders make pipeline decisions based on anecdotes. SE Managers coach based on gut feel. New team members ramp slowly because institutional knowledge is locked in individuals.

### What This Costs

| Problem | Business Impact |
|---------|----------------|
| Intelligence trapped in individuals | Single points of failure; knowledge lost during attrition |
| No systematic stakeholder tracking | Champions go un-nurtured; blockers go undetected |
| Reactive follow-up culture | NBAs are forgotten or delayed; prospects lose momentum |
| Coaching based on anecdote | SE development is inconsistent; delivery problems persist |
| No cross-account pattern recognition | Product gaps, competitive trends, and market signals go unnoticed |
| Manual account planning | Plans are stale the moment they're written |

### What Compass Changes

Compass eliminates the intelligence gap by making **every conversation compound**. Each transcript analysed enriches the account's knowledge graph — stakeholder sentiment trends over time, pain points gain confidence through repetition, use cases get validated or deprioritised, and competitive positioning sharpens with every mention.

The result: your team operates with **institutional memory that never forgets, never leaves, and gets smarter with every meeting**.

---

## How It Works — End to End

### 1. Meeting Ingestion

Compass connects to meeting recording platforms (currently Momentum.io, with Gong integration planned) and automatically syncs completed meetings with transcripts.

**Flow:**
```
Meeting recorded → Momentum syncs transcript → Compass matches to Account
→ Auto-import or Manual review queue → AI Analysis triggered
```

- **Auto-matching**: Meetings are matched to accounts via Salesforce Account ID, company name fuzzy matching, or attendee email domain
- **Review queue**: Unmatched meetings surface in a triage queue with attendee details so SEs can quickly assign them
- **Orphan detection**: Imported meetings that lose their account association are flagged for re-assignment

### 2. Multi-Pass AI Analysis

When a transcript is imported, Compass runs a **conditional multi-pass analysis pipeline** — not a single monolithic prompt. This architecture was chosen deliberately to manage LLM context limits, optimise cost, and allow passes to be independently versioned and toggled.

#### Pass 1 — Core Extraction (Real-time)
**Model:** Gemini 2.5 Flash

Extracts the foundational entities from the conversation:

| Entity | What's Captured |
|--------|----------------|
| **Technologies** | Name, layer (Host/Build/Adopt/Growth/Ops), relationship status (in use, evaluating, replaced, mentioned), confidence score |
| **People** | Name, role, MEDDIC stakeholder type, influence level, sentiment score, champion score with advocacy + info-sharing evidence |
| **Pain Points** | Description, category (vendor relationship / technical limitations / operational friction / resource constraints / strategic misalignment), severity, business theme |
| **Use Cases** | Description, functional area, business outcome, priority, theme |
| **Next Best Actions** | Action description, type (SE task / AE task / Prospect task), priority, due date, delivery method |
| **Competitors** | Name, context of mention, sentiment toward competitor |
| **Call Summary** | Meeting purpose (from 14 categories), key discussion points, commercial insights |

#### Pass 2 — Strategic Assessment (Real-time)
**Model:** Gemini 2.5 Flash

Evaluates opportunity-level dynamics:

- **Sales stage** assessment (0–6 scale mapped to MEDDIC stages)
- **Pre-sales stage** (Discovery → Technical Validation → Technical Win)
- **Commercial insights** (SWOT-categorised)
- **Operational metrics** (team size, timeline, budget signals)
- **Discovery question tracking**

#### Pass 3 — Activity Signal Detection (Async)
**Model:** Gemini 2.5 Flash Lite (cost-optimised)

Matches the transcript against **configurable detection rules** — pattern-based triggers that fire when specific topics, phrases, or conditions appear in conversations. Examples:

- "Competitor displacement opportunity detected"
- "Executive sponsor identified"
- "Security/compliance concern raised"
- "POC success criteria discussed"

Each rule can capture structured fields (e.g., competitor name, timeline mentioned, budget figure).

#### Pass 4 — Technical Readiness & Product Mentions (Async)
**Model:** Gemini 2.5 Flash Lite

- Maps conversation content to **readiness qualification questions** (configurable templates)
- Extracts **product mentions** (owned, complementary, competitive) with sentiment analysis

#### SE Coaching Analysis (Async)
**Model:** Gemini 2.5 Flash

Evaluates the SE's performance across **13 coaching dimensions** aligned to Sales Enablement standards:

| # | Dimension | What It Measures |
|---|-----------|-----------------|
| 1 | Discovery Depth | Quality of probing questions |
| 2 | Technical Translation | Ability to connect features to business outcomes |
| 3 | Competitive Handling | How competitive mentions were addressed |
| 4 | Stakeholder Engagement | Multi-threading and relationship building |
| 5 | Demo Effectiveness | Relevance and impact of demonstrations |
| 6 | Objection Handling | Quality of responses to pushback |
| 7 | Next Steps Clarity | Whether clear actions were established |
| 8 | Business Acumen | Understanding of prospect's business context |
| 9 | Active Listening | Evidence of hearing and responding to cues |
| 10 | Value Articulation | Connecting solution to measurable outcomes |
| 11 | Collaboration | Working effectively with AE/team members |
| 12 | Executive Presence | Confidence, credibility, authority |
| 13 | **Energy & Inspiration** | Vocal delivery, enthusiasm, prospect activation |

The **Energy & Inspiration** dimension is unique — it scores the SE's vocal delivery across 5 sub-techniques, each with timecoded transcript evidence:

1. **Pitch Variation (Staircase)** — Monotone vs. dynamic inflection
2. **Value Word Emphasis** — Whether key terms (ROI, revenue, risk) are punched
3. **Pace Variation (BPM)** — Strategic speed changes (sprinting through pain, slow-walking value)
4. **Vocal Warmth** — Genuine enthusiasm vs. clinical delivery
5. **Verbal Highlighters** — Use of attention-grabbing phrases ("Here's the part that usually surprises people...")

Every sub-score includes a **direct quote with timecode** (e.g., `[~12:34] "This is going to completely transform how your team..." — Strong vision-painting language`) for coaching traceability.

### 3. Account Knowledge Graph

Every insight extracted is materialised into account-level tables, building a **compounding knowledge graph**:

```
Account
├── Technologies (with stack layer mapping)
├── Contacts / Stakeholders
│   ├── MEDDIC classification
│   ├── Sentiment trend (per-meeting snapshots)
│   ├── Champion score with evidence
│   └── Influence level trajectory
├── Pain Points (themed, validated, confidence-scored)
├── Use Cases (prioritised, linked to functional areas)
├── Strategic Themes (auto-synthesised from pain points)
├── Metrics (extracted KPIs, team sizes, timelines)
├── Opportunities
│   ├── Pipeline stage tracking
│   ├── Competitive landscape
│   ├── Success criteria
│   ├── Validation tasks
│   ├── Milestones (Mutual Action Plan)
│   └── Readiness answers
├── Next Best Actions (auto-generated, assignable, trackable)
├── Documents (attached files, external links)
├── Customer Stories (generated from engagement data)
└── Technology Architecture Canvas (visual stack mapping)
```

**Key design principle:** Insights **compound over time**. When the same pain point is mentioned across three meetings, its confidence score increases and validation count increments. When a use case is deprioritised (not mentioned in recent meetings), that signal is captured. When a stakeholder's sentiment shifts from 45 to 72 over four calls, the trend is tracked and surfaced.

### 4. Stakeholder Intelligence

Compass implements **MEDDIC-aligned stakeholder classification** with evidence-based scoring — not positional guesswork.

**Classification rules:**
- **Champion**: Requires BOTH advocacy signals (internal pushing, budget advocacy, meeting facilitation) AND information sharing signals (org chart sharing, internal challenges, competitor info, timeline sharing). Score >50 requires both.
- **Economic Buyer**: Budget authority evidence
- **Decision Criteria Owner**: Requirements ownership signals
- **Coach**: Shares information but no advocacy evidence
- **Blocker**: Raises objections, favours competitors
- **End User**: Workflow and usage focus
- **Unknown**: Default — insufficient evidence

**Time-series tracking:** Each meeting creates a stakeholder snapshot (sentiment, influence, champion score), enabling trend analysis with linear regression to determine improving/stable/declining trajectories.

**Visualisation:** Quadrant bubble chart (X: Sentiment, Y: Influence, Size: Champion Score) with trend sparklines showing movement across meetings.

### 5. Competitive Intelligence

- **Competitive Scorecard**: Configurable rubric-based scoring across subcategories with weighted evidence
- **Per-opportunity competitive tracking**: Which competitors are in the deal, sentiment context, win/loss signals
- **Audit trail**: Every score change logged with evidence source, confidence weight, and reviewer
- **Heatmap views**: Cross-competitor strength comparison at a glance
- **Transcript-sourced evidence**: Competitive mentions extracted with context and linked to source calls

### 6. Next Best Actions (NBAs)

NBAs are automatically generated from transcript analysis and managed through a structured lifecycle:

- **Auto-generation**: AI extracts actionable follow-ups with type (SE/AE/Prospect task), priority, and suggested due date
- **Grouping**: NBAs are grouped by account and opportunity with status rollup
- **Assignment**: Assignable to team members with due date tracking
- **Auto-completion detection**: Subsequent transcripts are checked against open NBAs to detect if actions were addressed
- **Staleness management**: NBAs >14 days past due are flagged; stale tasks are auto-cancelled
- **Sub-tasks**: Parent/child NBA structure for complex follow-ups
- **Cross-account dashboard**: Filterable, sortable view across all accounts

### 7. Mutual Action Plans & Evaluation Decks

For opportunities progressing toward evaluation:

- **Mutual Action Plan (MAP)**: Milestones, validation tasks linked to success criteria, stakeholder map, use case summary — exportable to Excel
- **Evaluation Deck**: Auto-generated slide-by-slide view (Overview → Strategic Themes → Use Cases → Success Criteria → Risks → Timeline → Readiness → Validation Tasks) — exportable to PPTX with dynamic pagination
- **Success Criteria**: Customer-validated acceptance criteria linked to use cases

### 8. Activity Signals & Detection Rules

A configurable rule engine that monitors transcripts for specific patterns:

- **Rule builder**: Condition groups with AND/OR logic, trigger phrases, team scope filtering
- **Capture fields**: Structured data extraction when rules match (e.g., "Extract the budget figure mentioned")
- **Activity timeline**: Chronological feed of all detected signals across accounts
- **Alert rules**: Opportunity-level alerts for stale engagement, missing stakeholders, pipeline velocity drops

### 9. Product Analytics

Cross-account product intelligence:

- **Product mention tracking**: Which products (owned, complementary, competitive) are mentioned across deals
- **Sentiment analysis**: Per-product sentiment trends
- **Bubble timeline**: Visual timeline of product mentions by frequency and sentiment
- **Deal cycle bleed analysis**: Identifying which products correlate with longer/shorter deal cycles
- **By-person breakdown**: Which team members mention which products most frequently

### 10. Manager Dashboard & Team Coaching

For SE Managers and Sales Leaders:

- **Team activity metrics**: Meetings, accounts touched, NBAs generated per team member
- **Weekly heatmaps**: Visual engagement patterns across the team
- **Coaching scores**: 13-dimension radar chart per SE with trend tracking
- **Peer comparison**: Branch-level visibility (see peers reporting to same manager)
- **1:1 prep sheets**: Auto-generated coaching prep with key findings per team member
- **Executive weekly summary**: Synthesised account health across the portfolio
- **Coaching PDF export**: Downloadable reports with dimension breakdowns, evidence, and delivery technique analysis

---

## Security Architecture

Compass implements enterprise-grade security throughout:

| Layer | Implementation |
|-------|---------------|
| **Authentication** | Custom PBKDF2-SHA256 (310K iterations) + mandatory TOTP MFA |
| **Encryption at rest** | AES-256-GCM on all PII and sensitive fields (contacts, transcripts, insights) |
| **Session management** | 384-bit tokens, 7-day expiry, 1-hour inactivity timeout, fingerprinted |
| **Brute force protection** | Exponential backoff (2min → 24hr max lockout) |
| **Row-level security** | PostgreSQL RLS on all tables based on user role + team hierarchy |
| **Data isolation** | Encrypted fields searched via ephemeral in-memory decryption (no plaintext indexes) |
| **Role-based access** | Admin/Manager/User roles with page-level and tab-level access control |
| **API gateway** | All sensitive operations route through a centralised edge function with encryption/decryption |
| **User management** | Approval workflow for new signups, admin-controlled MFA reset, account suspension |

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | React 18, TypeScript, Vite 5 |
| **Styling** | Tailwind CSS v3, shadcn/ui component library |
| **State** | TanStack Query (React Query) for server state |
| **Routing** | React Router v7 |
| **Backend** | Supabase (PostgreSQL + Edge Functions) via Lovable Cloud |
| **AI** | Lovable AI Gateway → Google Gemini models (2.5 Flash, 2.5 Flash Lite) |
| **Encryption** | AES-256-GCM (Web Crypto API) |
| **Auth** | Custom PBKDF2 + TOTP (RFC 6238) |
| **Integrations** | Momentum.io (meetings), Salesforce (account matching), Slack (notifications), Gong (planned) |
| **Exports** | PPTX (evaluation decks), Excel (MAP), PDF (coaching reports) |

---

## Platform Navigation

```
Home ─────────────────── Mission Control / Activity Feed / Quadrant Dashboard
Accounts ─────────────── Account list → Detail view with 11 tabs
  └── Opportunities ──── Opportunity detail with competitive, stakeholder, milestone tabs
Next Best Actions ────── Cross-account NBA dashboard
Team Dashboard ───────── Manager view: team metrics, coaching, alerts
Activity Signals ─────── Detection rule match feed
Product Analytics ────── Cross-account product mention intelligence
Momentum Meetings ────── Import queue, review, auto-import
AI Discovery ─────────── Transcript review and analysis
Customer Stories ─────── Generated success stories from engagement data
Competitive Intel ────── Scorecard, heatmap, audit log

Configuration:
  Functional Areas ────── Business function taxonomy
  Reference Architecture  Standard technology stack layers
  Technology Library ──── Master technology catalogue
  Detection Rules ─────── Configurable signal triggers
  Alert Rules ─────────── Opportunity-level monitoring
  Readiness Questions ─── Qualification question templates
  Validation Tasks ────── POC/evaluation task templates

Settings:
  User Management ─────── Approval, roles, MFA
  AI Pipeline Editor ──── Prompt versioning, pass configuration
  Coaching Weights ────── Dimension weighting for SE scoring
  Competitive Rubric ──── Scorecard category management
  Notification Prefs ──── Email/Slack alert configuration
  Data Hygiene ─────────── Duplicate detection, merge tools
  Security ─────────────── 2FA setup, session management
```

---

## Who Is Compass For?

| Role | Primary Value |
|------|--------------|
| **Solutions Engineer** | Never lose a detail from a call again. Auto-generated NBAs. Account context at your fingertips. |
| **SE Manager** | Coaching backed by data, not anecdote. Team-wide visibility. 1:1 prep in seconds. |
| **Account Executive** | Real-time deal intelligence. Stakeholder dynamics. Competitive positioning. |
| **Sales Leader / VP** | Pipeline reality vs. CRM fiction. Cross-account pattern recognition. Team performance benchmarking. |
| **Sales Enablement** | SE coaching scores mapped to enablement categories. Delivery technique analysis. Evidence-based training priorities. |
| **Product Marketing** | Competitive intelligence from the field. Product mention sentiment. Win/loss signal patterns. |

---

## The Fundamental Thesis

> **The most valuable intelligence in B2B sales is generated in conversations — and today, nearly all of it is lost.**

Compass exists because the gap between "what was discussed" and "what the organisation knows" is the single largest source of preventable revenue loss in enterprise sales. Every untracked stakeholder shift, every forgotten follow-up, every missed competitive signal, every coaching opportunity based on instinct rather than evidence — these compound into deals lost, ramp times extended, and teams underperforming their potential.

Compass closes that gap by treating every conversation as a **data event** that enriches a persistent, queryable, secure knowledge graph. The platform doesn't replace human judgement — it ensures human judgement is informed by **everything that was actually said**, not just what someone remembers.

The result is a Sales Engineering team that operates with **compounding institutional intelligence** — where every call makes every future call more effective, and where no insight is ever lost to memory, attrition, or organisational silos.

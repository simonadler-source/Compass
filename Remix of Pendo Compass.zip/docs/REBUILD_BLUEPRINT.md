# Rebuild Blueprint: SE Intelligence Platform from Scratch

> A pragmatic, opinionated guide to rebuilding Compass (an AI-powered Sales Engineering Intelligence Platform) using commonly available, battle-tested technologies in 2026. This blueprint optimizes for **time-to-value, maintainability, and cost-efficiency** while preserving the platform's core capabilities: transcript analysis, account knowledge graphs, stakeholder intelligence, SE coaching, and competitive intelligence.

---

## 1. Executive Summary

### What We're Building
A SaaS platform that ingests sales call transcripts (Gong, Momentum, manual) and other signals (Slack, email, CRM), runs them through a multi-pass AI analysis pipeline, and produces:
- A compounding **account knowledge graph** (pain points, use cases, stakeholders, technologies)
- **SE coaching scores** across 13 dimensions (including vocal delivery)
- **Competitive intelligence** scored against a 93-subcategory rubric
- **Next Best Actions** routed to the right team member
- Executive dashboards, mutual action plans (MAPs), and evaluation decks

### Core Architectural Bets
1. **Monolithic Next.js app** for the web tier (vs. SPA + separate API) — simpler deploys, fewer moving parts, full-stack TypeScript.
2. **Postgres (Supabase or Neon) as the single source of truth** — relational + JSONB + pgvector covers 95% of needs without bolting on Mongo/Pinecone/Elastic.
3. **Inngest or Trigger.dev for the analysis pipeline** instead of hand-rolled edge functions + cron — durable, observable, retry-safe workflows out of the box.
4. **Vercel AI SDK + OpenRouter** for model abstraction — swap providers without rewriting prompts.
5. **Tigris/S3 + signed URLs** for transcript blobs; **never store >100KB text in row columns**.

---

## 2. Recommended Tech Stack

### Frontend
| Concern | Choice | Why |
|---|---|---|
| Framework | **Next.js 15 (App Router)** | Server components reduce client JS, built-in API routes, mature ecosystem |
| UI library | **shadcn/ui + Tailwind CSS v4** | Copy-paste components, full design control, no runtime cost |
| Data fetching | **TanStack Query v5** + **server actions** | Cache + optimistic updates for client; SA for mutations |
| Forms | **react-hook-form + Zod** | Type-safe validation shared with backend |
| Charts | **Recharts** or **Tremor** | Tremor for dashboards, Recharts for custom viz |
| Tables | **TanStack Table v8** | Headless, virtualized for 10K+ rows |

### Backend
| Concern | Choice | Why |
|---|---|---|
| Runtime | **Node.js 22 on Vercel/Fly.io** | Universal, fast cold starts on Fly Machines |
| API style | **tRPC** or **Next.js Route Handlers + Zod** | End-to-end type safety; tRPC if heavy client-server |
| Database | **Postgres 16 (Supabase or Neon)** | RLS, pgvector, branching (Neon), realtime (Supabase) |
| ORM | **Drizzle ORM** | SQL-first, lightweight, no codegen lag, great migrations |
| Auth | **Clerk** or **WorkOS** (enterprise SSO) | Drop-in MFA, SAML, impersonation; skip rebuilding auth |
| Background jobs | **Inngest** | Durable workflows, step retries, fan-out, replay UI |
| File storage | **Supabase Storage** or **Cloudflare R2** | S3-compatible, cheap egress (R2) |
| Search | **Postgres FTS + pgvector** | Hybrid keyword + semantic; defer Elastic until >10M docs |
| Realtime | **Supabase Realtime** or **Pusher** | For pipeline status, notifications |

### AI / ML Layer
| Concern | Choice | Why |
|---|---|---|
| Model gateway | **OpenRouter** or **Vercel AI Gateway** | One API, 100+ models, automatic fallback |
| Primary models | **Gemini 2.5 Flash** (extraction), **Gemini 2.5 Pro** (synthesis), **GPT-5-mini** (coaching) | Cost/quality sweet spots; use Pro only for hard reasoning |
| Embeddings | **OpenAI text-embedding-3-small** or **Voyage-3** | 1536-dim, cheap, good for semantic dedup |
| Structured output | **Zod + tool-calling** (not JSON mode) | More reliable across providers |
| Prompt management | **Promptfoo** (eval) + **Git** (versioning) | No vendor lock-in; treat prompts as code |
| Observability | **Langfuse** (self-hosted) or **Helicone** | Trace every LLM call, latency/cost dashboards |
| Audio (optional) | **Deepgram Nova-3** or **AssemblyAI Universal-2** | If you want native audio scoring for vocal delivery |

### Integrations
| Source | Approach |
|---|---|
| **Gong** | Direct API (v2) with cursor pagination + webhook subscriptions |
| **Momentum / Grain / Fathom** | Webhook ingestion → S3 → queue |
| **Salesforce** | **Nango** or **Merge.dev** (saves months of OAuth + schema work) |
| **Slack** | Bolt SDK + Events API; channel join + message scraper |
| **Email (inbound)** | **Resend Inbound** or **Postmark** with custom MX |
| **Calendar/Drive** | Nango again |

### DevOps
| Concern | Choice |
|---|---|
| Hosting | **Vercel** (web) + **Fly.io** (long-running workers) |
| Monitoring | **Sentry** (errors) + **Axiom** (logs) + **Langfuse** (LLM) |
| Feature flags | **PostHog** (also analytics + session replay) |
| CI/CD | **GitHub Actions** + Vercel preview deploys |
| Secrets | **Doppler** or Vercel Env (sync to Fly) |

---

## 3. Data Model (Core Tables)

Keep the schema lean. Resist the urge to create a table per feature — use JSONB for flexible attributes and lift to columns only when you need to query/index them.

```sql
-- Tenancy
organizations (id, name, plan, created_at)
users (id, org_id, email, role, ...)              -- managed by Clerk; mirrored locally
team_members (id, org_id, user_id, manager_id)    -- supports dotted-line via team_member_managers join

-- Core CRM mirror
accounts (id, org_id, name, salesforce_id, arr, stage, owner_id, ...)
opportunities (id, account_id, name, stage, amount, close_date, ...)
contacts (id, account_id, email_hash, name_encrypted, role, ...)

-- Ingestion
transcripts (
  id, org_id, account_id, opportunity_id,
  source,              -- 'gong' | 'momentum' | 'manual' | 'email'
  external_id,
  recorded_at,
  participants jsonb,  -- [{email, name, role, is_internal}]
  storage_key,         -- S3/R2 path to raw transcript
  status,              -- 'queued' | 'analyzing' | 'complete' | 'failed'
  pipeline_run_id      -- Inngest run for observability
)

-- Knowledge graph (compounding insights)
insights (
  id, org_id, account_id, opportunity_id,
  type,                -- 'pain_point' | 'use_case' | 'metric' | 'theme' | 'tech'
  payload jsonb,       -- type-specific structure
  confidence numeric,
  mention_count int,
  first_seen_transcript_id, last_seen_transcript_id,
  embedding vector(1536),
  superseded_by uuid   -- for snapshot history
)
-- Use partial indexes per type for query speed:
-- CREATE INDEX ON insights (account_id) WHERE type = 'pain_point';

-- Stakeholders (separate because they're heavily queried)
stakeholders (
  id, contact_id, opportunity_id,
  champion_score, influence_level, sentiment,
  meddic_role,         -- 'champion' | 'economic_buyer' | 'technical_buyer' | ...
  last_assessed_at
)

-- Coaching
coaching_scores (
  id, transcript_id, se_user_id,
  overall_score numeric,
  dimensions jsonb,    -- {discovery: 4.2, energy: 3.1, ...}
  evidence jsonb,      -- [{dimension, quote, timecode_seconds, assessment}]
  delivery_breakdown jsonb  -- {pitch_variation, value_word_emphasis, ...}
)

-- Detection rules (the configurable signal layer)
detection_rules (id, org_id, name, conditions jsonb, actions jsonb, is_active)
detection_matches (id, rule_id, transcript_id, captured jsonb, created_at)

-- Audit / history
insight_snapshots (id, insight_id, payload, valid_from, valid_to, source_transcript_id)
```

**Key principles:**
- **Multi-tenancy via `org_id` + RLS on every table.** No exceptions.
- **One `insights` table** with discriminated `type`, not 8 separate tables. Easier to dedupe, embed, and query the knowledge graph.
- **Encrypted columns only for true PII** (contact name, email, phone, transcript text). Use Supabase Vault or pgcrypto + a KMS-managed key. Don't encrypt `role`, `sentiment`, scores — you need to query them.
- **Append-only `insight_snapshots`** for time-travel; the live `insights` row is always "current."

---

## 4. The Analysis Pipeline (the heart of the system)

This is the most important architectural decision. The current platform uses a chain of edge functions with hand-rolled retry/recovery — it works but is hard to debug. **Use Inngest instead.**

### Pipeline as an Inngest function

```typescript
// inngest/analyze-transcript.ts
export const analyzeTranscript = inngest.createFunction(
  {
    id: "analyze-transcript",
    retries: 3,
    concurrency: { limit: 20, key: "event.data.orgId" }, // per-tenant fairness
  },
  { event: "transcript/uploaded" },
  async ({ event, step }) => {
    const { transcriptId } = event.data;

    // Step 1: Fetch + normalize (cached on retry)
    const transcript = await step.run("load", () => loadTranscript(transcriptId));

    // Step 2: Core extraction (parallel passes)
    const [core, summary, signals] = await Promise.all([
      step.run("extract-core", () => extractCore(transcript)),       // pain, use cases, metrics
      step.run("summarize", () => summarize(transcript)),
      step.run("detect-signals", () => runDetectionRules(transcript)),
    ]);

    // Step 3: Stakeholder enrichment (depends on core)
    const stakeholders = await step.run("stakeholders", () =>
      enrichStakeholders(transcript, core.participants)
    );

    // Step 4: Persist with semantic dedup
    await step.run("persist", () => upsertInsights(core, stakeholders, signals));

    // Step 5: Fan out to async passes
    await step.sendEvent("coaching", { name: "transcript/score-coaching", data: { transcriptId } });
    await step.sendEvent("competitive", { name: "transcript/score-competitive", data: { transcriptId } });
    await step.sendEvent("nbas", { name: "transcript/generate-nbas", data: { transcriptId } });
  }
);
```

**Why this is dramatically better than the current setup:**
- ✅ **Free retries** with exponential backoff per step
- ✅ **Replay any failed run** from the Inngest UI without writing recovery code
- ✅ **Per-tenant concurrency** prevents one noisy customer from starving others
- ✅ **Observable**: see every step's input/output, duration, cost
- ✅ **No "stuck enrichment" recovery service needed** — Inngest handles it

### Prompt strategy

1. **One file per pass** in `prompts/` (versioned in git): `core-extraction.md`, `coaching.md`, `competitive.md`, etc.
2. **Use tool-calling, not JSON mode.** Define a Zod schema, convert to JSON Schema, pass as a tool. Forces structured output and works across providers.
3. **Truncate intelligently**: keep first 2K chars (context), last 2K chars (next steps), and keyword-relevant middle turns. The current `smartTruncate` logic is solid — port it.
4. **Cache by content hash**: if the transcript hasn't changed and the prompt version hasn't changed, skip the LLM call.

### Semantic deduplication (the secret sauce)

When extracting "pain points" across 50 calls for one account, you'll get the same pain phrased 30 different ways. Solution:

```typescript
async function upsertInsight(orgId: string, accountId: string, candidate: Insight) {
  const embedding = await embed(candidate.payload.text);
  
  // Find existing insights within cosine distance 0.15
  const matches = await db.execute(sql`
    SELECT id, mention_count FROM insights
    WHERE org_id = ${orgId} AND account_id = ${accountId} AND type = ${candidate.type}
      AND embedding <=> ${embedding} < 0.15
    ORDER BY embedding <=> ${embedding}
    LIMIT 1
  `);

  if (matches.length) {
    // Increment mention count, update last_seen, take higher confidence
    return db.update(insights).set({
      mention_count: sql`mention_count + 1`,
      last_seen_transcript_id: candidate.transcriptId,
      confidence: sql`GREATEST(confidence, ${candidate.confidence})`,
    }).where(eq(insights.id, matches[0].id));
  }
  
  return db.insert(insights).values({ ...candidate, embedding, mention_count: 1 });
}
```

This is what makes the knowledge graph **compound** instead of becoming a dumping ground.

---

## 5. SE Coaching: Vocal Delivery Done Right

The current platform infers vocal delivery (pitch, pace, value-word emphasis) from text alone, which is fundamentally limited. If rebuilding, do this properly:

### Two-track approach

**Track A — Text-only (what exists today):**
Keep this as the baseline. Score the 5 delivery techniques (Staircase pitch, Value Word Emphasis, BPM variation, Vocal Warmth, Verbal Highlighters) from transcript patterns and discourse markers. Cheap, fast, available for any text source.

**Track B — Audio-aware (the upgrade):**
When raw audio is available (Gong, Momentum recordings):

```typescript
// 1. Get word-level timestamps + prosody from Deepgram Nova-3
const result = await deepgram.transcribe(audioUrl, {
  diarize: true,
  punctuate: true,
  utterances: true,
  // Nova-3 returns confidence + speaker; for prosody use a separate model
});

// 2. Compute acoustic features per SE utterance with a small Python worker (Modal or Replicate)
//    - F0 (pitch) variance — detects monotone
//    - Speech rate (words/sec) variance — detects pace changes
//    - Loudness (RMS) variance — detects emphasis
//    - Smile detection from formant analysis (optional)
const prosody = await modal.run("prosody-features", { audioUrl, utterances });

// 3. Feed acoustic features + transcript to the coaching LLM
const coaching = await scoreCoaching({ transcript, prosody });
```

Acoustic features turn the coaching from "AI guesses you sounded flat" into "F0 variance was 8 Hz vs. team median 24 Hz — measurably monotone for the 4:32–7:18 segment." This is the killer feature.

---

## 6. Security & Compliance

### Bare minimum for SOC 2 Type 1 readiness from day 1:
| Control | Implementation |
|---|---|
| Authentication | Clerk/WorkOS with mandatory MFA for admins |
| Authorization | Postgres RLS on every table; `has_role()` security-definer function |
| Encryption at rest | Database-level (AWS RDS/Supabase default) + column-level for PII via pgcrypto + KMS key |
| Encryption in transit | TLS 1.3 enforced; HSTS headers |
| Audit logging | Append-only `audit_log` table for all writes to sensitive tables (use Postgres triggers) |
| Secret management | Doppler or Vercel Env; rotate quarterly |
| Backup | Point-in-time recovery (Neon: 30 days; Supabase: 7+ days) |
| Vulnerability scanning | Dependabot + Snyk; weekly `npm audit` in CI |

### LLM-specific concerns:
- **Never send raw PII to the LLM.** Pre-redact emails/phones with a regex pass before prompts; restore in post-processing.
- **Log prompts but redact outputs in error logs.** Avoid leaking customer data into Sentry.
- **Use a dedicated AI gateway** (OpenRouter/Helicone) so you have a single audit trail of every model call.

---

## 7. Build Order (Phased Roadmap)

A two-engineer team can ship a credible v1 in **~12 weeks**.

### Phase 1 — Foundation (Weeks 1–3)
- Next.js app, Clerk auth, Postgres + Drizzle, Tailwind/shadcn baseline
- Org/user/account/opportunity tables with RLS
- Manual transcript upload + S3 storage + simple list view
- Inngest wired in with one trivial function (proof of life)

### Phase 2 — Core Pipeline (Weeks 4–6)
- Core extraction pass (pain points, use cases, metrics) → insights table
- Semantic dedup with pgvector
- Account detail page showing compounding insights with confidence
- Basic search across transcripts (Postgres FTS)

### Phase 3 — Stakeholders & Coaching (Weeks 7–9)
- Stakeholder extraction + MEDDIC classification
- Champion scoring + sentiment trends
- SE coaching pass (13 dimensions, text-only)
- Manager dashboard MVP

### Phase 4 — Integrations & Detection (Weeks 10–12)
- Gong sync (most-requested integration first)
- Salesforce via Nango
- Detection rules engine + NBA generation
- Email digest notifications via Resend

### Phase 5 — Differentiators (post-launch)
- Audio-aware coaching (Track B above)
- Competitive intelligence with rubric scoring
- MAP / Evaluation Deck PDF exports
- MCP server for AI-agent access

---

## 8. What to Skip (Common Traps)

- ❌ **Microservices.** A monolith with Inngest workers handles 10K orgs comfortably. Split when a team owns each service, not before.
- ❌ **GraphQL.** tRPC or REST + Zod gives you the same type safety with 1/10 the complexity.
- ❌ **Custom auth.** Clerk costs less per month than one engineer-day. Use it.
- ❌ **Vector database (Pinecone/Weaviate).** pgvector handles 100M+ vectors fine for this use case. Co-locating vectors with relational data is a massive win.
- ❌ **Building a model router.** OpenRouter does it better; you'd spend a quarter and still be behind.
- ❌ **Kubernetes.** Vercel + Fly Machines covers 99% of cases. Defer until you're hiring a platform team.
- ❌ **Real-time collaboration (Liveblocks/Yjs).** Sales engineers don't co-edit MAPs simultaneously. Optimistic UI + last-write-wins is fine.

---

## 9. Cost Envelope (rough monthly at 50 paying orgs, ~5K transcripts/month)

| Line item | Cost |
|---|---|
| Vercel Pro | $20 |
| Neon Scale (or Supabase Pro) | $69–$599 |
| Inngest Pro | $50 |
| Clerk (5K MAU) | $125 |
| Cloudflare R2 storage | $15 |
| LLM (Gemini Flash for 90% + Pro for synthesis) | $400–$1,200 |
| Embeddings | $30 |
| Sentry + Langfuse + PostHog | $150 |
| Deepgram (if audio) | $200–$800 |
| **Total** | **~$1,000–$3,000/mo** |

At ~$200/seat ARPU and 250 seats, that's a 90%+ gross margin business. The dominant variable cost is LLM tokens — invest engineering time in prompt compression, caching, and routing to cheap models for easy calls.

---

## 10. Decision Records (the "why" log)

Maintain a `decisions/` folder of short markdown ADRs (Architectural Decision Records). When future-you asks "why didn't we use Mongo?" — the answer should be one click away. Template:

```markdown
# ADR-007: Use Postgres + pgvector instead of Pinecone
- Date: 2026-04-20
- Status: Accepted
- Context: Need semantic search over 10M insights
- Decision: pgvector with HNSW index
- Consequences: One database, lower ops cost; revisit if QPS > 5K
```

---

## Closing Thought

The current platform's biggest strengths — the compounding knowledge graph, the multi-pass pipeline, the 13-dimension coaching with vocal delivery breakdown — are the **product**, not the **infrastructure**. The infrastructure should be as boring and commodity as possible so the team can spend 90% of its time on the product.

Pick boring tech. Ship in weeks, not quarters. Add complexity only when a real customer pays you to.

# Security Architecture Documentation

## Overview

This document provides a comprehensive overview of the security architecture implemented in the Pendo TechMap application, including authentication, authorization, encryption, session management, and infrastructure security controls.

---

## 1. User Registration

### 1.1 Registration Flow

```mermaid
sequenceDiagram
    participant User
    participant AuthPage
    participant auth-register Edge Function
    participant Database
    participant Resend Email Service
    
    User->>AuthPage: Submit registration form
    AuthPage->>auth-register: POST /auth-register
    auth-register->>auth-register: Validate @pendo.io domain
    auth-register->>auth-register: Validate password strength
    auth-register->>Database: Check for existing user
    auth-register->>auth-register: Hash password (PBKDF2)
    auth-register->>auth-register: Generate verification token
    auth-register->>Database: Insert profile (status: pending)
    auth-register->>Resend Email Service: Send verification email
    Resend Email Service->>User: Verification email
    auth-register->>AuthPage: Success response
```

### 1.2 Domain Restriction

- **Allowed Domain**: `@pendo.io` only
- **Enforcement**: Server-side validation in `auth-register` edge function
- **Implementation**: `src/pages/AuthPage.tsx`, `supabase/functions/auth-register/index.ts`

### 1.3 Password Requirements

| Requirement | Value |
|-------------|-------|
| Minimum Length | **12 characters** |
| Uppercase Required | Yes (at least 1) |
| Lowercase Required | Yes (at least 1) |
| Number Required | Yes (at least 1) |
| Special Character Required | Yes (at least 1 of: `!@#$%^&*()_+-=[]{}|;:,.<>?`) |
| Weak Pattern Detection | Yes (rejects common passwords, sequences) |
| Hashing Algorithm | PBKDF2 |
| Hash Function | SHA-256 |
| Iterations | **310,000** (OWASP 2023 recommendation) |
| Salt Length | 16 bytes (128 bits) |
| Output Key Length | 256 bits |

### 1.4 Password Complexity Validation

```typescript
// supabase/functions/auth-register/index.ts
function validatePasswordComplexity(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (password.length < 12) errors.push('Minimum 12 characters required');
  if (!/[A-Z]/.test(password)) errors.push('Uppercase letter required');
  if (!/[a-z]/.test(password)) errors.push('Lowercase letter required');
  if (!/[0-9]/.test(password)) errors.push('Number required');
  if (!/[!@#$%^&*()_+\-=\[\]{}|;:,.<>?]/.test(password)) errors.push('Special character required');
  
  // Reject weak patterns
  const weakPatterns = [/password/i, /qwerty/i, /^(.)\1+$/, /^(012|123|234)+$/];
  for (const pattern of weakPatterns) {
    if (pattern.test(password)) errors.push('Common weak pattern detected');
  }
  
  return { valid: errors.length === 0, errors };
}
```

### 1.5 Password Hashing Implementation

```typescript
// supabase/functions/auth-register/index.ts
async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16)); // 128-bit salt
  const keyMaterial = await crypto.subtle.importKey("raw", passwordData, "PBKDF2", false, ["deriveBits"]);
  const hash = await crypto.subtle.deriveBits({
    name: "PBKDF2",
    salt: salt,
    iterations: 310000, // OWASP 2023 recommendation (up from 100k)
    hash: "SHA-256",
  }, keyMaterial, 256);
  // Salt + hash combined and Base64 encoded for storage
}
```

**Note**: Legacy passwords hashed with 100,000 iterations are still supported for backward compatibility. Password verification attempts both iteration counts.

### 1.5 Email Verification

| Parameter | Value |
|-----------|-------|
| Token Length | 256 bits (32 bytes, 64 hex chars) |
| Token Expiry | 24 hours |
| Email Service | Resend |
| From Address | noreply@sependo.org |

---

## 2. User Authentication

### 2.1 Login Flow

```mermaid
sequenceDiagram
    participant User
    participant AuthPage
    participant auth-login Edge Function
    participant Database
    
    User->>AuthPage: Submit credentials
    AuthPage->>auth-login: POST /auth-login
    auth-login->>Database: Fetch user profile
    auth-login->>auth-login: Verify email is confirmed
    auth-login->>auth-login: Verify password (PBKDF2)
    
    alt MFA Enabled
        auth-login->>AuthPage: Request TOTP code
        User->>AuthPage: Enter TOTP code
        AuthPage->>auth-login: POST with TOTP
        auth-login->>auth-login: Verify TOTP (HMAC-SHA1)
    end
    
    auth-login->>auth-login: Generate session token
    auth-login->>Database: Create user_sessions record
    auth-login->>Database: Update last_login_at
    auth-login->>Database: Cleanup expired sessions
    auth-login->>AuthPage: Return session token + user data
    AuthPage->>User: Store token, redirect to app
```

### 2.2 Password Verification

```typescript
// supabase/functions/auth-login/index.ts
async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
  // Decode stored hash (salt + hash combined)
  const combined = decodeBase64(storedHash);
  const salt = combined.slice(0, 16);
  const storedHashBytes = combined.slice(16);
  
  // Derive hash with same parameters
  const hash = await crypto.subtle.deriveBits({
    name: "PBKDF2",
    salt: salt,
    iterations: 100000,
    hash: "SHA-256",
  }, keyMaterial, 256);
  
  // Constant-time comparison to prevent timing attacks
  let result = 0;
  for (let i = 0; i < hashArray.length; i++) {
    result |= hashArray[i] ^ storedHashBytes[i];
  }
  return result === 0;
}
```

### 2.3 Account Status Checks

| Status | Access |
|--------|--------|
| `pending` | Blocked until email verified |
| `active` | Full access |
| `suspended` | Blocked with error message |
| `locked` | Temporarily blocked due to failed login attempts |

### 2.4 Brute-Force Protection & Account Lockout

| Parameter | Value |
|-----------|-------|
| Max Failed Attempts Before Lockout | 5 |
| Lockout Duration (after 5 fails) | 1 minute |
| Lockout Duration (after 6 fails) | 2 minutes |
| Lockout Duration (after 7 fails) | 4 minutes |
| Lockout Duration (exponential) | 2^(attempts-5) minutes |
| Maximum Lockout Duration | 24 hours |

```typescript
// supabase/functions/auth-login/index.ts
// Check if account is locked
if (user.locked_until) {
  const lockedUntil = new Date(user.locked_until);
  if (lockedUntil > new Date()) {
    const remainingMinutes = Math.ceil((lockedUntil.getTime() - Date.now()) / 60000);
    throw new Error(`Account is temporarily locked. Try again in ${remainingMinutes} minute(s).`);
  }
}

// On failed password verification
const { data: lockoutData } = await supabaseAdmin.rpc('increment_failed_login', { _user_id: user.id });

// On successful login
await supabaseAdmin.rpc('reset_failed_login_attempts', { _user_id: user.id });
```

**Database Functions**:
- `increment_failed_login(_user_id)`: Increments counter and applies exponential lockout
- `reset_failed_login_attempts(_user_id)`: Clears counter and lockout on successful login

---

## 3. Multi-Factor Authentication (MFA)

### 3.1 2FA Implementation

| Parameter | Value |
|-----------|-------|
| Algorithm | TOTP (RFC 6238) |
| Hash | HMAC-SHA1 |
| Digits | 6 |
| Time Step | 30 seconds |
| Time Window | ±1 step (allows for clock drift) |
| Secret Encoding | Base32 |

### 3.2 TOTP Verification

```typescript
// supabase/functions/auth-login/index.ts
async function verifyTotp(secret: string, token: string, window: number = 1): Promise<boolean> {
  const secretBytes = decodeBase32(secret);
  const now = Math.floor(Date.now() / 1000);
  const period = 30;
  
  // Check current and adjacent time windows
  for (let i = -window; i <= window; i++) {
    const timeStep = Math.floor(now / period) + i;
    const expectedToken = await generateTotp(secretBytes, timeStep);
    if (expectedToken === token.padStart(6, '0')) {
      return true;
    }
  }
  return false;
}
```

### 3.3 2FA Setup Flow

1. User logs in without MFA
2. System prompts 2FA setup (mandatory for all users)
3. `auth-setup-2fa` generates secret and returns QR code URI
4. User scans QR with authenticator app
5. User verifies with TOTP code
6. `auth-verify-2fa` validates and stores secret

### 3.4 2FA Recovery

- Admin can reset MFA via `admin-reset-mfa` edge function
- Requires admin role verification

---

## 4. Session Management

### 4.1 Session Token Generation

| Parameter | Value |
|-----------|-------|
| Token Length | 384 bits (48 bytes, 96 hex chars) |
| Generation | `crypto.getRandomValues()` |
| Storage Client-Side | localStorage (`auth_session_token`) |
| Storage Server-Side | `user_sessions` table |

```typescript
// supabase/functions/auth-login/index.ts
function generateSessionToken(): string {
  const array = new Uint8Array(48);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}
```

### 4.2 Session Parameters

| Parameter | Value |
|-----------|-------|
| Session Duration | 7 days |
| Inactivity Timeout | 1 hour (client-side) |
| Activity Throttle | 1 minute minimum between resets |

### 4.3 Session Metadata Captured

| Field | Description |
|-------|-------------|
| `user_id` | Reference to profiles table |
| `token` | Unique session identifier |
| `expires_at` | Absolute expiration timestamp |
| `created_at` | Session creation time |
| `last_activity_at` | Last validated activity |
| `user_agent` | Browser/client identifier |
| `ip_address` | Client IP (from X-Forwarded-For) |
| `fingerprint_hash` | SHA-256 hash of User-Agent + IP for hijacking detection |

### 4.4 Session Fingerprinting (Hijacking Detection)

Sessions are bound to a fingerprint hash generated from the client's User-Agent and IP address. This helps detect potential session hijacking.

```typescript
// supabase/functions/auth-login/index.ts
async function generateSessionFingerprint(userAgent: string, ipAddress: string): Promise<string> {
  const data = `${userAgent}:${ipAddress}`;
  const encoder = new TextEncoder();
  const hashBuffer = await crypto.subtle.digest('SHA-256', encoder.encode(data));
  const hashArray = new Uint8Array(hashBuffer);
  return Array.from(hashArray, byte => byte.toString(16).padStart(2, '0')).join('');
}
```

| Behavior | Action |
|----------|--------|
| Fingerprint matches | Session validated normally |
| Fingerprint mismatch | Security warning logged (allows for legitimate IP changes) |
| Strict mode (optional) | Can reject mismatched sessions |

**Note**: IP addresses can legitimately change (mobile networks, VPNs), so mismatches are logged as warnings rather than hard rejections by default.

### 4.4 Session Validation

```typescript
// supabase/functions/api-gateway/index.ts
async function validateSession(supabase: any, sessionToken: string): Promise<{ valid: boolean; userId?: string }> {
  const { data, error } = await supabase.rpc('validate_session', { _token: sessionToken });
  
  if (error || !data || data.length === 0) {
    return { valid: false, error: 'Invalid or expired session' };
  }
  
  // Session updates last_activity_at on each validation
  return { valid: true, userId: data[0].user_id };
}
```

### 4.5 Session Cleanup

- Automated cleanup via `cleanup_expired_sessions()` database function
- Triggered on every login
- Removes all sessions where `expires_at < now()`

---

## 5. Data Encryption

### 5.1 Encryption Algorithm

| Parameter | Value |
|-----------|-------|
| Algorithm | AES-GCM |
| Key Length | 256 bits (32 bytes) |
| IV Length | 96 bits (12 bytes) |
| Key Source | `TRANSCRIPT_ENCRYPTION_KEY` secret |
| Key Format | 64-character hex string |

### 5.2 Key Derivation

```typescript
// supabase/functions/api-gateway/index.ts
function deriveKeyBytes(keyInput: string): Uint8Array {
  // Handle hex-encoded keys (64 hex chars = 32 bytes = 256 bits)
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  // Fallback for text keys (padded/truncated to 32 bytes)
}
```

### 5.3 Encryption Process

```typescript
async function encrypt(plaintext: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey("raw", keyBytes.buffer, "AES-GCM", false, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12)); // Fresh IV per encryption
  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plainBytes);
  return { ciphertext: bytesToBase64(cipherBytes), iv: bytesToBase64(iv) };
}
```

### 5.4 Encrypted Tables & Fields

| Table | Encrypted Fields |
|-------|-----------------|
| `account_contacts` | name, email, phone, role, notes |
| `account_nbas` | action, notes |
| `account_pain_points` | pain_point, business_impact |
| `account_use_cases` | use_case, description |
| `account_metrics` | metric_value, context |
| `account_strategic_themes` | theme_name, description, supporting_evidence |
| `account_exec_summaries` | summary_narrative, key_risks, key_opportunities, health_indicators, engagement_summary |
| `account_team_members` | team_member_email |
| `account_captured_insights` | value, value_json |
| `contact_meeting_snapshots` | notes, key_quotes, topics_discussed, concerns_raised, action_items |
| `customer_stories` | situation, behavior, impact, impact_metrics |
| `competitor_scores` | rationale |
| `competitors` | description, relationship_notes |
| `account_technologies` | owner_name, owner_email, notes, context |
| `account_documents` | content, name |
| `transcript_reviews` | transcript_content |
| `momentum_meetings` | title, host_email, host_name, attendees, transcript_content |
| `opportunity_readiness_answers` | answer, notes, evidence |

### 5.5 Encryption Schema Pattern

Each encrypted table follows this pattern:
```sql
-- Plaintext field (cleared after encryption)
field_name TEXT,
-- Encrypted field
field_name_encrypted TEXT,
-- Shared IV for the record
encryption_iv TEXT,
-- Flag indicating encryption status
is_encrypted BOOLEAN DEFAULT false
```

### 5.6 Tables NOT Encrypted (By Design)

| Table | Reason |
|-------|--------|
| `profiles` | Email required for login lookups before session exists; auth functions query by email directly |
| `user_sessions` | Token lookups required for session validation; no PII stored |
| `user_roles` | Role names are not sensitive; required for authorization checks |

**Note**: The `profiles` table intentionally stores `email` and `full_name` in cleartext because:
1. Auth edge functions (login, register, invite) run **before** a session exists
2. Login requires querying by email to find the user
3. Encrypting email would require decrypting all records to find a match
4. These functions use the `service_role` key and bypass the API Gateway

---

## 6. API Gateway Security

### 6.1 Gateway Architecture

```mermaid
flowchart TD
    A[Client Request] --> B[API Gateway Edge Function]
    B --> C{Session Valid?}
    C -->|No| D[401 Unauthorized]
    C -->|Yes| E{Table Allowed?}
    E -->|No| F[403 Forbidden]
    E -->|Yes| G{Operation}
    G -->|SELECT| H[Decrypt on Read]
    G -->|INSERT/UPDATE| I[Encrypt on Write]
    H --> J[Return Data]
    I --> K[Store Data]
```

### 6.2 Request Flow

1. **Session Validation**: Every request requires valid session token in `Authorization` header
2. **Table Allowlist**: Only whitelisted tables can be accessed
3. **Automatic Encryption**: Write operations encrypt sensitive fields
4. **Automatic Decryption**: Read operations decrypt sensitive fields
5. **Response**: Data returned to client in plaintext

### 6.3 Allowed Tables

The API Gateway maintains an explicit allowlist of tables that can be accessed:

- accounts, account_* (all account-related tables)
- opportunities, opportunity_*
- transcript_reviews
- momentum_meetings
- technology_repository
- functional_areas
- competitors, competitive_*
- customer_stories
- detection_rules, detection_rule_*
- And 40+ more tables

### 6.4 CORS Configuration

All edge functions implement Cross-Origin Resource Sharing (CORS) headers to allow browser requests from any origin.

| Header | Value | Purpose |
|--------|-------|---------|
| `Access-Control-Allow-Origin` | `*` | Allow requests from any origin |
| `Access-Control-Allow-Headers` | `authorization, x-client-info, apikey, content-type, x-session-token` | Permitted request headers |
| `Access-Control-Allow-Methods` | `POST, OPTIONS` | Permitted HTTP methods |

```typescript
// Standard CORS headers for all edge functions
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-session-token',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

// Preflight handler (required for CORS)
if (req.method === 'OPTIONS') {
  return new Response(null, { headers: corsHeaders });
}
```

**Important**: The `Access-Control-Allow-Methods` header is **required** for preflight requests to succeed. Without it, browsers will block POST requests with a CORS error: "Method OPTIONS is not allowed by Access-Control-Allow-Methods in preflight response."

### 6.5 Firewall/WAF Allowlist

For enterprise networks using Cloudflare or other WAF solutions, the following domains must be allowlisted:

| Domain Pattern | Purpose |
|----------------|---------|
| `*.supabase.co` | Backend API and edge functions |
| `*.lovableproject.com` | Lovable preview environments |
| `*.lovable.app` | Published application domains |

**Required Endpoints**:

| Path Pattern | Methods | Purpose |
|--------------|---------|---------|
| `/auth/v1/*` | POST, GET, OPTIONS | Authentication API |
| `/functions/v1/*` | POST, OPTIONS | Edge functions |
| `/rest/v1/*` | GET, POST, PATCH, DELETE, OPTIONS | Database REST API |

**Required Headers to Permit**:
- `authorization`
- `apikey`
- `x-client-info`
- `x-supabase-api-version`
- `content-type`

---

## 7. Role-Based Access Control (RBAC)

### 7.1 Role Architecture

```mermaid
erDiagram
    profiles ||--o{ user_roles : has
    user_roles }o--|| custom_roles : references
    custom_roles ||--o{ page_role_access : grants
    page_role_access }o--|| pages : controls
```

### 7.2 System Roles

| Role | Description |
|------|-------------|
| `admin` | Full system access, user management, settings |
| `manager` | Team oversight, reporting, dashboard access |
| `se` | Solutions Engineer - account/opportunity management |
| `ae` | Account Executive - limited technical access |
| `product` | Product team - analytics and feature access |

### 7.3 Role Storage

```sql
-- Roles stored in separate table (not on profiles) to prevent privilege escalation
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY,
    user_id UUID REFERENCES profiles(id),
    role app_role NOT NULL,
    UNIQUE (user_id, role)
);
```

### 7.4 Security Definer Functions

```sql
-- Bypasses RLS to prevent recursive policy checks
CREATE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;
```

### 7.5 Page Access Control

| Level | Implementation |
|-------|---------------|
| Database | `page_role_access` table mapping pages to roles |
| Function | `can_access_page(_user_id, _page_path)` |
| Client | `useCanAccessPage()` hook |
| UI | Conditional rendering based on access |

### 7.6 Hierarchical Page Access

```typescript
// Example page hierarchy
{ path: '/accounts', name: 'Accounts', isParent: true }
{ path: '/accounts/details', name: 'Accounts → Details', parent: '/accounts' }
{ path: '/accounts/insights', name: 'Accounts → Insights', parent: '/accounts' }
```

---

## 8. Row-Level Security (RLS)

### 8.1 RLS Strategy

All tables have RLS enabled with policies based on:
- Session authentication (`auth.uid()`)
- Role-based functions (`is_admin()`, `has_role()`, `is_manager()`)
- Team hierarchy (`get_team_members()`, `is_in_team()`)

### 8.2 Common Policy Patterns

```sql
-- Admin full access
CREATE POLICY "Admins can manage" ON table_name
FOR ALL USING (is_admin(auth.uid()));

-- Team member access
CREATE POLICY "Team can view" ON table_name
FOR SELECT USING (
  is_in_team((SELECT id FROM profiles WHERE email = owner_email), auth.uid())
);

-- Authenticated user access
CREATE POLICY "Auth users can view" ON table_name
FOR SELECT USING (auth.uid() IS NOT NULL);
```

### 8.3 Team Hierarchy

```sql
-- Recursive function to get all team members under a manager
CREATE FUNCTION public.get_team_members(_manager_id uuid)
RETURNS TABLE(user_id uuid, depth integer)
AS $$
  WITH RECURSIVE team_tree AS (
    SELECT report_id AS user_id, 1 AS depth
    FROM public.team_hierarchy
    WHERE manager_id = _manager_id
    
    UNION ALL
    
    SELECT th.report_id, tt.depth + 1
    FROM public.team_hierarchy th
    INNER JOIN team_tree tt ON th.manager_id = tt.user_id
    WHERE tt.depth < 10  -- Safety limit
  )
  SELECT DISTINCT user_id, MIN(depth) FROM team_tree GROUP BY user_id
$$;
```

---

## 9. Infrastructure Security

### 9.1 Cloudflare Protection

| Feature | Status |
|---------|--------|
| DDoS Protection | ✅ Enabled (Cloudflare default) |
| SSL/TLS | ✅ Full (strict) mode |
| WAF | ✅ Managed ruleset |
| Bot Protection | ✅ Enabled |
| Rate Limiting | ✅ Configured |
| HTTPS Redirect | ✅ Always HTTPS |

### 9.2 DNS & Domain Security

| Domain | Purpose |
|--------|---------|
| `sependo.org` | Production application |
| `searchitecture.lovable.app` | Lovable Cloud preview |

### 9.3 Edge Function Security

| Control | Implementation |
|---------|---------------|
| JWT Verification | Disabled in config, validated in code |
| CORS | Configured headers on all functions |
| Input Validation | Server-side validation on all endpoints |
| Service Role Key | Used only for admin operations |

---

## 10. Secrets Management

### 10.1 Stored Secrets

| Secret | Purpose |
|--------|---------|
| `LOVABLE_API_KEY` | Lovable AI integration |
| `MOMENTUM_API_KEY` | Momentum integration |
| `GOOGLE_API_KEY` | AI model access |
| `RESEND_API_KEY` | Email service |
| `TRANSCRIPT_ENCRYPTION_KEY` | Data encryption (256-bit) |
| `SUPABASE_SERVICE_ROLE_KEY` | Admin database access |

### 10.2 Secret Access

- Secrets stored in Supabase Vault
- Accessed via `Deno.env.get()` in edge functions
- Never exposed to client-side code
- Never logged or included in error messages

---

## 11. Security Settings UI

### 11.1 Security Tab Access

The Security Settings tab is available in Settings → Security for administrators only. It provides visibility into security configurations and active session management.

**Location**: `src/components/views/SecuritySettingsTab.tsx`

### 11.2 Password Requirements Display

The tab displays current password complexity rules:

| Requirement | Display |
|-------------|---------|
| Minimum Length | 12 characters |
| Character Types | Uppercase, lowercase, number, special character |
| Pattern Detection | Common weak patterns rejected |

### 11.3 Brute-Force Protection Display

Shows the exponential lockout schedule:

| Failed Attempts | Lockout Duration |
|-----------------|-----------------|
| 5 | 1 minute |
| 6 | 2 minutes |
| 7 | 4 minutes |
| 8 | 8 minutes |
| 9 | 16 minutes |
| 10+ | Up to 24 hours max |

### 11.4 Active Session Management

Administrators can view and manage all active sessions:

| Information Displayed | Description |
|----------------------|-------------|
| Device | Parsed from User-Agent string |
| IP Address | Client IP from session metadata |
| Last Activity | Timestamp of last validated request |
| Session Age | Time since session creation |
| Status | Active or current session indicator |

**Session Termination**: Admins can terminate any session except their current one by clicking the terminate button, which deletes the session from the `user_sessions` table.

### 11.5 Security Features Summary

The tab displays a summary of implemented security features:

| Feature | Status |
|---------|--------|
| AES-256-GCM Encryption | ✅ Active |
| Session Fingerprinting | ✅ Active |
| Two-Factor Authentication | ✅/⏳ per user |
| Role-Based Access Control | ✅ Active |
| Row-Level Security | ✅ Active |

---

## 12. Security Checklist

### 12.1 Authentication
- [x] Password hashing with PBKDF2 (310,000 iterations)
- [x] Constant-time password comparison
- [x] Email verification required
- [x] Domain restriction (@pendo.io)
- [x] Account status enforcement
- [x] Password complexity validation (12+ chars, mixed case, numbers, symbols)
- [x] Weak pattern detection

### 12.2 Brute-Force Protection
- [x] Failed login attempt tracking
- [x] Exponential account lockout
- [x] Maximum lockout duration (24 hours)
- [x] Automatic unlock after timeout

### 12.3 Session Management
- [x] Cryptographically secure token generation (384-bit)
- [x] Server-side session storage
- [x] Automatic session expiration (7 days)
- [x] Inactivity timeout (1 hour)
- [x] Session cleanup on logout
- [x] Session fingerprinting for hijacking detection
- [x] Admin session management UI

### 12.4 Multi-Factor Authentication
- [x] TOTP-based 2FA
- [x] Mandatory for all users
- [x] Admin reset capability
- [x] Time window tolerance

### 12.5 Encryption
- [x] AES-256-GCM encryption
- [x] Unique IV per record
- [x] Automatic encrypt/decrypt in API Gateway
- [x] PII fields encrypted at rest

### 12.6 Authorization
- [x] Role-based access control
- [x] Page-level access control
- [x] Team hierarchy enforcement
- [x] Row-level security policies

### 12.7 API Security
- [x] Session validation on all requests
- [x] Table allowlist enforcement
- [x] CORS configuration
- [x] Input validation

### 12.8 Infrastructure
- [x] Cloudflare DDoS protection
- [x] SSL/TLS encryption in transit
- [x] Secrets management
- [x] No sensitive data in logs

---

## 13. Security Contacts

For security concerns or vulnerability reports, contact the development team through internal channels.

---

*Document Version: 1.1*  
*Last Updated: 2026-01-15*

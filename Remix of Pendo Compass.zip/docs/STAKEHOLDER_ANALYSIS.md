# Stakeholder Analysis & Visualization System

This document provides a comprehensive guide to the stakeholder analysis and visualization system, enabling replication in other applications.

## Table of Contents

1. [Overview](#overview)
2. [MEDDIC-Aligned Stakeholder Types](#meddic-aligned-stakeholder-types)
3. [Database Schema](#database-schema)
4. [AI-Powered Extraction](#ai-powered-extraction)
5. [Champion Identification Criteria](#champion-identification-criteria)
6. [Visualization Components](#visualization-components)
7. [Data Management](#data-management)
8. [Integration Points](#integration-points)
9. [Replication Checklist](#replication-checklist)

---

## Overview

The stakeholder analysis system automatically extracts and assesses people mentioned in meeting transcripts. Unlike simple position-based scoring, this system uses **MEDDIC-aligned stakeholder typing** with evidence-based classification.

### Key Principles

1. **No Default Champions**: Stakeholders are classified as "Unknown/Needs Analysis" until sufficient evidence exists
2. **Evidence-Based Scoring**: Champion status requires BOTH advocacy signals AND information sharing
3. **MEDDIC Alignment**: Stakeholder types map to sales methodology roles

### Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    Meeting Transcripts                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              analyze-transcript Edge Function                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ AI Extraction with Evidence Collection:                  │   │
│  │ - Person identification                                  │   │
│  │ - Advocacy signals detection                             │   │
│  │ - Information sharing signals detection                  │   │
│  │ - MEDDIC role classification                             │   │
│  │ - Evidence-based champion scoring                        │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                   account_contacts Table                        │
│  - name, role, email, phone                                     │
│  - stakeholder_type (MEDDIC-aligned)                            │
│  - influence_level, sentiment, champion_score (nullable!)       │
│  - advocacy_signals, info_sharing_signals (evidence JSON)       │
└─────────────────────────────────────────────────────────────────┘
```

---

## MEDDIC-Aligned Stakeholder Types

### Type Definitions

| Type | Label | Description | Key Signals |
|------|-------|-------------|-------------|
| `champion` | Champion | Internal advocate who actively sells for you | Advocacy + Info sharing |
| `economic_buyer` | Economic Buyer | Sponsor with budget authority | Budget discussions, final sign-off power |
| `decision_criteria_owner` | Decision Criteria Owner | Defines requirements | Technical/business requirements ownership |
| `coach` | Coach | Provides insider guidance | Shares org dynamics, gives advice |
| `blocker` | Blocker | Actively opposes the solution | Creates obstacles, raises objections |
| `end_user` | End User | Day-to-day user, limited decision power | Usage questions, workflow focus |
| `unknown` | Needs Analysis | Insufficient evidence | No clear signals detected |

### Champion Definition (Sales Context)

A **sales champion** is an influential person inside the customer's organization who:

1. **Actively advocates** for your product/service internally
2. **Acts as your internal partner** to drive the deal forward
3. **Navigates politics** and gains support from other stakeholders
4. **Believes in the solution's value** and is motivated to see it adopted
5. **Connects you with decision-makers** and helps overcome objections
6. **Provides insights**: internal data, challenges, and goals

**Critical Distinction**: A champion is NOT necessarily the economic buyer (final sign-off), but helps you get to that person.

---

## Database Schema

### account_contacts Table (Updated)

```sql
CREATE TABLE public.account_contacts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.accounts(id),
  opportunity_id UUID REFERENCES public.opportunities(id),
  
  -- Basic contact information
  name TEXT NOT NULL,
  role TEXT,
  email TEXT,
  phone TEXT,
  notes TEXT,
  
  -- MEDDIC-aligned stakeholder type
  stakeholder_type TEXT CHECK (stakeholder_type IN (
    'champion', 'economic_buyer', 'decision_criteria_owner', 
    'coach', 'blocker', 'end_user', 'unknown'
  )),
  
  -- Stakeholder assessment scores (0-100 scale, NULLABLE for unknown)
  influence_level INTEGER,        -- Decision-making power
  sentiment INTEGER,              -- Attitude toward solution
  champion_score INTEGER,         -- Advocacy likelihood (requires evidence)
  
  -- Evidence collection (JSON arrays of detected signals)
  advocacy_signals JSONB DEFAULT NULL,      -- Evidence of internal advocacy
  info_sharing_signals JSONB DEFAULT NULL,  -- Evidence of sharing insights
  
  -- Assessment metadata
  last_assessed_at TIMESTAMPTZ,
  assessment_source TEXT,  -- 'ai' or 'manual'
  
  -- Classification flags
  is_internal BOOLEAN DEFAULT false,
  is_ignored BOOLEAN DEFAULT false,
  ignored_reason TEXT,
  source TEXT,
  
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

### Evidence Signal Structures

```typescript
// Advocacy signals (evidence of internal selling)
interface AdvocacySignals {
  internalPushing?: string[];    // "I'll push this internally", "Let me talk to my boss"
  budgetAdvocacy?: string[];     // "I can get budget approved", "I'll find the funding"
  sponsorBehavior?: string[];    // "I'll sponsor this project", "I'll own this initiative"
  meetingFacilitation?: string[]; // "Let me set up a call with...", "I'll introduce you to..."
}

// Info sharing signals (evidence of providing insider knowledge)
interface InfoSharingSignals {
  orgChartSharing?: string[];    // Shared org structure, reporting lines
  internalChallenges?: string[]; // Shared pain points, internal blockers
  competitorInfo?: string[];     // Shared competitor evaluations
  timelineSharing?: string[];    // Shared decision timelines, budget cycles
  processSsharing?: string[];    // Shared procurement process, approval workflows
}
```

---

## AI-Powered Extraction

### Champion Detection Prompt

```text
STAKEHOLDER ANALYSIS - MEDDIC-ALIGNED CLASSIFICATION

For each external person mentioned, determine their stakeholder type based on 
OBSERVABLE EVIDENCE from the transcript. Do NOT guess or assume.

## CRITICAL: Champion Identification Requirements

A person is ONLY a Champion if BOTH conditions are met:
1. ADVOCACY SIGNALS: Evidence they will/do advocate internally
2. INFO SHARING SIGNALS: Evidence they share insider information

### Advocacy Signals (look for these exact behaviors):
- "I'll push this internally" / "Let me talk to my boss"
- "I can get budget approved" / "I'll find the funding"
- "I'll sponsor this project" / "I'll champion this"
- "Let me set up a call with [decision-maker]"
- Proactively defending your solution against objections
- Volunteering to present your solution to others

### Info Sharing Signals (look for these exact behaviors):
- Sharing org charts or reporting structures
- Explaining internal challenges and pain points openly
- Providing competitor evaluation information
- Sharing decision timelines and budget cycles
- Explaining procurement/approval processes
- Giving advice on how to navigate their organization

## Classification Rules:

CHAMPION: Has BOTH advocacy signals AND info sharing signals
ECONOMIC_BUYER: Has budget authority, mentions funding, final decision power
DECISION_CRITERIA_OWNER: Defines technical/business requirements
COACH: Shares info but no advocacy (helpful but not pushing)
BLOCKER: Raises objections, mentions competitors favorably, creates obstacles
END_USER: Focuses on day-to-day usage, workflow questions
UNKNOWN: Insufficient evidence for classification (DEFAULT)

## Scoring Rules:

- If stakeholder_type = 'unknown': Set influence_level, sentiment, champion_score to NULL
- Only score if you have actual evidence from the transcript
- champion_score requires BOTH signal types to be > 50
```

### ExtractedPerson Interface (Updated)

```typescript
interface ExtractedPerson {
  name: string;
  role: string | null;
  email: string | null;
  phone: string | null;
  context: string;
  
  // MEDDIC-aligned classification
  stakeholderType: 'champion' | 'economic_buyer' | 'decision_criteria_owner' | 
                   'coach' | 'blocker' | 'end_user' | 'unknown';
  
  // Scores (null if insufficient evidence)
  influenceLevel: number | null;
  sentiment: number | null;
  championScore: number | null;
  
  // Evidence collection
  advocacySignals: {
    detected: boolean;
    examples: string[];
  };
  infoSharingSignals: {
    detected: boolean;
    examples: string[];
  };
  
  isInternal: boolean;
}

---

## Visualization Components

### Quadrant Bubble Chart

The main visualization is a 2D quadrant chart:

- **X-Axis**: Sentiment (0-100, Negative → Positive)
- **Y-Axis**: Influence (0-100, Low → High)
- **Bubble Size**: Champion Score (larger = higher)
- **Bubble Color**: Quadrant-based

### Quadrant Definitions

```typescript
const QUADRANTS = {
  topRight: { 
    label: 'Champions', 
    description: 'High influence, positive sentiment - nurture these relationships', 
    color: 'hsl(var(--primary))' 
  },
  topLeft: { 
    label: 'Blockers', 
    description: 'High influence, negative sentiment - need attention', 
    color: 'hsl(var(--destructive))' 
  },
  bottomRight: { 
    label: 'Supporters', 
    description: 'Low influence, positive sentiment - potential future champions', 
    color: 'hsl(var(--layer-growth))' 
  },
  bottomLeft: { 
    label: 'Detractors', 
    description: 'Low influence, negative sentiment - monitor for escalation', 
    color: 'hsl(var(--muted-foreground))' 
  },
};
```

### Quadrant Assignment Logic

```typescript
const getQuadrant = (influence: number, sentiment: number) => {
  if (influence >= 50) {
    return sentiment >= 50 ? 'topRight' : 'topLeft';
  } else {
    return sentiment >= 50 ? 'bottomRight' : 'bottomLeft';
  }
};
```

### Bubble Size Calculation

```typescript
const getBubbleSize = (championScore: number) => {
  // Size range: 20px (min) to 60px (max)
  return Math.max(20, Math.min(60, 20 + (championScore / 100) * 40));
};
```

### Bubble Positioning

```typescript
// Position bubble on the chart (CSS positioning)
const getBubbleStyle = (x: number, y: number, size: number) => ({
  left: `calc(${x}% - ${size / 2}px)`,   // X = sentiment (0-100)
  bottom: `calc(${y}% - ${size / 2}px)`, // Y = influence (0-100)
  width: `${size}px`,
  height: `${size}px`,
});
```

### Summary Statistics

```typescript
const calculateStats = (stakeholders: Stakeholder[]) => {
  const champions = stakeholders.filter(s => 
    s.influence_level >= 50 && s.sentiment >= 50
  );
  const blockers = stakeholders.filter(s => 
    s.influence_level >= 50 && s.sentiment < 50
  );
  const avgChampionScore = stakeholders.reduce(
    (acc, s) => acc + s.champion_score, 0
  ) / stakeholders.length;
  
  return {
    total: stakeholders.length,
    champions: champions.length,
    blockers: blockers.length,
    avgChampionScore: Math.round(avgChampionScore),
  };
};
```

---

## Data Management

### Fetching Stakeholders

```typescript
// Fetch stakeholders for an account
const fetchStakeholders = async (accountId: string) => {
  const { data, error } = await supabase
    .from('account_contacts')
    .select(`
      id, name, role, email, 
      influence_level, sentiment, champion_score, 
      last_assessed_at, assessment_source, 
      is_ignored, is_internal
    `)
    .eq('account_id', accountId)
    .order('name');
  
  if (error) throw error;
  
  // Apply defaults for null values
  return data.map(d => ({
    ...d,
    influence_level: d.influence_level ?? 50,
    sentiment: d.sentiment ?? 50,
    champion_score: d.champion_score ?? 50,
    is_ignored: d.is_ignored ?? false,
    is_internal: d.is_internal ?? false,
  }));
};
```

### Filtering Visible Stakeholders

```typescript
// Filter out ignored and internal stakeholders by default
const getVisibleStakeholders = (
  stakeholders: Stakeholder[], 
  showIgnored: boolean
) => {
  if (showIgnored) return stakeholders;
  return stakeholders.filter(s => !s.is_ignored && !s.is_internal);
};
```

### Updating Stakeholder Scores

```typescript
// Manual score update
const updateStakeholder = async (
  id: string, 
  influence: number, 
  sentiment: number, 
  champion: number
) => {
  const { error } = await supabase
    .from('account_contacts')
    .update({
      influence_level: influence,
      sentiment: sentiment,
      champion_score: champion,
      last_assessed_at: new Date().toISOString(),
      assessment_source: 'manual',
    })
    .eq('id', id);
  
  if (error) throw error;
};
```

### Removing Stakeholders (Soft Delete)

```typescript
// Mark stakeholder as ignored (soft delete)
const ignoreStakeholder = async (
  id: string, 
  reason: string, 
  isInternal: boolean
) => {
  const { error } = await supabase
    .from('account_contacts')
    .update({
      is_ignored: !isInternal,
      is_internal: isInternal,
      ignored_reason: reason,
    })
    .eq('id', id);
  
  if (error) throw error;
};
```

### Restoring Stakeholders

```typescript
// Restore a previously removed stakeholder
const restoreStakeholder = async (id: string) => {
  const { error } = await supabase
    .from('account_contacts')
    .update({
      is_ignored: false,
      is_internal: false,
      ignored_reason: null,
    })
    .eq('id', id);
  
  if (error) throw error;
};
```

### Adding New Stakeholders

```typescript
// Manually add a new stakeholder
const addStakeholder = async (data: {
  accountId: string;
  opportunityId?: string;
  name: string;
  role?: string;
  email?: string;
  phone?: string;
}) => {
  const { data: contact, error } = await supabase
    .from('account_contacts')
    .insert({
      account_id: data.accountId,
      opportunity_id: data.opportunityId,
      name: data.name,
      role: data.role || null,
      email: data.email || null,
      phone: data.phone || null,
      is_ignored: false,
      is_internal: false,
      source: 'manual',
    })
    .select()
    .single();
  
  if (error) throw error;
  return contact;
};
```

---

## Integration Points

### 1. Transcript Analysis Pipeline

Stakeholder extraction is part of the transcript analysis flow:

```typescript
// In analyze-transcript edge function
const analyzeTranscript = async (transcript: string) => {
  // AI analyzes transcript and extracts people
  const result = await aiProvider.analyze(transcript, prompt);
  
  // Store extracted people as contacts
  for (const person of result.people) {
    await supabase.from('account_contacts').upsert({
      account_id: result.suggestedAccountId,
      name: person.name,
      role: person.role,
      email: person.email,
      phone: person.phone,
      influence_level: person.influenceLevel,
      sentiment: person.sentiment,
      champion_score: person.championScore,
      is_internal: person.isInternal,
      assessment_source: 'ai',
      last_assessed_at: new Date().toISOString(),
      source: 'transcript',
    });
  }
};
```

### 2. Account-Level View

The `AccountStakeholderMapTab` component displays all stakeholders for an account:

```typescript
// Component usage
<AccountStakeholderMapTab accountId={accountId} />

// Features:
// - Quadrant bubble chart visualization
// - Summary statistics (champions, blockers, avg score)
// - Detailed stakeholder list
// - Edit scores via sliders
// - Remove/restore stakeholders
// - Toggle ignored stakeholders visibility
```

### 3. Opportunity-Level View

The `OpportunityStakeholdersTab` shows stakeholders for a specific opportunity:

```typescript
// Component usage
<OpportunityStakeholdersTab 
  opportunityId={opportunityId} 
  accountId={accountId} 
/>

// Features:
// - Card-based contact display
// - Add new contacts manually
// - Remove contacts
// - Basic influence/sentiment badges
```

### 4. MAP Document Export

Stakeholders are included in the Mutual Action Plan export:

```typescript
// In MAPTeam component
<MAPTeam 
  teamMembers={internalTeamMembers} 
  contacts={externalContacts} 
/>

// Displays:
// - Internal team (your employees on the account)
// - External contacts (customer stakeholders)
```

---

## Replication Checklist

### Prerequisites

- [ ] Database with account/contact tables
- [ ] AI service integration (OpenAI, Gemini, etc.)
- [ ] React frontend with chart library support

### Database Setup

1. [ ] Create `account_contacts` table with scoring columns
2. [ ] Add indexes for efficient filtering
3. [ ] Enable RLS with appropriate policies
4. [ ] Add foreign key relationships

### AI Integration

1. [ ] Create transcript analysis edge function
2. [ ] Implement ExtractedPerson interface
3. [ ] Add stakeholder assessment prompts to AI
4. [ ] Handle internal vs external classification
5. [ ] Store extracted people with scores

### Frontend Components

1. [ ] Create bubble chart visualization component
2. [ ] Implement quadrant logic and coloring
3. [ ] Add stakeholder list with editing
4. [ ] Build score editing dialog with sliders
5. [ ] Add remove/restore functionality
6. [ ] Implement filtering (hide ignored/internal)

### State Management

1. [ ] Use React Query for data fetching
2. [ ] Implement optimistic updates
3. [ ] Handle cache invalidation
4. [ ] Add error handling with toast notifications

### User Experience

1. [ ] Show loading states
2. [ ] Display empty states with guidance
3. [ ] Add tooltips for bubble details
4. [ ] Include summary statistics
5. [ ] Allow toggling ignored stakeholders

---

## Component File Reference

| Component | File Path | Purpose |
|-----------|-----------|---------|
| Account Stakeholder Map | `src/components/views/AccountStakeholderMapTab.tsx` | Main visualization with bubble chart |
| Opportunity Stakeholders | `src/components/views/OpportunityStakeholdersTab.tsx` | Opportunity-level contact management |
| MAP Team Section | `src/components/map/sections/MAPTeam.tsx` | Export view for internal/external teams |
| Analyze Transcript | `supabase/functions/analyze-transcript/index.ts` | AI extraction logic |

---

## Best Practices

### Scoring Accuracy

- AI scores should be validated by users initially
- Track assessment_source to distinguish AI vs manual
- Use last_assessed_at to identify stale assessments
- Enable easy score adjustment via sliders

### Data Hygiene

- Automatically flag internal team members
- Provide easy "remove from analysis" workflow
- Allow restoration of removed stakeholders
- Deduplicate contacts across transcripts

### Visualization

- Use consistent colors across quadrants
- Size bubbles proportionally to champion score
- Show initials inside bubbles for identification
- Provide detailed tooltips on hover

### Performance

- Filter data server-side when possible
- Use useMemo for derived calculations
- Implement pagination for large stakeholder lists
- Cache query results with React Query

import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { ImpersonationBanner } from "@/components/ImpersonationBanner";

// Pages
import AuthPage from "./pages/AuthPage";
import NotFound from "./pages/NotFound";
import HomePage from "./pages/HomePage";
import AccountsPage from "./pages/AccountsPage";
import AccountDetailPage from "./pages/AccountDetailPage";
import NBAPage from "./pages/NBAPage";
import MomentumPage from "./pages/MomentumPage";
import FunctionalAreasPage from "./pages/FunctionalAreasPage";
import ReferenceArchitecturePage from "./pages/ReferenceArchitecturePage";
import TechnologyLibraryPage from "./pages/TechnologyLibraryPage";
import TranscriptsPage from "./pages/TranscriptsPage";
import CustomerStoriesPage from "./pages/CustomerStoriesPage";
// IntegrationsPage moved to Settings tab
import SettingsPage from "./pages/SettingsPage";
import PendingApprovalPage from "./pages/PendingApprovalPage";
import DetectionRulesPage from "./pages/DetectionRulesPage";
import ManagerDashboardPage from "./pages/ManagerDashboardPage";
import ProductAnalyticsPage from "./pages/ProductAnalyticsPage";
import ActivitySignalsPage from "./pages/ActivitySignalsPage";
import ActionConfirmedPage from "./pages/ActionConfirmedPage";
import ReadinessQuestionsPage from "./pages/ReadinessQuestionsPage";
import ValidationTasksPage from "./pages/ValidationTasksPage";
import OpportunityAlertRulesPage from "./pages/OpportunityAlertRulesPage";
import OpportunityPage from "./pages/OpportunityPage";
import CompetitiveScorecardPage from "./pages/CompetitiveScorecardPage";

// Global import modal context
import { ImportModalProvider } from "@/features/momentum/import/ImportModalContext";

const queryClient = new QueryClient();

function ProtectedRoute({ children, allowWithoutMfa = false }: { children: React.ReactNode; allowWithoutMfa?: boolean }) {
  const { user, loading, profileStatus, profileStatusLoading, tempPassword } = useAuth();

  if (loading || (user && profileStatusLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  // If user needs to change temp password, redirect to auth
  if (tempPassword) {
    return <Navigate to="/auth" replace />;
  }

  // If user is pending approval, redirect to pending page
  if (profileStatus === 'pending') {
    return <Navigate to="/pending-approval" replace />;
  }

  // If user is suspended, sign them out
  if (profileStatus === 'suspended') {
    return <Navigate to="/auth" replace />;
  }

  // If MFA is not enabled and this route requires MFA, redirect to settings
  // Google SSO users are exempt from MFA requirement
  if (!user.mfa_enabled && !allowWithoutMfa && user.auth_provider !== 'google') {
    return <Navigate to="/settings" replace />;
  }

  return (
    <ErrorBoundary title="Compass crashed">
      {children}
    </ErrorBoundary>
  );
}

function PendingRoute({ children }: { children: React.ReactNode }) {
  const { user, loading, profileStatus, profileStatusLoading } = useAuth();

  if (loading || (user && profileStatusLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  // If user is already active, redirect to main app
  if (profileStatus === 'active') {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

function AuthRoute({ children }: { children: React.ReactNode }) {
  const { user, loading, tempPassword, profileStatus } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Only redirect away from auth if user is fully authenticated and not needing password change
  if (user && !tempPassword) {
    // If pending, go to pending page
    if (profileStatus === 'pending') {
      return <Navigate to="/pending-approval" replace />;
    }
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/auth" element={<AuthRoute><AuthPage /></AuthRoute>} />
      <Route path="/action-confirmed" element={<ActionConfirmedPage />} />
      <Route path="/pending-approval" element={<PendingRoute><PendingApprovalPage /></PendingRoute>} />
      
      {/* Default redirect */}
      <Route path="/" element={<Navigate to="/home" replace />} />
      
      {/* Protected routes */}
      <Route path="/home" element={<ProtectedRoute><HomePage /></ProtectedRoute>} />
      <Route path="/accounts" element={<ProtectedRoute><AccountsPage /></ProtectedRoute>} />
      <Route path="/accounts/:accountId" element={<ProtectedRoute><AccountDetailPage /></ProtectedRoute>} />
      <Route path="/opportunities/:opportunityId" element={<ProtectedRoute><OpportunityPage /></ProtectedRoute>} />
      <Route path="/nba" element={<ProtectedRoute><NBAPage /></ProtectedRoute>} />
      <Route path="/momentum" element={<ProtectedRoute><MomentumPage /></ProtectedRoute>} />
      <Route path="/functional-areas" element={<ProtectedRoute><FunctionalAreasPage /></ProtectedRoute>} />
      <Route path="/reference-architecture" element={<ProtectedRoute><ReferenceArchitecturePage /></ProtectedRoute>} />
      <Route path="/technology-library" element={<ProtectedRoute><TechnologyLibraryPage /></ProtectedRoute>} />
      <Route path="/transcripts" element={<ProtectedRoute><TranscriptsPage /></ProtectedRoute>} />
      <Route path="/customer-stories" element={<ProtectedRoute><CustomerStoriesPage /></ProtectedRoute>} />
      <Route path="/integrations" element={<Navigate to="/settings" replace />} />
      <Route path="/settings" element={<ProtectedRoute allowWithoutMfa={true}><SettingsPage /></ProtectedRoute>} />
      <Route path="/detection-rules" element={<ProtectedRoute><DetectionRulesPage /></ProtectedRoute>} />
      <Route path="/manager" element={<ProtectedRoute><ManagerDashboardPage /></ProtectedRoute>} />
      <Route path="/product-analytics" element={<ProtectedRoute><ProductAnalyticsPage /></ProtectedRoute>} />
      <Route path="/activity-signals" element={<ProtectedRoute><ActivitySignalsPage /></ProtectedRoute>} />
      <Route path="/readiness-questions" element={<ProtectedRoute><ReadinessQuestionsPage /></ProtectedRoute>} />
      <Route path="/validation-tasks" element={<ProtectedRoute><ValidationTasksPage /></ProtectedRoute>} />
      <Route path="/alert-rules" element={<ProtectedRoute><OpportunityAlertRulesPage /></ProtectedRoute>} />
      <Route path="/competitive-scorecard" element={<ProtectedRoute><CompetitiveScorecardPage /></ProtectedRoute>} />
      
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <ImportModalProvider>
            <ImpersonationBanner />
            <AppRoutes />
          </ImportModalProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;

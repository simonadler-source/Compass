import { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useRejectedCompetitors, useRejectCompetitor, isCompetitorRejected } from '@/hooks/useRejectedCompetitors';

interface AccountCompetitorManagerProps {
  accountId: string;
  /** Competitors already mentioned in transcripts (AI-extracted) */
  mentionedCompetitors: string[];
}

interface ManualCompetitor {
  id: string;
  competitor_name: string;
}

export function AccountCompetitorManager({
  accountId,
  mentionedCompetitors,
}: AccountCompetitorManagerProps) {
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');

  // Fetch rejected competitors for this account (no opportunity)
  const { data: rejectedCompetitors } = useRejectedCompetitors(null, accountId);
  const rejectMutation = useRejectCompetitor();
  // Fetch manually added competitors for this account (no opportunity_id)
  const { data: manualCompetitors, isLoading: loadingManual } = useQuery({
    queryKey: ['account-manual-competitors', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('product_mentions')
        .select('id, product_name')
        .eq('account_id', accountId)
        .is('opportunity_id', null)
        .eq('mention_type', 'competitive')
        .eq('is_manual', true)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []).map((d: any) => ({
        id: d.id,
        competitor_name: d.product_name,
      })) as ManualCompetitor[];
    },
  });

  // Fetch all known competitors from the repository
  const { data: knownCompetitors } = useQuery({
    queryKey: ['known-competitors'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('technology_repository')
        .select('id, name')
        .eq('is_competitor', true)
        .order('name')
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as { id: string; name: string }[];
    },
    staleTime: 1000 * 60 * 5,
  });

  // Filter out rejected competitors from AI-mentioned ones
  const visibleMentionedCompetitors = useMemo(() => {
    if (!rejectedCompetitors) return mentionedCompetitors;
    return mentionedCompetitors.filter(
      comp => !isCompetitorRejected(rejectedCompetitors, comp)
    );
  }, [mentionedCompetitors, rejectedCompetitors]);

  // Combine all competitor names (AI-mentioned + manual)
  const allCompetitors = useMemo(() => {
    const manualNames = (manualCompetitors || []).map((c) => c.competitor_name.toLowerCase());
    const mentioned = visibleMentionedCompetitors.map((c) => c.toLowerCase());
    const combined = new Set([...mentioned, ...manualNames]);
    return Array.from(combined);
  }, [visibleMentionedCompetitors, manualCompetitors]);

  // Filter known competitors that aren't already added
  const availableCompetitors = useMemo(() => {
    const addedLower = new Set(allCompetitors);
    return (knownCompetitors || []).filter(
      (c) => !addedLower.has(c.name.toLowerCase()) && 
             c.name.toLowerCase().includes(search.toLowerCase())
    );
  }, [knownCompetitors, allCompetitors, search]);

  // Add competitor mutation
  const addMutation = useMutation({
    mutationFn: async (competitorName: string) => {
      const { error } = await gateway
        .from('product_mentions')
        .insert({
          account_id: accountId,
          opportunity_id: null,
          product_name: competitorName,
          mention_type: 'competitive',
          is_manual: true,
          speaker_type: 'unknown',
          confidence_score: 1.0,
        })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['account-manual-competitors', accountId] });
      toast.success('Competitor added');
      setSearch('');
    },
    onError: (err) => {
      toast.error('Failed to add competitor: ' + (err as Error).message);
    },
  });

  // Remove competitor mutation
  const removeMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway
        .from('product_mentions')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['account-manual-competitors', accountId] });
      toast.success('Competitor removed');
    },
    onError: (err) => {
      toast.error('Failed to remove competitor: ' + (err as Error).message);
    },
  });

  const isAdding = addMutation.isPending;
  const isRemoving = removeMutation.isPending;
  const isRejecting = rejectMutation.isPending;

  const handleReject = (competitorName: string) => {
    rejectMutation.mutate({
      accountId,
      competitorName,
    });
  };

  return (
    <div className="space-y-3">
      {/* Competitors mentioned (AI + manual) */}
      <div className="flex flex-wrap gap-2">
        {/* AI-mentioned competitors (rejectable) */}
        {visibleMentionedCompetitors.map((comp, i) => (
          <Badge
            key={`ai-${i}`}
            variant="outline"
            className={cn(
              "text-orange-500 border-orange-500/50 bg-orange-500/10 pr-1 gap-1",
              isRejecting && "opacity-50"
            )}
          >
            {comp}
            <button
              type="button"
              onClick={() => handleReject(comp)}
              disabled={isRejecting}
              className="ml-1 hover:bg-orange-500/20 rounded-full p-0.5"
              title="Reject this competitor"
            >
              <X className="w-3 h-3" />
            </button>
          </Badge>
        ))}

        {/* Manually added competitors (removable) */}
        {(manualCompetitors || [])
          .filter((mc) => !visibleMentionedCompetitors.some((m) => m.toLowerCase() === mc.competitor_name.toLowerCase()))
          .map((mc) => (
            <Badge
              key={mc.id}
              variant="outline"
              className={cn(
                "text-orange-500 border-orange-500/50 bg-orange-500/10 pr-1 gap-1",
                isRemoving && "opacity-50"
              )}
            >
              {mc.competitor_name}
              <button
                type="button"
                onClick={() => removeMutation.mutate(mc.id)}
                disabled={isRemoving}
                className="ml-1 hover:bg-orange-500/20 rounded-full p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            </Badge>
          ))}

        {/* Add button */}
        <Popover open={isOpen} onOpenChange={setIsOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              className="h-6 px-2 text-xs gap-1 text-orange-500 border-orange-500/30 hover:bg-orange-500/10"
            >
              <Plus className="w-3 h-3" />
              Add
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-64 p-0" align="start">
            <div className="p-2 border-b border-border">
              <Input
                placeholder="Search competitors..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="h-8"
                autoFocus
              />
            </div>
            <ScrollArea className="h-[200px]">
              <div className="p-1 space-y-0.5">
                {availableCompetitors.length === 0 && (
                  <p className="text-xs text-muted-foreground p-2 text-center">
                    {search ? 'No matching competitors' : 'All known competitors are already added'}
                  </p>
                )}
                {availableCompetitors.map((comp) => (
                  <Button
                    key={comp.id}
                    variant="ghost"
                    size="sm"
                    className="w-full justify-between h-8"
                    onClick={() => {
                      addMutation.mutate(comp.name);
                      setIsOpen(false);
                    }}
                    disabled={isAdding}
                  >
                    <span className="truncate">{comp.name}</span>
                    {isAdding ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <Plus className="w-3 h-3 text-primary" />
                    )}
                  </Button>
                ))}
              </div>
            </ScrollArea>
            {search && !availableCompetitors.some((c) => c.name.toLowerCase() === search.toLowerCase()) && (
              <div className="p-2 border-t border-border">
                <Button
                  variant="secondary"
                  size="sm"
                  className="w-full text-xs"
                  onClick={() => {
                    addMutation.mutate(search.trim());
                    setIsOpen(false);
                  }}
                  disabled={isAdding || !search.trim()}
                >
                  <Plus className="w-3 h-3 mr-1" />
                  Add "{search}" as competitor
                </Button>
              </div>
            )}
          </PopoverContent>
        </Popover>
      </div>

      {loadingManual && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
    </div>
  );
}

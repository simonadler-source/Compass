import { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Building2, TrendingUp, Users, Target, ArrowRight, DollarSign } from 'lucide-react';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { cn } from '@/lib/utils';

interface AccountHoverCardProps {
  accountId: string;
  accountName: string;
  children: ReactNode;
  side?: 'top' | 'bottom' | 'left' | 'right';
  align?: 'start' | 'center' | 'end';
}

export function AccountHoverCard({ 
  accountId, 
  accountName, 
  children,
  side = 'bottom',
  align = 'start'
}: AccountHoverCardProps) {
  // Fetch account summary on hover
  const { data: accountData, isLoading } = useQuery({
    queryKey: ['account-hover-summary', accountId],
    queryFn: async () => {
      const [accountResult, oppsResult, contactsResult] = await Promise.all([
        gateway.from('accounts')
          .select('id, name, industry, arr, stage, engagement_score, momentum_score')
          .eq('id', accountId)
          .maybeSingle()
          .execute(),
        gateway.from('opportunities')
          .select('id, name, value, sales_stage')
          .eq('account_id', accountId)
          .neq('sales_stage', 'Closed Lost')
          .neq('sales_stage', 'Closed Won')
          .execute(),
        gateway.from('account_contacts')
          .select('id')
          .eq('account_id', accountId)
          .eq('is_ignored', false)
          .execute()
      ]);

      return {
        account: accountResult.data,
        openOpportunities: oppsResult.data?.length || 0,
        totalPipeline: oppsResult.data?.reduce((sum, o) => sum + (o.value || 0), 0) || 0,
        stakeholderCount: contactsResult.data?.length || 0
      };
    },
    staleTime: 60000, // Cache for 1 minute
    enabled: !!accountId
  });

  const formatCurrency = (value: number) => {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value}`;
  };

  const stageColors: Record<string, string> = {
    prospect: 'text-muted-foreground',
    discovery: 'text-blue-600',
    evaluation: 'text-purple-600',
    negotiation: 'text-amber-600',
    customer: 'text-green-600'
  };

  return (
    <HoverCard openDelay={300} closeDelay={100}>
      <HoverCardTrigger asChild>
        {children}
      </HoverCardTrigger>
      <HoverCardContent 
        side={side}
        align={align}
        className="w-80 p-0"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4">
          {/* Header */}
          <div className="flex items-start gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Building2 className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-foreground truncate">{accountName}</h4>
              {accountData?.account?.industry && (
                <p className="text-xs text-muted-foreground">{accountData.account.industry}</p>
              )}
              {accountData?.account?.stage && (
                <Badge variant="outline" className={cn("text-xs mt-1 capitalize", stageColors[accountData.account.stage])}>
                  {accountData.account.stage}
                </Badge>
              )}
            </div>
          </div>

          {/* Stats Grid */}
          {isLoading ? (
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="h-12 bg-muted/30 rounded-lg animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {/* ARR */}
              {accountData?.account?.arr && accountData.account.arr > 0 && (
                <div className="bg-muted/30 rounded-lg p-2">
                  <div className="flex items-center gap-1.5 text-muted-foreground mb-0.5">
                    <DollarSign className="w-3 h-3" />
                    <span className="text-xs">ARR</span>
                  </div>
                  <p className="font-semibold text-sm">{formatCurrency(accountData.account.arr)}</p>
                </div>
              )}

              {/* Pipeline */}
              {accountData && accountData.totalPipeline > 0 && (
                <div className="bg-muted/30 rounded-lg p-2">
                  <div className="flex items-center gap-1.5 text-muted-foreground mb-0.5">
                    <TrendingUp className="w-3 h-3" />
                    <span className="text-xs">Pipeline</span>
                  </div>
                  <p className="font-semibold text-sm">{formatCurrency(accountData.totalPipeline)}</p>
                </div>
              )}

              {/* Open Opportunities */}
              <div className="bg-muted/30 rounded-lg p-2">
                <div className="flex items-center gap-1.5 text-muted-foreground mb-0.5">
                  <Target className="w-3 h-3" />
                  <span className="text-xs">Open Opps</span>
                </div>
                <p className="font-semibold text-sm">{accountData?.openOpportunities || 0}</p>
              </div>

              {/* Stakeholders */}
              <div className="bg-muted/30 rounded-lg p-2">
                <div className="flex items-center gap-1.5 text-muted-foreground mb-0.5">
                  <Users className="w-3 h-3" />
                  <span className="text-xs">Stakeholders</span>
                </div>
                <p className="font-semibold text-sm">{accountData?.stakeholderCount || 0}</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t px-4 py-2 bg-muted/20">
          <Link to={`/accounts/${accountId}`}>
            <Button variant="ghost" size="sm" className="w-full justify-between text-xs h-7">
              View Account Details
              <ArrowRight className="w-3 h-3" />
            </Button>
          </Link>
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}

import { Account, Technology, LAYER_CONFIG, LayerType } from '@/types/architecture';
import { cn } from '@/lib/utils';
import { forwardRef } from 'react';

interface AccountPlanDocumentProps {
  account: Account;
}

const priorityLabels = {
  critical: 'Critical Priority',
  high: 'High Priority',
  medium: 'Medium Priority',
  low: 'Low Priority',
};

const layerStyles: Record<LayerType, { bg: string; border: string; text: string }> = {
  host: { bg: '#1a3636', border: '#10b981', text: '#34d399' },
  build: { bg: '#2d2640', border: '#8b5cf6', text: '#a78bfa' },
  adopt: { bg: '#362a1a', border: '#f59e0b', text: '#fbbf24' },
  growth: { bg: '#1a2d3d', border: '#3b82f6', text: '#60a5fa' },
  ops: { bg: '#3d1a2e', border: '#ec4899', text: '#f472b6' },
};

export const AccountPlanDocument = forwardRef<HTMLDivElement, AccountPlanDocumentProps>(
  ({ account }, ref) => {
    const layers: LayerType[] = ['host', 'build', 'adopt', 'growth', 'ops'];
    
    const getTechsByPriority = (priority: string) => 
      account.technologies.filter(t => t.priority === priority);
    
    const criticalTechs = getTechsByPriority('critical');
    const highTechs = getTechsByPriority('high');
    
    const stageLabels = {
      discovery: 'Discovery',
      evaluation: 'Evaluation', 
      proposal: 'Proposal',
      closing: 'Closing',
      customer: 'Customer',
    };

    return (
      <div 
        ref={ref}
        className="bg-[#0f1419] text-white p-12 w-[1200px] min-h-[1600px]"
        style={{ fontFamily: 'Inter, system-ui, sans-serif' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-12 pb-8 border-b border-gray-700">
          <div>
            <div className="text-sm text-cyan-400 font-medium tracking-widest uppercase mb-2">
              Technical Account Plan
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
              {account.name}
            </h1>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-400">Generated</div>
            <div className="text-lg font-medium">{new Date().toLocaleDateString('en-US', { 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}</div>
          </div>
        </div>

        {/* Account Summary */}
        <div className="grid grid-cols-4 gap-6 mb-12">
          <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
            <div className="text-sm text-gray-400 mb-1">Industry</div>
            <div className="text-xl font-semibold">{account.industry || 'Not specified'}</div>
          </div>
          <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
            <div className="text-sm text-gray-400 mb-1">Stage</div>
            <div className="text-xl font-semibold capitalize">
              {account.stage ? stageLabels[account.stage] : 'Not set'}
            </div>
          </div>
          <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
            <div className="text-sm text-gray-400 mb-1">Primary Contact</div>
            <div className="text-xl font-semibold">{account.primaryContact || 'Not set'}</div>
          </div>
          <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
            <div className="text-sm text-gray-400 mb-1">Technologies Mapped</div>
            <div className="text-xl font-semibold">{account.technologies.length}</div>
          </div>
        </div>

        {/* Architecture Overview */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
            <span className="w-8 h-1 bg-gradient-to-r from-cyan-400 to-purple-500 rounded"></span>
            Technical Architecture
          </h2>
          
          <div className="space-y-4">
            {layers.map(layer => {
              const techs = account.technologies.filter(t => t.layer === layer);
              const config = LAYER_CONFIG[layer];
              const style = layerStyles[layer];
              
              return (
                <div 
                  key={layer}
                  className="rounded-xl p-6 border"
                  style={{ 
                    backgroundColor: style.bg,
                    borderColor: `${style.border}50`,
                  }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold" style={{ color: style.text }}>
                        {config.label}
                      </h3>
                      <p className="text-sm text-gray-400">{config.description}</p>
                    </div>
                    <span className="text-sm text-gray-400 px-3 py-1 rounded-full bg-black/30">
                      {techs.length} system{techs.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  
                  {techs.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {techs.map(tech => (
                        <div 
                          key={tech.id}
                          className="px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ 
                            backgroundColor: `${style.border}30`,
                            color: style.text,
                            border: `1px solid ${style.border}50`,
                          }}
                        >
                          {tech.name}
                          {tech.version && <span className="ml-1 opacity-60">v{tech.version}</span>}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 italic text-sm">No systems discovered in this layer</p>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Priority Analysis */}
        {(criticalTechs.length > 0 || highTechs.length > 0) && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <span className="w-8 h-1 bg-gradient-to-r from-orange-400 to-red-500 rounded"></span>
              Priority Focus Areas
            </h2>
            
            <div className="grid grid-cols-2 gap-6">
              {criticalTechs.length > 0 && (
                <div className="bg-red-950/30 rounded-xl p-6 border border-red-500/30">
                  <h3 className="text-lg font-semibold text-red-400 mb-4">Critical Priority</h3>
                  <div className="space-y-3">
                    {criticalTechs.map(tech => (
                      <div key={tech.id} className="flex items-center justify-between">
                        <span className="font-medium">{tech.name}</span>
                        {tech.dataValue && (
                          <span className="text-sm text-gray-400">Value: {tech.dataValue}/10</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {highTechs.length > 0 && (
                <div className="bg-orange-950/30 rounded-xl p-6 border border-orange-500/30">
                  <h3 className="text-lg font-semibold text-orange-400 mb-4">High Priority</h3>
                  <div className="space-y-3">
                    {highTechs.map(tech => (
                      <div key={tech.id} className="flex items-center justify-between">
                        <span className="font-medium">{tech.name}</span>
                        {tech.dataValue && (
                          <span className="text-sm text-gray-400">Value: {tech.dataValue}/10</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Technology Details */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
            <span className="w-8 h-1 bg-gradient-to-r from-green-400 to-blue-500 rounded"></span>
            Technology Deep Dive
          </h2>
          
          <div className="grid grid-cols-2 gap-4">
            {account.technologies.map(tech => (
              <TechnologyDetailCard key={tech.id} technology={tech} />
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 pt-8 border-t border-gray-700 flex items-center justify-between text-sm text-gray-400">
          <div>Generated by Pendo Compass</div>
          <div>Last Updated: {account.updatedAt.toLocaleDateString()}</div>
        </div>
      </div>
    );
  }
);

AccountPlanDocument.displayName = 'AccountPlanDocument';

function TechnologyDetailCard({ technology }: { technology: Technology }) {
  const style = layerStyles[technology.layer];
  const hasDetails = technology.owner || technology.version || technology.securityModel || technology.issues;
  
  if (!hasDetails) {
    return null;
  }

  return (
    <div 
      className="rounded-lg p-4 border"
      style={{ 
        backgroundColor: '#1a1f2e',
        borderColor: `${style.border}30`,
      }}
    >
      <div className="flex items-center gap-2 mb-3">
        <div 
          className="w-2 h-2 rounded-full"
          style={{ backgroundColor: style.border }}
        />
        <h4 className="font-semibold">{technology.name}</h4>
        <span className="text-xs text-gray-500 px-2 py-0.5 rounded bg-gray-800">
          {technology.category}
        </span>
      </div>
      
      <div className="grid grid-cols-2 gap-3 text-sm">
        {technology.owner && (
          <div>
            <span className="text-gray-400">Owner:</span>{' '}
            <span className="text-gray-200">{technology.owner}</span>
          </div>
        )}
        {technology.version && (
          <div>
            <span className="text-gray-400">Version:</span>{' '}
            <span className="text-gray-200">{technology.version}</span>
          </div>
        )}
        {technology.securityModel && (
          <div>
            <span className="text-gray-400">Security:</span>{' '}
            <span className="text-gray-200">{technology.securityModel}</span>
          </div>
        )}
        {technology.status && (
          <div>
            <span className="text-gray-400">Status:</span>{' '}
            <span className={cn(
              "capitalize",
              technology.status === 'active' && "text-green-400",
              technology.status === 'planned' && "text-blue-400",
              technology.status === 'deprecated' && "text-red-400",
            )}>
              {technology.status}
            </span>
          </div>
        )}
      </div>
      
      {technology.issues && (
        <div className="mt-3 text-sm">
          <span className="text-gray-400">Known Issues:</span>{' '}
          <span className="text-orange-300">{technology.issues}</span>
        </div>
      )}
    </div>
  );
}

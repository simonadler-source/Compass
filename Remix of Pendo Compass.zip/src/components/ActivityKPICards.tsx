import { 
  Play, RotateCcw, Search, Target, ClipboardCheck, 
  Presentation, Users, FlaskConical, MessageCircle, 
  GraduationCap, DollarSign, Code, Circle
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const iconMap: Record<string, React.ElementType> = {
  'play': Play,
  'rotate-ccw': RotateCcw,
  'search': Search,
  'target': Target,
  'clipboard-check': ClipboardCheck,
  'presentation': Presentation,
  'users': Users,
  'flask-conical': FlaskConical,
  'message-circle': MessageCircle,
  'graduation-cap': GraduationCap,
  'dollar-sign': DollarSign,
  'code': Code,
  'circle': Circle,
};

interface ActivityKPICardsProps {
  byType: Record<string, { count: number; label: string; icon: string; color: string }>;
  totalActivities: number;
  compact?: boolean;
}

export function ActivityKPICards({ byType, totalActivities, compact = false }: ActivityKPICardsProps) {
  const sortedTypes = Object.entries(byType)
    .sort((a, b) => b[1].count - a[1].count);

  if (compact) {
    return (
      <div className="flex flex-wrap gap-2">
        {sortedTypes.map(([name, data]) => {
          const IconComponent = iconMap[data.icon] || Circle;
          return (
            <div
              key={name}
              className="flex items-center gap-1.5 px-2 py-1 rounded-md text-xs"
              style={{ backgroundColor: `${data.color}20` }}
            >
              <IconComponent className="w-3 h-3" style={{ color: data.color }} />
              <span className="font-medium">{data.count}</span>
              <span className="text-muted-foreground">{data.label}</span>
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
      {sortedTypes.map(([name, data]) => {
        const IconComponent = iconMap[data.icon] || Circle;
        return (
          <Card key={name} className="overflow-hidden">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <div 
                  className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${data.color}20` }}
                >
                  <IconComponent className="w-4 h-4" style={{ color: data.color }} />
                </div>
                <div className="min-w-0">
                  <p className="text-xl font-bold text-foreground">{data.count}</p>
                  <p className="text-xs text-muted-foreground truncate">{data.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
      
      {/* Total card */}
      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 bg-primary/20">
              <Target className="w-4 h-4 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="text-xl font-bold text-foreground">{totalActivities}</p>
              <p className="text-xs text-muted-foreground">Total Activities</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { useMemo } from 'react';
import { format, differenceInDays, parseISO, formatDistanceToNow } from 'date-fns';
import { 
  Play, RotateCcw, Search, Target, ClipboardCheck, 
  Presentation, Users, FlaskConical, MessageCircle, 
  GraduationCap, DollarSign, Code, Circle, ExternalLink,
  Mail, MailCheck, MailPlus, MailOpen, MailQuestion, Calendar,
  FileText, Scale, Shield, Wrench, Workflow, Layers, Zap
} from 'lucide-react';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';
import type { OpportunityActivity } from '@/hooks/useOpportunityActivities';

// Signal icons mapping - matches CEP Timeline
const SIGNAL_ICONS: Record<string, React.ElementType> = {
  demo: Target,
  reverse_demo: Presentation,
  evaluation: FlaskConical,
  legal: Scale,
  security: Shield,
  technical_discovery: Wrench,
  process_discovery: Workflow,
  nda: FileText,
  pricing: DollarSign,
  dry_run: Play,
  technical_win: Target,
  technical_loss: Target,
};

// Signal colors - matches CEP Timeline style
const SIGNAL_COLORS: Record<string, string> = {
  demo: 'text-chart-3 bg-chart-3/20 border-chart-3/40',
  reverse_demo: 'text-chart-2 bg-chart-2/20 border-chart-2/40',
  evaluation: 'text-chart-1 bg-chart-1/20 border-chart-1/40',
  legal: 'text-indigo-500 bg-indigo-500/20 border-indigo-500/40',
  security: 'text-cyan-500 bg-cyan-500/20 border-cyan-500/40',
  technical_discovery: 'text-teal-500 bg-teal-500/20 border-teal-500/40',
  process_discovery: 'text-amber-500 bg-amber-500/20 border-amber-500/40',
  nda: 'text-violet-500 bg-violet-500/20 border-violet-500/40',
  pricing: 'text-rose-500 bg-rose-500/20 border-rose-500/40',
  dry_run: 'text-lime-600 bg-lime-600/20 border-lime-600/40',
  technical_win: 'text-green-500 bg-green-500/20 border-green-500/40',
  technical_loss: 'text-red-500 bg-red-500/20 border-red-500/40',
};

const activityIconMap: Record<string, React.ElementType> = {
  'play': Play,
  'rotate-ccw': RotateCcw,
  'search': Search,
  'target': Target,
  'clipboard-check': ClipboardCheck,
  'presentation': Presentation,
  'users': Users,
  'flask-conical': FlaskConical,
  'message-circle': MessageCircle,
  'graduation-cap': GraduationCap,
  'dollar-sign': DollarSign,
  'code': Code,
  'circle': Circle,
  'mail': Mail,
  'mail-check': MailCheck,
  'mail-plus': MailPlus,
  'mail-open': MailOpen,
  'mail-question': MailQuestion,
  'calendar': Calendar,
};

export interface TimelineSignal {
  id: string;
  ruleId: string;
  ruleName: string;
  ruleKey: string;
  confidenceScore: number;
  matchedPhrases: string[];
  detectedAt: string;
  transcriptId?: string;
  speakerType?: string;
  speakerName?: string;
}

interface ActivityTimelineProps {
  activities: OpportunityActivity[];
  signals?: TimelineSignal[];
  showOpportunityName?: boolean;
  compact?: boolean;
}

function getSentimentColor(score: number | null): string {
  if (score === null) return 'text-muted-foreground';
  if (score >= 70) return 'text-green-600';
  if (score >= 40) return 'text-yellow-600';
  return 'text-red-600';
}

function getSentimentLabel(score: number | null): string {
  if (score === null) return 'Unknown';
  if (score >= 70) return 'Positive';
  if (score >= 40) return 'Neutral';
  return 'Negative';
}

// Signal dot component for timeline
function SignalDot({ 
  signal, 
  position, 
  compact,
  clusteredSignals,
}: { 
  signal: TimelineSignal; 
  position: number;
  compact: boolean;
  clusteredSignals?: TimelineSignal[];
}) {
  const signalKey = signal.ruleKey.toLowerCase().replace(/\s+/g, '_');
  const Icon = SIGNAL_ICONS[signalKey] || Zap;
  const colorClass = SIGNAL_COLORS[signalKey] || 'text-primary bg-primary/20 border-primary/40';
  const isCluster = clusteredSignals && clusteredSignals.length > 1;
  
  const sizeClass = compact ? "w-5 h-5" : "w-6 h-6";
  const iconSizeClass = compact ? "w-2.5 h-2.5" : "w-3 h-3";

  if (isCluster) {
    // Render cluster indicator
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div
              className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-20"
              style={{ left: `${Math.max(4, Math.min(96, position))}%` }}
            >
              <div className="relative">
                <div className={cn(
                  "rounded-full flex items-center justify-center cursor-pointer border transition-all hover:scale-125",
                  sizeClass,
                  "text-primary bg-primary/20 border-primary/40"
                )}>
                  <Layers className={iconSizeClass} />
                </div>
                <div className="absolute -top-1 -right-1 min-w-[14px] h-[14px] rounded-full bg-primary text-primary-foreground text-[9px] font-bold flex items-center justify-center px-0.5">
                  {clusteredSignals.length}
                </div>
              </div>
            </div>
          </TooltipTrigger>
          <TooltipContent side="top" className="max-w-sm z-50">
            <div className="space-y-2">
              <p className="font-medium">{clusteredSignals.length} Signals Detected</p>
              <p className="text-xs text-muted-foreground">
                {format(parseISO(signal.detectedAt), 'MMM d, yyyy')}
              </p>
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {clusteredSignals.map((s, i) => {
                  const sKey = s.ruleKey.toLowerCase().replace(/\s+/g, '_');
                  const SIcon = SIGNAL_ICONS[sKey] || Zap;
                  const sColor = SIGNAL_COLORS[sKey] || 'text-primary bg-primary/20 border-primary/40';
                  return (
                    <div key={s.id} className="flex items-center gap-2 text-xs">
                      <div className={cn("w-4 h-4 rounded-full flex items-center justify-center border", sColor)}>
                        <SIcon className="w-2 h-2" />
                      </div>
                      <span>{s.ruleName}</span>
                      <span className="text-muted-foreground ml-auto">
                        {Math.round(s.confidenceScore * 100)}%
                      </span>
                    </div>
                  );
                })}
              </div>
              {clusteredSignals[0]?.transcriptId && (
                <Link 
                  to={`/transcripts?id=${clusteredSignals[0].transcriptId}`}
                  className="text-xs text-primary hover:underline flex items-center gap-1 pt-1"
                >
                  <ExternalLink className="w-3 h-3" />
                  View Transcript
                </Link>
              )}
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  // Single signal dot
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div
            className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-20"
            style={{ left: `${Math.max(4, Math.min(96, position))}%` }}
          >
            <div className={cn(
              "rounded-full flex items-center justify-center cursor-pointer border transition-all hover:scale-125",
              sizeClass,
              colorClass
            )}>
              <Icon className={iconSizeClass} />
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-sm z-50">
          <div className="space-y-2">
            <p className="font-medium">{signal.ruleName}</p>
            <div className="flex items-center gap-2 text-xs">
              <Badge variant="outline" className="text-xs">
                {Math.round(signal.confidenceScore * 100)}% confidence
              </Badge>
            </div>
            {signal.speakerName && (
              <p className="text-xs text-muted-foreground">
                Speaker: {signal.speakerName}
              </p>
            )}
            {signal.matchedPhrases.length > 0 && (
              <p className="text-xs italic">
                "{signal.matchedPhrases.slice(0, 2).join('", "')}"
                {signal.matchedPhrases.length > 2 && ` +${signal.matchedPhrases.length - 2} more`}
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              {formatDistanceToNow(parseISO(signal.detectedAt), { addSuffix: true })}
            </p>
            {signal.transcriptId && (
              <Link 
                to={`/transcripts?id=${signal.transcriptId}`}
                className="text-xs text-primary hover:underline flex items-center gap-1"
              >
                <ExternalLink className="w-3 h-3" />
                View Transcript
              </Link>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export function ActivityTimeline({ 
  activities, 
  signals = [],
  showOpportunityName = false, 
  compact = false 
}: ActivityTimelineProps) {
  const sortedActivities = useMemo(() => {
    return [...activities].sort((a, b) => 
      new Date(a.activity_date).getTime() - new Date(b.activity_date).getTime()
    );
  }, [activities]);

  // Combine activities and signals to determine timeline range
  const timelineRange = useMemo(() => {
    const allDates: number[] = [];
    
    sortedActivities.forEach(a => {
      allDates.push(new Date(a.activity_date).getTime());
    });
    
    signals.forEach(s => {
      allDates.push(new Date(s.detectedAt).getTime());
    });
    
    if (allDates.length === 0) {
      return { startTs: Date.now(), endTs: Date.now(), spanMs: 1 };
    }
    
    const startTs = Math.min(...allDates);
    const endTs = Math.max(...allDates);
    const spanMs = Math.max(endTs - startTs, 1);
    
    return { startTs, endTs, spanMs };
  }, [sortedActivities, signals]);

  // Calculate activity positions
  const activityPositions = useMemo(() => {
    const { startTs, spanMs } = timelineRange;
    
    const pos = sortedActivities.map(activity => {
      const ts = new Date(activity.activity_date).getTime();
      const position = ((ts - startTs) / spanMs) * 100;
      return { activity, position };
    });

    // Ensure minimum spacing between activities
    const minSpacing = 8;
    for (let i = 1; i < pos.length; i++) {
      if (pos[i].position - pos[i - 1].position < minSpacing) {
        pos[i].position = pos[i - 1].position + minSpacing;
      }
    }

    // Normalize if exceeds 100
    const maxPos = pos[pos.length - 1]?.position || 0;
    if (maxPos > 90) {
      const scale = 90 / maxPos;
      pos.forEach(p => (p.position *= scale));
    }

    return pos;
  }, [sortedActivities, timelineRange]);

  // Calculate signal positions with clustering
  const signalPositions = useMemo(() => {
    if (signals.length === 0) return [];
    
    const { startTs, spanMs } = timelineRange;
    
    // Calculate raw positions
    const rawPositions = signals.map(signal => {
      const ts = new Date(signal.detectedAt).getTime();
      const position = ((ts - startTs) / spanMs) * 100;
      return { signal, position: Math.max(2, Math.min(98, position)) };
    });

    // Group signals that are close together (within 5% of timeline)
    const clusterThreshold = 5;
    const clusters: { signals: TimelineSignal[]; position: number }[] = [];
    
    // Sort by position
    const sorted = [...rawPositions].sort((a, b) => a.position - b.position);
    
    sorted.forEach(({ signal, position }) => {
      // Find existing cluster nearby
      const nearbyCluster = clusters.find(c => Math.abs(c.position - position) < clusterThreshold);
      
      if (nearbyCluster) {
        nearbyCluster.signals.push(signal);
        // Update cluster position to average
        nearbyCluster.position = nearbyCluster.signals.reduce((sum, s) => {
          const ts = new Date(s.detectedAt).getTime();
          return sum + ((ts - startTs) / spanMs) * 100;
        }, 0) / nearbyCluster.signals.length;
      } else {
        clusters.push({ signals: [signal], position });
      }
    });

    return clusters;
  }, [signals, timelineRange]);

  const hasContent = activities.length > 0 || signals.length > 0;

  if (!hasContent) {
    return (
      <div className="flex items-center justify-center h-12 text-sm text-muted-foreground">
        No activities or signals recorded
      </div>
    );
  }

  // Get date range for labels
  const { startTs, endTs } = timelineRange;

  return (
    <div className={cn("relative", compact ? "h-10" : "h-16")}>
      {/* Timeline bar */}
      <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-1 bg-muted rounded-full" />
      
      {/* Signal markers (rendered first, below activities) */}
      {signalPositions.map((cluster, idx) => (
        <SignalDot
          key={`cluster-${idx}`}
          signal={cluster.signals[0]}
          position={cluster.position}
          compact={compact}
          clusteredSignals={cluster.signals.length > 1 ? cluster.signals : undefined}
        />
      ))}
      
      {/* Activity markers */}
      {activityPositions.map(({ activity, position }) => {
        const activityType = activity.activity_type;
        const IconComponent = activityIconMap[activityType?.icon || 'circle'] || Circle;
        const color = activityType?.color || '#6366f1';
        const isMinor = (activityType as any)?.is_minor === true;

        // Smaller size for minor activities (emails)
        const sizeClass = isMinor 
          ? (compact ? "w-4 h-4" : "w-5 h-5") 
          : (compact ? "w-6 h-6" : "w-8 h-8");
        const iconSizeClass = isMinor 
          ? (compact ? "w-2 h-2" : "w-2.5 h-2.5") 
          : (compact ? "w-3 h-3" : "w-4 h-4");

        return (
          <HoverCard key={activity.id} openDelay={100} closeDelay={100}>
            <HoverCardTrigger asChild>
              <button
                className={cn(
                  "absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-10",
                  "rounded-full flex items-center justify-center transition-transform hover:scale-125",
                  sizeClass,
                  isMinor && "opacity-80"
                )}
                style={{ 
                  left: `${Math.max(4, Math.min(96, position))}%`,
                  backgroundColor: color,
                }}
              >
                <IconComponent className={cn("text-white", iconSizeClass)} />
              </button>
            </HoverCardTrigger>
            <HoverCardContent className="w-80" side="top">
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-semibold text-foreground">
                        {activity.title || activityType?.label || 'Activity'}
                      </h4>
                    </div>
                    <div className="flex items-center gap-1.5 mt-1">
                      <Badge 
                        variant="outline" 
                        className="text-xs text-amber-600 border-amber-500/50 bg-amber-500/10"
                      >
                        {activityType?.label || 'Activity'}
                      </Badge>
                      <Badge 
                        variant="outline" 
                        className={cn("text-xs shrink-0", getSentimentColor(activity.sentiment_score))}
                      >
                        {getSentimentLabel(activity.sentiment_score)}
                      </Badge>
                    </div>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground">
                  {format(parseISO(activity.activity_date), 'MMM d, yyyy p')}
                </div>

                {showOpportunityName && (activity as any).opportunity?.name && (
                  <div className="text-xs text-muted-foreground">
                    Opportunity: {(activity as any).opportunity.name}
                  </div>
                )}

                {activity.sentiment_score !== null && (
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-muted-foreground">Sentiment Score:</span>
                    <span className={cn("font-medium", getSentimentColor(activity.sentiment_score))}>
                      {activity.sentiment_score}%
                    </span>
                  </div>
                )}

                {(activity.ae_email || activity.se_email) && (
                  <div className="flex flex-wrap gap-2 text-xs">
                    {activity.ae_email && (
                      <span className="text-muted-foreground">
                        AE: {activity.ae_email.split('@')[0]}
                      </span>
                    )}
                    {activity.se_email && (
                      <span className="text-muted-foreground">
                        SE: {activity.se_email.split('@')[0]}
                      </span>
                    )}
                  </div>
                )}

                {activity.transcript_id && (
                  <Link 
                    to={`/transcripts?id=${activity.transcript_id}`}
                    className="flex items-center gap-1 text-xs text-primary hover:underline mt-2"
                  >
                    <ExternalLink className="w-3 h-3" />
                    View Transcript
                  </Link>
                )}
              </div>
            </HoverCardContent>
          </HoverCard>
        );
      })}

      {/* Date labels */}
      {!compact && hasContent && (
        <>
          <div className="absolute left-0 -bottom-5 text-xs text-muted-foreground">
            {format(new Date(startTs), 'MMM d')}
          </div>
          <div className="absolute right-0 -bottom-5 text-xs text-muted-foreground">
            {format(new Date(endTs), 'MMM d')}
          </div>
        </>
      )}
    </div>
  );
}

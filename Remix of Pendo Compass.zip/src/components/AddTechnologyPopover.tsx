import { useState, useMemo } from 'react';
import { Plus, Search, Loader2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useTechnologyRepository, useGetOrCreateTechnology, TechnologyRepoItem } from '@/hooks/useTechnologyRepository';
import { cn } from '@/lib/utils';

interface AddTechnologyPopoverProps {
  onSelectTechnology: (tech: { name: string; repositoryTechId?: string; layer?: string; category?: string }) => void;
  existingTechNames: string[];
  disabled?: boolean;
}

export function AddTechnologyPopover({ onSelectTechnology, existingTechNames, disabled }: AddTechnologyPopoverProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const { data: allTechnologies, isLoading } = useTechnologyRepository(undefined, 'all', 'vendor');
  const getOrCreate = useGetOrCreateTechnology();
  
  // Filter technologies based on search
  const filteredTechnologies = useMemo(() => {
    if (!allTechnologies) return [];
    const query = searchQuery.toLowerCase();
    return allTechnologies
      .filter(tech => {
        // Exclude already existing ones
        if (existingTechNames.some(name => name.toLowerCase() === tech.name.toLowerCase())) {
          return false;
        }
        // Search by name or aliases
        if (tech.name.toLowerCase().includes(query)) return true;
        if (tech.aliases?.some(alias => alias.toLowerCase().includes(query))) return true;
        if (tech.functional_area?.toLowerCase().includes(query)) return true;
        return false;
      })
      .slice(0, 15); // Limit results
  }, [allTechnologies, searchQuery, existingTechNames]);
  
  // Check if search matches exactly any tech (for "create new" logic)
  const exactMatch = useMemo(() => {
    if (!searchQuery.trim()) return null;
    return allTechnologies?.find(t => t.name.toLowerCase() === searchQuery.toLowerCase().trim());
  }, [allTechnologies, searchQuery]);
  
  const handleSelect = (tech: TechnologyRepoItem) => {
    onSelectTechnology({
      name: tech.name,
      repositoryTechId: tech.id,
      layer: tech.layer,
      category: tech.functional_area,
    });
    setSearchQuery('');
    setIsOpen(false);
  };
  
  const handleCreateNew = async () => {
    if (!searchQuery.trim()) return;
    try {
      const newTech = await getOrCreate.mutateAsync({ name: searchQuery.trim() });
      onSelectTechnology({
        name: newTech.name,
        repositoryTechId: newTech.id,
        layer: newTech.layer,
        category: newTech.functional_area,
      });
      setSearchQuery('');
      setIsOpen(false);
    } catch (error) {
      console.error('Failed to create technology:', error);
    }
  };
  
  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          disabled={disabled}
          className="h-7 px-2 text-xs gap-1 text-muted-foreground hover:text-primary"
        >
          <Plus className="w-3 h-3" />
          Add
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="start" sideOffset={5}>
        <div className="p-3 border-b border-border">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search or add new technology..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 h-9"
              autoFocus
            />
          </div>
        </div>
        
        <ScrollArea className="h-[280px]">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="p-2 space-y-1">
              {/* Show filtered results */}
              {filteredTechnologies.map(tech => (
                <button
                  key={tech.id}
                  onClick={() => handleSelect(tech)}
                  className={cn(
                    "w-full flex items-center justify-between gap-2 px-3 py-2 rounded-md text-sm text-left",
                    "hover:bg-accent transition-colors"
                  )}
                >
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{tech.name}</div>
                    {tech.functional_area && (
                      <div className="text-xs text-muted-foreground truncate">
                        {tech.functional_area}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    {tech.status === 'draft' && (
                      <Badge variant="outline" className="text-[10px] px-1 py-0">
                        Draft
                      </Badge>
                    )}
                    <Plus className="w-4 h-4 text-primary" />
                  </div>
                </button>
              ))}
              
              {/* No results - offer to create */}
              {filteredTechnologies.length === 0 && searchQuery.trim() && !exactMatch && (
                <div className="py-6 text-center space-y-3">
                  <p className="text-sm text-muted-foreground">
                    No technology found for "{searchQuery}"
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCreateNew}
                    disabled={getOrCreate.isPending}
                    className="gap-1.5"
                  >
                    {getOrCreate.isPending ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <Plus className="w-3 h-3" />
                    )}
                    Add "{searchQuery}" as draft
                  </Button>
                </div>
              )}
              
              {/* Prompt to type */}
              {!searchQuery && filteredTechnologies.length === 0 && (
                <div className="py-8 text-center text-sm text-muted-foreground">
                  Type to search the technology library
                </div>
              )}
            </div>
          )}
        </ScrollArea>
        
        {/* Footer hint */}
        <div className="p-2 border-t border-border bg-muted/30 text-center">
          <span className="text-xs text-muted-foreground">
            Select from library or create a new draft
          </span>
        </div>
      </PopoverContent>
    </Popover>
  );
}

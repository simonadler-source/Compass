import { useAnalysisRunLogs, AnalysisRunLog } from '@/hooks/useAnalysisRunLogs';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, CheckCircle2, XCircle, Clock, Loader2, SkipForward, AlertTriangle } from 'lucide-react';
import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';

interface AnalysisStatusPanelProps {
  transcriptId: string | null;
}

const statusConfig: Record<string, { icon: React.ElementType; color: string; label: string }> = {
  completed: { icon: CheckCircle2, color: 'text-green-500', label: 'Completed' },
  failed: { icon: XCircle, color: 'text-destructive', label: 'Failed' },
  running: { icon: Loader2, color: 'text-blue-500', label: 'Running' },
  skipped: { icon: SkipForward, color: 'text-muted-foreground', label: 'Skipped' },
};

const categoryLabels: Record<string, string> = {
  timeout: 'Timeout',
  schema_explosion: 'Schema Error',
  ai_error: 'AI Error',
  content_error: 'Content Issue',
  unknown: 'Unknown',
};

function PassRow({ log }: { log: AnalysisRunLog }) {
  const [expanded, setExpanded] = useState(false);
  const cfg = statusConfig[log.status] || statusConfig.failed;
  const Icon = cfg.icon;

  return (
    <div className="border border-border rounded-md">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-muted/50 transition-colors"
      >
        <Icon className={`h-4 w-4 ${cfg.color} ${log.status === 'running' ? 'animate-spin' : ''}`} />
        <span className="font-medium flex-1 text-left">{log.pass_name || log.pass_key}</span>
        <Badge variant="outline" className="text-xs capitalize">{log.phase}</Badge>
        {log.duration_ms !== null && (
          <span className="text-xs text-muted-foreground">{(log.duration_ms / 1000).toFixed(1)}s</span>
        )}
        {log.retry_attempt > 0 && (
          <Badge variant="secondary" className="text-xs">retry #{log.retry_attempt}</Badge>
        )}
        <Badge
          variant={log.status === 'completed' ? 'default' : log.status === 'failed' ? 'destructive' : 'secondary'}
          className="text-xs"
        >
          {cfg.label}
        </Badge>
      </button>
      {expanded && (
        <div className="px-3 pb-2 space-y-1 text-xs text-muted-foreground border-t border-border pt-2">
          <div>Started: {new Date(log.started_at).toLocaleString()}</div>
          {log.completed_at && <div>Completed: {new Date(log.completed_at).toLocaleString()}</div>}
          {log.input_tokens_estimate && <div>Tokens: ~{log.input_tokens_estimate} in / ~{log.output_tokens_estimate} out</div>}
          {log.error_message && (
            <div className="mt-1 p-2 bg-destructive/10 rounded text-destructive text-xs">
              <span className="font-medium">{categoryLabels[log.error_category || ''] || log.error_category}: </span>
              {log.error_message}
            </div>
          )}
          {log.result_summary && (
            <div className="mt-1 p-2 bg-muted rounded text-xs">
              {Object.entries(log.result_summary).map(([k, v]) => (
                <span key={k} className="mr-3">{k}: <strong>{String(v)}</strong></span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export function AnalysisStatusPanel({ transcriptId }: AnalysisStatusPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { data: logs, isLoading } = useAnalysisRunLogs(transcriptId);

  if (!transcriptId) return null;

  const completed = logs?.filter(l => l.status === 'completed').length || 0;
  const failed = logs?.filter(l => l.status === 'failed').length || 0;
  const total = logs?.length || 0;
  const hasFailures = failed > 0;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <CollapsibleTrigger className="flex items-center gap-2 w-full p-3 text-sm font-medium hover:bg-muted/50 rounded-lg transition-colors">
        <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-0' : '-rotate-90'}`} />
        <span>Analysis Pipeline Status</span>
        {isLoading ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />
        ) : total > 0 ? (
          <>
            <Badge variant={hasFailures ? 'destructive' : 'default'} className="text-xs ml-auto">
              {completed}/{total} passes
            </Badge>
            {hasFailures && (
              <Badge variant="destructive" className="text-xs">
                <AlertTriangle className="h-3 w-3 mr-1" />
                {failed} failed
              </Badge>
            )}
          </>
        ) : (
          <Badge variant="secondary" className="text-xs ml-auto">No runs</Badge>
        )}
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="space-y-1.5 p-2">
          {logs?.map(log => <PassRow key={log.id} log={log} />)}
          {total === 0 && !isLoading && (
            <p className="text-sm text-muted-foreground p-3 text-center">
              No analysis runs recorded for this transcript yet.
            </p>
          )}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

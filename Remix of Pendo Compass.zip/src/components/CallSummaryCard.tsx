import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  MessageSquare, 
  ListChecks, 
  Users, 
  Clock,
  ArrowRight,
  BookOpen,
  Lightbulb,
  TrendingUp,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface CallSummaryAttendee {
  name: string;
  role?: string;
}

interface CallSummaryNextStep {
  action: string;
  owner?: string;
}

interface CallSummaryThemeSection {
  title: string;
  content: string;
}

interface CallSummarySuggestedAction {
  action: string;
  rationale?: string;
}

export interface CallSummaryData {
  quickRecap: string;
  themeSections: CallSummaryThemeSection[];
  nextSteps: CallSummaryNextStep[];
  suggestedActions?: CallSummarySuggestedAction[];
  attendees?: {
    internal?: CallSummaryAttendee[];
    external?: CallSummaryAttendee[];
  };
  durationMinutes?: number;
  opportunityContext?: string;
}

interface CallSummaryCardProps {
  summary: CallSummaryData;
  compact?: boolean;
  className?: string;
}

export function CallSummaryCard({ summary, compact = false, className }: CallSummaryCardProps) {
  if (!summary?.quickRecap) return null;

  if (compact) {
    return (
      <div className={cn("space-y-2", className)}>
        <div className="flex items-start gap-2">
          <MessageSquare className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
          <p className="text-sm text-foreground leading-relaxed">{summary.quickRecap}</p>
        </div>
        {summary.nextSteps?.length > 0 && (
          <div className="flex items-start gap-2">
            <ListChecks className="w-3.5 h-3.5 text-muted-foreground mt-0.5 shrink-0" />
            <p className="text-xs text-muted-foreground">
              {summary.nextSteps.length} next step{summary.nextSteps.length !== 1 ? 's' : ''} agreed
            </p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={cn("space-y-4", className)}>
      {/* Quick Recap */}
      <div className="space-y-1.5">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-primary" />
          <h4 className="text-sm font-semibold text-foreground">Quick Recap</h4>
          {summary.durationMinutes && (
            <Badge variant="outline" className="text-xs ml-auto">
              <Clock className="w-3 h-3 mr-1" />
              {summary.durationMinutes} min
            </Badge>
          )}
        </div>
        <p className="text-sm text-foreground/80 leading-relaxed pl-6">{summary.quickRecap}</p>
      </div>

      {/* Opportunity Context */}
      {summary.opportunityContext && (
        <div className="flex items-start gap-2 pl-6 rounded-md bg-primary/5 border border-primary/10 p-2.5">
          <TrendingUp className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
          <p className="text-xs text-foreground/70 leading-relaxed">{summary.opportunityContext}</p>
        </div>
      )}

      {/* Attendees */}
      {summary.attendees && (summary.attendees.internal?.length || summary.attendees.external?.length) ? (
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-muted-foreground" />
            <h4 className="text-sm font-semibold text-foreground">Attendees</h4>
          </div>
          <div className="pl-6 flex flex-wrap gap-x-6 gap-y-1">
            {summary.attendees.internal?.length ? (
              <div>
                <span className="text-xs text-muted-foreground font-medium">Internal: </span>
                <span className="text-xs text-foreground">
                  {summary.attendees.internal.map(a => a.role ? `${a.name} (${a.role})` : a.name).join(', ')}
                </span>
              </div>
            ) : null}
            {summary.attendees.external?.length ? (
              <div>
                <span className="text-xs text-muted-foreground font-medium">External: </span>
                <span className="text-xs text-foreground">
                  {summary.attendees.external.map(a => a.role ? `${a.name} (${a.role})` : a.name).join(', ')}
                </span>
              </div>
            ) : null}
          </div>
        </div>
      ) : null}

      <Separator className="my-2" />

      {/* Theme Sections */}
      {summary.themeSections?.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-muted-foreground" />
            <h4 className="text-sm font-semibold text-foreground">Summary</h4>
          </div>
          <div className="pl-6 space-y-3">
            {summary.themeSections.map((section, i) => (
              <div key={i}>
                <h5 className="text-sm font-medium text-foreground">{section.title}</h5>
                <p className="text-sm text-muted-foreground leading-relaxed mt-0.5">{section.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <Separator className="my-2" />

      {/* Next Steps */}
      {summary.nextSteps?.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <ListChecks className="w-4 h-4 text-primary" />
            <h4 className="text-sm font-semibold text-foreground">Next Steps</h4>
            <Badge variant="secondary" className="text-xs ml-1">{summary.nextSteps.length}</Badge>
          </div>
          <ul className="pl-6 space-y-1.5">
            {summary.nextSteps.map((step, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <ArrowRight className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                <span className="text-foreground/80">
                  {step.owner && <span className="font-medium text-foreground">{step.owner}</span>}
                  {step.owner && ' — '}
                  {step.action}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Suggested Actions */}
      {summary.suggestedActions && summary.suggestedActions.length > 0 && (
        <>
          <Separator className="my-2" />
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-500" />
              <h4 className="text-sm font-semibold text-foreground">Suggested Actions</h4>
              <Badge variant="outline" className="text-xs ml-1 border-amber-500/30 text-amber-600 bg-amber-500/5">Internal</Badge>
            </div>
            <ul className="pl-6 space-y-2">
              {summary.suggestedActions.map((sa, i) => (
                <li key={i} className="text-sm">
                  <div className="flex items-start gap-2">
                    <span className="text-amber-500 font-medium shrink-0">•</span>
                    <div>
                      <span className="text-foreground/80">{sa.action}</span>
                      {sa.rationale && (
                        <p className="text-xs text-muted-foreground mt-0.5">{sa.rationale}</p>
                      )}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}
    </div>
  );
}

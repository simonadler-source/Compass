import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { BarChart3 } from 'lucide-react';

interface CompetitorScoreBadgeProps {
  vendorName: string;
  compact?: boolean;
}

/**
 * A small badge that shows a competitor's average competitive scorecard score
 * and how it compares to Pendo. Used in list/grid views of the Technology Library.
 */
export function CompetitorScoreBadge({ vendorName, compact = false }: CompetitorScoreBadgeProps) {
  const { data } = useQuery({
    queryKey: ['scorecard-badge', vendorName],
    queryFn: async () => {
      const [compRes, pendoRes] = await Promise.all([
        gateway.from('competitive_scorecard').select('score').eq('vendor_name', vendorName).execute(),
        gateway.from('competitive_scorecard').select('score').eq('vendor_name', 'Pendo').execute(),
      ]);

      if (compRes.error || pendoRes.error) return null;

      const compScores = (compRes.data || []) as { score: number }[];
      const pendoScores = (pendoRes.data || []) as { score: number }[];

      if (compScores.length === 0) return null;

      const avgComp = compScores.reduce((s, c) => s + c.score, 0) / compScores.length;
      const avgPendo = pendoScores.length > 0 
        ? pendoScores.reduce((s, p) => s + p.score, 0) / pendoScores.length 
        : 0;

      return {
        avgScore: avgComp,
        avgPendo,
        diff: avgPendo - avgComp,
        count: compScores.length,
      };
    },
    enabled: !!vendorName,
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });

  if (!data) return null;

  const getColor = () => {
    if (data.diff >= 1) return 'bg-green-500/15 text-green-500 border-green-500/30';
    if (data.diff >= 0) return 'bg-amber-500/15 text-amber-500 border-amber-500/30';
    return 'bg-red-500/15 text-red-500 border-red-500/30';
  };

  if (compact) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Badge variant="outline" className={cn("text-xs gap-1 px-1.5", getColor())}>
              <BarChart3 className="w-3 h-3" />
              {data.avgScore.toFixed(1)}
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <div className="text-xs space-y-1">
              <p className="font-medium">{vendorName} Competitive Score</p>
              <p>Avg: {data.avgScore.toFixed(2)} / 5.0 ({data.count} subcategories)</p>
              <p>Pendo Avg: {data.avgPendo.toFixed(2)} / 5.0</p>
              <p className={data.diff >= 0 ? 'text-green-400' : 'text-red-400'}>
                Pendo {data.diff >= 0 ? 'leads' : 'trails'} by {Math.abs(data.diff).toFixed(2)}
              </p>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <Badge variant="outline" className={cn("text-xs gap-1", getColor())}>
        <BarChart3 className="w-3 h-3" />
        {data.avgScore.toFixed(1)} / 5.0
      </Badge>
      <span className="text-xs text-muted-foreground">
        vs Pendo {data.avgPendo.toFixed(1)}
      </span>
    </div>
  );
}
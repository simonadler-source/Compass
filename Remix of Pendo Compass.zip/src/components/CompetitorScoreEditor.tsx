import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { Link2, Save, TrendingUp, TrendingDown, Minus, Plus, BarChart3, Shield, Target } from 'lucide-react';
import { encryptedInsert, encryptedUpdate } from '@/lib/encryptedDb';

interface CompetitorScoreEditorProps {
  technologyId: string;
  technologyName: string;
  competitorId: string | null;
  onCompetitorLink: (competitorId: string | null) => void;
}

interface ScorecardScore {
  id: string;
  vendor_name: string;
  category: string;
  subcategory: string;
  score: number;
}

interface CategorySummary {
  category: string;
  avgCompetitorScore: number;
  avgPendoScore: number;
  subcategories: {
    subcategory: string;
    competitorScore: number;
    pendoScore: number;
    difference: number;
  }[];
  advantages: number;
  gaps: number;
}

// Hook to fetch scorecard data for a vendor
function useScorecardVendorData(vendorName: string | null) {
  return useQuery({
    queryKey: ['scorecard-vendor-data', vendorName],
    queryFn: async () => {
      if (!vendorName) return null;

      const [compRes, pendoRes] = await Promise.all([
        gateway.from('competitive_scorecard').select('*').eq('vendor_name', vendorName).order('category').execute(),
        gateway.from('competitive_scorecard').select('*').eq('vendor_name', 'Pendo').order('category').execute(),
      ]);

      if (compRes.error) throw new Error(compRes.error.message);
      if (pendoRes.error) throw new Error(pendoRes.error.message);

      const compScores = (compRes.data || []) as ScorecardScore[];
      const pendoScores = (pendoRes.data || []) as ScorecardScore[];

      const pendoMap = new Map(
        pendoScores.map(s => [`${s.category}|${s.subcategory}`, s.score])
      );

      // Build category summaries
      const categoryMap = new Map<string, CategorySummary>();

      for (const cs of compScores) {
        const key = cs.category;
        const pendoScore = pendoMap.get(`${cs.category}|${cs.subcategory}`) || 0;
        const diff = pendoScore - cs.score;

        if (!categoryMap.has(key)) {
          categoryMap.set(key, {
            category: key,
            avgCompetitorScore: 0,
            avgPendoScore: 0,
            subcategories: [],
            advantages: 0,
            gaps: 0,
          });
        }

        const cat = categoryMap.get(key)!;
        cat.subcategories.push({
          subcategory: cs.subcategory,
          competitorScore: cs.score,
          pendoScore,
          difference: diff,
        });

        if (diff >= 1.5) cat.advantages++;
        if (diff <= -1) cat.gaps++;
      }

      // Calculate averages
      for (const cat of categoryMap.values()) {
        const compSum = cat.subcategories.reduce((s, sc) => s + sc.competitorScore, 0);
        const pendoSum = cat.subcategories.reduce((s, sc) => s + sc.pendoScore, 0);
        cat.avgCompetitorScore = cat.subcategories.length > 0 ? compSum / cat.subcategories.length : 0;
        cat.avgPendoScore = cat.subcategories.length > 0 ? pendoSum / cat.subcategories.length : 0;
      }

      const categories = Array.from(categoryMap.values()).sort((a, b) => a.category.localeCompare(b.category));

      const totalCompScore = compScores.reduce((s, cs) => s + cs.score, 0);
      const totalPendoScore = compScores.reduce((s, cs) => s + (pendoMap.get(`${cs.category}|${cs.subcategory}`) || 0), 0);
      const avgCompScore = compScores.length > 0 ? totalCompScore / compScores.length : 0;
      const avgPendoScore = compScores.length > 0 ? totalPendoScore / compScores.length : 0;
      const totalAdvantages = categories.reduce((s, c) => s + c.advantages, 0);
      const totalGaps = categories.reduce((s, c) => s + c.gaps, 0);

      return {
        vendorName,
        scoreCount: compScores.length,
        avgScore: avgCompScore,
        avgPendoScore,
        totalAdvantages,
        totalGaps,
        categories,
      };
    },
    enabled: !!vendorName,
  });
}

// Exported hook for use in list views
export function useCompetitorScorecardSummary(vendorName: string | null) {
  return useScorecardVendorData(vendorName);
}

export function CompetitorScoreEditor({
  technologyId,
  technologyName,
  competitorId,
  onCompetitorLink,
}: CompetitorScoreEditorProps) {
  const queryClient = useQueryClient();

  // Fetch all competitors for linking
  const { data: competitors } = useQuery({
    queryKey: ['all-competitors'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('competitors')
        .select('*')
        .order('name');
      if (error) throw error;
      return data;
    },
  });

  // Create competitor record
  const createCompetitor = useMutation({
    mutationFn: async (name: string) => {
      const { data: inserted, error } = await gateway
        .from('competitors')
        .insert({ name, is_primary_competitor: true })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const data = Array.isArray(inserted) ? inserted[0] : inserted;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['all-competitors'] });
      onCompetitorLink(data.id);
      toast.success('Competitor record created');
    },
  });

  // Fetch scorecard data using the technology name as vendor_name
  const { data: scorecardData, isLoading: scorecardLoading } = useScorecardVendorData(technologyName);

  const linkedCompetitor = competitors?.find((c: any) => c.id === competitorId);

  if (!competitorId) {
    return (
      <div className="space-y-4">
        {/* Show scorecard preview even without competitor link */}
        {scorecardData && scorecardData.scoreCount > 0 && (
          <ScorecardSummaryCard data={scorecardData} />
        )}
        
        <div className="p-4 border rounded-lg bg-muted/30 space-y-3">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Link2 className="w-5 h-5" />
            <span className="font-medium">Link to Competitor Record</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Link this technology to a competitor record to enable manual score editing.
            {scorecardData && scorecardData.scoreCount > 0 && (
              <> Scorecard data is already available from imported competitive data.</>
            )}
          </p>
          <div className="flex gap-2">
            <Select onValueChange={(v) => onCompetitorLink(v)}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Select existing competitor..." />
              </SelectTrigger>
              <SelectContent>
                {competitors?.filter((c: any) => c.name !== 'Pendo').map((c: any) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button 
              variant="outline" 
              onClick={() => createCompetitor.mutate(technologyName)}
              disabled={createCompetitor.isPending}
            >
              <Plus className="w-4 h-4 mr-1" />
              Create New
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Linked competitor header */}
      <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
        <div className="flex items-center gap-3">
          <Link2 className="w-5 h-5 text-primary" />
          <div>
            <p className="font-medium">{linkedCompetitor?.name || technologyName}</p>
            <p className="text-xs text-muted-foreground">
              Linked competitor record
            </p>
          </div>
        </div>
        <Button size="sm" variant="outline" onClick={() => onCompetitorLink(null)}>
          Unlink
        </Button>
      </div>

      {/* Scorecard data from competitive_scorecard */}
      {scorecardLoading ? (
        <div className="text-center py-6 text-sm text-muted-foreground">Loading scorecard data...</div>
      ) : scorecardData && scorecardData.scoreCount > 0 ? (
        <ScorecardSummaryCard data={scorecardData} showDetails />
      ) : (
        <div className="text-center py-6 text-sm text-muted-foreground border rounded-lg">
          <BarChart3 className="w-8 h-8 mx-auto mb-2 opacity-40" />
          <p>No scorecard data found for "{technologyName}"</p>
          <p className="text-xs mt-1">Import competitive data or ensure the vendor name matches exactly.</p>
        </div>
      )}
    </div>
  );
}

// Scorecard summary card - reusable component
function ScorecardSummaryCard({ 
  data, 
  showDetails = false 
}: { 
  data: NonNullable<ReturnType<typeof useScorecardVendorData>['data']>;
  showDetails?: boolean;
}) {
  const getScoreColor = (score: number) => {
    if (score >= 4) return 'text-green-500';
    if (score >= 3) return 'text-amber-500';
    if (score >= 2) return 'text-orange-500';
    return 'text-red-500';
  };

  const getDiffIcon = (diff: number) => {
    if (diff >= 1.5) return <TrendingUp className="w-3 h-3 text-green-500" />;
    if (diff <= -1) return <TrendingDown className="w-3 h-3 text-red-500" />;
    return <Minus className="w-3 h-3 text-muted-foreground" />;
  };

  return (
    <div className="space-y-3">
      {/* Summary stats */}
      <div className="grid grid-cols-4 gap-3">
        <div className="p-3 border rounded-lg bg-muted/30 text-center">
          <p className={cn("text-xl font-bold", getScoreColor(data.avgScore))}>
            {data.avgScore.toFixed(1)}
          </p>
          <p className="text-xs text-muted-foreground">Avg Score</p>
        </div>
        <div className="p-3 border rounded-lg bg-muted/30 text-center">
          <p className="text-xl font-bold text-primary">{data.avgPendoScore.toFixed(1)}</p>
          <p className="text-xs text-muted-foreground">Pendo Avg</p>
        </div>
        <div className="p-3 border rounded-lg bg-muted/30 text-center">
          <p className="text-xl font-bold text-green-500">{data.totalAdvantages}</p>
          <p className="text-xs text-muted-foreground">Pendo Leads</p>
        </div>
        <div className="p-3 border rounded-lg bg-muted/30 text-center">
          <p className="text-xl font-bold text-red-500">{data.totalGaps}</p>
          <p className="text-xs text-muted-foreground">Competitor Leads</p>
        </div>
      </div>

      {/* Category breakdown */}
      {showDetails && (
        <ScrollArea className="h-[350px] pr-4">
          <Accordion type="multiple" className="space-y-1">
            {data.categories.map((cat) => (
              <AccordionItem key={cat.category} value={cat.category} className="border rounded-lg px-3">
                <AccordionTrigger className="hover:no-underline py-2">
                  <div className="flex items-center gap-3 w-full pr-2">
                    <span className="font-medium text-sm flex-1 text-left">{cat.category}</span>
                    <div className="flex items-center gap-2">
                      {cat.advantages > 0 && (
                        <Badge variant="secondary" className="text-xs bg-green-500/15 text-green-500 gap-1">
                          <Shield className="w-3 h-3" />
                          {cat.advantages}
                        </Badge>
                      )}
                      {cat.gaps > 0 && (
                        <Badge variant="secondary" className="text-xs bg-red-500/15 text-red-500 gap-1">
                          <Target className="w-3 h-3" />
                          {cat.gaps}
                        </Badge>
                      )}
                      <span className={cn("text-sm font-semibold", getScoreColor(cat.avgCompetitorScore))}>
                        {cat.avgCompetitorScore.toFixed(1)}
                      </span>
                      <span className="text-xs text-muted-foreground">vs</span>
                      <span className="text-sm font-semibold text-primary">
                        {cat.avgPendoScore.toFixed(1)}
                      </span>
                    </div>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pb-3">
                  <div className="space-y-2">
                    {cat.subcategories.map((sc) => (
                      <div key={sc.subcategory} className="flex items-center gap-2 text-sm">
                        {getDiffIcon(sc.difference)}
                        <span className="flex-1 text-muted-foreground">{sc.subcategory}</span>
                        <div className="flex items-center gap-2">
                          <span className={cn("font-medium w-6 text-right", getScoreColor(sc.competitorScore))}>
                            {sc.competitorScore}
                          </span>
                          <div className="w-16">
                            <Progress 
                              value={(sc.competitorScore / 5) * 100} 
                              className="h-1.5"
                            />
                          </div>
                          <span className="text-xs text-muted-foreground">vs</span>
                          <span className="font-medium text-primary w-6 text-right">{sc.pendoScore}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </ScrollArea>
      )}

      {!showDetails && (
        <div className="space-y-1.5">
          {data.categories.map((cat) => (
            <div key={cat.category} className="flex items-center gap-2 text-xs">
              <span className="flex-1 text-muted-foreground truncate">{cat.category}</span>
              <span className={cn("font-medium", getScoreColor(cat.avgCompetitorScore))}>
                {cat.avgCompetitorScore.toFixed(1)}
              </span>
              <div className="w-12">
                <Progress value={(cat.avgCompetitorScore / 5) * 100} className="h-1" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { HelpCircle, ChevronRight, Lightbulb, MessageSquare, Copy, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';
import { toast } from 'sonner';

interface DiscoveryQuestionsPanelProps {
  functionalArea?: string;
  functionalAreaId?: string;
  nbaAction?: string;
  compact?: boolean;
}

// Keywords that indicate whitespace opportunities
const WHITESPACE_KEYWORDS = [
  'whitespace', 'expansion', 'upsell', 'cross-sell', 'new use case',
  'explore', 'opportunity', 'growth', 'additional', 'expand',
  'untapped', 'potential', 'unused', 'underutilized'
];

export function isWhitespaceNBA(action: string, type?: string): boolean {
  if (type === 'whitespace') return true;
  const lowerAction = action.toLowerCase();
  return WHITESPACE_KEYWORDS.some(keyword => lowerAction.includes(keyword));
}

export function DiscoveryQuestionsPanel({
  functionalArea,
  functionalAreaId,
  nbaAction,
  compact = false,
}: DiscoveryQuestionsPanelProps) {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Fetch discovery questions for the functional area
  const { data: questions, isLoading } = useQuery({
    queryKey: ['discovery-questions', functionalArea, functionalAreaId],
    queryFn: async () => {
      let query = gateway
        .from('discovery_questions')
        .select('*, functional_areas(name)')
        .eq('is_active', true)
        .order('category', { ascending: true })
        .order('sort_order', { ascending: true });

      if (functionalAreaId) {
        query = query.eq('functional_area_id', functionalAreaId);
      }

      const { data, error } = await query.execute();
      if (error) throw new Error(getErrorMessage(error));

      // If we have a functional area name but no ID, filter by name
      if (!functionalAreaId && functionalArea) {
        return data.filter((q: any) => 
          q.functional_areas?.name?.toLowerCase().includes(functionalArea.toLowerCase())
        );
      }

      return data;
    },
    enabled: !!(functionalArea || functionalAreaId),
  });

  // Fetch all questions if no specific area
  const { data: allQuestions } = useQuery({
    queryKey: ['discovery-questions-all'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('discovery_questions')
        .select('*, functional_areas(name)')
        .eq('is_active', true)
        .order('category', { ascending: true })
        .order('sort_order', { ascending: true })
        .limit(10)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    enabled: !functionalArea && !functionalAreaId,
  });

  const displayQuestions = questions || allQuestions || [];

  const copyQuestion = (question: string, index: number) => {
    navigator.clipboard.writeText(question);
    setCopiedIndex(index);
    toast.success('Question copied to clipboard');
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Group questions by category
  const groupedQuestions = displayQuestions.reduce((acc: Record<string, any[]>, q: any) => {
    const category = q.category || 'General';
    acc[category] = acc[category] || [];
    acc[category].push(q);
    return acc;
  }, {});

  if (isLoading) {
    return (
      <div className="p-4 text-sm text-muted-foreground animate-pulse">
        Loading discovery questions...
      </div>
    );
  }

  if (displayQuestions.length === 0) {
    return null;
  }

  if (compact) {
    return (
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm font-medium text-primary">
          <Lightbulb className="w-4 h-4" />
          <span>Suggested Discovery Questions</span>
        </div>
        <div className="space-y-1.5">
          {displayQuestions.slice(0, 3).map((q: any, idx: number) => (
            <div 
              key={q.id} 
              className="flex items-start gap-2 p-2 rounded-md bg-primary/5 hover:bg-primary/10 transition-colors group cursor-pointer"
              onClick={() => copyQuestion(q.question, idx)}
            >
              <MessageSquare className="w-3.5 h-3.5 text-primary mt-0.5 flex-shrink-0" />
              <span className="text-xs text-foreground flex-1">{q.question}</span>
              {copiedIndex === idx ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />
              ) : (
                <Copy className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
              )}
            </div>
          ))}
        </div>
        {displayQuestions.length > 3 && (
          <p className="text-xs text-muted-foreground">
            +{displayQuestions.length - 3} more questions
          </p>
        )}
      </div>
    );
  }

  return (
    <Card className="border-primary/20 bg-primary/5">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Lightbulb className="w-4 h-4 text-primary" />
          Discovery Questions
          {functionalArea && (
            <Badge variant="outline" className="text-xs ml-auto">
              {functionalArea}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="max-h-64">
          <div className="space-y-4">
            {Object.entries(groupedQuestions).map(([category, categoryQuestions]) => (
              <div key={category}>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  {category}
                </h4>
                <div className="space-y-2">
                  {(categoryQuestions as any[]).map((q, idx) => (
                    <div 
                      key={q.id}
                      className="flex items-start gap-2 p-2 rounded-md hover:bg-primary/10 transition-colors group cursor-pointer"
                      onClick={() => copyQuestion(q.question, idx)}
                    >
                      <HelpCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-sm flex-1">{q.question}</span>
                      {copiedIndex === idx ? (
                        <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                      ) : (
                        <Copy className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

import { useState } from 'react';
import { format, addDays, differenceInDays, isPast, isToday, parseISO } from 'date-fns';
import { Calendar, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface DueDatePickerProps {
  dueDate: string | null | undefined;
  onDateChange: (newDate: Date, previousDate: Date | null) => void;
  disabled?: boolean;
  compact?: boolean;
}

export function DueDatePicker({ dueDate, onDateChange, disabled, compact = true }: DueDatePickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  const parsedDate = dueDate ? parseISO(dueDate) : null;
  const daysRemaining = parsedDate ? differenceInDays(parsedDate, new Date()) : null;

  // Color gradient based on days remaining
  const getDateStyles = () => {
    if (!parsedDate) return 'text-muted-foreground';
    
    if (isPast(parsedDate) && !isToday(parsedDate)) {
      return 'text-destructive font-medium';
    }
    if (isToday(parsedDate)) {
      return 'text-amber-600 font-medium';
    }
    if (daysRemaining !== null && daysRemaining <= 2) {
      return 'text-amber-500';
    }
    if (daysRemaining !== null && daysRemaining <= 7) {
      return 'text-layer-build';
    }
    return 'text-green-600';
  };

  const getDateLabel = () => {
    if (!parsedDate) return 'No due date';
    
    if (isToday(parsedDate)) return 'Today';
    if (daysRemaining === 1) return 'Tomorrow';
    if (daysRemaining === -1) return 'Yesterday';
    if (daysRemaining !== null && daysRemaining < -1) {
      return `${Math.abs(daysRemaining)}d overdue`;
    }
    if (daysRemaining !== null && daysRemaining <= 7) {
      return `${daysRemaining}d`;
    }
    return format(parsedDate, 'MMM d');
  };

  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      onDateChange(date, parsedDate);
      setIsOpen(false);
    }
  };

  const handleQuickDelay = (days: number) => {
    const baseDate = parsedDate || new Date();
    const newDate = addDays(baseDate, days);
    onDateChange(newDate, parsedDate);
    setIsOpen(false);
  };

  if (compact) {
    return (
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <PopoverTrigger asChild>
                <button
                  className={cn(
                    "text-[10px] flex items-center gap-0.5 hover:underline transition-colors cursor-pointer",
                    getDateStyles(),
                    disabled && "opacity-50 cursor-not-allowed"
                  )}
                  disabled={disabled}
                >
                  <Clock className="w-2.5 h-2.5" />
                  <span>{getDateLabel()}</span>
                </button>
              </PopoverTrigger>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">
              {parsedDate ? format(parsedDate, 'EEEE, MMMM d, yyyy') : 'Set due date'}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        <PopoverContent className="w-auto p-0" align="start" sideOffset={5}>
          <div className="p-2 border-b border-border">
            <p className="text-xs font-medium text-muted-foreground mb-2">Quick delay</p>
            <div className="flex gap-1">
              {[1, 2, 5, 10].map((days) => (
                <Button
                  key={days}
                  variant="outline"
                  size="sm"
                  className="text-xs h-7 px-2"
                  onClick={() => handleQuickDelay(days)}
                >
                  +{days}d
                </Button>
              ))}
            </div>
          </div>
          <CalendarComponent
            mode="single"
            selected={parsedDate || undefined}
            onSelect={handleDateSelect}
            initialFocus
            className={cn("p-3 pointer-events-auto")}
          />
        </PopoverContent>
      </Popover>
    );
  }

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "justify-start text-left font-normal h-8",
            !parsedDate && "text-muted-foreground",
            getDateStyles()
          )}
          disabled={disabled}
        >
          <Calendar className="w-3.5 h-3.5 mr-1.5" />
          {parsedDate ? format(parsedDate, 'MMM d, yyyy') : 'Set due date'}
        </Button>
      </PopoverTrigger>
      
      <PopoverContent className="w-auto p-0" align="start">
        <div className="p-2 border-b border-border">
          <p className="text-xs font-medium text-muted-foreground mb-2">Quick delay</p>
          <div className="flex gap-1">
            {[1, 2, 5, 10].map((days) => (
              <Button
                key={days}
                variant="outline"
                size="sm"
                className="text-xs h-7 px-2"
                onClick={() => handleQuickDelay(days)}
              >
                +{days}d
              </Button>
            ))}
          </div>
        </div>
        <CalendarComponent
          mode="single"
          selected={parsedDate || undefined}
          onSelect={handleDateSelect}
          initialFocus
          className={cn("p-3 pointer-events-auto")}
        />
      </PopoverContent>
    </Popover>
  );
}

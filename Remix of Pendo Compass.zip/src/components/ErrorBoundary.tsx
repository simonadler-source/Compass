import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type Props = {
  children: React.ReactNode;
  title?: string;
};

type State = {
  hasError: boolean;
  errorMessage?: string;
};

export class ErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: unknown): State {
    const message = error instanceof Error ? error.message : String(error);
    return { hasError: true, errorMessage: message };
  }

  componentDidCatch(error: unknown) {
    // Keep this visible in production logs and also inform the user.
    console.error("[ErrorBoundary] Unhandled render error", error);
    toast.error("Something went wrong. Please refresh.", { duration: 8000 });
  }

  private handleReload = () => {
    window.location.reload();
  };

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <main className="min-h-screen flex items-center justify-center bg-background p-6">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        <Card className="glass border-border max-w-lg w-full relative z-10">
          <CardHeader>
            <CardTitle>{this.props.title ?? "App error"}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              The app hit an unexpected error and couldn’t render this screen.
            </p>
            {this.state.errorMessage && (
              <pre className="text-xs whitespace-pre-wrap rounded-md border bg-muted/30 p-3 text-foreground">
                {this.state.errorMessage}
              </pre>
            )}
            <div className="flex justify-end">
              <Button onClick={this.handleReload} variant="glow">
                Reload
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    );
  }
}

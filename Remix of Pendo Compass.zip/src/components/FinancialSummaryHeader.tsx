import { useMemo, useState } from 'react';
import { DollarSign, TrendingUp, Sparkles, ChevronDown, Target, Percent } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { useAggregateAccountFinancials, PipelineByStage } from '@/hooks/useAccountFinancials';

interface FinancialSummaryHeaderProps {
  accountIds: string[];
  totalWhitespace?: number;
}

function formatCompactCurrency(amount: number): string {
  if (amount >= 1000000) {
    return `$${(amount / 1000000).toFixed(1)}M`;
  } else if (amount >= 1000) {
    return `$${(amount / 1000).toFixed(0)}k`;
  }
  return `$${amount.toFixed(0)}`;
}

export function FinancialSummaryHeader({ accountIds, totalWhitespace = 0 }: FinancialSummaryHeaderProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const { aggregate, isLoading } = useAggregateAccountFinancials(accountIds);

  if (isLoading || accountIds.length === 0) {
    return null;
  }

  const { totalArr, totalPipeline, totalWeightedPipeline, pipelineByStage } = aggregate;
  
  // Use provided whitespace or fall back to zero
  const effectiveWhitespace = totalWhitespace || 0;

  // Calculate weighted percentage
  const weightedPct = totalPipeline > 0 ? Math.round((totalWeightedPipeline / totalPipeline) * 100) : 0;

  return (
    <TooltipProvider>
      <div className="glass rounded-xl border border-border/50">
        <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
          {/* Main Summary Row */}
          <div className="p-4">
            <div className="grid grid-cols-4 gap-6">
              {/* Current ARR */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">
                    {formatCompactCurrency(totalArr)}
                  </p>
                  <p className="text-xs text-muted-foreground">Current ARR</p>
                </div>
              </div>

              {/* Total Pipeline */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-layer-build/10 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-layer-build" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-2xl font-bold text-foreground">
                      {formatCompactCurrency(totalPipeline)}
                    </p>
                    {pipelineByStage.length > 0 && (
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                          <ChevronDown className={cn("w-4 h-4 transition-transform", isExpanded && "rotate-180")} />
                        </Button>
                      </CollapsibleTrigger>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">Open Pipeline</p>
                </div>
              </div>

              {/* Weighted Pipeline */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-3 cursor-help">
                    <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                      <Percent className="w-5 h-5 text-amber-500" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">
                        {formatCompactCurrency(totalWeightedPipeline)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Weighted ({weightedPct}%)
                      </p>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Pipeline weighted by stage probability</p>
                </TooltipContent>
              </Tooltip>

              {/* Whitespace */}
              {effectiveWhitespace > 0 && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-layer-growth/10 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-layer-growth" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {formatCompactCurrency(effectiveWhitespace)}
                    </p>
                    <p className="text-xs text-muted-foreground">Whitespace</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Expanded Pipeline by Stage */}
          <CollapsibleContent>
            <div className="px-4 pb-4 pt-0">
              <div className="border-t border-border/50 pt-3">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">
                  Pipeline by Stage
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                  {pipelineByStage.map((stage) => (
                    <PipelineStageCard key={stage.stage} stage={stage} />
                  ))}
                </div>
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </div>
    </TooltipProvider>
  );
}

function PipelineStageCard({ stage }: { stage: PipelineByStage }) {
  const weightPct = stage.value > 0 ? Math.round((stage.weightedValue / stage.value) * 100) : 0;
  
  return (
    <div className="p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
      <div className="flex items-center justify-between mb-1">
        <span className="text-sm font-medium text-foreground truncate">{stage.stage}</span>
        <Badge variant="secondary" className="text-xs ml-2">
          {stage.count}
        </Badge>
      </div>
      <div className="flex items-baseline justify-between">
        <span className="text-lg font-semibold text-foreground">
          {formatCompactCurrency(stage.value)}
        </span>
        <span className="text-xs text-muted-foreground">
          {weightPct}% weight
        </span>
      </div>
    </div>
  );
}

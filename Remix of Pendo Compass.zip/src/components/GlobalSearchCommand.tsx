import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from '@/components/ui/command';
import { 
  Building2, 
  Target, 
  Users, 
  FileText, 
  CheckSquare,
  Search,
} from 'lucide-react';
import { gateway } from '@/lib/apiGateway';
// supabase import removed — all queries go through gateway for session-token auth
import { Badge } from '@/components/ui/badge';

interface SearchResult {
  id: string;
  type: 'account' | 'opportunity' | 'contact' | 'transcript' | 'nba';
  title: string;
  subtitle?: string;
  metadata?: string;
  accountId?: string;
}

export function GlobalSearchCommand() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Keyboard shortcut
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };

    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, []);

  // Search function — uses cached decrypted data when available, falls back to gateway
  const performSearch = useCallback(async (searchQuery: string) => {
    if (!searchQuery.trim() || searchQuery.length < 2) {
      setResults([]);
      return;
    }

    setIsLoading(true);
    const searchResults: SearchResult[] = [];
    const lowerQuery = searchQuery.toLowerCase();

    try {
      // --- ACCOUNTS: search via gateway (RLS requires session token) ---
      const accountsRes = await gateway.from('accounts')
        .select('id, name, industry, status')
        .ilike('name', `%${searchQuery}%`)
        .limit(5)
        .execute();

      if (accountsRes.data) {
        (accountsRes.data as any[]).forEach(acc => {
          searchResults.push({
            id: acc.id,
            type: 'account',
            title: acc.name,
            subtitle: acc.industry || undefined,
            metadata: acc.status || undefined,
          });
        });
      }

      // --- OPPORTUNITIES: search via gateway ---
      const oppsRes = await gateway.from('opportunities')
        .select('id, name, account_id, sales_stage')
        .ilike('name', `%${searchQuery}%`)
        .limit(5)
        .execute();

      if (oppsRes.data) {
        (oppsRes.data as any[]).forEach(opp => {
          searchResults.push({
            id: opp.id,
            type: 'opportunity',
            title: opp.name,
            metadata: opp.sales_stage || undefined,
            accountId: opp.account_id || undefined,
          });
        });
      }

      // --- CONTACTS: names are encrypted — fetch via gateway and filter client-side ---
      let contactResults: SearchResult[] = [];

      // Try cached contact data first
      const allContactCaches = queryClient.getQueriesData<any[]>({ queryKey: ['account-contacts'] });
      for (const [, data] of allContactCaches) {
        if (!data) continue;
        for (const contact of data) {
          const name = contact.name || contact.name_encrypted || '';
          const email = contact.email || contact.email_encrypted || '';
          const role = contact.role || contact.role_encrypted || '';
          if (name.toLowerCase().includes(lowerQuery) || email.toLowerCase().includes(lowerQuery)) {
            contactResults.push({
              id: contact.id,
              type: 'contact',
              title: name || email || 'Unknown Contact',
              subtitle: role || undefined,
              metadata: contact.stakeholder_type || undefined,
              accountId: contact.account_id,
            });
          }
          if (contactResults.length >= 5) break;
        }
        if (contactResults.length >= 5) break;
      }

      // Fallback: fetch via gateway if no cache hits
      if (contactResults.length === 0) {
        const contactRes = await gateway.from('account_contacts')
          .select('id, name_encrypted, email_encrypted, role_encrypted, stakeholder_type, account_id, accounts:account_id(name)')
          .limit(500)
          .execute();

        if (contactRes.data) {
          for (const contact of contactRes.data as any[]) {
            const name = contact.name_encrypted || '';
            const email = contact.email_encrypted || '';
            if (name.toLowerCase().includes(lowerQuery) || email.toLowerCase().includes(lowerQuery)) {
              contactResults.push({
                id: contact.id,
                type: 'contact',
                title: name || email || 'Unknown Contact',
                subtitle: contact.accounts?.name,
                metadata: contact.stakeholder_type || undefined,
                accountId: contact.account_id,
              });
            }
            if (contactResults.length >= 5) break;
          }
        }
      }

      searchResults.push(...contactResults);

      // --- NBAs: action field is encrypted — search cached decrypted data first ---
      let nbaResults: SearchResult[] = [];

      // Try grouped NBAs cache (from NBA dashboard — richest source)
      const groupedNBAsCache = queryClient.getQueryData<any[]>(['grouped-account-nbas']);
      if (groupedNBAsCache && groupedNBAsCache.length > 0) {
        for (const group of groupedNBAsCache) {
          for (const sub of group.subTasks || []) {
            if (sub.action?.toLowerCase().includes(lowerQuery)) {
              nbaResults.push({
                id: sub.id,
                type: 'nba',
                title: sub.action || 'Untitled Action',
                subtitle: group.accountName,
                metadata: sub.type,
                accountId: group.accountId,
              });
            }
            if (nbaResults.length >= 5) break;
          }
          if (nbaResults.length >= 5) break;
        }
      }

      // Try per-account NBA caches if grouped cache missed
      if (nbaResults.length === 0) {
        const allQueries = queryClient.getQueriesData<any[]>({ queryKey: ['account-nbas'] });
        for (const [, data] of allQueries) {
          if (!data) continue;
          for (const nba of data) {
            const action = nba.action || nba.action_encrypted || '';
            if (action.toLowerCase().includes(lowerQuery)) {
              nbaResults.push({
                id: nba.id,
                type: 'nba',
                title: action || 'Untitled Action',
                subtitle: nba.accounts?.name,
                metadata: nba.action_type,
                accountId: nba.account_id,
              });
            }
            if (nbaResults.length >= 5) break;
          }
          if (nbaResults.length >= 5) break;
        }
      }

      // Fallback: fetch via gateway (decrypts server-side) if no cache
      if (nbaResults.length === 0) {
        const nbaRes = await gateway.from('account_nbas')
          .select('id, action, action_type, status, account_id, opportunity_id, accounts:account_id(name)')
          .eq('status', 'pending')
          .limit(200)
          .execute();

        if (nbaRes.data) {
          for (const nba of nbaRes.data as any[]) {
            if (nba.action?.toLowerCase().includes(lowerQuery)) {
              nbaResults.push({
                id: nba.id,
                type: 'nba',
                title: nba.action || 'Untitled Action',
                subtitle: nba.accounts?.name,
                metadata: nba.action_type,
                accountId: nba.account_id,
              });
            }
            if (nbaResults.length >= 5) break;
          }
        }
      }

      searchResults.push(...nbaResults);

      // --- TRANSCRIPTS: file_name may be encrypted — search cached data first ---
      let transcriptResults: SearchResult[] = [];

      // Try transcript-reviews cache
      const allTranscriptCaches = queryClient.getQueriesData<any[]>({ queryKey: ['transcript-reviews'] });
      for (const [, data] of allTranscriptCaches) {
        if (!data) continue;
        for (const tr of data) {
          const fileName = tr.file_name || tr.meeting_title || '';
          if (fileName.toLowerCase().includes(lowerQuery)) {
            transcriptResults.push({
              id: tr.id,
              type: 'transcript',
              title: fileName || 'Untitled Transcript',
              subtitle: tr.accounts?.name,
              metadata: tr.status || undefined,
              accountId: tr.final_account_id || undefined,
            });
          }
          if (transcriptResults.length >= 5) break;
        }
        if (transcriptResults.length >= 5) break;
      }

      // Fallback: fetch via gateway if no cache
      if (transcriptResults.length === 0) {
        const trRes = await gateway.from('transcript_reviews')
          .select('id, file_name, meeting_title, status, final_account_id, opportunity_id, accounts:suggested_account_id(name)')
          .order('created_at', { ascending: false })
          .limit(200)
          .execute();

        if (trRes.data) {
          for (const tr of trRes.data as any[]) {
            const fileName = tr.file_name || tr.meeting_title || '';
            if (fileName.toLowerCase().includes(lowerQuery)) {
              transcriptResults.push({
                id: tr.id,
                type: 'transcript',
                title: fileName || 'Untitled Transcript',
                subtitle: tr.accounts?.name,
                metadata: tr.status || undefined,
                accountId: tr.final_account_id || undefined,
              });
            }
            if (transcriptResults.length >= 5) break;
          }
        }
      }

      searchResults.push(...transcriptResults);

      setResults(searchResults);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsLoading(false);
    }
  }, [queryClient]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      performSearch(query);
    }, 300);

    return () => clearTimeout(timer);
  }, [query, performSearch]);

  const handleSelect = (result: SearchResult) => {
    setOpen(false);
    setQuery('');

    switch (result.type) {
      case 'account':
        navigate(`/accounts/${result.id}`);
        break;
      case 'opportunity':
        if (result.accountId) {
          navigate(`/accounts/${result.accountId}?opportunityId=${result.id}`);
        }
        break;
      case 'contact':
        if (result.accountId) {
          navigate(`/accounts/${result.accountId}?tab=stakeholders`);
        }
        break;
      case 'nba':
        if (result.accountId) {
          navigate(`/accounts/${result.accountId}?tab=nbas`);
        }
        break;
      case 'transcript':
        navigate(`/transcripts?transcriptId=${result.id}`);
        break;
      default:
        break;
    }
  };

  const getIcon = (type: SearchResult['type']) => {
    switch (type) {
      case 'account':
        return <Building2 className="mr-2 h-4 w-4 text-primary" />;
      case 'opportunity':
        return <Target className="mr-2 h-4 w-4 text-accent-foreground" />;
      case 'contact':
        return <Users className="mr-2 h-4 w-4 text-secondary-foreground" />;
      case 'transcript':
        return <FileText className="mr-2 h-4 w-4 text-muted-foreground" />;
      case 'nba':
        return <CheckSquare className="mr-2 h-4 w-4 text-destructive" />;
    }
  };

  const groupedResults = results.reduce((acc, result) => {
    if (!acc[result.type]) {
      acc[result.type] = [];
    }
    acc[result.type].push(result);
    return acc;
  }, {} as Record<string, SearchResult[]>);

  const groupLabels: Record<string, string> = {
    account: 'Accounts',
    opportunity: 'Opportunities',
    contact: 'Contacts',
    transcript: 'Transcripts',
    nba: 'Actions (NBAs)',
  };

  return (
    <>
      {/* Search trigger button */}
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 px-3 py-1.5 text-sm text-muted-foreground bg-muted/50 hover:bg-muted rounded-md border border-border/50 transition-colors"
      >
        <Search className="h-4 w-4" />
        <span className="hidden sm:inline">Search...</span>
        <kbd className="hidden sm:inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium opacity-100">
          <span className="text-xs">⌘</span>K
        </kbd>
      </button>

      <CommandDialog open={open} onOpenChange={setOpen} shouldFilter={false}>
        <CommandInput 
          placeholder="Search accounts, opportunities, transcripts..." 
          value={query}
          onValueChange={setQuery}
        />
        <CommandList>
          {isLoading && (
            <div className="py-6 text-center text-sm text-muted-foreground">
              Searching...
            </div>
          )}
          
          {!isLoading && query.length >= 2 && results.length === 0 && (
            <CommandEmpty>No results found.</CommandEmpty>
          )}

          {!isLoading && query.length < 2 && (
            <div className="py-6 text-center text-sm text-muted-foreground">
              Type at least 2 characters to search
            </div>
          )}

          {Object.entries(groupedResults).map(([type, items], idx) => (
            <div key={type}>
              {idx > 0 && <CommandSeparator />}
              <CommandGroup heading={groupLabels[type]}>
                {items.map((result) => (
                  <CommandItem
                    key={`${result.type}-${result.id}`}
                    onSelect={() => handleSelect(result)}
                    className="cursor-pointer"
                  >
                    {getIcon(result.type)}
                    <div className="flex-1 overflow-hidden">
                      <div className="truncate font-medium">{result.title}</div>
                      {result.subtitle && (
                        <div className="truncate text-xs text-muted-foreground">
                          {result.subtitle}
                        </div>
                      )}
                    </div>
                    {result.metadata && (
                      <Badge variant="secondary" className="ml-2 text-xs">
                        {result.metadata}
                      </Badge>
                    )}
                  </CommandItem>
                ))}
              </CommandGroup>
            </div>
          ))}
        </CommandList>
      </CommandDialog>
    </>
  );
}

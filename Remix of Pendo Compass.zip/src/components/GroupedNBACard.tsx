import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Mail, 
  Users, 
  ClipboardList, 
  CheckCircle2, 
  Circle, 
  ChevronDown, 
  ChevronUp,
  Building2,
  Sparkles,
  AlertCircle,
  CheckSquare,
  TrendingUp,
  HelpCircle,
  User,
  Briefcase,
  Wrench,
  Target,
  ExternalLink,
  X,
  AlertTriangle,
  Ban,
  UserPlus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { GroupedNBA, SubTaskNBA, DeliveryMethod, PriorityFactor, NBAOwner } from '@/hooks/useGroupedNBAs';
import { DueDatePicker } from '@/components/DueDatePicker';
import { isPast, isToday, isTomorrow, parseISO } from 'date-fns';
import { AssignableUser } from '@/hooks/useAssignableOpportunityUsers';
import { AccountHoverCard } from '@/components/AccountHoverCard';

const ownerConfig: Record<NBAOwner, { icon: typeof User; label: string; fullLabel: string; color: string }> = {
  prospect: { icon: User, label: 'Prospect', fullLabel: 'Customer Action', color: 'text-amber-600 bg-amber-500/10 border-amber-500/30' },
  sales_rep: { icon: Briefcase, label: 'AE', fullLabel: 'Account Executive', color: 'text-blue-600 bg-blue-500/10 border-blue-500/30' },
  sales_engineer: { icon: Wrench, label: 'SE', fullLabel: 'Solutions Engineer', color: 'text-purple-600 bg-purple-500/10 border-purple-500/30' },
};

interface GroupedNBACardProps {
  group: GroupedNBA;
  onCompleteSubTask: (subTaskId: string) => void;
  onCancelSubTask?: (subTaskId: string) => void;
  onCompleteAll: (subTaskIds: string[]) => void;
  onViewAccount: (accountId: string) => void;
  onDueDateChange?: (nbaId: string, newDate: Date, previousDate: Date | null) => void;
  onOwnerChange?: (nbaId: string, accountId: string, opportunityId: string | null, newOwner: string | null) => void;
  assignableUsers?: AssignableUser[];
}

const deliveryMethodConfig: Record<DeliveryMethod, { icon: typeof Mail; label: string; color: string }> = {
  email: { icon: Mail, label: 'Email', color: 'text-blue-500 bg-blue-500/10' },
  meeting: { icon: Users, label: 'Meeting', color: 'text-purple-500 bg-purple-500/10' },
  internal: { icon: ClipboardList, label: 'Internal', color: 'text-muted-foreground bg-muted' },
};

const priorityColors: Record<string, string> = {
  high: 'border-destructive/30 bg-destructive/5',
  medium: 'border-layer-build/30 bg-layer-build/5',
  low: 'border-border bg-muted/30',
};

const priorityBadgeColors: Record<string, string> = {
  high: 'border-destructive text-destructive bg-destructive/10',
  medium: 'border-layer-build text-layer-build bg-layer-build/10',
  low: 'border-muted-foreground text-muted-foreground',
};

// Priority breakdown tooltip component
function PriorityBreakdownTooltip({ 
  priority, 
  priorityScore, 
  factors 
}: { 
  priority: 'high' | 'medium' | 'low'; 
  priorityScore: number;
  factors: PriorityFactor[];
}) {
  return (
    <div className="p-3 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">Why {priority} priority?</span>
        </div>
        <Badge variant="outline" className="text-xs">
          Score: {Math.round(priorityScore)}
        </Badge>
      </div>
      
      <div className="space-y-2">
        {factors.map((factor, idx) => (
          <div key={idx} className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">{factor.label}</span>
              <span className="font-medium text-foreground">+{factor.contribution}</span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary/60 rounded-full transition-all"
                style={{ width: `${Math.min(100, (factor.contribution / 100) * 100)}%` }}
              />
            </div>
            <p className="text-[10px] text-muted-foreground">{factor.description}</p>
          </div>
        ))}
      </div>
      
      <div className="pt-2 border-t border-border/30 text-[10px] text-muted-foreground">
        {priority === 'high' && 'Score ≥200 → High priority'}
        {priority === 'medium' && 'Score 100-199 → Medium priority'}
        {priority === 'low' && 'Score <100 → Low priority'}
      </div>
    </div>
  );
}

export function GroupedNBACard({ group, onCompleteSubTask, onCancelSubTask, onCompleteAll, onViewAccount, onDueDateChange, onOwnerChange, assignableUsers }: GroupedNBACardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  
  const deliveryConfig = deliveryMethodConfig[group.deliveryMethod];
  const DeliveryIcon = deliveryConfig.icon;
  const pendingSubTasks = group.subTasks.filter(st => st.status !== 'completed');
  const progress = (group.completedSubTasks / group.totalSubTasks) * 100;

  const handleCompleteAll = () => {
    const pendingIds = pendingSubTasks.map(st => st.id);
    if (pendingIds.length > 0) {
      onCompleteAll(pendingIds);
    }
  };

  const handleDueDateChange = (subTaskId: string, newDate: Date, previousDate: Date | null) => {
    onDueDateChange?.(subTaskId, newDate, previousDate);
  };

  // Get due date status helper
  const getDueDateStatus = (dueDate: string | undefined) => {
    if (!dueDate) return null;
    const date = parseISO(dueDate);
    if (isPast(date) && !isToday(date)) {
      return { status: 'overdue', label: 'Overdue', color: 'text-destructive bg-destructive/10' };
    }
    if (isToday(date)) {
      return { status: 'today', label: 'Due today', color: 'text-amber-600 bg-amber-500/10' };
    }
    if (isTomorrow(date)) {
      return { status: 'tomorrow', label: 'Due tomorrow', color: 'text-blue-600 bg-blue-500/10' };
    }
    return null;
  };

  return (
    <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
      <div className={cn("glass rounded-xl border transition-all", priorityColors[group.priority])}>
        <CollapsibleTrigger className="w-full p-4 cursor-pointer">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* Delivery method icon */}
              <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center shrink-0", deliveryConfig.color)}>
                <DeliveryIcon className="w-5 h-5" />
              </div>
              
              <div className="text-left">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-foreground">{group.title}</p>
                  <Badge variant="outline" className="text-xs">
                    {deliveryConfig.label}
                  </Badge>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Badge variant="outline" className={cn("text-xs capitalize cursor-help", priorityBadgeColors[group.priority])}>
                          {group.priority}
                        </Badge>
                      </TooltipTrigger>
                      <TooltipContent side="bottom" className="w-72 p-0" sideOffset={5}>
                        <PriorityBreakdownTooltip 
                          priority={group.priority}
                          priorityScore={group.priorityScore}
                          factors={group.priorityFactors}
                        />
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <AccountHoverCard accountId={group.accountId} accountName={group.accountName}>
                    <Link 
                      to={`/accounts/${group.accountId}`}
                      className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Building2 className="w-3 h-3" />
                      <span className="hover:underline">{group.accountName}</span>
                    </Link>
                  </AccountHoverCard>
                  {group.opportunityId && group.opportunityName && (
                    <Link 
                      to={`/accounts/${group.accountId}?opportunityId=${group.opportunityId}`}
                      className="flex items-center gap-1 text-xs text-primary/80 hover:text-primary transition-colors"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Target className="w-3 h-3" />
                      <span className="hover:underline">{group.opportunityName}</span>
                    </Link>
                  )}
                  <Badge variant="outline" className="text-xs capitalize">
                    {group.stage}
                  </Badge>
                </div>
                {/* Priority reasoning */}
                {group.priorityReasoning && group.priorityReasoning.length > 0 && (
                  <div className="flex items-center gap-1.5 mt-1.5">
                    <TrendingUp className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">
                      {group.priorityReasoning.join(' • ')}
                    </span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              {/* Progress indicator */}
              <div className="flex items-center gap-2 min-w-[100px]">
                <Progress value={progress} className="h-2 w-16" />
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  {group.completedSubTasks}/{group.totalSubTasks}
                </span>
              </div>
              
              {isExpanded ? (
                <ChevronUp className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              )}
            </div>
          </div>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <div className="px-3 pb-3 pt-1 border-t border-border/50 space-y-1">
            {/* Sub-tasks list - compact */}
            {group.subTasks.map((subTask) => (
              <SubTaskItem
                key={subTask.id}
                subTask={subTask}
                accountId={group.accountId}
                opportunityId={group.opportunityId || null}
                onComplete={() => onCompleteSubTask(subTask.id)}
                onCancel={onCancelSubTask ? () => onCancelSubTask(subTask.id) : undefined}
                onDueDateChange={(newDate, prevDate) => handleDueDateChange(subTask.id, newDate, prevDate)}
                onOwnerChange={onOwnerChange}
                assignableUsers={assignableUsers}
                getDueDateStatus={getDueDateStatus}
              />
            ))}
            
            {/* Actions */}
            <div className="flex items-center gap-2 pt-2 border-t border-border/30 flex-wrap">
              <Button size="sm" variant="default" asChild>
                <Link to={`/accounts/${group.accountId}`}>
                  <Building2 className="w-4 h-4 mr-1" />
                  View Account
                </Link>
              </Button>
              
              {group.opportunityId && (
                <Button size="sm" variant="outline" asChild>
                  <Link to={`/accounts/${group.accountId}?opportunityId=${group.opportunityId}`}>
                    <Target className="w-4 h-4 mr-1" />
                    View Opportunity
                  </Link>
                </Button>
              )}
              
              {pendingSubTasks.length > 0 && (
                <Button size="sm" variant="outline" onClick={handleCompleteAll}>
                  <CheckSquare className="w-4 h-4 mr-1" />
                  Complete All ({pendingSubTasks.length})
                </Button>
              )}
            </div>
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}

interface SubTaskItemProps {
  subTask: SubTaskNBA;
  accountId: string;
  opportunityId: string | null;
  onComplete: () => void;
  onCancel?: () => void;
  onDueDateChange: (newDate: Date, previousDate: Date | null) => void;
  onOwnerChange?: (nbaId: string, accountId: string, opportunityId: string | null, newOwner: string | null) => void;
  assignableUsers?: AssignableUser[];
  getDueDateStatus: (dueDate: string | undefined) => { status: string; label: string; color: string } | null;
}

function getInitials(name: string | null, email: string): string {
  if (name) {
    return name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
  }
  return email.slice(0, 2).toUpperCase();
}

function formatOwnerName(owner: string): string {
  if (owner.includes('@')) {
    return owner.split('@')[0]
      .split('.')
      .map(part => part.charAt(0).toUpperCase() + part.slice(1))
      .join(' ');
  }
  return owner;
}

function SubTaskItem({ subTask, accountId, opportunityId, onComplete, onCancel, onDueDateChange, onOwnerChange, assignableUsers, getDueDateStatus }: SubTaskItemProps) {
  const [ownerPopoverOpen, setOwnerPopoverOpen] = useState(false);
  const isCompleted = subTask.status === 'completed';
  const isInactive = isCompleted;
  const hasAutoCompleteHint = subTask.autoCompleteConfidence !== undefined && subTask.autoCompleteConfidence > 0;
  const dueDateStatus = getDueDateStatus(subTask.dueDate);
  
  const canReassign = !isInactive && onOwnerChange && assignableUsers && assignableUsers.length > 0;

  const handleOwnerSelect = (email: string | null) => {
    if (onOwnerChange) {
      onOwnerChange(subTask.id, accountId, opportunityId, email);
    }
    setOwnerPopoverOpen(false);
  };

  // Find current owner's display info from assignable users
  const currentOwnerUser = assignableUsers?.find(u => 
    u.email.toLowerCase() === subTask.owner?.toLowerCase()
  );

  const renderOwnerBadge = () => {
    if (ownerConfig[subTask.owner as NBAOwner]) {
      const config = ownerConfig[subTask.owner as NBAOwner];
      const OwnerIcon = config.icon;
      return (
        <Badge 
          variant="outline" 
          className={cn(
            "text-xs h-7 px-3 flex items-center gap-1.5 font-medium",
            config.color,
            canReassign && "cursor-pointer hover:bg-accent"
          )}
        >
          <OwnerIcon className="w-3.5 h-3.5" />
          {config.fullLabel}
          {canReassign && <ChevronDown className="w-3 h-3 ml-1" />}
        </Badge>
      );
    } else {
      const displayName = currentOwnerUser?.full_name || formatOwnerName(subTask.owner || '');
      return (
        <Badge 
          variant="outline" 
          className={cn(
            "text-xs h-7 px-3 text-purple-600 bg-purple-500/10 border-purple-500/30 font-medium flex items-center gap-1.5",
            canReassign && "cursor-pointer hover:bg-purple-500/20"
          )}
        >
          <Avatar className="h-4 w-4">
            <AvatarFallback className="text-[8px] bg-purple-600/20 text-purple-600">
              {getInitials(currentOwnerUser?.full_name || null, subTask.owner || '')}
            </AvatarFallback>
          </Avatar>
          {displayName}
          {canReassign && <ChevronDown className="w-3 h-3 ml-1" />}
        </Badge>
      );
    }
  };

  return (
    <div className={cn(
      "flex items-center gap-3 py-2 px-2 rounded transition-colors group",
      isInactive && "opacity-50",
      !isInactive && hasAutoCompleteHint && "bg-amber-500/5",
      !isInactive && dueDateStatus?.status === 'overdue' && "bg-destructive/5"
    )}>
      {/* Checkbox */}
      <Checkbox 
        checked={isCompleted}
        onCheckedChange={() => !isCompleted && onComplete()}
        disabled={isCompleted}
        className="shrink-0 h-4 w-4"
      />
      
      {/* Action text - allow wrapping for visibility */}
      <p className={cn(
        "text-sm flex-1 min-w-0 leading-snug",
        isInactive && "line-through text-muted-foreground"
      )}>
        {subTask.action}
      </p>
      
      {/* Auto-completion hint - compact */}
      {hasAutoCompleteHint && !isInactive && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span className="inline-flex shrink-0">
                <Sparkles className="w-3 h-3 text-amber-500" />
              </span>
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-xs">
              <p className="text-xs">{subTask.autoCompleteReason}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
      
      {/* Due date status */}
      {!isInactive && dueDateStatus && (
        <Badge variant="outline" className={cn('text-xs h-6 px-2 shrink-0', dueDateStatus.color)}>
          {dueDateStatus.status === 'overdue' && <AlertTriangle className="w-3 h-3 mr-1" />}
          {dueDateStatus.label}
        </Badge>
      )}
      
      {/* Due date picker */}
      <DueDatePicker
        dueDate={subTask.dueDate}
        onDateChange={onDueDateChange}
        disabled={isInactive}
        compact
      />
      
      {/* Owner badge - clickable for reassignment */}
      {subTask.owner && (
        canReassign ? (
          <Popover open={ownerPopoverOpen} onOpenChange={setOwnerPopoverOpen}>
            <PopoverTrigger asChild onClick={(e) => e.stopPropagation()}>
              {renderOwnerBadge()}
            </PopoverTrigger>
            <PopoverContent className="w-64 p-0" align="end" onClick={(e) => e.stopPropagation()}>
              <Command>
                <CommandInput placeholder="Search team members..." className="h-9" />
                <CommandList>
                  <CommandEmpty>No team members found.</CommandEmpty>
                  <CommandGroup heading="Team Members">
                    {assignableUsers?.filter(u => !u.isExternal).map((user) => (
                      <CommandItem
                        key={user.email}
                        value={`${user.full_name || ''} ${user.email}`}
                        onSelect={() => handleOwnerSelect(user.email)}
                        className="flex items-center gap-2"
                      >
                        <Avatar className="h-5 w-5">
                          <AvatarFallback className="text-[10px]">
                            {getInitials(user.full_name, user.email)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm truncate">{user.full_name || user.email}</p>
                          {user.role && <p className="text-xs text-muted-foreground">{user.role}</p>}
                        </div>
                        {subTask.owner?.toLowerCase() === user.email.toLowerCase() && (
                          <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                        )}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                  {assignableUsers?.some(u => u.isExternal) && (
                    <CommandGroup heading="External Contacts">
                      {assignableUsers?.filter(u => u.isExternal).map((user) => (
                        <CommandItem
                          key={user.email}
                          value={`${user.full_name || ''} ${user.email}`}
                          onSelect={() => handleOwnerSelect(user.email)}
                          className="flex items-center gap-2"
                        >
                          <Avatar className="h-5 w-5">
                            <AvatarFallback className="text-[10px] bg-amber-500/20 text-amber-600">
                              {getInitials(user.full_name, user.email)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm truncate">{user.full_name || user.email}</p>
                            {user.role && <p className="text-xs text-muted-foreground">{user.role}</p>}
                          </div>
                          {subTask.owner?.toLowerCase() === user.email.toLowerCase() && (
                            <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                          )}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  )}
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        ) : (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                {renderOwnerBadge()}
              </TooltipTrigger>
              <TooltipContent side="top">
                <p className="text-xs">
                  {subTask.owner === 'prospect' && 'Customer action item'}
                  {subTask.owner === 'sales_rep' && 'Account Executive action'}
                  {subTask.owner === 'sales_engineer' && 'Solutions Engineer action'}
                  {typeof subTask.owner === 'string' && subTask.owner.includes('@') && `Assigned to ${subTask.owner}`}
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )
      )}
      
      {/* Priority badge - more prominent with full text */}
      <Badge 
        variant="outline" 
        className={cn(
          "text-xs h-7 px-3 font-semibold uppercase tracking-wide",
          subTask.priority === 'high' && 'border-destructive text-destructive bg-destructive/10',
          subTask.priority === 'medium' && 'border-layer-build text-layer-build bg-layer-build/10',
          subTask.priority === 'low' && 'border-muted-foreground text-muted-foreground bg-muted/50'
        )}
      >
        {subTask.priority}
      </Badge>
      
      {/* Cancel button */}
      {!isInactive && onCancel && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity shrink-0 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                onClick={(e) => {
                  e.stopPropagation();
                  onCancel();
                }}
              >
                <X className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs">Cancel task</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
    </div>
  );
}
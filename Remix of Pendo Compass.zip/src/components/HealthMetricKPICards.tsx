import { useMemo } from 'react';
import { Users, TrendingUp, Heart } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendIndicator } from '@/components/TrendIndicator';
import { useAccountHealthMetrics, MetricHistoryPoint } from '@/hooks/useAccountHealthMetrics';
import { cn } from '@/lib/utils';
import { LineChart, Line, ResponsiveContainer } from 'recharts';

interface HealthMetricKPICardsProps {
  accountId: string;
}

interface SparklineData {
  value: number;
  date: string;
}

const STATUS_COLORS: Record<string, string> = {
  cold: 'bg-blue-500/20 text-blue-500 border-blue-500/30',
  warming: 'bg-yellow-500/20 text-yellow-500 border-yellow-500/30',
  warm: 'bg-orange-500/20 text-orange-500 border-orange-500/30',
  hot: 'bg-red-500/20 text-red-500 border-red-500/30',
  champion: 'bg-green-500/20 text-green-500 border-green-500/30',
};

const STATUS_LABELS: Record<string, string> = {
  cold: 'Cold',
  warming: 'Warming',
  warm: 'Warm',
  hot: 'Hot',
  champion: 'Champion',
};

const SPARKLINE_COLORS: Record<string, string> = {
  improving: '#22c55e',
  stable: '#6b7280',
  declining: '#ef4444',
  unknown: '#6b7280',
};

function getSparklineData(history: MetricHistoryPoint[], currentValue: number | null): SparklineData[] {
  if (!history || history.length === 0) {
    // If no history, just show current value as a flat line
    if (currentValue !== null) {
      return [
        { value: currentValue, date: 'start' },
        { value: currentValue, date: 'now' },
      ];
    }
    return [];
  }

  // Convert history to sparkline data points
  const dataPoints: SparklineData[] = history.map((point) => {
    let value: number;
    if (typeof point.new_value === 'number') {
      value = point.new_value;
    } else if (typeof point.new_value === 'string') {
      // For status values, convert to numeric scale
      const statusOrder = ['cold', 'warming', 'warm', 'hot', 'champion'];
      const index = statusOrder.indexOf(point.new_value);
      value = index >= 0 ? (index + 1) * 20 : 50;
    } else {
      value = 50;
    }
    return {
      value,
      date: point.changed_at,
    };
  });

  // Add current value as the last point if different from last history point
  if (currentValue !== null && dataPoints.length > 0) {
    const lastHistoryValue = dataPoints[dataPoints.length - 1].value;
    if (Math.abs(lastHistoryValue - currentValue) > 0.1) {
      dataPoints.push({ value: currentValue, date: 'now' });
    }
  }

  return dataPoints;
}

function MiniSparkline({ data, trend }: { data: SparklineData[]; trend: string }) {
  if (data.length < 2) {
    return (
      <div className="w-full h-full flex items-center justify-center text-xs text-muted-foreground">
        No data
      </div>
    );
  }

  const color = SPARKLINE_COLORS[trend] || SPARKLINE_COLORS.unknown;

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data}>
        <Line
          type="monotone"
          dataKey="value"
          stroke={color}
          strokeWidth={2}
          dot={false}
          isAnimationActive={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

interface MetricKPICardProps {
  title: string;
  icon: React.ElementType;
  score: number | null;
  status: string | null;
  trend: 'improving' | 'stable' | 'declining' | 'unknown';
  history: MetricHistoryPoint[];
  isRelationship?: boolean;
  source?: 'account' | 'synthesis' | null;
}

function MetricKPICard({ 
  title, 
  icon: Icon, 
  score, 
  status, 
  trend, 
  history, 
  isRelationship = false,
  source = null
}: MetricKPICardProps) {
  const sparklineData = useMemo(() => {
    if (isRelationship) {
      // For relationship, convert status to numeric
      const statusOrder = ['cold', 'warming', 'warm', 'hot', 'champion'];
      const currentNumeric = status ? (statusOrder.indexOf(status) + 1) * 20 : null;
      return getSparklineData(history, currentNumeric);
    }
    return getSparklineData(history, score);
  }, [history, score, status, isRelationship]);

  const displayValue = isRelationship 
    ? STATUS_LABELS[status || ''] || '—'
    : score !== null ? `${score}%` : '—';

  const statusKey = status || (score !== null ? getStatusFromScore(score) : null);
  const statusColor = statusKey ? STATUS_COLORS[statusKey] : '';

  // Show "Baseline" when derived from synthesis with no history
  const showBaseline = source === 'synthesis' && history.length === 0;
  // Show actual trend only if we have history to calculate it
  const displayTrend = history.length >= 2 ? trend : 'unknown';

  return (
    <Card className="bg-muted/30 border-border/50">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-md bg-primary/10">
              <Icon className="w-3.5 h-3.5 text-primary" />
            </div>
            <span className="text-xs font-medium text-muted-foreground">{title}</span>
          </div>
          {showBaseline ? (
            <Badge variant="outline" className="text-[10px] px-1.5 py-0 bg-primary/10 text-primary border-primary/30">
              Baseline
            </Badge>
          ) : (
            <TrendIndicator trend={displayTrend} size="sm" />
          )}
        </div>
        
        <div className="flex items-end justify-between gap-2">
          <div className="space-y-1">
            <div className="text-xl font-semibold text-foreground">
              {displayValue}
            </div>
            {statusKey && (
              <Badge 
                variant="outline" 
                className={cn("text-[10px] px-1.5 py-0", statusColor)}
              >
                {STATUS_LABELS[statusKey] || statusKey}
              </Badge>
            )}
          </div>
          
          <div className="w-16 h-8 flex-shrink-0">
            <MiniSparkline data={sparklineData} trend={displayTrend} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function getStatusFromScore(score: number): string {
  if (score >= 80) return 'champion';
  if (score >= 60) return 'hot';
  if (score >= 40) return 'warm';
  if (score >= 20) return 'warming';
  return 'cold';
}

export function HealthMetricKPICards({ accountId }: HealthMetricKPICardsProps) {
  const { data: metrics, isLoading } = useAccountHealthMetrics(accountId);

  if (isLoading) {
    return (
      <div className="grid grid-cols-3 gap-3">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="bg-muted/30 border-border/50 animate-pulse">
            <CardContent className="p-4 h-24" />
          </Card>
        ))}
      </div>
    );
  }

  if (!metrics) {
    return null;
  }

  return (
    <div className="grid grid-cols-3 gap-3">
      <MetricKPICard
        title="Engagement"
        icon={Users}
        score={metrics.engagement.current}
        status={metrics.engagement.status}
        trend={metrics.engagement.trend}
        history={metrics.engagement.history}
        source={metrics.engagement.source}
      />
      <MetricKPICard
        title="Momentum"
        icon={TrendingUp}
        score={metrics.momentum.current}
        status={metrics.momentum.status}
        trend={metrics.momentum.trend}
        history={metrics.momentum.history}
        source={metrics.momentum.source}
      />
      <MetricKPICard
        title="Relationship"
        icon={Heart}
        score={null}
        status={metrics.relationship.status}
        trend={metrics.relationship.trend}
        history={metrics.relationship.history}
        isRelationship
        source={metrics.relationship.source}
      />
    </div>
  );
}

import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { UserX, Eye } from 'lucide-react';

export function ImpersonationBanner() {
  const { impersonatedUser, stopImpersonating } = useAuth();

  if (!impersonatedUser) return null;

  return (
    <div className="bg-amber-500 text-amber-950 px-4 py-2 flex items-center justify-center gap-4">
      <Eye className="w-4 h-4" />
      <span className="font-medium text-sm">
        Viewing as: <span className="font-bold">{impersonatedUser.email}</span>
        {impersonatedUser.full_name && ` (${impersonatedUser.full_name})`}
      </span>
      <Button 
        size="sm" 
        variant="outline"
        onClick={stopImpersonating}
        className="h-7 bg-amber-600 border-amber-700 text-amber-50 hover:bg-amber-700 hover:text-white"
      >
        <UserX className="w-3 h-3 mr-1" />
        Stop Impersonating
      </Button>
    </div>
  );
}
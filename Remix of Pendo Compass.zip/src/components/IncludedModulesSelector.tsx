import { useState, useMemo, useEffect } from 'react';
import { Check, Package, X, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { cn } from '@/lib/utils';

interface ModulePricing {
  id: string;
  module_name: string;
  module_type: string;
  functional_area_id: string | null;
  fixed_cost: number;
  per_mau_cost: number;
  mau_percentage: number;
  is_active: boolean;
}

interface FunctionalArea {
  id: string;
  name: string;
}

interface IncludedModulesSelectorProps {
  selectedModuleIds: string[];
  onSelectionChange: (moduleIds: string[]) => void;
  disabled?: boolean;
  opportunityId?: string;
}

export function IncludedModulesSelector({
  selectedModuleIds,
  onSelectionChange,
  disabled = false,
  opportunityId,
}: IncludedModulesSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);

  // Fetch module pricing
  const { data: modules } = useQuery({
    queryKey: ['module-pricing-active'],
    queryFn: async () => {
      const response = await gateway
        .from('module_pricing')
        .select('id, module_name, module_type, functional_area_id, fixed_cost, per_mau_cost, mau_percentage, is_active')
        .eq('is_active', true)
        .order('module_name')
        .execute();
      if (response.error) throw new Error(response.error.message);
      return (response.data || []) as ModulePricing[];
    },
  });

  // Fetch functional areas
  const { data: functionalAreas } = useQuery({
    queryKey: ['functional-areas'],
    queryFn: async () => {
      const response = await gateway
        .from('functional_areas')
        .select('id, name')
        .order('sort_order')
        .execute();
      if (response.error) throw new Error(response.error.message);
      return (response.data || []) as FunctionalArea[];
    },
  });

  // Fetch required modules from linked use cases
  const { data: useCaseModuleIds } = useQuery({
    queryKey: ['use-case-required-modules', opportunityId],
    queryFn: async () => {
      if (!opportunityId) return [];
      const response = await gateway
        .from('account_use_cases')
        .select('required_module_ids')
        .eq('opportunity_id', opportunityId)
        .execute();
      if (response.error) throw new Error(response.error.message);
      const allIds = new Set<string>();
      (response.data || []).forEach((uc: any) => {
        (uc.required_module_ids || []).forEach((id: string) => allIds.add(id));
      });
      return [...allIds];
    },
    enabled: !!opportunityId,
  });

  // Compute suggested modules not yet selected
  const suggestedModuleIds = useMemo(() => {
    if (!useCaseModuleIds) return [];
    return useCaseModuleIds.filter(id => !selectedModuleIds.includes(id));
  }, [useCaseModuleIds, selectedModuleIds]);

  const suggestedModules = modules?.filter(m => suggestedModuleIds.includes(m.id)) || [];

  // Group modules by functional area
  const modulesByArea = useMemo(() => {
    if (!modules || !functionalAreas) return new Map<string, ModulePricing[]>();
    
    const areaMap = new Map<string, ModulePricing[]>();
    const noArea: ModulePricing[] = [];
    
    functionalAreas.forEach(area => {
      areaMap.set(area.name, []);
    });
    
    modules.forEach(mod => {
      if (mod.functional_area_id) {
        const area = functionalAreas.find(a => a.id === mod.functional_area_id);
        if (area) {
          const existing = areaMap.get(area.name) || [];
          existing.push(mod);
          areaMap.set(area.name, existing);
        } else {
          noArea.push(mod);
        }
      } else {
        noArea.push(mod);
      }
    });
    
    if (noArea.length > 0) {
      areaMap.set('Platform & Core', noArea);
    }
    
    return areaMap;
  }, [modules, functionalAreas]);

  const toggleModule = (moduleId: string) => {
    if (selectedModuleIds.includes(moduleId)) {
      onSelectionChange(selectedModuleIds.filter(id => id !== moduleId));
    } else {
      onSelectionChange([...selectedModuleIds, moduleId]);
    }
  };

  const addAllSuggested = () => {
    onSelectionChange([...selectedModuleIds, ...suggestedModuleIds]);
  };

  const selectedCount = selectedModuleIds.length;
  const selectedModules = modules?.filter(m => selectedModuleIds.includes(m.id)) || [];

  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium">Included Modules</Label>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button 
            variant="outline" 
            className="w-full justify-start h-auto min-h-10 py-2"
            disabled={disabled}
          >
            <Package className="w-4 h-4 mr-2 shrink-0" />
            {selectedCount === 0 ? (
              <span className="text-muted-foreground">Select modules in this deal...</span>
            ) : (
              <div className="flex flex-wrap gap-1">
                {selectedModules.slice(0, 3).map(mod => (
                  <Badge key={mod.id} variant="secondary" className="text-xs">
                    {mod.module_name}
                  </Badge>
                ))}
                {selectedCount > 3 && (
                  <Badge variant="secondary" className="text-xs">
                    +{selectedCount - 3} more
                  </Badge>
                )}
              </div>
            )}
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Select Modules in This Deal</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground mb-4">
            Select the product modules that are included in this opportunity. 
            These will be subtracted from the whitespace calculation.
          </p>
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-4">
              {Array.from(modulesByArea.entries()).map(([areaName, areaModules]) => {
                if (areaModules.length === 0) return null;
                const selectedInArea = areaModules.filter(m => selectedModuleIds.includes(m.id)).length;
                const suggestedInArea = areaModules.filter(m => suggestedModuleIds.includes(m.id)).length;
                
                return (
                  <Collapsible key={areaName} defaultOpen={selectedInArea > 0 || suggestedInArea > 0}>
                    <CollapsibleTrigger className="flex items-center justify-between w-full p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                      <span className="font-medium text-sm">{areaName}</span>
                      <div className="flex items-center gap-2">
                        {suggestedInArea > 0 && (
                          <Badge className="text-xs bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300 border-0">
                            <Sparkles className="w-3 h-3 mr-0.5" />
                            {suggestedInArea} suggested
                          </Badge>
                        )}
                        {selectedInArea > 0 && (
                          <Badge variant="secondary" className="text-xs">
                            {selectedInArea} selected
                          </Badge>
                        )}
                      </div>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="pt-2">
                      <div className="space-y-1 pl-2">
                        {areaModules.map(mod => {
                          const isSuggested = suggestedModuleIds.includes(mod.id);
                          return (
                            <div
                              key={mod.id}
                              className={cn(
                                "flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-colors",
                                selectedModuleIds.includes(mod.id)
                                  ? "bg-primary/10 border border-primary/30"
                                  : isSuggested
                                  ? "bg-amber-50 border border-amber-200 dark:bg-amber-900/10 dark:border-amber-800/30"
                                  : "hover:bg-muted/50"
                              )}
                              onClick={() => toggleModule(mod.id)}
                            >
                              <Checkbox
                                checked={selectedModuleIds.includes(mod.id)}
                                onCheckedChange={() => toggleModule(mod.id)}
                              />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium truncate flex items-center gap-1.5">
                                  {mod.module_name}
                                  {isSuggested && (
                                    <span className="text-[10px] font-normal text-amber-600 dark:text-amber-400">from use cases</span>
                                  )}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {mod.module_type === 'platform' ? 'Platform' : 
                                   mod.module_type === 'mau' ? 'Per-MAU' : 'Add-on Module'}
                                </p>
                              </div>
                              {selectedModuleIds.includes(mod.id) && (
                                <Check className="w-4 h-4 text-primary shrink-0" />
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                );
              })}
            </div>
          </ScrollArea>
          <div className="flex items-center justify-between pt-4 border-t">
            <span className="text-sm text-muted-foreground">
              {selectedCount} module{selectedCount !== 1 ? 's' : ''} selected
            </span>
            <Button onClick={() => setIsOpen(false)}>Done</Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Suggested modules from use cases */}
      {suggestedModules.length > 0 && !disabled && (
        <div className="rounded-lg border border-amber-200 bg-amber-50/50 dark:border-amber-800/30 dark:bg-amber-900/10 p-3 space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-amber-800 dark:text-amber-300 flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              Required by linked use cases
            </p>
            <Button variant="ghost" size="sm" className="h-6 text-xs text-amber-700 dark:text-amber-400 hover:text-amber-900" onClick={addAllSuggested}>
              Add all
            </Button>
          </div>
          <div className="flex flex-wrap gap-1">
            {suggestedModules.map(mod => (
              <Badge
                key={mod.id}
                variant="outline"
                className="text-xs cursor-pointer border-amber-300 text-amber-800 dark:border-amber-700 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900/30"
                onClick={() => toggleModule(mod.id)}
              >
                + {mod.module_name}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Show selected modules as removable badges */}
      {selectedModules.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {selectedModules.map(mod => (
            <Badge
              key={mod.id}
              variant="secondary"
              className="gap-1 pr-1 cursor-pointer hover:bg-destructive/20"
              onClick={() => !disabled && toggleModule(mod.id)}
            >
              {mod.module_name}
              {!disabled && <X className="w-3 h-3" />}
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}

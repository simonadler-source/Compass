import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Sparkles, CheckCircle2, ShieldCheck, ArrowUp, ArrowDown, Clock, Zap, RefreshCw } from 'lucide-react';
import { formatDistanceToNow, differenceInHours, differenceInDays } from 'date-fns';

interface NewBadgeProps {
  createdAt: string;
  hoursThreshold?: number;
  className?: string;
}

/**
 * Shows a "New" badge for recently created items
 */
export function NewBadge({ createdAt, hoursThreshold = 24, className }: NewBadgeProps) {
  const created = new Date(createdAt);
  const hours = differenceInHours(new Date(), created);
  
  if (hours > hoursThreshold) return null;
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant="secondary"
            className={cn(
              "text-[10px] px-1.5 py-0 gap-0.5 bg-emerald-500/10 text-emerald-600 border-emerald-500/30 animate-pulse",
              className
            )}
          >
            <Sparkles className="w-2.5 h-2.5" />
            New
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>Detected {formatDistanceToNow(created, { addSuffix: true })}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface ValidationBadgeProps {
  validationCount: number | null;
  lastValidatedAt: string | null;
  confidenceScore: number | null;
  className?: string;
}

/**
 * Shows validation count and confidence score
 */
export function ValidationBadge({ 
  validationCount, 
  lastValidatedAt, 
  confidenceScore,
  className 
}: ValidationBadgeProps) {
  const count = validationCount || 0;
  const confidence = confidenceScore ? Math.round(confidenceScore * 100) : null;
  
  if (count === 0 && !confidence) return null;
  
  const getConfidenceColor = (conf: number) => {
    if (conf >= 80) return 'text-emerald-600 border-emerald-500/30';
    if (conf >= 60) return 'text-blue-600 border-blue-500/30';
    if (conf >= 40) return 'text-amber-600 border-amber-500/30';
    return 'text-muted-foreground border-muted';
  };
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={cn("flex items-center gap-1", className)}>
            {count > 0 && (
              <Badge 
                variant="outline"
                className="text-[10px] px-1.5 py-0 gap-0.5"
              >
                <ShieldCheck className="w-2.5 h-2.5" />
                {count}x
              </Badge>
            )}
            {confidence !== null && (
              <Badge 
                variant="outline"
                className={cn("text-[10px] px-1.5 py-0", getConfidenceColor(confidence))}
              >
                {confidence}%
              </Badge>
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <div className="text-xs space-y-1">
            {count > 0 && <p>Validated {count} time{count !== 1 ? 's' : ''}</p>}
            {confidence !== null && <p>AI confidence: {confidence}%</p>}
            {lastValidatedAt && (
              <p className="text-muted-foreground">
                Last validated {formatDistanceToNow(new Date(lastValidatedAt), { addSuffix: true })}
              </p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface StatusChangeIndicatorProps {
  previousStatus?: string | null;
  currentStatus: string;
  changedAt?: string | null;
  className?: string;
}

/**
 * Shows visual indicator for status changes
 */
export function StatusChangeIndicator({ 
  previousStatus, 
  currentStatus, 
  changedAt,
  className 
}: StatusChangeIndicatorProps) {
  if (!previousStatus || previousStatus === currentStatus) return null;
  
  const statusProgression: Record<string, number> = {
    identified: 1,
    proposed: 2,
    validated: 3,
    in_progress: 4,
    implemented: 5,
    blocked: 0,
    disqualified: 0,
  };
  
  const isProgression = (statusProgression[currentStatus] || 0) > (statusProgression[previousStatus] || 0);
  const isRegression = (statusProgression[currentStatus] || 0) < (statusProgression[previousStatus] || 0);
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant="outline"
            className={cn(
              "text-[10px] px-1.5 py-0 gap-0.5 animate-pulse",
              isProgression && "text-emerald-600 border-emerald-500/30 bg-emerald-500/5",
              isRegression && "text-amber-600 border-amber-500/30 bg-amber-500/5",
              className
            )}
          >
            {isProgression ? <ArrowUp className="w-2.5 h-2.5" /> : <ArrowDown className="w-2.5 h-2.5" />}
            {isProgression ? 'Advanced' : 'Changed'}
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>Changed from "{previousStatus}" to "{currentStatus}"</p>
          {changedAt && (
            <p className="text-muted-foreground text-xs mt-1">
              {formatDistanceToNow(new Date(changedAt), { addSuffix: true })}
            </p>
          )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface CompletedBadgeProps {
  completedAt: string;
  autoCompleted?: boolean;
  autoCompleteReason?: string | null;
  className?: string;
}

/**
 * Shows completion indicator with auto-complete info
 */
export function CompletedBadge({ 
  completedAt, 
  autoCompleted, 
  autoCompleteReason,
  className 
}: CompletedBadgeProps) {
  const isRecent = differenceInDays(new Date(), new Date(completedAt)) < 7;
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant="outline"
            className={cn(
              "text-[10px] px-1.5 py-0 gap-0.5",
              isRecent ? "text-emerald-600 border-emerald-500/30 bg-emerald-500/10" : "text-muted-foreground",
              autoCompleted && "border-purple-500/30 text-purple-600 bg-purple-500/10",
              isRecent && "animate-pulse",
              className
            )}
          >
            {autoCompleted ? <Zap className="w-2.5 h-2.5" /> : <CheckCircle2 className="w-2.5 h-2.5" />}
            {autoCompleted ? 'Auto' : 'Done'}
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <div className="text-xs space-y-1">
            <p>Completed {formatDistanceToNow(new Date(completedAt), { addSuffix: true })}</p>
            {autoCompleted && autoCompleteReason && (
              <p className="text-muted-foreground max-w-[200px]">{autoCompleteReason}</p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface SentimentChangeIndicatorProps {
  previousSentiment?: number | null;
  currentSentiment: number | null;
  className?: string;
}

/**
 * Shows sentiment trajectory indicator
 */
export function SentimentChangeIndicator({ 
  previousSentiment, 
  currentSentiment,
  className 
}: SentimentChangeIndicatorProps) {
  if (previousSentiment == null || currentSentiment == null) return null;
  if (previousSentiment === currentSentiment) return null;
  
  const delta = currentSentiment - previousSentiment;
  const isImproving = delta > 0;
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant="outline"
            className={cn(
              "text-[10px] px-1.5 py-0 gap-0.5",
              isImproving 
                ? "text-emerald-600 border-emerald-500/30 bg-emerald-500/5" 
                : "text-red-600 border-red-500/30 bg-red-500/5",
              className
            )}
          >
            {isImproving ? <ArrowUp className="w-2.5 h-2.5" /> : <ArrowDown className="w-2.5 h-2.5" />}
            {isImproving ? '+' : ''}{delta}
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>Sentiment changed from {previousSentiment} to {currentSentiment}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface RecentlyUpdatedBadgeProps {
  updatedAt: string;
  hoursThreshold?: number;
  className?: string;
}

/**
 * Shows "Updated" badge for recently modified items
 */
export function RecentlyUpdatedBadge({ updatedAt, hoursThreshold = 24, className }: RecentlyUpdatedBadgeProps) {
  const updated = new Date(updatedAt);
  const hours = differenceInHours(new Date(), updated);
  
  if (hours > hoursThreshold) return null;
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant="secondary"
            className={cn(
              "text-[10px] px-1.5 py-0 gap-0.5 bg-blue-500/10 text-blue-600 border-blue-500/30",
              className
            )}
          >
            <RefreshCw className="w-2.5 h-2.5" />
            Updated
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>Updated {formatDistanceToNow(updated, { addSuffix: true })}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface SourceTranscriptBadgeProps {
  hasSource: boolean;
  className?: string;
}

/**
 * Indicates item was extracted from a transcript
 */
export function SourceTranscriptBadge({ hasSource, className }: SourceTranscriptBadgeProps) {
  if (!hasSource) return null;
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant="outline"
            className={cn("text-[10px] px-1.5 py-0 text-muted-foreground", className)}
          >
            <Clock className="w-2.5 h-2.5 mr-0.5" />
            From call
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>Extracted from meeting transcript</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MEETING_TYPES, MeetingType, useUpdateTranscriptMeetingType } from "@/hooks/useMeetingTypeSelector";
import { toast } from "sonner";

interface MeetingTypeSelectorProps {
  transcriptId: string;
  currentType: MeetingType | null;
  onTypeChange?: (type: MeetingType) => void;
  disabled?: boolean;
}

export function MeetingTypeSelector({ 
  transcriptId, 
  currentType, 
  onTypeChange,
  disabled = false 
}: MeetingTypeSelectorProps) {
  const updateMutation = useUpdateTranscriptMeetingType();
  
  const handleChange = async (value: MeetingType) => {
    try {
      await updateMutation.mutateAsync({ transcriptId, meetingType: value });
      onTypeChange?.(value);
      toast.success("Meeting type updated");
    } catch (error) {
      toast.error("Failed to update meeting type");
    }
  };
  
  return (
    <Select 
      value={currentType || 'discovery'} 
      onValueChange={handleChange}
      disabled={disabled || updateMutation.isPending}
    >
      <SelectTrigger className="w-[180px]">
        <SelectValue placeholder="Select type" />
      </SelectTrigger>
      <SelectContent>
        {MEETING_TYPES.map((type) => (
          <SelectItem key={type.value} value={type.value}>
            <div className="flex flex-col">
              <span>{type.label}</span>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

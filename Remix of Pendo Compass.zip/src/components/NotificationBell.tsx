import { Bell, Check, CheckCheck, Users, AlertTriangle, ChevronDown, ChevronRight, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useNotifications } from "@/hooks/useNotifications";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export function NotificationBell() {
  const { notifications, unreadCount, markAsRead, markAllAsRead } =
    useNotifications();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [expandedNotifications, setExpandedNotifications] = useState<Set<string>>(new Set());

  const toggleExpanded = (id: string) => {
    setExpandedNotifications(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const getIcon = (type: string) => {
    switch (type) {
      case "team_meeting_sync":
        return <Users className="h-4 w-4 text-primary" />;
      case "credits_exhausted":
        return <AlertTriangle className="h-4 w-4 text-destructive" />;
      default:
        return <Bell className="h-4 w-4 text-muted-foreground" />;
    }
  };

  // Navigate to a specific meeting/account
  const navigateToMeeting = (meeting: { accountId?: string; accountName?: string; opportunityId?: string }) => {
    if (meeting.opportunityId) {
      navigate(`/opportunities/${meeting.opportunityId}`);
      setOpen(false);
    } else if (meeting.accountId) {
      navigate(`/accounts/${meeting.accountId}`);
      setOpen(false);
    }
  };

  const handleNotificationClick = (
    e: React.MouseEvent,
    notification: {
    id: string;
    type: string;
    is_read: boolean;
    data: Record<string, any> | null;
    }
  ) => {
    // Don't navigate if clicking on expand button or meeting list
    const target = e.target as HTMLElement;
    if (target.closest('[data-expand-trigger]') || target.closest('[data-meeting-item]')) {
      return;
    }

    // Mark as read if unread
    if (!notification.is_read) {
      markAsRead(notification.id);
    }

    // Navigate based on notification type and data
    const data = notification.data || {};
    
    switch (notification.type) {
      case "team_meeting_sync":
        // If multiple meetings, don't auto-navigate - let user pick from expanded list
        if (data.meetings?.length > 1) {
          toggleExpanded(notification.id);
        } else if (data.meetings?.length === 1) {
          // Single meeting - navigate directly
          navigateToMeeting(data.meetings[0]);
        } else if (data.account_id) {
          navigate(`/accounts/${data.account_id}`);
          setOpen(false);
        } else {
          navigate("/momentum");
          setOpen(false);
        }
        break;
      case "credits_exhausted":
        // Navigate to settings
        navigate("/settings");
        setOpen(false);
        break;
      case "nba_created":
        if (data.account_id) {
          navigate(`/accounts/${data.account_id}?tab=nbas`);
          setOpen(false);
        }
        break;
      case "transcript_ready":
        if (data.account_id) {
          navigate(`/accounts/${data.account_id}?tab=transcripts`);
          setOpen(false);
        } else {
          navigate("/transcripts");
          setOpen(false);
        }
        break;
      case "account_update":
        if (data.account_id) {
          navigate(`/accounts/${data.account_id}`);
          setOpen(false);
        }
        break;
      default:
        // For unknown types, check if there's an account_id in data
        if (data.account_id) {
          navigate(`/accounts/${data.account_id}`);
          setOpen(false);
        } else if (data.link) {
          navigate(data.link);
          setOpen(false);
        }
        break;
    }
  };

  // Render meeting list for expandable notifications
  const renderMeetingsList = (meetings: Array<{ title: string; accountName: string; accountId: string; opportunityId?: string; teamMembers?: string[] }>) => {
    // Group by account for cleaner display
    const byAccount = meetings.reduce((acc, meeting) => {
      const key = meeting.accountId;
      if (!acc[key]) {
        acc[key] = { accountName: meeting.accountName, accountId: meeting.accountId, meetings: [] };
      }
      acc[key].meetings.push(meeting);
      return acc;
    }, {} as Record<string, { accountName: string; accountId: string; meetings: typeof meetings }>);

    return (
      <div className="mt-2 space-y-2" data-meeting-item>
        {Object.values(byAccount).map((group) => (
          <div 
            key={group.accountId}
            className="bg-muted/50 rounded-md p-2 hover:bg-muted transition-colors cursor-pointer"
            onClick={() => navigateToMeeting({ accountId: group.accountId })}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-foreground">{group.accountName}</span>
              <span className="text-[10px] text-muted-foreground">{group.meetings.length} meeting{group.meetings.length > 1 ? 's' : ''}</span>
            </div>
            <div className="mt-1 space-y-1">
              {group.meetings.slice(0, 3).map((meeting, idx) => (
                <p key={idx} className="text-[11px] text-muted-foreground truncate">
                  • {meeting.title}
                </p>
              ))}
              {group.meetings.length > 3 && (
                <p className="text-[10px] text-muted-foreground/70">
                  +{group.meetings.length - 3} more...
                </p>
              )}
            </div>
            <div className="flex items-center gap-1 mt-1.5 text-[10px] text-primary">
              <ExternalLink className="h-2.5 w-2.5" />
              <span>Go to account</span>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center font-medium">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <h4 className="font-semibold text-sm">Notifications</h4>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="h-auto p-1 text-xs text-muted-foreground hover:text-foreground"
              onClick={() => markAllAsRead()}
            >
              <CheckCheck className="h-3 w-3 mr-1" />
              Mark all read
            </Button>
          )}
        </div>

        <ScrollArea className="h-[300px]">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[200px] text-muted-foreground">
              <Bell className="h-8 w-8 mb-2 opacity-50" />
              <p className="text-sm">No notifications</p>
            </div>
          ) : (
            <div className="divide-y">
              {notifications.map((notification) => (
                <div key={notification.id}>
                  {/* Check if this is an expandable multi-meeting notification */}
                  {notification.type === "team_meeting_sync" && notification.data?.meetings?.length > 1 ? (
                    <Collapsible
                      open={expandedNotifications.has(notification.id)}
                      onOpenChange={() => toggleExpanded(notification.id)}
                    >
                      <div
                        className={cn(
                          "px-4 py-3 transition-colors",
                          !notification.is_read && "bg-primary/5"
                        )}
                        onClick={(e) => handleNotificationClick(e, notification)}
                      >
                        <div className="flex gap-3">
                          <div className="flex-shrink-0 mt-0.5">
                            {getIcon(notification.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2">
                              <p
                                className={cn(
                                  "text-sm font-medium",
                                  !notification.is_read && "text-foreground",
                                  notification.is_read && "text-muted-foreground"
                                )}
                              >
                                {notification.title}
                              </p>
                              <div className="flex items-center gap-1.5">
                                {!notification.is_read && (
                                  <span className="flex-shrink-0 h-2 w-2 rounded-full bg-primary" />
                                )}
                                <CollapsibleTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-5 w-5 p-0"
                                    data-expand-trigger
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (!notification.is_read) {
                                        markAsRead(notification.id);
                                      }
                                    }}
                                  >
                                    {expandedNotifications.has(notification.id) ? (
                                      <ChevronDown className="h-3.5 w-3.5" />
                                    ) : (
                                      <ChevronRight className="h-3.5 w-3.5" />
                                    )}
                                  </Button>
                                </CollapsibleTrigger>
                              </div>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              Click to see {notification.data.meetings.length} affected accounts
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {formatDistanceToNow(new Date(notification.created_at), {
                                addSuffix: true,
                              })}
                            </p>
                            <CollapsibleContent>
                              {renderMeetingsList(notification.data.meetings)}
                            </CollapsibleContent>
                          </div>
                        </div>
                      </div>
                    </Collapsible>
                  ) : (
                    /* Standard notification display */
                    <div
                      className={cn(
                        "px-4 py-3 hover:bg-muted/50 transition-colors cursor-pointer",
                        !notification.is_read && "bg-primary/5"
                      )}
                      onClick={(e) => handleNotificationClick(e, notification)}
                    >
                      <div className="flex gap-3">
                        <div className="flex-shrink-0 mt-0.5">
                          {getIcon(notification.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <p
                              className={cn(
                                "text-sm font-medium truncate",
                                !notification.is_read && "text-foreground",
                                notification.is_read && "text-muted-foreground"
                              )}
                            >
                              {notification.title}
                            </p>
                            {!notification.is_read && (
                              <span className="flex-shrink-0 h-2 w-2 rounded-full bg-primary" />
                            )}
                          </div>
                          {notification.message && (
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2 whitespace-pre-wrap">
                              {notification.message}
                            </p>
                          )}
                          <p className="text-xs text-muted-foreground mt-1">
                            {formatDistanceToNow(new Date(notification.created_at), {
                              addSuffix: true,
                            })}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useOneOnOnePrep, PrepOpportunity, HolisticCoachingData, CoachingCallInsight, CoachingAccountGroup, PrepEvalOpportunity } from '@/hooks/useOneOnOnePrep';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import {
  Users,
  Target,
  DollarSign,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle2,
  Gauge,
  FlaskConical,
  Lightbulb,
  Calendar,
  ExternalLink,
  RefreshCw,
  FileText,
  Video,
  Printer,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Star,
  Minus,
  ArrowUp,
  ArrowDown,
  Brain,
  MessageSquareQuote,
  Zap,
  ShieldAlert,
  Activity,
} from 'lucide-react';

interface OneOnOnePrepSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  memberEmail: string | null;
  memberName: string | null;
}

const statusConfig: Record<PrepOpportunity['status'], { label: string; color: string; icon: React.ReactNode }> = {
  at_risk: { label: 'At Risk', color: 'bg-red-500/15 text-red-700 border-red-500/30', icon: <AlertTriangle className="h-3 w-3" /> },
  stalled: { label: 'Stalled', color: 'bg-amber-500/15 text-amber-700 border-amber-500/30', icon: <Clock className="h-3 w-3" /> },
  eval_ready: { label: 'Eval Ready', color: 'bg-blue-500/15 text-blue-700 border-blue-500/30', icon: <FlaskConical className="h-3 w-3" /> },
  progressing: { label: 'Progressing', color: 'bg-green-500/15 text-green-700 border-green-500/30', icon: <TrendingUp className="h-3 w-3" /> },
  healthy: { label: 'Healthy', color: 'bg-muted text-muted-foreground', icon: <CheckCircle2 className="h-3 w-3" /> },
};

function getScoreColor(score: number, max: number = 5) {
  const pct = score / max;
  if (pct >= 0.7) return 'text-green-700 bg-green-500/10';
  if (pct >= 0.5) return 'text-amber-700 bg-amber-500/10';
  return 'text-red-700 bg-red-500/10';
}

function getScoreBarColor(score: number, max: number = 5) {
  const pct = score / max;
  if (pct >= 0.7) return 'bg-green-500';
  if (pct >= 0.5) return 'bg-amber-500';
  return 'bg-red-500';
}

function TrendIcon({ trend }: { trend: 'improving' | 'declining' | 'stable' }) {
  if (trend === 'improving') return <ArrowUp className="h-3 w-3 text-green-600" />;
  if (trend === 'declining') return <ArrowDown className="h-3 w-3 text-red-600" />;
  return <Minus className="h-3 w-3 text-muted-foreground" />;
}

export function OneOnOnePrepSheet({ open, onOpenChange, memberEmail, memberName }: OneOnOnePrepSheetProps) {
  const navigate = useNavigate();
  const { prepData, holisticCoaching, isLoading } = useOneOnOnePrep(memberEmail, open);
  const [expandedAccount, setExpandedAccount] = useState<string | null>(null);

  const displayName = memberName || memberEmail || 'Team Member';
  const today = format(new Date(), 'EEEE, MMMM d, yyyy');

  const handlePrint = () => {
    document.body.classList.add('printing-prep-sheet');

    const cleanup = () => {
      document.body.classList.remove('printing-prep-sheet');
      window.removeEventListener('afterprint', cleanup);
    };

    window.addEventListener('afterprint', cleanup);
    window.print();
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="prep-sheet-print-dialog !w-[96vw] !max-w-none p-0 print:!w-full print:!max-w-none print:!static print:!h-auto print:!shadow-none print:!border-none print:!transform-none">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="px-6 pt-6 pb-4 border-b bg-gradient-to-br from-primary/5 to-accent/5">
            <SheetHeader>
              <div className="flex items-center justify-between">
                <div>
                  <SheetTitle className="text-xl flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    1:1 Prep — {displayName}
                  </SheetTitle>
                  <p className="text-sm text-muted-foreground mt-1">{today}</p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handlePrint}
                  className="print:hidden"
                >
                  <Printer className="h-4 w-4 mr-1" />
                  Print
                </Button>
              </div>
            </SheetHeader>
          </div>

          {isLoading || !prepData ? (
            <div className="flex-1 flex items-center justify-center">
              <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <ScrollArea className="flex-1">
              <div className="px-6 py-4 space-y-5">
                {/* Quick Stats Bar */}
                <div className="grid grid-cols-4 gap-3">
                  <StatMini icon={<Target className="h-4 w-4" />} label="Active Opps" value={prepData.summary.totalOpps} />
                  <StatMini icon={<DollarSign className="h-4 w-4" />} label="Pipeline" value={`$${(prepData.summary.totalPipeline / 1000).toFixed(0)}k`} />
                  <StatMini icon={<Video className="h-4 w-4" />} label="Meetings (14d)" value={prepData.summary.meetingsLast14d} />
                  <StatMini icon={<CheckCircle2 className="h-4 w-4" />} label="NBAs Done (14d)" value={prepData.summary.nbasCompletedCount} />
                </div>

                {/* Status Overview */}
                <div className="flex flex-wrap gap-2">
                  {prepData.summary.atRiskCount > 0 && (
                    <Badge variant="outline" className="bg-red-500/10 text-red-700 border-red-500/30">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      {prepData.summary.atRiskCount} At Risk
                    </Badge>
                  )}
                  {prepData.summary.stalledCount > 0 && (
                    <Badge variant="outline" className="bg-amber-500/10 text-amber-700 border-amber-500/30">
                      <Clock className="h-3 w-3 mr-1" />
                      {prepData.summary.stalledCount} Stalled
                    </Badge>
                  )}
                  {prepData.summary.evalReadyCount > 0 && (
                    <Badge variant="outline" className="bg-blue-500/10 text-blue-700 border-blue-500/30">
                      <FlaskConical className="h-3 w-3 mr-1" />
                      {prepData.summary.evalReadyCount} Eval Ready
                    </Badge>
                  )}
                  {prepData.summary.progressingCount > 0 && (
                    <Badge variant="outline" className="bg-green-500/10 text-green-700 border-green-500/30">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {prepData.summary.progressingCount} Progressing
                    </Badge>
                  )}
                </div>

                <Separator />

                {/* =============== EVALUATION SYNOPSIS =============== */}
                {prepData.evalOpportunities.length > 0 && (
                  <>
                    <EvalSynopsisSection evalOpps={prepData.evalOpportunities} onNavigate={(id) => { onOpenChange(false); navigate(`/opportunities/${id}`); }} />
                    <Separator />
                  </>
                )}

                {/* =============== HOLISTIC COACHING SECTION =============== */}
                {holisticCoaching && (
                  <>
                    <HolisticCoachingSection coaching={holisticCoaching} expandedAccount={expandedAccount} onExpandAccount={setExpandedAccount} />
                    <Separator />
                  </>
                )}

                {/* Needs Attention - At Risk & Stalled */}
                {(prepData.summary.atRiskCount > 0 || prepData.summary.stalledCount > 0) && (
                  <Section title="Needs Attention" icon={<AlertTriangle className="h-4 w-4 text-amber-600" />}>
                    <div className="space-y-2">
                      {prepData.opportunities
                        .filter(o => o.status === 'at_risk' || o.status === 'stalled')
                        .map(opp => (
                          <OppRow key={opp.id} opp={opp} onClick={() => { onOpenChange(false); navigate(`/opportunities/${opp.id}`); }} />
                        ))}
                    </div>
                  </Section>
                )}

                {/* Evaluation Ready */}
                {prepData.summary.evalReadyCount > 0 && (
                  <Section title="Primed for Evaluation" icon={<FlaskConical className="h-4 w-4 text-blue-600" />}>
                    <div className="space-y-2">
                      {prepData.opportunities
                        .filter(o => o.status === 'eval_ready')
                        .map(opp => (
                          <OppRow key={opp.id} opp={opp} onClick={() => { onOpenChange(false); navigate(`/opportunities/${opp.id}`); }} />
                        ))}
                    </div>
                  </Section>
                )}

                {/* Progressing Well */}
                {prepData.summary.progressingCount > 0 && (
                  <Section title="Progressing Well" icon={<TrendingUp className="h-4 w-4 text-green-600" />}>
                    <div className="space-y-2">
                      {prepData.opportunities
                        .filter(o => o.status === 'progressing')
                        .map(opp => (
                          <OppRow key={opp.id} opp={opp} onClick={() => { onOpenChange(false); navigate(`/opportunities/${opp.id}`); }} />
                        ))}
                    </div>
                  </Section>
                )}

                {/* Healthy / Other Opportunities */}
                {prepData.opportunities.filter(o => o.status === 'healthy').length > 0 && (
                  <Section title="Other Active Deals" icon={<Target className="h-4 w-4 text-muted-foreground" />}>
                    <div className="space-y-2">
                      {prepData.opportunities
                        .filter(o => o.status === 'healthy')
                        .map(opp => (
                          <OppRow key={opp.id} opp={opp} onClick={() => { onOpenChange(false); navigate(`/opportunities/${opp.id}`); }} compact />
                        ))}
                    </div>
                  </Section>
                )}

                <Separator />

                {/* Recent Accomplishments */}
                <Section title="Recent Accomplishments (14d)" icon={<CheckCircle2 className="h-4 w-4 text-green-600" />}>
                  {prepData.accomplishments.length > 0 ? (
                    <ul className="space-y-1.5">
                      {prepData.accomplishments.slice(0, 8).map((a, i) => (
                        <li key={i} className="text-sm flex items-start gap-2">
                          <CheckCircle2 className="h-3.5 w-3.5 text-green-500 mt-0.5 shrink-0" />
                          <span className="text-muted-foreground">{a.description}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-sm text-muted-foreground italic">No completed actions in the last 14 days</p>
                  )}
                </Section>

                {/* Coaching Discussion Points (NBA-based) */}
                {prepData.coachingItems.length > 0 && (
                  <Section title="Coaching Action Items" icon={<Lightbulb className="h-4 w-4 text-violet-600" />}>
                    <ul className="space-y-2">
                      {prepData.coachingItems.map(item => {
                        // Parse coaching type and code from notes
                        const coachingTypeMatch = item.notes?.match(/AI Coaching: (.+?)\s*\((\w+)\)/);
                        const coachingType = coachingTypeMatch?.[1] || null;
                        const coachingCode = coachingTypeMatch?.[2] || null;
                        const isGenericAction = !item.action || item.action === 'Coaching recommendation';
                        
                        // Build a contextual description when the action text is generic
                        const contextDescriptions: Record<string, string> = {
                          stale_champion: 'Champion stakeholder has gone quiet — re-engage to maintain momentum and validate internal advocacy.',
                          no_executive_sponsor: 'No executive sponsor identified. High-value deals without exec alignment face higher close-risk.',
                          competitor_mentioned: 'A competitor was recently mentioned in a call — prepare differentiation talking points and a competitive play.',
                          deal_velocity_slow: 'This deal is moving slower than average for its current stage. Investigate blockers and consider re-qualifying.',
                          engagement_decline: 'Engagement has dropped significantly month-over-month. Assess whether stakeholder interest is waning.',
                        };
                        const contextDescription = coachingCode ? contextDescriptions[coachingCode] : null;
                        
                        return (
                          <li key={item.id} className="text-sm p-3 rounded-md bg-violet-500/5 border-l-2 border-violet-500/40 border border-violet-500/10">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Lightbulb className="h-3.5 w-3.5 text-violet-500 shrink-0" />
                              <span className="font-medium text-foreground">{item.opportunityName}</span>
                              {item.accountName && (
                                <span className="text-xs text-muted-foreground">({item.accountName})</span>
                              )}
                              <div className="flex items-center gap-1.5 ml-auto">
                                {coachingType && (
                                  <Badge variant="outline" className="text-[10px] bg-violet-500/10 text-violet-700 border-violet-500/20">
                                    {coachingType}
                                  </Badge>
                                )}
                                {item.priority && (
                                  <Badge variant="outline" className={cn("text-[10px]",
                                    item.priority === 'high' ? 'bg-red-500/10 text-red-700 border-red-500/20' :
                                    item.priority === 'medium' ? 'bg-amber-500/10 text-amber-700 border-amber-500/20' :
                                    ''
                                  )}>
                                    {item.priority}
                                  </Badge>
                                )}
                              </div>
                            </div>
                            {!isGenericAction && (
                              <p className="text-foreground mt-1.5 pl-5 font-medium">{item.action}</p>
                            )}
                            {contextDescription && (
                              <p className="text-muted-foreground mt-1 pl-5 text-xs leading-relaxed">{contextDescription}</p>
                            )}
                            {!contextDescription && item.notes && (
                              <p className="text-muted-foreground mt-1 pl-5 text-xs">{item.notes}</p>
                            )}
                          </li>
                        );
                      })}
                    </ul>
                  </Section>
                )}
              </div>
            </ScrollArea>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

// ============ EVALUATION SYNOPSIS SECTION ============

const phaseOrder = ['Value Discovery', 'Eval Planning', 'Eval Deployment', 'Eval Workshops', 'Conclusion', 'Procurement & Contracting', 'Go Live & Value Realization'];

function EvalSynopsisSection({ evalOpps, onNavigate }: { evalOpps: PrepEvalOpportunity[]; onNavigate: (id: string) => void }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <FlaskConical className="h-5 w-5 text-blue-600" />
        <h3 className="text-sm font-semibold text-foreground">Evaluation Synopsis</h3>
        <Badge variant="outline" className="text-xs ml-auto">
          {evalOpps.length} active eval{evalOpps.length !== 1 ? 's' : ''}
        </Badge>
      </div>

      <div className="space-y-3">
        {evalOpps.map(ev => {
          const progressPct = ev.milestones.total > 0
            ? Math.round((ev.milestones.completed / ev.milestones.total) * 100)
            : 0;
          const openRisks = ev.risks.filter(r => r.status === 'open' || r.status === 'mitigating');
          const highSevRisks = openRisks.filter(r => r.severity === 'high' || r.severity === 'critical');
          const issues = ev.risks.filter(r => r.entryType === 'issue' && (r.status === 'open' || r.status === 'mitigating'));

          return (
            <div
              key={ev.id}
              className={cn(
                "p-3 rounded-lg border bg-card space-y-2.5 cursor-pointer hover:bg-accent/50 transition-colors",
                highSevRisks.length > 0 ? "border-red-500/30" : issues.length > 0 ? "border-amber-500/30" : ""
              )}
              onClick={() => onNavigate(ev.id)}
            >
              {/* Header */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="font-medium text-sm truncate">{ev.name}</span>
                  <span className="text-xs text-muted-foreground">({ev.accountName})</span>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {ev.evalType && (
                    <Badge variant="outline" className="text-[10px] capitalize">{ev.evalType}</Badge>
                  )}
                  {ev.evalPhase && (
                    <Badge variant="outline" className="text-[10px] bg-blue-500/10 text-blue-700 border-blue-500/20 capitalize">
                      {ev.evalPhase.replace(/_/g, ' ')}
                    </Badge>
                  )}
                  <ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
                </div>
              </div>

              {/* Eval dates */}
              {(ev.evalStartDate || ev.evalEndDate) && (
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <Calendar className="h-3 w-3" />
                  {ev.evalStartDate && <span>Start: {format(new Date(ev.evalStartDate), 'MMM d, yyyy')}</span>}
                  {ev.evalEndDate && <span>End: {format(new Date(ev.evalEndDate), 'MMM d, yyyy')}</span>}
                  {ev.evalStartDate && ev.evalEndDate && (() => {
                    const now = new Date();
                    const end = new Date(ev.evalEndDate!);
                    const start = new Date(ev.evalStartDate!);
                    const totalDays = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)));
                    const elapsed = Math.ceil((now.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
                    const remaining = Math.max(0, totalDays - elapsed);
                    return <span className={cn("font-medium", remaining <= 7 ? "text-red-600" : remaining <= 14 ? "text-amber-600" : "text-muted-foreground")}>
                      ({remaining}d remaining)
                    </span>;
                  })()}
                </div>
              )}

              {/* Timeline progress */}
              {ev.milestones.total > 0 && (
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Activity className="h-3 w-3" />
                      Timeline Progress
                    </span>
                    <span className="font-medium">{ev.milestones.completed}/{ev.milestones.total} milestones ({progressPct}%)</span>
                  </div>
                  <Progress value={progressPct} className="h-1.5" />
                  
                  {/* Phase breakdown */}
                  <div className="flex flex-wrap gap-1.5">
                    {phaseOrder
                      .filter(phase => ev.milestones.phases[phase])
                      .map(phase => {
                        const p = ev.milestones.phases[phase];
                        const done = p.completed === p.total;
                        return (
                          <Badge key={phase} variant="outline" className={cn("text-[10px]",
                            done ? "bg-green-500/10 text-green-700 border-green-500/20" :
                            p.completed > 0 ? "bg-blue-500/10 text-blue-700 border-blue-500/20" :
                            ""
                          )}>
                            {phase}: {p.completed}/{p.total}
                          </Badge>
                        );
                      })}
                  </div>

                  {/* Next upcoming milestone */}
                  {ev.milestones.nextUpcoming && (
                    <div className="text-xs text-muted-foreground flex items-center gap-1.5">
                      <Calendar className="h-3 w-3" />
                      Next: <span className="font-medium text-foreground">{ev.milestones.nextUpcoming.name}</span>
                      — {format(new Date(ev.milestones.nextUpcoming.date), 'MMM d')}
                    </div>
                  )}
                </div>
              )}

              {/* Risks & Issues */}
              {openRisks.length > 0 && (
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                    <ShieldAlert className="h-3 w-3" />
                    Open Risks & Issues ({openRisks.length})
                  </p>
                  <div className="space-y-1">
                    {openRisks.slice(0, 4).map(risk => (
                      <div key={risk.id} className={cn(
                        "text-xs p-2 rounded border-l-2",
                        risk.entryType === 'issue' ? "bg-red-500/5 border-red-500" :
                        risk.severity === 'high' || risk.severity === 'critical' ? "bg-amber-500/5 border-amber-500" :
                        "bg-muted/50 border-muted-foreground/30"
                      )}>
                        <div className="flex items-center gap-1.5">
                          <Badge variant="outline" className={cn("text-[9px]",
                            risk.entryType === 'issue' ? "bg-red-500/10 text-red-700 border-red-500/20" :
                            "bg-amber-500/10 text-amber-700 border-amber-500/20"
                          )}>
                            {risk.entryType === 'issue' ? 'Issue' : 'Risk'} · {risk.severity}
                          </Badge>
                        </div>
                        <p className="text-muted-foreground mt-0.5">{risk.description}</p>
                      </div>
                    ))}
                    {openRisks.length > 4 && (
                      <p className="text-[10px] text-muted-foreground italic">+{openRisks.length - 4} more</p>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============ HOLISTIC COACHING SECTION ============

function HolisticCoachingSection({ 
  coaching, 
  expandedAccount, 
  onExpandAccount 
}: { 
  coaching: HolisticCoachingData; 
  expandedAccount: string | null;
  onExpandAccount: (id: string | null) => void;
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Brain className="h-5 w-5 text-violet-600" />
        <h3 className="text-sm font-semibold text-foreground">Coaching Insights Across Calls</h3>
        <Badge variant="outline" className="text-xs ml-auto">
          {coaching.callInsights.length} call{coaching.callInsights.length !== 1 ? 's' : ''} analyzed
        </Badge>
      </div>

      {/* Overall Score + Trend */}
      <div className="flex items-center gap-4 p-3 rounded-lg bg-violet-500/5 border border-violet-500/15">
        <div className="text-center">
          <p className="text-2xl font-bold text-foreground">{coaching.overallAvg}</p>
          <p className="text-[10px] text-muted-foreground">Avg Score /5</p>
        </div>
        <div className="flex items-center gap-1.5">
          <TrendIcon trend={coaching.overallTrend} />
          <span className="text-xs text-muted-foreground capitalize">{coaching.overallTrend}</span>
        </div>
        <div className="flex-1 flex flex-wrap gap-1.5 justify-end">
          {coaching.topStrengths.length > 0 && (
            <Badge variant="outline" className="text-xs bg-green-500/10 text-green-700 border-green-500/20">
              <Star className="h-3 w-3 mr-1" />
              {coaching.topStrengths[0]}
            </Badge>
          )}
          {coaching.topGaps.length > 0 && (
            <Badge variant="outline" className="text-xs bg-red-500/10 text-red-700 border-red-500/20">
              <Zap className="h-3 w-3 mr-1" />
              {coaching.topGaps[0]}
            </Badge>
          )}
        </div>
      </div>

      {/* Dimension Breakdown - top gaps */}
      {coaching.topGaps.length > 0 && (
        <div>
          <p className="text-xs font-medium text-muted-foreground mb-2">Focus Areas (weakest dimensions)</p>
          <div className="space-y-1.5">
            {coaching.dimensionSummaries
              .filter(d => d.avgScore < 3)
              .slice(0, 5)
              .map(dim => (
                <div key={dim.dimension} className="flex items-center gap-2">
                  <span className="text-xs w-32 truncate text-muted-foreground">{dim.label}</span>
                  <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className={cn("h-full rounded-full transition-all", getScoreBarColor(dim.avgScore))}
                      style={{ width: `${(dim.avgScore / 5) * 100}%` }}
                    />
                  </div>
                  <span className="text-xs font-medium w-8 text-right">{dim.avgScore}</span>
                  <TrendIcon trend={dim.trend} />
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Strengths */}
      {coaching.dimensionSummaries.filter(d => d.avgScore >= 3.5).length > 0 && (
        <div>
          <p className="text-xs font-medium text-muted-foreground mb-2">Strengths</p>
          <div className="space-y-1.5">
            {coaching.dimensionSummaries
              .filter(d => d.avgScore >= 3.5)
              .reverse()
              .slice(0, 3)
              .map(dim => (
                <div key={dim.dimension} className="flex items-center gap-2">
                  <span className="text-xs w-32 truncate text-muted-foreground">{dim.label}</span>
                  <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className={cn("h-full rounded-full transition-all", getScoreBarColor(dim.avgScore))}
                      style={{ width: `${(dim.avgScore / 5) * 100}%` }}
                    />
                  </div>
                  <span className="text-xs font-medium w-8 text-right">{dim.avgScore}</span>
                  <TrendIcon trend={dim.trend} />
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Recurring Coaching Techniques */}
      {coaching.recurringGuidance.length > 0 && (
        <div>
          <p className="text-xs font-medium text-muted-foreground mb-2">Recurring Coaching Recommendations</p>
          <ul className="space-y-1.5">
            {coaching.recurringGuidance.map((technique, i) => (
              <li key={i} className="text-xs flex items-start gap-2 p-2 rounded-md bg-violet-500/5 border border-violet-500/10">
                <MessageSquareQuote className="h-3.5 w-3.5 text-violet-500 mt-0.5 shrink-0" />
                <span className="text-muted-foreground">{technique}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Account-by-Account Breakdown */}
      {coaching.accountGroups.length > 0 && (
        <div>
          <p className="text-xs font-medium text-muted-foreground mb-2">Account-by-Account Breakdown</p>
          <div className="space-y-1.5">
            {coaching.accountGroups.map(group => (
              <AccountCoachingRow
                key={group.accountId}
                group={group}
                isExpanded={expandedAccount === group.accountId}
                onToggle={() => onExpandAccount(
                  expandedAccount === group.accountId ? null : group.accountId
                )}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function AccountCoachingRow({ group, isExpanded, onToggle }: { group: CoachingAccountGroup; isExpanded: boolean; onToggle: () => void }) {
  return (
    <Collapsible open={isExpanded} onOpenChange={onToggle}>
      <CollapsibleTrigger className="w-full">
        <div className="flex items-center gap-2 p-2 rounded-md border bg-card hover:bg-accent/50 transition-colors text-left">
          {isExpanded ? <ChevronDown className="h-3.5 w-3.5 shrink-0" /> : <ChevronRight className="h-3.5 w-3.5 shrink-0" />}
          <span className="text-sm font-medium truncate">{group.accountName}</span>
          <Badge variant="outline" className="text-[10px] ml-auto">
            {group.calls.length} call{group.calls.length !== 1 ? 's' : ''}
          </Badge>
          <Badge variant="outline" className={cn("text-xs", getScoreColor(group.avgScore))}>
            {group.avgScore}/5
          </Badge>
          <TrendIcon trend={group.trend} />
        </div>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="ml-5 mt-1 space-y-2">
          {group.calls.map(call => (
            <div key={call.transcriptId || call.date} className="p-3 rounded-md border bg-muted/30 space-y-2 text-xs">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-[10px] capitalize">{call.meetingType}</Badge>
                <span className="text-muted-foreground">{format(new Date(call.date), 'MMM d')}</span>
                <div className="flex-1" />
                <Badge variant="outline" className={cn("text-xs", getScoreColor(call.overallScore))}>
                  {call.overallScore.toFixed(1)}/5
                </Badge>
              </div>
              {call.greatnessMoment && (
                <div>
                  <p className="font-medium text-green-700 flex items-center gap-1 mb-0.5">
                    <Star className="h-3 w-3" /> Greatness Moment
                  </p>
                  <p className="text-muted-foreground">{call.greatnessMoment}</p>
                </div>
              )}
              {call.opportunityGap && (
                <div>
                  <p className="font-medium text-red-700 flex items-center gap-1 mb-0.5">
                    <Zap className="h-3 w-3" /> Opportunity Gap
                  </p>
                  <p className="text-muted-foreground">{call.opportunityGap}</p>
                </div>
              )}
              {call.actionableNextStep && (
                <div>
                  <p className="font-medium text-violet-700 flex items-center gap-1 mb-0.5">
                    <Lightbulb className="h-3 w-3" /> Suggested Next Step
                  </p>
                  <p className="text-muted-foreground">{call.actionableNextStep}</p>
                </div>
              )}
              {Array.isArray(call.coachingGuidance) && call.coachingGuidance.length > 0 && (
                <div>
                  <p className="font-medium text-foreground mb-1">Coaching Guidance</p>
                  {call.coachingGuidance.map((g: any, i: number) => (
                    <div key={i} className="p-2 rounded bg-background border mb-1.5 last:mb-0">
                      {g.technique && <p className="font-medium text-violet-700">{g.technique}</p>}
                      {g.pattern_observed && <p className="text-muted-foreground mt-0.5">{g.pattern_observed}</p>}
                      {g.expected_impact && <p className="text-muted-foreground mt-0.5 italic">{g.expected_impact}</p>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}
// ============ SHARED COMPONENTS ============

function StatMini({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="flex items-center gap-2 p-2.5 rounded-lg bg-muted/50 border">
      <div className="text-muted-foreground">{icon}</div>
      <div>
        <p className="text-lg font-bold leading-none">{value}</p>
        <p className="text-[10px] text-muted-foreground">{label}</p>
      </div>
    </div>
  );
}

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function OppRow({ opp, onClick, compact }: { opp: PrepOpportunity; onClick: () => void; compact?: boolean }) {
  const config = statusConfig[opp.status];
  
  return (
    <div
      className="p-2.5 rounded-lg border bg-card hover:bg-accent/50 cursor-pointer transition-colors"
      onClick={onClick}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <Badge variant="outline" className={cn("text-xs shrink-0", config.color)}>
            {config.icon}
            <span className="ml-1">{config.label}</span>
          </Badge>
          <span className="font-medium text-sm truncate">{opp.name}</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {opp.value && (
            <span className="text-xs font-medium text-muted-foreground">
              ${(opp.value / 1000).toFixed(0)}k
            </span>
          )}
          {opp.readinessScore != null && (
            <Badge variant="outline" className={cn(
              "text-xs",
              opp.readinessScore >= 70 ? "text-green-700 bg-green-500/10" :
              opp.readinessScore >= 40 ? "text-amber-700 bg-amber-500/10" :
              "text-red-700 bg-red-500/10"
            )}>
              {opp.readinessScore}%
            </Badge>
          )}
          <ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
        </div>
      </div>
      {!compact && (
        <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground pl-1">
          <span>{opp.accountName}</span>
          {opp.salesStage && <span>• {opp.salesStage}</span>}
          {opp.closeDate && (
            <span>• Close: {format(new Date(opp.closeDate), 'MMM d')}</span>
          )}
          <span className="italic">— {opp.statusReason}</span>
        </div>
      )}
    </div>
  );
}

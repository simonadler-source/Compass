import { useState, useMemo } from 'react';
import { useAllUsers } from '@/hooks/useUserRole';
import { useTeamHierarchy, RelationshipType } from '@/hooks/useTeamHierarchy';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Check, ChevronsUpDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { 
  ChevronDown, 
  ChevronRight, 
  Plus, 
  UserPlus, 
  Users, 
  ArrowUp,
  MoreHorizontal,
  Link2
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface OrgNode {
  id: string;
  email: string;
  fullName: string | null;
  children: OrgNode[];
  dottedChildren: OrgNode[];
  managerId: string | null;
}

interface OrgChartProps {
  onAddHierarchy?: () => void;
}

export function OrgChart({ onAddHierarchy }: OrgChartProps) {
  const { data: users, isLoading: usersLoading } = useAllUsers();
  const { hierarchyEntries, addReport, removeReport, isLoading: hierarchyLoading } = useTeamHierarchy();
  
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [addMode, setAddMode] = useState<'report' | 'manager' | 'dotted'>('report');
  const [selectedUser, setSelectedUser] = useState<OrgNode | null>(null);
  const [selectedTargetId, setSelectedTargetId] = useState('');
  const [relationshipType, setRelationshipType] = useState<RelationshipType>('solid');

  // Build org tree from hierarchy entries
  const { orgTree, rootNodes, orphanedUsers } = useMemo(() => {
    if (!users || !hierarchyEntries) return { orgTree: new Map(), rootNodes: [], orphanedUsers: [] };

    // Create a map of userId -> their solid-line manager
    const solidManagerMap = new Map<string, string>();
    hierarchyEntries.forEach(entry => {
      if (entry.relationship_type !== 'dotted') {
        solidManagerMap.set(entry.report_id, entry.manager_id);
      }
    });

    // Create nodes for all users
    const nodeMap = new Map<string, OrgNode>();
    users.forEach(u => {
      nodeMap.set(u.id, {
        id: u.id,
        email: u.email,
        fullName: u.full_name,
        children: [],
        dottedChildren: [],
        managerId: solidManagerMap.get(u.id) || null,
      });
    });

    // Build parent-child relationships
    hierarchyEntries.forEach(entry => {
      const manager = nodeMap.get(entry.manager_id);
      const report = nodeMap.get(entry.report_id);
      if (manager && report) {
        if (entry.relationship_type === 'dotted') {
          manager.dottedChildren.push(report);
        } else {
          manager.children.push(report);
        }
      }
    });

    // Sort children alphabetically
    nodeMap.forEach(node => {
      node.children.sort((a, b) => 
        (a.fullName || a.email).localeCompare(b.fullName || b.email)
      );
      node.dottedChildren.sort((a, b) => 
        (a.fullName || a.email).localeCompare(b.fullName || b.email)
      );
    });

    // Find root nodes (users with solid reports who don't have a solid manager)
    const usersWithReports = new Set(hierarchyEntries.map(e => e.manager_id));
    const usersWithSolidManagers = new Set(
      hierarchyEntries.filter(e => e.relationship_type !== 'dotted').map(e => e.report_id)
    );
    
    const roots = Array.from(nodeMap.values())
      .filter(n => usersWithReports.has(n.id) && !usersWithSolidManagers.has(n.id))
      .sort((a, b) => (a.fullName || a.email).localeCompare(b.fullName || b.email));

    // Orphaned users are those not in any hierarchy
    const allInHierarchy = new Set([...usersWithReports, ...new Set(hierarchyEntries.map(e => e.report_id))]);
    const orphans = Array.from(nodeMap.values())
      .filter(n => !allInHierarchy.has(n.id))
      .sort((a, b) => (a.fullName || a.email).localeCompare(b.fullName || b.email));

    return { orgTree: nodeMap, rootNodes: roots, orphanedUsers: orphans };
  }, [users, hierarchyEntries]);

  const toggleExpand = (nodeId: string) => {
    setExpandedNodes(prev => {
      const next = new Set(prev);
      if (next.has(nodeId)) {
        next.delete(nodeId);
      } else {
        next.add(nodeId);
      }
      return next;
    });
  };

  const expandAll = () => {
    const allIds = new Set(Array.from(orgTree.keys()));
    setExpandedNodes(allIds);
  };

  const collapseAll = () => {
    setExpandedNodes(new Set());
  };

  const handleAddReport = (user: OrgNode) => {
    setSelectedUser(user);
    setAddMode('report');
    setRelationshipType('solid');
    setSelectedTargetId('');
    setAddDialogOpen(true);
  };

  const handleAddDottedReport = (user: OrgNode) => {
    setSelectedUser(user);
    setAddMode('dotted');
    setRelationshipType('dotted');
    setSelectedTargetId('');
    setAddDialogOpen(true);
  };

  const handleSetManager = (user: OrgNode) => {
    setSelectedUser(user);
    setAddMode('manager');
    setRelationshipType('solid');
    setSelectedTargetId('');
    setAddDialogOpen(true);
  };

  const handleConfirmAdd = () => {
    if (!selectedUser || !selectedTargetId) return;

    if (addMode === 'report' || addMode === 'dotted') {
      addReport.mutate({ 
        managerId: selectedUser.id, 
        reportId: selectedTargetId, 
        relationshipType: addMode === 'dotted' ? 'dotted' : 'solid' 
      });
    } else {
      addReport.mutate({ managerId: selectedTargetId, reportId: selectedUser.id, relationshipType });
    }
    
    setAddDialogOpen(false);
    setSelectedUser(null);
    setSelectedTargetId('');
  };

  const handleRemoveFromManager = (user: OrgNode) => {
    if (user.managerId) {
      removeReport.mutate({ managerId: user.managerId, reportId: user.id });
    }
  };

  // Get users available for selection (exclude self and prevent circular references)
  const availableUsers = useMemo(() => {
    if (!selectedUser || !users) return [];
    
    if (addMode === 'report' || addMode === 'dotted') {
      const existingIds = new Set([
        ...selectedUser.children.map(c => c.id),
        ...selectedUser.dottedChildren.map(c => c.id),
      ]);
      return users.filter(u => 
        u.id !== selectedUser.id && 
        !existingIds.has(u.id) &&
        u.id !== selectedUser.managerId
      ).sort((a, b) => {
        const nameA = (a.full_name || a.email).toLowerCase();
        const nameB = (b.full_name || b.email).toLowerCase();
        return nameA.localeCompare(nameB);
      });
    } else {
      const getAllDescendants = (node: OrgNode): Set<string> => {
        const descendants = new Set<string>();
        [...node.children, ...node.dottedChildren].forEach(child => {
          descendants.add(child.id);
          getAllDescendants(child).forEach(id => descendants.add(id));
        });
        return descendants;
      };
      const descendants = getAllDescendants(selectedUser);
      return users.filter(u => 
        u.id !== selectedUser.id && 
        !descendants.has(u.id) &&
        u.id !== selectedUser.managerId
      ).sort((a, b) => {
        const nameA = (a.full_name || a.email).toLowerCase();
        const nameB = (b.full_name || b.email).toLowerCase();
        return nameA.localeCompare(nameB);
      });
    }
  }, [selectedUser, users, addMode]);

  const isLoading = usersLoading || hierarchyLoading;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const OrgNodeCard = ({ node, depth = 0, isDotted = false }: { node: OrgNode; depth?: number; isDotted?: boolean }) => {
    const isExpanded = expandedNodes.has(node.id);
    const hasChildren = node.children.length > 0 || node.dottedChildren.length > 0;
    const totalReports = node.children.length + node.dottedChildren.length;

    return (
      <div className="relative">
        {/* Connection lines */}
        {depth > 0 && (
          <div className={cn(
            "absolute left-0 top-0 w-6 h-6 border-l-2 border-b-2 rounded-bl-lg -translate-x-3",
            isDotted ? "border-dashed border-muted-foreground/40" : "border-border"
          )} />
        )}
        
        <Card className={cn(
          "p-3 mb-2 transition-all hover:shadow-md border-border bg-card",
          depth === 0 && "border-primary/30 bg-primary/5",
          isDotted && "border-dashed border-muted-foreground/40"
        )}>
          <div className="flex items-center gap-2">
            {/* Expand/collapse toggle */}
            <Button
              variant="ghost"
              size="sm"
              className={cn("w-6 h-6 p-0", !hasChildren && "invisible")}
              onClick={() => toggleExpand(node.id)}
            >
              {isExpanded ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )}
            </Button>

            {/* User info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="font-medium truncate">
                  {node.fullName || node.email.split('@')[0]}
                </p>
                {isDotted && (
                  <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-dashed text-muted-foreground">
                    dotted
                  </Badge>
                )}
              </div>
              <p className="text-xs text-muted-foreground truncate">{node.email}</p>
            </div>

            {/* Report count badge */}
            {totalReports > 0 && (
              <div className="flex items-center gap-1">
                {node.children.length > 0 && (
                  <Badge variant="secondary" className="text-xs">
                    {node.children.length} direct
                  </Badge>
                )}
                {node.dottedChildren.length > 0 && (
                  <Badge variant="outline" className="text-xs border-dashed">
                    {node.dottedChildren.length} dotted
                  </Badge>
                )}
              </div>
            )}

            {/* Actions menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="w-8 h-8 p-0">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleAddReport(node)}>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add Direct Report
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleAddDottedReport(node)}>
                  <Link2 className="w-4 h-4 mr-2" />
                  Add Dotted-Line Report
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleSetManager(node)}>
                  <ArrowUp className="w-4 h-4 mr-2" />
                  Set Reports To
                </DropdownMenuItem>
                {node.managerId && (
                  <DropdownMenuItem 
                    onClick={() => handleRemoveFromManager(node)}
                    className="text-destructive"
                  >
                    <Users className="w-4 h-4 mr-2" />
                    Remove from Manager
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </Card>

        {/* Children */}
        {isExpanded && hasChildren && (
          <div className="ml-8 pl-3 border-l-2 border-border">
            {node.children.map(child => (
              <OrgNodeCard key={child.id} node={child} depth={depth + 1} />
            ))}
            {node.dottedChildren.map(child => (
              <OrgNodeCard key={`dotted-${child.id}`} node={child} depth={depth + 1} isDotted />
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex items-center gap-2 flex-wrap">
        <Button variant="outline" size="sm" onClick={expandAll}>
          Expand All
        </Button>
        <Button variant="outline" size="sm" onClick={collapseAll}>
          Collapse All
        </Button>
        <div className="flex-1" />
        <Button size="sm" onClick={onAddHierarchy}>
          <Plus className="w-4 h-4 mr-2" />
          Add Assignment
        </Button>
      </div>

      {/* Org Chart Tree */}
      {rootNodes.length > 0 ? (
        <div className="space-y-4">
          <h3 className="text-sm font-medium text-muted-foreground">Team Structure</h3>
          {rootNodes.map(node => (
            <OrgNodeCard key={node.id} node={node} />
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-muted-foreground border-2 border-dashed border-border rounded-lg">
          <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>No team structure defined yet.</p>
          <p className="text-sm mt-1">Click "Add Assignment" to create manager-report relationships.</p>
        </div>
      )}

      {/* Orphaned Users (not in any hierarchy) */}
      {orphanedUsers.length > 0 && rootNodes.length > 0 && (
        <div className="space-y-4 pt-4 border-t border-border">
          <h3 className="text-sm font-medium text-muted-foreground">
            Unassigned Users ({orphanedUsers.length})
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {orphanedUsers.map(node => (
              <Card key={node.id} className="p-3 bg-muted/30">
                <div className="flex items-center gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate text-sm">
                      {node.fullName || node.email.split('@')[0]}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">{node.email}</p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="w-8 h-8 p-0">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleAddReport(node)}>
                        <UserPlus className="w-4 h-4 mr-2" />
                        Add Direct Report
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleAddDottedReport(node)}>
                        <Link2 className="w-4 h-4 mr-2" />
                        Add Dotted-Line Report
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleSetManager(node)}>
                        <ArrowUp className="w-4 h-4 mr-2" />
                        Set Reports To
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Add Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {addMode === 'dotted' ? 'Add Dotted-Line Report' : addMode === 'report' ? 'Add Direct Report' : 'Set Reports To'}
            </DialogTitle>
            <DialogDescription>
              {addMode === 'dotted'
                ? `Add a dotted-line report to ${selectedUser?.fullName || selectedUser?.email}. They will appear in your team for coaching and dashboards.`
                : addMode === 'report' 
                  ? `Add a direct report to ${selectedUser?.fullName || selectedUser?.email}`
                  : `Set who ${selectedUser?.fullName || selectedUser?.email} reports to`
              }
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>{addMode === 'manager' ? 'Select Manager' : 'Select User'}</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" role="combobox" className="w-full justify-between font-normal">
                    {selectedTargetId
                      ? (() => {
                          const u = availableUsers.find(u => u.id === selectedTargetId);
                          return u ? (u.full_name || u.email) : 'Choose...';
                        })()
                      : (addMode === 'manager' ? 'Choose a manager...' : 'Choose a user...')}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Search users..." />
                    <CommandList>
                      <CommandEmpty>No user found.</CommandEmpty>
                      <CommandGroup>
                        {availableUsers.map(u => (
                          <CommandItem
                            key={u.id}
                            value={`${u.full_name || ''} ${u.email}`}
                            onSelect={() => setSelectedTargetId(u.id)}
                          >
                            <Check className={cn("mr-2 h-4 w-4", selectedTargetId === u.id ? "opacity-100" : "opacity-0")} />
                            <span>{u.full_name || u.email}</span>
                            {u.full_name && <span className="ml-1 text-muted-foreground">({u.email})</span>}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>
            {addMode === 'manager' && (
              <div className="space-y-2">
                <Label>Relationship Type</Label>
                <Select value={relationshipType} onValueChange={(v) => setRelationshipType(v as RelationshipType)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="solid">Solid Line (primary manager)</SelectItem>
                    <SelectItem value="dotted">Dotted Line (secondary manager)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleConfirmAdd}
              disabled={!selectedTargetId || addReport.isPending}
            >
              {addMode === 'dotted' ? 'Add Dotted-Line Report' : addMode === 'report' ? 'Add Report' : 'Set Manager'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { useState } from 'react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Network, Users, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { OrgNode, collectSubtreeEmails } from '@/hooks/useOrgTree';

interface OrgTreePickerProps {
  roots: OrgNode[];
  selectedId: string | null;
  onSelect: (node: OrgNode) => void;
}

export default function OrgTreePicker({ roots, selectedId, onSelect }: OrgTreePickerProps) {
  const [open, setOpen] = useState(false);

  const findLabel = (nodes: OrgNode[]): string | null => {
    for (const n of nodes) {
      if (n.id === selectedId) return n.full_name || n.email;
      const child = findLabel(n.children);
      if (child) return child;
    }
    return null;
  };
  const selectedLabel = selectedId ? findLabel(roots) : null;

  const renderItems = (nodes: OrgNode[], depth: number = 0): React.ReactNode[] => {
    return nodes.flatMap(node => {
      const hasChildren = node.children.length > 0;
      const indent = depth * 16;
      return [
        <CommandItem
          key={node.id}
          value={`${node.full_name || ''} ${node.email}`}
          onSelect={() => { onSelect(node); setOpen(false); }}
          className="cursor-pointer"
          style={{ paddingLeft: `${8 + indent}px` }}
        >
          <div className="flex items-center gap-2 w-full">
            {hasChildren ? (
              <Network className="h-3.5 w-3.5 text-primary shrink-0" />
            ) : (
              <Users className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            )}
            <div className="flex-1 min-w-0">
              <p className={cn("text-sm truncate", selectedId === node.id && "font-semibold")}>
                {node.full_name || node.email}
              </p>
              {node.full_name && (
                <p className="text-[10px] text-muted-foreground truncate">{node.email}</p>
              )}
            </div>
            {hasChildren && (
              <Badge variant="secondary" className="text-[10px] shrink-0">
                {collectSubtreeEmails(node).length}
              </Badge>
            )}
          </div>
        </CommandItem>,
        ...renderItems(node.children, depth + 1),
      ];
    });
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 max-w-[240px]">
          <Network className="h-4 w-4 shrink-0" />
          <span className="truncate">{selectedLabel || 'Select team...'}</span>
          <ChevronDown className="h-3 w-3 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[320px] p-0 z-50" align="start">
        <Command>
          <CommandInput placeholder="Search people..." />
          <CommandList>
            <CommandEmpty>No results.</CommandEmpty>
            <CommandGroup>
              {renderItems(roots)}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway } from '@/lib/apiGateway';
import { decryptTranscript } from '@/lib/encryption';
import { Layers, RotateCcw } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { toast } from 'sonner';

interface PassStatus {
  pass_key: string;
  pass_name: string;
  status: 'completed' | 'failed' | 'running' | 'skipped' | 'pending';
  duration_ms: number | null;
  error_message: string | null;
  retry_attempt: number;
}

interface PipelineStageIndicatorProps {
  transcriptId: string;
  isAnalyzing?: boolean;
  className?: string;
}

const statusColors: Record<string, string> = {
  completed: 'bg-green-500',
  failed: 'bg-destructive',
  running: 'bg-amber-500 animate-pulse',
  skipped: 'bg-muted-foreground/40',
  pending: 'bg-blue-400',
};

// Map DB pass_keys to display-friendly canonical keys
const PASS_ALIASES: Record<string, string> = {
  enrichment_detection: 'activity_detection',
  enrichment_readiness: 'readiness_extraction',
};

// Reverse map: canonical UI key → actual DB pass_key (for retries)
const REVERSE_ALIASES: Record<string, string> = {
  activity_detection: 'enrichment_detection',
  readiness_extraction: 'enrichment_readiness',
};

const CANONICAL_STAGES: { key: string; name: string }[] = [
  { key: 'core_extraction', name: 'Core Extraction' },
  { key: 'call_summary', name: 'Call Summary' },
  { key: 'stage_assessment', name: 'Stage Assessment' },
  { key: 'activity_detection', name: 'Activity Detection' },
  { key: 'readiness_extraction', name: 'Readiness Extraction' },
  { key: 'account_synthesis', name: 'Account Synthesis' },
  { key: 'competitive_analysis', name: 'Competitive Analysis' },
  { key: 'se_coaching', name: 'SE Coaching Analysis' },
];

export function PipelineStageIndicator({ transcriptId, isAnalyzing, className }: PipelineStageIndicatorProps) {
  const [showTooltip, setShowTooltip] = useState(false);
  const [tooltipPos, setTooltipPos] = useState({ top: 0, left: 0 });
  const [retryingStage, setRetryingStage] = useState<string | null>(null);
  const triggerRef = useRef<HTMLDivElement>(null);
  const hideTimeout = useRef<ReturnType<typeof setTimeout>>();
  const queryClient = useQueryClient();

  const { data: runLogs } = useQuery({
    queryKey: ['analysis-run-logs', transcriptId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('analysis_run_logs')
        .select('pass_key, pass_name, status, duration_ms, error_message, retry_attempt')
        .eq('transcript_id', transcriptId)
        .order('started_at', { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!transcriptId,
    refetchInterval: (query) => {
      const logs = query.state.data;
      const hasNonTerminal = logs?.some((l: any) => !['completed', 'failed', 'skipped'].includes(l.status));
      return (hasNonTerminal || isAnalyzing) ? 3000 : false;
    },
  });

  const canonicalLogs = new Map<string, PassStatus>();
  for (const log of (runLogs || [])) {
    const canonical = PASS_ALIASES[log.pass_key] || log.pass_key;
    if (!canonicalLogs.has(canonical)) {
      canonicalLogs.set(canonical, {
        pass_key: canonical,
        pass_name: log.pass_name || canonical,
        status: log.status as PassStatus['status'],
        duration_ms: log.duration_ms,
        error_message: log.error_message,
        retry_attempt: log.retry_attempt,
      });
    }
  }

  const stages = CANONICAL_STAGES.map(({ key, name }) => {
    const log = canonicalLogs.get(key);
    return {
      key,
      name: log?.pass_name || name,
      status: log?.status || 'pending',
      duration_ms: log?.duration_ms ?? null,
      error_message: log?.error_message ?? null,
      retry_attempt: log?.retry_attempt ?? 0,
    };
  });

  const hasAnyRuns = runLogs && runLogs.length > 0;
  const allCompleted = stages.every(s => s.status === 'completed');
  const hasFailed = stages.some(s => s.status === 'failed');
  const hasRunning = stages.some(s => s.status === 'running');
  const incompleteStages = stages.filter(s => s.status === 'failed' || s.status === 'pending');
  // Treat pending stages as retryable if at least one stage has completed (pipeline ran but didn't finish)
  const hasIncomplete = incompleteStages.length > 0 && hasAnyRuns;
  const hasPendingAfterRun = stages.some(s => s.status === 'pending') && stages.some(s => s.status === 'completed');

  const fetchTranscriptForRetry = async () => {
    const { data: review, error: fetchError } = await gateway
      .from('transcript_reviews')
      .select('transcript_content, final_account_id, opportunity_id, is_encrypted')
      .eq('id', transcriptId)
      .maybeSingle();

    if (fetchError) throw new Error(fetchError.message);

    let transcriptContent = review?.transcript_content;
    if ((!transcriptContent || review?.is_encrypted) && transcriptId) {
      transcriptContent = await decryptTranscript(transcriptId, 'transcript_reviews');
    }
    if (!transcriptContent?.trim()) throw new Error('Transcript content is empty');

    return { transcriptContent, review };
  };

  const invokeRetry = async (passKeys: string[]) => {
    // Convert canonical UI keys back to actual DB pass_keys for the edge function
    const dbPassKeys = passKeys.map(k => REVERSE_ALIASES[k] || k);
    const { transcriptContent, review } = await fetchTranscriptForRetry();
    const { error } = await supabase.functions.invoke('unified-transcript-analysis', {
      body: {
        transcript: transcriptContent!.slice(0, 120000),
        transcriptReviewId: transcriptId,
        accountId: review?.final_account_id || undefined,
        opportunityId: review?.opportunity_id || undefined,
        retryPassKeys: dbPassKeys,
        streaming: false,
      },
    });
    if (error) throw error;
  };

  const handleRetryStage = async (passKey: string) => {
    setRetryingStage(passKey);
    queryClient.setQueryData(['analysis-run-logs', transcriptId], (old: any[] | undefined) => {
      if (!old) return old;
      return [
        { pass_key: passKey, pass_name: CANONICAL_STAGES.find(s => s.key === passKey)?.name || passKey, status: 'running', duration_ms: null, error_message: null, retry_attempt: 0 },
        ...old,
      ];
    });
    try {
      await invokeRetry([passKey]);
      toast.success(`Retried ${CANONICAL_STAGES.find(s => s.key === passKey)?.name || passKey}`);
      queryClient.invalidateQueries({ queryKey: ['analysis-run-logs', transcriptId] });
    } catch (err: any) {
      toast.error(`Retry failed: ${err.message || 'Unknown error'}`);
      queryClient.invalidateQueries({ queryKey: ['analysis-run-logs', transcriptId] });
    } finally {
      setRetryingStage(null);
    }
  };

  const handleRetryIncomplete = async () => {
    const keys = incompleteStages.map(s => s.key);
    setRetryingStage('__all__');
    queryClient.setQueryData(['analysis-run-logs', transcriptId], (old: any[] | undefined) => {
      if (!old) return old;
      const synthetics = keys.map(k => ({
        pass_key: k, pass_name: CANONICAL_STAGES.find(s => s.key === k)?.name || k, status: 'running', duration_ms: null, error_message: null, retry_attempt: 0,
      }));
      return [...synthetics, ...old];
    });
    try {
      await invokeRetry(keys);
      toast.success(`Retrying ${keys.length} incomplete stage${keys.length > 1 ? 's' : ''}`);
      queryClient.invalidateQueries({ queryKey: ['analysis-run-logs', transcriptId] });
    } catch (err: any) {
      toast.error(`Retry failed: ${err.message || 'Unknown error'}`);
      queryClient.invalidateQueries({ queryKey: ['analysis-run-logs', transcriptId] });
    } finally {
      setRetryingStage(null);
    }
  };

  const show = useCallback(() => {
    clearTimeout(hideTimeout.current);
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      setTooltipPos({ top: rect.bottom + 6, left: Math.max(8, rect.left) });
    }
    setShowTooltip(true);
  }, []);

  const hide = useCallback(() => {
    hideTimeout.current = setTimeout(() => setShowTooltip(false), 150);
  }, []);

  const keepOpen = useCallback(() => {
    clearTimeout(hideTimeout.current);
  }, []);

  if (!stages.length) return null;

  return (
    <>
      <div
        ref={triggerRef}
        className={cn('flex items-center gap-1 cursor-default', className)}
        onMouseEnter={show}
        onMouseLeave={hide}
      >
        <Layers className={cn(
          'w-3.5 h-3.5 shrink-0',
          !hasAnyRuns ? 'text-muted-foreground/40' :
          allCompleted ? 'text-green-500' :
          hasFailed ? 'text-destructive' :
          hasRunning ? 'text-blue-500' :
          'text-muted-foreground'
        )} />
        <div className="flex items-center gap-px">
          {stages.map((stage) => (
            <div
              key={stage.key}
              className={cn(
                'h-2.5 w-3 rounded-[2px] first:rounded-l-sm last:rounded-r-sm transition-colors',
                statusColors[stage.status] || statusColors.pending,
              )}
            />
          ))}
        </div>
      </div>

      {showTooltip && createPortal(
        <div
          className="fixed z-[9999] animate-in fade-in-0 zoom-in-95 duration-100"
          style={{ top: tooltipPos.top, left: tooltipPos.left }}
          onMouseEnter={keepOpen}
          onMouseLeave={hide}
        >
          <div className="bg-popover border border-border rounded-md shadow-md text-xs divide-y divide-border max-w-xs">
            <div className="px-3 py-1.5 font-medium text-foreground bg-muted/50 rounded-t-md">
              Analysis Pipeline — {stages.length} stages
            </div>
            {stages.map((stage) => (
              <div key={stage.key} className="flex items-center gap-2 px-3 py-1.5">
                <div className={cn('w-2 h-2 rounded-[2px] shrink-0', statusColors[stage.status] || statusColors.pending)} />
                <span className="flex-1 truncate">{stage.name}</span>
                <span className="text-muted-foreground shrink-0">
                  {stage.status === 'completed' && stage.duration_ms != null
                    ? `${(stage.duration_ms / 1000).toFixed(1)}s`
                    : stage.status === 'failed'
                    ? stage.retry_attempt > 0 ? `retry #${stage.retry_attempt}` : 'failed'
                    : stage.status === 'running'
                    ? 'running…'
                    : stage.status === 'skipped'
                    ? 'skipped'
                    : '—'}
                </span>
                {(stage.status === 'failed' || (stage.status === 'pending' && hasPendingAfterRun)) && (
                  <button
                    onClick={(e) => { e.stopPropagation(); handleRetryStage(stage.key); }}
                    disabled={retryingStage === stage.key}
                    className="ml-1 p-0.5 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-foreground disabled:opacity-50"
                    title={`Retry ${stage.name}`}
                  >
                    <RotateCcw className={cn('h-3 w-3', retryingStage === stage.key && 'animate-spin')} />
                  </button>
                )}
              </div>
            ))}
            {hasFailed && (
              <div className="px-3 py-1.5 text-destructive bg-destructive/5">
                {stages.filter(s => s.status === 'failed').map(s => s.error_message).filter(Boolean)[0] || 'Analysis failed'}
              </div>
            )}
            {hasIncomplete && !hasRunning && (
              <div className="px-3 py-1.5 rounded-b-md">
                <button
                  onClick={(e) => { e.stopPropagation(); handleRetryIncomplete(); }}
                  disabled={retryingStage !== null}
                  className="flex items-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80 disabled:opacity-50 transition-colors"
                >
                  <RotateCcw className={cn('h-3 w-3', retryingStage === '__all__' && 'animate-spin')} />
                  Retry {incompleteStages.length} incomplete stage{incompleteStages.length > 1 ? 's' : ''}
                </button>
              </div>
            )}
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

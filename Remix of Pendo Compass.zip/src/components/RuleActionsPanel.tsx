import { useState, useRef } from 'react';
import { Plus, Trash2, Database, FileText, CheckCircle2, ListTodo, Zap, GripVertical, Pencil, Variable, UserCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { toast } from 'sonner';
import {
  RuleActionType,
  DetectionRuleAction,
  useUpsertRuleAction,
  useDeleteRuleAction,
  getActionTypeLabel,
} from '@/hooks/useDetectionRules';

interface RuleActionsPanelProps {
  ruleId: string;
  actions: DetectionRuleAction[];
  readinessCategories: any[];
  validationTaskTemplates: any[];
}

const ACTION_TYPE_ICONS: Record<RuleActionType, React.ElementType> = {
  update_field: Database,
  extract_data: FileText,
  answer_question: CheckCircle2,
  create_task: ListTodo,
  create_nba: Zap,
};

const ACTION_TYPE_COLORS: Record<RuleActionType, string> = {
  update_field: 'bg-blue-500/10 border-blue-500/20 text-blue-600',
  extract_data: 'bg-purple-500/10 border-purple-500/20 text-purple-600',
  answer_question: 'bg-green-500/10 border-green-500/20 text-green-600',
  create_task: 'bg-amber-500/10 border-amber-500/20 text-amber-600',
  create_nba: 'bg-orange-500/10 border-orange-500/20 text-orange-600',
};

export function RuleActionsPanel({
  ruleId,
  actions,
  readinessCategories,
  validationTaskTemplates,
}: RuleActionsPanelProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAction, setEditingAction] = useState<DetectionRuleAction | null>(null);
  const [selectedType, setSelectedType] = useState<RuleActionType | ''>('');
  
  // Form state for each action type
  const [fieldName, setFieldName] = useState('');
  const [fieldType, setFieldType] = useState('text');
  const [extractionPrompt, setExtractionPrompt] = useState('');
  const [fieldDescription, setFieldDescription] = useState('');
  const [trackHistory, setTrackHistory] = useState(true); // Default to tracking history
  const [targetEntity, setTargetEntity] = useState<'account' | 'opportunity'>('opportunity');
  const [questionId, setQuestionId] = useState('');
  const [autoAnswer, setAutoAnswer] = useState('');
  const [templateId, setTemplateId] = useState('');
  const [autoUpdateStatus, setAutoUpdateStatus] = useState<'not_started' | 'in_progress' | 'completed' | ''>('');
  const [nbaText, setNbaText] = useState('');
  const [nbaPriority, setNbaPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [nbaAssignTo, setNbaAssignTo] = useState('');
  const nbaTextareaRef = useRef<HTMLTextAreaElement>(null);
  
  const upsertAction = useUpsertRuleAction();
  const deleteAction = useDeleteRuleAction();

  const openEditDialog = (action: DetectionRuleAction) => {
    setEditingAction(action);
    setSelectedType(action.action_type);
    const config = action.action_config as any;
    
    switch (action.action_type) {
      case 'update_field':
        setFieldName(config.field_name || '');
        setTargetEntity((action.target_entity === 'account' || action.target_entity === 'opportunity') ? action.target_entity : 'opportunity');
        break;
      case 'extract_data':
        setFieldName(config.field_name || '');
        setFieldType(config.field_type || 'text');
        setExtractionPrompt(config.extraction_prompt || '');
        setFieldDescription(config.description || '');
        setTrackHistory(config.track_history !== false); // Default true
        break;
      case 'answer_question':
        setQuestionId(config.question_id || '');
        setAutoAnswer(config.auto_answer || '');
        break;
      case 'create_task':
        setTemplateId(config.template_id || '');
        setAutoUpdateStatus(config.auto_update_status || '');
        break;
      case 'create_nba':
        setNbaText(config.action_text || '');
        setNbaPriority(config.priority || 'medium');
        setNbaAssignTo(config.assign_to || '');
        break;
    }
    setDialogOpen(true);
  };

  const resetForm = () => {
    setEditingAction(null);
    setSelectedType('');
    setFieldName('');
    setFieldType('text');
    setExtractionPrompt('');
    setFieldDescription('');
    setTrackHistory(true);
    setTargetEntity('opportunity');
    setQuestionId('');
    setAutoAnswer('');
    setTemplateId('');
    setAutoUpdateStatus('');
    setNbaText('');
    setNbaPriority('medium');
    setNbaAssignTo('');
  };

  const handleSaveAction = async () => {
    if (!selectedType) return;

    try {
      let action_config: any = {};
      let target: 'account' | 'opportunity' | null = null;

      switch (selectedType) {
        case 'update_field':
          if (!fieldName.trim()) {
            toast.error('Field name is required');
            return;
          }
          action_config = {
            field_name: fieldName.trim().toLowerCase().replace(/\s+/g, '_'),
            value_type: 'timestamp',
          };
          target = targetEntity;
          break;

        case 'extract_data':
          if (!fieldName.trim()) {
            toast.error('Field name is required');
            return;
          }
          action_config = {
            field_name: fieldName.trim(),
            field_type: fieldType,
            extraction_prompt: extractionPrompt.trim() || null,
            description: fieldDescription.trim() || null,
            is_required: false,
            track_history: trackHistory,
          };
          target = 'account';
          break;

        case 'answer_question':
          if (!questionId) {
            toast.error('Please select a question');
            return;
          }
          action_config = {
            question_id: questionId,
            auto_answer: autoAnswer.trim() || null,
            auto_answer_json: null,
          };
          target = 'opportunity';
          break;

        case 'create_task':
          if (!templateId) {
            toast.error('Please select a task template');
            return;
          }
          action_config = {
            template_id: templateId,
            auto_update_status: autoUpdateStatus || null,
          };
          target = 'opportunity';
          break;
          target = 'opportunity';
          break;

        case 'create_nba':
          if (!nbaText.trim()) {
            toast.error('Action text is required');
            return;
          }
          action_config = {
            action_text: nbaText.trim(),
            priority: nbaPriority,
            assign_to: nbaAssignTo || null,
          };
          target = 'opportunity';
          break;
      }

      await upsertAction.mutateAsync({
        id: editingAction?.id, // Pass existing ID for updates
        rule_id: ruleId,
        action_type: selectedType,
        action_config,
        target_entity: target,
        sort_order: editingAction ? editingAction.sort_order : actions.length,
      });

      toast.success(editingAction ? 'Action updated' : 'Action added');
      setDialogOpen(false);
      resetForm();
    } catch (error) {
      toast.error(editingAction ? 'Failed to update action' : 'Failed to add action');
    }
  };

  const handleDeleteAction = async (actionId: string) => {
    try {
      await deleteAction.mutateAsync({ id: actionId, ruleId });
      toast.success('Action removed');
    } catch (error) {
      toast.error('Failed to remove action');
    }
  };

  const getActionSummary = (action: DetectionRuleAction): string => {
    const config = action.action_config as any;
    switch (action.action_type) {
      case 'update_field':
        return `Set ${config.field_name} → ${config.value_type}`;
      case 'extract_data':
        return `Extract "${config.field_name}" as ${config.field_type}`;
      case 'answer_question':
        return config.auto_answer 
          ? `Auto-answer: "${config.auto_answer}"`
          : 'Mark question as detected';
      case 'create_task':
        return 'Create validation task';
      case 'create_nba':
        return `Create NBA: "${config.action_text?.substring(0, 40)}..."`;
      default:
        return 'Unknown action';
    }
  };

  const getQuestionName = (questionId: string): string => {
    for (const cat of readinessCategories) {
      const q = cat.questions?.find((q: any) => q.id === questionId);
      if (q) return q.question;
    }
    return 'Unknown question';
  };

  const getTemplateName = (templateId: string): string => {
    const t = validationTaskTemplates.find((t: any) => t.id === templateId);
    return t ? t.activity : 'Unknown template';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="font-medium text-sm">Rule Actions</h4>
          <p className="text-xs text-muted-foreground">
            When this rule matches, these actions will be executed
          </p>
        </div>
        <Button size="sm" variant="outline" onClick={() => setDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-1" />
          Add Action
        </Button>
      </div>

      {actions.length === 0 ? (
        <div className="text-sm text-muted-foreground p-6 bg-muted/20 rounded-md text-center border border-dashed">
          No actions configured. Add an action to define what happens when this rule matches.
        </div>
      ) : (
        <div className="space-y-2">
          {actions.map((action, index) => {
            const Icon = ACTION_TYPE_ICONS[action.action_type];
            const colorClass = ACTION_TYPE_COLORS[action.action_type];
            const config = action.action_config as any;
            
            return (
              <div
                key={action.id}
                className={`flex items-start gap-3 p-3 rounded-lg border ${colorClass}`}
              >
                <div className="flex items-center gap-2 text-muted-foreground">
                  <GripVertical className="w-4 h-4 cursor-grab opacity-50" />
                  <span className="text-xs font-medium w-4">{index + 1}</span>
                </div>
                <Icon className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className="text-xs">
                      {getActionTypeLabel(action.action_type)}
                    </Badge>
                    {action.target_entity && (
                      <Badge variant="secondary" className="text-xs capitalize">
                        {action.target_entity}
                      </Badge>
                    )}
                  </div>
                  <div className="text-sm mt-1">
                    {action.action_type === 'update_field' && (
                      <span>Set <code className="bg-muted px-1 rounded text-xs">{config.field_name}</code></span>
                    )}
                    {action.action_type === 'extract_data' && (
                      <span>Extract "{config.field_name}" as <code className="bg-muted px-1 rounded text-xs">{config.field_type}</code></span>
                    )}
                    {action.action_type === 'answer_question' && (
                      <span className="line-clamp-1">{getQuestionName(config.question_id)}</span>
                    )}
                    {action.action_type === 'create_task' && (
                      <span>{getTemplateName(config.template_id)}</span>
                    )}
                  {action.action_type === 'create_nba' && (
                    <span className="line-clamp-1">{config.action_text}</span>
                  )}
                  </div>
                  {action.action_type === 'create_nba' && config.assign_to && (
                    <Badge variant="secondary" className="text-xs mt-1">
                      <UserCircle className="w-3 h-3 mr-1" />
                      {config.assign_to.startsWith('role:') ? config.assign_to.replace('role:', '').replace(/_/g, ' ') : config.assign_to}
                    </Badge>
                  )}
                  {action.action_type === 'answer_question' && config.auto_answer && (
                    <div className="mt-1">
                      <Badge variant="secondary" className="text-xs">
                        Auto-answer: {config.auto_answer}
                      </Badge>
                    </div>
                  )}
                  {action.action_type === 'extract_data' && config.extraction_prompt && (
                    <p className="text-xs text-muted-foreground mt-1 italic line-clamp-1">
                      Prompt: "{config.extraction_prompt}"
                    </p>
                  )}
                  {action.action_type === 'create_nba' && (
                    <Badge variant="outline" className="text-xs mt-1 capitalize">
                      {config.priority} priority
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openEditDialog(action)}
                    className="p-1 hover:bg-muted rounded"
                  >
                    <Pencil className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                  </button>
                  <button
                    onClick={() => handleDeleteAction(action.id)}
                    className="p-1 hover:bg-destructive/10 rounded"
                  >
                    <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add/Edit Action Dialog */}
      <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) resetForm(); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingAction ? 'Edit Action' : 'Add Action'}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Action Type</Label>
              <Select value={selectedType} onValueChange={(v) => setSelectedType(v as RuleActionType)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select what happens when rule matches" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="update_field">
                    <div className="flex items-center gap-2">
                      <Database className="w-4 h-4" />
                      Update Field — Record detection timestamp
                    </div>
                  </SelectItem>
                  <SelectItem value="extract_data">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Extract Data — AI extracts structured data
                    </div>
                  </SelectItem>
                  <SelectItem value="answer_question">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      Answer Question — Auto-fill readiness answer
                    </div>
                  </SelectItem>
                  <SelectItem value="create_task">
                    <div className="flex items-center gap-2">
                      <ListTodo className="w-4 h-4" />
                      Create Task — Generate validation task
                    </div>
                  </SelectItem>
                  <SelectItem value="create_nba">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4" />
                      Create NBA — Generate next best action
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Update Field Form */}
            {selectedType === 'update_field' && (
              <div className="space-y-4 p-4 bg-muted/20 rounded-lg">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Field Name</Label>
                    <Input
                      value={fieldName}
                      onChange={(e) => setFieldName(e.target.value.toLowerCase().replace(/\s+/g, '_'))}
                      placeholder="e.g., pricing_discussed"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Store On</Label>
                    <Select value={targetEntity} onValueChange={(v) => setTargetEntity(v as 'account' | 'opportunity')}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="opportunity">Opportunity</SelectItem>
                        <SelectItem value="account">Account</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  When matched, records detection timestamp in <code className="bg-muted px-1 rounded">detection_signal_fields.{fieldName || 'field_name'}</code>
                </p>
              </div>
            )}

            {/* Extract Data Form */}
            {selectedType === 'extract_data' && (
              <div className="space-y-4 p-4 bg-muted/20 rounded-lg">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Field Name</Label>
                    <Input
                      value={fieldName}
                      onChange={(e) => setFieldName(e.target.value)}
                      placeholder="e.g., Contract End Date"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Field Type</Label>
                    <Select value={fieldType} onValueChange={setFieldType}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="text">Text</SelectItem>
                        <SelectItem value="number">Number</SelectItem>
                        <SelectItem value="date">Date</SelectItem>
                        <SelectItem value="boolean">Yes/No</SelectItem>
                        <SelectItem value="list">List</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Extraction Prompt</Label>
                  <Textarea
                    value={extractionPrompt}
                    onChange={(e) => setExtractionPrompt(e.target.value)}
                    placeholder="e.g., Extract the date when their current contract expires"
                    rows={2}
                  />
                  <p className="text-xs text-muted-foreground">
                    Instructions for AI on how to extract this value from transcripts
                  </p>
                </div>
                
                {/* Track History Toggle */}
                <div className="flex items-start gap-3 p-3 bg-blue-500/5 border border-blue-500/20 rounded-md">
                  <input
                    type="checkbox"
                    id="track-history"
                    checked={trackHistory}
                    onChange={(e) => setTrackHistory(e.target.checked)}
                    className="mt-0.5 h-4 w-4 rounded border-muted-foreground/50"
                  />
                  <div className="flex-1">
                    <label htmlFor="track-history" className="text-sm font-medium cursor-pointer">
                      Track Historical Changes
                    </label>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      When enabled, each extracted value is stored with the transcript date and a link to the source transcript, 
                      allowing you to trend changes over time.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Answer Question Form */}
            {selectedType === 'answer_question' && (
              <div className="space-y-4 p-4 bg-muted/20 rounded-lg">
                <div className="space-y-2">
                  <Label>Readiness Question</Label>
                  <Select value={questionId} onValueChange={setQuestionId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a question to auto-answer" />
                    </SelectTrigger>
                    <SelectContent className="max-h-80">
                      {readinessCategories.map((cat: any) => (
                        <div key={cat.id}>
                          <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-muted/50">
                            {cat.name} {cat.deployment_type?.name && `(${cat.deployment_type.name})`}
                          </div>
                          {cat.questions?.map((q: any) => (
                            <SelectItem key={q.id} value={q.id} className="pl-4">
                              {q.question}
                            </SelectItem>
                          ))}
                        </div>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Auto-Answer Value (optional)</Label>
                  <Input
                    value={autoAnswer}
                    onChange={(e) => setAutoAnswer(e.target.value)}
                    placeholder="Value to auto-fill when rule matches"
                  />
                  <p className="text-xs text-muted-foreground">
                    If provided, this answer will be applied automatically
                  </p>
                </div>
              </div>
            )}

            {/* Create Task Form */}
            {selectedType === 'create_task' && (
              <div className="space-y-4 p-4 bg-muted/20 rounded-lg">
                <div className="space-y-2">
                  <Label>Validation Task Template</Label>
                  <Select value={templateId} onValueChange={setTemplateId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a task template" />
                    </SelectTrigger>
                    <SelectContent className="max-h-80">
                      {Object.entries(
                        validationTaskTemplates.reduce((acc: Record<string, any[]>, t: any) => {
                          const key = t.module;
                          if (!acc[key]) acc[key] = [];
                          acc[key].push(t);
                          return acc;
                        }, {})
                      ).map(([module, tasks]) => (
                        <div key={module}>
                          <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-muted/50">
                            {module}
                          </div>
                          {(tasks as any[]).map((t: any) => (
                            <SelectItem key={t.id} value={t.id} className="text-sm">
                              {t.sub_module && <span className="text-muted-foreground">{t.sub_module}: </span>}
                              {t.activity}
                            </SelectItem>
                          ))}
                        </div>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Auto-Update Status (optional)</Label>
                  <Select value={autoUpdateStatus} onValueChange={(v) => setAutoUpdateStatus(v as any)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Don't update status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Don't update status</SelectItem>
                      <SelectItem value="in_progress">Mark as In Progress</SelectItem>
                      <SelectItem value="completed">Mark as Completed</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    If set, updates the task status when this rule matches (for existing tasks too)
                  </p>
                </div>
                
                <p className="text-xs text-muted-foreground border-t pt-3 mt-2">
                  Creates the task if it doesn't exist. If it already exists, only the status is updated (if configured above).
                </p>
              </div>
            )}

            {/* Create NBA Form */}
            {selectedType === 'create_nba' && (
              <div className="space-y-4 p-4 bg-muted/20 rounded-lg">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Action Text</Label>
                    <span className="text-xs text-muted-foreground">Use parameters below to inject context</span>
                  </div>
                  <Textarea
                    ref={nbaTextareaRef}
                    value={nbaText}
                    onChange={(e) => setNbaText(e.target.value)}
                    placeholder="e.g., Prepare the demo for {{account_name}} focusing on {{use_case}}"
                    rows={3}
                  />
                  <div className="flex flex-wrap gap-1">
                    {[
                      { token: '{{account_name}}', label: 'Account' },
                      { token: '{{opportunity_name}}', label: 'Opportunity' },
                      { token: '{{stakeholder_name}}', label: 'Stakeholder' },
                      { token: '{{competitor_name}}', label: 'Competitor' },
                      { token: '{{use_case}}', label: 'Use Case' },
                      { token: '{{industry}}', label: 'Industry' },
                      { token: '{{pain_point}}', label: 'Pain Point' },
                    ].map(({ token, label }) => (
                      <button
                        key={token}
                        type="button"
                        className="inline-flex items-center gap-1 px-2 py-0.5 text-xs rounded-full border border-primary/30 bg-primary/5 text-primary hover:bg-primary/10 transition-colors"
                        onClick={() => {
                          const ta = nbaTextareaRef.current;
                          if (ta) {
                            const start = ta.selectionStart;
                            const end = ta.selectionEnd;
                            const newText = nbaText.slice(0, start) + token + nbaText.slice(end);
                            setNbaText(newText);
                            setTimeout(() => {
                              ta.focus();
                              ta.setSelectionRange(start + token.length, start + token.length);
                            }, 0);
                          } else {
                            setNbaText(nbaText + token);
                          }
                        }}
                      >
                        <Variable className="w-3 h-3" />
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Priority</Label>
                    <Select value={nbaPriority} onValueChange={(v) => setNbaPriority(v as 'low' | 'medium' | 'high')}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-1">
                      <UserCircle className="w-3.5 h-3.5" />
                      Assign To
                    </Label>
                    <Select value={nbaAssignTo} onValueChange={setNbaAssignTo}>
                      <SelectTrigger>
                        <SelectValue placeholder="Unassigned" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Unassigned</SelectItem>
                        <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-muted/50">By Role</div>
                        <SelectItem value="role:opportunity_owner">Opportunity Owner</SelectItem>
                        <SelectItem value="role:primary_se">Primary SE</SelectItem>
                        <SelectItem value="role:account_owner">Account Owner</SelectItem>
                        <SelectItem value="role:account_se">Account SE</SelectItem>
                        <SelectItem value="role:meeting_host">Meeting Host</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground border-t pt-3 mt-1">
                  Parameters are resolved at execution time from the matched transcript's context. Role-based assignment maps to the user holding that role on the account or opportunity.
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => { setDialogOpen(false); resetForm(); }}>
              Cancel
            </Button>
            <Button 
              onClick={handleSaveAction} 
              disabled={!selectedType || upsertAction.isPending}
            >
              Add Action
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
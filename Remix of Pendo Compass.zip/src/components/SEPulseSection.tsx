import { useState, useMemo, useRef, useCallback, useEffect } from 'react';
import { ChevronDown, ChevronUp, Activity, Building2, AlertTriangle, FileText, Check, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useOpportunitySEUpdates } from '@/hooks/useOpportunitySEUpdates';
import { format, parseISO, differenceInDays } from 'date-fns';
import { toast } from 'sonner';

const preSalesStageOptions = [
  { value: 'Discovery', label: 'Discovery' },
  { value: 'Demo', label: 'Demo' },
  { value: 'Proof - Scoping', label: 'Proof - Scoping' },
  { value: 'Proof', label: 'Proof' },
  { value: 'Technical Win', label: 'Technical Win' },
  { value: 'Technical Loss', label: 'Technical Loss' },
  { value: 'Unqualified', label: 'Unqualified' },
];

interface SEPulseSectionProps {
  onSelectAccount: (accountId: string) => void;
}

/** Auto-save debounce helper */
function useDebouncedCallback(fn: (...args: any[]) => void, delay: number) {
  const timer = useRef<ReturnType<typeof setTimeout>>();
  const callback = useCallback((...args: any[]) => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => fn(...args), delay);
  }, [fn, delay]);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  return callback;
}

export function SEPulseSection({ onSelectAccount }: SEPulseSectionProps) {
  const { effectiveUserEmail } = useAuth();
  const [isOpen, setIsOpen] = useState(true);
  const [drafts, setDrafts] = useState<Record<string, { weekly_update: string; potential_risks: string; pre_sales_stage: string }>>({});
  const [saving, setSaving] = useState<Record<string, boolean>>({});
  const [saved, setSaved] = useState<Record<string, boolean>>({});
  const [editingOppIds, setEditingOppIds] = useState<Set<string>>(new Set());
  const queryClient = useQueryClient();

  // Fetch active opportunities where user is PRIMARY SE on the opportunity
  const { data: myOpportunities, isLoading } = useQuery({
    queryKey: ['se-pulse-opportunities', effectiveUserEmail],
    queryFn: async () => {
      if (!effectiveUserEmail) return [];
      const { data, error } = await gateway
        .from('opportunities')
        .select('id, name, account_id, sales_stage, pre_sales_stage, value, close_date, primary_se_email, accounts(name)')
        .ilike('primary_se_email', effectiveUserEmail)
        .eq('is_archived', false)
        .order('close_date', { ascending: true })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: !!effectiveUserEmail,
  });

  const opportunityIds = useMemo(() => (myOpportunities || []).map((o: any) => o.id), [myOpportunities]);
  const { data: seUpdates } = useOpportunitySEUpdates(opportunityIds);

  const updatesMap = useMemo(() => {
    const map = new Map<string, any>();
    (seUpdates || []).forEach((u: any) => map.set(u.opportunity_id, u));
    return map;
  }, [seUpdates]);

  // Initialize drafts when data loads
  useEffect(() => {
    if (!myOpportunities) return;
    setDrafts(prev => {
      const next = { ...prev };
      myOpportunities.forEach((opp: any) => {
        if (!next[opp.id]) {
          const existing = updatesMap.get(opp.id);
          next[opp.id] = {
            weekly_update: existing?.weekly_update || '',
            potential_risks: existing?.potential_risks || '',
            pre_sales_stage: opp.pre_sales_stage || '',
          };
        }
      });
      return next;
    });
  }, [myOpportunities, updatesMap]);

  const doSave = useCallback(async (oppId: string, draft: { weekly_update: string; potential_risks: string; pre_sales_stage: string }) => {
    if (!effectiveUserEmail) return;
    setSaving(p => ({ ...p, [oppId]: true }));
    setSaved(p => ({ ...p, [oppId]: false }));
    try {
      const opp = myOpportunities?.find((o: any) => o.id === oppId);
      // Upsert SE update
      const { error: upsertErr } = await gateway
        .from('opportunity_se_updates')
        .upsert({
          opportunity_id: oppId,
          updated_by: effectiveUserEmail,
          weekly_update: draft.weekly_update || null,
          potential_risks: draft.potential_risks || null,
        }, { onConflict: 'opportunity_id' })
        .execute();
      if (upsertErr) throw new Error(getErrorMessage(upsertErr));

      // Update pre-sales stage if changed
      if (draft.pre_sales_stage && draft.pre_sales_stage !== opp?.pre_sales_stage) {
        const { error: stageErr } = await gateway
          .from('opportunities')
          .update({ pre_sales_stage: draft.pre_sales_stage })
          .eq('id', oppId)
          .execute();
        if (stageErr) throw new Error(getErrorMessage(stageErr));
      }

      queryClient.invalidateQueries({ queryKey: ['opportunity-se-updates'] });
      queryClient.invalidateQueries({ queryKey: ['se-pulse-opportunities'] });
      setSaved(p => ({ ...p, [oppId]: true }));
      setTimeout(() => setSaved(p => ({ ...p, [oppId]: false })), 2000);
    } catch (err: any) {
      console.error('SE Pulse save error:', err);
      toast.error(`Failed to save: ${err.message}`);
    } finally {
      setSaving(p => ({ ...p, [oppId]: false }));
    }
  }, [effectiveUserEmail, myOpportunities, queryClient]);

  const debouncedSave = useDebouncedCallback((oppId: string, draft: any) => {
    doSave(oppId, draft);
  }, 1500);

  const updateDraft = (oppId: string, field: string, value: string) => {
    setEditingOppIds(prev => new Set(prev).add(oppId));
    setDrafts(prev => {
      const updated = { ...prev, [oppId]: { ...prev[oppId], [field]: value } };
      debouncedSave(oppId, updated[oppId]);
      return updated;
    });
  };

  const handleStageChange = (oppId: string, value: string) => {
    setDrafts(prev => {
      const updated = { ...prev, [oppId]: { ...prev[oppId], pre_sales_stage: value } };
      // Save stage immediately (no debounce)
      doSave(oppId, updated[oppId]);
      return updated;
    });
  };

  // Split opportunities into "due" (no update in 7 days) and "up to date"
  const { dueOpportunities, upToDateOpportunities } = useMemo(() => {
    if (!myOpportunities) return { dueOpportunities: [], upToDateOpportunities: [] };
    const due: any[] = [];
    const upToDate: any[] = [];
    for (const opp of myOpportunities) {
      // Keep the opp in "due" if the user is actively editing it
      if (editingOppIds.has(opp.id)) {
        due.push(opp);
        continue;
      }
      const existing = updatesMap.get(opp.id);
      if (existing?.updated_at) {
        const daysSinceUpdate = differenceInDays(new Date(), parseISO(existing.updated_at));
        if (daysSinceUpdate < 7) {
          upToDate.push(opp);
          continue;
        }
      }
      due.push(opp);
    }
    return { dueOpportunities: due, upToDateOpportunities: upToDate };
  }, [myOpportunities, updatesMap, editingOppIds]);
  const handleRowBlur = useCallback((oppId: string) => {
    setTimeout(() => {
      setEditingOppIds(prev => {
        const next = new Set(prev);
        next.delete(oppId);
        return next;
      });
    }, 500);
  }, []);

  if (!effectiveUserEmail || (myOpportunities && myOpportunities.length === 0)) {
    return null;
  }

  const renderOpportunityRow = (opp: any) => {
    const draft = drafts[opp.id];
    const existing = updatesMap.get(opp.id);
    const isSaving = saving[opp.id];
    const isSaved = saved[opp.id];

    return (
      <div key={opp.id} className="px-5 py-3">
        {/* Row header */}
        <div className="flex items-center justify-between gap-4 mb-2">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => onSelectAccount(opp.account_id)}
              className="flex items-center gap-1.5 text-sm font-medium text-foreground hover:text-primary transition-colors truncate"
            >
              <Building2 className="w-3.5 h-3.5 shrink-0 text-muted-foreground" />
              <span className="truncate">{opp.accounts?.name}</span>
            </button>
            <span className="text-muted-foreground">·</span>
            <span className="text-sm text-muted-foreground truncate">{opp.name}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {opp.close_date && (
              <span className="text-xs text-muted-foreground">
                Close: {format(parseISO(opp.close_date), 'MMM d')}
              </span>
            )}
            {isSaving && <Loader2 className="w-3.5 h-3.5 text-muted-foreground animate-spin" />}
            {isSaved && <Check className="w-3.5 h-3.5 text-green-500" />}
            {existing?.updated_at && !isSaving && !isSaved && (
              <span className="text-[10px] text-muted-foreground">
                Updated {format(parseISO(existing.updated_at), 'MMM d')}
              </span>
            )}
          </div>
        </div>

        {/* Always-visible edit form */}
        {draft && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Weekly Update</label>
              <Textarea
                value={draft.weekly_update}
                onChange={(e) => updateDraft(opp.id, 'weekly_update', e.target.value)}
                onFocus={() => setEditingOppIds(prev => new Set(prev).add(opp.id))}
                onBlur={() => handleRowBlur(opp.id)}
                placeholder="What happened this week?"
                className="h-20 text-sm resize-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Potential Risks</label>
              <Textarea
                value={draft.potential_risks}
                onChange={(e) => updateDraft(opp.id, 'potential_risks', e.target.value)}
                onFocus={() => setEditingOppIds(prev => new Set(prev).add(opp.id))}
                onBlur={() => handleRowBlur(opp.id)}
                placeholder="Any risks or blockers?"
                className="h-20 text-sm resize-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Pre-Sales Stage</label>
              <Select
                value={draft.pre_sales_stage}
                onValueChange={(value) => handleStageChange(opp.id, value)}
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Select stage" />
                </SelectTrigger>
                <SelectContent>
                  {preSalesStageOptions.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <div className="glass rounded-xl border border-border">
        <CollapsibleTrigger asChild>
          <button className="w-full flex items-center justify-between px-5 py-3.5 hover:bg-muted/30 transition-colors rounded-t-xl">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <Activity className="w-4 h-4 text-primary" />
              </div>
              <div className="text-left">
                <h2 className="text-sm font-semibold text-foreground">SE Opportunity Pulse</h2>
                <p className="text-xs text-muted-foreground">
                  {dueOpportunities.length > 0
                    ? `${dueOpportunities.length} update${dueOpportunities.length > 1 ? 's' : ''} due`
                    : 'All up to date'}
                  {' · '}
                  {myOpportunities?.length || 0} active opportunities
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {dueOpportunities.length > 0 && (
                <Badge variant="outline" className="text-xs border-destructive/30 text-destructive bg-destructive/10">
                  {dueOpportunities.length} due
                </Badge>
              )}
              {isOpen ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </div>
          </button>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <div className="border-t border-border">
            {isLoading ? (
              <div className="p-4 space-y-3">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
              </div>
            ) : (
              <Tabs defaultValue="due" className="w-full">
                <div className="px-5 pt-2">
                  <TabsList className="h-8">
                    <TabsTrigger value="due" className="text-xs h-7">
                      Due ({dueOpportunities.length})
                    </TabsTrigger>
                    <TabsTrigger value="all" className="text-xs h-7">
                      All ({myOpportunities?.length || 0})
                    </TabsTrigger>
                  </TabsList>
                </div>
                <TabsContent value="due" className="mt-0">
                  <div className="divide-y divide-border">
                    {dueOpportunities.length > 0 ? (
                      dueOpportunities.map(renderOpportunityRow)
                    ) : (
                      <div className="px-5 py-6 text-center">
                        <Check className="w-5 h-5 text-green-500 mx-auto mb-1" />
                        <p className="text-sm text-muted-foreground">All opportunities are up to date</p>
                      </div>
                    )}
                  </div>
                </TabsContent>
                <TabsContent value="all" className="mt-0">
                  <div className="divide-y divide-border">
                    {myOpportunities?.map(renderOpportunityRow)}
                  </div>
                </TabsContent>
              </Tabs>
            )}
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}

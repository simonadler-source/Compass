import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Shield, CheckCircle, Copy, Smartphone } from 'lucide-react';
import QRCode from 'qrcode';
import { useAuth } from '@/contexts/AuthContext';

interface Setup2FADialogProps {
  sessionToken: string;
  onComplete: () => void;
  onSkip?: () => void;
}

export function Setup2FADialog({ sessionToken, onComplete, onSkip }: Setup2FADialogProps) {
  const [step, setStep] = useState<'intro' | 'qr' | 'verify' | 'success'>('intro');
  const [secret, setSecret] = useState('');
  const [otpAuthUri, setOtpAuthUri] = useState('');
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const queryClient = useQueryClient();
  const { user, updateMfaStatus } = useAuth();

  const startSetup = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('auth', {
        body: { action: 'setup-2fa' },
        headers: { Authorization: `Bearer ${sessionToken}` }
      });

      if (error || !data?.success) {
        throw new Error(data?.error || 'Failed to start 2FA setup');
      }

      setSecret(data.secret);
      setOtpAuthUri(data.otpAuthUri);

      // Generate QR code
      const qrUrl = await QRCode.toDataURL(data.otpAuthUri, {
        width: 256,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#ffffff',
        },
      });
      setQrCodeDataUrl(qrUrl);
      setStep('qr');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const verifyCode = async () => {
    if (verificationCode.length !== 6) {
      toast.error('Please enter a 6-digit code');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('auth', {
        headers: { Authorization: `Bearer ${sessionToken}` },
        body: { action: 'verify-2fa', code: verificationCode }
      });

      if (error || !data?.success) {
        throw new Error(data?.error || 'Verification failed');
      }

      // Update the AuthContext user state with mfa_enabled=true
      updateMfaStatus(true);
      
      // Invalidate the user profile query so sidebar re-fetches with mfa_enabled=true
      queryClient.invalidateQueries({ queryKey: ['user-profile', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
      
      setStep('success');
      toast.success('2FA enabled successfully!');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const copySecret = async () => {
    try {
      await navigator.clipboard.writeText(secret);
      setCopied(true);
      toast.success('Secret copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Failed to copy');
    }
  };

  // Intro screen
  if (step === 'intro') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        
        <div className="glass rounded-2xl p-8 w-full max-w-md relative z-10">
          <div className="flex flex-col items-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-[hsl(var(--pendo-pink))]/10 flex items-center justify-center mb-4">
              <Shield className="w-8 h-8 text-[hsl(var(--pendo-pink))]" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Set Up 2FA</h1>
            <p className="text-sm text-muted-foreground text-center mt-2">
              Add an extra layer of security to your account with two-factor authentication.
            </p>
          </div>

          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-muted/50 border border-border space-y-2">
              <div className="flex items-start gap-3">
                <Smartphone className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <p className="font-medium text-sm">You'll need an authenticator app</p>
                  <p className="text-xs text-muted-foreground">
                    Such as Google Authenticator, Authy, or 1Password
                  </p>
                </div>
              </div>
            </div>

            <Button
              onClick={startSetup}
              className="w-full"
              variant="glow"
              disabled={loading}
            >
              {loading ? 'Setting up...' : 'Set Up 2FA'}
            </Button>

            {onSkip && (
              <button
                type="button"
                onClick={onSkip}
                className="w-full text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                Skip for now
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // QR Code screen
  if (step === 'qr') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        
        <div className="glass rounded-2xl p-8 w-full max-w-md relative z-10">
          <div className="flex flex-col items-center mb-6">
            <h1 className="text-2xl font-bold text-foreground mb-2">Scan QR Code</h1>
            <p className="text-sm text-muted-foreground text-center">
              Open your authenticator app and scan this QR code
            </p>
          </div>

          <div className="flex justify-center mb-6">
            {qrCodeDataUrl && (
              <div className="p-4 bg-white rounded-lg">
                <img src={qrCodeDataUrl} alt="2FA QR Code" className="w-48 h-48" />
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="p-3 rounded-lg bg-muted/50 border border-border">
              <p className="text-xs text-muted-foreground mb-1">Or enter this code manually:</p>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-xs font-mono break-all">{secret}</code>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={copySecret}
                  className="shrink-0"
                >
                  <Copy className={`w-4 h-4 ${copied ? 'text-green-500' : ''}`} />
                </Button>
              </div>
            </div>

            <Button
              onClick={() => setStep('verify')}
              className="w-full"
              variant="glow"
            >
              Continue
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Verify screen
  if (step === 'verify') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        
        <div className="glass rounded-2xl p-8 w-full max-w-md relative z-10">
          <div className="flex flex-col items-center mb-6">
            <h1 className="text-2xl font-bold text-foreground mb-2">Verify Setup</h1>
            <p className="text-sm text-muted-foreground text-center">
              Enter the 6-digit code from your authenticator app
            </p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="verification-code">Verification Code</Label>
              <Input
                id="verification-code"
                type="text"
                inputMode="numeric"
                autoComplete="one-time-code"
                placeholder="123456"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                maxLength={6}
                className="text-center text-2xl tracking-widest"
              />
            </div>

            <Button
              onClick={verifyCode}
              className="w-full"
              variant="glow"
              disabled={loading || verificationCode.length !== 6}
            >
              {loading ? 'Verifying...' : 'Verify & Enable 2FA'}
            </Button>

            <button
              type="button"
              onClick={() => setStep('qr')}
              className="w-full text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              Back to QR Code
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Success screen
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="fixed inset-0 bg-glow pointer-events-none" />
      
      <div className="glass rounded-2xl p-8 w-full max-w-md relative z-10">
        <div className="flex flex-col items-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-green-500/10 flex items-center justify-center mb-4">
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">2FA Enabled!</h1>
          <p className="text-sm text-muted-foreground text-center mt-2">
            Your account is now protected with two-factor authentication.
          </p>
        </div>

        <Button
          onClick={onComplete}
          className="w-full"
          variant="glow"
        >
          Continue to App
        </Button>
      </div>
    </div>
  );
}

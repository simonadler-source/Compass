import { useState, useEffect } from 'react';
import { Hash, Search, Users, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';


interface SlackChannelOption {
  id: string;
  name: string;
  topic: string;
  purpose: string;
  num_members: number;
  is_member: boolean;
}

interface SlackChannelPickerProps {
  onSelect: (channel: { id: string; name: string }) => void;
  excludeIds?: string[];
}

export function SlackChannelPicker({ onSelect, excludeIds = [] }: SlackChannelPickerProps) {
  const [search, setSearch] = useState('');
  const [channels, setChannels] = useState<SlackChannelOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError(null);
      try {
        const { data, error: fnError } = await supabase.functions.invoke('list-slack-channels', {
          body: null,
        });
        if (fnError) throw fnError;
        if (!cancelled) {
          setChannels(data?.channels || []);
        }
      } catch (err: any) {
        if (!cancelled) setError(err.message || 'Failed to load channels');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => { cancelled = true; };
  }, []);

  const filtered = channels.filter(ch => {
    if (excludeIds.includes(ch.id)) return false;
    if (!search) return true;
    const q = search.toLowerCase();
    return ch.name.toLowerCase().includes(q) || ch.topic.toLowerCase().includes(q) || ch.purpose.toLowerCase().includes(q);
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8 text-muted-foreground gap-2">
        <Loader2 className="w-4 h-4 animate-spin" />
        <span className="text-sm">Loading Slack channels…</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-sm text-destructive py-4 text-center">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search channels…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>
      <p className="text-xs text-muted-foreground">Channels marked "Invite bot" need the Lovable App invited first.</p>
      <ScrollArea className="h-[240px]">
        {filtered.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            {search ? 'No matching channels' : 'No channels available'}
          </p>
        ) : (
          <div className="space-y-0.5">
            {filtered.map(ch => (
                <button
                  key={ch.id}
                  onClick={() => onSelect({ id: ch.id, name: ch.name })}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-left text-sm hover:bg-accent transition-colors"
                >
                  <Hash className="w-4 h-4 text-muted-foreground shrink-0" />
                  <div className="flex-1 min-w-0">
                    <span className="font-medium">{ch.name}</span>
                    {ch.topic && (
                      <p className="text-xs text-muted-foreground truncate">{ch.topic}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground shrink-0">
                    <Users className="w-3 h-3" />
                    {ch.num_members}
                  </div>
                </button>
              ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}

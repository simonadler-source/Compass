import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { 
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, 
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger 
} from '@/components/ui/alert-dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  MapPin, CalendarIcon, Users, ExternalLink, Pencil, Trash2, 
  Plus, X, Search, Building2, ChevronDown, ChevronRight, Upload 
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useTeamManualMeetings, useUpdateManualMeeting, useDeleteManualMeeting, MANUAL_MEETING_TYPES } from '@/hooks/useManualMeetings';
import AddManualMeetingDialog from '@/components/dialogs/AddManualMeetingDialog';
import ImportSalesforceActivitiesDialog from '@/components/dialogs/ImportSalesforceActivitiesDialog';
import { gateway } from '@/lib/apiGateway';
import { useQuery } from '@tanstack/react-query';

interface TeamManualMeetingsSectionProps {
  teamEmails: string[];
}

function EditMeetingDialog({ meeting, open, onOpenChange }: { meeting: any; open: boolean; onOpenChange: (v: boolean) => void }) {
  const updateMeeting = useUpdateManualMeeting();
  const [meetingType, setMeetingType] = useState(meeting.meeting_type);
  const [meetingDate, setMeetingDate] = useState<Date | undefined>(new Date(meeting.meeting_date));
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [notes, setNotes] = useState(meeting.notes || '');
  const [attendeeEmails, setAttendeeEmails] = useState<string[]>(meeting.attendee_emails || []);
  const [attendeeInput, setAttendeeInput] = useState('');
  const [oppSearch, setOppSearch] = useState('');
  const [selectedOpp, setSelectedOpp] = useState<any>(
    meeting.opportunities ? {
      id: meeting.opportunity_id,
      name: meeting.opportunities.name,
      accountId: meeting.opportunities.accounts?.id || meeting.account_id,
      accountName: meeting.opportunities.accounts?.name || 'Unknown',
      value: meeting.opportunities.value,
    } : null
  );

  const { data: oppResults } = useQuery({
    queryKey: ['opp-search-edit', oppSearch],
    queryFn: async () => {
      if (oppSearch.length < 2) return [];
      const result = await gateway.from('opportunities')
        .select('id, name, value, account_id, accounts(id, name)')
        .ilike('name', `%${oppSearch}%`)
        .eq('is_archived', false)
        .limit(8)
        .execute();
      return (result.data || []).map((o: any) => ({
        id: o.id, name: o.name, accountId: o.account_id,
        accountName: o.accounts?.name || 'Unknown', value: o.value,
      }));
    },
    enabled: oppSearch.length >= 2,
  });

  const handleAddAttendee = () => {
    const email = attendeeInput.trim().toLowerCase();
    if (email && !attendeeEmails.includes(email)) {
      setAttendeeEmails(prev => [...prev, email]);
      setAttendeeInput('');
    }
  };

  const handleSave = () => {
    updateMeeting.mutate({
      id: meeting.id,
      meeting_type: meetingType,
      meeting_date: meetingDate?.toISOString(),
      notes: notes || null,
      attendee_emails: attendeeEmails,
      opportunity_id: selectedOpp?.id || null,
      account_id: selectedOpp?.accountId || null,
    }, { onSuccess: () => onOpenChange(false) });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Pencil className="h-5 w-5 text-primary" />
            Edit Meeting
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          {/* Opportunity */}
          <div className="space-y-2">
            <Label>Opportunity</Label>
            {selectedOpp ? (
              <div className="flex items-center gap-2 bg-muted/50 rounded-lg px-3 py-2 border">
                <Building2 className="h-4 w-4 text-primary shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{selectedOpp.name}</p>
                  <p className="text-xs text-muted-foreground">{selectedOpp.accountName}</p>
                </div>
                <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => { setSelectedOpp(null); setOppSearch(''); }}>
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ) : (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search opportunities..." value={oppSearch} onChange={(e) => setOppSearch(e.target.value)} className="pl-9" />
                {oppResults && oppResults.length > 0 && oppSearch.length >= 2 && (
                  <div className="absolute z-50 w-full mt-1 bg-popover border rounded-lg shadow-lg max-h-48 overflow-y-auto">
                    {oppResults.map((opp: any) => (
                      <button key={opp.id} className="w-full text-left px-3 py-2 hover:bg-accent text-sm" onClick={() => { setSelectedOpp(opp); setOppSearch(''); }}>
                        <p className="font-medium">{opp.name}</p>
                        <p className="text-xs text-muted-foreground">{opp.accountName}</p>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Type & Date */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Type</Label>
              <Select value={meetingType} onValueChange={setMeetingType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {MANUAL_MEETING_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Date</Label>
              <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !meetingDate && "text-muted-foreground")}>
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {meetingDate ? format(meetingDate, 'PPP') : 'Pick a date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={meetingDate} onSelect={(d) => { setMeetingDate(d); setDatePickerOpen(false); }} disabled={(date) => date > new Date()} className="p-3 pointer-events-auto" />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Attendees */}
          <div className="space-y-2">
            <Label>Participants</Label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {attendeeEmails.map(email => (
                <Badge key={email} variant="secondary" className="gap-1 pr-1">
                  {email}
                  <button onClick={() => setAttendeeEmails(prev => prev.filter(e => e !== email))} className="hover:text-destructive"><X className="h-3 w-3" /></button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Input placeholder="Add email..." value={attendeeInput} onChange={(e) => setAttendeeInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAddAttendee()} className="flex-1" />
              <Button variant="outline" size="icon" onClick={handleAddAttendee} disabled={!attendeeInput.trim()}><Plus className="h-4 w-4" /></Button>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label>Notes</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={updateMeeting.isPending}>
            {updateMeeting.isPending ? 'Saving…' : 'Save Changes'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function TeamManualMeetingsSection({ teamEmails }: TeamManualMeetingsSectionProps) {
  const navigate = useNavigate();
  const { data: meetings, isLoading } = useTeamManualMeetings(teamEmails);
  const deleteMeeting = useDeleteManualMeeting();
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [editingMeeting, setEditingMeeting] = useState<any>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const getMeetingTypeLabel = (type: string) => 
    MANUAL_MEETING_TYPES.find(t => t.value === type)?.label || type;

  if (isLoading) return null;

  return (
    <>
      <Card className="mt-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" />
                Off-site & Unrecorded Meetings
              </CardTitle>
              <CardDescription>
                Manual meetings logged by team members — linked to opportunities and activity timelines
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={() => setImportDialogOpen(true)}>
                <Upload className="h-4 w-4 mr-1" /> Import CSV
              </Button>
              <Button size="sm" onClick={() => setAddDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-1" /> Log Meeting
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {!meetings || meetings.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <MapPin className="h-10 w-10 mx-auto mb-3 opacity-40" />
              <p>No off-site meetings logged yet</p>
              <p className="text-sm mt-1">Use "Log Meeting" to track client onsites, workshops, and unrecorded calls</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-8" />
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Opportunity</TableHead>
                    <TableHead>Participants</TableHead>
                    <TableHead className="w-20">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {meetings.map((meeting: any) => {
                    const isExpanded = expandedId === meeting.id;
                    return (
                      <>
                        <TableRow 
                          key={meeting.id} 
                          className="cursor-pointer hover:bg-muted/50"
                          onClick={() => setExpandedId(isExpanded ? null : meeting.id)}
                        >
                          <TableCell className="pr-0">
                            {isExpanded ? <ChevronDown className="h-4 w-4 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm">
                            <div className="flex items-center gap-1.5">
                              <CalendarIcon className="h-3.5 w-3.5 text-muted-foreground" />
                              {format(new Date(meeting.meeting_date), 'MMM d, yyyy')}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={meeting.is_highlighted ? "default" : "secondary"} className="text-xs">
                              {getMeetingTypeLabel(meeting.meeting_type)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {meeting.opportunities ? (
                              <button
                                className="text-sm text-primary hover:underline flex items-center gap-1"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  navigate(`/opportunities/${meeting.opportunity_id}`);
                                }}
                              >
                                {meeting.opportunities.name}
                                <ExternalLink className="h-3 w-3" />
                              </button>
                            ) : meeting.accounts?.name ? (
                              <div className="flex items-center gap-1 text-sm">
                                <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
                                <button
                                  className="text-primary hover:underline"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    navigate(`/accounts/${meeting.account_id}`);
                                  }}
                                >
                                  {meeting.accounts.name}
                                </button>
                                <Badge variant="outline" className="text-[10px] ml-1">Account only</Badge>
                              </div>
                            ) : (
                              <span className="text-xs text-muted-foreground">Not linked</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Users className="h-3.5 w-3.5 text-muted-foreground" />
                              <span className="text-sm">{meeting.attendee_emails?.length || 0}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditingMeeting(meeting)}>
                                <Pencil className="h-3.5 w-3.5" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive">
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Delete meeting?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      This will also remove the linked opportunity activity. This cannot be undone.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => deleteMeeting.mutate(meeting.id)}>
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                        {isExpanded && (
                          <TableRow key={`${meeting.id}-detail`}>
                            <TableCell colSpan={6} className="bg-muted/20 p-4">
                              <div className="space-y-3">
                                {/* Participants */}
                                <div>
                                  <p className="text-xs font-medium text-muted-foreground mb-1.5">Participants</p>
                                  <div className="flex flex-wrap gap-1.5">
                                    {(meeting.attendee_emails || []).map((email: string) => (
                                      <Badge key={email} variant="outline" className="text-xs font-normal">{email}</Badge>
                                    ))}
                                  </div>
                                </div>
                                {/* Account */}
                                {meeting.opportunities?.accounts && (
                                  <div>
                                    <p className="text-xs font-medium text-muted-foreground mb-1">Account</p>
                                    <button
                                      className="text-sm text-primary hover:underline flex items-center gap-1"
                                      onClick={() => navigate(`/accounts/${meeting.opportunities.accounts.id}`)}
                                    >
                                      <Building2 className="h-3.5 w-3.5" />
                                      {meeting.opportunities.accounts.name}
                                    </button>
                                  </div>
                                )}
                                {/* Notes */}
                                {meeting.notes && (
                                  <div>
                                    <p className="text-xs font-medium text-muted-foreground mb-1">Notes</p>
                                    <p className="text-sm whitespace-pre-wrap">{meeting.notes}</p>
                                  </div>
                                )}
                                {!meeting.notes && (
                                  <p className="text-xs text-muted-foreground italic">No notes added</p>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        )}
                      </>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <AddManualMeetingDialog open={addDialogOpen} onOpenChange={setAddDialogOpen} />
      <ImportSalesforceActivitiesDialog open={importDialogOpen} onOpenChange={setImportDialogOpen} />
      {editingMeeting && (
        <EditMeetingDialog meeting={editingMeeting} open={!!editingMeeting} onOpenChange={(v) => { if (!v) setEditingMeeting(null); }} />
      )}
    </>
  );
}

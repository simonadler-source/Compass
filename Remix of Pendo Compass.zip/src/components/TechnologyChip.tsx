import { useDrag } from 'react-dnd';
import { cn } from '@/lib/utils';
import { Technology, LayerType, LAYER_CONFIG } from '@/types/architecture';
import { GripVertical, Info } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface TechnologyChipProps {
  technology: Technology;
  onSelect?: (tech: Technology) => void;
  showDetails?: boolean;
  isDraggable?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const layerChipClasses: Record<LayerType, string> = {
  host: 'chip-host',
  build: 'chip-build',
  adopt: 'chip-adopt',
  growth: 'chip-growth',
  ops: 'chip-ops',
};

export function TechnologyChip({ 
  technology, 
  onSelect, 
  showDetails = false,
  isDraggable = true,
  size = 'md'
}: TechnologyChipProps) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'technology',
    item: technology,
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }), [technology]);

  const sizeClasses = {
    sm: 'text-xs px-2 py-1',
    md: 'text-sm px-3 py-1.5',
    lg: 'text-base px-4 py-2',
  };

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div
          ref={isDraggable ? drag : undefined}
          onClick={() => onSelect?.(technology)}
          className={cn(
            "inline-flex items-center gap-2 rounded-full border cursor-pointer",
            "transition-all duration-200 hover:scale-105 active:scale-95",
            "shadow-chip",
            layerChipClasses[technology.layer],
            sizeClasses[size],
            isDragging && "opacity-50 scale-110",
            onSelect && "cursor-pointer"
          )}
        >
          {isDraggable && (
            <GripVertical className="w-3 h-3 opacity-50" />
          )}
          <span className="font-medium">{technology.name}</span>
          {showDetails && technology.version && (
            <span className="text-xs opacity-70">v{technology.version}</span>
          )}
          {technology.issues && (
            <Info className="w-3 h-3 text-priority-high" />
          )}
        </div>
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-xs">
        <div className="space-y-1">
          <p className="font-semibold">{technology.name}</p>
          <p className="text-xs text-muted-foreground">
            {LAYER_CONFIG[technology.layer].label} • {technology.category}
          </p>
          {technology.owner && (
            <p className="text-xs">Owner: {technology.owner}</p>
          )}
          {technology.issues && (
            <p className="text-xs text-priority-high">⚠️ {technology.issues}</p>
          )}
        </div>
      </TooltipContent>
    </Tooltip>
  );
}

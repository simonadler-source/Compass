import { TrendingUp, TrendingDown, Minus, HelpCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface TrendIndicatorProps {
  trend: 'improving' | 'stable' | 'declining' | 'unknown';
  label?: string;
  size?: 'sm' | 'md';
}

export function TrendIndicator({ trend, label, size = 'md' }: TrendIndicatorProps) {
  const iconSize = size === 'sm' ? 14 : 16;
  
  const config = {
    improving: {
      icon: TrendingUp,
      color: 'text-green-500',
      label: 'Improving',
    },
    stable: {
      icon: Minus,
      color: 'text-muted-foreground',
      label: 'Stable',
    },
    declining: {
      icon: TrendingDown,
      color: 'text-red-500',
      label: 'Declining',
    },
    unknown: {
      icon: HelpCircle,
      color: 'text-muted-foreground/50',
      label: 'Not enough data',
    },
  };
  
  const { icon: Icon, color, label: defaultLabel } = config[trend];
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span className={cn("inline-flex items-center gap-1", color)}>
            <Icon size={iconSize} />
            {label && <span className="text-xs">{label}</span>}
          </span>
        </TooltipTrigger>
        <TooltipContent>
          <p>{defaultLabel}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

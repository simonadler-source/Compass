import { useMemo, useState } from 'react';
import { DollarSign, TrendingUp, Users, ChevronDown, ChevronRight, Layers, Target, Info, Edit2, Server, Package, Percent } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { useWhitespaceRevenue, WhitespaceRevenue } from '@/hooks/useModulePricing';
import { cn } from '@/lib/utils';

interface WhitespaceRevenueCalculatorProps {
  accountId: string;
  accountName: string;
  mauCount: number | null;
  baseMauValue: number | null;
  employeeCount: number | null;
  aggregatedFromOpportunities?: boolean;
  onUpdateMauCount?: (mauCount: number) => void;
  onUpdateBaseMauValue?: (value: number) => void;
}

function formatCurrency(amount: number): string {
  if (amount >= 1000000) {
    return `$${(amount / 1000000).toFixed(1)}M`;
  }
  if (amount >= 1000) {
    return `$${(amount / 1000).toFixed(0)}k`;
  }
  return `$${amount.toLocaleString()}`;
}

function formatNumber(num: number): string {
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M`;
  }
  if (num >= 1000) {
    return `${(num / 1000).toFixed(0)}k`;
  }
  return num.toLocaleString();
}

function RevenueAreaRow({ area }: { area: WhitespaceRevenue }) {
  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div className="w-8 h-8 rounded-lg bg-layer-build/10 flex items-center justify-center flex-shrink-0">
          <Package className="w-4 h-4 text-layer-build" />
        </div>
        <div className="min-w-0">
          <p className="font-medium text-sm truncate">{area.moduleName}</p>
          <p className="text-xs text-muted-foreground">{area.functionalArea}</p>
        </div>
      </div>
      <div className="flex items-center gap-4 flex-shrink-0">
        <div className="text-right">
          <Badge variant="outline" className="text-xs">
            {area.coverageGap}% gap
          </Badge>
        </div>
        {area.discount > 0 && (
          <Badge variant="secondary" className="text-xs">
            -{area.discount}%
          </Badge>
        )}
        <div className="text-right min-w-[80px]">
          <p className="font-semibold text-primary">{formatCurrency(area.potentialRevenue)}</p>
        </div>
      </div>
    </div>
  );
}

export function WhitespaceRevenueCalculator({
  accountId,
  accountName,
  mauCount,
  baseMauValue,
  employeeCount,
  aggregatedFromOpportunities,
  onUpdateMauCount,
  onUpdateBaseMauValue,
}: WhitespaceRevenueCalculatorProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [isEditingMau, setIsEditingMau] = useState(false);
  const [editMauValue, setEditMauValue] = useState(mauCount?.toString() || '');

  // Use MAU count if available, otherwise estimate from employee count
  const effectiveMauCount = useMemo(() => {
    if (mauCount && mauCount > 0) return mauCount;
    // Rough estimate: 20% of employees are active users
    if (employeeCount && employeeCount > 0) return Math.round(employeeCount * 0.2);
    return null;
  }, [mauCount, employeeCount]);

  const { calculation, isLoading } = useWhitespaceRevenue(accountId, effectiveMauCount, baseMauValue);

  const handleSaveMau = () => {
    const value = parseInt(editMauValue, 10);
    if (!isNaN(value) && value > 0 && onUpdateMauCount) {
      onUpdateMauCount(value);
    }
    setIsEditingMau(false);
  };

  if (!effectiveMauCount) {
    return (
      <Card className="glass border-layer-build/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-layer-build" />
            Revenue Calculator
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <Users className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground mb-4">
              Enter MAU or employee count to calculate revenue
            </p>
            <div className="flex items-center gap-2 max-w-xs mx-auto">
              <Input
                type="number"
                placeholder="Enter MAU count"
                value={editMauValue}
                onChange={(e) => setEditMauValue(e.target.value)}
                className="text-center"
              />
              <Button size="sm" onClick={handleSaveMau} disabled={!editMauValue}>
                Calculate
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="glass border-layer-build/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-layer-build" />
            Revenue Calculator
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-24 flex items-center justify-center">
            <p className="text-sm text-muted-foreground">Calculating...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const totalRevenue = calculation 
    ? calculation.platformCost + calculation.mauCost + calculation.totalModuleCost 
    : 0;

  return (
    <Card className="glass border-layer-build/20">
      <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
        <CardHeader className="pb-3">
          <CollapsibleTrigger asChild>
            <div className="flex items-center justify-between cursor-pointer">
              <CardTitle className="text-base flex items-center gap-2">
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
                <TrendingUp className="w-5 h-5 text-layer-build" />
                Revenue Calculator
              </CardTitle>
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="text-sm font-semibold">
                  {formatCurrency(totalRevenue)} total
                </Badge>
              </div>
            </div>
          </CollapsibleTrigger>
        </CardHeader>

        <CollapsibleContent>
          <CardContent className="pt-0">
            {/* Summary Grid */}
            <div className="grid grid-cols-4 gap-3 mb-4 p-3 rounded-lg bg-muted/30">
              {/* MAU */}
              <div className="text-center">
                <div className="flex items-center justify-center gap-1">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  {isEditingMau ? (
                    <div className="flex items-center gap-1">
                      <Input
                        type="number"
                        value={editMauValue}
                        onChange={(e) => setEditMauValue(e.target.value)}
                        className="w-20 h-6 text-xs text-center"
                        onKeyDown={(e) => e.key === 'Enter' && handleSaveMau()}
                      />
                      <Button size="sm" variant="ghost" className="h-6 px-1" onClick={handleSaveMau}>
                        Save
                      </Button>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        setEditMauValue(effectiveMauCount.toString());
                        setIsEditingMau(true);
                      }}
                      className="flex items-center gap-1 hover:text-primary transition-colors"
                    >
                      <span className="text-lg font-bold text-foreground">{formatNumber(effectiveMauCount)}</span>
                      <Edit2 className="w-3 h-3 text-muted-foreground" />
                    </button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {aggregatedFromOpportunities ? 'MAU (from opps)' : mauCount ? 'MAU' : 'Est. MAU'}
                </p>
              </div>

              {/* Platform Cost */}
              <div className="text-center">
                <div className="flex items-center justify-center gap-1">
                  <Server className="w-4 h-4 text-muted-foreground" />
                  <span className="text-lg font-bold text-foreground">
                    {calculation ? formatCurrency(calculation.platformCost) : '$0'}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">Platform</p>
              </div>

              {/* MAU Cost */}
              <div className="text-center">
                <div className="flex items-center justify-center gap-1">
                  <DollarSign className="w-4 h-4 text-muted-foreground" />
                  <span className="text-lg font-bold text-foreground">
                    {calculation ? formatCurrency(calculation.mauCost) : '$0'}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">MAU Cost</p>
              </div>

              {/* Total */}
              <div className="text-center">
                <p className="text-lg font-bold text-primary">{formatCurrency(totalRevenue)}</p>
                <p className="text-xs text-muted-foreground">Total</p>
              </div>
            </div>

            {/* Module Breakdown */}
            {calculation && calculation.byArea.length > 0 && (
              <div className="space-y-2">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                  <Package className="w-3 h-3" />
                  Module Whitespace ({formatCurrency(calculation.totalModuleCost)})
                </Label>
                <div className="space-y-1.5">
                  {calculation.byArea.map((area, index) => (
                    <RevenueAreaRow key={area.functionalAreaId || index} area={area} />
                  ))}
                </div>
              </div>
            )}

            {/* Footer */}
            <div className="mt-4 pt-3 border-t border-border/50">
              <p className="text-xs text-muted-foreground text-center">
                <span className="text-primary">Combat Math™</span> • Pricing configured in Settings
              </p>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
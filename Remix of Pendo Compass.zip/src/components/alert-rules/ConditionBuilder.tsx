import { Plus, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  RuleConditions,
  ConditionGroup,
  LogicalOperator,
  createEmptyGroup,
} from './types';
import { ConditionGroupCard } from './ConditionGroupCard';

interface ConditionBuilderProps {
  conditions: RuleConditions;
  availableSignals?: { id: string; name: string; signal_field_name: string }[];
  onChange: (updated: RuleConditions) => void;
}

export function ConditionBuilder({
  conditions,
  availableSignals,
  onChange,
}: ConditionBuilderProps) {
  const handleGroupChange = (index: number, updated: ConditionGroup) => {
    const newGroups = [...conditions.groups];
    newGroups[index] = updated;
    onChange({ ...conditions, groups: newGroups });
  };

  const handleGroupRemove = (index: number) => {
    const newGroups = conditions.groups.filter((_, i) => i !== index);
    onChange({ ...conditions, groups: newGroups });
  };

  const handleAddGroup = () => {
    onChange({
      ...conditions,
      groups: [...conditions.groups, createEmptyGroup()],
    });
  };

  const toggleGroupOperator = () => {
    const newOperator: LogicalOperator =
      conditions.groupOperator === 'AND' ? 'OR' : 'AND';
    onChange({ ...conditions, groupOperator: newOperator });
  };

  // Generate a summary of the condition logic
  const getLogicSummary = (): string => {
    if (conditions.groups.length === 0) return 'No conditions configured';

    const groupSummaries = conditions.groups.map((group, i) => {
      const conditionCount = group.conditions.length;
      if (conditionCount === 1) {
        return `Condition ${i + 1}`;
      }
      const innerLogic = group.conditions
        .map((_, j) => `${i + 1}.${j + 1}`)
        .join(` ${group.operator} `);
      return `(${innerLogic})`;
    });

    return groupSummaries.join(` ${conditions.groupOperator} `);
  };

  return (
    <div className="space-y-4">
      {/* Header with logic summary */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">Trigger Conditions</span>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="h-4 w-4 text-muted-foreground cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>
                  Configure multiple conditions with AND/OR logic. Click on
                  the operator badges to toggle between AND and OR. Add
                  multiple groups for complex logic like (A AND B) OR (C AND D).
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <div className="text-xs text-muted-foreground font-mono bg-muted px-2 py-1 rounded">
          {getLogicSummary()}
        </div>
      </div>

      {/* Condition groups */}
      <div className="space-y-4">
        {conditions.groups.map((group, groupIndex) => (
          <div key={group.id}>
            {groupIndex > 0 && (
              <div className="flex items-center justify-center py-2">
                <Badge
                  variant="secondary"
                  className="cursor-pointer hover:bg-primary/10 px-4"
                  onClick={toggleGroupOperator}
                >
                  {conditions.groupOperator}
                </Badge>
              </div>
            )}
            <ConditionGroupCard
              group={group}
              groupIndex={groupIndex}
              availableSignals={availableSignals}
              onChange={(updated) => handleGroupChange(groupIndex, updated)}
              onRemove={() => handleGroupRemove(groupIndex)}
              canRemove={conditions.groups.length > 1}
            />
          </div>
        ))}
      </div>

      {/* Add group button */}
      <Button
        variant="outline"
        size="sm"
        onClick={handleAddGroup}
        className="w-full border-dashed"
      >
        <Plus className="h-4 w-4 mr-2" />
        Add Condition Group
      </Button>

      {/* Visual logic explanation */}
      {conditions.groups.length > 1 && (
        <div className="p-3 bg-muted/50 rounded-lg text-sm">
          <span className="font-medium">Rule triggers when: </span>
          <span className="text-muted-foreground">
            {conditions.groups.map((group, i) => (
              <span key={group.id}>
                {i > 0 && (
                  <span className="mx-1 text-primary font-medium">
                    {conditions.groupOperator}
                  </span>
                )}
                <span className="font-mono">
                  (Group {i + 1}: {group.conditions.length} condition
                  {group.conditions.length > 1 ? 's' : ''} with{' '}
                  <span className="text-primary">{group.operator}</span>)
                </span>
              </span>
            ))}
          </span>
        </div>
      )}
    </div>
  );
}

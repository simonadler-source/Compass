import { Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  ConditionGroup,
  Condition,
  LogicalOperator,
  createEmptyCondition,
} from './types';
import { ConditionRow } from './ConditionRow';

interface ConditionGroupCardProps {
  group: ConditionGroup;
  groupIndex: number;
  availableSignals?: { id: string; name: string; signal_field_name: string }[];
  onChange: (updated: ConditionGroup) => void;
  onRemove: () => void;
  canRemove: boolean;
}

export function ConditionGroupCard({
  group,
  groupIndex,
  availableSignals,
  onChange,
  onRemove,
  canRemove,
}: ConditionGroupCardProps) {
  const handleConditionChange = (index: number, updated: Condition) => {
    const newConditions = [...group.conditions];
    newConditions[index] = updated;
    onChange({ ...group, conditions: newConditions });
  };

  const handleConditionRemove = (index: number) => {
    const newConditions = group.conditions.filter((_, i) => i !== index);
    onChange({ ...group, conditions: newConditions });
  };

  const handleAddCondition = () => {
    onChange({
      ...group,
      conditions: [...group.conditions, createEmptyCondition()],
    });
  };

  const toggleOperator = () => {
    const newOperator: LogicalOperator = group.operator === 'AND' ? 'OR' : 'AND';
    onChange({ ...group, operator: newOperator });
  };

  return (
    <div className="relative border rounded-lg bg-card">
      {/* Group header */}
      <div className="flex items-center justify-between px-4 py-2 border-b bg-muted/30">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-muted-foreground">
            Group {groupIndex + 1}
          </span>
          {group.conditions.length > 1 && (
            <Badge
              variant="outline"
              className="cursor-pointer hover:bg-primary/10"
              onClick={toggleOperator}
            >
              {group.operator}
            </Badge>
          )}
        </div>
        {canRemove && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onRemove}
            className="h-7 text-muted-foreground hover:text-destructive"
          >
            <Trash2 className="h-4 w-4 mr-1" />
            Remove Group
          </Button>
        )}
      </div>

      {/* Conditions */}
      <div className="p-4 space-y-3">
        {group.conditions.map((condition, conditionIndex) => (
          <div key={condition.id} className="flex items-center gap-2">
            {conditionIndex > 0 && (
              <Badge
                variant="secondary"
                className="mr-2 cursor-pointer hover:bg-primary/10 min-w-[50px] justify-center"
                onClick={toggleOperator}
              >
                {group.operator}
              </Badge>
            )}
            {conditionIndex === 0 && group.conditions.length > 1 && (
              <div className="w-[62px]" /> // Spacer to align first condition
            )}
            <ConditionRow
              condition={condition}
              availableSignals={availableSignals}
              onChange={(updated) => handleConditionChange(conditionIndex, updated)}
              onRemove={() => handleConditionRemove(conditionIndex)}
              canRemove={group.conditions.length > 1}
            />
          </div>
        ))}

        {/* Add condition button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={handleAddCondition}
          className="mt-2 text-muted-foreground"
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Condition
        </Button>
      </div>
    </div>
  );
}

import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Condition,
  ConditionOperator,
  CONDITION_FIELD_META,
  CONDITION_OPERATORS,
  getFieldMeta,
  DateRangeConfig,
} from './types';
import { DateRangeCondition } from './DateRangeCondition';

interface ConditionRowProps {
  condition: Condition;
  availableSignals?: { id: string; name: string; signal_field_name: string }[];
  onChange: (updated: Condition) => void;
  onRemove: () => void;
  canRemove: boolean;
}

export function ConditionRow({
  condition,
  availableSignals = [],
  onChange,
  onRemove,
  canRemove,
}: ConditionRowProps) {
  const fieldMeta = getFieldMeta(condition.field);
  const operators = fieldMeta?.operators || ['equals'];

  const handleFieldChange = (newField: string) => {
    const newMeta = getFieldMeta(newField as any);
    const defaultOperator = newMeta?.operators[0] || 'equals';
    let defaultValue: string | number | boolean = '';
    
    if (newMeta?.valueType === 'number') {
      defaultValue = parseInt(newMeta.placeholder || '0') || 0;
    } else if (newMeta?.valueType === 'boolean') {
      defaultValue = true;
    }

    onChange({
      ...condition,
      field: newField as any,
      operator: defaultOperator,
      value: defaultValue,
      fieldContext: undefined,
    });
  };

  const handleOperatorChange = (newOperator: string) => {
    onChange({
      ...condition,
      operator: newOperator as ConditionOperator,
    });
  };

  const handleValueChange = (newValue: string | number | boolean) => {
    onChange({
      ...condition,
      value: newValue,
    });
  };

  const handleContextChange = (context: string) => {
    onChange({
      ...condition,
      fieldContext: context,
    });
  };

  const handleDateRangeChange = (dateRangeConfig: DateRangeConfig) => {
    onChange({
      ...condition,
      dateRangeConfig,
    });
  };

  const renderValueInput = () => {
    if (!fieldMeta) return null;

    const { valueType, selectOptions, placeholder, suffix } = fieldMeta;

    // For operators that don't need a value
    if (condition.operator === 'is_empty' || condition.operator === 'is_not_empty') {
      // For date_range type (any_signal_detected_since), show date range picker
      if (valueType === 'date_range') {
        return (
          <DateRangeCondition
            value={condition.dateRangeConfig || { type: 'rolling_days', rollingDays: 7 }}
            onChange={handleDateRangeChange}
          />
        );
      }
      // For signal/stakeholder fields, show context selector
      if (valueType === 'signal') {
        return (
          <Select
            value={condition.fieldContext || ''}
            onValueChange={handleContextChange}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select signal..." />
            </SelectTrigger>
            <SelectContent>
              {availableSignals.map((signal) => (
                <SelectItem key={signal.id} value={signal.signal_field_name}>
                  {signal.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      }
      if (valueType === 'stakeholder_role' && selectOptions) {
        return (
          <Select
            value={condition.fieldContext || ''}
            onValueChange={handleContextChange}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select role..." />
            </SelectTrigger>
            <SelectContent>
              {selectOptions.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      }
      return null;
    }

    switch (valueType) {
      case 'number':
        return (
          <div className="flex items-center gap-1">
            <Input
              type="number"
              value={condition.value as number}
              onChange={(e) => handleValueChange(parseInt(e.target.value) || 0)}
              placeholder={placeholder}
              className="w-[100px]"
            />
            {suffix && <span className="text-sm text-muted-foreground">{suffix}</span>}
          </div>
        );

      case 'stage':
      case 'select':
        return (
          <Select
            value={String(condition.value)}
            onValueChange={handleValueChange}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select value..." />
            </SelectTrigger>
            <SelectContent>
              {selectOptions?.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case 'signal':
        return (
          <Select
            value={condition.fieldContext || ''}
            onValueChange={handleContextChange}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select signal..." />
            </SelectTrigger>
            <SelectContent>
              {availableSignals.map((signal) => (
                <SelectItem key={signal.id} value={signal.signal_field_name}>
                  {signal.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case 'stakeholder_role':
        return (
          <Select
            value={condition.fieldContext || ''}
            onValueChange={handleContextChange}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select role..." />
            </SelectTrigger>
            <SelectContent>
              {selectOptions?.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case 'boolean':
        return (
          <Select
            value={String(condition.value)}
            onValueChange={(v) => handleValueChange(v === 'true')}
          >
            <SelectTrigger className="w-[100px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="true">Yes</SelectItem>
              <SelectItem value="false">No</SelectItem>
            </SelectContent>
          </Select>
        );

      default:
        return (
          <Input
            value={String(condition.value)}
            onChange={(e) => handleValueChange(e.target.value)}
            placeholder={placeholder}
            className="w-[150px]"
          />
        );
    }
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {/* Field selector */}
      <Select value={condition.field} onValueChange={handleFieldChange}>
        <SelectTrigger className="w-[200px]">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {CONDITION_FIELD_META.map((meta) => (
            <SelectItem key={meta.field} value={meta.field}>
              {meta.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Operator selector */}
      <Select value={condition.operator} onValueChange={handleOperatorChange}>
        <SelectTrigger className="w-[120px]">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {operators.map((op) => (
            <SelectItem key={op} value={op}>
              {CONDITION_OPERATORS[op]}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Value input */}
      {renderValueInput()}

      {/* Remove button */}
      {canRemove && (
        <Button
          variant="ghost"
          size="icon"
          onClick={onRemove}
          className="h-8 w-8 text-muted-foreground hover:text-destructive"
        >
          <X className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
}

import { useState } from 'react';
import { Calendar, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export type DateRangeType = 'rolling_days' | 'date_range' | 'since_last_digest';

export interface DateRangeConfig {
  type: DateRangeType;
  rollingDays?: number;
  startDate?: string; // ISO date string
  endDate?: string; // ISO date string
}

interface DateRangeConditionProps {
  value: DateRangeConfig;
  onChange: (config: DateRangeConfig) => void;
}

const DATE_RANGE_OPTIONS = [
  { value: 'rolling_days', label: 'Last N Days (Rolling)', icon: Clock },
  { value: 'date_range', label: 'Specific Date Range', icon: Calendar },
  { value: 'since_last_digest', label: 'Since Last Digest', icon: Clock },
] as const;

export function DateRangeCondition({ value, onChange }: DateRangeConditionProps) {
  const [startOpen, setStartOpen] = useState(false);
  const [endOpen, setEndOpen] = useState(false);

  const handleTypeChange = (type: DateRangeType) => {
    const newConfig: DateRangeConfig = { type };
    if (type === 'rolling_days') {
      newConfig.rollingDays = value.rollingDays || 7;
    } else if (type === 'date_range') {
      newConfig.startDate = value.startDate;
      newConfig.endDate = value.endDate;
    }
    onChange(newConfig);
  };

  const handleRollingDaysChange = (days: number) => {
    onChange({ ...value, rollingDays: days });
  };

  const handleStartDateChange = (date: Date | undefined) => {
    onChange({ ...value, startDate: date?.toISOString() });
    setStartOpen(false);
  };

  const handleEndDateChange = (date: Date | undefined) => {
    onChange({ ...value, endDate: date?.toISOString() });
    setEndOpen(false);
  };

  return (
    <div className="space-y-3">
      <div className="space-y-2">
        <Label className="text-xs text-muted-foreground">Detection Window</Label>
        <Select value={value.type} onValueChange={(v) => handleTypeChange(v as DateRangeType)}>
          <SelectTrigger className="w-[220px]">
            <SelectValue placeholder="Select window type..." />
          </SelectTrigger>
          <SelectContent>
            {DATE_RANGE_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                <div className="flex items-center gap-2">
                  <opt.icon className="h-3.5 w-3.5" />
                  {opt.label}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {value.type === 'rolling_days' && (
        <div className="flex items-center gap-2">
          <Label className="text-xs text-muted-foreground whitespace-nowrap">Last</Label>
          <Input
            type="number"
            min={1}
            max={365}
            value={value.rollingDays || 7}
            onChange={(e) => handleRollingDaysChange(parseInt(e.target.value) || 7)}
            className="w-[80px]"
          />
          <span className="text-sm text-muted-foreground">days</span>
        </div>
      )}

      {value.type === 'date_range' && (
        <div className="flex items-center gap-2 flex-wrap">
          <Popover open={startOpen} onOpenChange={setStartOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className={cn(
                  'w-[140px] justify-start text-left font-normal',
                  !value.startDate && 'text-muted-foreground'
                )}
              >
                <Calendar className="mr-2 h-4 w-4" />
                {value.startDate
                  ? format(new Date(value.startDate), 'MMM d, yyyy')
                  : 'Start date'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <CalendarComponent
                mode="single"
                selected={value.startDate ? new Date(value.startDate) : undefined}
                onSelect={handleStartDateChange}
                initialFocus
                className="p-3 pointer-events-auto"
              />
            </PopoverContent>
          </Popover>

          <span className="text-sm text-muted-foreground">to</span>

          <Popover open={endOpen} onOpenChange={setEndOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className={cn(
                  'w-[140px] justify-start text-left font-normal',
                  !value.endDate && 'text-muted-foreground'
                )}
              >
                <Calendar className="mr-2 h-4 w-4" />
                {value.endDate
                  ? format(new Date(value.endDate), 'MMM d, yyyy')
                  : 'End date'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <CalendarComponent
                mode="single"
                selected={value.endDate ? new Date(value.endDate) : undefined}
                onSelect={handleEndDateChange}
                disabled={(date) =>
                  value.startDate ? date < new Date(value.startDate) : false
                }
                initialFocus
                className="p-3 pointer-events-auto"
              />
            </PopoverContent>
          </Popover>
        </div>
      )}

      {value.type === 'since_last_digest' && (
        <p className="text-xs text-muted-foreground">
          Triggers on any signals detected since the last email digest was sent
        </p>
      )}
    </div>
  );
}

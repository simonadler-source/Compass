import { useState, useMemo, useCallback } from 'react';
import { Check, ChevronDown, Users, X, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { useAllActiveUsers, type ActiveUser } from '@/hooks/useAllActiveUsers';

export interface TeamScopeConfig {
  includeMyTeam: boolean;
  additionalUserIds: string[]; // User IDs whose teams should also be included
}

interface TeamScopePickerProps {
  value: TeamScopeConfig;
  onChange: (config: TeamScopeConfig) => void;
}

export function TeamScopePicker({ value, onChange }: TeamScopePickerProps) {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { users, isLoading } = useAllActiveUsers();

  const selectedUsers = useMemo(() => {
    return users.filter((u) => value.additionalUserIds.includes(u.id));
  }, [users, value.additionalUserIds]);

  const filteredUsers = useMemo(() => {
    if (!searchQuery.trim()) return users;
    const query = searchQuery.toLowerCase();
    return users.filter(
      (u) =>
        u.full_name?.toLowerCase().includes(query) ||
        u.email.toLowerCase().includes(query)
    );
  }, [users, searchQuery]);

  const handleToggleUser = useCallback(
    (userId: string) => {
      const newIds = value.additionalUserIds.includes(userId)
        ? value.additionalUserIds.filter((id) => id !== userId)
        : [...value.additionalUserIds, userId];
      onChange({ ...value, additionalUserIds: newIds });
    },
    [value, onChange]
  );

  const handleRemoveUser = useCallback(
    (userId: string) => {
      onChange({
        ...value,
        additionalUserIds: value.additionalUserIds.filter((id) => id !== userId),
      });
    },
    [value, onChange]
  );

  const handleToggleMyTeam = useCallback(
    (checked: boolean) => {
      onChange({ ...value, includeMyTeam: checked });
    },
    [value, onChange]
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="space-y-0.5">
          <Label className="text-sm font-medium">Include My Team</Label>
          <p className="text-xs text-muted-foreground">
            Alert on opportunities where you or your direct reports are assigned
          </p>
        </div>
        <Switch
          checked={value.includeMyTeam}
          onCheckedChange={handleToggleMyTeam}
        />
      </div>

      <div className="space-y-2">
        <Label className="text-sm font-medium">Additional Leaders' Teams</Label>
        <p className="text-xs text-muted-foreground mb-2">
          Also monitor opportunities where these users or their teams are assigned
        </p>

        {/* Selected users badges */}
        {selectedUsers.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-2">
            {selectedUsers.map((user) => (
              <Badge
                key={user.id}
                variant="secondary"
                className="pl-2 pr-1 py-0.5 flex items-center gap-1"
              >
                <span className="text-xs">
                  {user.full_name || user.email}
                </span>
                <button
                  type="button"
                  onClick={() => handleRemoveUser(user.id)}
                  className="ml-1 rounded-full p-0.5 hover:bg-muted-foreground/20"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}

        {/* Multi-select popover */}
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              role="combobox"
              aria-expanded={open}
              className="w-full justify-between"
            >
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">
                  {selectedUsers.length === 0
                    ? 'Select users...'
                    : `${selectedUsers.length} user${selectedUsers.length !== 1 ? 's' : ''} selected`}
                </span>
              </div>
              <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[320px] p-0" align="start">
            <Command shouldFilter={false}>
              <div className="flex items-center border-b px-3">
                <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
                <Input
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="border-0 focus-visible:ring-0 px-0"
                />
              </div>
              <CommandList>
                <CommandEmpty>
                  {isLoading ? 'Loading users...' : 'No users found.'}
                </CommandEmpty>
                <CommandGroup>
                  <ScrollArea className="h-[200px]">
                    {filteredUsers.map((user) => {
                      const isSelected = value.additionalUserIds.includes(user.id);
                      return (
                        <CommandItem
                          key={user.id}
                          value={user.id}
                          onSelect={() => handleToggleUser(user.id)}
                          className="cursor-pointer"
                        >
                          <div
                            className={cn(
                              'mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary',
                              isSelected
                                ? 'bg-primary text-primary-foreground'
                                : 'opacity-50 [&_svg]:invisible'
                            )}
                          >
                            <Check className="h-3 w-3" />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-sm">
                              {user.full_name || user.email}
                            </span>
                            {user.full_name && (
                              <span className="text-xs text-muted-foreground">
                                {user.email}
                              </span>
                            )}
                          </div>
                        </CommandItem>
                      );
                    })}
                  </ScrollArea>
                </CommandGroup>
              </CommandList>
            </Command>
          </PopoverContent>
        </Popover>
      </div>

      {/* Summary */}
      {(value.includeMyTeam || selectedUsers.length > 0) && (
        <div className="p-3 bg-muted/50 rounded-lg text-sm">
          <span className="font-medium">Monitoring scope: </span>
          <span className="text-muted-foreground">
            {value.includeMyTeam && selectedUsers.length === 0 && 'Your team only'}
            {value.includeMyTeam && selectedUsers.length > 0 && (
              <>Your team + {selectedUsers.length} additional leader{selectedUsers.length !== 1 ? 's' : ''}</>
            )}
            {!value.includeMyTeam && selectedUsers.length > 0 && (
              <>{selectedUsers.length} selected leader{selectedUsers.length !== 1 ? 's' : ''} only</>
            )}
            {!value.includeMyTeam && selectedUsers.length === 0 && (
              <span className="text-amber-500">No scope selected - rule won't match any opportunities</span>
            )}
          </span>
        </div>
      )}
    </div>
  );
}

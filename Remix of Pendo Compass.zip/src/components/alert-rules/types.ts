// Alert Rule Condition Types
import type { DateRangeConfig } from './DateRangeCondition';
import type { TeamScopeConfig } from './TeamScopePicker';

// Re-export for convenience
export type { DateRangeConfig, TeamScopeConfig };

export type ConditionField = 
  | 'readiness_score'
  | 'pre_sales_stage'
  | 'sales_stage'
  | 'days_in_stage'
  | 'days_since_meeting'
  | 'days_since_readiness_update'
  | 'stakeholder_count'
  | 'missing_stakeholder_role'
  | 'unanswered_question_count'
  | 'signal_detected'
  | 'signal_missing'
  | 'any_signal_detected_since'
  | 'metric_count'
  | 'pain_point_count'
  | 'use_case_count'
  | 'milestone_overdue'
  | 'deal_value'
  | 'competitive_threat_score'
  | 'competitor_count'
  | 'new_competitive_insight';

export type ConditionOperator = 
  | 'equals'
  | 'not_equals'
  | 'less_than'
  | 'less_than_or_equal'
  | 'greater_than'
  | 'greater_than_or_equal'
  | 'contains'
  | 'not_contains'
  | 'is_empty'
  | 'is_not_empty';

export type LogicalOperator = 'AND' | 'OR';

export interface Condition {
  id: string;
  field: ConditionField;
  operator: ConditionOperator;
  value: string | number | boolean | string[];
  // For fields that need extra context (e.g., which signal, which stakeholder role)
  fieldContext?: string;
  // For date-based conditions like any_signal_detected_since
  dateRangeConfig?: DateRangeConfig;
}

export interface ConditionGroup {
  id: string;
  operator: LogicalOperator; // How conditions within this group are combined
  conditions: Condition[];
}

// Root structure: groups are combined with their own operator
export interface RuleConditions {
  groupOperator: LogicalOperator; // How groups are combined (e.g., group1 AND group2, or group1 OR group2)
  groups: ConditionGroup[];
  // Team scope configuration for the rule
  teamScope?: TeamScopeConfig;
}

// Field metadata for UI
export interface ConditionFieldMeta {
  field: ConditionField;
  label: string;
  description: string;
  valueType: 'number' | 'string' | 'select' | 'stage' | 'signal' | 'stakeholder_role' | 'boolean' | 'date_range';
  operators: ConditionOperator[];
  selectOptions?: { value: string; label: string }[];
  placeholder?: string;
  suffix?: string;
}

export const CONDITION_OPERATORS: Record<ConditionOperator, string> = {
  equals: '=',
  not_equals: '≠',
  less_than: '<',
  less_than_or_equal: '≤',
  greater_than: '>',
  greater_than_or_equal: '≥',
  contains: 'contains',
  not_contains: 'does not contain',
  is_empty: 'is empty',
  is_not_empty: 'is not empty',
};

// Pre-sales stages in order of precedence (1 = earliest, 7 = latest/terminal)
export const PRE_SALES_STAGES = [
  { value: 'discovery', label: 'Discovery', order: 1 },
  { value: 'demo', label: 'Demo', order: 2 },
  { value: 'proof_scoping', label: 'Proof - Scoping', order: 3 },
  { value: 'proof', label: 'Proof', order: 4 },
  { value: 'technical_win', label: 'Technical Win', order: 5 },
  { value: 'technical_loss', label: 'Technical Loss', order: 6 },
  { value: 'unqualified', label: 'Unqualified', order: 7 },
];

export const SALES_STAGES = [
  { value: 'stage_0', label: 'Stage 0 - Qualification' },
  { value: 'stage_1', label: 'Stage 1 - Discovery' },
  { value: 'stage_2', label: 'Stage 2 - Solution' },
  { value: 'stage_3', label: 'Stage 3 - Proof' },
  { value: 'stage_4', label: 'Stage 4 - Negotiate' },
  { value: 'stage_5', label: 'Stage 5 - Sales Won' },
  { value: 'stage_6', label: 'Stage 6 - Closed Won' },
  { value: 'stage_7', label: 'Stage 7 - Closed Lost' },
];

export const STAKEHOLDER_ROLES = [
  { value: 'champion', label: 'Champion' },
  { value: 'economic_buyer', label: 'Economic Buyer' },
  { value: 'decision_maker', label: 'Decision Maker' },
  { value: 'technical_buyer', label: 'Technical Buyer' },
  { value: 'end_user', label: 'End User' },
  { value: 'influencer', label: 'Influencer' },
  { value: 'blocker', label: 'Blocker' },
];

export const CONDITION_FIELD_META: ConditionFieldMeta[] = [
  {
    field: 'readiness_score',
    label: 'Technical Readiness Score',
    description: 'The calculated readiness percentage',
    valueType: 'number',
    operators: ['less_than', 'less_than_or_equal', 'greater_than', 'greater_than_or_equal', 'equals'],
    placeholder: '70',
    suffix: '%',
  },
  {
    field: 'pre_sales_stage',
    label: 'Pre-Sales Stage',
    description: 'Current pre-sales stage of the opportunity',
    valueType: 'stage',
    operators: ['equals', 'not_equals', 'greater_than_or_equal', 'less_than_or_equal'],
    selectOptions: PRE_SALES_STAGES,
  },
  {
    field: 'sales_stage',
    label: 'Sales Stage',
    description: 'Current sales stage of the opportunity',
    valueType: 'stage',
    operators: ['equals', 'not_equals', 'greater_than_or_equal', 'less_than_or_equal'],
    selectOptions: SALES_STAGES,
  },
  {
    field: 'days_in_stage',
    label: 'Days in Current Stage',
    description: 'Number of days since the last stage change',
    valueType: 'number',
    operators: ['greater_than', 'greater_than_or_equal', 'less_than', 'equals'],
    placeholder: '30',
    suffix: 'days',
  },
  {
    field: 'days_since_meeting',
    label: 'Days Since Last Meeting',
    description: 'Number of days since the last customer meeting',
    valueType: 'number',
    operators: ['greater_than', 'greater_than_or_equal', 'less_than', 'equals'],
    placeholder: '14',
    suffix: 'days',
  },
  {
    field: 'days_since_readiness_update',
    label: 'Days Since Readiness Update',
    description: 'Number of days since technical readiness was last updated',
    valueType: 'number',
    operators: ['greater_than', 'greater_than_or_equal', 'less_than', 'equals'],
    placeholder: '14',
    suffix: 'days',
  },
  {
    field: 'stakeholder_count',
    label: 'Total Stakeholder Count',
    description: 'Number of identified stakeholders',
    valueType: 'number',
    operators: ['less_than', 'greater_than', 'equals', 'greater_than_or_equal'],
    placeholder: '3',
  },
  {
    field: 'missing_stakeholder_role',
    label: 'Missing Stakeholder Role',
    description: 'A specific stakeholder role that has not been identified',
    valueType: 'stakeholder_role',
    operators: ['is_empty', 'is_not_empty'],
    selectOptions: STAKEHOLDER_ROLES,
  },
  {
    field: 'unanswered_question_count',
    label: 'Unanswered Question Count',
    description: 'Number of readiness questions without answers',
    valueType: 'number',
    operators: ['greater_than', 'greater_than_or_equal', 'less_than', 'equals'],
    placeholder: '5',
  },
  {
    field: 'signal_detected',
    label: 'Signal Detected',
    description: 'A specific activity signal has been detected',
    valueType: 'signal',
    operators: ['is_not_empty'],
  },
  {
    field: 'signal_missing',
    label: 'Signal Missing',
    description: 'A specific activity signal has NOT been detected',
    valueType: 'signal',
    operators: ['is_empty'],
  },
  {
    field: 'any_signal_detected_since',
    label: 'Any Signal Detected (Date Window)',
    description: 'Any detection rule match within a specified time window',
    valueType: 'date_range',
    operators: ['is_not_empty'],
  },
  {
    field: 'metric_count',
    label: 'Business Metrics Count',
    description: 'Number of business metrics captured',
    valueType: 'number',
    operators: ['less_than', 'equals', 'greater_than_or_equal'],
    placeholder: '1',
  },
  {
    field: 'pain_point_count',
    label: 'Pain Points Count',
    description: 'Number of pain points identified',
    valueType: 'number',
    operators: ['less_than', 'equals', 'greater_than_or_equal'],
    placeholder: '1',
  },
  {
    field: 'use_case_count',
    label: 'Use Cases Count',
    description: 'Number of use cases identified',
    valueType: 'number',
    operators: ['less_than', 'equals', 'greater_than_or_equal'],
    placeholder: '1',
  },
  {
    field: 'milestone_overdue',
    label: 'Milestone Overdue',
    description: 'Any milestone is past its target date',
    valueType: 'boolean',
    operators: ['equals'],
  },
  {
    field: 'deal_value',
    label: 'Deal Value (ARR)',
    description: 'The deal value / ARR amount on the opportunity',
    valueType: 'number',
    operators: ['greater_than', 'greater_than_or_equal', 'less_than', 'less_than_or_equal', 'equals'],
    placeholder: '50000',
    suffix: '$',
  },
  {
    field: 'competitive_threat_score',
    label: 'Competitive Threat Score',
    description: 'The calculated competitive threat score (0-100)',
    valueType: 'number',
    operators: ['greater_than', 'greater_than_or_equal', 'less_than', 'less_than_or_equal', 'equals'],
    placeholder: '60',
    suffix: '/100',
  },
  {
    field: 'competitor_count',
    label: 'Competitor Count',
    description: 'Number of competitors identified on the opportunity',
    valueType: 'number',
    operators: ['greater_than', 'greater_than_or_equal', 'less_than', 'equals'],
    placeholder: '2',
  },
  {
    field: 'new_competitive_insight',
    label: 'New Competitive Insight',
    description: 'A new competitive insight was detected within a time window',
    valueType: 'date_range',
    operators: ['is_not_empty'],
  },
];

// Helper to get field metadata
export function getFieldMeta(field: ConditionField): ConditionFieldMeta | undefined {
  return CONDITION_FIELD_META.find((m) => m.field === field);
}

// Generate unique ID for conditions and groups
export function generateId(): string {
  return Math.random().toString(36).substr(2, 9);
}

// Create empty condition
export function createEmptyCondition(): Condition {
  return {
    id: generateId(),
    field: 'readiness_score',
    operator: 'less_than',
    value: 70,
  };
}

// Create empty condition group
export function createEmptyGroup(): ConditionGroup {
  return {
    id: generateId(),
    operator: 'AND',
    conditions: [createEmptyCondition()],
  };
}

// Create default rule conditions
export function createDefaultRuleConditions(): RuleConditions {
  return {
    groupOperator: 'AND',
    groups: [createEmptyGroup()],
  };
}

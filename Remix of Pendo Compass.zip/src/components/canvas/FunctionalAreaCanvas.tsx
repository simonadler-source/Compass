import { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { Canvas as FabricCanvas, Rect, Text, Group, Line, Path, Circle, FabricObject, Point } from 'fabric';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ZoomIn, ZoomOut, RotateCcw, Link2, Trash2, Plus, Edit2, Settings, LayoutGrid } from 'lucide-react';
import { TechnologyRepoItem } from '@/hooks/useTechnologyRepository';
import { Layer } from '@/hooks/useLayers';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from '@/components/ui/context-menu';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

declare module 'fabric' {
  interface FabricObject {
    nodeId?: string;
    areaId?: string;
    techId?: string;
    isPort?: boolean;
    portSide?: 'left' | 'right' | 'top' | 'bottom';
    parentTechId?: string;
  }
}

export interface CanvasTechNode {
  id: string;
  techId: string;
  name: string;
  functionalArea: string;
  layer: string;
  x: number;
  y: number;
  isCompetitor?: boolean;
  relationshipStatus?: 'competitor' | 'complementary' | 'complementary_risk' | 'neutral';
  ownerName?: string;
  status?: 'pending' | 'confirmed';
  priority?: 'critical' | 'high' | 'medium' | 'low';
}

export interface CanvasAreaNode {
  id: string;
  name: string;
  layer: string;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  priority?: 'critical' | 'high' | 'medium' | 'low';
}

export interface CanvasConnection {
  id: string;
  fromTechId: string;
  toTechId: string;
  label?: string;
  fromPort?: 'left' | 'right' | 'top' | 'bottom';
  toPort?: 'left' | 'right' | 'top' | 'bottom';
}

interface FunctionalAreaCanvasProps {
  areas: CanvasAreaNode[];
  technologies: CanvasTechNode[];
  connections: CanvasConnection[];
  layers?: Layer[];
  layerHeights?: Record<string, number>;
  onAreasChange: (areas: CanvasAreaNode[]) => void;
  onTechnologiesChange: (techs: CanvasTechNode[]) => void;
  onConnectionsChange: (conns: CanvasConnection[]) => void;
  onDropTechnology?: (tech: TechnologyRepoItem, areaId: string, x: number, y: number) => void;
  onRemoveTechnology?: (techNodeId: string) => void;
  onAddArea?: (area: { name: string; layer: string; color: string }) => void;
  onEditArea?: (id: string, updates: { name?: string; color?: string }) => void;
  onDeleteArea?: (id: string) => void;
  mode?: 'reference' | 'account';
  readOnly?: boolean;
  height?: number;
}

// Fallback layer config if no layers provided
const DEFAULT_LAYERS = ['host', 'build', 'adopt', 'growth', 'operations'] as const;
const DEFAULT_LAYER_CONFIG: Record<string, { label: string; subtitle: string; color: string; bgColor: string; lineColor: string; height: number }> = {
  host: { label: 'LAYER 1: HOST ENVIRONMENT', subtitle: '(Where Pendo Lives)', color: '#fef3c7', bgColor: '#fffbeb', lineColor: '#f59e0b', height: 160 },
  build: { label: 'LAYER 2: BUILD STACK', subtitle: '(Product & Engineering)', color: '#fde68a', bgColor: '#fef9c3', lineColor: '#eab308', height: 160 },
  adopt: { label: 'LAYER 3: ADOPT STACK', subtitle: '(Enablement & Support)', color: '#fed7aa', bgColor: '#ffedd5', lineColor: '#f97316', height: 160 },
  growth: { label: 'LAYER 4: GROWTH STACK', subtitle: '(Revenue & CRM)', color: '#fecaca', bgColor: '#fef2f2', lineColor: '#ef4444', height: 160 },
  operations: { label: 'LAYER 5: BUSINESS OPS', subtitle: '(C-Suite & Strategy)', color: '#e9d5ff', bgColor: '#faf5ff', lineColor: '#a855f7', height: 160 },
};

// Functional area colors for connection lines
const AREA_COLORS: Record<string, string> = {
  'Host Application': '#f59e0b',
  'Third-Party Apps': '#d97706',
  'Data Capture & Delivery': '#22c55e',
  'Analytics & Insights': '#3b82f6',
  'Roadmap & Feedback': '#8b5cf6',
  'Issue Tracking & Agile': '#6366f1',
  'Digital Adoption & Guides': '#ec4899',
  'Knowledge Base & Content': '#14b8a6',
  'Learning Management (LMS)': '#06b6d4',
  'CRM': '#f43f5e',
  'Back Office Processes': '#f97316',
  'Data Lake / Warehouse': '#84cc16',
  'Financial & Planning Systems': '#a855f7',
  'Executive Dashboards & BI': '#6366f1',
};

const LEFT_MARGIN = 160;
const LAYER_HEIGHT = 160;
const CANVAS_WIDTH = 1600;
const CANVAS_HEIGHT = 900;
const DEFAULT_TECH_CHIP_WIDTH = 120; // Increased from 100
const DEFAULT_TECH_CHIP_HEIGHT = 36;
const MIN_TECH_CHIP_WIDTH = 80; // Increased from 60
const MAX_TECH_CHIP_WIDTH = 180; // Maximum chip width for long names
const MIN_TECH_CHIP_HEIGHT = 28;
const CHIP_PADDING = 10; // Increased padding between chips in grid
const AREA_HEADER_HEIGHT = 32; // space for area title
const PORT_RADIUS = 5;
const CHAR_WIDTH = 7; // Approximate pixel width per character

// Pendo pink for chip borders
const PENDO_PINK = '#ec4899';

// Priority colors for area badges
const PRIORITY_COLORS: Record<string, string> = {
  critical: '#ef4444',
  high: '#f97316',
  medium: '#eab308',
  low: '#22c55e',
};

const colorWithAlpha = (color: string, alpha: number) => {
  if (!color) return `rgba(0, 0, 0, ${alpha})`;
  if (color.startsWith('rgba(') || color.startsWith('hsla(')) return color;

  if (color.startsWith('rgb(')) {
    return color.replace('rgb(', 'rgba(').replace(')', `, ${alpha})`);
  }

  if (color.startsWith('#')) {
    const hex = color.replace('#', '').trim();
    const normalized = hex.length === 3 ? hex.split('').map(c => c + c).join('') : hex;

    if (normalized.length >= 6) {
      const r = parseInt(normalized.slice(0, 2), 16);
      const g = parseInt(normalized.slice(2, 4), 16);
      const b = parseInt(normalized.slice(4, 6), 16);
      return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
  }

  // Fallback: return as-is (better than hiding it)
  return color;
};

const adjustHexColor = (color: string, amount: number) => {
  // amount: -1..1 (negative darkens, positive lightens)
  if (!color?.startsWith('#')) return color;
  const hex = color.replace('#', '').trim();
  const normalized = hex.length === 3 ? hex.split('').map(c => c + c).join('') : hex;
  if (normalized.length < 6) return color;

  const r0 = parseInt(normalized.slice(0, 2), 16);
  const g0 = parseInt(normalized.slice(2, 4), 16);
  const b0 = parseInt(normalized.slice(4, 6), 16);

  const clamp = (n: number) => Math.max(0, Math.min(255, Math.round(n)));
  const shift = (v: number) => {
    if (amount >= 0) return v + (255 - v) * amount;
    return v * (1 + amount);
  };

  const r = clamp(shift(r0));
  const g = clamp(shift(g0));
  const b = clamp(shift(b0));
  return `rgb(${r}, ${g}, ${b})`;
};

export function FunctionalAreaCanvas({
  areas,
  technologies,
  connections,
  layers: propLayers,
  layerHeights: propLayerHeights,
  onAreasChange,
  onTechnologiesChange,
  onConnectionsChange,
  onDropTechnology,
  onRemoveTechnology,
  onAddArea,
  onEditArea,
  onDeleteArea,
  mode = 'account',
  readOnly = false,
  height = 850,
}: FunctionalAreaCanvasProps) {
  // Build layer config from props or fallback to defaults
  const layerConfig = useMemo(() => {
    if (propLayers && propLayers.length > 0) {
      const config: Record<string, { label: string; subtitle: string; color: string; bgColor: string; lineColor: string; height: number }> = {};
      propLayers.forEach(layer => {
        // Use dynamic height if provided, otherwise use layer's stored height
        const dynamicHeight = propLayerHeights?.[layer.name] ?? layer.height;
        config[layer.name] = {
          label: `LAYER ${layer.sort_order + 1}: ${layer.label}`,
          subtitle: layer.subtitle || '',
          color: layer.color,
          bgColor: layer.bg_color,
          lineColor: layer.line_color,
          height: dynamicHeight,
        };
      });
      return config;
    }
    return DEFAULT_LAYER_CONFIG;
  }, [propLayers, propLayerHeights]);

  const layerNames = useMemo(() => {
    if (propLayers && propLayers.length > 0) {
      return propLayers.map(l => l.name);
    }
    return [...DEFAULT_LAYERS];
  }, [propLayers]);

  // Calculate Y offset for each layer based on dynamic heights
  const layerYOffsets = useMemo(() => {
    const offsets: Record<string, number> = {};
    let currentY = 0;
    layerNames.forEach(name => {
      offsets[name] = currentY;
      currentY += layerConfig[name]?.height || 160;
    });
    return offsets;
  }, [layerNames, layerConfig]);

  // Calculate total canvas height based on layers
  const totalLayerHeight = useMemo(() => {
    return layerNames.reduce((sum, name) => sum + (layerConfig[name]?.height || 160), 0);
  }, [layerNames, layerConfig]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const fabricRef = useRef<FabricCanvas | null>(null);
  const areasMapRef = useRef<Map<string, Group>>(new Map());
  const techsMapRef = useRef<Map<string, Group>>(new Map());
  const portsMapRef = useRef<Map<string, Circle>>(new Map());
  const connectionsRef = useRef<FabricObject[]>([]);

  // Keep latest values for Fabric event handlers (avoid stale closures)
  const technologiesRef = useRef<CanvasTechNode[]>(technologies);
  const areasRef = useRef<CanvasAreaNode[]>(areas);
  const onTechnologiesChangeRef = useRef(onTechnologiesChange);

  useEffect(() => {
    technologiesRef.current = technologies;
  }, [technologies]);

  useEffect(() => {
    areasRef.current = areas;
  }, [areas]);

  useEffect(() => {
    onTechnologiesChangeRef.current = onTechnologiesChange;
  }, [onTechnologiesChange]);

  const [selectedTechId, setSelectedTechId] = useState<string | null>(null);
  const [selectedAreaId, setSelectedAreaId] = useState<string | null>(null);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionStart, setConnectionStart] = useState<{ techId: string; port: string } | null>(null);
  const [showLabelDialog, setShowLabelDialog] = useState(false);
  const [showAreaDialog, setShowAreaDialog] = useState(false);
  const [editingArea, setEditingArea] = useState<CanvasAreaNode | null>(null);
  const [newAreaName, setNewAreaName] = useState('');
  const [newAreaLayer, setNewAreaLayer] = useState('adopt');
  const [newAreaColor, setNewAreaColor] = useState('#fef9c3');
  const [pendingConnection, setPendingConnection] = useState<{ from: string; to: string; fromPort: string; toPort: string } | null>(null);
  const [connectionLabel, setConnectionLabel] = useState('');
  const [tempLine, setTempLine] = useState<Line | null>(null);
  const [layoutVersion, setLayoutVersion] = useState(0);

  // Calculate tech count per area for gradient activation
  const techCountByArea = useMemo(() => {
    const counts: Record<string, number> = {};
    technologies.forEach(tech => {
      const area = areas.find(a => a.name === tech.functionalArea);
      if (area) {
        counts[area.id] = (counts[area.id] || 0) + 1;
      }
    });
    return counts;
  }, [technologies, areas]);

  // Calculate optimal chip dimensions for an area based on tech count AND text lengths
  const getOptimalChipDimensions = useCallback((area: CanvasAreaNode, areaId: string) => {
    const techsInArea = technologies.filter(t => {
      const tArea = areas.find(a => a.name === t.functionalArea);
      return tArea?.id === areaId;
    });
    
    const techCount = techsInArea.length;
    const MAX_ROWS = 4; // Limit vertical growth
    
    if (techCount === 0) {
      return { width: DEFAULT_TECH_CHIP_WIDTH, height: DEFAULT_TECH_CHIP_HEIGHT, cols: 1, rows: 0, requiredHeight: 80 };
    }
    
    // Calculate the width needed for each tech based on its name
    const techWidths = techsInArea.map(tech => {
      const textWidth = tech.name.length * CHAR_WIDTH + 24; // 24px for padding inside chip
      return Math.max(MIN_TECH_CHIP_WIDTH, Math.min(MAX_TECH_CHIP_WIDTH, textWidth));
    });
    
    // Use the maximum width needed to ensure no truncation
    const chipWidth = Math.max(...techWidths);
    const chipHeight = DEFAULT_TECH_CHIP_HEIGHT;
    
    // Calculate columns to keep rows within MAX_ROWS
    let cols = 1;
    let rows = techCount;
    while (rows > MAX_ROWS && cols < techCount) {
      cols++;
      rows = Math.ceil(techCount / cols);
    }
    
    // Calculate required height for this area (with extra padding)
    const requiredHeight = AREA_HEADER_HEIGHT + CHIP_PADDING * 2 + rows * chipHeight + (rows - 1) * CHIP_PADDING + 5;
    
    return { width: chipWidth, height: chipHeight, cols, rows, requiredHeight };
  }, [technologies, areas]);

  // Cache chip dimensions per area
  const chipDimensionsByArea = useMemo(() => {
    const dims: Record<string, { width: number; height: number; cols: number; rows: number; requiredHeight: number }> = {};
    areas.forEach(area => {
      dims[area.id] = getOptimalChipDimensions(area, area.id);
    });
    return dims;
  }, [areas, getOptimalChipDimensions]);

  // Keep latest chip dims for Fabric event handlers (avoid stale closures)
  const chipDimensionsByAreaRef = useRef(chipDimensionsByArea);
  useEffect(() => {
    chipDimensionsByAreaRef.current = chipDimensionsByArea;
  }, [chipDimensionsByArea]);

  // Calculate priority per area (from technologies or area itself)
  const priorityByArea = useMemo(() => {
    const priorities: Record<string, string> = {};
    areas.forEach(area => {
      if (area.priority) {
        priorities[area.id] = area.priority;
      } else {
        // Check technologies in this area for their priority
        const areaTechs = technologies.filter(t => t.functionalArea === area.name);
        const priorityOrder = ['critical', 'high', 'medium', 'low'];
        for (const p of priorityOrder) {
          if (areaTechs.some(t => t.priority === p)) {
            priorities[area.id] = p;
            break;
          }
        }
      }
    });
    return priorities;
  }, [areas, technologies]);

  // Get border opacity based on tech count (gradient: 0.3 base -> 1.0 solid at 3+ techs)
  const getAreaBorderOpacity = useCallback((areaId: string) => {
    const count = techCountByArea[areaId] || 0;
    if (count === 0) return 0.2;
    if (count === 1) return 0.5;
    if (count === 2) return 0.75;
    return 1.0;
  }, [techCountByArea]);

  // Calculate grid position for a technology within an area
  const getGridPositionInArea = useCallback((area: CanvasAreaNode, slotIndex: number) => {
    const dims = chipDimensionsByArea[area.id] || { width: DEFAULT_TECH_CHIP_WIDTH, height: DEFAULT_TECH_CHIP_HEIGHT, cols: 2 };
    const { width: chipWidth, height: chipHeight, cols } = dims;
    
    const row = Math.floor(slotIndex / cols);
    const col = slotIndex % cols;
    
    const x = area.x + CHIP_PADDING + col * (chipWidth + CHIP_PADDING);
    const y = area.y + AREA_HEADER_HEIGHT + CHIP_PADDING + row * (chipHeight + CHIP_PADDING);
    
    return { x, y, chipWidth, chipHeight };
  }, [chipDimensionsByArea]);

  // Get the next available slot index for a new tech in an area
  const getNextSlotInArea = useCallback((areaId: string, excludeTechId?: string) => {
    const area = areas.find(a => a.id === areaId);
    if (!area) return 0;
    
    const techsInArea = technologies.filter(t => {
      const tArea = areas.find(a => a.name === t.functionalArea);
      return tArea?.id === areaId && t.id !== excludeTechId;
    });
    
    return techsInArea.length;
  }, [areas, technologies]);

  // Recalculate grid positions for all technologies within their areas
  const recalculateGridPositions = useCallback((techs: CanvasTechNode[]): CanvasTechNode[] => {
    // Group techs by area
    const techsByArea: Record<string, CanvasTechNode[]> = {};
    const unassignedTechs: CanvasTechNode[] = [];
    
    techs.forEach(tech => {
      const area = areas.find(a => a.name === tech.functionalArea);
      if (area) {
        if (!techsByArea[area.id]) techsByArea[area.id] = [];
        techsByArea[area.id].push(tech);
      } else {
        unassignedTechs.push(tech);
      }
    });
    
    const repositioned: CanvasTechNode[] = [];
    
    // Reposition techs within each area
    Object.entries(techsByArea).forEach(([areaId, areaTechs]) => {
      const area = areas.find(a => a.id === areaId);
      if (!area) {
        repositioned.push(...areaTechs);
        return;
      }
      
      areaTechs.forEach((tech, slotIndex) => {
        const pos = getGridPositionInArea(area, slotIndex);
        repositioned.push({ ...tech, x: pos.x, y: pos.y });
      });
    });
    
    // Keep unassigned techs as-is
    repositioned.push(...unassignedTechs);
    
    return repositioned;
  }, [areas, getGridPositionInArea]);

  // Get connection color based on source tech's functional area
  const getConnectionColor = useCallback((fromTechId: string) => {
    const tech = technologies.find(t => t.id === fromTechId);
    if (!tech) return '#94a3b8';
    return AREA_COLORS[tech.functionalArea] || layerConfig[tech.layer]?.lineColor || '#94a3b8';
  }, [technologies]);

  // Draw layer backgrounds using dynamic layer config
  const drawLayersOnCanvas = useCallback((canvas: FabricCanvas, width: number) => {
    let currentY = 0;
    layerNames.forEach((layerName, index) => {
      const config = layerConfig[layerName];
      if (!config) return;
      
      const layerHeight = config.height;

      const bg = new Rect({
        left: 0, top: currentY, width, height: layerHeight,
        fill: config.bgColor,
        selectable: false, evented: false,
      });
      canvas.add(bg);

      const labelBg = new Rect({
        left: 0, top: currentY, width: LEFT_MARGIN - 10, height: layerHeight,
        fill: config.color,
        selectable: false, evented: false,
      });
      canvas.add(labelBg);

      const layerNum = config.label.split(':')[0];
      const layerLabel = config.label.split(':')[1]?.trim() || '';
      
      canvas.add(new Text(layerNum + ':', {
        left: 10, top: currentY + 25, fontSize: 10, fill: '#78350f',
        fontFamily: 'Inter, system-ui, sans-serif', fontWeight: '700',
        selectable: false, evented: false,
      }));

      canvas.add(new Text(layerLabel, {
        left: 10, top: currentY + 42, fontSize: 13, fill: '#78350f',
        fontFamily: 'Inter, system-ui, sans-serif', fontWeight: '800',
        selectable: false, evented: false,
      }));

      canvas.add(new Text(config.subtitle, {
        left: 10, top: currentY + 62, fontSize: 9, fill: '#92400e',
        fontFamily: 'Inter, system-ui, sans-serif', fontStyle: 'italic',
        selectable: false, evented: false,
      }));

      if (index < layerNames.length - 1) {
        canvas.add(new Line([0, currentY + layerHeight, width, currentY + layerHeight], {
          stroke: '#e2e8f0', strokeWidth: 1,
          selectable: false, evented: false,
        }));
      }
      
      currentY += layerHeight;
    });
  }, [layerNames, layerConfig]);

  // Initialize canvas
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const containerWidth = containerRef.current.offsetWidth || 1200;
    const canvasWidth = Math.max(CANVAS_WIDTH, containerWidth);
    const canvasHeight = Math.max(CANVAS_HEIGHT, height, totalLayerHeight);
    
    const canvas = new FabricCanvas(canvasRef.current, {
      width: canvasWidth,
      height: canvasHeight,
      backgroundColor: 'transparent',
      selection: !readOnly,
    });

    fabricRef.current = canvas;
    drawLayersOnCanvas(canvas, canvasWidth);

    // Enable panning with drag (primary behavior) or middle mouse
    let isPanning = false;
    let lastPosX = 0;
    let lastPosY = 0;

    canvas.on('mouse:down', (opt) => {
      const evt = opt.e as MouseEvent;
      const target = opt.target;
      
      // Pan if clicking on empty space, or with alt/middle mouse
      if (!target || evt.altKey || evt.button === 1) {
        isPanning = true;
        lastPosX = evt.clientX;
        lastPosY = evt.clientY;
        canvas.selection = false;
        canvas.setCursor('grabbing');
      }
    });

    canvas.on('mouse:move', (opt) => {
      if (isPanning) {
        const evt = opt.e as MouseEvent;
        const vpt = canvas.viewportTransform;
        if (vpt) {
          vpt[4] += evt.clientX - lastPosX;
          vpt[5] += evt.clientY - lastPosY;
          canvas.requestRenderAll();
        }
        lastPosX = evt.clientX;
        lastPosY = evt.clientY;
      }
    });

    canvas.on('mouse:up', () => {
      isPanning = false;
      canvas.selection = !readOnly;
      canvas.setCursor('default');
    });

    // Mouse wheel now pans instead of zooming
    canvas.on('mouse:wheel', (opt) => {
      const evt = opt.e;
      const vpt = canvas.viewportTransform;
      if (vpt) {
        // Scroll pans the canvas
        vpt[4] -= evt.deltaX;
        vpt[5] -= evt.deltaY;
        canvas.requestRenderAll();
      }
      evt.preventDefault();
      evt.stopPropagation();
    });

    // Handle object movement - update connections live
    canvas.on('object:moving', (e) => {
      const obj = e.target as any;
      if (obj?.techId) {
        obj.setCoords();
        redrawConnections();
      }
    });

    canvas.on('object:modified', (e) => {
      const obj = e.target as any;
      if (!obj?.techId) return;

      const currentTechs = technologiesRef.current;
      const currentAreas = areasRef.current;

      const left = obj.left || 0;
      const top = obj.top || 0;

      // Detect which area the chip is inside (use chip center)
      const cx = left + DEFAULT_TECH_CHIP_WIDTH / 2;
      const cy = top + DEFAULT_TECH_CHIP_HEIGHT / 2;

      let targetAreaId: string | null = null;
      areasMapRef.current.forEach((group, id) => {
        const bounds = group.getBoundingRect();
        if (cx >= bounds.left && cx <= bounds.left + bounds.width && cy >= bounds.top && cy <= bounds.top + bounds.height) {
          targetAreaId = id;
        }
      });

      const targetArea = targetAreaId ? currentAreas.find(a => a.id === targetAreaId) : undefined;

      // If it was dropped into an area, snap to grid position within that area
      let finalX = left;
      let finalY = top;
      
      if (targetArea) {
        // Count existing techs in this area (excluding the one being moved)
        const techsInArea = currentTechs.filter(t => {
          const tArea = currentAreas.find(a => a.name === t.functionalArea);
          return tArea?.id === targetAreaId && t.id !== obj.techId;
        });
        
        // Use dynamic chip dimensions
        const dims = chipDimensionsByAreaRef.current[targetArea.id] || { width: DEFAULT_TECH_CHIP_WIDTH, height: DEFAULT_TECH_CHIP_HEIGHT, cols: 2 };
        const { width: chipWidth, height: chipHeight, cols: chipsPerRow } = dims;
        
        // Calculate which slot user is trying to drop into based on position
        const relX = left - targetArea.x - CHIP_PADDING;
        const relY = top - targetArea.y - AREA_HEADER_HEIGHT - CHIP_PADDING;
        
        const dropCol = Math.max(0, Math.floor(relX / (chipWidth + CHIP_PADDING)));
        const dropRow = Math.max(0, Math.floor(relY / (chipHeight + CHIP_PADDING)));
        const desiredSlot = dropRow * chipsPerRow + dropCol;
        
        // Clamp to available slots (append at end if dropping past existing techs)
        const slotIndex = Math.min(desiredSlot, techsInArea.length);
        
        // Calculate final grid position
        const row = Math.floor(slotIndex / chipsPerRow);
        const col = slotIndex % chipsPerRow;
        
        finalX = targetArea.x + CHIP_PADDING + col * (chipWidth + CHIP_PADDING);
        finalY = targetArea.y + AREA_HEADER_HEIGHT + CHIP_PADDING + row * (chipHeight + CHIP_PADDING);
        
        obj.set({ left: finalX, top: finalY });
        obj.setCoords();
      }

      const updated = currentTechs.map(t => {
        if (t.id !== obj.techId) return t;
        return {
          ...t,
          x: finalX,
          y: finalY,
          ...(targetArea
            ? { functionalArea: targetArea.name, layer: targetArea.layer }
            : null),
        };
      });

      onTechnologiesChangeRef.current(updated);
    });

    canvas.on('selection:created', (e) => {
      const selected = e.selected?.[0] as any;
      if (selected?.techId) {
        setSelectedTechId(selected.techId);
      }
    });

    canvas.on('selection:cleared', () => {
      setSelectedTechId(null);
    });

    // Handle port clicks for connections
    canvas.on('mouse:down', (e) => {
      const target = e.target as any;
      if (target?.isPort && isConnecting) {
        if (!connectionStart) {
          setConnectionStart({ techId: target.parentTechId, port: target.portSide });
          // Start drawing temp line
          const port = portsMapRef.current.get(`${target.parentTechId}-${target.portSide}`);
          if (port) {
            const line = new Line([port.left!, port.top!, port.left!, port.top!], {
              stroke: getConnectionColor(target.parentTechId),
              strokeWidth: 2,
              strokeDashArray: [5, 3],
              selectable: false,
              evented: false,
            });
            canvas.add(line);
            setTempLine(line);
          }
        } else if (target.parentTechId !== connectionStart.techId) {
          // Complete connection
          setPendingConnection({
            from: connectionStart.techId,
            to: target.parentTechId,
            fromPort: connectionStart.port,
            toPort: target.portSide,
          });
          setShowLabelDialog(true);
          
          // Remove temp line
          if (tempLine) {
            canvas.remove(tempLine);
            setTempLine(null);
          }
          setConnectionStart(null);
        }
      }
    });

    // Update temp line on mouse move
    canvas.on('mouse:move', (e) => {
      if (tempLine && connectionStart) {
        const pointer = canvas.getViewportPoint(e.e);
        tempLine.set({ x2: pointer.x, y2: pointer.y });
        canvas.renderAll();
      }
    });

    return () => {
      canvas.dispose();
      fabricRef.current = null;
    };
  }, [height, readOnly, isConnecting, drawLayersOnCanvas, totalLayerHeight]);


  // Create connection port
  const createPort = (techId: string, side: 'left' | 'right' | 'top' | 'bottom', x: number, y: number) => {
    const port = new Circle({
      left: x - PORT_RADIUS,
      top: y - PORT_RADIUS,
      radius: PORT_RADIUS,
      fill: isConnecting ? '#3b82f6' : '#94a3b8',
      stroke: '#ffffff',
      strokeWidth: 2,
      selectable: false,
      evented: true,
      hoverCursor: 'crosshair',
    });
    (port as any).isPort = true;
    (port as any).portSide = side;
    (port as any).parentTechId = techId;
    return port;
  };

  // Get port position for a tech chip (uses default sizes for ports)
  const getPortPosition = (techGroup: Group, side: 'left' | 'right' | 'top' | 'bottom') => {
    const left = techGroup.left || 0;
    const top = techGroup.top || 0;
    const width = (techGroup as any)._chipWidth || DEFAULT_TECH_CHIP_WIDTH;
    const height = (techGroup as any)._chipHeight || DEFAULT_TECH_CHIP_HEIGHT;
    
    switch (side) {
      case 'left': return { x: left, y: top + height / 2 };
      case 'right': return { x: left + width, y: top + height / 2 };
      case 'top': return { x: left + width / 2, y: top };
      case 'bottom': return { x: left + width / 2, y: top + height };
    }
  };

  // Calculate optimal port sides for connection
  const getOptimalPorts = (from: CanvasTechNode, to: CanvasTechNode): { fromPort: 'left' | 'right' | 'top' | 'bottom'; toPort: 'left' | 'right' | 'top' | 'bottom' } => {
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    
    // Determine primary direction
    if (Math.abs(dx) > Math.abs(dy)) {
      // Horizontal dominant
      if (dx > 0) {
        return { fromPort: 'right', toPort: 'left' };
      } else {
        return { fromPort: 'left', toPort: 'right' };
      }
    } else {
      // Vertical dominant
      if (dy > 0) {
        return { fromPort: 'bottom', toPort: 'top' };
      } else {
        return { fromPort: 'top', toPort: 'bottom' };
      }
    }
  };

  // Draw auto-routed bezier connection
  const drawConnection = useCallback((conn: CanvasConnection) => {
    const canvas = fabricRef.current;
    if (!canvas) return null;

    const fromTech = techsMapRef.current.get(conn.fromTechId);
    const toTech = techsMapRef.current.get(conn.toTechId);
    if (!fromTech || !toTech) return null;

    const fromData = technologies.find(t => t.id === conn.fromTechId);
    const toData = technologies.find(t => t.id === conn.toTechId);
    if (!fromData || !toData) return null;

    // Get port positions
    const { fromPort, toPort } = conn.fromPort && conn.toPort 
      ? { fromPort: conn.fromPort, toPort: conn.toPort }
      : getOptimalPorts(fromData, toData);

    const fromPos = getPortPosition(fromTech, fromPort);
    const toPos = getPortPosition(toTech, toPort);

    // Calculate bezier control points for smooth curves
    const dx = toPos.x - fromPos.x;
    const dy = toPos.y - fromPos.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const curvature = Math.min(distance * 0.4, 100);

    let cp1x = fromPos.x, cp1y = fromPos.y;
    let cp2x = toPos.x, cp2y = toPos.y;

    // Control points based on port direction
    switch (fromPort) {
      case 'right': cp1x += curvature; break;
      case 'left': cp1x -= curvature; break;
      case 'bottom': cp1y += curvature; break;
      case 'top': cp1y -= curvature; break;
    }
    switch (toPort) {
      case 'right': cp2x += curvature; break;
      case 'left': cp2x -= curvature; break;
      case 'bottom': cp2y += curvature; break;
      case 'top': cp2y -= curvature; break;
    }

    const color = getConnectionColor(conn.fromTechId);
    
    // Create bezier path
    const pathData = `M ${fromPos.x} ${fromPos.y} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${toPos.x} ${toPos.y}`;
    const path = new Path(pathData, {
      stroke: color,
      strokeWidth: 3,
      fill: '',
      selectable: false,
      evented: false,
      opacity: 0.8,
    });

    // Arrow head at end
    const arrowSize = 8;
    const angle = Math.atan2(toPos.y - cp2y, toPos.x - cp2x);
    
    const arrowPath = new Path(
      `M ${toPos.x} ${toPos.y} ` +
      `L ${toPos.x - arrowSize * Math.cos(angle - Math.PI / 6)} ${toPos.y - arrowSize * Math.sin(angle - Math.PI / 6)} ` +
      `L ${toPos.x - arrowSize * Math.cos(angle + Math.PI / 6)} ${toPos.y - arrowSize * Math.sin(angle + Math.PI / 6)} Z`,
      {
        fill: color,
        stroke: color,
        strokeWidth: 1,
        selectable: false,
        evented: false,
      }
    );

    canvas.add(path);
    canvas.add(arrowPath);

    const objects: FabricObject[] = [path, arrowPath];

    // Add label if exists
    if (conn.label) {
      const midX = (fromPos.x + toPos.x) / 2;
      const midY = (fromPos.y + toPos.y) / 2;
      
      const labelBg = new Rect({
        left: midX - 40,
        top: midY - 10,
        width: 80,
        height: 20,
        fill: '#ffffff',
        stroke: color,
        strokeWidth: 1,
        rx: 4,
        ry: 4,
        selectable: false,
        evented: false,
      });

      const labelText = new Text(conn.label.length > 12 ? conn.label.substring(0, 11) + '…' : conn.label, {
        left: midX,
        top: midY,
        fontSize: 9,
        fill: color,
        fontFamily: 'Inter, system-ui, sans-serif',
        fontWeight: '600',
        originX: 'center',
        originY: 'center',
        selectable: false,
        evented: false,
      });

      canvas.add(labelBg);
      canvas.add(labelText);
      objects.push(labelBg, labelText);
    }

    return objects;
  }, [technologies, getConnectionColor]);

  // Redraw all connections
  const redrawConnections = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;

    // Remove old connections
    connectionsRef.current.forEach(obj => canvas.remove(obj));
    connectionsRef.current = [];

    // Draw new connections
    connections.forEach(conn => {
      const objects = drawConnection(conn);
      if (objects) {
        connectionsRef.current.push(...objects);
      }
    });

    // Bring tech chips to front
    techsMapRef.current.forEach(group => canvas.bringObjectToFront(group));
    portsMapRef.current.forEach(port => canvas.bringObjectToFront(port));

    canvas.renderAll();
  }, [connections, drawConnection]);

  // Render technology chips with ports
  useEffect(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;

    // Remove old ports
    portsMapRef.current.forEach(port => canvas.remove(port));
    portsMapRef.current.clear();

    // Remove old techs
    techsMapRef.current.forEach((group, id) => {
      if (!technologies.find(t => t.id === id)) {
        canvas.remove(group);
        techsMapRef.current.delete(id);
      }
    });

    // Group technologies by area to calculate grid positions
    const techsByArea: Record<string, CanvasTechNode[]> = {};
    const unassignedTechs: CanvasTechNode[] = [];
    
    technologies.forEach(tech => {
      const area = areas.find(a => a.name === tech.functionalArea);
      if (area) {
        if (!techsByArea[area.id]) techsByArea[area.id] = [];
        techsByArea[area.id].push(tech);
      } else {
        unassignedTechs.push(tech);
      }
    });

    // Calculate grid positions for each tech using dynamic chip sizes
    const techPositions: Record<string, { x: number; y: number; chipWidth: number; chipHeight: number }> = {};
    
    Object.entries(techsByArea).forEach(([areaId, areaTechs]) => {
      const area = areas.find(a => a.id === areaId);
      if (!area) return;
      
      const dims = chipDimensionsByArea[areaId] || { width: DEFAULT_TECH_CHIP_WIDTH, height: DEFAULT_TECH_CHIP_HEIGHT, cols: 2 };
      const { width: chipWidth, height: chipHeight, cols } = dims;
      
      areaTechs.forEach((tech, slotIndex) => {
        const row = Math.floor(slotIndex / cols);
        const col = slotIndex % cols;
        
        techPositions[tech.id] = {
          x: area.x + CHIP_PADDING + col * (chipWidth + CHIP_PADDING),
          y: area.y + AREA_HEADER_HEIGHT + CHIP_PADDING + row * (chipHeight + CHIP_PADDING),
          chipWidth,
          chipHeight,
        };
      });
    });
    
    // Unassigned techs keep their original positions
    unassignedTechs.forEach(tech => {
      techPositions[tech.id] = { x: tech.x, y: tech.y, chipWidth: DEFAULT_TECH_CHIP_WIDTH, chipHeight: DEFAULT_TECH_CHIP_HEIGHT };
    });

    // Add/update techs with calculated positions
    technologies.forEach(tech => {
      const pos = techPositions[tech.id] || { x: tech.x, y: tech.y, chipWidth: DEFAULT_TECH_CHIP_WIDTH, chipHeight: DEFAULT_TECH_CHIP_HEIGHT };
      const { chipWidth, chipHeight } = pos;
      let group = techsMapRef.current.get(tech.id);
      
      if (group) {
        // Update existing group position and size.
        // NOTE: previously we only updated left/top which could leave stale chip widths/heights,
        // causing overlaps or chips spilling outside functional areas after re-layout.
        const prevW = (group as any)._chipWidth ?? DEFAULT_TECH_CHIP_WIDTH;
        const prevH = (group as any)._chipHeight ?? DEFAULT_TECH_CHIP_HEIGHT;
        const sizeChanged = prevW !== chipWidth || prevH !== chipHeight;

        if (sizeChanged) {
          // Recreate group to ensure Fabric recalculates bounds correctly.
          canvas.remove(group);
          techsMapRef.current.delete(tech.id);
          group = undefined;
        } else {
          group.set({ left: pos.x, top: pos.y });
          (group as any)._chipWidth = chipWidth;
          (group as any)._chipHeight = chipHeight;
          group.setCoords();
        }
      }

      if (!group) {
        const isCompetitor = tech.isCompetitor || tech.relationshipStatus === 'competitor';
        const isPending = tech.status === 'pending';
        const isRisk = tech.relationshipStatus === 'complementary_risk';
        
        let bgColor = '#ffffff';
        let borderColor = '#d1d5db';
        let textColor = '#1f2937';
        
        if (isCompetitor) {
          bgColor = '#fef2f2'; borderColor = '#ef4444'; textColor = '#991b1b';
        } else if (isRisk) {
          bgColor = '#fefce8'; borderColor = '#eab308'; textColor = '#854d0e';
        } else if (isPending) {
          bgColor = '#fff7ed'; borderColor = '#f97316'; textColor = '#9a3412';
        }

        const chip = new Rect({
          width: chipWidth,
          height: chipHeight,
          fill: bgColor,
          stroke: borderColor,
          strokeWidth: isPending ? 2 : 1,
          strokeDashArray: isPending ? [4, 2] : undefined,
          rx: 6,
          ry: 6,
          shadow: { color: 'rgba(0,0,0,0.08)', blur: 4, offsetX: 1, offsetY: 2 } as any,
        });

        // Show full name - no truncation since chips are sized to fit
        const displayName = tech.name;
        const fontSize = chipHeight < 32 ? 9 : 10;

        const nameText = new Text(displayName, {
          left: chipWidth / 2,
          top: chipHeight / 2,
          fontSize,
          fill: textColor,
          fontFamily: 'Inter, system-ui, sans-serif',
          fontWeight: '500',
          originX: 'center',
          originY: 'center',
        });

        group = new Group([chip, nameText], {
          left: pos.x,
          top: pos.y,
          selectable: !readOnly,
          hasControls: false,
          hasBorders: true,
          lockRotation: true,
          lockScalingX: true,
          lockScalingY: true,
        });

        (group as any).techId = tech.id;
        canvas.add(group);
        techsMapRef.current.set(tech.id, group);
      }

      // Create ports for this tech (only in connect mode)
      if (isConnecting && group) {
        const sides: Array<'left' | 'right' | 'top' | 'bottom'> = ['left', 'right', 'top', 'bottom'];
        sides.forEach(side => {
          const pos = getPortPosition(group!, side);
          const port = createPort(tech.id, side, pos.x, pos.y);
          canvas.add(port);
          portsMapRef.current.set(`${tech.id}-${side}`, port);
        });
      }
    });

    redrawConnections();
  }, [technologies, areas, chipDimensionsByArea, layoutVersion, readOnly, isConnecting, redrawConnections]);

  // Handle area changes - redraw with gradient borders based on tech count
  useEffect(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;

    // Remove areas that no longer exist
    areasMapRef.current.forEach((group, id) => {
      if (!areas.find(a => a.id === id)) {
        canvas.remove(group);
        areasMapRef.current.delete(id);
      }
    });

    // Add or update areas with gradient activation
    areas.forEach(area => {
      const existing = areasMapRef.current.get(area.id);
      const techCount = techCountByArea[area.id] || 0;
      
      // Use the dimensions from props - they are already calculated correctly
      // Only expand slightly if needed for chip content
      const dims = chipDimensionsByArea[area.id];
      const dynamicHeight = area.height; // Use prop height - already calculated with MAX_ROWS limit
      const dynamicWidth = area.width;   // Use prop width - already calculated with proper columns
      
      // Different styling for reference vs account mode
      let borderColor: string;
      let strokeWidth: number;
      let fillOpacity: number;
      let strokeDashArray: number[] | undefined;
      let fillColor: string;

      const isEmpty = techCount === 0;
      const emptyBorder = adjustHexColor(area.color, -0.65) || '#334155';
      const emptyFill = adjustHexColor(area.color, -0.18) || '#e2e8f0';

      // Get priority-based border color
      const areaPriority = priorityByArea[area.id];
      const priorityBorderColor = areaPriority ? PRIORITY_COLORS[areaPriority] : null;
      
      if (mode === 'reference') {
        // Reference mode: visible placeholder style
        borderColor = priorityBorderColor || (techCount > 0 ? PENDO_PINK : emptyBorder);
        strokeWidth = techCount > 0 ? 3 : 2;
        strokeDashArray = techCount > 0 ? undefined : [6, 3];
        fillOpacity = techCount > 0 ? 0.7 : 0.45;
        fillColor = techCount > 0 ? area.color : emptyFill;
      } else {
        // Account mode: use priority-based RGB border colors
        borderColor = priorityBorderColor || (techCount > 0 ? PENDO_PINK : emptyBorder);
        strokeWidth = priorityBorderColor ? 4 : (techCount > 0 ? 3 : 2);
        strokeDashArray = undefined; // solid border reads better on light layers
        fillOpacity = techCount > 0 ? 0.85 : 0.55;
        fillColor = techCount > 0 ? area.color : emptyFill;
      }

      if (existing) {
        // Update existing area position and remove for redraw with new styling
        canvas.remove(existing);
        areasMapRef.current.delete(area.id);
      }

      // Create area with current styling and DYNAMIC dimensions
      // NOTE: use alpha on fill instead of object opacity so borders stay visible.
      const rect = new Rect({
        width: dynamicWidth,
        height: dynamicHeight,
        fill: colorWithAlpha(fillColor, fillOpacity),
        stroke: borderColor,
        strokeWidth: strokeWidth,
        strokeDashArray: strokeDashArray,
        rx: 8,
        ry: 8,
        shadow: isEmpty
          ? ({ color: 'rgba(15, 23, 42, 0.12)', blur: 10, offsetX: 0, offsetY: 2 } as any)
          : undefined,
      });

      // Text color with better contrast - always dark for visibility
      const textColor = '#1f2937';
      const textOpacity = mode === 'reference' && techCount === 0 ? 0.85 : 1;

      const titleText = new Text(area.name, {
        left: dynamicWidth / 2,
        top: 12,
        fontSize: 11,
        fill: textColor,
        opacity: textOpacity,
        fontFamily: 'Inter, system-ui, sans-serif',
        fontWeight: '700',
        originX: 'center',
      });

      const groupItems: FabricObject[] = [rect, titleText];
      
      // Show "drop here" hint for reference mode empty areas
      if (techCount === 0 && mode === 'reference') {
        const hintText = new Text('Drop technologies here', {
          left: dynamicWidth / 2,
          top: dynamicHeight / 2 + 5,
          fontSize: 9,
          fill: '#9ca3af',
          fontFamily: 'Inter, system-ui, sans-serif',
          fontStyle: 'italic',
          originX: 'center',
          originY: 'center',
        });
        groupItems.push(hintText);
      }
      
      // Show tech count badge if in account mode and has techs
      if (techCount > 0 && mode === 'account') {
        const countBadge = new Rect({
          left: dynamicWidth - 28,
          top: 6,
          width: 22,
          height: 16,
          fill: PENDO_PINK,
          rx: 8,
          ry: 8,
        });
        const countText = new Text(String(techCount), {
          left: dynamicWidth - 17,
          top: 14,
          fontSize: 10,
          fill: '#ffffff',
          fontFamily: 'Inter, system-ui, sans-serif',
          fontWeight: '700',
          originX: 'center',
          originY: 'center',
        });
        groupItems.push(countBadge, countText);
      }
      
      // Show priority badge if area has a priority (use existing areaPriority from above)
      // Circular badge in bottom-right corner with priority label
      if (areaPriority && mode === 'account') {
        const priorityColor = PRIORITY_COLORS[areaPriority] || '#888888';
        const priorityLabel = areaPriority.charAt(0).toUpperCase() + areaPriority.slice(1);
        const badgeSize = 24;
        
        // Create circular badge background
        const priorityBadge = new Circle({
          left: dynamicWidth - badgeSize - 4,
          top: dynamicHeight - badgeSize - 4,
          radius: badgeSize / 2,
          fill: priorityColor,
          stroke: '#ffffff',
          strokeWidth: 2,
          shadow: { color: 'rgba(0,0,0,0.25)', blur: 4, offsetX: 0, offsetY: 2 } as any,
        });
        
        // Priority letter (H, M, L, C)
        const priorityLetter = areaPriority === 'critical' ? 'C' : areaPriority.charAt(0).toUpperCase();
        const priorityText = new Text(priorityLetter, {
          left: dynamicWidth - badgeSize / 2 - 4,
          top: dynamicHeight - badgeSize / 2 - 4,
          fontSize: 11,
          fill: '#ffffff',
          fontFamily: 'Inter, system-ui, sans-serif',
          fontWeight: '800',
          originX: 'center',
          originY: 'center',
        });
        groupItems.push(priorityBadge, priorityText);
      }

      const group = new Group(groupItems, {
        left: existing ? existing.left : area.x,
        top: existing ? existing.top : area.y,
        selectable: !readOnly,
        hasControls: true,
        hasBorders: true,
        lockRotation: true,
      });

      (group as any).areaId = area.id;
      canvas.add(group);
      areasMapRef.current.set(area.id, group);
    });

    redrawConnections();
  }, [areas, readOnly, techCountByArea, priorityByArea, mode, redrawConnections, chipDimensionsByArea]);

  const handleCreateConnection = () => {
    if (!pendingConnection) return;

    const newConnection: CanvasConnection = {
      id: crypto.randomUUID(),
      fromTechId: pendingConnection.from,
      toTechId: pendingConnection.to,
      fromPort: pendingConnection.fromPort as any,
      toPort: pendingConnection.toPort as any,
      label: connectionLabel.trim() || undefined,
    };

    onConnectionsChange([...connections, newConnection]);
    setConnectionLabel('');
    setPendingConnection(null);
    setShowLabelDialog(false);
  };

  const handleDeleteConnection = (connId: string) => {
    onConnectionsChange(connections.filter(c => c.id !== connId));
  };

  const toggleConnectMode = () => {
    setIsConnecting(!isConnecting);
    setConnectionStart(null);
    if (tempLine && fabricRef.current) {
      fabricRef.current.remove(tempLine);
      setTempLine(null);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);

    const canvas = fabricRef.current;
    const container = containerRef.current;
    if (!canvas || !container || !onDropTechnology) return;

    try {
      const data = e.dataTransfer.getData('application/json');
      if (!data) return;

      const tech: TechnologyRepoItem = JSON.parse(data);
      const pointer = canvas.getPointer(e.nativeEvent as any);
      let dropX = pointer.x;
      let dropY = pointer.y;

      // Find target area
      let targetAreaId = '';
      let targetArea: CanvasAreaNode | undefined;
      areasMapRef.current.forEach((group, id) => {
        const bounds = group.getBoundingRect();
        if (dropX >= bounds.left && dropX <= bounds.left + bounds.width &&
            dropY >= bounds.top && dropY <= bounds.top + bounds.height) {
          targetAreaId = id;
          targetArea = areasRef.current.find(a => a.id === id);
        }
      });

      // If dropped into an area, calculate grid position
      if (targetArea) {
        const techsInArea = technologiesRef.current.filter(t => {
          const tArea = areasRef.current.find(a => a.name === t.functionalArea);
          return tArea?.id === targetAreaId;
        });
        
        const slotIndex = techsInArea.length; // New tech goes at end
        const dims = chipDimensionsByAreaRef.current[targetArea.id] || { width: DEFAULT_TECH_CHIP_WIDTH, height: DEFAULT_TECH_CHIP_HEIGHT, cols: 2 };
        const { width: chipWidth, height: chipHeight, cols } = dims;
        
        const row = Math.floor(slotIndex / cols);
        const col = slotIndex % cols;
        
        dropX = targetArea.x + CHIP_PADDING + col * (chipWidth + CHIP_PADDING);
        dropY = targetArea.y + AREA_HEADER_HEIGHT + CHIP_PADDING + row * (chipHeight + CHIP_PADDING);
      }

      onDropTechnology(tech, targetAreaId, dropX, dropY);
    } catch (err) {
      console.error('Drop error:', err);
    }
  }, [onDropTechnology]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    setIsDraggingOver(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDraggingOver(false);
  }, []);

  const handleZoom = (delta: number) => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    canvas.setZoom(Math.max(0.4, Math.min(2, canvas.getZoom() + delta)));
    canvas.renderAll();
  };

  const handleReset = () => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    canvas.setZoom(1);
    canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
    canvas.renderAll();
  };

  const handleDeleteSelected = () => {
    if (selectedTechId && onRemoveTechnology) {
      // Also remove connections to this tech
      onConnectionsChange(connections.filter(c => c.fromTechId !== selectedTechId && c.toTechId !== selectedTechId));
      onRemoveTechnology(selectedTechId);
      setSelectedTechId(null);
    }
  };

  const handleOpenAddArea = () => {
    setEditingArea(null);
    setNewAreaName('');
    setNewAreaLayer('adopt');
    setNewAreaColor('#fef9c3');
    setShowAreaDialog(true);
  };

  const handleOpenEditArea = (area: CanvasAreaNode) => {
    setEditingArea(area);
    setNewAreaName(area.name);
    setNewAreaLayer(area.layer);
    setNewAreaColor(area.color);
    setShowAreaDialog(true);
  };

  const handleSaveArea = () => {
    if (editingArea && onEditArea) {
      onEditArea(editingArea.id, {
        name: newAreaName,
        color: newAreaColor,
      });
    } else if (onAddArea) {
      onAddArea({
        name: newAreaName,
        layer: newAreaLayer,
        color: newAreaColor,
      });
    }
    setShowAreaDialog(false);
    setEditingArea(null);
  };

  const handleDeleteArea = (areaId: string) => {
    if (onDeleteArea && confirm('Delete this functional area?')) {
      onDeleteArea(areaId);
    }
  };

  const handleRelayoutTechs = () => {
    const repositioned = recalculateGridPositions(technologies);
    onTechnologiesChange(repositioned);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between p-2 bg-muted/30 border-b border-border">
        <div className="flex items-center gap-2">
          {onAddArea && !readOnly && (
            <Button variant="outline" size="sm" onClick={handleOpenAddArea}>
              <Plus className="w-4 h-4 mr-1" />
              Add Area
            </Button>
          )}
          <Button
            variant={isConnecting ? 'default' : 'outline'}
            size="sm"
            onClick={toggleConnectMode}
          >
            <Link2 className="w-4 h-4 mr-1" />
            {isConnecting ? 'Done Connecting' : 'Connect'}
          </Button>
          {!readOnly && technologies.length > 0 && (
            <Button variant="outline" size="sm" onClick={handleRelayoutTechs} title="Snap all technologies to grid layout within their areas">
              <LayoutGrid className="w-4 h-4 mr-1" />
              Re-layout
            </Button>
          )}
          {selectedTechId && !readOnly && (
            <Button variant="destructive" size="sm" onClick={handleDeleteSelected}>
              <Trash2 className="w-4 h-4 mr-1" />
              Remove
            </Button>
          )}
          {connections.length > 0 && (
            <span className="text-xs text-muted-foreground ml-2">
              {connections.length} connection{connections.length !== 1 ? 's' : ''}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={() => handleZoom(0.1)}>
            <ZoomIn className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => handleZoom(-0.1)}>
            <ZoomOut className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={handleReset}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Connection mode instructions */}
      {isConnecting && (
        <div className="bg-primary/10 text-primary text-sm px-4 py-2 text-center">
          Click a port on one technology, then click a port on another to create a connection
          {connectionStart && ' — Source selected, now click target port'}
        </div>
      )}

      {/* Canvas with context menu for areas */}
      <ContextMenu>
        <ContextMenuTrigger asChild>
          <div 
            ref={containerRef}
            className={cn(
              "flex-1 overflow-auto border rounded-b-xl transition-colors relative",
              isDraggingOver ? "bg-primary/5 border-primary" : "border-border"
            )}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
          >
            <canvas ref={canvasRef} />
            <div className="absolute bottom-4 left-4 bg-card/80 backdrop-blur-sm rounded-lg px-3 py-1.5 text-xs text-muted-foreground border border-border/50 pointer-events-none">
              Drag to pan • Scroll to pan • Use buttons to zoom
            </div>
          </div>
        </ContextMenuTrigger>
        <ContextMenuContent>
          {selectedAreaId && (
            <>
              <ContextMenuItem onClick={() => {
                const area = areas.find(a => a.id === selectedAreaId);
                if (area) handleOpenEditArea(area);
              }}>
                <Edit2 className="w-4 h-4 mr-2" />
                Edit Area
              </ContextMenuItem>
              <ContextMenuItem 
                onClick={() => handleDeleteArea(selectedAreaId)}
                className="text-destructive"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete Area
              </ContextMenuItem>
            </>
          )}
          {!selectedAreaId && onAddArea && (
            <ContextMenuItem onClick={handleOpenAddArea}>
              <Plus className="w-4 h-4 mr-2" />
              Add Functional Area
            </ContextMenuItem>
          )}
        </ContextMenuContent>
      </ContextMenu>

      {/* Connection Label Dialog */}
      <Dialog open={showLabelDialog} onOpenChange={setShowLabelDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Connection Label (Optional)</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Label</Label>
              <Input
                placeholder="e.g., Data Sync, API, Events"
                value={connectionLabel}
                onChange={(e) => setConnectionLabel(e.target.value)}
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => {
                setShowLabelDialog(false);
                setPendingConnection(null);
              }}>
                Skip
              </Button>
              <Button onClick={handleCreateConnection}>
                Create Connection
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add/Edit Area Dialog */}
      <Dialog open={showAreaDialog} onOpenChange={setShowAreaDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingArea ? 'Edit Functional Area' : 'Add Functional Area'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input
                placeholder="e.g., Analytics & Insights"
                value={newAreaName}
                onChange={(e) => setNewAreaName(e.target.value)}
              />
            </div>
            {!editingArea && (
              <div className="space-y-2">
                <Label>Layer</Label>
                <Select value={newAreaLayer} onValueChange={setNewAreaLayer}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="host">Host Environment</SelectItem>
                    <SelectItem value="build">Build Stack</SelectItem>
                    <SelectItem value="adopt">Adopt Stack</SelectItem>
                    <SelectItem value="growth">Growth Stack</SelectItem>
                    <SelectItem value="operations">Business Operations</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-2">
              <Label>Color</Label>
              <div className="flex gap-2">
                {['#fef9c3', '#fce7f3', '#dbeafe', '#d1fae5', '#fde68a', '#e9d5ff', '#fed7aa'].map(color => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setNewAreaColor(color)}
                    className={cn(
                      "w-8 h-8 rounded-lg border-2 transition-all",
                      newAreaColor === color ? "border-pendo-pink scale-110" : "border-transparent"
                    )}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setShowAreaDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveArea} disabled={!newAreaName.trim()}>
                {editingArea ? 'Save Changes' : 'Add Area'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

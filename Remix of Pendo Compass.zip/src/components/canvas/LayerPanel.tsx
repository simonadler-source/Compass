import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Layer, useLayers, useCreateLayer, useUpdateLayer, useDeleteLayer } from '@/hooks/useLayers';
import { Plus, MoreVertical, Edit2, Trash2, GripVertical, ChevronUp, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface LayerPanelProps {
  onLayerSelect?: (layer: Layer) => void;
  selectedLayerId?: string;
  readOnly?: boolean;
}

export function LayerPanel({ onLayerSelect, selectedLayerId, readOnly = false }: LayerPanelProps) {
  const { data: layers, isLoading } = useLayers();
  const createLayer = useCreateLayer();
  const updateLayer = useUpdateLayer();
  const deleteLayer = useDeleteLayer();
  
  const [showDialog, setShowDialog] = useState(false);
  const [editingLayer, setEditingLayer] = useState<Layer | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    label: '',
    subtitle: '',
    color: '#fef9c3',
    bg_color: '#fffbeb',
    line_color: '#eab308',
    height: 160,
  });

  const handleOpenCreate = () => {
    setEditingLayer(null);
    setFormData({
      name: '',
      label: '',
      subtitle: '',
      color: '#fef9c3',
      bg_color: '#fffbeb',
      line_color: '#eab308',
      height: 160,
    });
    setShowDialog(true);
  };

  const handleOpenEdit = (layer: Layer) => {
    setEditingLayer(layer);
    setFormData({
      name: layer.name,
      label: layer.label,
      subtitle: layer.subtitle || '',
      color: layer.color,
      bg_color: layer.bg_color,
      line_color: layer.line_color,
      height: layer.height,
    });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!formData.name.trim() || !formData.label.trim()) return;

    if (editingLayer) {
      await updateLayer.mutateAsync({
        id: editingLayer.id,
        name: formData.name.toLowerCase().replace(/\s+/g, '_'),
        label: formData.label,
        subtitle: formData.subtitle || null,
        color: formData.color,
        bg_color: formData.bg_color,
        line_color: formData.line_color,
        height: formData.height,
      });
    } else {
      await createLayer.mutateAsync({
        name: formData.name.toLowerCase().replace(/\s+/g, '_'),
        label: formData.label,
        subtitle: formData.subtitle || undefined,
        color: formData.color,
        bg_color: formData.bg_color,
        line_color: formData.line_color,
        height: formData.height,
        sort_order: (layers?.length || 0),
      });
    }
    setShowDialog(false);
  };

  const handleDelete = async (layer: Layer) => {
    if (confirm(`Delete layer "${layer.label}"? This may affect functional areas using this layer.`)) {
      await deleteLayer.mutateAsync(layer.id);
    }
  };

  const handleMoveUp = async (layer: Layer, index: number) => {
    if (index === 0 || !layers) return;
    const prevLayer = layers[index - 1];
    await Promise.all([
      updateLayer.mutateAsync({ id: layer.id, sort_order: prevLayer.sort_order }),
      updateLayer.mutateAsync({ id: prevLayer.id, sort_order: layer.sort_order }),
    ]);
  };

  const handleMoveDown = async (layer: Layer, index: number) => {
    if (!layers || index === layers.length - 1) return;
    const nextLayer = layers[index + 1];
    await Promise.all([
      updateLayer.mutateAsync({ id: layer.id, sort_order: nextLayer.sort_order }),
      updateLayer.mutateAsync({ id: nextLayer.id, sort_order: layer.sort_order }),
    ]);
  };

  const handleHeightChange = async (layer: Layer, delta: number) => {
    const newHeight = Math.max(80, Math.min(400, layer.height + delta));
    await updateLayer.mutateAsync({ id: layer.id, height: newHeight });
  };

  const colorPresets = [
    { color: '#fef3c7', bg: '#fffbeb', line: '#f59e0b' },
    { color: '#fde68a', bg: '#fef9c3', line: '#eab308' },
    { color: '#fed7aa', bg: '#ffedd5', line: '#f97316' },
    { color: '#fecaca', bg: '#fef2f2', line: '#ef4444' },
    { color: '#e9d5ff', bg: '#faf5ff', line: '#a855f7' },
    { color: '#dbeafe', bg: '#eff6ff', line: '#3b82f6' },
    { color: '#d1fae5', bg: '#ecfdf5', line: '#10b981' },
  ];

  if (isLoading) {
    return (
      <div className="p-4 flex items-center justify-center">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-3 border-b border-border">
        <h3 className="font-semibold text-sm text-foreground">Layers</h3>
        {!readOnly && (
          <Button variant="ghost" size="icon" onClick={handleOpenCreate}>
            <Plus className="w-4 h-4" />
          </Button>
        )}
      </div>

      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {layers?.map((layer, index) => (
            <div
              key={layer.id}
              className={cn(
                "group flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-colors",
                selectedLayerId === layer.id
                  ? "bg-primary/10 border border-primary/30"
                  : "hover:bg-muted/50"
              )}
              onClick={() => onLayerSelect?.(layer)}
            >
              {!readOnly && (
                <GripVertical className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 cursor-grab" />
              )}
              
              <div
                className="w-3 h-3 rounded-sm flex-shrink-0"
                style={{ backgroundColor: layer.color }}
              />
              
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{layer.label}</p>
                {layer.subtitle && (
                  <p className="text-xs text-muted-foreground truncate">{layer.subtitle}</p>
                )}
              </div>

              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <span>{layer.height}px</span>
              </div>

              {!readOnly && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 opacity-0 group-hover:opacity-100"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <MoreVertical className="w-3 h-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleOpenEdit(layer)}>
                      <Edit2 className="w-4 h-4 mr-2" />
                      Edit Layer
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleMoveUp(layer, index)} disabled={index === 0}>
                      <ChevronUp className="w-4 h-4 mr-2" />
                      Move Up
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleMoveDown(layer, index)} disabled={index === (layers?.length || 0) - 1}>
                      <ChevronDown className="w-4 h-4 mr-2" />
                      Move Down
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleHeightChange(layer, 20)}>
                      Increase Height
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleHeightChange(layer, -20)}>
                      Decrease Height
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => handleDelete(layer)}
                      className="text-destructive"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete Layer
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Add/Edit Layer Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingLayer ? 'Edit Layer' : 'Add Layer'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Name (ID)</Label>
                <Input
                  placeholder="e.g., analytics"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Display Label</Label>
                <Input
                  placeholder="e.g., ANALYTICS LAYER"
                  value={formData.label}
                  onChange={(e) => setFormData(prev => ({ ...prev, label: e.target.value }))}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Subtitle</Label>
              <Input
                placeholder="e.g., (Data & Insights)"
                value={formData.subtitle}
                onChange={(e) => setFormData(prev => ({ ...prev, subtitle: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <Label>Height (px)</Label>
              <Input
                type="number"
                min={80}
                max={400}
                value={formData.height}
                onChange={(e) => setFormData(prev => ({ ...prev, height: parseInt(e.target.value) || 160 }))}
              />
            </div>

            <div className="space-y-2">
              <Label>Color Theme</Label>
              <div className="flex gap-2 flex-wrap">
                {colorPresets.map((preset, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setFormData(prev => ({
                      ...prev,
                      color: preset.color,
                      bg_color: preset.bg,
                      line_color: preset.line,
                    }))}
                    className={cn(
                      "w-8 h-8 rounded-lg border-2 transition-all",
                      formData.color === preset.color ? "border-primary scale-110" : "border-transparent"
                    )}
                    style={{ backgroundColor: preset.color }}
                  />
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setShowDialog(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                disabled={!formData.name.trim() || !formData.label.trim()}
              >
                {editingLayer ? 'Save Changes' : 'Add Layer'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

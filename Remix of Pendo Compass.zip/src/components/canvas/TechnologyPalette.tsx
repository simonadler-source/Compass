import { useState, useMemo } from 'react';
import { Search, ChevronDown, ChevronRight, GripVertical, AlertTriangle, Plus, FileEdit } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useTechnologyRepository, TechnologyRepoItem } from '@/hooks/useTechnologyRepository';
import { cn } from '@/lib/utils';

interface TechnologyPaletteProps {
  onDragStart: (tech: TechnologyRepoItem) => void;
  onAddCustom?: () => void;
}

const LAYER_ORDER = ['host', 'build', 'adopt', 'growth', 'operations'];
const LAYER_LABELS: Record<string, string> = {
  host: 'Host Environment',
  build: 'Build Stack',
  adopt: 'Adopt Stack',
  growth: 'Growth Stack',
  operations: 'Business Operations',
};

export function TechnologyPalette({ onDragStart, onAddCustom }: TechnologyPaletteProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedAreas, setExpandedAreas] = useState<Set<string>>(new Set(['Analytics & Insights', 'Digital Adoption & Guides', 'CRM']));
  
  const { data: technologies, isLoading } = useTechnologyRepository();

  // Group technologies by functional area, then by layer
  const groupedTechs = useMemo(() => {
    if (!technologies) return {};

    const filtered = searchQuery
      ? technologies.filter(t => 
          t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          t.functional_area.toLowerCase().includes(searchQuery.toLowerCase()) ||
          t.capabilities?.some(c => c.toLowerCase().includes(searchQuery.toLowerCase()))
        )
      : technologies;

    // Group by layer first, then by functional area
    const byLayer: Record<string, Record<string, TechnologyRepoItem[]>> = {};
    
    filtered.forEach(tech => {
      if (!byLayer[tech.layer]) {
        byLayer[tech.layer] = {};
      }
      if (!byLayer[tech.layer][tech.functional_area]) {
        byLayer[tech.layer][tech.functional_area] = [];
      }
      byLayer[tech.layer][tech.functional_area].push(tech);
    });

    return byLayer;
  }, [technologies, searchQuery]);

  const toggleArea = (area: string) => {
    setExpandedAreas(prev => {
      const next = new Set(prev);
      if (next.has(area)) {
        next.delete(area);
      } else {
        next.add(area);
      }
      return next;
    });
  };

  const handleDragStart = (e: React.DragEvent, tech: TechnologyRepoItem) => {
    e.dataTransfer.setData('application/json', JSON.stringify(tech));
    e.dataTransfer.effectAllowed = 'copy';
    onDragStart(tech);
  };

  return (
    <div className="h-full flex flex-col bg-card border-r border-border">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold text-foreground mb-3">Technology Palette</h3>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search technologies..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        {onAddCustom && (
          <Button variant="outline" size="sm" className="w-full mt-3" onClick={onAddCustom}>
            <Plus className="w-4 h-4 mr-1" />
            Add Custom Technology
          </Button>
        )}
      </div>

      {/* Technology List */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {isLoading ? (
            <div className="p-4 text-center text-muted-foreground text-sm">
              Loading technologies...
            </div>
          ) : (
            LAYER_ORDER.map(layer => {
              const layerAreas = groupedTechs[layer];
              if (!layerAreas || Object.keys(layerAreas).length === 0) return null;

              return (
                <div key={layer} className="mb-4">
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-2 py-1 mb-1">
                    {LAYER_LABELS[layer]}
                  </div>
                  
                  {Object.entries(layerAreas).map(([area, techs]) => (
                    <Collapsible
                      key={area}
                      open={expandedAreas.has(area) || !!searchQuery}
                      onOpenChange={() => toggleArea(area)}
                    >
                      <CollapsibleTrigger className="flex items-center gap-2 w-full p-2 hover:bg-muted/50 rounded-lg text-left">
                        {expandedAreas.has(area) || searchQuery ? (
                          <ChevronDown className="w-4 h-4 text-muted-foreground" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-muted-foreground" />
                        )}
                        <span className="text-sm font-medium text-foreground flex-1">{area}</span>
                        <Badge variant="secondary" className="text-xs">
                          {techs.length}
                        </Badge>
                      </CollapsibleTrigger>
                      
                      <CollapsibleContent>
                        <div className="ml-2 pl-4 border-l border-border/50 space-y-1 py-1">
                          {techs.map(tech => (
                            <div
                              key={tech.id}
                              draggable
                              onDragStart={(e) => handleDragStart(e, tech)}
                            className={cn(
                              "flex items-center gap-2 px-3 py-2 rounded-lg cursor-grab active:cursor-grabbing",
                              "transition-all group border-2",
                              "bg-secondary/80 hover:bg-secondary",
                              "border-pendo-pink/60 hover:border-pendo-pink",
                              tech.status === 'draft' && "border-dashed border-amber-500"
                            )}
                          >
                            <GripVertical className="w-3 h-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                            
                            {tech.logo_url ? (
                              <img 
                                src={tech.logo_url} 
                                alt={tech.name}
                                className="w-5 h-5 object-contain rounded"
                              />
                            ) : (
                              <div className="w-5 h-5 bg-muted rounded flex items-center justify-center text-[10px] font-bold text-muted-foreground">
                                {tech.name.charAt(0)}
                              </div>
                            )}
                            
                            <span className="text-sm flex-1 truncate text-foreground font-medium">{tech.name}</span>
                              
                              {tech.status === 'draft' && (
                                <span title="Draft - needs review">
                                  <FileEdit className="w-3.5 h-3.5 text-amber-500" />
                                </span>
                              )}
                              
                              {tech.is_competitor && (
                                <span title="Competitor">
                                  <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  ))}
                </div>
              );
            })
          )}

          {!isLoading && technologies?.length === 0 && (
            <div className="p-4 text-center text-muted-foreground text-sm">
              No technologies in repository
            </div>
          )}

          {!isLoading && searchQuery && Object.keys(groupedTechs).length === 0 && (
            <div className="p-4 text-center text-muted-foreground text-sm">
              No technologies match "{searchQuery}"
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Legend */}
      <div className="p-3 border-t border-border text-xs text-muted-foreground space-y-1">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-3 h-3 text-red-500" />
          <span>= Competitor product</span>
        </div>
        <div className="flex items-center gap-2">
          <FileEdit className="w-3 h-3 text-amber-500" />
          <span>= Draft (needs review)</span>
        </div>
        <p className="mt-1">Drag technologies onto the canvas</p>
      </div>
    </div>
  );
}

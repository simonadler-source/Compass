import { useEffect, useRef, useState, useCallback } from 'react';
import { Canvas as FabricCanvas, Rect, Text, Group, Line, Path, FabricObject } from 'fabric';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Trash2, Link2, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';

// Extend FabricObject to include custom data
declare module 'fabric' {
  interface FabricObject {
    nodeId?: string;
  }
}

export interface CanvasNode {
  id: string;
  name: string;
  category: string;
  layer: string;
  x: number;
  y: number;
  tools?: string;
  issues?: string;
  persona?: string;
  isPendo?: boolean;
  status?: 'pending' | 'confirmed' | 'rejected';
}

export interface CanvasConnection {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  label: string;
}

interface VisualArchitectureCanvasProps {
  nodes: CanvasNode[];
  connections: CanvasConnection[];
  onNodesChange: (nodes: CanvasNode[]) => void;
  onConnectionsChange: (connections: CanvasConnection[]) => void;
  onAddNode?: (node: Omit<CanvasNode, 'id' | 'x' | 'y'>) => void;
  onRemoveNode?: (nodeId: string) => void;
  readOnly?: boolean;
  height?: number;
}

const LAYERS = ['host', 'build', 'adopt', 'growth', 'ops'] as const;

// Pendo-style layer configuration
const LAYER_CONFIG: Record<string, { 
  label: string; 
  subtitle: string;
  color: string; 
  bgColor: string;
  textColor: string;
}> = {
  host: { 
    label: 'LAYER 1: HOST ENVIRONMENT', 
    subtitle: '(Where Pendo Lives)',
    color: '#fef3c7', 
    bgColor: '#fef9e7',
    textColor: '#92400e'
  },
  build: { 
    label: 'LAYER 2: BUILD STACK', 
    subtitle: '(Product & Engineering)',
    color: '#fde68a', 
    bgColor: '#fef3c7',
    textColor: '#92400e'
  },
  adopt: { 
    label: 'LAYER 3: ADOPT STACK', 
    subtitle: '(Enablement & Support)',
    color: '#fed7aa', 
    bgColor: '#ffedd5',
    textColor: '#9a3412'
  },
  growth: { 
    label: 'LAYER 4: GROWTH STACK', 
    subtitle: '(Revenue & CRM)',
    color: '#fecaca', 
    bgColor: '#fef2f2',
    textColor: '#991b1b'
  },
  ops: { 
    label: 'LAYER 5: BUSINESS OPS & STRATEGY', 
    subtitle: '(C-Suite & Ops)',
    color: '#e9d5ff', 
    bgColor: '#faf5ff',
    textColor: '#6b21a8'
  },
};

// Category colors matching Pendo diagram
const CATEGORY_COLORS: Record<string, { fill: string; stroke: string; text: string }> = {
  default: { fill: '#fef9c3', stroke: '#eab308', text: '#713f12' }, // Yellow
  pendo: { fill: '#bbf7d0', stroke: '#22c55e', text: '#14532d' }, // Green (Pendo products)
  integration: { fill: '#e9d5ff', stroke: '#a855f7', text: '#581c87' }, // Purple (Pendo integrations)
  pending: { fill: '#fed7aa', stroke: '#f97316', text: '#9a3412' }, // Orange (pending review)
  analytics: { fill: '#fef9c3', stroke: '#eab308', text: '#713f12' },
  crm: { fill: '#fef9c3', stroke: '#eab308', text: '#713f12' },
  platform: { fill: '#fed7aa', stroke: '#f97316', text: '#9a3412' },
  data: { fill: '#fecaca', stroke: '#ef4444', text: '#7f1d1d' },
};

const LAYER_HEIGHT = 140;
const NODE_WIDTH = 180;
const NODE_HEIGHT = 90;
const LEFT_MARGIN = 180;
const PADDING = 20;

export function VisualArchitectureCanvas({
  nodes,
  connections,
  onNodesChange,
  onConnectionsChange,
  onAddNode,
  onRemoveNode,
  readOnly = false,
  height = 750,
}: VisualArchitectureCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const fabricRef = useRef<FabricCanvas | null>(null);
  const nodesMapRef = useRef<Map<string, Group>>(new Map());
  const connectionsMapRef = useRef<Map<string, Group>>(new Map());

  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionStart, setConnectionStart] = useState<string | null>(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showConnectionDialog, setShowConnectionDialog] = useState(false);
  const [pendingConnection, setPendingConnection] = useState<{ from: string; to: string } | null>(null);
  const [newNodeName, setNewNodeName] = useState('');
  const [newNodeCategory, setNewNodeCategory] = useState('');
  const [newNodeLayer, setNewNodeLayer] = useState('adopt');
  const [newNodeTools, setNewNodeTools] = useState('');
  const [newNodeIssues, setNewNodeIssues] = useState('');
  const [newNodePersona, setNewNodePersona] = useState('');
  const [newNodeIsPendo, setNewNodeIsPendo] = useState(false);
  const [connectionLabel, setConnectionLabel] = useState('');
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);

  // Initialize canvas
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const width = containerRef.current.offsetWidth || 1200;
    
    const canvas = new FabricCanvas(canvasRef.current, {
      width,
      height,
      backgroundColor: '#f8fafc',
      selection: !readOnly,
    });

    fabricRef.current = canvas;

    // Draw layer backgrounds
    drawLayers(canvas, width);

    // Handle object movement
    canvas.on('object:moving', (e) => {
      const obj = e.target as any;
      if (!obj || !obj.nodeId) return;

      // Snap to layer
      const layerIndex = Math.round((obj.top || 0) / LAYER_HEIGHT);
      const clampedIndex = Math.max(0, Math.min(LAYERS.length - 1, layerIndex));

      // Clamp to canvas bounds
      const left = Math.max(LEFT_MARGIN + PADDING, Math.min((obj.left || 0), width - NODE_WIDTH - PADDING));
      const top = clampedIndex * LAYER_HEIGHT + (LAYER_HEIGHT - NODE_HEIGHT) / 2;

      obj.set({ left, top });
      obj.setCoords();

      // Update connections
      updateConnectionLines();
    });

    canvas.on('object:modified', (e) => {
      const obj = e.target as any;
      if (!obj || !obj.nodeId) return;

      const layerIndex = Math.round((obj.top || 0) / LAYER_HEIGHT);
      const clampedIndex = Math.max(0, Math.min(LAYERS.length - 1, layerIndex));
      const newLayer = LAYERS[clampedIndex];

      const updatedNodes = nodes.map(n =>
        n.id === obj.nodeId
          ? { ...n, x: obj.left || 0, y: obj.top || 0, layer: newLayer }
          : n
      );
      onNodesChange(updatedNodes);
    });

    canvas.on('selection:created', (e) => {
      const selected = e.selected?.[0] as any;
      if (selected?.nodeId) {
        setSelectedNodeId(selected.nodeId);
        
        if (isConnecting && connectionStart && connectionStart !== selected.nodeId) {
          setPendingConnection({ from: connectionStart, to: selected.nodeId });
          setShowConnectionDialog(true);
          setIsConnecting(false);
          setConnectionStart(null);
        } else if (isConnecting) {
          setConnectionStart(selected.nodeId);
        }
      }
    });

    canvas.on('selection:cleared', () => {
      setSelectedNodeId(null);
    });

    return () => {
      canvas.dispose();
      fabricRef.current = null;
    };
  }, [height, readOnly]);

  // Draw layer backgrounds with left labels
  const drawLayers = (canvas: FabricCanvas, width: number) => {
    LAYERS.forEach((layer, index) => {
      const config = LAYER_CONFIG[layer];
      const y = index * LAYER_HEIGHT;

      // Layer background
      const bg = new Rect({
        left: 0,
        top: y,
        width,
        height: LAYER_HEIGHT,
        fill: config.bgColor,
        selectable: false,
        evented: false,
      });
      canvas.add(bg);

      // Left label background
      const labelBg = new Rect({
        left: 0,
        top: y,
        width: LEFT_MARGIN - 10,
        height: LAYER_HEIGHT,
        fill: config.color,
        selectable: false,
        evented: false,
        rx: 0,
        ry: 0,
      });
      canvas.add(labelBg);

      // Layer main label
      const labelText = new Text(config.label.split(':')[0] + ':', {
        left: 10,
        top: y + 20,
        fontSize: 11,
        fill: config.textColor,
        fontFamily: 'Inter, system-ui, sans-serif',
        fontWeight: '700',
        selectable: false,
        evented: false,
      });
      canvas.add(labelText);

      // Layer name
      const layerName = config.label.split(':')[1]?.trim() || '';
      const nameText = new Text(layerName, {
        left: 10,
        top: y + 38,
        fontSize: 12,
        fill: config.textColor,
        fontFamily: 'Inter, system-ui, sans-serif',
        fontWeight: '800',
        selectable: false,
        evented: false,
      });
      canvas.add(nameText);

      // Subtitle
      const subtitleText = new Text(config.subtitle, {
        left: 10,
        top: y + 58,
        fontSize: 10,
        fill: config.textColor,
        fontFamily: 'Inter, system-ui, sans-serif',
        fontStyle: 'italic',
        selectable: false,
        evented: false,
      });
      canvas.add(subtitleText);

      // Layer divider
      if (index < LAYERS.length - 1) {
        const line = new Line([0, y + LAYER_HEIGHT, width, y + LAYER_HEIGHT], {
          stroke: '#e2e8f0',
          strokeWidth: 1,
          selectable: false,
          evented: false,
        });
        canvas.add(line);
      }
    });
  };

  // Get color scheme for node
  const getNodeColors = (node: CanvasNode) => {
    // Pending review nodes get special orange styling
    if (node.status === 'pending') {
      return CATEGORY_COLORS.pending;
    }
    if (node.isPendo) {
      return CATEGORY_COLORS.pendo;
    }
    if (node.category?.toLowerCase().includes('pendo')) {
      return CATEGORY_COLORS.integration;
    }
    const categoryKey = node.category?.toLowerCase().replace(/\s+/g, '') || 'default';
    return CATEGORY_COLORS[categoryKey] || CATEGORY_COLORS.default;
  };

  // Render nodes
  useEffect(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;

    // Remove old nodes
    nodesMapRef.current.forEach((group, id) => {
      if (!nodes.find(n => n.id === id)) {
        canvas.remove(group);
        nodesMapRef.current.delete(id);
      }
    });

    // Add/update nodes
    nodes.forEach(node => {
      const existing = nodesMapRef.current.get(node.id);
      
      if (existing) {
        if (existing.left !== node.x || existing.top !== node.y) {
          existing.set({ left: node.x, top: node.y });
          existing.setCoords();
        }
      } else {
        const colors = getNodeColors(node);
        const layerIndex = LAYERS.indexOf(node.layer as typeof LAYERS[number]);
        const y = node.y || (layerIndex >= 0 ? layerIndex * LAYER_HEIGHT + (LAYER_HEIGHT - NODE_HEIGHT) / 2 : 280);
        const x = node.x || LEFT_MARGIN + PADDING + Math.random() * 300;

        // Main box
        const rect = new Rect({
          width: NODE_WIDTH,
          height: NODE_HEIGHT,
          fill: colors.fill,
          stroke: colors.stroke,
          strokeWidth: 2,
          rx: 6,
          ry: 6,
          shadow: {
            color: 'rgba(0,0,0,0.1)',
            blur: 8,
            offsetX: 2,
            offsetY: 2,
          } as any,
        });

        // Title (bold)
        const titleText = new Text(node.name, {
          fontSize: 12,
          fill: colors.text,
          fontFamily: 'Inter, system-ui, sans-serif',
          fontWeight: '700',
          left: NODE_WIDTH / 2,
          top: 12,
          originX: 'center',
        });

        // Category subtitle
        const categoryText = new Text(`(${node.category})`, {
          fontSize: 9,
          fill: colors.text,
          fontFamily: 'Inter, system-ui, sans-serif',
          left: NODE_WIDTH / 2,
          top: 28,
          originX: 'center',
          opacity: 0.8,
        });

        const groupItems: FabricObject[] = [rect, titleText, categoryText];

        // Tools line if present
        if (node.tools) {
          const toolsText = new Text(`Tool: ${node.tools}`, {
            fontSize: 8,
            fill: colors.text,
            fontFamily: 'Inter, system-ui, sans-serif',
            left: 8,
            top: 45,
            opacity: 0.9,
          });
          groupItems.push(toolsText);
        }

        // Issues/Status line if present
        if (node.issues) {
          const issuesText = new Text(`Status: ${node.issues}`, {
            fontSize: 8,
            fill: colors.text,
            fontFamily: 'Inter, system-ui, sans-serif',
            left: 8,
            top: 58,
            opacity: 0.7,
          });
          groupItems.push(issuesText);
        }

        const group = new Group(groupItems, {
          left: x,
          top: y,
          selectable: !readOnly,
          hasControls: false,
          hasBorders: true,
          lockRotation: true,
          lockScalingX: true,
          lockScalingY: true,
        });
        
        (group as any).nodeId = node.id;

        // Add persona label above if present
        if (node.persona) {
          const personaText = new Text(node.persona, {
            left: x + NODE_WIDTH / 2,
            top: y - 16,
            fontSize: 9,
            fill: '#64748b',
            fontFamily: 'Inter, system-ui, sans-serif',
            fontStyle: 'italic',
            originX: 'center',
            selectable: false,
            evented: false,
          });
          canvas.add(personaText);
        }

        canvas.add(group);
        nodesMapRef.current.set(node.id, group);
      }
    });

    canvas.renderAll();
    updateConnectionLines();
  }, [nodes, readOnly]);

  // Update connection lines with curved arrows
  const updateConnectionLines = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;

    // Remove old connections
    connectionsMapRef.current.forEach((group) => {
      canvas.remove(group);
    });
    connectionsMapRef.current.clear();

    // Draw connections
    connections.forEach(conn => {
      const fromNode = nodesMapRef.current.get(conn.fromNodeId);
      const toNode = nodesMapRef.current.get(conn.toNodeId);
      
      if (!fromNode || !toNode) return;

      const fromX = (fromNode.left || 0) + NODE_WIDTH / 2;
      const fromY = (fromNode.top || 0) + NODE_HEIGHT / 2;
      const toX = (toNode.left || 0) + NODE_WIDTH / 2;
      const toY = (toNode.top || 0) + NODE_HEIGHT / 2;

      // Draw curved path
      const midX = (fromX + toX) / 2;
      const midY = (fromY + toY) / 2;
      const controlOffset = Math.abs(toY - fromY) * 0.3;
      
      const pathData = `M ${fromX} ${fromY} Q ${midX + controlOffset} ${midY} ${toX} ${toY}`;
      
      const path = new Path(pathData, {
        stroke: '#a855f7',
        strokeWidth: 3,
        fill: '',
        selectable: false,
        evented: false,
      });
      canvas.add(path);

      // Arrow head
      const angle = Math.atan2(toY - midY, toX - midX);
      const arrowLength = 12;
      const arrowX = toX - Math.cos(angle) * 30;
      const arrowY = toY - Math.sin(angle) * 30;

      const arrow1 = new Line([
        arrowX, arrowY,
        arrowX - arrowLength * Math.cos(angle - Math.PI / 6),
        arrowY - arrowLength * Math.sin(angle - Math.PI / 6),
      ], {
        stroke: '#a855f7',
        strokeWidth: 3,
        selectable: false,
        evented: false,
      });

      const arrow2 = new Line([
        arrowX, arrowY,
        arrowX - arrowLength * Math.cos(angle + Math.PI / 6),
        arrowY - arrowLength * Math.sin(angle + Math.PI / 6),
      ], {
        stroke: '#a855f7',
        strokeWidth: 3,
        selectable: false,
        evented: false,
      });

      canvas.add(arrow1);
      canvas.add(arrow2);

      // Label on connection
      if (conn.label) {
        const labelBg = new Rect({
          left: midX - 50,
          top: midY - 12,
          width: 100,
          height: 24,
          fill: '#ffffff',
          stroke: '#a855f7',
          strokeWidth: 1,
          rx: 4,
          ry: 4,
          selectable: false,
          evented: false,
        });

        const labelText = new Text(conn.label, {
          left: midX,
          top: midY,
          fontSize: 9,
          fill: '#6b21a8',
          fontFamily: 'Inter, system-ui, sans-serif',
          fontWeight: '500',
          originX: 'center',
          originY: 'center',
          selectable: false,
          evented: false,
        });

        canvas.add(labelBg);
        canvas.add(labelText);
      }

      connectionsMapRef.current.set(conn.id, path as any);
    });

    // Bring nodes to front
    nodesMapRef.current.forEach(group => {
      canvas.bringObjectToFront(group);
    });

    canvas.renderAll();
  }, [connections]);

  useEffect(() => {
    updateConnectionLines();
  }, [connections, updateConnectionLines]);

  const handleAddNode = () => {
    if (!newNodeName.trim() || !onAddNode) return;
    
    onAddNode({
      name: newNodeName.trim(),
      category: newNodeCategory.trim() || 'Technology',
      layer: newNodeLayer,
      tools: newNodeTools.trim() || undefined,
      issues: newNodeIssues.trim() || undefined,
      persona: newNodePersona.trim() || undefined,
      isPendo: newNodeIsPendo,
    });

    // Reset form
    setNewNodeName('');
    setNewNodeCategory('');
    setNewNodeLayer('adopt');
    setNewNodeTools('');
    setNewNodeIssues('');
    setNewNodePersona('');
    setNewNodeIsPendo(false);
    setShowAddDialog(false);
  };

  const handleCreateConnection = () => {
    if (!pendingConnection) return;

    const newConnection: CanvasConnection = {
      id: crypto.randomUUID(),
      fromNodeId: pendingConnection.from,
      toNodeId: pendingConnection.to,
      label: connectionLabel.trim(),
    };

    onConnectionsChange([...connections, newConnection]);
    setConnectionLabel('');
    setPendingConnection(null);
    setShowConnectionDialog(false);
  };

  const handleDeleteSelected = () => {
    if (!selectedNodeId || !onRemoveNode) return;
    
    const updatedConnections = connections.filter(
      c => c.fromNodeId !== selectedNodeId && c.toNodeId !== selectedNodeId
    );
    onConnectionsChange(updatedConnections);
    onRemoveNode(selectedNodeId);
    setSelectedNodeId(null);
  };

  const handleZoom = (delta: number) => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    
    const zoom = canvas.getZoom() + delta;
    canvas.setZoom(Math.max(0.5, Math.min(2, zoom)));
    canvas.renderAll();
  };

  const handleReset = () => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    
    canvas.setZoom(1);
    canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
    canvas.renderAll();
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      {!readOnly && (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowAddDialog(true)}>
              <Plus className="w-4 h-4 mr-1" />
              Add Technology
            </Button>
            <Button
              variant={isConnecting ? 'default' : 'outline'}
              size="sm"
              onClick={() => {
                setIsConnecting(!isConnecting);
                setConnectionStart(null);
              }}
            >
              <Link2 className="w-4 h-4 mr-1" />
              {isConnecting ? 'Cancel' : 'Connect'}
            </Button>
            {selectedNodeId && (
              <Button variant="destructive" size="sm" onClick={handleDeleteSelected}>
                <Trash2 className="w-4 h-4 mr-1" />
                Delete
              </Button>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => handleZoom(0.1)}>
              <ZoomIn className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => handleZoom(-0.1)}>
              <ZoomOut className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={handleReset}>
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Instructions */}
      {isConnecting && (
        <div className="text-sm text-primary bg-primary/10 px-4 py-2 rounded-lg">
          Click a source node, then click a target node to create a connection
          {connectionStart && ' — Source selected, now click target'}
        </div>
      )}

      {/* Canvas */}
      <div 
        ref={containerRef}
        className="border border-border rounded-xl overflow-hidden shadow-lg"
      >
        <canvas ref={canvasRef} />
      </div>

      {/* Add Node Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add Technology Block</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Name *</Label>
              <Input
                placeholder="e.g., Analytics & Insights, CRM"
                value={newNodeName}
                onChange={(e) => setNewNodeName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Input
                placeholder="e.g., Customer Source of Truth"
                value={newNodeCategory}
                onChange={(e) => setNewNodeCategory(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Layer</Label>
              <Select value={newNodeLayer} onValueChange={setNewNodeLayer}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LAYERS.map(layer => (
                    <SelectItem key={layer} value={layer}>
                      {LAYER_CONFIG[layer].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Tools (optional)</Label>
              <Input
                placeholder="e.g., Salesforce, HubSpot"
                value={newNodeTools}
                onChange={(e) => setNewNodeTools(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Status/Issues (optional)</Label>
              <Textarea
                placeholder="e.g., Essential business system"
                value={newNodeIssues}
                onChange={(e) => setNewNodeIssues(e.target.value)}
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label>Persona (optional)</Label>
              <Input
                placeholder="e.g., Product Owner, Data Analyst"
                value={newNodePersona}
                onChange={(e) => setNewNodePersona(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="isPendo"
                checked={newNodeIsPendo}
                onChange={(e) => setNewNodeIsPendo(e.target.checked)}
                className="rounded border-border"
              />
              <Label htmlFor="isPendo" className="text-sm cursor-pointer">
                This is a Pendo product (green styling)
              </Label>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddNode} disabled={!newNodeName.trim()}>
                Add Block
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Connection Label Dialog */}
      <Dialog open={showConnectionDialog} onOpenChange={setShowConnectionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Connection Label</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Connection Label</Label>
              <Input
                placeholder="e.g., Two-Way Sync, API Integration, Data Flow"
                value={connectionLabel}
                onChange={(e) => setConnectionLabel(e.target.value)}
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => {
                setShowConnectionDialog(false);
                setPendingConnection(null);
              }}>
                Cancel
              </Button>
              <Button onClick={handleCreateConnection}>
                Create Connection
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

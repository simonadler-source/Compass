import { useState } from 'react';
import { CEPOpportunity } from '@/hooks/useCEPOpportunities';
import { CEPSimpleTimeline } from './CEPSimpleTimeline';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { SalesforceIcon } from '@/components/icons/SalesforceIcon';
import { cn } from '@/lib/utils';
import { gateway } from '@/lib/apiGateway';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { format, formatDistanceToNow } from 'date-fns';
import { 
  AlertTriangle, 
  Building2, 
  User, 
  Users, 
  ChevronRight,
  Clock,
  Target,
  Presentation,
  FlaskConical,
  RefreshCw,
  Mic,
  ExternalLink,
} from 'lucide-react';

const SALESFORCE_BASE_URL = 'https://pendo.lightning.force.com/lightning/r/Opportunity';

// Sales stage options for dropdown - aligned with OpportunityDetailView
const SALES_STAGE_OPTIONS = [
  { value: 'stage_0', label: 'Stage 0: Qualification' },
  { value: 'stage_1', label: 'Stage 1: Discovery' },
  { value: 'stage_2', label: 'Stage 2: Solution' },
  { value: 'stage_3', label: 'Stage 3: Proof' },
  { value: 'stage_4', label: 'Stage 4: Negotiate' },
  { value: 'stage_5_sales_won', label: 'Stage 5: Sales Won' },
  { value: 'stage_6_closed_won', label: 'Stage 6: Closed Won' },
  { value: 'stage_7_closed_lost', label: 'Stage 7: Closed Lost' },
];

// Pre-sales stage options - aligned with OpportunityDetailView
const PRE_SALES_STAGE_OPTIONS = [
  { value: 'Discovery', label: 'Discovery' },
  { value: 'Demo', label: 'Demo' },
  { value: 'Proof - Scoping', label: 'Proof - Scoping' },
  { value: 'Proof', label: 'Proof' },
  { value: 'Technical Win', label: 'Technical Win' },
  { value: 'Technical Loss', label: 'Technical Loss' },
  { value: 'Unqualified', label: 'Unqualified' },
];

interface CEPSimpleCardProps {
  opportunity: CEPOpportunity;
  showAccountInfo?: boolean;
}

function extractName(email: string | null): string {
  if (!email) return '—';
  const localPart = email.split('@')[0];
  if (localPart.includes('.')) {
    return localPart
      .split('.')
      .map(part => part.charAt(0).toUpperCase() + part.slice(1))
      .join(' ');
  }
  return localPart.charAt(0).toUpperCase() + localPart.slice(1);
}

export function CEPSimpleCard({ opportunity, showAccountInfo = true }: CEPSimpleCardProps) {
  const queryClient = useQueryClient();
  const [isUpdating, setIsUpdating] = useState(false);
  
  const hasGaps = opportunity.missingExitCriteria.length > 0 || Math.abs(opportunity.stageDiscrepancy) >= 2;

  // Determine which signal types are detected
  const detectedTypes = new Set(opportunity.signals.map(s => s.type));
  const hasDemo = detectedTypes.has('demo');
  const hasReverseDemo = detectedTypes.has('reverse_demo');
  const hasEvaluation = detectedTypes.has('evaluation');

  // Open opportunity in a new tab
  const openOpportunityInNewTab = () => {
    const url = `/accounts/${opportunity.accountId}?opportunityId=${opportunity.id}`;
    window.open(url, '_blank');
  };

  const handleSalesStageChange = async (value: string) => {
    setIsUpdating(true);
    try {
      const response = await gateway.from('opportunities')
        .update({ sales_stage: value })
        .eq('id', opportunity.id)
        .execute();
      
      if (response.error) throw response.error;
      
      queryClient.invalidateQueries({ queryKey: ['cep-opportunities'] });
      toast.success('Sales stage updated');
    } catch (error) {
      toast.error('Failed to update sales stage');
    } finally {
      setIsUpdating(false);
    }
  };

  const handlePreSalesStageChange = async (value: string) => {
    setIsUpdating(true);
    try {
      const response = await gateway.from('opportunities')
        .update({ pre_sales_stage: value })
        .eq('id', opportunity.id)
        .execute();
      
      if (response.error) throw response.error;
      
      queryClient.invalidateQueries({ queryKey: ['cep-opportunities'] });
      toast.success('Pre-Sales stage updated');
    } catch (error) {
      toast.error('Failed to update pre-sales stage');
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <>
      <div className={cn(
        'bg-card border rounded-lg p-4 hover:border-primary/50 transition-colors',
        hasGaps && !opportunity.isClosedWon && !opportunity.isClosedLost && 'border-amber-500/50 bg-amber-500/5',
        opportunity.isClosedWon && 'border-emerald-600/40 bg-emerald-600/5',
        opportunity.isClosedLost && 'border-rose-600/40 bg-rose-600/5',
        isUpdating && 'opacity-70 pointer-events-none',
      )}>
        {/* Header Row */}
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <button 
              onClick={openOpportunityInNewTab}
              className="font-semibold text-primary hover:underline truncate text-left"
            >
              {opportunity.name}
            </button>
            
            {opportunity.salesforceOpportunityId && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <a
                      href={`${SALESFORCE_BASE_URL}/${opportunity.salesforceOpportunityId}/view`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center p-1 rounded hover:bg-muted transition-colors shrink-0"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <SalesforceIcon className="h-4 w-4" />
                    </a>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Open in Salesforce</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            
            {hasGaps && (
              <Badge variant="outline" className="shrink-0 bg-orange-600 text-white border-orange-700 h-5 text-[10px] font-semibold shadow-sm">
                <AlertTriangle className="w-3 h-3 mr-1" />
                Gap
              </Badge>
            )}

            {/* Signal indicators */}
            <div className="flex items-center gap-1.5 ml-2">
              <div className={cn(
                'w-5 h-5 rounded-full flex items-center justify-center border',
                hasDemo 
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-500' 
                  : 'bg-muted border-muted-foreground/20 text-muted-foreground/40'
              )}>
                <Target className="w-3 h-3" />
              </div>
              <div className={cn(
                'w-5 h-5 rounded-full flex items-center justify-center border',
                hasReverseDemo 
                  ? 'bg-blue-500/20 border-blue-500/40 text-blue-500' 
                  : 'bg-muted border-muted-foreground/20 text-muted-foreground/40'
              )}>
                <Presentation className="w-3 h-3" />
              </div>
              <div className={cn(
                'w-5 h-5 rounded-full flex items-center justify-center border',
                hasEvaluation 
                  ? 'bg-purple-500/20 border-purple-500/40 text-purple-600' 
                  : 'bg-muted border-muted-foreground/20 text-muted-foreground/40'
              )}>
                <FlaskConical className="w-3 h-3" />
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3 shrink-0">
            {/* Stage dropdowns */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-muted-foreground">Sales:</span>
              <Select value={opportunity.salesStage || ''} onValueChange={handleSalesStageChange}>
                <SelectTrigger className="h-6 text-xs px-2 min-w-[70px] w-auto">
                  <SelectValue placeholder="Set" />
                </SelectTrigger>
                <SelectContent>
                  {SALES_STAGE_OPTIONS.map(opt => (
                    <SelectItem key={opt.value} value={opt.value} className="text-xs">
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-muted-foreground">Pre-Sales:</span>
              <Select value={opportunity.preSalesStage || ''} onValueChange={handlePreSalesStageChange}>
                <SelectTrigger className={cn(
                  "h-6 text-xs px-2 min-w-[90px] w-auto",
                  opportunity.stageDiscrepancy >= 2 && "border-orange-500 text-orange-700 font-medium"
                )}>
                  <SelectValue placeholder="Set" />
                </SelectTrigger>
                <SelectContent>
                  {PRE_SALES_STAGE_OPTIONS.map(opt => (
                    <SelectItem key={opt.value} value={opt.value} className="text-xs">
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {opportunity.daysInCurrentStage !== null && (
              <div className={cn(
                'flex items-center gap-1 text-xs text-muted-foreground',
                opportunity.daysInCurrentStage > 30 && 'text-orange-600 font-semibold',
              )}>
                <Clock className="w-3 h-3" />
                <span>{opportunity.daysInCurrentStage}d</span>
              </div>
            )}
            
            <button 
              onClick={openOpportunityInNewTab}
              className="text-muted-foreground hover:text-primary"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Simple Timeline */}
        <CEPSimpleTimeline opportunity={opportunity} showLabels={false} />

        {/* Footer Row */}
        <div className="flex items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-4">
            {showAccountInfo && (
              <a 
                href={`/accounts/${opportunity.accountId}`}
                className="flex items-center gap-1 text-muted-foreground hover:underline"
              >
                <Building2 className="w-3 h-3" />
                {opportunity.accountName}
              </a>
            )}
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <User className="w-3 h-3" />
                    <span className="font-medium">AE:</span>
                    <span>{extractName(opportunity.ownerEmail)}</span>
                  </div>
                </TooltipTrigger>
                <TooltipContent>{opportunity.ownerEmail || 'No AE assigned'}</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Users className="w-3 h-3" />
                    <span className="font-medium">SE:</span>
                    <span>{extractName(opportunity.primarySeEmail)}</span>
                  </div>
                </TooltipTrigger>
                <TooltipContent>{opportunity.primarySeEmail || 'No SE assigned'}</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          
          {/* Right side: Salesforce ID, timestamps */}
          <div className="flex items-center gap-3 text-muted-foreground">
            {opportunity.salesforceOpportunityId && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <a
                      href={`${SALESFORCE_BASE_URL}/${opportunity.salesforceOpportunityId.trim()}/view`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 hover:text-primary transition-colors"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <SalesforceIcon className="h-3 w-3" />
                      <span className="font-mono text-[10px]">{opportunity.salesforceOpportunityId.slice(-8)}</span>
                      <ExternalLink className="h-2.5 w-2.5" />
                    </a>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Salesforce ID: {opportunity.salesforceOpportunityId}</p>
                    <p className="text-xs text-muted-foreground">Click to open in Salesforce</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            
            {opportunity.lastTranscriptAt && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center gap-1">
                      <Mic className="w-3 h-3" />
                      <span>{formatDistanceToNow(new Date(opportunity.lastTranscriptAt), { addSuffix: true })}</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Last transcript: {format(new Date(opportunity.lastTranscriptAt), 'MMM d, yyyy')}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            
            {opportunity.updatedAt && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center gap-1">
                      <RefreshCw className="w-3 h-3" />
                      <span>{formatDistanceToNow(new Date(opportunity.updatedAt), { addSuffix: true })}</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Last updated: {format(new Date(opportunity.updatedAt), 'MMM d, yyyy h:mm a')}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
        </div>
      </div>

    </>
  );
}

export default CEPSimpleCard;

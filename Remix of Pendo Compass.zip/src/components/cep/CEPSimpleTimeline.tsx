import { useMemo } from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { CEPOpportunity, CEPSignal, ProductMentionOnTimeline } from '@/hooks/useCEPOpportunities';
import { CEP_STAGES, CEPSignalType } from '@/lib/cepConfig';
import { Diamond } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, formatDistanceToNow, differenceInDays, isBefore, parseISO } from 'date-fns';
import pendoLogo from '@/assets/pendo-logo.png';
import { SignalCluster } from './SignalCluster';

// Stage colors for the horizontal bar
const STAGE_COLORS = [
  'hsl(285, 90%, 65%)', // S0
  'hsl(285, 90%, 55%)', // S1
  'hsl(330, 85%, 60%)', // S2
  'hsl(330, 85%, 50%)', // S3
  'hsl(330, 85%, 40%)', // S4
  'hsl(35, 95%, 55%)',  // S5
  'hsl(35, 95%, 45%)',  // S6
];

interface CEPSimpleTimelineProps {
  opportunity: CEPOpportunity;
  showLabels?: boolean;
}

// Triangle marker pointing at the timeline
function TriangleMarker({ 
  position, 
  label, 
  type, 
  isAbove = true,
}: { 
  position: number;
  label: string;
  type: 'actual' | 'detected';
  isAbove?: boolean;
}) {
  const leftPercent = ((position + 0.5) / 7) * 100;
  const color = type === 'actual' ? 'hsl(var(--foreground))' : 'hsl(var(--chart-2))';
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div 
            className="absolute flex flex-col items-center z-10"
            style={{ 
              left: `${leftPercent}%`,
              transform: 'translateX(-50%)',
              ...(isAbove ? { bottom: '0' } : { top: '0' }),
            }}
          >
            {isAbove ? (
              <>
                <span className="text-[8px] font-semibold whitespace-nowrap mb-0.5" style={{ color }}>
                  {label}
                </span>
                <svg width="12" height="8" viewBox="0 0 12 8" className="shrink-0">
                  <polygon points="6,8 0,0 12,0" fill={color} />
                </svg>
              </>
            ) : (
              <>
                <svg width="12" height="8" viewBox="0 0 12 8" className="shrink-0">
                  <polygon points="6,0 0,8 12,8" fill={color} />
                </svg>
                <span className="text-[8px] font-semibold whitespace-nowrap mt-0.5" style={{ color }}>
                  {label}
                </span>
              </>
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent side={isAbove ? 'top' : 'bottom'}>
          <p className="text-xs">{label}: Stage {position}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Delta arrow with dot and arrowhead - offset from markers
function DeltaArrow({ 
  detectedStage, 
  actualStage, 
}: { 
  detectedStage: number;
  actualStage: number;
}) {
  if (detectedStage === actualStage) return null;
  
  const OFFSET = 16; // px offset from markers
  const DOT_RADIUS = 4;
  const ARROW_SIZE = 8;
  
  const detectedPercent = ((detectedStage + 0.5) / 7) * 100;
  const actualPercent = ((actualStage + 0.5) / 7) * 100;
  const isGoingLeft = detectedStage > actualStage;
  
  const arrowColor = 'hsl(var(--destructive))';
  
  const dotOffset = isGoingLeft ? -OFFSET : OFFSET;
  const arrowOffset = isGoingLeft ? OFFSET : -OFFSET;
  
  return (
    <div 
      className="absolute left-0 right-0 pointer-events-none"
      style={{
        height: '12px',
        top: '50%',
        transform: 'translateY(-50%)',
      }}
    >
      <svg 
        width="100%" 
        height="12" 
        className="overflow-visible"
      >
        <line 
          x1={`calc(${detectedPercent}% + ${dotOffset}px)`}
          y1="6"
          x2={`calc(${actualPercent}% + ${arrowOffset}px)`}
          y2="6"
          stroke={arrowColor}
          strokeWidth="2"
        />
        <circle 
          cx="0"
          cy="6"
          r={DOT_RADIUS}
          fill={arrowColor}
          style={{ transform: `translateX(calc(${detectedPercent}% + ${dotOffset}px))` }}
        />
        <g style={{ transform: `translateX(calc(${actualPercent}% + ${arrowOffset}px))` }}>
          {isGoingLeft ? (
            <path d={`M 0 6 L ${ARROW_SIZE} ${6 - ARROW_SIZE/2} L ${ARROW_SIZE} ${6 + ARROW_SIZE/2} Z`} fill={arrowColor} />
          ) : (
            <path d={`M 0 6 L ${-ARROW_SIZE} ${6 - ARROW_SIZE/2} L ${-ARROW_SIZE} ${6 + ARROW_SIZE/2} Z`} fill={arrowColor} />
          )}
        </g>
      </svg>
    </div>
  );
}

// NOTE: SignalDot has been replaced by SignalCluster component for better grouping

// Helper to format product name for display - strip "Pendo" prefix to show module name only
function formatModuleName(name: string): string {
  // Strip common Pendo prefixes to show just the module name
  const prefixes = ['Pendo ', "Pendo's ", 'Pendo\'s '];
  for (const prefix of prefixes) {
    if (name.startsWith(prefix)) {
      return name.slice(prefix.length);
    }
  }
  // Handle parenthetical format like "NPS module (Pendo)" or "MCP (Pendo's)"
  const parentheticalPattern = /\s*\(Pendo(?:'s)?\)$/i;
  if (parentheticalPattern.test(name)) {
    return name.replace(parentheticalPattern, '');
  }
  // If it's just "Pendo", keep it as-is (generic mention)
  return name;
}

// Product mention dot with Pendo logo - half below the bar
function ProductMentionDot({ 
  mentions, 
  leftPercent,
}: { 
  mentions: ProductMentionOnTimeline[];
  leftPercent: number;
}) {
  // Aggregate mentions by product name to get proper counts (only owned/Pendo products)
  const productAggregates = useMemo(() => {
    const aggregates = new Map<string, { count: number; type: string }>();
    mentions.forEach(m => {
      const existing = aggregates.get(m.productName);
      if (existing) {
        existing.count += m.mentionCount;
      } else {
        aggregates.set(m.productName, { count: m.mentionCount, type: m.mentionType });
      }
    });
    return Array.from(aggregates.entries()).map(([name, data]) => ({
      name,
      displayName: formatModuleName(name),
      count: data.count,
      type: data.type,
    }));
  }, [mentions]);
  
  const totalCount = productAggregates.reduce((sum, p) => sum + p.count, 0);
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div 
            className="absolute -translate-x-1/2 z-10"
            style={{ left: `${leftPercent}%`, bottom: '-6px' }}
          >
            <div className="relative">
              <div className="w-5 h-5 rounded-full flex items-center justify-center cursor-pointer border-2 bg-pink-500 border-pink-600 shadow-md shadow-pink-500/50">
                <img src={pendoLogo} alt="Pendo" className="w-3 h-3 object-contain brightness-0 invert" />
              </div>
              {totalCount > 1 && (
                <div className="absolute -top-1.5 -right-1.5 min-w-[14px] h-[14px] rounded-full bg-slate-800 text-white text-[9px] font-bold flex items-center justify-center px-0.5 border border-white shadow-sm">
                  {totalCount}
                </div>
              )}
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="max-w-sm z-50">
          <div className="space-y-2">
            <p className="font-medium text-pink-500">Pendo Products ({totalCount})</p>
            <div className="space-y-1.5 max-h-40 overflow-y-auto">
              {productAggregates.map((product, i) => (
                <div key={i} className="text-xs flex items-center justify-between gap-3">
                  <span className="text-foreground">{product.displayName}</span>
                  <span className="text-muted-foreground font-medium">×{product.count}</span>
                </div>
              ))}
            </div>
            {mentions[0]?.transcriptDate && (
              <p className="text-xs text-muted-foreground border-t border-border pt-1.5 mt-1.5">
                {format(new Date(mentions[0].transcriptDate), 'MMM d, yyyy')}
              </p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Diamond marker for today/close date - centered on bar
function DiamondMarker({ 
  type, 
  leftPercent, 
  date,
  isOverdue = false,
}: { 
  type: 'today' | 'closeDate';
  leftPercent: number;
  date: Date;
  isOverdue?: boolean;
}) {
  const isToday = type === 'today';
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div 
            className="absolute -translate-x-1/2 -translate-y-1/2 z-20"
            style={{ left: `${leftPercent}%`, top: '50%' }}
          >
            <Diamond 
              className={cn(
                'w-3 h-3 fill-current',
                isToday ? 'text-green-500' : isOverdue ? 'text-red-500 animate-pulse' : 'text-red-500',
              )} 
            />
          </div>
        </TooltipTrigger>
        <TooltipContent side="top" className="z-50">
          <p className="font-medium">
            {isToday ? 'Today' : isOverdue ? 'Overdue Close Date' : 'Target Close Date'}
          </p>
          <p className="text-xs text-muted-foreground">{format(date, 'MMM d, yyyy')}</p>
          {isOverdue && (
            <p className="text-xs text-red-500">
              {differenceInDays(new Date(), date)} days overdue
            </p>
          )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export function CEPSimpleTimeline({ opportunity, showLabels = true }: CEPSimpleTimelineProps) {
  const salesStage = opportunity.crmStage ?? 0;
  const detectedStage = opportunity.inferredStage ?? null;
  const preSalesStage = opportunity.preSalesTimelinePosition ?? null;
  
  // Show delta arrow only when there's a difference
  const salesHasDelta = detectedStage !== null && detectedStage !== salesStage;
  const preSalesHasDelta = detectedStage !== null && preSalesStage !== null && detectedStage !== preSalesStage;
  
  // Always show detected stage marker if we have one (even when no delta)
  const showDetectedOnCommercial = detectedStage !== null;
  const showDetectedOnTechnical = detectedStage !== null && preSalesStage !== null;

  // Calculate timeline dates
  const today = useMemo(() => new Date(), []);
  
  const timelineDates = useMemo(() => {
    // Start date: earliest of created_at or first activity
    const startDate = opportunity.firstActivityDate 
      ? parseISO(opportunity.firstActivityDate)
      : opportunity.createdAt 
        ? parseISO(opportunity.createdAt) 
        : null;
    
    // Close date from opportunity
    const closeDate = opportunity.closeDate ? parseISO(opportunity.closeDate) : null;
    
    // Determine if overdue
    const isOverdue = closeDate ? isBefore(closeDate, today) : false;
    
    // End date: max of close date or today (if overdue, extend to today)
    let endDate = closeDate;
    if (isOverdue) {
      endDate = today;
    } else if (!endDate) {
      // If no close date, use today + 30 days as default
      endDate = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);
    }
    
    // Ensure minimum 7-day range for visual spacing
    if (startDate && endDate) {
      const minRangeDays = 7;
      const currentRangeDays = differenceInDays(endDate, startDate);
      if (currentRangeDays < minRangeDays) {
        endDate = new Date(startDate.getTime() + minRangeDays * 24 * 60 * 60 * 1000);
      }
    }
    
    return { startDate, closeDate, endDate, isOverdue };
  }, [opportunity.firstActivityDate, opportunity.createdAt, opportunity.closeDate, today]);

  // Calculate position percentage for a given date
  const getPositionPercent = useMemo(() => {
    const { startDate, endDate } = timelineDates;
    if (!startDate || !endDate) return () => 50;
    
    const startTime = startDate.getTime();
    const endTime = endDate.getTime();
    const range = endTime - startTime;
    
    if (range <= 0) return () => 50;
    
    return (date: Date) => {
      const time = date.getTime();
      const percent = ((time - startTime) / range) * 100;
      return Math.max(2, Math.min(98, percent)); // Keep within 2-98% to avoid edge clipping
    };
  }, [timelineDates]);

  // Group signals by proximity for clustering - signals within 5% are grouped together
  const signalClusters = useMemo(() => {
    const rawPositions = opportunity.signals.map(signal => ({
      signal,
      position: getPositionPercent(parseISO(signal.detectedAt)),
    }));
    
    // Sort by position
    rawPositions.sort((a, b) => a.position - b.position);
    
    // Group signals within 5% proximity into clusters
    const CLUSTER_THRESHOLD = 5; // 5% proximity threshold
    const clusters: { signals: CEPSignal[]; centerPosition: number }[] = [];
    
    rawPositions.forEach(({ signal, position }) => {
      // Try to add to existing nearby cluster
      const nearbyCluster = clusters.find(
        c => Math.abs(c.centerPosition - position) <= CLUSTER_THRESHOLD
      );
      
      if (nearbyCluster) {
        nearbyCluster.signals.push(signal);
        // Recalculate center position as average
        const allPositions = nearbyCluster.signals.map(s => 
          getPositionPercent(parseISO(s.detectedAt))
        );
        nearbyCluster.centerPosition = allPositions.reduce((a, b) => a + b, 0) / allPositions.length;
      } else {
        clusters.push({
          signals: [signal],
          centerPosition: position,
        });
      }
    });
    
    return clusters;
  }, [opportunity.signals, getPositionPercent]);

  // Today position - calculated before product mentions so we can clamp them
  const todayPositionValue = getPositionPercent(today);

  // Group product mentions by date with horizontal spreading - only show owned (Pendo) products
  // Clamp positions to not exceed today (mentions can't be in the future)
  const productMentionGroups = useMemo(() => {
    const mentions = opportunity.productMentions || [];
    // Filter to only include owned (Pendo) products
    const ownedMentions = mentions.filter(pm => pm.mentionType === 'owned');
    
    const groups = new Map<string, ProductMentionOnTimeline[]>();
    ownedMentions.forEach(pm => {
      const dateKey = pm.transcriptDate ? pm.transcriptDate.split('T')[0] : 'no-date';
      if (!groups.has(dateKey)) {
        groups.set(dateKey, []);
      }
      groups.get(dateKey)!.push(pm);
    });
    
    const rawGroups = Array.from(groups.entries()).map(([dateKey, groupMentions]) => {
      // For mentions without date, position at today (they happened in the past)
      // For dated mentions, clamp to not exceed today position
      let position: number;
      if (dateKey === 'no-date') {
        position = Math.min(todayPositionValue, 50);
      } else {
        const rawPosition = getPositionPercent(parseISO(groupMentions[0].transcriptDate!));
        position = Math.min(rawPosition, todayPositionValue);
      }
      return {
        dateKey,
        mentions: groupMentions,
        position,
      };
    });
    
    // Apply horizontal spreading for groups at similar positions
    const positionBuckets = new Map<number, typeof rawGroups>();
    rawGroups.forEach(item => {
      const groupKey = Math.round(item.position / 5) * 5;
      if (!positionBuckets.has(groupKey)) {
        positionBuckets.set(groupKey, []);
      }
      positionBuckets.get(groupKey)!.push(item);
    });
    
    const spreadItems: (typeof rawGroups[0] & { spreadPosition: number })[] = [];
    positionBuckets.forEach((group) => {
      const spreadWidth = Math.min(15, group.length * 4);
      const startOffset = -spreadWidth / 2;
      group.forEach((item, idx) => {
        const offset = group.length > 1 
          ? startOffset + (spreadWidth * idx) / (group.length - 1)
          : 0;
        spreadItems.push({
          ...item,
          spreadPosition: Math.max(2, Math.min(98, item.position + offset)),
        });
      });
    });
    
    return spreadItems;
  }, [opportunity.productMentions, getPositionPercent, todayPositionValue]);

  // Today position (alias for use in JSX)
  const todayPosition = todayPositionValue;
  
  // Close date position
  const closeDatePosition = timelineDates.closeDate 
    ? getPositionPercent(timelineDates.closeDate) 
    : null;

  return (
    <div className="py-2 px-1">
      {/* Commercial Alignment Row */}
      <div className="flex items-end gap-1 mb-0.5">
        <span className="text-[8px] font-medium text-muted-foreground uppercase tracking-wide w-20 pb-0.5 bg-slate-100/60 dark:bg-slate-800/40 px-1 rounded-l">
          Commercial
        </span>
        <div className="flex-1 relative h-5 bg-slate-100/60 dark:bg-slate-800/40 rounded-r">
          {salesHasDelta && detectedStage !== null && (
            <DeltaArrow 
              detectedStage={detectedStage}
              actualStage={salesStage}
            />
          )}
          <TriangleMarker position={salesStage} label="CRM" type="actual" isAbove={true} />
          {showDetectedOnCommercial && (
            <TriangleMarker position={detectedStage!} label="Det" type="detected" isAbove={true} />
          )}
        </div>
      </div>

      {/* Date labels */}
      <div className="flex justify-between text-[8px] text-muted-foreground ml-[84px] mb-0.5">
        <span>{timelineDates.startDate ? format(timelineDates.startDate, 'MMM d') : '—'}</span>
        <span>{timelineDates.endDate ? format(timelineDates.endDate, 'MMM d') : '—'}</span>
      </div>

      {/* Main Timeline Bar with date-based positioning - 7px height */}
      <div className="relative h-[7px] rounded-full overflow-visible ml-[84px]">
        {/* Stage colored segments as background */}
        <div className="absolute inset-0 flex rounded-full overflow-hidden">
          {CEP_STAGES.map((stage, index) => (
            <div
              key={stage.id}
              className="flex-1 first:rounded-l-full last:rounded-r-full"
              style={{
                backgroundColor: STAGE_COLORS[index],
                opacity: index <= salesStage ? 1 : 0.3,
              }}
            />
          ))}
        </div>
        
        {/* Signal clusters - grouped by proximity */}
        {signalClusters.map((cluster, idx) => (
          <SignalCluster
            key={`cluster-${idx}`}
            signals={cluster.signals}
            leftPercent={Math.max(2, Math.min(98, cluster.centerPosition))}
            showDate={true}
          />
        ))}
        
        {/* Product mentions positioned by date with horizontal spreading */}
        {productMentionGroups.map(({ dateKey, mentions, spreadPosition }) => (
          <ProductMentionDot
            key={dateKey}
            mentions={mentions}
            leftPercent={spreadPosition}
          />
        ))}
        
        {/* Today diamond (green) */}
        {todayPosition >= 0 && todayPosition <= 100 && (
          <DiamondMarker
            type="today"
            date={today}
            leftPercent={todayPosition}
          />
        )}
        
        {/* Close date diamond (red) */}
        {timelineDates.closeDate && closeDatePosition !== null && (
          <DiamondMarker
            type="closeDate"
            date={timelineDates.closeDate}
            isOverdue={timelineDates.isOverdue}
            leftPercent={closeDatePosition}
          />
        )}
      </div>

      {/* Stage labels */}
      <div className="flex mt-0.5 ml-[84px]">
        {CEP_STAGES.map((stage) => (
          <div key={stage.id} className="flex-1 text-center">
            <span className="text-[7px] text-muted-foreground">S{stage.id}</span>
          </div>
        ))}
      </div>

      {/* Technical Alignment Row */}
      <div className="flex items-start gap-1 mt-0.5">
        <span className="text-[8px] font-medium text-muted-foreground uppercase tracking-wide w-20 pt-0.5 bg-blue-50/60 dark:bg-blue-900/30 px-1 rounded-l">
          Technical
        </span>
        <div className="flex-1 relative h-5 bg-blue-50/60 dark:bg-blue-900/30 rounded-r">
          {preSalesStage !== null ? (
            <>
              {preSalesHasDelta && detectedStage !== null && (
                <DeltaArrow 
                  detectedStage={detectedStage}
                  actualStage={preSalesStage}
                />
              )}
              <TriangleMarker position={preSalesStage} label="PS" type="actual" isAbove={false} />
              {showDetectedOnTechnical && (
                <TriangleMarker position={detectedStage!} label="Det" type="detected" isAbove={false} />
              )}
            </>
          ) : (
            <span className="text-[7px] text-muted-foreground italic absolute left-1 top-1/2 -translate-y-1/2">
              No pre-sales position set
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

export default CEPSimpleTimeline;

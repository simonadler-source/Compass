import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CEP_STAGES, CEP_PHASES } from '@/lib/cepConfig';
import { CEPOpportunity, CEPSignal, ProductMentionOnTimeline } from '@/hooks/useCEPOpportunities';
import { SalesforceIcon } from '@/components/icons/SalesforceIcon';
import pendoLogo from '@/assets/pendo-logo.png';
import { 
  Target, 
  Presentation, 
  FlaskConical, 
  AlertTriangle,
  Building2,
  Clock,
  ChevronRight,
  XCircle,
  User,
  Users,
  Scale,
  Shield,
  Wrench,
  Workflow,
  FileText,
  DollarSign,
  PlayCircle,
  Diamond,
  Layers,
  CalendarRange,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, formatDistanceToNow, differenceInDays, isAfter, isBefore, parseISO } from 'date-fns';
import { gateway } from '@/lib/apiGateway';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { CEPSignalType } from '@/lib/cepConfig';

const SALESFORCE_BASE_URL = 'https://pendo.lightning.force.com/lightning/r/Opportunity';

interface CEPTimelineBarProps {
  opportunity: CEPOpportunity;
  showAccountInfo?: boolean;
}

const SIGNAL_ICONS: Record<CEPSignalType, any> = {
  demo: Target,
  demo_delivered: PlayCircle,
  reverse_demo: Presentation,
  evaluation: FlaskConical,
  legal: Scale,
  security: Shield,
  technical_discovery: Wrench,
  process_discovery: Workflow,
  nda: FileText,
  pricing: DollarSign,
  dry_run: PlayCircle,
  eval_active: CalendarRange,
  eval_pending: Layers,
};

const SIGNAL_COLORS: Record<CEPSignalType, string> = {
  demo: 'text-chart-3 bg-chart-3/20 border-chart-3/40',
  demo_delivered: 'text-green-600 bg-green-600/20 border-green-600/40',
  reverse_demo: 'text-chart-2 bg-chart-2/20 border-chart-2/40',
  evaluation: 'text-chart-1 bg-chart-1/20 border-chart-1/40',
  legal: 'text-indigo-500 bg-indigo-500/20 border-indigo-500/40',
  security: 'text-cyan-500 bg-cyan-500/20 border-cyan-500/40',
  technical_discovery: 'text-teal-500 bg-teal-500/20 border-teal-500/40',
  process_discovery: 'text-amber-500 bg-amber-500/20 border-amber-500/40',
  nda: 'text-violet-500 bg-violet-500/20 border-violet-500/40',
  pricing: 'text-rose-500 bg-rose-500/20 border-rose-500/40',
  dry_run: 'text-lime-600 bg-lime-600/20 border-lime-600/40',
  eval_active: 'text-orange-600 bg-orange-600/20 border-orange-600/40',
  eval_pending: 'text-yellow-600 bg-yellow-600/20 border-yellow-600/40',
};

// Sales stage options for dropdown
const SALES_STAGE_OPTIONS = [
  { value: 'stage_0', label: 'Stage 0' },
  { value: 'stage_1', label: 'Stage 1' },
  { value: 'stage_2', label: 'Stage 2' },
  { value: 'stage_3', label: 'Stage 3' },
  { value: 'stage_4', label: 'Stage 4' },
  { value: 'stage_5', label: 'Stage 5' },
  { value: 'stage_6', label: 'Stage 6' },
  { value: 'stage_7', label: 'Stage 7' },
];

// Pre-sales stage options
const PRE_SALES_STAGE_OPTIONS = [
  { value: 'discovery', label: 'Discovery' },
  { value: 'demo', label: 'Demo' },
  { value: 'reverse_demo', label: 'Reverse Demo' },
  { value: 'evaluation', label: 'Evaluation' },
  { value: 'poc', label: 'POC' },
  { value: 'pov', label: 'POV' },
  { value: 'technical_win', label: 'Technical Win' },
  { value: 'closed', label: 'Closed' },
];

// Signal dot positioned by date
function SignalDot({ signal, style }: { signal: CEPSignal; style?: React.CSSProperties }) {
  const Icon = SIGNAL_ICONS[signal.type];
  const occurrenceCount = signal.occurrenceCount || signal.occurrences?.length || 1;
  const hasMultiple = occurrenceCount > 1;
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="absolute -translate-x-1/2 -translate-y-1/2" style={style}>
            <div className="relative">
              <div className={cn(
                'w-6 h-6 rounded-full flex items-center justify-center cursor-pointer border',
                'transition-all hover:scale-125 hover:shadow-md z-10',
                SIGNAL_COLORS[signal.type]
              )}>
                <Icon className="w-3.5 h-3.5" />
              </div>
              {hasMultiple && (
                <div className="absolute -top-1 -right-1 min-w-[14px] h-[14px] rounded-full bg-primary text-primary-foreground text-[9px] font-bold flex items-center justify-center px-0.5">
                  {occurrenceCount}
                </div>
              )}
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-sm z-50">
          <div className="space-y-2">
            <p className="font-medium">{signal.ruleName.replace(' Signals', '')}</p>
            {hasMultiple ? (
              <div className="space-y-1.5">
                <p className="text-xs text-muted-foreground font-medium">
                  {occurrenceCount} occurrences detected:
                </p>
                <div className="max-h-32 overflow-y-auto space-y-1">
                  {signal.occurrences.map((occ, i) => (
                    <div key={i} className="text-xs border-l-2 border-primary/40 pl-2 py-0.5">
                      <p className="text-muted-foreground">
                        {formatDistanceToNow(new Date(occ.detectedAt), { addSuffix: true })}
                      </p>
                      {occ.speakerName && (
                        <p className="text-muted-foreground/80">
                          {occ.speakerName}
                        </p>
                      )}
                      {occ.matchedPhrases?.length > 0 && (
                        <p className="italic truncate">"{occ.matchedPhrases[0]}"</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <>
                {signal.speakerName && (
                  <p className="text-xs text-muted-foreground">
                    {signal.speakerType === 'external' ? 'Customer: ' : 'Pendo: '}
                    {signal.speakerName}
                  </p>
                )}
                {signal.matchedPhrases.length > 0 && (
                  <p className="text-xs italic">"{signal.matchedPhrases[0]}"</p>
                )}
                <p className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(signal.detectedAt), { addSuffix: true })}
                </p>
              </>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Product mention dot with Pendo logo - shows Pendo products only
function ProductMentionDot({ 
  mentions,
  style 
}: { 
  mentions: ProductMentionOnTimeline[]; 
  style?: React.CSSProperties;
}) {
  // Aggregate mentions by product name to get proper counts (only owned/Pendo products)
  const productAggregates = useMemo(() => {
    const aggregates = new Map<string, { count: number; type: string }>();
    mentions.forEach(m => {
      const existing = aggregates.get(m.productName);
      if (existing) {
        existing.count += m.mentionCount;
      } else {
        aggregates.set(m.productName, { count: m.mentionCount, type: m.mentionType });
      }
    });
    return Array.from(aggregates.entries()).map(([name, data]) => ({
      name,
      count: data.count,
      type: data.type,
    }));
  }, [mentions]);
  
  const totalCount = productAggregates.reduce((sum, p) => sum + p.count, 0);
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="absolute -translate-x-1/2 -translate-y-1/2" style={style}>
            <div className="relative">
              <div className="w-6 h-6 rounded-full flex items-center justify-center cursor-pointer border bg-pink-500/20 border-pink-500/40 transition-all hover:scale-125 hover:shadow-md z-10">
                <img src={pendoLogo} alt="Pendo" className="w-4 h-4 object-contain" />
              </div>
              {totalCount > 1 && (
                <div className="absolute -top-1 -right-1 min-w-[14px] h-[14px] rounded-full bg-pink-500 text-white text-[9px] font-bold flex items-center justify-center px-0.5">
                  {totalCount}
                </div>
              )}
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-sm z-50">
          <div className="space-y-2">
            <p className="font-medium text-pink-500">Pendo Products ({totalCount})</p>
            <div className="space-y-1.5 max-h-40 overflow-y-auto">
              {productAggregates.map((product, i) => (
                <div key={i} className="text-xs flex items-center justify-between gap-3">
                  <span className="text-foreground">{product.name}</span>
                  <span className="text-muted-foreground font-medium">×{product.count}</span>
                </div>
              ))}
            </div>
            {mentions[0]?.transcriptDate && (
              <p className="text-xs text-muted-foreground border-t border-border pt-1.5 mt-1.5">
                {format(new Date(mentions[0].transcriptDate), 'MMM d, yyyy')}
              </p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Diamond marker for today/close date
function DiamondMarker({ 
  type, 
  style, 
  date,
  isOverdue = false,
}: { 
  type: 'today' | 'closeDate';
  style?: React.CSSProperties;
  date: Date;
  isOverdue?: boolean;
}) {
  const isToday = type === 'today';
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div 
            className="absolute -translate-x-1/2 -translate-y-1/2 z-20" 
            style={style}
          >
            <Diamond 
              className={cn(
                'w-5 h-5 fill-current',
                isToday ? 'text-green-500' : isOverdue ? 'text-red-500 animate-pulse' : 'text-red-500',
              )} 
            />
          </div>
        </TooltipTrigger>
        <TooltipContent side="top" className="z-50">
          <p className="font-medium">
            {isToday ? 'Today' : isOverdue ? 'Overdue Close Date' : 'Target Close Date'}
          </p>
          <p className="text-xs text-muted-foreground">{format(date, 'MMM d, yyyy')}</p>
          {isOverdue && (
            <p className="text-xs text-red-500">
              {differenceInDays(new Date(), date)} days overdue
            </p>
          )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function StageSelector({ 
  label, 
  value, 
  options, 
  onValueChange,
  variant = 'default',
}: { 
  label: string;
  value: string | null;
  options: { value: string; label: string }[];
  onValueChange: (value: string) => void;
  variant?: 'default' | 'warning';
}) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-xs text-muted-foreground whitespace-nowrap">{label}:</span>
      <Select value={value || ''} onValueChange={onValueChange}>
        <SelectTrigger 
          className={cn(
            "h-6 text-xs px-2 min-w-[80px] w-auto",
            variant === 'warning' && "border-amber-500/50 text-amber-600"
          )}
        >
          <SelectValue placeholder="Set stage" />
        </SelectTrigger>
        <SelectContent>
          {options.map(opt => (
            <SelectItem key={opt.value} value={opt.value} className="text-xs">
              {opt.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function extractName(email: string | null): string {
  if (!email) return '—';
  const localPart = email.split('@')[0];
  if (localPart.includes('.')) {
    return localPart
      .split('.')
      .map(part => part.charAt(0).toUpperCase() + part.slice(1))
      .join(' ');
  }
  return localPart.charAt(0).toUpperCase() + localPart.slice(1);
}

function SignalSummary({ signals, type, label }: { signals: CEPSignal[], type: 'demo' | 'reverse_demo' | 'evaluation', label: string }) {
  const count = signals.filter(s => s.type === type).length;
  if (count === 0) return null;
  
  const Icon = SIGNAL_ICONS[type];
  
  return (
    <div className="flex items-center gap-1">
      <div className={cn("w-4 h-4 rounded-full flex items-center justify-center border", SIGNAL_COLORS[type])}>
        <Icon className="w-2.5 h-2.5" />
      </div>
      <span className="text-xs text-muted-foreground">{label} ({count})</span>
    </div>
  );
}

export function CEPTimelineBar({ opportunity, showAccountInfo = true }: CEPTimelineBarProps) {
  const queryClient = useQueryClient();
  const [isUpdating, setIsUpdating] = useState(false);
  
  const currentStage = opportunity.crmStage ?? opportunity.inferredStage ?? 0;
  const hasGaps = opportunity.missingExitCriteria.length > 0 || Math.abs(opportunity.stageDiscrepancy) >= 2;

  // Determine which signal types are NOT detected
  const detectedTypes = new Set(opportunity.signals.map(s => s.type));
  const missingSignalTypes = (['demo', 'reverse_demo', 'evaluation'] as const).filter(t => !detectedTypes.has(t));

  // Calculate timeline dates
  const today = useMemo(() => new Date(), []);
  
  const timelineDates = useMemo(() => {
    // Start date: earliest of created_at or first activity
    const startDate = opportunity.firstActivityDate 
      ? parseISO(opportunity.firstActivityDate)
      : opportunity.createdAt 
        ? parseISO(opportunity.createdAt) 
        : null;
    
    // Close date from opportunity
    const closeDate = opportunity.closeDate ? parseISO(opportunity.closeDate) : null;
    
    // Determine if overdue
    const isOverdue = closeDate ? isBefore(closeDate, today) : false;
    
    // End date: max of close date or today (if overdue, extend to today)
    let endDate = closeDate;
    if (isOverdue) {
      endDate = today;
    } else if (!endDate) {
      // If no close date, use today + 30 days as default
      endDate = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);
    }
    
    // Ensure minimum 7-day range for visual spacing
    if (startDate && endDate) {
      const minRangeDays = 7;
      const currentRangeDays = differenceInDays(endDate, startDate);
      if (currentRangeDays < minRangeDays) {
        endDate = new Date(startDate.getTime() + minRangeDays * 24 * 60 * 60 * 1000);
      }
    }
    
    return { startDate, closeDate, endDate, isOverdue };
  }, [opportunity.firstActivityDate, opportunity.createdAt, opportunity.closeDate, today]);

  // Calculate position percentage for a given date
  const getPositionPercent = useMemo(() => {
    const { startDate, endDate } = timelineDates;
    if (!startDate || !endDate) return () => 50;
    
    const startTime = startDate.getTime();
    const endTime = endDate.getTime();
    const range = endTime - startTime;
    
    // Ensure minimum range to prevent division issues
    if (range <= 0) return () => 50;
    
    return (date: Date) => {
      const time = date.getTime();
      const percent = ((time - startTime) / range) * 100;
      return Math.max(2, Math.min(98, percent)); // Keep within 2-98% to avoid edge clipping
    };
  }, [timelineDates]);

  // Group all signals with their positions - minimal spreading only for exact overlaps
  const signalsWithPositions = useMemo(() => {
    const rawPositions = opportunity.signals.flatMap(signal => 
      signal.occurrences.map((occ, idx) => ({
        signal,
        occurrenceIdx: idx,
        date: parseISO(occ.detectedAt),
        position: getPositionPercent(parseISO(occ.detectedAt)),
      }))
    );
    
    // Group by exact position (within 0.5%) to only spread truly overlapping items
    const positionGroups = new Map<number, typeof rawPositions>();
    rawPositions.forEach(item => {
      // Round to nearest 0.5% to group only very close items
      const groupKey = Math.round(item.position * 2) / 2;
      if (!positionGroups.has(groupKey)) {
        positionGroups.set(groupKey, []);
      }
      positionGroups.get(groupKey)!.push(item);
    });
    
    // Apply minimal horizontal spreading only within each group
    const spreadItems: (typeof rawPositions[0] & { spreadPosition: number })[] = [];
    positionGroups.forEach((group) => {
      // Small spread: 3% per item, max 10%
      const spreadWidth = Math.min(10, (group.length - 1) * 3);
      const startOffset = -spreadWidth / 2;
      group.forEach((item, idx) => {
        const offset = group.length > 1 
          ? startOffset + (spreadWidth * idx) / (group.length - 1)
          : 0;
        spreadItems.push({
          ...item,
          spreadPosition: Math.max(2, Math.min(98, item.position + offset)),
        });
      });
    });
    
    return spreadItems;
  }, [opportunity.signals, getPositionPercent]);

  // Group product mentions by date with horizontal spreading - only show owned (Pendo) products
  const productMentionGroups = useMemo(() => {
    const allMentions = opportunity.productMentions;
    const ownedMentions = allMentions.filter(pm => pm.mentionType === 'owned');
    
    // Group owned mentions by date for positioning
    const groups = new Map<string, ProductMentionOnTimeline[]>();
    ownedMentions.forEach(pm => {
      if (!pm.transcriptDate) return;
      const dateKey = pm.transcriptDate.split('T')[0];
      if (!groups.has(dateKey)) {
        groups.set(dateKey, []);
      }
      groups.get(dateKey)!.push(pm);
    });
    
    const rawGroups = Array.from(groups.entries()).map(([dateKey, mentions]) => ({
      dateKey,
      mentions,
      date: parseISO(mentions[0].transcriptDate!),
      position: getPositionPercent(parseISO(mentions[0].transcriptDate!)),
    }));
    
    // Apply horizontal spreading for product mention groups at similar positions
    const positionGroups = new Map<number, typeof rawGroups>();
    rawGroups.forEach(item => {
      const groupKey = Math.round(item.position / 3) * 3;
      if (!positionGroups.has(groupKey)) {
        positionGroups.set(groupKey, []);
      }
      positionGroups.get(groupKey)!.push(item);
    });
    
    const spreadItems: (typeof rawGroups[0] & { spreadPosition: number })[] = [];
    positionGroups.forEach((group) => {
      const spreadWidth = Math.min(10, group.length * 3);
      const startOffset = -spreadWidth / 2;
      group.forEach((item, idx) => {
        const offset = group.length > 1 
          ? startOffset + (spreadWidth * idx) / (group.length - 1)
          : 0;
        spreadItems.push({
          ...item,
          spreadPosition: Math.max(2, Math.min(98, item.position + offset)),
        });
      });
    });
    
    return spreadItems;
  }, [opportunity.productMentions, getPositionPercent]);

  // Calculate stage segment widths based on dates (still equal widths for visual consistency)
  const stageSegments = useMemo(() => {
    const totalStages = CEP_STAGES.length;
    return CEP_STAGES.map((stage, index) => {
      const phase = CEP_PHASES[stage.phase];
      const widthPercent = 100 / totalStages;
      const startPercent = index * widthPercent;
      
      return {
        stage,
        phase,
        widthPercent,
        startPercent,
        isCurrent: stage.id === currentStage,
        isPast: stage.id < currentStage,
        isFuture: stage.id > currentStage,
        isFirst: index === 0,
        isLast: index === totalStages - 1,
        isSuggestedStage: opportunity.inferredStage !== null && stage.id === opportunity.inferredStage && opportunity.inferredStage !== opportunity.crmStage,
        isPreSalesStage: opportunity.preSalesTimelinePosition !== null && stage.id === opportunity.preSalesTimelinePosition,
      };
    });
  }, [currentStage, opportunity.inferredStage, opportunity.crmStage, opportunity.preSalesTimelinePosition]);

  const handleSalesStageChange = async (value: string) => {
    setIsUpdating(true);
    try {
      const response = await gateway.from('opportunities')
        .update({ sales_stage: value })
        .eq('id', opportunity.id)
        .execute();
      
      if (response.error) throw response.error;
      
      queryClient.invalidateQueries({ queryKey: ['cep-opportunities'] });
      toast.success('Sales stage updated');
    } catch (error) {
      toast.error('Failed to update sales stage');
    } finally {
      setIsUpdating(false);
    }
  };

  const handlePreSalesStageChange = async (value: string) => {
    setIsUpdating(true);
    try {
      const response = await gateway.from('opportunities')
        .update({ pre_sales_stage: value })
        .eq('id', opportunity.id)
        .execute();
      
      if (response.error) throw response.error;
      
      queryClient.invalidateQueries({ queryKey: ['cep-opportunities'] });
      toast.success('Pre-Sales stage updated');
    } catch (error) {
      toast.error('Failed to update pre-sales stage');
    } finally {
      setIsUpdating(false);
    }
  };

  // Today position
  const todayPosition = getPositionPercent(today);
  
  // Close date position (if exists)
  const closeDatePosition = timelineDates.closeDate 
    ? getPositionPercent(timelineDates.closeDate) 
    : null;

  // Eval period positions
  const evalStartPosition = opportunity.evalStartDate
    ? getPositionPercent(parseISO(opportunity.evalStartDate))
    : null;
  const evalEndPosition = opportunity.evalEndDate
    ? getPositionPercent(parseISO(opportunity.evalEndDate))
    : null;
  const hasPendingEval = !!opportunity.primaryEvalQuote && !opportunity.evalStartDate;

  return (
    <div className={cn(
      'bg-card border rounded-lg p-3 hover:border-primary/50 transition-colors',
      hasGaps && 'border-amber-500/50 bg-amber-500/5',
      isUpdating && 'opacity-70 pointer-events-none',
    )}>
      {/* Row 1: Opportunity name, signals detected, stage dropdowns, days, link */}
      <div className="flex items-center justify-between gap-3 mb-2">
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <Link 
            to={`/accounts/${opportunity.accountId}?tab=opportunities&opp=${opportunity.id}`}
            className="font-semibold text-primary hover:underline truncate"
          >
            {opportunity.name}
          </Link>
          {opportunity.salesforceOpportunityId && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <a
                    href={`${SALESFORCE_BASE_URL}/${opportunity.salesforceOpportunityId}/view`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center p-1 rounded hover:bg-muted transition-colors shrink-0"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <SalesforceIcon className="h-4 w-4" />
                  </a>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Open in Salesforce</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
          
          {hasGaps && (
            <Badge variant="outline" className="shrink-0 bg-amber-500/10 text-amber-500 border-amber-500/30 h-5 text-[10px]">
              <AlertTriangle className="w-3 h-3 mr-1" />
              Gap
            </Badge>
          )}
          
          {/* Signals detected - inline */}
          {opportunity.signals.length > 0 && (
            <div className="flex items-center gap-2 shrink-0">
              <SignalSummary signals={opportunity.signals} type="demo" label="Demo" />
              <SignalSummary signals={opportunity.signals} type="reverse_demo" label="Rev Demo" />
              <SignalSummary signals={opportunity.signals} type="evaluation" label="Eval" />
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-3 shrink-0">
          {/* Stage dropdowns */}
          <StageSelector
            label="Sales"
            value={opportunity.salesStage}
            options={SALES_STAGE_OPTIONS}
            onValueChange={handleSalesStageChange}
          />
          <StageSelector
            label="Pre-Sales"
            value={opportunity.preSalesStage}
            options={PRE_SALES_STAGE_OPTIONS}
            onValueChange={handlePreSalesStageChange}
            variant={opportunity.stageDiscrepancy >= 2 ? 'warning' : 'default'}
          />
          
          {/* Days in stage */}
          {opportunity.daysInCurrentStage !== null && (
            <div className={cn(
              'flex items-center gap-1 text-xs text-muted-foreground',
              opportunity.daysInCurrentStage > 30 && 'text-amber-500 font-medium',
            )}>
              <Clock className="w-3 h-3" />
              <span>{opportunity.daysInCurrentStage}d</span>
            </div>
          )}
          
          <Link 
            to={`/accounts/${opportunity.accountId}?tab=opportunities&opp=${opportunity.id}`}
            className="text-muted-foreground hover:text-primary"
          >
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>

      {/* Date labels above timeline */}
      <div className="flex justify-between text-[10px] text-muted-foreground mb-1 px-1">
        <span>
          {timelineDates.startDate ? format(timelineDates.startDate, 'MMM d, yyyy') : '—'}
        </span>
        <span>
          {timelineDates.endDate ? format(timelineDates.endDate, 'MMM d, yyyy') : '—'}
        </span>
      </div>

      {/* Timeline bar with stage backgrounds and date-positioned signals */}
      <div className="relative h-14 rounded-md overflow-visible border border-border bg-muted/20">
        {/* Stage segment backgrounds */}
        <div className="absolute inset-0 flex rounded-md overflow-hidden">
          {stageSegments.map(({ stage, phase, isCurrent, isPast, isFuture, isFirst, isLast, isSuggestedStage, isPreSalesStage }) => (
            <TooltipProvider key={stage.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div 
                    className={cn(
                      'flex-1 flex flex-col items-center justify-end pb-1',
                      'border-r border-background/50 last:border-r-0',
                      'transition-all duration-200',
                      isFirst && 'rounded-l-md',
                      isLast && 'rounded-r-md',
                      isCurrent && 'ring-2 ring-primary ring-inset z-[5]',
                      isPreSalesStage && !isCurrent && 'ring-2 ring-green-500 ring-inset border-dashed',
                      isSuggestedStage && !isCurrent && !isPreSalesStage && 'ring-2 ring-destructive ring-inset border-dashed',
                      isFuture && 'opacity-50',
                    )}
                    style={{
                      backgroundColor: isPast || isCurrent 
                        ? phase.bgColor.replace('0.15', isCurrent ? '0.4' : '0.25')
                        : 'hsl(var(--muted) / 0.3)',
                    }}
                  >
                    {/* Stage label at bottom */}
                    <span 
                      className={cn(
                        'text-[10px] font-bold uppercase tracking-wide',
                        isPast || isCurrent ? 'text-foreground/80' : 'text-muted-foreground/60'
                      )}
                      style={{
                        color: isPast || isCurrent ? phase.color : undefined,
                      }}
                    >
                      S{stage.id}
                    </span>
                    
                    {/* Current stage indicator */}
                    {isCurrent && (
                      <div 
                        className="absolute -bottom-2 left-1/2 -translate-x-1/2"
                        style={{
                          width: 0,
                          height: 0,
                          borderLeft: '8px solid transparent',
                          borderRight: '8px solid transparent',
                          borderTop: `8px solid ${phase.color}`,
                        }}
                      />
                    )}
                  </div>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-sm z-50">
                  <div className="space-y-2">
                    <div>
                      <p className="font-semibold">{stage.name}: {stage.description}</p>
                      {isPreSalesStage && !isCurrent && (
                        <p className="text-xs text-green-600 font-medium mt-1">✓ Current Pre-Sales stage</p>
                      )}
                      {isSuggestedStage && !isCurrent && !isPreSalesStage && (
                        <p className="text-xs text-destructive font-medium mt-1">⚠ Signals suggest this stage</p>
                      )}
                    </div>
                    <div className="text-xs">
                      <p className="font-medium">Key Activity:</p>
                      <p className="text-muted-foreground">{stage.keyActivity}</p>
                    </div>
                    <div className="text-xs">
                      <p className="font-medium">Exit Criteria:</p>
                      <ul className="list-disc list-inside text-muted-foreground">
                        {stage.exitCriteria.slice(0, 3).map((c, i) => (
                          <li key={i}>{c}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>
        
        {/* Signals positioned by date with horizontal spreading */}
        {signalsWithPositions.map(({ signal, occurrenceIdx, spreadPosition }, idx) => (
          <SignalDot 
            key={`${signal.id}-${occurrenceIdx}`} 
            signal={signal}
            style={{ 
              left: `${spreadPosition}%`, 
              top: '35%',
              zIndex: 10 + idx,
            }}
          />
        ))}
        
        {/* Product mentions positioned by date with horizontal spreading */}
        {productMentionGroups.map(({ dateKey, mentions, spreadPosition }, idx) => (
          <ProductMentionDot
            key={dateKey}
            mentions={mentions}
            style={{
              left: `${spreadPosition}%`,
              top: '65%',
              zIndex: 10 + signalsWithPositions.length + idx,
            }}
          />
        ))}
        
        {/* Eval period band */}
        {evalStartPosition !== null && evalEndPosition !== null && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div
                  className="absolute top-[15%] bottom-[15%] rounded pointer-events-auto cursor-help z-[6]"
                  style={{
                    left: `${evalStartPosition}%`,
                    width: `${Math.max(evalEndPosition - evalStartPosition, 2)}%`,
                    background: 'hsl(var(--chart-1) / 0.18)',
                    border: '1px solid hsl(var(--chart-1) / 0.5)',
                  }}
                />
              </TooltipTrigger>
              <TooltipContent side="top" className="max-w-xs z-50">
                <p className="font-medium text-orange-600">Evaluation Period</p>
                {opportunity.evalType && <p className="text-xs text-muted-foreground">Type: {opportunity.evalType}</p>}
                {opportunity.evalStartDate && <p className="text-xs text-muted-foreground">Start: {format(parseISO(opportunity.evalStartDate), 'MMM d, yyyy')}</p>}
                {opportunity.evalEndDate && <p className="text-xs text-muted-foreground">End: {format(parseISO(opportunity.evalEndDate), 'MMM d, yyyy')}</p>}
                {opportunity.primaryEvalQuote && <p className="text-xs text-muted-foreground mt-1 italic">"{opportunity.primaryEvalQuote}"</p>}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}

        {/* Eval start dot marker */}
        {evalStartPosition !== null && opportunity.evalStartDate && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-[15] w-5 h-5 rounded-full border-2 flex items-center justify-center cursor-help"
                  style={{
                    left: `${evalStartPosition}%`,
                    top: '50%',
                    backgroundColor: 'hsl(var(--chart-1) / 0.2)',
                    borderColor: 'hsl(var(--chart-1))',
                  }}
                >
                  <CalendarRange className="w-2.5 h-2.5" style={{ color: 'hsl(var(--chart-1))' }} />
                </div>
              </TooltipTrigger>
              <TooltipContent side="top" className="z-50">
                <p className="font-medium">Eval Start</p>
                <p className="text-xs text-muted-foreground">{format(parseISO(opportunity.evalStartDate), 'MMM d, yyyy')}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}

        {/* Eval end dot marker */}
        {evalEndPosition !== null && opportunity.evalEndDate && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-[15] w-5 h-5 rounded-full border-2 flex items-center justify-center cursor-help"
                  style={{
                    left: `${evalEndPosition}%`,
                    top: '50%',
                    backgroundColor: 'hsl(var(--chart-1) / 0.2)',
                    borderColor: 'hsl(var(--chart-1))',
                  }}
                >
                  <CalendarRange className="w-2.5 h-2.5" style={{ color: 'hsl(var(--chart-1))' }} />
                </div>
              </TooltipTrigger>
              <TooltipContent side="top" className="z-50">
                <p className="font-medium">Eval End</p>
                <p className="text-xs text-muted-foreground">{format(parseISO(opportunity.evalEndDate), 'MMM d, yyyy')}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}

        {/* Today diamond (green) */}
        {todayPosition >= 0 && todayPosition <= 100 && (
          <DiamondMarker
            type="today"
            date={today}
            style={{ left: `${todayPosition}%`, top: '50%' }}
          />
        )}
        
        {/* Close date diamond (red) */}
        {timelineDates.closeDate && closeDatePosition !== null && (
          <DiamondMarker
            type="closeDate"
            date={timelineDates.closeDate}
            isOverdue={timelineDates.isOverdue}
            style={{ left: `${closeDatePosition}%`, top: '50%' }}
          />
        )}
      </div>

      {/* Row 3: Account info, Team members, Missing signals, Missing criteria */}
      <div className="mt-2 flex items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-4">
          {showAccountInfo && (
            <Link 
              to={`/accounts/${opportunity.accountId}`}
              className="flex items-center gap-1 text-muted-foreground hover:underline"
            >
              <Building2 className="w-3 h-3" />
              {opportunity.accountName}
            </Link>
          )}
          
          {/* AE & SE Names */}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <User className="w-3 h-3" />
                  <span className="font-medium">AE:</span>
                  <span>{extractName(opportunity.ownerEmail)}</span>
                </div>
              </TooltipTrigger>
              <TooltipContent>{opportunity.ownerEmail || 'No AE assigned'}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Users className="w-3 h-3" />
                  <span className="font-medium">SE:</span>
                  <span>{extractName(opportunity.primarySeEmail)}</span>
                </div>
              </TooltipTrigger>
              <TooltipContent>{opportunity.primarySeEmail || 'No SE assigned'}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          {/* Product mentions count */}
          {opportunity.productMentions.length > 0 && (
            <div className="flex items-center gap-1 text-muted-foreground">
              <img src={pendoLogo} alt="Pendo" className="w-3 h-3 object-contain" />
              <span>{opportunity.productMentions.length} product{opportunity.productMentions.length !== 1 ? 's' : ''}</span>
            </div>
          )}

          {/* Eval pending alert */}
          {hasPendingEval && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge variant="outline" className="h-5 text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30 cursor-help">
                    <CalendarRange className="w-2.5 h-2.5 mr-1" />
                    Eval Pending
                  </Badge>
                </TooltipTrigger>
                <TooltipContent side="top" className="max-w-xs z-50">
                  <p className="font-medium text-amber-600">Evaluation Quote Exists</p>
                  <p className="text-xs text-muted-foreground mt-1">A primary eval quote has been provided but no eval start date has been set yet.</p>
                  {opportunity.primaryEvalQuote && (
                    <p className="text-xs italic mt-1">"{opportunity.primaryEvalQuote}"</p>
                  )}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}

          {/* Eval active indicator */}
          {opportunity.evalStartDate && !opportunity.evalEndDate && (
            <Badge variant="outline" className="h-5 text-[10px] bg-orange-500/10 text-orange-600 border-orange-500/30">
              <CalendarRange className="w-2.5 h-2.5 mr-1" />
              Eval Active
            </Badge>
          )}

          {/* Eval completed indicator */}
          {opportunity.evalEndDate && (
            <Badge variant="outline" className="h-5 text-[10px] bg-green-500/10 text-green-600 border-green-500/30">
              <CalendarRange className="w-2.5 h-2.5 mr-1" />
              Eval Complete
            </Badge>
          )}
          
          {/* Signals NOT detected */}
          {missingSignalTypes.length > 0 && (
            <div className="flex items-center gap-1.5 text-muted-foreground/60">
              <span className="font-medium">Not detected:</span>
              {missingSignalTypes.map(type => {
                const Icon = SIGNAL_ICONS[type];
                const label = type === 'reverse_demo' ? 'Rev Demo' : type === 'evaluation' ? 'Eval' : 'Demo';
                return (
                  <div key={type} className="flex items-center gap-0.5 opacity-50">
                    <Icon className="w-3 h-3" />
                    <span>{label}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
        
        {/* Missing criteria */}
        {opportunity.missingExitCriteria.length > 0 && (
          <div className="flex items-center gap-1 flex-wrap justify-end">
            {opportunity.missingExitCriteria.slice(0, 2).map((criteria, i) => (
              <Badge 
                key={i} 
                variant="outline" 
                className="text-[10px] h-5 bg-destructive/10 text-destructive border-destructive/30"
              >
                <XCircle className="w-2.5 h-2.5 mr-0.5" />
                {criteria}
              </Badge>
            ))}
            {opportunity.missingExitCriteria.length > 2 && (
              <span className="text-[10px] text-destructive">+{opportunity.missingExitCriteria.length - 2} more</span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

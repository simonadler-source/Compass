import { useState, useMemo } from 'react';
import { useCEPOpportunities, useCEPOwners, useCEPPrimarySEs, CEPFilters, useCEPSignalTypes } from '@/hooks/useCEPOpportunities';
import pendoLogo from '@/assets/pendo-logo.png';
import { CEPSimpleCard } from './CEPSimpleCard';
import { CEP_STAGES, CEP_PHASES } from '@/lib/cepConfig';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Filter, 
  ChevronDown, 
  AlertTriangle,
  Target,
  Presentation,
  FlaskConical,
  Clock,
  Users,
  Layers,
  Search,
  X,
  UsersRound,
  Scale,
  Shield,
  Wrench,
  Workflow,
  FileText,
  DollarSign,
  PlayCircle,
  CheckCircle,
  XCircle,
  Zap,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTeamMembers } from '@/hooks/useTeamMembers';

// Default icon for signals without a specific mapping
const DEFAULT_SIGNAL_ICON = Zap;

// Icon mapping by signal field name or rule key patterns
function getSignalIcon(key: string): LucideIcon {
  const lower = key.toLowerCase();
  if (lower.includes('demo') && lower.includes('reverse')) return Presentation;
  if (lower.includes('demo')) return Target;
  if (lower.includes('eval') || lower.includes('poc')) return FlaskConical;
  if (lower.includes('legal')) return Scale;
  if (lower.includes('security')) return Shield;
  if (lower.includes('tech')) return Wrench;
  if (lower.includes('process')) return Workflow;
  if (lower.includes('nda')) return FileText;
  if (lower.includes('pricing')) return DollarSign;
  if (lower.includes('dry')) return PlayCircle;
  if (lower.includes('win')) return CheckCircle;
  if (lower.includes('loss')) return XCircle;
  return DEFAULT_SIGNAL_ICON;
}

type GroupBy = 'none' | 'stage' | 'phase' | 'gap_status' | 'ae_manager' | 'se_manager';

// Pre-sales stage options for filtering
const PRE_SALES_STAGE_OPTIONS = [
  { value: 'Discovery', label: 'Discovery' },
  { value: 'Demo', label: 'Demo' },
  { value: 'Proof - Scoping', label: 'Proof - Scoping' },
  { value: 'Proof', label: 'Proof' },
  { value: 'Technical Win', label: 'Technical Win' },
  { value: 'Technical Loss', label: 'Technical Loss' },
  { value: 'Unqualified', label: 'Unqualified' },
];

interface CEPTimelineTabProps {
  /** External signal type filter - synced from parent */
  externalSignalTypeFilter?: string[];
  /** Callback when signal type filter changes internally */
  onSignalTypeFilterChange?: (types: string[]) => void;
}

export function CEPTimelineTab({ 
  externalSignalTypeFilter,
  onSignalTypeFilterChange,
}: CEPTimelineTabProps = {}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [stageFilter, setStageFilter] = useState<number[]>([]);
  const [preSalesStageFilter, setPreSalesStageFilter] = useState<string[]>([]);
  const [ownerFilter, setOwnerFilter] = useState<string[]>([]);
  const [primarySEFilter, setPrimarySEFilter] = useState<string[]>([]);
  const [internalSignalTypeFilter, setInternalSignalTypeFilter] = useState<string[]>([]);
  const [showMyTeamOnly, setShowMyTeamOnly] = useState(false);
  const [hasProductMentionsOnly, setHasProductMentionsOnly] = useState(false);
  const [hasGapsOnly, setHasGapsOnly] = useState(false);
  const [stuckDays, setStuckDays] = useState<number | null>(null);
  const [groupBy, setGroupBy] = useState<GroupBy>('none');
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set(['all']));

  // Use external filter if provided, otherwise use internal
  const signalTypeFilter = externalSignalTypeFilter ?? internalSignalTypeFilter;

  // Get team members for "My Team" filter
  const { teamEmailsWithSelf, isLoading: teamLoading } = useTeamMembers();
  
  // Get dynamic signal types from detection rules
  const { data: signalTypes = [], isLoading: signalTypesLoading } = useCEPSignalTypes();

  const filters: CEPFilters = {
    stageFilter: stageFilter.length > 0 ? stageFilter : null,
    ownerFilter: ownerFilter.length > 0 ? ownerFilter : null,
    teamEmails: showMyTeamOnly ? teamEmailsWithSelf : null,
    hasGaps: hasGapsOnly,
    stuckThresholdDays: stuckDays,
  };

  const { data: opportunities = [], isLoading, error } = useCEPOpportunities(filters);
  const { data: owners = [] } = useCEPOwners();
  const { data: primarySEs = [] } = useCEPPrimarySEs();

  // Apply search, signal type, pre-sales stage, and primary SE filters
  const filteredOpportunities = useMemo(() => {
    let result = opportunities;
    
    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(opp =>
        opp.name.toLowerCase().includes(query) ||
        opp.accountName.toLowerCase().includes(query)
      );
    }
    
    // Filter by signal types (by rule ID)
    if (signalTypeFilter.length > 0) {
      result = result.filter(opp =>
        opp.signals.some(signal => signalTypeFilter.includes(signal.ruleId))
      );
    }

    // Filter by pre-sales stage
    if (preSalesStageFilter.length > 0) {
      result = result.filter(opp =>
        opp.preSalesStage && preSalesStageFilter.some(stage => 
          opp.preSalesStage?.toLowerCase() === stage.toLowerCase()
        )
      );
    }

    // Filter by primary SE
    if (primarySEFilter.length > 0) {
      result = result.filter(opp =>
        opp.primarySeEmail && primarySEFilter.includes(opp.primarySeEmail)
      );
    }

    // Filter by Pendo product mentions (owned products only)
    if (hasProductMentionsOnly) {
      result = result.filter(opp => 
        opp.productMentions && 
        opp.productMentions.some(pm => pm.mentionType === 'owned')
      );
    }

    return result;
  }, [opportunities, searchQuery, signalTypeFilter, preSalesStageFilter, primarySEFilter, hasProductMentionsOnly]);

  // Group opportunities
  const groupedOpportunities = useMemo(() => {
    if (groupBy === 'none') {
      return [{ key: 'all', label: 'All Opportunities', items: filteredOpportunities }];
    }

    const groups = new Map<string, typeof filteredOpportunities>();
    
    filteredOpportunities.forEach(opp => {
      let groupKey: string;

      if (groupBy === 'stage') {
        const stage = opp.crmStage ?? opp.inferredStage ?? 0;
        groupKey = `stage_${stage}`;
      } else if (groupBy === 'phase') {
        const stage = opp.crmStage ?? opp.inferredStage ?? 0;
        const stageConfig = CEP_STAGES[stage];
        groupKey = stageConfig?.phase || 'pipeline_generation';
      } else if (groupBy === 'ae_manager') {
        groupKey = opp.ownerManagerEmail || 'unassigned';
      } else if (groupBy === 'se_manager') {
        groupKey = opp.seManagerEmail || 'unassigned';
      } else {
        // gap_status
        const hasGap = opp.missingExitCriteria.length > 0 || Math.abs(opp.stageDiscrepancy) >= 2;
        groupKey = hasGap ? 'gaps' : 'on_track';
      }

      if (!groups.has(groupKey)) {
        groups.set(groupKey, []);
      }
      groups.get(groupKey)!.push(opp);
    });

    return Array.from(groups.entries())
      .map(([key, items]) => {
        let label = key;
        if (groupBy === 'stage') {
          label = `Stage ${key.replace('stage_', '')}`;
        } else if (groupBy === 'phase' && CEP_PHASES[key as keyof typeof CEP_PHASES]) {
          label = CEP_PHASES[key as keyof typeof CEP_PHASES].label;
        } else if (key === 'gaps') {
          label = 'Has Gaps';
        } else if (key === 'on_track') {
          label = 'On Track';
        } else if (key === 'unassigned') {
          label = 'Unassigned';
        } else if (groupBy === 'ae_manager' || groupBy === 'se_manager') {
          // Format email to name
          const localPart = key.split('@')[0];
          label = localPart.includes('.') 
            ? localPart.split('.').map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(' ')
            : localPart;
        }
        return { key, label, items };
      })
      .sort((a, b) => {
        if (groupBy === 'stage') {
          return parseInt(a.key.replace('stage_', '')) - parseInt(b.key.replace('stage_', ''));
        }
        if (a.key === 'unassigned') return 1;
        if (b.key === 'unassigned') return -1;
        return a.label.localeCompare(b.label);
      });
  }, [filteredOpportunities, groupBy]);

  const toggleGroup = (key: string) => {
    setExpandedGroups(prev => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  const clearFilters = () => {
    setSearchQuery('');
    setStageFilter([]);
    setPreSalesStageFilter([]);
    setOwnerFilter([]);
    setPrimarySEFilter([]);
    // Only clear internal filter if not externally controlled
    if (!externalSignalTypeFilter) {
      setInternalSignalTypeFilter([]);
    }
    if (onSignalTypeFilterChange) {
      onSignalTypeFilterChange([]);
    }
    setShowMyTeamOnly(false);
    setHasProductMentionsOnly(false);
    setHasGapsOnly(false);
    setStuckDays(null);
  };

  const toggleSignalTypeFilter = (ruleId: string) => {
    const newFilter = signalTypeFilter.includes(ruleId)
      ? signalTypeFilter.filter(t => t !== ruleId)
      : [...signalTypeFilter, ruleId];
    
    if (onSignalTypeFilterChange) {
      onSignalTypeFilterChange(newFilter);
    } else {
      setInternalSignalTypeFilter(newFilter);
    }
  };

  const hasActiveFilters = searchQuery || stageFilter.length > 0 || preSalesStageFilter.length > 0 || ownerFilter.length > 0 || primarySEFilter.length > 0 || signalTypeFilter.length > 0 || showMyTeamOnly || hasProductMentionsOnly || hasGapsOnly || stuckDays;

  // Summary stats
  const stats = useMemo(() => {
    const withGaps = filteredOpportunities.filter(
      o => o.missingExitCriteria.length > 0 || Math.abs(o.stageDiscrepancy) >= 2
    ).length;
    const withSignals = filteredOpportunities.filter(o => o.signals.length > 0).length;
    const stuck = filteredOpportunities.filter(o => o.daysInCurrentStage !== null && o.daysInCurrentStage > 30).length;
    
    return { withGaps, withSignals, stuck, total: filteredOpportunities.length };
  }, [filteredOpportunities]);

  if (error) {
    return (
      <Card className="border-destructive">
        <CardContent className="pt-6">
          <div className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="w-5 h-5" />
            <span>Failed to load CEP timeline data</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-semibold">CEP Process Timeline</h2>
        <p className="text-sm text-muted-foreground">
          Visualize opportunity alignment with the Customer Engagement Process
        </p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3">
              <Layers className="w-8 h-8 text-primary" />
              <div>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-xs text-muted-foreground">Opportunities</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3">
              <FlaskConical className="w-8 h-8 text-chart-1" />
              <div>
                <p className="text-2xl font-bold">{stats.withSignals}</p>
                <p className="text-xs text-muted-foreground">With Signals</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className={cn(stats.withGaps > 0 && 'border-orange-500')}>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3">
              <AlertTriangle className={cn('w-8 h-8', stats.withGaps > 0 ? 'text-orange-600' : 'text-muted-foreground')} />
              <div>
                <p className="text-2xl font-bold">{stats.withGaps}</p>
                <p className="text-xs text-muted-foreground">With Gaps</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className={cn(stats.stuck > 0 && 'border-orange-500')}>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3">
              <Clock className={cn('w-8 h-8', stats.stuck > 0 ? 'text-orange-600' : 'text-muted-foreground')} />
              <div>
                <p className="text-2xl font-bold">{stats.stuck}</p>
                <p className="text-xs text-muted-foreground">Stuck (&gt;30d)</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-4 space-y-3">
          <div className="flex flex-wrap items-center gap-4">
            {/* Search */}
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search opportunities or accounts..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>

            {/* Stage filter */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Stage
                  {stageFilter.length > 0 && (
                    <Badge variant="secondary" className="ml-2">
                      {stageFilter.length}
                    </Badge>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuLabel>Filter by Stage</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {CEP_STAGES.map(stage => (
                  <DropdownMenuCheckboxItem
                    key={stage.id}
                    checked={stageFilter.includes(stage.id)}
                    onCheckedChange={checked => {
                      setStageFilter(prev =>
                        checked
                          ? [...prev, stage.id]
                          : prev.filter(s => s !== stage.id)
                      );
                    }}
                  >
                    <span 
                      className="w-2 h-2 rounded-full mr-2"
                      style={{ backgroundColor: CEP_PHASES[stage.phase].color }}
                    />
                    {stage.name}
                  </DropdownMenuCheckboxItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Pre-Sales Stage filter */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Target className="w-4 h-4 mr-2" />
                  Pre-Sales Stage
                  {preSalesStageFilter.length > 0 && (
                    <Badge variant="secondary" className="ml-2">
                      {preSalesStageFilter.length}
                    </Badge>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuLabel>Filter by Pre-Sales Stage</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {PRE_SALES_STAGE_OPTIONS.map(stage => (
                  <DropdownMenuCheckboxItem
                    key={stage.value}
                    checked={preSalesStageFilter.includes(stage.value)}
                    onCheckedChange={checked => {
                      setPreSalesStageFilter(prev =>
                        checked
                          ? [...prev, stage.value]
                          : prev.filter(s => s !== stage.value)
                      );
                    }}
                  >
                    {stage.label}
                  </DropdownMenuCheckboxItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>


            {owners.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Users className="w-4 h-4 mr-2" />
                    Owner
                    {ownerFilter.length > 0 && (
                      <Badge variant="secondary" className="ml-2">
                        {ownerFilter.length}
                      </Badge>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="max-h-64 overflow-auto">
                  <DropdownMenuLabel>Filter by Owner</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {owners.map(owner => (
                    <DropdownMenuCheckboxItem
                      key={owner}
                      checked={ownerFilter.includes(owner)}
                      onCheckedChange={checked => {
                        setOwnerFilter(prev =>
                          checked
                            ? [...prev, owner]
                            : prev.filter(o => o !== owner)
                        );
                      }}
                    >
                      {owner}
                    </DropdownMenuCheckboxItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {/* Primary SE filter */}
            {primarySEs.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Wrench className="w-4 h-4 mr-2" />
                    Primary SE
                    {primarySEFilter.length > 0 && (
                      <Badge variant="secondary" className="ml-2">
                        {primarySEFilter.length}
                      </Badge>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="max-h-64 overflow-auto">
                  <DropdownMenuLabel>Filter by Primary SE</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {primarySEs.map(se => (
                    <DropdownMenuCheckboxItem
                      key={se}
                      checked={primarySEFilter.includes(se)}
                      onCheckedChange={checked => {
                        setPrimarySEFilter(prev =>
                          checked
                            ? [...prev, se]
                            : prev.filter(s => s !== se)
                        );
                      }}
                    >
                      {se}
                    </DropdownMenuCheckboxItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {/* My Team Only toggle */}
            <div className="flex items-center gap-2">
              <Switch
                id="my-team-only"
                checked={showMyTeamOnly}
                onCheckedChange={setShowMyTeamOnly}
                disabled={teamLoading}
              />
              <Label htmlFor="my-team-only" className="text-sm cursor-pointer flex items-center gap-1">
                <UsersRound className="w-3.5 h-3.5" />
                My Team
              </Label>
            </div>

            {/* Gap filter toggle */}
            <div className="flex items-center gap-2">
              <Switch
                id="gaps-only"
                checked={hasGapsOnly}
                onCheckedChange={setHasGapsOnly}
              />
              <Label htmlFor="gaps-only" className="text-sm cursor-pointer">
                Gaps only
              </Label>
            </div>

            {/* Stuck threshold */}
            <Select
              value={stuckDays?.toString() || 'none'}
              onValueChange={val => setStuckDays(val === 'none' ? null : parseInt(val))}
            >
              <SelectTrigger className="w-[140px]">
                <Clock className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Stuck..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Any duration</SelectItem>
                <SelectItem value="7">≥ 7 days</SelectItem>
                <SelectItem value="14">≥ 14 days</SelectItem>
                <SelectItem value="30">≥ 30 days</SelectItem>
                <SelectItem value="60">≥ 60 days</SelectItem>
              </SelectContent>
            </Select>

            {/* Group by */}
            <Select value={groupBy} onValueChange={v => setGroupBy(v as GroupBy)}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Group by..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No grouping</SelectItem>
                <SelectItem value="stage">By Stage</SelectItem>
                <SelectItem value="phase">By Phase</SelectItem>
                <SelectItem value="gap_status">By Gap Status</SelectItem>
                <SelectItem value="ae_manager">By AE Manager</SelectItem>
                <SelectItem value="se_manager">By SE Manager</SelectItem>
              </SelectContent>
            </Select>

            {/* Clear filters */}
            {hasActiveFilters && (
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                <X className="w-4 h-4 mr-1" />
                Clear
              </Button>
            )}
          </div>
          
          {/* Signal Type Legend - Clickable Filters */}
          <div className="flex flex-wrap items-center gap-1 pt-2 border-t">
            <span className="text-xs text-muted-foreground mr-2">Filter by signal:</span>
            {signalTypesLoading ? (
              <span className="text-xs text-muted-foreground">Loading...</span>
            ) : (
              signalTypes.map((signalType) => {
                const Icon = getSignalIcon(signalType.key);
                const isActive = signalTypeFilter.includes(signalType.id);
                
                return (
                  <TooltipProvider key={signalType.id}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button
                          onClick={() => toggleSignalTypeFilter(signalType.id)}
                          className={cn(
                            'flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium transition-all border',
                            isActive
                              ? 'border-current'
                              : 'text-muted-foreground bg-muted/50 border-transparent hover:bg-muted'
                          )}
                          style={isActive ? { color: signalType.color, backgroundColor: `${signalType.color}15`, borderColor: signalType.color } : undefined}
                        >
                          <Icon className="w-3 h-3" />
                          <span>{signalType.name}</span>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{isActive ? 'Remove filter' : `Show opportunities with ${signalType.name} signals`}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                );
              })
            )}
            
            {/* Pendo Product Mentions Filter */}
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => setHasProductMentionsOnly(!hasProductMentionsOnly)}
                    className={cn(
                      'flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium transition-all border ml-2',
                      hasProductMentionsOnly
                        ? 'text-pink-600 bg-pink-500/15 border-pink-500'
                        : 'text-muted-foreground bg-muted/50 border-transparent hover:bg-muted'
                    )}
                  >
                    <img src={pendoLogo} alt="Pendo" className="w-3 h-3 object-contain" />
                    <span>Pendo product mentions</span>
                  </button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{hasProductMentionsOnly ? 'Remove filter' : 'Show opportunities with Pendo product mentions'}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </CardContent>
      </Card>

      {/* Opportunities list */}
      {isLoading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      ) : filteredOpportunities.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Layers className="w-12 h-12 mx-auto text-muted-foreground opacity-50" />
            <p className="mt-4 text-muted-foreground">
              {hasActiveFilters
                ? 'No opportunities match your filters'
                : 'No opportunities found'}
            </p>
            {hasActiveFilters && (
              <Button variant="outline" className="mt-4" onClick={clearFilters}>
                Clear filters
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {groupedOpportunities.map(group => (
            <Collapsible
              key={group.key}
              open={expandedGroups.has(group.key)}
              onOpenChange={() => toggleGroup(group.key)}
            >
              {groupBy !== 'none' && (
                <CollapsibleTrigger asChild>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-between px-4 py-2 h-auto hover:bg-muted/50"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{group.label}</span>
                      <Badge variant="secondary">{group.items.length}</Badge>
                    </div>
                    <ChevronDown className={cn(
                      'w-4 h-4 transition-transform',
                      expandedGroups.has(group.key) && 'rotate-180'
                    )} />
                  </Button>
                </CollapsibleTrigger>
              )}
              <CollapsibleContent className="space-y-3 pt-2">
                {group.items.map(opportunity => (
                  <CEPSimpleCard key={opportunity.id} opportunity={opportunity} />
                ))}
              </CollapsibleContent>
            </Collapsible>
          ))}
        </div>
      )}
    </div>
  );
}

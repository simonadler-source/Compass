import { useMemo, useState } from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { CEPSignal } from '@/hooks/useCEPOpportunities';
import { CEPSignalType } from '@/lib/cepConfig';
import { 
  Target, 
  Presentation, 
  FlaskConical, 
  Scale,
  Shield,
  Wrench,
  Workflow,
  FileText,
  DollarSign,
  PlayCircle,
  Layers,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, formatDistanceToNow } from 'date-fns';

const SIGNAL_ICONS: Record<CEPSignalType, LucideIcon> = {
  demo: Target,
  demo_delivered: PlayCircle,
  reverse_demo: Presentation,
  evaluation: FlaskConical,
  legal: Scale,
  security: Shield,
  technical_discovery: Wrench,
  process_discovery: Workflow,
  nda: FileText,
  pricing: DollarSign,
  dry_run: PlayCircle,
  eval_active: FlaskConical,
  eval_pending: Layers,
};

const SIGNAL_COLORS: Record<CEPSignalType, string> = {
  demo: 'text-white bg-emerald-500 border-emerald-600 shadow-emerald-500/50',
  demo_delivered: 'text-white bg-green-600 border-green-700 shadow-green-600/50',
  reverse_demo: 'text-white bg-blue-500 border-blue-600 shadow-blue-500/50',
  evaluation: 'text-white bg-amber-500 border-amber-600 shadow-amber-500/50',
  legal: 'text-white bg-indigo-500 border-indigo-600 shadow-indigo-500/50',
  security: 'text-white bg-cyan-500 border-cyan-600 shadow-cyan-500/50',
  technical_discovery: 'text-white bg-teal-500 border-teal-600 shadow-teal-500/50',
  process_discovery: 'text-white bg-orange-500 border-orange-600 shadow-orange-500/50',
  nda: 'text-white bg-violet-500 border-violet-600 shadow-violet-500/50',
  pricing: 'text-white bg-rose-500 border-rose-600 shadow-rose-500/50',
  dry_run: 'text-white bg-lime-500 border-lime-600 shadow-lime-500/50',
  eval_active: 'text-white bg-orange-600 border-orange-700 shadow-orange-600/50',
  eval_pending: 'text-white bg-yellow-500 border-yellow-600 shadow-yellow-500/50',
};

// Readable signal type labels
const SIGNAL_LABELS: Record<CEPSignalType, string> = {
  demo: 'Demo Request',
  demo_delivered: 'Demo Delivered',
  reverse_demo: 'Reverse Demo',
  evaluation: 'Evaluation',
  legal: 'Legal',
  security: 'Security',
  technical_discovery: 'Tech Discovery',
  process_discovery: 'Process Discovery',
  nda: 'NDA',
  pricing: 'Pricing',
  dry_run: 'Dry Run',
  eval_active: 'Evaluation Active',
  eval_pending: 'Eval Pending (Quote)',
};

interface SignalClusterProps {
  signals: CEPSignal[];
  leftPercent: number;
  showDate?: boolean;
}

// Single signal dot for when there's just one signal
function SingleSignalDot({ 
  signal, 
  leftPercent,
  showDate = false,
}: { 
  signal: CEPSignal;
  leftPercent: number;
  showDate?: boolean;
}) {
  const Icon = SIGNAL_ICONS[signal.type];
  const colorClass = SIGNAL_COLORS[signal.type];
  const occurrenceCount = signal.occurrenceCount || signal.occurrences?.length || 1;
  const hasMultiple = occurrenceCount > 1;
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div 
            className="absolute -translate-x-1/2 z-10 flex flex-col items-center"
            style={{ left: `${leftPercent}%`, top: '-6px' }}
          >
            <div className="relative">
              <div className={cn(
                'w-5 h-5 rounded-full flex items-center justify-center cursor-pointer border-2 shadow-md',
                colorClass
              )}>
                <Icon className="w-3 h-3" />
              </div>
              {hasMultiple && (
                <div className="absolute -top-1.5 -right-1.5 min-w-[14px] h-[14px] rounded-full bg-slate-800 text-white text-[9px] font-bold flex items-center justify-center px-0.5 border border-white shadow-sm">
                  {occurrenceCount}
                </div>
              )}
            </div>
            {showDate && (
              <span className="text-[7px] text-muted-foreground mt-0.5 whitespace-nowrap">
                {format(new Date(signal.detectedAt), 'M/d')}
              </span>
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-sm z-50">
          <div className="space-y-1">
            <p className="font-medium text-sm">{SIGNAL_LABELS[signal.type]}</p>
            {signal.speakerName && (
              <p className="text-xs text-muted-foreground">
                {signal.speakerType === 'external' ? 'Customer: ' : 'Pendo: '}
                {signal.speakerName}
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              {format(new Date(signal.detectedAt), 'MMM d, yyyy')}
            </p>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Cluster icon that expands on hover to show all signals
function ClusterIcon({ 
  signals, 
  leftPercent,
  showDate = false,
}: { 
  signals: CEPSignal[];
  leftPercent: number;
  showDate?: boolean;
}) {
  const [isHovered, setIsHovered] = useState(false);
  
  // Get date range for the cluster
  const dateRange = useMemo(() => {
    const dates = signals.map(s => new Date(s.detectedAt)).sort((a, b) => a.getTime() - b.getTime());
    const earliest = dates[0];
    const latest = dates[dates.length - 1];
    
    // If same day, show single date
    if (format(earliest, 'M/d') === format(latest, 'M/d')) {
      return format(earliest, 'M/d');
    }
    return `${format(earliest, 'M/d')}-${format(latest, 'M/d')}`;
  }, [signals]);
  
  // Count by type for summary
  const typeCounts = useMemo(() => {
    const counts = new Map<CEPSignalType, number>();
    signals.forEach(s => {
      counts.set(s.type, (counts.get(s.type) || 0) + 1);
    });
    return Array.from(counts.entries());
  }, [signals]);
  
  return (
    <div 
      className="absolute -translate-x-1/2 z-10 flex flex-col items-center"
      style={{ left: `${leftPercent}%`, top: '-6px' }}
    >
      <HoverCard openDelay={100} closeDelay={200}>
        <HoverCardTrigger asChild>
          <div 
            className="relative cursor-pointer"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            {/* Stacked cluster visualization */}
            <div className="relative">
              {/* Background layers to create stack effect */}
              <div className="absolute -top-0.5 -left-0.5 w-5 h-5 rounded-full bg-slate-400/50 border border-white" />
              <div className="absolute -top-0.25 -left-0.25 w-5 h-5 rounded-full bg-slate-500/50 border border-white" />
              
              {/* Main cluster icon */}
              <div className={cn(
                'w-5 h-5 rounded-full flex items-center justify-center border-2 shadow-md relative',
                'bg-gradient-to-br from-purple-500 to-indigo-600 border-purple-700 text-white',
                isHovered && 'scale-110 ring-2 ring-purple-300'
              )}>
                <Layers className="w-3 h-3" />
              </div>
              
              {/* Count badge */}
              <div className="absolute -top-1.5 -right-1.5 min-w-[14px] h-[14px] rounded-full bg-slate-800 text-white text-[9px] font-bold flex items-center justify-center px-0.5 border border-white shadow-sm">
                {signals.length}
              </div>
            </div>
          </div>
        </HoverCardTrigger>
        
        <HoverCardContent 
          side="top" 
          align="center" 
          className="w-auto min-w-[200px] max-w-[280px] p-3 z-50"
        >
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2 border-b border-border pb-2">
              <span className="font-medium text-sm">{signals.length} Signals</span>
              <span className="text-xs text-muted-foreground">{dateRange}</span>
            </div>
            
            {/* List each signal with icon, type, and person */}
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {signals.map((signal, idx) => {
                const Icon = SIGNAL_ICONS[signal.type];
                const colorClass = SIGNAL_COLORS[signal.type];
                
                return (
                  <div key={signal.id || idx} className="flex items-center gap-2 py-1">
                    <div className={cn(
                      'w-4 h-4 rounded-full flex items-center justify-center shrink-0',
                      colorClass
                    )}>
                      <Icon className="w-2.5 h-2.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-medium truncate">
                          {SIGNAL_LABELS[signal.type]}
                        </span>
                        <span className="text-[10px] text-muted-foreground shrink-0">
                          {format(new Date(signal.detectedAt), 'M/d')}
                        </span>
                      </div>
                      {signal.speakerName && (
                        <p className="text-[10px] text-muted-foreground truncate">
                          {signal.speakerType === 'external' ? '👤 ' : '🏢 '}
                          {signal.speakerName}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            
            {/* Type summary at bottom */}
            <div className="flex flex-wrap gap-1 pt-1.5 border-t border-border">
              {typeCounts.map(([type, count]) => {
                const Icon = SIGNAL_ICONS[type];
                return (
                  <div 
                    key={type}
                    className={cn(
                      'inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px]',
                      SIGNAL_COLORS[type]
                    )}
                  >
                    <Icon className="w-2.5 h-2.5" />
                    <span>{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </HoverCardContent>
      </HoverCard>
      
      {showDate && (
        <span className="text-[7px] text-muted-foreground mt-0.5 whitespace-nowrap">
          {dateRange}
        </span>
      )}
    </div>
  );
}

/**
 * SignalCluster - Renders either a single signal dot or a cluster icon
 * based on the number of signals. Clusters expand on hover to show details.
 */
export function SignalCluster({ signals, leftPercent, showDate = false }: SignalClusterProps) {
  if (signals.length === 0) return null;
  
  // Single signal: render as normal dot
  if (signals.length === 1) {
    return (
      <SingleSignalDot 
        signal={signals[0]} 
        leftPercent={leftPercent} 
        showDate={showDate}
      />
    );
  }
  
  // Two signals: render both individually with slight offset
  if (signals.length === 2) {
    return (
      <>
        <SingleSignalDot 
          signal={signals[0]} 
          leftPercent={Math.max(2, leftPercent - 1.5)} 
          showDate={false}
        />
        <SingleSignalDot 
          signal={signals[1]} 
          leftPercent={Math.min(98, leftPercent + 1.5)} 
          showDate={showDate}
        />
      </>
    );
  }
  
  // Three or more: render as cluster
  return (
    <ClusterIcon 
      signals={signals} 
      leftPercent={leftPercent} 
      showDate={showDate}
    />
  );
}

export default SignalCluster;

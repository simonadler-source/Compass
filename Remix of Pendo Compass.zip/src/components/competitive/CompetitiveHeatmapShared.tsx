import React from 'react';
import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { useCompetitorVendors, useCompetitiveRubric, type CompetitiveScore, type CompetitiveRubric } from '@/hooks/useCompetitiveScorecard';

// ── Shared Types ──────────────────────────────────────────────────────────

export interface ScoreCell {
  id: string;
  score: number;
  vendor: string;
  category: string;
  subcategory: string;
}

export interface AuditEntry {
  id: string;
  vendor_name: string;
  subcategory: string;
  rationale: string | null;
  evidence_url: string | null;
  source_type: string | null;
  current_score: number | null;
  file_score: number | null;
  file_score_term: string | null;
  validated_score: number | null;
  validated_score_term: string | null;
  audit_datetime: string;
  status: string | null;
  type: string | null;
}

export interface HeatmapRow {
  category: string;
  subcategory: string;
  isAverage: boolean;
  scores: Map<string, ScoreCell>;
}

// ── Heatmap color helper ───────────────────────────────────────────

export function getHeatmapStyle(score: number, isAverage: boolean): React.CSSProperties {
  if (score === 0) return { backgroundColor: 'hsl(var(--muted))', color: 'hsl(var(--muted-foreground))' };
  const colors: [number, number, number][] = [
    [0, 0, 0],
    [220, 38, 38],
    [234, 88, 12],
    [202, 138, 4],
    [101, 163, 13],
    [22, 163, 74],
  ];
  const idx = Math.min(Math.max(Math.floor(score), 1), 5);
  const frac = score - Math.floor(score);
  let r: number, g: number, b: number;
  if (frac > 0 && idx < 5) {
    const [r1, g1, b1] = colors[idx];
    const [r2, g2, b2] = colors[idx + 1];
    r = Math.round(r1 + (r2 - r1) * frac);
    g = Math.round(g1 + (g2 - g1) * frac);
    b = Math.round(b1 + (b2 - b1) * frac);
  } else {
    [r, g, b] = colors[idx];
  }
  const opacity = isAverage ? 0.7 : 0.55;
  return {
    backgroundColor: `rgba(${r}, ${g}, ${b}, ${opacity})`,
    color: 'hsl(var(--foreground))',
  };
}

// ── Shared Data Hooks ─────────────────────────────────────────────

export function useHeatmapScores(activeVendors: string[]) {
  return useQuery({
    queryKey: ['heatmap-scores', activeVendors],
    queryFn: async () => {
      const results = await Promise.all(
        activeVendors.map(vendor =>
          gateway.from('competitive_scorecard')
            .select('*')
            .eq('vendor_name', vendor)
            .order('category')
            .execute()
            .then(res => ({
              vendor,
              scores: (res.data || []) as CompetitiveScore[],
              error: res.error,
            }))
        )
      );

      const scoreMap = new Map<string, Map<string, ScoreCell>>();
      for (const result of results) {
        if (result.error) continue;
        for (const s of result.scores) {
          const rowKey = `${s.category}|${s.subcategory}`;
          if (!scoreMap.has(rowKey)) scoreMap.set(rowKey, new Map());
          scoreMap.get(rowKey)!.set(result.vendor, {
            id: s.id,
            score: s.score,
            vendor: result.vendor,
            category: s.category,
            subcategory: s.subcategory,
          });
        }
      }
      return scoreMap;
    },
    enabled: activeVendors.length > 0,
  });
}

export type TrendDirection = 'up' | 'down' | 'stable' | 'pending_up' | 'pending_down' | null;

export interface HeatmapAuditData {
  auditMap: Map<string, AuditEntry>;
  trendMap: Map<string, TrendDirection>;
}

export function useHeatmapAudits(activeVendors: string[]) {
  return useQuery({
    queryKey: ['heatmap-audits', activeVendors],
    queryFn: async () => {
      const results = await Promise.all(
        activeVendors.map(vendor =>
          gateway.from('competitive_audit_log')
            .select('*')
            .eq('vendor_name', vendor)
            .order('audit_datetime', { ascending: false })
            .execute()
            .then(res => ({
              vendor,
              entries: (res.data || []) as AuditEntry[],
            }))
        )
      );

      const auditMap = new Map<string, AuditEntry>();
      const trendMap = new Map<string, TrendDirection>();

      for (const result of results) {
        // Group entries by subcategory for trend computation
        const subcatEntries = new Map<string, AuditEntry[]>();
        const seen = new Set<string>();

        for (const entry of result.entries) {
          const key = `${result.vendor}|${entry.subcategory}`;

          // Keep first (most recent) as the latest audit entry
          if (!seen.has(key)) {
            seen.add(key);
            auditMap.set(key, entry);
          }

          // Collect all entries per subcategory for trend analysis
          if (!subcatEntries.has(key)) subcatEntries.set(key, []);
          subcatEntries.get(key)!.push(entry);
        }

        // Compute trends per subcategory
        for (const [key, entries] of subcatEntries) {
          // Check for pending proposals first
          const pendingEntries = entries.filter(e => e.status === 'pending');
          const approvedEntries = entries.filter(e => e.status !== 'pending');

          if (pendingEntries.length > 0) {
            const proposedScore = pendingEntries[0].file_score ?? pendingEntries[0].validated_score;
            const currentScore = pendingEntries[0].current_score;
            if (proposedScore != null && currentScore != null) {
              if (proposedScore > currentScore) {
                trendMap.set(key, 'pending_up');
                continue;
              } else if (proposedScore < currentScore) {
                trendMap.set(key, 'pending_down');
                continue;
              }
            }
          }

          // For approved entries, compare earliest to most recent
          const scored = approvedEntries
            .filter(e => e.validated_score != null || e.current_score != null)
            .map(e => e.validated_score ?? e.current_score ?? 0);

          if (scored.length >= 2) {
            const earliest = scored[scored.length - 1]; // entries are desc order
            const latest = scored[0];
            if (latest > earliest) trendMap.set(key, 'up');
            else if (latest < earliest) trendMap.set(key, 'down');
            else trendMap.set(key, 'stable');
          }
        }
      }

      return { auditMap, trendMap } as HeatmapAuditData;
    },
    enabled: activeVendors.length > 0,
  });
}

export function useHeatmapRows(
  allScores: Map<string, Map<string, ScoreCell>> | undefined,
  searchTerm: string,
  activeVendors: string[]
) {
  return useMemo(() => {
    if (!allScores) return [] as HeatmapRow[];

    const categoryMap = new Map<string, HeatmapRow[]>();

    for (const [key, vendorScores] of allScores.entries()) {
      const [category, subcategory] = key.split('|');
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        if (!category.toLowerCase().includes(term) && !subcategory.toLowerCase().includes(term)) continue;
      }
      if (!categoryMap.has(category)) categoryMap.set(category, []);
      categoryMap.get(category)!.push({ category, subcategory, isAverage: false, scores: vendorScores });
    }

    const sortedCategories = Array.from(categoryMap.keys()).sort();
    const allRows: HeatmapRow[] = [];

    for (const category of sortedCategories) {
      const catRows = categoryMap.get(category)!;
      catRows.sort((a, b) => a.subcategory.localeCompare(b.subcategory));

      const avgScores = new Map<string, ScoreCell>();
      for (const vendor of activeVendors) {
        const scores = catRows.map(r => r.scores.get(vendor)?.score ?? 0).filter(s => s > 0);
        const avg = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
        avgScores.set(vendor, { id: `avg-${category}-${vendor}`, score: avg, vendor, category, subcategory: 'Category Average' });
      }
      allRows.push({ category, subcategory: 'Category Average', isAverage: true, scores: avgScores });
      allRows.push(...catRows);
    }
    return allRows;
  }, [allScores, searchTerm, activeVendors]);
}

export function useVendorTotals(
  allScores: Map<string, Map<string, ScoreCell>> | undefined,
  activeVendors: string[]
) {
  return useMemo(() => {
    const totals = new Map<string, number>();
    if (!allScores) return totals;

    // Group scores by category
    const categoryScores = new Map<string, Map<string, number[]>>();
    for (const [key, vendorScores] of allScores.entries()) {
      const category = key.split('|')[0];
      if (!categoryScores.has(category)) categoryScores.set(category, new Map());
      const catMap = categoryScores.get(category)!;
      for (const vendor of activeVendors) {
        if (!catMap.has(vendor)) catMap.set(vendor, []);
        const cell = vendorScores.get(vendor);
        if (cell && cell.score > 0) catMap.get(vendor)!.push(cell.score);
      }
    }

    const numCategories = categoryScores.size;
    if (numCategories === 0) return totals;

    for (const vendor of activeVendors) {
      let sumOfCategoryAverages = 0;
      for (const [, vendorMap] of categoryScores) {
        const scores = vendorMap.get(vendor) || [];
        if (scores.length > 0) {
          sumOfCategoryAverages += scores.reduce((a, b) => a + b, 0) / scores.length;
        }
      }
      // Normalize: max possible = numCategories * 5 (since scores are 1-5)
      totals.set(vendor, (sumOfCategoryAverages / (numCategories * 5)) * 100);
    }
    return totals;
  }, [allScores, activeVendors]);
}

export function useRubricMap() {
  const { data: rubrics } = useCompetitiveRubric();
  return useMemo(() => {
    if (!rubrics) return new Map<string, CompetitiveRubric>();
    return new Map(rubrics.map(r => [`${r.category}|${r.subcategory}`, r]));
  }, [rubrics]);
}

export { useCompetitorVendors, type CompetitiveRubric };

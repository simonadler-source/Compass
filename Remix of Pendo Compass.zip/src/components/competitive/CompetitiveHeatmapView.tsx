import { useState, useMemo, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Search, ChevronDown, Users, BarChart3, FileText, ExternalLink, Clock, Shield, TrendingUp, TrendingDown, Minus, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { gateway } from '@/lib/apiGateway';
import {
  getHeatmapStyle,
  useHeatmapScores,
  useHeatmapAudits,
  useHeatmapRows,
  useVendorTotals,
  useRubricMap,
  useCompetitorVendors,
  type ScoreCell,
  type AuditEntry,
  type CompetitiveRubric,
  type TrendDirection,
} from './CompetitiveHeatmapShared';

// ── Read-Only Score Cell ──────────────────────────────────────────

const SCORE_LABELS: Record<number, string> = {
  1: 'Basic',
  2: 'Developing',
  3: 'Established',
  4: 'Advanced',
  5: 'Market-Leading',
};

function useAuditHistory(vendor: string, subcategory: string, enabled: boolean) {
  return useQuery({
    queryKey: ['audit-history', vendor, subcategory],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('competitive_audit_log')
        .select('*')
        .eq('vendor_name', vendor)
        .eq('subcategory', subcategory)
        .order('audit_datetime', { ascending: true })
        .execute();
      if (error) throw error;
      return (data || []) as AuditEntry[];
    },
    enabled,
    staleTime: 60_000,
  });
}

function ScoreTrendIcon({ entries }: { entries: AuditEntry[] }) {
  if (entries.length < 2) return null;
  const scores = entries
    .filter(e => e.validated_score != null || e.current_score != null)
    .map(e => e.validated_score ?? e.current_score ?? 0);
  if (scores.length < 2) return null;
  const first = scores[0];
  const last = scores[scores.length - 1];
  if (last > first) return <TrendingUp className="w-3 h-3 text-primary" />;
  if (last < first) return <TrendingDown className="w-3 h-3 text-destructive" />;
  return <Minus className="w-3 h-3 text-muted-foreground" />;
}

function AuditEntryRow({ entry, isLast }: { entry: AuditEntry; isLast: boolean }) {
  const score = entry.validated_score ?? entry.file_score ?? entry.current_score;
  return (
    <div className={`py-1.5 ${!isLast ? 'border-b border-border/50' : ''}`}>
      <div className="flex items-center justify-between gap-2 mb-0.5">
        <span className="text-[10px] text-muted-foreground flex items-center gap-1">
          <Clock className="w-2.5 h-2.5" />
          {format(new Date(entry.audit_datetime), 'MMM d, yyyy')}
        </span>
        <div className="flex items-center gap-1">
          {entry.current_score != null && entry.validated_score != null && entry.current_score !== entry.validated_score && (
            <span className="text-[10px] font-mono text-muted-foreground">
              {entry.current_score}→{entry.validated_score}
            </span>
          )}
          {score != null && (
            <span
              className="text-[10px] font-bold font-mono px-1 py-0.5 rounded"
              style={getHeatmapStyle(score, false)}
            >
              {score}
            </span>
          )}
        </div>
      </div>
      {entry.rationale && (
        <p className="text-[11px] text-muted-foreground leading-snug">{entry.rationale}</p>
      )}
      <div className="flex flex-wrap gap-1.5 mt-0.5">
        {entry.source_type && (
          <Badge variant="outline" className="text-[9px] px-1 py-0">{entry.source_type}</Badge>
        )}
        {entry.evidence_url && (
          <a
            href={entry.evidence_url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-0.5 text-[10px] text-primary hover:underline"
            onClick={(e) => e.stopPropagation()}
          >
            <ExternalLink className="w-2.5 h-2.5" /> Evidence
          </a>
        )}
      </div>
    </div>
  );
}

function CellTrendIcon({ trend }: { trend: TrendDirection }) {
  if (!trend) return null;
  switch (trend) {
    case 'up':
      return <TrendingUp className="w-2.5 h-2.5 text-primary" />;
    case 'down':
      return <TrendingDown className="w-2.5 h-2.5 text-destructive" />;
    case 'stable':
      return <Minus className="w-2.5 h-2.5 text-muted-foreground/60" />;
    case 'pending_up':
      return <TrendingUp className="w-2.5 h-2.5 text-primary/50 animate-pulse" />;
    case 'pending_down':
      return <TrendingDown className="w-2.5 h-2.5 text-destructive/50 animate-pulse" />;
    default:
      return null;
  }
}

function ReadOnlyScoreCell({
  cell,
  hasAuditDot,
  rubric,
  trend,
}: {
  cell: ScoreCell;
  hasAuditDot: boolean;
  rubric: CompetitiveRubric | undefined;
  trend: TrendDirection;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const scoreLevel = Math.min(Math.max(Math.round(cell.score), 1), 5);
  const rubricDesc = rubric?.[`level_${scoreLevel}_description` as keyof CompetitiveRubric] as string | undefined;

  const { data: auditHistory, isLoading: historyLoading } = useAuditHistory(
    cell.vendor,
    cell.subcategory,
    isOpen,
  );

  return (
    <HoverCard openDelay={300} closeDelay={200} onOpenChange={setIsOpen}>
      <HoverCardTrigger asChild>
        <div
          className="w-full px-2 py-1.5 text-xs font-mono text-center relative cursor-help flex items-center justify-center gap-1"
          style={getHeatmapStyle(cell.score, false)}
        >
          <span>{cell.score}</span>
          <CellTrendIcon trend={trend} />
          {hasAuditDot && (
            <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-primary/70" />
          )}
        </div>
      </HoverCardTrigger>
      <HoverCardContent side="top" align="center" className="w-72 p-0">
        {/* Header: current score + rubric */}
        <div className="p-3 space-y-1.5 border-b border-border">
          <div className="flex items-center gap-1.5 text-xs font-medium">
            <BarChart3 className="w-3 h-3 text-primary" />
            <span>{cell.vendor} — {cell.subcategory}</span>
          </div>
          <div className="flex items-center gap-2">
            <span
              className="text-sm font-bold font-mono px-1.5 py-0.5 rounded"
              style={getHeatmapStyle(cell.score, false)}
            >
              {cell.score}/5
            </span>
            <Badge variant="outline" className="text-[9px] px-1 py-0">
              {SCORE_LABELS[scoreLevel] ?? `Level ${scoreLevel}`}
            </Badge>
            {auditHistory && <ScoreTrendIcon entries={auditHistory} />}
          </div>
          {rubricDesc && (
            <p className="text-[11px] text-muted-foreground leading-snug">{rubricDesc}</p>
          )}
        </div>

        {/* Changelog */}
        <div className="px-3 pt-2 pb-1">
          <div className="flex items-center gap-1.5 text-xs font-medium mb-1">
            <FileText className="w-3 h-3 text-primary" />
            Score History
            {auditHistory && auditHistory.length > 0 && (
              <span className="text-muted-foreground text-[10px]">({auditHistory.length})</span>
            )}
          </div>
        </div>

        {historyLoading && (
          <div className="flex items-center justify-center py-4 text-muted-foreground">
            <Loader2 className="w-4 h-4 animate-spin mr-1.5" />
            <span className="text-xs">Loading history…</span>
          </div>
        )}

        {!historyLoading && (!auditHistory || auditHistory.length === 0) && (
          <div className="px-3 pb-3">
            <p className="text-xs text-muted-foreground italic">No score changes recorded yet.</p>
          </div>
        )}

        {!historyLoading && auditHistory && auditHistory.length > 0 && (
          <ScrollArea className="max-h-56 px-3 pb-2">
            {auditHistory.map((entry, idx) => (
              <AuditEntryRow
                key={entry.id}
                entry={entry}
                isLast={idx === auditHistory.length - 1}
              />
            ))}
          </ScrollArea>
        )}
      </HoverCardContent>
    </HoverCard>
  );
}

// ── Main Read-Only Heatmap ────────────────────────────────────────

export function CompetitiveHeatmapView() {
  const [selectedVendors, setSelectedVendors] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [vendorSearch, setVendorSearch] = useState('');

  const { data: allVendors, isLoading: vendorsLoading } = useCompetitorVendors();

  const unsortedVendors = useMemo(() => ['Pendo', ...selectedVendors], [selectedVendors]);

  const { data: allScores, isLoading: scoresLoading } = useHeatmapScores(unsortedVendors);
  const { data: auditData } = useHeatmapAudits(unsortedVendors);
  const auditMap = auditData?.auditMap;
  const trendMap = auditData?.trendMap;
  const vendorTotals = useVendorTotals(allScores, unsortedVendors);

  // Sort vendors by total score descending, Pendo always first
  const activeVendors = useMemo(() => {
    const others = unsortedVendors.filter(v => v !== 'Pendo');
    others.sort((a, b) => (vendorTotals.get(b) || 0) - (vendorTotals.get(a) || 0));
    return ['Pendo', ...others];
  }, [unsortedVendors, vendorTotals]);

  const rows = useHeatmapRows(allScores, searchTerm, activeVendors);
  const rubricMap = useRubricMap();

  const toggleVendor = (vendor: string) => {
    setSelectedVendors(prev =>
      prev.includes(vendor) ? prev.filter(v => v !== vendor) : [...prev, vendor]
    );
  };

  const filteredVendors = useMemo(() => {
    if (!allVendors) return [];
    if (!vendorSearch) return allVendors;
    return allVendors.filter(v => v.toLowerCase().includes(vendorSearch.toLowerCase()));
  }, [allVendors, vendorSearch]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-primary/10">
            <Shield className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-semibold">Competitive Scorecard</h2>
            <p className="text-sm text-muted-foreground">
              Vendor capability maturity comparison across {allScores?.size ?? '—'} subcategories
            </p>
          </div>
        </div>
      </div>

      {/* Controls row */}
      <div className="flex gap-3 items-end flex-wrap">
        <div className="min-w-[220px]">
          <label className="text-sm font-medium text-muted-foreground mb-1 block">Vendors to compare</label>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-between text-sm h-9">
                <span className="flex items-center gap-2">
                  <Users className="w-3.5 h-3.5" />
                  {selectedVendors.length === 0
                    ? 'Select vendors...'
                    : `${selectedVendors.length} vendor${selectedVendors.length !== 1 ? 's' : ''} + Pendo`}
                </span>
                <ChevronDown className="w-3.5 h-3.5 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-64 p-0" align="start">
              <div className="p-2 border-b border-border">
                <Input placeholder="Search vendors..." value={vendorSearch} onChange={(e) => setVendorSearch(e.target.value)} className="h-8 text-sm" />
              </div>
              <ScrollArea className="h-64">
                <div className="p-2 space-y-1">
                  <div className="flex items-center gap-2 px-2 py-1.5 rounded-md bg-primary/10">
                    <Checkbox checked disabled className="opacity-50" />
                    <span className="text-sm font-medium">Pendo</span>
                    <Badge variant="outline" className="text-[10px] ml-auto">Always shown</Badge>
                  </div>
                  {vendorsLoading ? (
                    <div className="space-y-2 p-2">{[1, 2, 3].map(i => <Skeleton key={i} className="h-6 w-full" />)}</div>
                  ) : (
                    filteredVendors.map(vendor => (
                      <label key={vendor} className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-muted/50 cursor-pointer">
                        <Checkbox checked={selectedVendors.includes(vendor)} onCheckedChange={() => toggleVendor(vendor)} />
                        <span className="text-sm">{vendor}</span>
                      </label>
                    ))
                  )}
                </div>
              </ScrollArea>
              {selectedVendors.length > 0 && (
                <div className="p-2 border-t border-border">
                  <Button variant="ghost" size="sm" className="w-full text-xs" onClick={() => setSelectedVendors([])}>Clear all</Button>
                </div>
              )}
            </PopoverContent>
          </Popover>
        </div>

        <div className="flex-1 max-w-xs">
          <label className="text-sm font-medium text-muted-foreground mb-1 block">Filter</label>
          <div className="relative">
            <Search className="absolute left-2.5 top-2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search categories..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-9 h-9" />
          </div>
        </div>

        <div className="flex gap-1">
          <Button variant="ghost" size="sm" className="text-xs" onClick={() => setSelectedVendors(allVendors?.slice(0, 5) || [])}>Top 5</Button>
          <Button variant="ghost" size="sm" className="text-xs" onClick={() => setSelectedVendors(allVendors || [])}>All</Button>
        </div>
      </div>

      {/* Empty state */}
      {selectedVendors.length === 0 && !scoresLoading && (
        <div className="flex flex-col items-center justify-center py-16 border border-dashed border-border rounded-lg">
          <BarChart3 className="h-12 w-12 text-muted-foreground/30 mb-3" />
          <p className="text-muted-foreground text-sm">Select vendors above to view the comparison heatmap</p>
          <p className="text-muted-foreground/60 text-xs mt-1">Pendo is always included as the baseline</p>
        </div>
      )}

      {scoresLoading && selectedVendors.length > 0 && (
        <div className="space-y-2">{[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-10 w-full" />)}</div>
      )}

      {/* Heatmap table */}
      {selectedVendors.length > 0 && !scoresLoading && rows.length > 0 && (
        <TooltipProvider delayDuration={300}>
          <div className="border border-border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-muted/50 border-b border-border">
                    <th className="text-left px-3 py-2.5 font-medium text-muted-foreground text-xs sticky left-0 bg-muted/50 z-10 min-w-[160px]">Category</th>
                    <th className="text-left px-3 py-2.5 font-medium text-muted-foreground text-xs sticky left-[160px] bg-muted/50 z-10 min-w-[180px]">Subcategory</th>
                    {activeVendors.map(vendor => (
                      <th key={vendor} className={`text-center px-2 py-2.5 font-medium text-xs min-w-[90px] max-w-[110px] ${vendor === 'Pendo' ? 'bg-primary/10 text-primary' : 'text-muted-foreground'}`}>
                        <span className="truncate block" title={vendor}>{vendor}</span>
                      </th>
                    ))}
                  </tr>
                  <tr className="border-b-2 border-border bg-muted/30">
                    <td className="px-3 py-2 font-bold text-xs sticky left-0 bg-muted/30 z-10" colSpan={2}>Product Totals</td>
                    {activeVendors.map(vendor => {
                      const total = vendorTotals.get(vendor) || 0;
                      return (
                        <td key={vendor} className="text-center px-2 py-2">
                          <span className="font-bold text-sm" style={getHeatmapStyle(total / 20, true)}>{total.toFixed(1)}</span>
                        </td>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, idx) => {
                    const isFirst = idx === 0 || rows[idx - 1]?.category !== row.category;
                    const rowKey = `${row.category}|${row.subcategory}`;
                    const rubric = rubricMap.get(rowKey);

                    return (
                      <tr
                        key={`${row.category}-${row.subcategory}-${row.isAverage}`}
                        className={row.isAverage ? 'bg-muted/40 font-semibold border-t-2 border-border' : 'border-b border-border/50 hover:bg-muted/10'}
                      >
                        <td className={`px-3 py-1.5 text-xs sticky left-0 z-10 ${row.isAverage ? 'bg-muted/40 font-semibold' : 'bg-background text-muted-foreground'}`}>
                          {row.isAverage ? row.category : (isFirst ? row.category : '')}
                        </td>
                        <td className={`px-3 py-1.5 text-xs sticky left-[160px] z-10 ${row.isAverage ? 'bg-muted/40 font-semibold' : 'bg-background'}`}>
                          {row.isAverage ? (
                            <span className="italic">Category Average</span>
                          ) : (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="cursor-help truncate block max-w-[170px]" title={row.subcategory}>{row.subcategory}</span>
                              </TooltipTrigger>
                              {rubric && (
                                <TooltipContent side="right" className="max-w-sm p-3 space-y-1.5">
                                  <p className="font-medium text-xs mb-2">{rubric.subcategory}</p>
                                  {[1, 2, 3, 4, 5].map(level => {
                                    const desc = rubric[`level_${level}_description` as keyof CompetitiveRubric] as string;
                                    if (!desc) return null;
                                    return (
                                      <div key={level} className="text-xs text-muted-foreground">
                                        <span className="font-mono mr-1 font-medium">{level}:</span>{desc}
                                      </div>
                                    );
                                  })}
                                </TooltipContent>
                              )}
                            </Tooltip>
                          )}
                        </td>

                        {activeVendors.map(vendor => {
                          const cell = row.scores.get(vendor);
                          if (!cell) {
                            return <td key={vendor} className="text-center px-0 py-0"><div className="px-2 py-1.5 text-xs text-muted-foreground/40">—</div></td>;
                          }

                          if (row.isAverage) {
                            return (
                              <td key={vendor} className={`text-center px-0 py-0 ${vendor === 'Pendo' ? 'border-l-2 border-r-2 border-primary/20' : ''}`}>
                                <div className="px-2 py-1.5 font-bold text-xs" style={getHeatmapStyle(cell.score, true)}>
                                  {cell.score.toFixed(2)}
                                </div>
                              </td>
                            );
                          }

                          const auditKey = `${vendor}|${cell.subcategory}`;
                          const hasAuditDot = !!auditMap?.get(auditKey)?.rationale;
                          const trend = trendMap?.get(auditKey) ?? null;

                          return (
                            <td key={vendor} className={`text-center px-0 py-0 ${vendor === 'Pendo' ? 'border-l-2 border-r-2 border-primary/20' : ''}`}>
                              <ReadOnlyScoreCell cell={cell} hasAuditDot={hasAuditDot} rubric={rubric} trend={trend} />
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </TooltipProvider>
      )}
    </div>
  );
}

import { 
  ArrowUp, ArrowDown, Minus, Shield, Target, 
  TrendingUp, AlertTriangle, CheckCircle 
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useCompetitivePlays, useVendorComparison, type VendorComparison } from '@/hooks/useCompetitiveScorecard';

interface ScorecardComparisonProps {
  competitorNames: string[];
  opportunityId: string;
  onPlayClick?: (play: any) => void;
}

function ScoreBar({ score, maxScore = 5 }: { score: number; maxScore?: number }) {
  return (
    <div className="flex items-center gap-2">
      <Progress 
        value={(score / maxScore) * 100} 
        className="h-2 w-20"
      />
      <span className="text-xs font-medium w-6">{score.toFixed(1)}</span>
    </div>
  );
}

// Separate component for each competitor to satisfy React Hooks rules
function CompetitorCard({ competitorName }: { competitorName: string }) {
  const { data, isLoading } = useVendorComparison(competitorName);
  
  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="animate-pulse h-16 bg-muted rounded"></div>
        </CardContent>
      </Card>
    );
  }
  
  if (!data || data.length === 0) return null;
  
  const advantages = data.filter(c => c.difference >= 0.5).length;
  const weaknesses = data.filter(c => c.difference <= -0.5).length;
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center justify-between">
          <span>vs {competitorName}</span>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-emerald-600 border-emerald-200">
              <CheckCircle className="w-3 h-3 mr-1" />
              {advantages} advantages
            </Badge>
            <Badge variant="outline" className="text-amber-600 border-amber-200">
              <AlertTriangle className="w-3 h-3 mr-1" />
              {weaknesses} gaps
            </Badge>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="max-h-64 overflow-y-auto">
          {data
            .sort((a, b) => b.difference - a.difference)
            .slice(0, 10)
            .map((comparison, idx) => (
              <ComparisonRow 
                key={`${comparison.subcategory}-${idx}`}
                comparison={comparison}
                competitorName={competitorName}
              />
            ))}
        </div>
      </CardContent>
    </Card>
  );
}

function ComparisonRow({ 
  comparison, 
  competitorName,
}: { 
  comparison: VendorComparison;
  competitorName: string;
}) {
  const diff = comparison.difference;
  
  return (
    <div className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium truncate">{comparison.subcategory}</span>
          {diff >= 1.5 && (
            <Badge variant="outline" className="text-xs text-emerald-600 border-emerald-200">
              <TrendingUp className="w-3 h-3 mr-1" />
              Advantage
            </Badge>
          )}
          {diff >= 0.5 && diff < 1.5 && (
            <Badge variant="outline" className="text-xs text-amber-600 border-amber-200">
              <Target className="w-3 h-3 mr-1" />
              Landmine
            </Badge>
          )}
        </div>
        <span className="text-xs text-muted-foreground">{comparison.category}</span>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="text-right">
          <span className="text-xs text-muted-foreground block">Pendo</span>
          <ScoreBar score={comparison.pendoScore} />
        </div>
        
        <div className="flex items-center w-8 justify-center">
          {diff > 0.5 ? (
            <ArrowUp className="w-4 h-4 text-emerald-500" />
          ) : diff < -0.5 ? (
            <ArrowDown className="w-4 h-4 text-destructive" />
          ) : (
            <Minus className="w-4 h-4 text-muted-foreground" />
          )}
        </div>
        
        <div className="text-left">
          <span className="text-xs text-muted-foreground block">{competitorName}</span>
          <ScoreBar score={comparison.competitorScore} />
        </div>
      </div>
    </div>
  );
}

export function ScorecardComparison({ competitorNames, opportunityId, onPlayClick }: ScorecardComparisonProps) {
  const { data: plays, isLoading: playsLoading } = useCompetitivePlays(opportunityId, competitorNames);
  
  // Filter plays to relevant ones
  const differentiationPlays = (plays || []).filter(p => p.type === 'differentiation');
  const landminePlays = (plays || []).filter(p => p.type === 'landmine');
  const objectionPlays = (plays || []).filter(p => p.type === 'objection_handler');
  
  if (playsLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-muted rounded w-1/3"></div>
            <div className="h-24 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (competitorNames.length === 0) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-muted-foreground">
          <Shield className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">No scorecard data available for detected competitors</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="space-y-4">
      {/* Summary Cards per competitor */}
      {competitorNames.map(name => (
        <CompetitorCard key={name} competitorName={name} />
      ))}
      
      {/* Suggested Plays */}
      {(differentiationPlays.length > 0 || landminePlays.length > 0 || objectionPlays.length > 0) && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Target className="w-4 h-4" />
              Competitive Plays
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {differentiationPlays.slice(0, 3).map((play, idx) => (
              <div 
                key={`diff-${idx}`}
                className="p-2 rounded border border-emerald-200 bg-emerald-50/50 dark:bg-emerald-950/20 cursor-pointer hover:bg-emerald-100/50 dark:hover:bg-emerald-900/30"
                onClick={() => onPlayClick?.(play)}
              >
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                  <span className="text-sm font-medium">{play.title}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{play.description}</p>
              </div>
            ))}
            {landminePlays.slice(0, 3).map((play, idx) => (
              <div 
                key={`land-${idx}`}
                className="p-2 rounded border border-amber-200 bg-amber-50/50 dark:bg-amber-950/20 cursor-pointer hover:bg-amber-100/50 dark:hover:bg-amber-900/30"
                onClick={() => onPlayClick?.(play)}
              >
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-amber-600" />
                  <span className="text-sm font-medium">{play.title}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{play.description}</p>
                {(play.talkingPoints ?? []).length > 0 && (
                  <div className="mt-2 text-xs">
                    <span className="font-medium">Ask:</span> "{(play.talkingPoints ?? [])[0]}"
                  </div>
                )}
              </div>
            ))}
            {objectionPlays.slice(0, 2).map((play, idx) => (
              <div 
                key={`obj-${idx}`}
                className="p-2 rounded border border-destructive/30 bg-destructive/5 cursor-pointer hover:bg-destructive/10"
                onClick={() => onPlayClick?.(play)}
              >
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-destructive" />
                  <span className="text-sm font-medium">{play.title}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{play.description}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

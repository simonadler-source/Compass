import { useState } from 'react';
import { format } from 'date-fns';
import { CalendarIcon, Plus, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';
import { useActivityTypes, useCreateActivity } from '@/hooks/useOpportunityActivities';
import { useAssignableOpportunityUsers } from '@/hooks/useAssignableOpportunityUsers';
import { toast } from 'sonner';

interface AddActivityDialogProps {
  opportunityId: string;
  accountId: string;
  trigger?: React.ReactNode;
}

export function AddActivityDialog({ opportunityId, accountId, trigger }: AddActivityDialogProps) {
  const [open, setOpen] = useState(false);
  const [activityTypeId, setActivityTypeId] = useState('');
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [activityDate, setActivityDate] = useState<Date | undefined>(new Date());

  const { data: activityTypes, isLoading: loadingTypes } = useActivityTypes();
  const { data: assignableUsers, isLoading: loadingUsers } = useAssignableOpportunityUsers(opportunityId);
  const createActivity = useCreateActivity();

  const handleSubmit = async () => {
    if (!activityTypeId || !activityDate) {
      toast.error('Please select an activity type and date');
      return;
    }

    try {
      await createActivity.mutateAsync({
        opportunity_id: opportunityId,
        account_id: accountId,
        activity_type_id: activityTypeId,
        activity_date: activityDate.toISOString(),
        title: title || null,
        notes: notes || null,
        ae_email: assignedTo || null,
        detection_source: 'manual',
        transcript_id: null,
        sentiment_score: null,
        sentiment_label: null,
        confidence_score: null,
        se_email: null,
      });
      
      toast.success('Activity added successfully');
      setOpen(false);
      resetForm();
    } catch (error) {
      toast.error('Failed to add activity');
    }
  };

  const resetForm = () => {
    setActivityTypeId('');
    setTitle('');
    setNotes('');
    setAssignedTo('');
    setActivityDate(new Date());
  };

  const selectedType = activityTypes?.find(t => t.id === activityTypeId);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm">
            <Plus className="w-4 h-4 mr-1" />
            Add Activity
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add Activity</DialogTitle>
          <DialogDescription>
            Log a new activity for this opportunity
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Activity Type */}
          <div className="space-y-2">
            <Label htmlFor="activity-type">Activity Type *</Label>
            <Select value={activityTypeId} onValueChange={setActivityTypeId}>
              <SelectTrigger id="activity-type">
                <SelectValue placeholder="Select activity type" />
              </SelectTrigger>
              <SelectContent>
                {loadingTypes ? (
                  <SelectItem value="loading" disabled>Loading...</SelectItem>
                ) : (
                  activityTypes?.map(type => (
                    <SelectItem key={type.id} value={type.id}>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: type.color }}
                        />
                        {type.label}
                      </div>
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              placeholder={selectedType ? `${selectedType.label} meeting...` : 'Enter activity title'}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          {/* Date */}
          <div className="space-y-2">
            <Label>Date *</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !activityDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {activityDate ? format(activityDate, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={activityDate}
                  onSelect={setActivityDate}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Assigned To */}
          <div className="space-y-2">
            <Label htmlFor="assigned-to">Assigned To</Label>
            <Select value={assignedTo} onValueChange={setAssignedTo}>
              <SelectTrigger id="assigned-to">
                <SelectValue placeholder="Select team member">
                  {assignedTo && (
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-muted-foreground" />
                      {assignableUsers?.allUsers?.find(u => u.email === assignedTo)?.name || assignedTo.split('@')[0]}
                    </div>
                  )}
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">
                  <span className="text-muted-foreground">Unassigned</span>
                </SelectItem>
                {loadingUsers ? (
                  <SelectItem value="loading" disabled>Loading...</SelectItem>
                ) : (
                  assignableUsers?.allUsers?.map(user => (
                    <SelectItem key={user.email} value={user.email}>
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-muted-foreground" />
                        {user.name || user.email.split('@')[0]}
                        <span className="text-xs text-muted-foreground">
                          ({user.role})
                        </span>
                      </div>
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="Add any notes or details about this activity..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={!activityTypeId || !activityDate || createActivity.isPending}
          >
            {createActivity.isPending ? 'Adding...' : 'Add Activity'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

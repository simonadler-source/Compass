import { useState, useRef } from 'react';
 import { Link2, Upload, X } from 'lucide-react';
 import { Button } from '@/components/ui/button';
 import { Input } from '@/components/ui/input';
 import { Label } from '@/components/ui/label';
 import { Textarea } from '@/components/ui/textarea';
 import { Badge } from '@/components/ui/badge';
 import {
   Dialog,
   DialogContent,
   DialogHeader,
   DialogTitle,
   DialogFooter,
 } from '@/components/ui/dialog';
 import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
 } from '@/components/ui/select';
 import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
 import { useCreateDocument, CreateDocumentInput } from '@/hooks/useDocuments';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
 
 interface AddDocumentDialogProps {
   open: boolean;
   onOpenChange: (open: boolean) => void;
   accountId: string;
   opportunityId?: string | null;
   opportunityName?: string;
 }
 
 const documentTypes = [
   { value: 'proposal', label: 'Proposal' },
   { value: 'contract', label: 'Contract' },
   { value: 'presentation', label: 'Presentation' },
   { value: 'technical_spec', label: 'Technical Spec' },
   { value: 'case_study', label: 'Case Study' },
   { value: 'screenshot', label: 'Screenshot' },
   { value: 'meeting_notes', label: 'Meeting Notes' },
   { value: 'reference', label: 'Reference Material' },
   { value: 'other', label: 'Other' },
 ];
 
 const statusOptions = [
   { value: 'draft', label: 'Draft' },
   { value: 'active', label: 'Active' },
   { value: 'archived', label: 'Archived' },
 ];
 
 export function AddDocumentDialog({
   open,
   onOpenChange,
   accountId,
   opportunityId,
   opportunityName,
 }: AddDocumentDialogProps) {
   const createDocument = useCreateDocument();
   const [activeTab, setActiveTab] = useState<'url' | 'file'>('url');
   
   // Form state
   const [name, setName] = useState('');
   const [description, setDescription] = useState('');
   const [url, setUrl] = useState('');
   const [type, setType] = useState('reference');
   const [status, setStatus] = useState<'draft' | 'active' | 'archived'>('active');
   const [version, setVersion] = useState('1.0');
   const [expiryDate, setExpiryDate] = useState('');
   const [tagInput, setTagInput] = useState('');
   const [tags, setTags] = useState<string[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
 
   const resetForm = () => {
     setName('');
     setDescription('');
     setUrl('');
     setType('reference');
     setStatus('active');
     setVersion('1.0');
     setExpiryDate('');
     setTagInput('');
     setTags([]);
     setActiveTab('url');
    setSelectedFile(null);
    setIsUploading(false);
   };
 
   const handleAddTag = () => {
     if (tagInput.trim() && !tags.includes(tagInput.trim())) {
       setTags([...tags, tagInput.trim()]);
       setTagInput('');
     }
   };
 
   const handleRemoveTag = (tagToRemove: string) => {
     setTags(tags.filter(t => t !== tagToRemove));
   };
 
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (50MB limit)
      if (file.size > 52428800) {
        toast.error('File size exceeds 50MB limit');
        return;
      }
      setSelectedFile(file);
      // Auto-populate name if empty
      if (!name.trim()) {
        setName(file.name.replace(/\.[^/.]+$/, '')); // Remove extension
      }
    }
  };

  const uploadFile = async (file: File): Promise<string | null> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${accountId}/${opportunityId || 'account'}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
    
    const { data, error } = await supabase.storage
      .from('account-documents')
      .upload(fileName, file);
    
    if (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload file: ' + error.message);
      return null;
    }
    
    // Get the public URL (or signed URL for private bucket)
    const { data: urlData } = supabase.storage
      .from('account-documents')
      .getPublicUrl(data.path);
    
    return urlData.publicUrl;
  };

   const handleSubmit = async () => {
     if (!name.trim()) return;
    if (activeTab === 'url' && !url.trim()) return;
    if (activeTab === 'file' && !selectedFile) return;

    setIsUploading(true);
    let fileUrl: string | null = null;

    try {
      if (activeTab === 'file' && selectedFile) {
        fileUrl = await uploadFile(selectedFile);
        if (!fileUrl) {
          setIsUploading(false);
          return;
        }
      }

      const docInput: CreateDocumentInput = {
        account_id: accountId,
        opportunity_id: opportunityId || null,
        name: name.trim(),
        description: description.trim() || null,
        type,
        status,
        version,
        tags,
        expiry_date: expiryDate || null,
        is_external_url: activeTab === 'url',
        file_url: activeTab === 'url' ? url.trim() : fileUrl,
      };
 
      await createDocument.mutateAsync(docInput);
      resetForm();
      onOpenChange(false);
    } catch (error) {
      console.error('Submit error:', error);
    } finally {
      setIsUploading(false);
    }
   };
 
  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  };

   return (
     <Dialog open={open} onOpenChange={(isOpen) => {
       if (!isOpen) resetForm();
       onOpenChange(isOpen);
     }}>
       <DialogContent className="sm:max-w-[550px]">
         <DialogHeader>
           <DialogTitle>Add Document</DialogTitle>
           {opportunityId && opportunityName && (
             <p className="text-sm text-muted-foreground">
               Adding to opportunity: {opportunityName}
             </p>
           )}
         </DialogHeader>
 
         <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'url' | 'file')}>
           <TabsList className="grid w-full grid-cols-2">
             <TabsTrigger value="url" className="gap-2">
               <Link2 className="w-4 h-4" />
               URL Link
             </TabsTrigger>
            <TabsTrigger value="file" className="gap-2">
               <Upload className="w-4 h-4" />
               Upload File
             </TabsTrigger>
           </TabsList>
 
           <TabsContent value="url" className="space-y-4 mt-4">
             <div className="space-y-2">
               <Label htmlFor="url">Document URL *</Label>
               <Input
                 id="url"
                 placeholder="https://docs.google.com/..."
                 value={url}
                 onChange={(e) => setUrl(e.target.value)}
               />
               <p className="text-xs text-muted-foreground">
                 Link to SharePoint, Google Drive, Confluence, or any external document
               </p>
             </div>
           </TabsContent>
 
           <TabsContent value="file" className="space-y-4 mt-4">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              className="hidden"
              accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.png,.jpg,.jpeg,.gif,.webp,.txt,.csv,.zip"
            />
            <div 
              className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              {selectedFile ? (
                <div className="space-y-2">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                    <Upload className="w-6 h-6 text-primary" />
                  </div>
                  <p className="font-medium text-sm">{selectedFile.name}</p>
                  <p className="text-xs text-muted-foreground">{formatFileSize(selectedFile.size)}</p>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedFile(null);
                      if (fileInputRef.current) fileInputRef.current.value = '';
                    }}
                  >
                    Remove
                  </Button>
                </div>
              ) : (
                <>
                  <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm font-medium">Click to select a file</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    PDF, Word, Excel, PowerPoint, Images, CSV (Max 50MB)
                  </p>
                </>
              )}
             </div>
           </TabsContent>
         </Tabs>
 
         <div className="space-y-4">
           <div className="space-y-2">
             <Label htmlFor="name">Document Name *</Label>
             <Input
               id="name"
               placeholder="Q4 Technical Proposal"
               value={name}
               onChange={(e) => setName(e.target.value)}
             />
           </div>
 
           <div className="space-y-2">
             <Label htmlFor="description">Description</Label>
             <Textarea
               id="description"
               placeholder="Brief description of the document..."
               value={description}
               onChange={(e) => setDescription(e.target.value)}
               rows={2}
             />
           </div>
 
           <div className="grid grid-cols-2 gap-4">
             <div className="space-y-2">
               <Label>Document Type</Label>
               <Select value={type} onValueChange={setType}>
                 <SelectTrigger>
                   <SelectValue />
                 </SelectTrigger>
                 <SelectContent>
                   {documentTypes.map(t => (
                     <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                   ))}
                 </SelectContent>
               </Select>
             </div>
 
             <div className="space-y-2">
               <Label>Status</Label>
               <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
                 <SelectTrigger>
                   <SelectValue />
                 </SelectTrigger>
                 <SelectContent>
                   {statusOptions.map(s => (
                     <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                   ))}
                 </SelectContent>
               </Select>
             </div>
           </div>
 
           <div className="grid grid-cols-2 gap-4">
             <div className="space-y-2">
               <Label htmlFor="version">Version</Label>
               <Input
                 id="version"
                 placeholder="1.0"
                 value={version}
                 onChange={(e) => setVersion(e.target.value)}
               />
             </div>
 
             <div className="space-y-2">
               <Label htmlFor="expiry">Expiry Date</Label>
               <Input
                 id="expiry"
                 type="date"
                 value={expiryDate}
                 onChange={(e) => setExpiryDate(e.target.value)}
               />
             </div>
           </div>
 
           <div className="space-y-2">
             <Label>Tags</Label>
             <div className="flex gap-2">
               <Input
                 placeholder="Add a tag..."
                 value={tagInput}
                 onChange={(e) => setTagInput(e.target.value)}
                 onKeyDown={(e) => {
                   if (e.key === 'Enter') {
                     e.preventDefault();
                     handleAddTag();
                   }
                 }}
               />
               <Button type="button" variant="outline" onClick={handleAddTag}>
                 Add
               </Button>
             </div>
             {tags.length > 0 && (
               <div className="flex flex-wrap gap-1 mt-2">
                 {tags.map(tag => (
                   <Badge key={tag} variant="secondary" className="gap-1">
                     {tag}
                     <X
                       className="w-3 h-3 cursor-pointer hover:text-destructive"
                       onClick={() => handleRemoveTag(tag)}
                     />
                   </Badge>
                 ))}
               </div>
             )}
           </div>
         </div>
 
         <DialogFooter>
           <Button variant="outline" onClick={() => onOpenChange(false)}>
             Cancel
           </Button>
           <Button 
             onClick={handleSubmit}
              disabled={!name.trim() || (activeTab === 'url' && !url.trim()) || (activeTab === 'file' && !selectedFile) || createDocument.isPending || isUploading}
           >
              {isUploading ? 'Uploading...' : createDocument.isPending ? 'Adding...' : 'Add Document'}
           </Button>
         </DialogFooter>
       </DialogContent>
     </Dialog>
   );
 }
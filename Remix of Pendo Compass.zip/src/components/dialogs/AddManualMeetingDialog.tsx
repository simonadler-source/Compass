import { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { CalendarIcon, MapPin, Plus, X, Search, Building2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { useAddManualMeeting, MANUAL_MEETING_TYPES } from '@/hooks/useManualMeetings';
import { useTeamMembers } from '@/hooks/useTeamMembers';
import { gateway } from '@/lib/apiGateway';
import { useQuery } from '@tanstack/react-query';

interface AddManualMeetingDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preselectedMemberEmail?: string;
}

export default function AddManualMeetingDialog({ open, onOpenChange, preselectedMemberEmail }: AddManualMeetingDialogProps) {
  const [meetingType, setMeetingType] = useState('client_onsite');
  const [meetingDate, setMeetingDate] = useState<Date | undefined>(new Date());
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [attendeeEmails, setAttendeeEmails] = useState<string[]>(preselectedMemberEmail ? [preselectedMemberEmail] : []);
  const [notes, setNotes] = useState('');
  const [oppSearch, setOppSearch] = useState('');
  const [selectedOpp, setSelectedOpp] = useState<{ id: string; name: string; accountId: string; accountName: string; value: number | null } | null>(null);
  const [attendeeInput, setAttendeeInput] = useState('');

  const addMeeting = useAddManualMeeting();
  const { teamEmailsWithSelf } = useTeamMembers();

  // Search opportunities
  const { data: oppResults } = useQuery({
    queryKey: ['opp-search-manual', oppSearch],
    queryFn: async () => {
      if (oppSearch.length < 2) return [];
      const result = await gateway.from('opportunities')
        .select('id, name, value, account_id, accounts(id, name)')
        .ilike('name', `%${oppSearch}%`)
        .eq('is_archived', false)
        .limit(8)
        .execute();
      return (result.data || []).map((o: any) => ({
        id: o.id,
        name: o.name,
        accountId: o.account_id,
        accountName: o.accounts?.name || 'Unknown',
        value: o.value,
      }));
    },
    enabled: oppSearch.length >= 2,
  });

  const handleAddAttendee = () => {
    const email = attendeeInput.trim().toLowerCase();
    if (email && !attendeeEmails.includes(email)) {
      setAttendeeEmails(prev => [...prev, email]);
      setAttendeeInput('');
    }
  };

  const handleSubmit = () => {
    if (!meetingDate) return;
    addMeeting.mutate({
      opportunity_id: selectedOpp?.id || null,
      account_id: selectedOpp?.accountId || null,
      meeting_type: meetingType,
      meeting_date: meetingDate.toISOString(),
      attendee_emails: attendeeEmails,
      notes: notes || null,
    }, {
      onSuccess: () => {
        onOpenChange(false);
        resetForm();
      },
    });
  };

  const resetForm = () => {
    setMeetingType('client_onsite');
    setMeetingDate(new Date());
    setAttendeeEmails(preselectedMemberEmail ? [preselectedMemberEmail] : []);
    setNotes('');
    setOppSearch('');
    setSelectedOpp(null);
    setAttendeeInput('');
  };

  const typeInfo = MANUAL_MEETING_TYPES.find(t => t.value === meetingType);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            Log Unrecorded Meeting
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Opportunity Search */}
          <div className="space-y-2">
            <Label>Opportunity</Label>
            {selectedOpp ? (
              <div className="flex items-center gap-2 bg-muted/50 rounded-lg px-3 py-2 border">
                <Building2 className="h-4 w-4 text-primary shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{selectedOpp.name}</p>
                  <p className="text-xs text-muted-foreground">{selectedOpp.accountName}
                    {selectedOpp.value && ` — $${(selectedOpp.value / 1000).toFixed(0)}k`}
                  </p>
                </div>
                <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => { setSelectedOpp(null); setOppSearch(''); }}>
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ) : (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search opportunities..."
                  value={oppSearch}
                  onChange={(e) => setOppSearch(e.target.value)}
                  className="pl-9"
                />
                {oppResults && oppResults.length > 0 && oppSearch.length >= 2 && (
                  <div className="absolute z-50 w-full mt-1 bg-popover border rounded-lg shadow-lg max-h-48 overflow-y-auto">
                    {oppResults.map((opp: any) => (
                      <button
                        key={opp.id}
                        className="w-full text-left px-3 py-2 hover:bg-accent text-sm flex items-center justify-between"
                        onClick={() => { setSelectedOpp(opp); setOppSearch(''); }}
                      >
                        <div>
                          <p className="font-medium">{opp.name}</p>
                          <p className="text-xs text-muted-foreground">{opp.accountName}</p>
                        </div>
                        {opp.value && <span className="text-xs text-muted-foreground">${(opp.value / 1000).toFixed(0)}k</span>}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Meeting Type & Date */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Type</Label>
              <Select value={meetingType} onValueChange={setMeetingType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MANUAL_MEETING_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Date</Label>
              <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !meetingDate && "text-muted-foreground")}>
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {meetingDate ? format(meetingDate, 'PPP') : 'Pick a date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={meetingDate}
                    onSelect={(d) => { setMeetingDate(d); setDatePickerOpen(false); }}
                    disabled={(date) => date > new Date()}
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Attendees */}
          <div className="space-y-2">
            <Label>Team Attendees</Label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {attendeeEmails.map(email => (
                <Badge key={email} variant="secondary" className="gap-1 pr-1">
                  {email}
                  <button onClick={() => setAttendeeEmails(prev => prev.filter(e => e !== email))} className="hover:text-destructive">
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Select value="" onValueChange={(v) => {
                if (v && !attendeeEmails.includes(v)) setAttendeeEmails(prev => [...prev, v]);
              }}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Select team member..." />
                </SelectTrigger>
                <SelectContent>
                  {teamEmailsWithSelf
                    .filter(e => !attendeeEmails.includes(e))
                    .map(email => (
                      <SelectItem key={email} value={email}>{email}</SelectItem>
                    ))
                  }
                </SelectContent>
              </Select>
              <div className="flex gap-1">
                <Input
                  placeholder="Or type email..."
                  value={attendeeInput}
                  onChange={(e) => setAttendeeInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddAttendee()}
                  className="w-40"
                />
                <Button variant="outline" size="icon" onClick={handleAddAttendee} disabled={!attendeeInput.trim()}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label>Notes <span className="text-muted-foreground font-normal">(optional)</span></Label>
            <Textarea
              placeholder="e.g. Onsite with CTO to review architecture and deployment timeline"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
            />
          </div>

          {typeInfo?.highlighted && (
            <p className="text-xs text-muted-foreground bg-primary/5 rounded-md px-3 py-2">
              💡 This meeting type will appear as a <strong>Notable Activity</strong> callout in the Executive Summary.
            </p>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={addMeeting.isPending || !meetingDate || attendeeEmails.length === 0}>
            {addMeeting.isPending ? 'Adding…' : 'Add Meeting'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, BarChart3, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { encryptedInsert } from '@/lib/encryptedDb';
import { toast } from 'sonner';

interface AddMetricDialogProps {
  accountId: string;
  opportunityId?: string;
  trigger?: React.ReactNode;
}

const METRIC_CATEGORIES = [
  { value: 'Usage', label: 'Usage (users, licenses, volumes)' },
  { value: 'Cost/Financial', label: 'Cost/Financial (pricing, budget, spend)' },
  { value: 'Time/Efficiency', label: 'Time/Efficiency (hours, duration)' },
  { value: 'Performance', label: 'Performance (SLAs, uptime)' },
  { value: 'Support/Service', label: 'Support/Service (tickets, response time)' },
  { value: 'Adoption', label: 'Adoption (engagement, retention)' },
  { value: 'Revenue', label: 'Revenue (sales, deal value)' },
];

export function AddMetricDialog({ accountId, opportunityId, trigger }: AddMetricDialogProps) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [metricName, setMetricName] = useState('');
  const [metricValue, setMetricValue] = useState('');
  const [numericValue, setNumericValue] = useState('');
  const [category, setCategory] = useState('Usage');
  const [context, setContext] = useState('');

  const createMutation = useMutation({
    mutationFn: async () => {
      const { error } = await encryptedInsert('account_metrics', {
        account_id: accountId,
        opportunity_id: opportunityId || null,
        metric_name: metricName.trim(),
        metric_value: metricValue.trim(),
        metric_numeric_value: numericValue ? parseFloat(numericValue) : null,
        metric_category: category,
        context: context.trim() || null,
        source: 'manual',
        confidence_score: 1.0,
        needs_review: false,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Metric added successfully');
      queryClient.invalidateQueries({ queryKey: ['account-metrics', accountId] });
      setOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast.error('Failed to add metric: ' + (error as Error).message);
    },
  });

  const resetForm = () => {
    setMetricName('');
    setMetricValue('');
    setNumericValue('');
    setCategory('Usage');
    setContext('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!metricName.trim() || !metricValue.trim()) {
      toast.error('Please enter metric name and value');
      return;
    }
    createMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm" className="gap-1.5">
            <Plus className="w-3.5 h-3.5" />
            Add Metric
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Add Manual Metric
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="metricName">Metric Name *</Label>
            <Input
              id="metricName"
              placeholder="e.g., Support Tickets per Month"
              value={metricName}
              onChange={(e) => setMetricName(e.target.value)}
              autoFocus
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="metricValue">Value (as stated) *</Label>
              <Input
                id="metricValue"
                placeholder="e.g., 500 tickets"
                value={metricValue}
                onChange={(e) => setMetricValue(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="numericValue">Numeric Value</Label>
              <Input
                id="numericValue"
                type="number"
                placeholder="e.g., 500"
                value={numericValue}
                onChange={(e) => setNumericValue(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {METRIC_CATEGORIES.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="context">Context (optional)</Label>
            <Textarea
              id="context"
              placeholder="Where/when was this mentioned? Any additional notes..."
              value={context}
              onChange={(e) => setContext(e.target.value)}
              rows={2}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createMutation.isPending}>
              {createMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Add Metric
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

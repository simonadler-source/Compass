import { useState } from 'react';
import { Plus, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAssignableOpportunityUsers } from '@/hooks/useAssignableOpportunityUsers';
import { useOpportunityContacts } from '@/hooks/useOpportunityContacts';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

const PHASES = [
  'Value Discovery',
  'Eval Planning',
  'Eval Deployment',
  'Eval Workshops',
  'Conclusion',
  'Procurement & Contracting',
  'Go Live & Value Realization',
];

interface AddMilestoneDialogProps {
  opportunityId: string;
  trigger?: React.ReactNode;
}

export function AddMilestoneDialog({ opportunityId, trigger }: AddMilestoneDialogProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [phase, setPhase] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: assignableUsers, isLoading: loadingUsers } = useAssignableOpportunityUsers(opportunityId);
  const { data: contacts, isLoading: loadingContacts } = useOpportunityContacts(opportunityId);
  const queryClient = useQueryClient();

  const handleSubmit = async () => {
    if (!name || !phase) {
      toast.error('Please enter a name and select a phase');
      return;
    }

    setIsSubmitting(true);
    try {
      // Get highest sort_order for the phase
      const { data: existing } = await gateway
        .from('opportunity_milestones')
        .select('sort_order')
        .eq('opportunity_id', opportunityId)
        .eq('phase', phase)
        .order('sort_order', { ascending: false })
        .limit(1)
        .execute();

      const sortOrder = existing && existing.length > 0 ? (existing[0].sort_order + 1) : 0;

      const { error } = await gateway
        .from('opportunity_milestones')
        .insert({
          opportunity_id: opportunityId,
          name,
          description: description || null,
          phase,
          assigned_to: assignedTo || null,
          notes: notes || null,
          status: 'not_scheduled',
          sort_order: sortOrder,
        })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      
      toast.success('Milestone added');
      queryClient.invalidateQueries({ queryKey: ['opportunity-milestones', opportunityId] });
      setOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error('Failed to add milestone: ' + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setName('');
    setDescription('');
    setPhase('');
    setAssignedTo('');
    setNotes('');
  };

  const teamMembers = assignableUsers?.allUsers || [];
  const stakeholders = contacts?.filter(c => !c.is_internal && !c.is_ignored) || [];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm">
            <Plus className="w-4 h-4 mr-1" />
            Add Activity
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add Activity</DialogTitle>
          <DialogDescription>
            Add a new milestone or activity to the timeline
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              placeholder="Enter milestone name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          {/* Phase */}
          <div className="space-y-2">
            <Label htmlFor="phase">Phase *</Label>
            <Select value={phase} onValueChange={setPhase}>
              <SelectTrigger id="phase">
                <SelectValue placeholder="Select phase" />
              </SelectTrigger>
              <SelectContent>
                {PHASES.map(p => (
                  <SelectItem key={p} value={p}>{p}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              placeholder="Brief description of this activity"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          {/* Assigned To */}
          <div className="space-y-2">
            <Label htmlFor="assigned-to">Assigned To</Label>
            <Select value={assignedTo} onValueChange={setAssignedTo}>
              <SelectTrigger id="assigned-to">
                <SelectValue placeholder="Select assignee" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">
                  <span className="text-muted-foreground">Unassigned</span>
                </SelectItem>
                
                {teamMembers.length > 0 && (
                  <>
                    <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground">
                      Team Members
                    </div>
                    {teamMembers.map(user => (
                      <SelectItem key={user.email} value={user.email}>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-primary" />
                          {user.name || user.email.split('@')[0]}
                        </div>
                      </SelectItem>
                    ))}
                  </>
                )}
                
                {stakeholders.length > 0 && (
                  <>
                    <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground mt-2">
                      Stakeholders
                    </div>
                    {stakeholders.map(contact => (
                      <SelectItem key={contact.id} value={contact.email || contact.id}>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-amber-500" />
                          {contact.name}
                        </div>
                      </SelectItem>
                    ))}
                  </>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="Add notes..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={!name || !phase || isSubmitting}
          >
            {isSubmitting ? 'Adding...' : 'Add Activity'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useCreateAccount } from '@/hooks/useAccounts';
import { useAuth } from '@/contexts/AuthContext';

interface CreateAccountDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAccountCreated?: (accountId: string) => void;
}

const industries = [
  'Technology',
  'Healthcare',
  'Finance',
  'Retail',
  'Manufacturing',
  'Education',
  'Media',
  'Other',
];

const stages = [
  { value: 'discovery', label: 'Discovery' },
  { value: 'evaluation', label: 'Evaluation' },
  { value: 'proposal', label: 'Proposal' },
  { value: 'closing', label: 'Closing' },
  { value: 'customer', label: 'Customer' },
];

export function CreateAccountDialog({ open, onOpenChange, onAccountCreated }: CreateAccountDialogProps) {
  const { user } = useAuth();
  const [name, setName] = useState('');
  const [industry, setIndustry] = useState('');
  const [stage, setStage] = useState('discovery');
  const [arr, setArr] = useState('');

  const createAccount = useCreateAccount();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) return;

    try {
      const result = await createAccount.mutateAsync({
        name: name.trim(),
        industry: industry || null,
        stage,
        arr: arr ? parseFloat(arr) : null,
        owner_id: user?.id || null,
      });

      // Reset form
      setName('');
      setIndustry('');
      setStage('discovery');
      setArr('');
      onOpenChange(false);
      
      if (onAccountCreated) {
        onAccountCreated(result.id);
      }
    } catch (error) {
      // Error handled by mutation
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass border-border sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create Account Folder</DialogTitle>
          <DialogDescription>
            Create a new customer account to store architecture maps, transcripts, and plans.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="name">Account Name *</Label>
            <Input
              id="name"
              placeholder="e.g., Acme Corporation"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="industry">Industry</Label>
            <Select value={industry} onValueChange={setIndustry}>
              <SelectTrigger>
                <SelectValue placeholder="Select industry" />
              </SelectTrigger>
              <SelectContent>
                {industries.map(ind => (
                  <SelectItem key={ind} value={ind}>{ind}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="stage">Deal Stage</Label>
            <Select value={stage} onValueChange={setStage}>
              <SelectTrigger>
                <SelectValue placeholder="Select stage" />
              </SelectTrigger>
              <SelectContent>
                {stages.map(s => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="arr">ARR ($)</Label>
            <Input
              id="arr"
              type="number"
              placeholder="e.g., 100000"
              value={arr}
              onChange={(e) => setArr(e.target.value)}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="glow" disabled={!name.trim() || createAccount.isPending}>
              {createAccount.isPending ? 'Creating...' : 'Create Account'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

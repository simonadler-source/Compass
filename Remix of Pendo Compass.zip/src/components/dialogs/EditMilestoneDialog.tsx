import { useState, useEffect } from 'react';
import { User, StickyNote, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAssignableOpportunityUsers } from '@/hooks/useAssignableOpportunityUsers';
import { useOpportunityContacts } from '@/hooks/useOpportunityContacts';
import { useUpdateMilestone } from '@/hooks/useOpportunityReadiness';
import { toast } from 'sonner';

interface Milestone {
  id: string;
  name: string;
  notes: string | null;
  assigned_to: string | null;
}

interface EditMilestoneDialogProps {
  milestone: Milestone | null;
  opportunityId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function EditMilestoneDialog({ 
  milestone, 
  opportunityId, 
  open, 
  onOpenChange 
}: EditMilestoneDialogProps) {
  const [notes, setNotes] = useState('');
  const [assignedTo, setAssignedTo] = useState('__unassigned__');

  const { data: assignableUsers, isLoading: loadingUsers } = useAssignableOpportunityUsers(opportunityId);
  const { data: contacts, isLoading: loadingContacts } = useOpportunityContacts(opportunityId);
  const updateMilestone = useUpdateMilestone();

  useEffect(() => {
    if (milestone) {
      setNotes(milestone.notes || '');
      setAssignedTo(milestone.assigned_to || '__unassigned__');
    }
  }, [milestone]);

  const handleSave = async () => {
    if (!milestone) return;

    try {
      await updateMilestone.mutateAsync({
        id: milestone.id,
        opportunityId,
        notes: notes || null,
        assignedTo: assignedTo === '__unassigned__' ? null : assignedTo || null,
      });
      
      toast.success('Milestone updated');
      onOpenChange(false);
    } catch (error) {
      toast.error('Failed to update milestone');
    }
  };

  // Combine team members and stakeholders for assignment options
  const teamMembers = assignableUsers?.allUsers || [];
  const stakeholders = contacts?.filter(c => !c.is_internal && !c.is_ignored) || [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <StickyNote className="w-5 h-5 text-primary" />
            Edit Milestone
          </DialogTitle>
          <DialogDescription>
            {milestone?.name}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Assigned To */}
          <div className="space-y-2">
            <Label htmlFor="assigned-to">Assigned To</Label>
            <Select value={assignedTo} onValueChange={setAssignedTo}>
              <SelectTrigger id="assigned-to">
                <SelectValue placeholder="Select assignee">
                  {assignedTo && (
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-muted-foreground" />
                      {teamMembers.find(u => u.email === assignedTo)?.name || 
                       stakeholders.find(s => s.email === assignedTo)?.name ||
                       assignedTo.split('@')[0]}
                    </div>
                  )}
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__unassigned__">
                   <span className="text-muted-foreground">Unassigned</span>
                 </SelectItem>
                
                {/* Team Members */}
                {teamMembers.length > 0 && (
                  <>
                    <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground">
                      Team Members
                    </div>
                    {teamMembers.map(user => (
                      <SelectItem key={user.email} value={user.email}>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-primary" />
                          {user.name || user.email.split('@')[0]}
                          <span className="text-xs text-muted-foreground">
                            ({user.role})
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </>
                )}
                
                {/* Stakeholders */}
                {stakeholders.length > 0 && (
                  <>
                    <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground mt-2">
                      Stakeholders
                    </div>
                    {stakeholders.map(contact => (
                      <SelectItem key={contact.id} value={contact.email || contact.id}>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-amber-500" />
                          {contact.name}
                          {contact.role && (
                            <span className="text-xs text-muted-foreground">
                              ({contact.role})
                            </span>
                          )}
                        </div>
                      </SelectItem>
                    ))}
                  </>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="Add notes about this milestone..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={updateMilestone.isPending}
          >
            {updateMilestone.isPending ? 'Saving...' : 'Save'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

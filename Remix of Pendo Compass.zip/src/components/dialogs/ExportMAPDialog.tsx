import { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { FileDown, Download, Building2, Target, Lightbulb, Calendar, Users, Layers, Settings2, ArrowLeft, ClipboardCheck, CheckSquare, FileSpreadsheet } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { toast } from 'sonner';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MAPDocument } from '@/components/map/MAPDocument';
import { exportMAPToExcel } from '@/lib/exportMAPExcel';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

export interface MAPSection {
  id: string;
  label: string;
  icon: React.ElementType;
  description: string;
}

export const MAP_SECTIONS: MAPSection[] = [
  { id: 'executive-summary', label: 'Executive Summary', icon: Building2, description: 'Account overview, key priorities, prepared for/by' },
  { id: 'account-insights', label: 'Account Intelligence', icon: Target, description: 'SWOT analysis, pain points, and extracted metrics' },
  { id: 'current-architecture', label: 'Technologies & Architecture', icon: Layers, description: 'Current tech stack visualization' },
  { id: 'future-state', label: 'Current vs Future State', icon: Target, description: 'Transformation from current to future with Pendo' },
  { id: 'competitors', label: 'Competitive Landscape', icon: Target, description: 'Detected competitors and positioning analysis' },
  { id: 'use-cases', label: 'Use Cases', icon: Lightbulb, description: 'Linked and suggested (70%+ confidence) use cases' },
  { id: 'priority-radar', label: 'Priority Radar', icon: Target, description: 'Use cases by priority with visual chart + table' },
  { id: 'stakeholder-map', label: 'Stakeholder Map', icon: Users, description: 'Org chart visual and detailed role breakdown' },
  { id: 'actions', label: 'Next Best Actions', icon: CheckSquare, description: 'Pending and completed actions with owners' },
  { id: 'technical-readiness', label: 'Technical Readiness', icon: ClipboardCheck, description: 'Technical qualification assessment status' },
  { id: 'milestones', label: 'Milestones & Timeline', icon: Calendar, description: 'Mutual action plan timeline' },
  { id: 'validation-tasks', label: 'Validation Tasks', icon: CheckSquare, description: 'Technical validation activities and progress' },
  { id: 'activity-signals', label: 'Activity & Signals', icon: Calendar, description: 'Activity timeline and detected signals' },
  { id: 'evaluation-plan', label: 'Evaluation Plan', icon: FileDown, description: 'Problem → Solution → Proof evaluation framework' },
];

interface ExportMAPDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  accountId: string;
  accountName: string;
  prospectLogoUrl?: string;
  opportunityId?: string;
}

export function ExportMAPDialog({ 
  open, 
  onOpenChange, 
  accountId, 
  accountName,
  prospectLogoUrl,
  opportunityId 
}: ExportMAPDialogProps) {
  const [isExporting, setIsExporting] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [selectedSections, setSelectedSections] = useState<Set<string>>(
    new Set(MAP_SECTIONS.map(s => s.id))
  );
  const documentRef = useRef<HTMLDivElement>(null);

  // Fetch all data needed for Excel export
  const { data: account } = useQuery({
    queryKey: ['export-map-account', accountId],
    queryFn: async () => {
      const { data, error } = await supabase.from('accounts').select('*').eq('id', accountId).single();
      if (error) throw error;
      return data;
    },
    enabled: open,
  });

  const { data: technologies = [] } = useQuery({
    queryKey: ['export-map-technologies', accountId],
    queryFn: async () => {
      const { data, error } = await gateway.from('account_technologies').select('*').eq('account_id', accountId).execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: open,
  });

  const { data: useCases = [] } = useQuery({
    queryKey: ['export-map-use-cases', accountId],
    queryFn: async () => {
      const { data, error } = await gateway.from('account_use_cases').select('*').eq('account_id', accountId).execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: open,
  });

  const { data: opportunities = [] } = useQuery({
    queryKey: ['export-map-opportunities', accountId],
    queryFn: async () => {
      const { data, error } = await supabase.from('opportunities').select('id, name').eq('account_id', accountId);
      if (error) throw error;
      return data;
    },
    enabled: open,
  });

  const primaryOpportunityId = opportunities[0]?.id;

  const { data: milestones = [] } = useQuery({
    queryKey: ['export-map-milestones', primaryOpportunityId],
    queryFn: async () => {
      if (!primaryOpportunityId) return [];
      const { data, error } = await gateway.from('opportunity_milestones').select('*').eq('opportunity_id', primaryOpportunityId).order('sort_order').execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: open && !!primaryOpportunityId,
  });

  const { data: milestoneTemplates = [] } = useQuery({
    queryKey: ['export-map-milestone-templates'],
    queryFn: async () => {
      const { data, error } = await gateway.from('milestone_templates').select('*').order('sort_order').execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: open,
  });

  const { data: validationTasks = [] } = useQuery({
    queryKey: ['export-map-validation-tasks', primaryOpportunityId],
    queryFn: async () => {
      if (!primaryOpportunityId) return [];
      const { data, error } = await gateway.from('opportunity_validation_tasks').select('*').eq('opportunity_id', primaryOpportunityId).order('sort_order').execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: open && !!primaryOpportunityId,
  });

  const { data: validationTemplates = [] } = useQuery({
    queryKey: ['export-map-validation-templates'],
    queryFn: async () => {
      const { data, error } = await supabase.from('validation_task_templates').select('*').order('sort_order');
      if (error) throw error;
      return data;
    },
    enabled: open,
  });

  const { data: readinessCategories = [] } = useQuery({
    queryKey: ['export-map-readiness-categories'],
    queryFn: async () => {
      const { data: categories, error: catError } = await supabase.from('readiness_template_categories').select('*').order('sort_order');
      if (catError) throw catError;
      if (!categories || categories.length === 0) return [];

      const categoryIds = categories.map(c => c.id);
      const { data: questions, error: qError } = await supabase.from('readiness_template_questions').select('*').in('category_id', categoryIds).order('sort_order');
      if (qError) throw qError;

      return categories.map(cat => ({
        ...cat,
        questions: (questions || []).filter(q => q.category_id === cat.id),
      }));
    },
    enabled: open,
  });

  const { data: readinessAnswers = [] } = useQuery({
    queryKey: ['export-map-readiness-answers', primaryOpportunityId],
    queryFn: async () => {
      if (!primaryOpportunityId) return [];
      const { data, error } = await gateway.from('opportunity_readiness_answers').select('*').eq('opportunity_id', primaryOpportunityId).execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: open && !!primaryOpportunityId,
  });

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['export-map-team', accountId],
    queryFn: async () => {
      const { data, error } = await gateway.from('account_team_members').select('*').eq('account_id', accountId).execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: open,
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ['export-map-contacts', accountId],
    queryFn: async () => {
      const { data, error } = await gateway.from('account_contacts').select('*').eq('account_id', accountId).eq('is_internal', false).not('is_ignored', 'is', true).execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: open,
  });

  const toggleSection = (sectionId: string) => {
    setSelectedSections(prev => {
      const next = new Set(prev);
      if (next.has(sectionId)) {
        next.delete(sectionId);
      } else {
        next.add(sectionId);
      }
      return next;
    });
  };

  const selectAll = () => {
    setSelectedSections(new Set(MAP_SECTIONS.map(s => s.id)));
  };

  const selectNone = () => {
    setSelectedSections(new Set());
  };

  const handleExportExcel = async () => {
    setIsExporting(true);
    try {
      toast.loading('Generating Excel...', { id: 'excel-export' });
      
      await exportMAPToExcel({
        accountName,
        accountId,
        industry: account?.industry,
        stage: account?.stage,
        technologies,
        useCases,
        milestones,
        milestoneTemplates,
        validationTasks,
        validationTemplates,
        readinessCategories,
        readinessAnswers,
        teamMembers,
        contacts,
        opportunities,
      });

      toast.success('Excel downloaded!', { id: 'excel-export' });
    } catch (error) {
      console.error('Excel export failed:', error);
      toast.error('Failed to generate Excel', { id: 'excel-export' });
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportPDF = async () => {
    const element = documentRef.current;
    if (!element) return;

    if (selectedSections.size === 0) {
      toast.error('Please select at least one section to export');
      return;
    }

    setIsExporting(true);
    try {
      toast.loading('Generating PDF...', { id: 'pdf-export' });

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
      });

      const imgData = canvas.toDataURL('image/png');
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      const canvasWidth = canvas.width;
      const canvasHeight = canvas.height;
      
      const ratio = canvasWidth / canvasHeight;
      const imgWidth = pdfWidth;
      const imgHeight = pdfWidth / ratio;
      
      let position = 0;
      let heightLeft = imgHeight;
      
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;
      
      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pdfHeight;
      }

      const fileName = `${accountName.replace(/\s+/g, '_')}_Mutual_Activity_Plan.pdf`;
      pdf.save(fileName);

      toast.success('PDF downloaded!', { id: 'pdf-export' });
    } catch (error) {
      console.error('PDF export failed:', error);
      toast.error('Failed to generate PDF', { id: 'pdf-export' });
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportImage = async () => {
    const element = documentRef.current;
    if (!element) return;

    if (selectedSections.size === 0) {
      toast.error('Please select at least one section to export');
      return;
    }

    setIsExporting(true);
    try {
      toast.loading('Generating image...', { id: 'image-export' });

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
      });

      const link = document.createElement('a');
      link.download = `${accountName.replace(/\s+/g, '_')}_Mutual_Activity_Plan.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();

      toast.success('Image downloaded!', { id: 'image-export' });
    } catch (error) {
      console.error('Image export failed:', error);
      toast.error('Failed to generate image', { id: 'image-export' });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[90vh] p-0 overflow-hidden">
        <DialogHeader className="p-4 pb-3 border-b border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {showSettings && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowSettings(false)}
                >
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              )}
              <DialogTitle className="text-lg">
                {showSettings ? 'Configure Sections' : 'Mutual Activity Plan Preview'}
              </DialogTitle>
            </div>
            {!showSettings && (
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowSettings(true)}
                >
                  <Settings2 className="w-4 h-4 mr-2" />
                  Sections ({selectedSections.size})
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleExportImage}
                  disabled={isExporting || selectedSections.size === 0}
                >
                  <Download className="w-4 h-4 mr-2" />
                  PNG
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleExportExcel}
                  disabled={isExporting}
                  className="text-green-600 border-green-600/50 hover:bg-green-600/10"
                >
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  Excel
                </Button>
                <Button
                  size="sm"
                  onClick={handleExportPDF}
                  disabled={isExporting || selectedSections.size === 0}
                >
                  <FileDown className="w-4 h-4 mr-2" />
                  Download PDF
                </Button>
              </div>
            )}
          </div>
        </DialogHeader>

        {showSettings ? (
          <div className="p-6 space-y-4">
            {/* Section Picker */}
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Select Sections to Include</h3>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" onClick={selectAll}>
                  Select All
                </Button>
                <Button variant="ghost" size="sm" onClick={selectNone}>
                  Clear All
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              {MAP_SECTIONS.map(section => {
                const Icon = section.icon;
                const isSelected = selectedSections.has(section.id);
                
                return (
                  <div
                    key={section.id}
                    className={`flex items-start gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      isSelected 
                        ? 'border-primary bg-primary/5' 
                        : 'border-border hover:border-muted-foreground/50'
                    }`}
                    onClick={() => toggleSection(section.id)}
                  >
                    <Checkbox
                      checked={isSelected}
                      onCheckedChange={() => toggleSection(section.id)}
                      className="mt-0.5"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4 text-muted-foreground" />
                        <Label className="font-medium cursor-pointer">{section.label}</Label>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {section.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-4 border-t border-border">
              <Button onClick={() => setShowSettings(false)}>
                Done
              </Button>
            </div>
          </div>
        ) : (
          <ScrollArea className="h-[75vh]">
            <div className="flex justify-center p-4 bg-muted/30">
              <div 
                className="bg-white shadow-xl rounded-lg overflow-hidden"
                style={{ 
                  transform: 'scale(0.6)', 
                  transformOrigin: 'top center',
                  marginBottom: '-40%'
                }}
              >
                <MAPDocument
                  ref={documentRef}
                  accountId={accountId}
                  accountName={accountName}
                  selectedSections={selectedSections}
                  prospectLogoUrl={prospectLogoUrl}
                  opportunityId={opportunityId}
                />
              </div>
            </div>
          </ScrollArea>
        )}

        {/* Hidden document for export (full scale) */}
        <div className="fixed left-[-9999px] top-0">
          <MAPDocument
            ref={documentRef}
            accountId={accountId}
            accountName={accountName}
            selectedSections={selectedSections}
            prospectLogoUrl={prospectLogoUrl}
            opportunityId={opportunityId}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}

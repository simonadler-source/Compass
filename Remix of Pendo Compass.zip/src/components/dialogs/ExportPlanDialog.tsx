import { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Account } from '@/types/architecture';
import { AccountPlanDocument } from '@/components/AccountPlanDocument';
import { FileDown, Image, FileText, Eye, Download } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { toast } from 'sonner';
import { ScrollArea } from '@/components/ui/scroll-area';

interface ExportPlanDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  account: Account;
}

export function ExportPlanDialog({ open, onOpenChange, account }: ExportPlanDialogProps) {
  const [isExporting, setIsExporting] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const documentRef = useRef<HTMLDivElement>(null);

  const handleExportPDF = async () => {
    const element = documentRef.current;
    if (!element) return;

    setIsExporting(true);
    try {
      toast.loading('Generating PDF...', { id: 'pdf-export' });

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#0f1419',
      });

      const imgData = canvas.toDataURL('image/png');
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      const canvasWidth = canvas.width;
      const canvasHeight = canvas.height;
      
      const ratio = canvasWidth / canvasHeight;
      const imgWidth = pdfWidth;
      const imgHeight = pdfWidth / ratio;
      
      let position = 0;
      let heightLeft = imgHeight;
      
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;
      
      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pdfHeight;
      }

      const fileName = `${account.name.replace(/\s+/g, '_')}_Technical_Account_Plan.pdf`;
      pdf.save(fileName);

      toast.success('PDF downloaded!', { id: 'pdf-export' });
    } catch (error) {
      console.error('PDF export failed:', error);
      toast.error('Failed to generate PDF', { id: 'pdf-export' });
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportImage = async () => {
    const element = documentRef.current;
    if (!element) return;

    setIsExporting(true);
    try {
      toast.loading('Generating image...', { id: 'image-export' });

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#0f1419',
      });

      const link = document.createElement('a');
      link.download = `${account.name.replace(/\s+/g, '_')}_Technical_Account_Plan.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();

      toast.success('Image downloaded!', { id: 'image-export' });
    } catch (error) {
      console.error('Image export failed:', error);
      toast.error('Failed to generate image', { id: 'image-export' });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] p-0 overflow-hidden">
        <DialogHeader className="p-6 pb-4 border-b border-border">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl">
              Export Technical Account Plan
            </DialogTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPreviewMode(!previewMode)}
              >
                <Eye className="w-4 h-4 mr-2" />
                {previewMode ? 'Hide Preview' : 'Show Preview'}
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="p-6">
          {!previewMode ? (
            <div className="space-y-6">
              <div className="text-center py-8">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                  <FileText className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">
                  Generate Account Plan for {account.name}
                </h3>
                <p className="text-muted-foreground max-w-md mx-auto">
                  Create a beautiful, structured technical account plan document ready for sharing with stakeholders.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 max-w-lg mx-auto">
                <Button
                  size="lg"
                  onClick={handleExportPDF}
                  disabled={isExporting}
                  className="h-24 flex-col gap-2"
                >
                  <FileDown className="w-6 h-6" />
                  <span>Download PDF</span>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={handleExportImage}
                  disabled={isExporting}
                  className="h-24 flex-col gap-2"
                >
                  <Image className="w-6 h-6" />
                  <span>Download Image</span>
                </Button>
              </div>

              <div className="bg-muted/50 rounded-lg p-4 max-w-lg mx-auto">
                <h4 className="font-medium mb-2">Document includes:</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Account summary with industry and stage</li>
                  <li>• Complete technical architecture map</li>
                  <li>• Priority focus areas and recommendations</li>
                  <li>• Detailed technology specifications</li>
                </ul>
              </div>
            </div>
          ) : (
            <ScrollArea className="h-[60vh]">
              <div className="flex justify-center pb-6">
                <div className="transform scale-[0.4] origin-top">
                  <AccountPlanDocument ref={documentRef} account={account} />
                </div>
              </div>
            </ScrollArea>
          )}
        </div>

        {/* Hidden document for export */}
        <div className="fixed left-[-9999px] top-0">
          <AccountPlanDocument ref={documentRef} account={account} />
        </div>
      </DialogContent>
    </Dialog>
  );
}

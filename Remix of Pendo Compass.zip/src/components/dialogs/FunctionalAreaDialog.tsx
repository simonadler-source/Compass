import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { FunctionalArea } from "@/hooks/useTechnologyRepository";

const LAYERS = [
  { value: "host", label: "Host" },
  { value: "build", label: "Build" },
  { value: "adopt", label: "Adopt" },
  { value: "growth", label: "Growth" },
] as const;

type FunctionalAreaCreate = Omit<FunctionalArea, "id" | "created_at">;

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  existingArea: FunctionalArea | null;
  defaultSortOrder: number;
  onCreate: (area: FunctionalAreaCreate) => void;
  onUpdate: (area: Partial<FunctionalArea> & { id: string }) => void;
};

export function FunctionalAreaDialog({
  open,
  onOpenChange,
  existingArea,
  defaultSortOrder,
  onCreate,
  onUpdate,
}: Props) {
  const isEdit = !!existingArea;

  const initialLayer = existingArea?.layer ?? "adopt";

  const [name, setName] = useState("");
  const [layer, setLayer] = useState<string>(initialLayer);
  const [description, setDescription] = useState("");
  const [color, setColor] = useState("hsl(220 70% 50%)");
  const [defaultWidth, setDefaultWidth] = useState<number>(200);
  const [defaultHeight, setDefaultHeight] = useState<number>(100);
  const [sortOrder, setSortOrder] = useState<number>(defaultSortOrder);

  const title = isEdit ? "Edit Functional Area" : "Add Functional Area";

  const canSubmit = useMemo(() => {
    return name.trim().length > 0 && layer.trim().length > 0 && color.trim().length > 0;
  }, [name, layer, color]);

  useEffect(() => {
    if (!open) return;

    if (existingArea) {
      setName(existingArea.name);
      setLayer(existingArea.layer ?? "adopt");
      setDescription(existingArea.description ?? "");
      setColor(existingArea.color ?? "hsl(220 70% 50%)");
      setDefaultWidth(existingArea.default_width ?? 200);
      setDefaultHeight(existingArea.default_height ?? 100);
      setSortOrder(existingArea.sort_order ?? defaultSortOrder);
    } else {
      setName("");
      setLayer("adopt");
      setDescription("");
      setColor("hsl(220 70% 50%)");
      setDefaultWidth(200);
      setDefaultHeight(100);
      setSortOrder(defaultSortOrder);
    }
  }, [open, existingArea, defaultSortOrder]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;

    const payload = {
      name: name.trim(),
      layer,
      description: description.trim() ? description.trim() : null,
      color: color.trim(),
      default_width: Number.isFinite(defaultWidth) ? defaultWidth : 200,
      default_height: Number.isFinite(defaultHeight) ? defaultHeight : 100,
      sort_order: Number.isFinite(sortOrder) ? sortOrder : defaultSortOrder,
    };

    if (existingArea) {
      onUpdate({ id: existingArea.id, ...payload });
    } else {
      onCreate(payload as FunctionalAreaCreate);
    }

    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="fa-name">Name</Label>
            <Input
              id="fa-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Analytics & Insights"
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Layer</Label>
            <Select value={layer} onValueChange={setLayer}>
              <SelectTrigger>
                <SelectValue placeholder="Select a layer" />
              </SelectTrigger>
              <SelectContent>
                {LAYERS.map((l) => (
                  <SelectItem key={l.value} value={l.value}>
                    {l.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="fa-desc">Description (optional)</Label>
            <Textarea
              id="fa-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Short description shown in the list"
              rows={2}
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="fa-color">Color (HSL)</Label>
              <div className="flex items-center gap-2">
                <div
                  className="h-9 w-9 rounded-md border border-border"
                  style={{ backgroundColor: color }}
                  aria-label="Functional area color preview"
                />
                <Input
                  id="fa-color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  placeholder="hsl(220 70% 50%)"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Tip: use an HSL color like <span className="font-mono">hsl(220 70% 50%)</span>
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="fa-order">Sort order</Label>
              <Input
                id="fa-order"
                type="number"
                inputMode="numeric"
                value={String(sortOrder)}
                onChange={(e) => setSortOrder(Number(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">Lower shows first within the layer.</p>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="fa-w">Default width</Label>
              <Input
                id="fa-w"
                type="number"
                inputMode="numeric"
                value={String(defaultWidth)}
                onChange={(e) => setDefaultWidth(Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fa-h">Default height</Label>
              <Input
                id="fa-h"
                type="number"
                inputMode="numeric"
                value={String(defaultHeight)}
                onChange={(e) => setDefaultHeight(Number(e.target.value))}
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!canSubmit}>
              {isEdit ? "Save changes" : "Create area"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

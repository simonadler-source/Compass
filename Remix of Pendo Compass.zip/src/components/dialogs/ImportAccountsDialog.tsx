import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Upload, FileText, CheckCircle, AlertCircle, Download, RefreshCw, Database, Zap, CheckCheck } from 'lucide-react';
import { toast } from 'sonner';
import { gateway } from '@/lib/apiGateway';

interface ImportAccountsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface CSVRow {
  accountName: string;
  accountId?: string;
  opportunityName?: string;
  opportunityId?: string;
  salesStage?: string;
  preSalesStage?: string;
  closeDate?: string;
  arrUsd?: number;
  ownerEmail?: string;
  seEmail?: string;
  tcvCurrency?: string;
  tcv?: number;
  nextStep?: string;
  opportunityType?: string;
  initialProductInterest?: string[];
  primaryEvalQuote?: string;
  evalStartDate?: string;
  evalEndDate?: string;
  evalType?: string;
  evalDocumentsNotes?: string;
  seNotes?: string;
}

interface ColumnMapping {
  accountName: string;
  accountId: string;
  opportunityName: string;
  opportunityId: string;
  salesStage: string;
  preSalesStage: string;
  closeDate: string;
  arrUsd: string;
  ownerEmail: string;
  seEmail: string;
  tcvCurrency: string;
  tcv: string;
  nextStep: string;
  opportunityType: string;
  initialProductInterest: string;
  primaryEvalQuote: string;
  evalStartDate: string;
  evalEndDate: string;
  evalType: string;
  evalDocumentsNotes: string;
  seNotes: string;
}

interface ImportPhase {
  phase: 'idle' | 'fetching' | 'matching' | 'processing' | 'complete';
  message: string;
  current: number;
  total: number;
  currentItem?: string;
}

interface ActivityLogEntry {
  type: 'info' | 'success' | 'warning' | 'error';
  message: string;
  timestamp: number;
}

// Validate that a string looks like an email (not a date or other data)
const validateEmail = (value?: string): string | undefined => {
  if (!value) return undefined;
  const trimmed = value.trim();
  if (!trimmed || !trimmed.includes('@') || /^\d+[\/\-]/.test(trimmed)) return undefined;
  return trimmed;
};

// Sample CSV matching actual Salesforce export format
const SAMPLE_CSV = `"Account Name","Account ID","Opportunity Name","Opportunity ID","Stage","PreSales Stage","Close Date","ARR (USD)","Opportunity Owner Email","Primary Sales Engineer","TCV Currency","TCV","Next Step","Type","Initial Product Interest","Primary Eval Quote","Actual Eval Start Date","Actual Eval End Date","Evaluation Type","Eval Documents/Notes","SE Notes"
"Acme Corp","0010a00001abc123","Acme Corp - Enterprise Deal","006Pf000005oBBt","Stage 2","Discovery","3/15/2025","150000.00","ae@company.com","se@company.com","USD","175000.00","Schedule technical deep dive","New Business","Analytics, Guides","Q-12345","1/10/2025","3/10/2025","POC","https://docs.google.com/doc1 https://confluence.example.com/eval-notes","Waiting on security review results"
"Global Industries","0010a00001def456","Global Industries - Renewals - 2025","006Pf000005oCCu","Closed Won","Technical Win","2/28/2025","250000.00","ae2@company.com","","EUR","220000.00","","Renewals","Analytics, Session Replay, Feedback","","","","","",""`;

export function ImportAccountsDialog({ open, onOpenChange }: ImportAccountsDialogProps) {
  const [step, setStep] = useState<'upload' | 'mapping' | 'preview' | 'importing' | 'complete'>('upload');
  const [csvData, setCsvData] = useState<string[][]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [updateOnlyMode, setUpdateOnlyMode] = useState(false);
  const [mapping, setMapping] = useState<ColumnMapping>({
    accountName: '',
    accountId: '',
    opportunityName: '',
    opportunityId: '',
    salesStage: '',
    preSalesStage: '',
    closeDate: '',
    arrUsd: '',
    ownerEmail: '',
    seEmail: '',
    tcvCurrency: '',
    tcv: '',
    nextStep: '',
    opportunityType: '',
    initialProductInterest: '',
    primaryEvalQuote: '',
    evalStartDate: '',
    evalEndDate: '',
    evalType: '',
    evalDocumentsNotes: '',
    seNotes: '',
  });
  const [parsedRows, setParsedRows] = useState<CSVRow[]>([]);
  const [importPhase, setImportPhase] = useState<ImportPhase>({ phase: 'idle', message: '', current: 0, total: 0 });
  const [activityLog, setActivityLog] = useState<ActivityLogEntry[]>([]);
  const [importResults, setImportResults] = useState<{ 
    accountsCreated: number;
    accountsUpdated: number;
    opportunitiesCreated: number;
    opportunitiesUpdated: number;
    accountsReactivated: number;
    docsCreated: number;
    seNotesUpserted: number;
    skipped: number;
    failed: number;
    errors: string[];
  }>({ accountsCreated: 0, accountsUpdated: 0, opportunitiesCreated: 0, opportunitiesUpdated: 0, accountsReactivated: 0, docsCreated: 0, seNotesUpserted: 0, skipped: 0, failed: 0, errors: [] });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addLog = (type: ActivityLogEntry['type'], message: string) => {
    setActivityLog(prev => [...prev.slice(-49), { type, message, timestamp: Date.now() }]);
  };

  const resetState = () => {
    setStep('upload');
    setCsvData([]);
    setHeaders([]);
    setUpdateOnlyMode(false);
    setMapping({ 
      accountName: '', 
      accountId: '', 
      opportunityName: '', 
      opportunityId: '',
      salesStage: '',
      preSalesStage: '',
      closeDate: '',
      arrUsd: '',
      ownerEmail: '',
      seEmail: '',
      tcvCurrency: '',
      tcv: '',
      nextStep: '',
      opportunityType: '',
      initialProductInterest: '',
      primaryEvalQuote: '',
      evalStartDate: '',
      evalEndDate: '',
      evalType: '',
      evalDocumentsNotes: '',
      seNotes: '',
    });
    setParsedRows([]);
    setImportPhase({ phase: 'idle', message: '', current: 0, total: 0 });
    setActivityLog([]);
    setImportResults({ accountsCreated: 0, accountsUpdated: 0, opportunitiesCreated: 0, opportunitiesUpdated: 0, accountsReactivated: 0, docsCreated: 0, seNotesUpserted: 0, skipped: 0, failed: 0, errors: [] });
  };

  const handleClose = () => {
    resetState();
    onOpenChange(false);
  };

  const parseCSV = (text: string): string[][] => {
    const lines = text.split('\n').filter(line => line.trim());
    return lines.map(line => {
      const result: string[] = [];
      let current = '';
      let inQuotes = false;
      
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim());
      return result;
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.csv')) {
      toast.error('Please upload a CSV file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const data = parseCSV(text);
      
      if (data.length < 2) {
        toast.error('CSV must have at least a header row and one data row');
        return;
      }

      setHeaders(data[0]);
      setCsvData(data.slice(1));
      
      // Auto-detect column mappings for Salesforce exports
      const headerLower = data[0].map(h => h.toLowerCase().trim());
      const findHeader = (patterns: string[]) => {
        const idx = headerLower.findIndex(h => patterns.some(p => h.includes(p) || h === p));
        return idx >= 0 ? data[0][idx] : '';
      };
      
      const autoMapping: ColumnMapping = {
        accountName: findHeader(['account name', 'account', 'company', 'company name']),
        accountId: findHeader(['account id (18)', 'account id', 'accountid', 'account: id', 'sfdc account id']),
        opportunityName: findHeader(['opportunity name', 'opportunity', 'deal', 'deal name', 'opp name']),
        opportunityId: findHeader(['opportunity id (18)', 'opportunity id', 'opportunityid', 'opp id', 'sfdc opportunity id']),
        salesStage: findHeader(['stage', 'sales stage', 'opportunity stage', 'status']),
        preSalesStage: findHeader(['presales stage', 'pre-sales stage', 'pre sales stage', 'technical stage']),
        closeDate: findHeader(['close date', 'closedate', 'expected close', 'close']),
        arrUsd: findHeader(['arr (usd)', 'arr', 'amount', 'value', 'deal value', 'revenue', 'opportunity amount']),
        ownerEmail: findHeader(['opportunity owner email', 'owner email', 'owner', 'account executive', 'ae email', 'rep email']),
        seEmail: findHeader(['primary sales engineer', 'se email', 'sales engineer', 'se', 'engineer email', 'technical rep']),
        tcvCurrency: findHeader(['tcv currency', 'currency', 'deal currency']),
        tcv: findHeader(['tcv', 'total contract value']),
        nextStep: findHeader(['next step', 'next steps', 'nextstep']),
        opportunityType: findHeader(['type', 'opportunity type', 'deal type']),
        initialProductInterest: findHeader(['initial product interest', 'product interest', 'products', 'modules']),
        primaryEvalQuote: findHeader(['primary eval quote', 'eval quote', 'evaluation quote', 'trial quote']),
        evalStartDate: findHeader(['actual eval start date', 'eval start date', 'evaluation start', 'trial start']),
        evalEndDate: findHeader(['actual eval end date', 'eval end date', 'evaluation end', 'trial end']),
        evalType: findHeader(['evaluation type', 'eval type', 'trial type']),
        evalDocumentsNotes: findHeader(['eval documents/notes', 'eval documents', 'eval notes', 'evaluation documents', 'evaluation notes']),
        seNotes: findHeader(['se notes', 'se update', 'se weekly update', 'se next steps']),
      };
      
      setMapping(autoMapping);
      setStep('mapping');
    };
    reader.readAsText(file);
  };

  const handleMappingComplete = () => {
    if (!mapping.accountName) {
      toast.error('Account Name mapping is required');
      return;
    }

    const getIdx = (field: string) => field ? headers.indexOf(field) : -1;
    
    const indices = {
      accountName: getIdx(mapping.accountName),
      accountId: getIdx(mapping.accountId),
      opportunityName: getIdx(mapping.opportunityName),
      opportunityId: getIdx(mapping.opportunityId),
      salesStage: getIdx(mapping.salesStage),
      preSalesStage: getIdx(mapping.preSalesStage),
      closeDate: getIdx(mapping.closeDate),
      arrUsd: getIdx(mapping.arrUsd),
      ownerEmail: getIdx(mapping.ownerEmail),
      seEmail: getIdx(mapping.seEmail),
      tcvCurrency: getIdx(mapping.tcvCurrency),
      tcv: getIdx(mapping.tcv),
      nextStep: getIdx(mapping.nextStep),
      opportunityType: getIdx(mapping.opportunityType),
      initialProductInterest: getIdx(mapping.initialProductInterest),
      primaryEvalQuote: getIdx(mapping.primaryEvalQuote),
      evalStartDate: getIdx(mapping.evalStartDate),
      evalEndDate: getIdx(mapping.evalEndDate),
      evalType: getIdx(mapping.evalType),
      evalDocumentsNotes: getIdx(mapping.evalDocumentsNotes),
      seNotes: getIdx(mapping.seNotes),
    };

    const rows: CSVRow[] = csvData.map(row => {
      // Parse product interest (comma or semicolon-separated)
      let productInterest: string[] | undefined;
      if (indices.initialProductInterest >= 0 && row[indices.initialProductInterest]?.trim()) {
        productInterest = row[indices.initialProductInterest]
          .split(/[,;]/) // Support both comma and semicolon
          .map(p => p.trim())
          .filter(p => p.length > 0);
      }

      return {
        accountName: row[indices.accountName] || '',
        accountId: indices.accountId >= 0 ? row[indices.accountId]?.trim() : undefined,
        opportunityName: indices.opportunityName >= 0 ? row[indices.opportunityName]?.trim() : undefined,
        opportunityId: indices.opportunityId >= 0 ? row[indices.opportunityId]?.trim() : undefined,
        salesStage: indices.salesStage >= 0 ? row[indices.salesStage]?.trim() : undefined,
        preSalesStage: indices.preSalesStage >= 0 ? row[indices.preSalesStage]?.trim() : undefined,
        closeDate: indices.closeDate >= 0 ? parseDate(row[indices.closeDate]?.trim()) : undefined,
        arrUsd: indices.arrUsd >= 0 ? parseNumber(row[indices.arrUsd]) : undefined,
        ownerEmail: indices.ownerEmail >= 0 ? validateEmail(row[indices.ownerEmail]?.trim()) : undefined,
        seEmail: indices.seEmail >= 0 ? validateEmail(row[indices.seEmail]?.trim()) : undefined,
        tcvCurrency: indices.tcvCurrency >= 0 ? row[indices.tcvCurrency]?.trim() : undefined,
        tcv: indices.tcv >= 0 ? parseNumber(row[indices.tcv]) : undefined,
        nextStep: indices.nextStep >= 0 ? row[indices.nextStep]?.trim() : undefined,
        opportunityType: indices.opportunityType >= 0 ? row[indices.opportunityType]?.trim() : undefined,
        initialProductInterest: productInterest,
        primaryEvalQuote: indices.primaryEvalQuote >= 0 ? row[indices.primaryEvalQuote]?.trim() || undefined : undefined,
        evalStartDate: indices.evalStartDate >= 0 ? parseDate(row[indices.evalStartDate]?.trim()) : undefined,
        evalEndDate: indices.evalEndDate >= 0 ? parseDate(row[indices.evalEndDate]?.trim()) : undefined,
        evalType: indices.evalType >= 0 ? row[indices.evalType]?.trim() || undefined : undefined,
        evalDocumentsNotes: indices.evalDocumentsNotes >= 0 ? row[indices.evalDocumentsNotes]?.trim() || undefined : undefined,
        seNotes: indices.seNotes >= 0 ? row[indices.seNotes]?.trim() || undefined : undefined,
      };
    }).filter(row => row.accountName.trim());

    setParsedRows(rows);
    setStep('preview');
  };

  // Parse date from various formats (M/D/YYYY, MM/DD/YYYY, YYYY-MM-DD)
  const parseDate = (dateStr?: string): string | undefined => {
    if (!dateStr) return undefined;
    
    // Try M/D/YYYY or MM/DD/YYYY format
    const mdyMatch = dateStr.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (mdyMatch) {
      const [, month, day, year] = mdyMatch;
      return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    
    // Already in YYYY-MM-DD format
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      return dateStr;
    }
    
    return dateStr;
  };

  // Parse number, properly handling 0 values and empty strings
  const parseNumber = (value?: string): number | undefined => {
    if (!value || value.trim() === '') return undefined;
    const cleaned = value.replace(/[^0-9.-]/g, '');
    if (cleaned === '' || cleaned === '-') return undefined;
    const num = parseFloat(cleaned);
    return isNaN(num) ? undefined : num;
  };

  const normalizeSfdcId = (id?: string) => {
    const v = (id ?? '').trim();
    return v.length ? v : undefined;
  };

  const sfdcPrefix15 = (id?: string) => {
    const v = normalizeSfdcId(id);
    return v ? v.slice(0, 15) : undefined;
  };

  // Terminal stages that should set is_archived = true
  const TERMINAL_STAGES = new Set([
    'closed_won', 'closed_lost', 'disqualified', 'closed/shifted',
    'closed/cancelled shift', 'stage_5_sales_won', 'stage_6_closed_won',
    'stage_7_closed_lost', 'closed_shifted', 'closed_cancelled_shift',
    'crm_disqualified', 'crm_other',
  ]);

  // Check if stage indicates closed/terminal opportunity
  const isClosedOpportunityStage = (stage?: string): boolean => {
    if (!stage) return false;
    const s = stage.toLowerCase().trim();
    if (TERMINAL_STAGES.has(s)) return true;
    // Catch any "closed" variant not explicitly listed
    if (s.includes('closed') || s.includes('disqualified')) return true;
    return false;
  };

  // Normalize Salesforce stage values to internal format
  const normalizeSalesStage = (stage?: string): string => {
    if (!stage) return 'stage_1';
    const s = stage.toLowerCase().trim();
    // Exact internal values - pass through
    if (['stage_0','stage_1','stage_2','stage_3','stage_4','closed_won','closed_lost',
         'stage_6','stage_7_closed_lost','stage_5_sales_won','stage_6_closed_won'].includes(s)) return s;
    // Disqualified variants
    if (s === 'disqualified' || s === 'crm_disqualified') return 'Disqualified';
    // Closed/Shifted variants
    if (s.includes('closed') && s.includes('shift')) {
      if (s.includes('cancel')) return 'Closed/Cancelled Shift';
      return 'Closed/Shifted';
    }
    // CRM other
    if (s === 'crm_other') return 'CRM_OTHER';
    // Numbered stages from Salesforce labels
    if (s.includes('stage 0') || s.includes('qualification')) return 'stage_0';
    if (s.includes('stage 1') || s === 'discovery') return 'stage_1';
    if (s.includes('stage 2') || s.includes('solution')) return 'stage_2';
    if (s.includes('stage 3') || s.includes('proof')) return 'stage_3';
    if (s.includes('stage 4') || s.includes('negotiate')) return 'stage_4';
    if (s.includes('stage 7') || (s.includes('closed') && s.includes('lost'))) return 'closed_lost';
    if (s.includes('stage 6') || s.includes('closed won')) return 'closed_won';
    if (s.includes('stage 5') || (s.includes('closed') && s.includes('won'))) return 'closed_won';
    return stage;
  };

  // Normalize to Title Case format expected by UI dropdowns
  const normalizePreSalesStage = (stage?: string): string => {
    if (!stage) return 'Discovery';
    const s = stage.toLowerCase().trim();
    if (s === 'not started') return 'Not Started';
    if (s.includes('discovery')) return 'Discovery';
    if (s.includes('demo')) return 'Demo';
    if (s.includes('scoping')) return 'Proof - Scoping';
    if (s.includes('proof')) return 'Proof';
    if (s.includes('technical win')) return 'Technical Win';
    if (s.includes('technical loss')) return 'Technical Loss';
    if (s.includes('unqualified')) return 'Unqualified';
    if (s.includes('stale') || s.includes('not active')) return 'Stale / Not Active';
    return stage;
  };

  const handleImport = async () => {
    setStep('importing');
    setActivityLog([]);
    
    let accountsCreated = 0;
    let accountsUpdated = 0;
    let opportunitiesCreated = 0;
    let opportunitiesUpdated = 0;
    let accountsReactivated = 0;
    let skipped = 0;
    let failed = 0;
    const errors: string[] = [];

    // Group rows by account
    const accountGroups = new Map<string, { sfAccountId?: string; rows: CSVRow[] }>();
    for (const row of parsedRows) {
      const key = row.accountId || row.accountName;
      if (!accountGroups.has(key)) {
        accountGroups.set(key, { sfAccountId: row.accountId, rows: [] });
      }
      accountGroups.get(key)!.rows.push(row);
    }

    // ============ PHASE 1: Batch fetch existing data ============
    setImportPhase({ phase: 'fetching', message: 'Fetching existing accounts...', current: 0, total: 3 });
    addLog('info', '🔍 Starting batch data fetch...');

    // Collect unique identifiers for batch query
    const uniqueAccountNames = [...new Set(parsedRows.map(r => r.accountName.toLowerCase()))];
    const uniqueAccountSfIds = [...new Set(parsedRows.map(r => normalizeSfdcId(r.accountId)).filter(Boolean) as string[])];
    const uniqueOppSfIds = [...new Set(parsedRows.map(r => normalizeSfdcId(r.opportunityId)).filter(Boolean) as string[])];

    // Build lookup maps
    const accountBySfId = new Map<string, { id: string; relationship_status: string | null; salesforce_account_id: string | null }>();
    const accountByName = new Map<string, { id: string; relationship_status: string | null; salesforce_account_id: string | null }>();
    const oppBySfId = new Map<string, { id: string; is_archived: boolean | null; salesforce_opportunity_id: string | null; account_id: string }>();
    const oppByAccountAndName = new Map<string, { id: string; is_archived: boolean | null; salesforce_opportunity_id: string | null; account_id: string }>();
    
    // Pendo module lookup for mapping product interest to module IDs
    const moduleByName = new Map<string, string>(); // lowercase name/alias -> module ID

    try {
      // Fetch accounts in batches (by SFDC ID and name)
      addLog('info', `📊 Fetching ${uniqueAccountSfIds.length} accounts by Salesforce ID...`);
      if (uniqueAccountSfIds.length > 0) {
        // Query in chunks to avoid overly long queries
        const chunkSize = 50;
        for (let i = 0; i < uniqueAccountSfIds.length; i += chunkSize) {
          const chunk = uniqueAccountSfIds.slice(i, i + chunkSize);
          const res = await gateway
            .from('accounts')
            .select('id, relationship_status, salesforce_account_id, name')
            .in('salesforce_account_id', chunk)
            .execute();
          
          if (res.data) {
            for (const acc of res.data as any[]) {
              if (acc.salesforce_account_id) {
                // Trim the ID to handle any whitespace in DB records
                const sfId = acc.salesforce_account_id.trim();
                accountBySfId.set(sfId, acc);
                // Also map by 15-char prefix
                accountBySfId.set(sfId.slice(0, 15), acc);
              }
              if (acc.name) {
                accountByName.set(acc.name.toLowerCase(), acc);
              }
            }
          }
        }
      }

      setImportPhase({ phase: 'fetching', message: 'Fetching existing accounts by name...', current: 1, total: 3 });
      addLog('info', `📊 Fetching accounts by name (${uniqueAccountNames.length} unique names)...`);
      
      // Fetch by name for accounts not matched by SFDC ID
      const unmatchedNames = uniqueAccountNames.filter(n => !accountByName.has(n));
      if (unmatchedNames.length > 0) {
        const chunkSize = 50;
        for (let i = 0; i < unmatchedNames.length; i += chunkSize) {
          const chunk = unmatchedNames.slice(i, i + chunkSize);
          const res = await gateway
            .from('accounts')
            .select('id, relationship_status, salesforce_account_id, name')
            .in('name', chunk.map(n => n.charAt(0).toUpperCase() + n.slice(1))) // Try with title case
            .execute();
          
          if (res.data) {
            for (const acc of res.data as any[]) {
              if (acc.name) {
                accountByName.set(acc.name.toLowerCase(), acc);
              }
            }
          }
        }
      }
      
      addLog('success', `✅ Found ${accountBySfId.size + accountByName.size} existing accounts`);

      // Fetch opportunities by SFDC ID
      setImportPhase({ phase: 'fetching', message: 'Fetching existing opportunities...', current: 2, total: 3 });
      addLog('info', `📊 Fetching ${uniqueOppSfIds.length} opportunities by Salesforce ID...`);
      
      if (uniqueOppSfIds.length > 0) {
        const chunkSize = 50;
        for (let i = 0; i < uniqueOppSfIds.length; i += chunkSize) {
          const chunk = uniqueOppSfIds.slice(i, i + chunkSize);
          const res = await gateway
            .from('opportunities')
            .select('id, is_archived, salesforce_opportunity_id, account_id, name')
            .in('salesforce_opportunity_id', chunk)
            .execute();
          
          if (res.data) {
            for (const opp of res.data as any[]) {
              if (opp.salesforce_opportunity_id) {
                // Trim the ID to handle any whitespace in DB records
                const sfId = opp.salesforce_opportunity_id.trim();
                oppBySfId.set(sfId, opp);
                oppBySfId.set(sfId.slice(0, 15), opp);
              }
              if (opp.account_id && opp.name) {
                oppByAccountAndName.set(`${opp.account_id}:${opp.name.toLowerCase()}`, opp);
              }
            }
          }
        }
      }
      
      addLog('success', `✅ Found ${oppBySfId.size} existing opportunities`);
      
      // Fetch Pendo modules for product interest mapping from module_pricing (used by IncludedModulesSelector)
      addLog('info', '📦 Fetching pricing modules for product mapping...');
      const modulesRes = await gateway
        .from('module_pricing')
        .select('id, module_name')
        .eq('is_active', true)
        .execute();
      
      if (modulesRes.data) {
        for (const mod of modulesRes.data as any[]) {
          const name = mod.module_name?.toLowerCase() || '';
          moduleByName.set(name, mod.id);
          // Add common aliases (e.g., "Guides Pro" -> also match "guides")
          // Handle variations like "Session Replay" matching "session replay"
          const simplified = name.replace(/\s+pro$/i, '').trim();
          if (simplified !== name) {
            moduleByName.set(simplified, mod.id);
          }
        }
        addLog('success', `✅ Loaded ${modulesRes.data.length} pricing modules for mapping`);
      }
      
      setImportPhase({ phase: 'fetching', message: 'Data fetch complete', current: 3, total: 3 });

    } catch (err: any) {
      addLog('error', `❌ Failed to fetch existing data: ${err.message}`);
      errors.push(`Data fetch failed: ${err.message}`);
      setImportResults({ accountsCreated, accountsUpdated, opportunitiesCreated, opportunitiesUpdated, accountsReactivated, docsCreated: 0, seNotesUpserted: 0, skipped, failed: 1, errors });
      setStep('complete');
      return;
    }

    // ============ PHASE 2: Match records (in-memory) ============
    setImportPhase({ phase: 'matching', message: 'Matching records...', current: 0, total: accountGroups.size });
    addLog('info', '🔗 Matching CSV records to existing data...');

    // Pre-compute matches
    type AccountMatch = {
      existing: { id: string; relationship_status: string | null; salesforce_account_id: string | null } | null;
      needsCreate: boolean;
      updates: Record<string, any>;
    };
    type OppMatch = {
      row: CSVRow;
      existing: { id: string; is_archived: boolean | null; salesforce_opportunity_id: string | null } | null;
      needsCreate: boolean;
      updates: Record<string, any>;
    };

    const accountMatches = new Map<string, AccountMatch>();
    const oppMatches: OppMatch[] = [];

    let matchCount = 0;
    for (const [key, group] of accountGroups) {
      matchCount++;
      setImportPhase({ phase: 'matching', message: `Matching: ${group.rows[0].accountName}`, current: matchCount, total: accountGroups.size });

      const firstRow = group.rows[0];
      const sfAccountId = normalizeSfdcId(group.sfAccountId);
      const sfAccountId15 = sfdcPrefix15(group.sfAccountId);

      // Find existing account
      let existingAccount = sfAccountId ? (accountBySfId.get(sfAccountId) || accountBySfId.get(sfAccountId15!)) : null;
      if (!existingAccount) {
        existingAccount = accountByName.get(firstRow.accountName.toLowerCase()) || null;
      }

      const updates: Record<string, any> = {};
      if (sfAccountId && existingAccount && !existingAccount.salesforce_account_id) {
        updates.salesforce_account_id = sfAccountId;
      }
      if (firstRow.seEmail) updates.primary_se_email = firstRow.seEmail;
      if (existingAccount?.relationship_status === 'whitespace_only') {
        updates.relationship_status = 'warm';
      }

      accountMatches.set(key, {
        existing: existingAccount,
        needsCreate: !existingAccount && !updateOnlyMode,
        updates,
      });

      // Match opportunities
      for (const row of group.rows) {
        const oppId = normalizeSfdcId(row.opportunityId);
        const oppId15 = sfdcPrefix15(row.opportunityId);
        const hasOppKey = !!oppId || !!row.opportunityName;
        if (!hasOppKey) continue;

        let existingOpp = oppId ? (oppBySfId.get(oppId) || oppBySfId.get(oppId15!)) : null;
        if (!existingOpp && existingAccount && row.opportunityName) {
          existingOpp = oppByAccountAndName.get(`${existingAccount.id}:${row.opportunityName.toLowerCase()}`) || null;
        }

        // Only add fields that have actual values - don't set defaults that could overwrite existing data
        const oppUpdates: Record<string, any> = {};
        
        // Only update sales_stage if actually provided in CSV
        if (row.salesStage?.trim()) {
          oppUpdates.sales_stage = normalizeSalesStage(row.salesStage);
          oppUpdates.is_archived = isClosedOpportunityStage(row.salesStage);
        }
        // Only update pre_sales_stage if actually provided in CSV
        if (row.preSalesStage?.trim()) {
          oppUpdates.pre_sales_stage = normalizePreSalesStage(row.preSalesStage);
        }
        if (row.opportunityName) oppUpdates.name = row.opportunityName;
        if (oppId && existingOpp && !existingOpp.salesforce_opportunity_id) {
          oppUpdates.salesforce_opportunity_id = oppId;
        }
        if (row.closeDate) oppUpdates.close_date = row.closeDate;
        if (typeof row.arrUsd === 'number') oppUpdates.value = row.arrUsd;
        if (row.ownerEmail) oppUpdates.owner_email = row.ownerEmail;
        if (row.seEmail) oppUpdates.primary_se_email = row.seEmail;
        if (typeof row.tcv === 'number') oppUpdates.tcv = row.tcv;
        if (row.tcvCurrency) oppUpdates.tcv_currency = row.tcvCurrency;
        if (row.nextStep) oppUpdates.next_step = row.nextStep;
        if (row.opportunityType) oppUpdates.opportunity_type = row.opportunityType;
        if (row.primaryEvalQuote) oppUpdates.primary_eval_quote = row.primaryEvalQuote;
        if (row.evalStartDate) oppUpdates.eval_start_date = row.evalStartDate;
        if (row.evalEndDate) oppUpdates.eval_end_date = row.evalEndDate;
        if (row.evalType) oppUpdates.eval_type = row.evalType;
        if (row.evalDocumentsNotes) oppUpdates.eval_notes = row.evalDocumentsNotes;
        if (row.initialProductInterest?.length) {
          oppUpdates.initial_product_interest = row.initialProductInterest;
          // Map product interest text to module IDs
          const mappedModuleIds: string[] = [];
          for (const product of row.initialProductInterest) {
            const normalizedName = product.toLowerCase().trim();
            const moduleId = moduleByName.get(normalizedName);
            if (moduleId && !mappedModuleIds.includes(moduleId)) {
              mappedModuleIds.push(moduleId);
            }
          }
          if (mappedModuleIds.length > 0) {
            oppUpdates.included_module_ids = mappedModuleIds;
          }
        }

        oppMatches.push({
          row,
          existing: existingOpp,
          needsCreate: !existingOpp && !updateOnlyMode && !!row.opportunityName,
          updates: oppUpdates,
        });
      }
    }

    addLog('success', `✅ Matched ${[...accountMatches.values()].filter(m => m.existing).length} accounts, ${oppMatches.filter(m => m.existing).length} opportunities`);

    // ============ PHASE 3: Process updates/inserts ============
    setImportPhase({ phase: 'processing', message: 'Processing records...', current: 0, total: accountGroups.size + oppMatches.length });
    addLog('info', '⚡ Processing updates and inserts...');

    const createdAccountIds = new Map<string, string>(); // key -> new id
    const createdOppIds = new Map<number, string>(); // oppMatches index -> new opp id

    let processCount = 0;
    for (const [key, group] of accountGroups) {
      processCount++;
      const match = accountMatches.get(key)!;
      const firstRow = group.rows[0];
      
      setImportPhase({ phase: 'processing', message: `Account: ${firstRow.accountName}`, current: processCount, total: accountGroups.size + oppMatches.length });

      try {
        if (match.existing) {
          // Update existing account
          if (Object.keys(match.updates).length > 0) {
            const res = await gateway.from('accounts').update(match.updates).eq('id', match.existing.id).execute();
            if (res.error) throw new Error(res.error.message);
            accountsUpdated++;
            if (match.updates.relationship_status === 'warm') {
              accountsReactivated++;
              addLog('success', `🔄 Reactivated: ${firstRow.accountName}`);
            } else {
              addLog('info', `📝 Updated: ${firstRow.accountName}`);
            }
          }
          createdAccountIds.set(key, match.existing.id);
        } else if (match.needsCreate) {
          // Create new account
          const sfAccountId = normalizeSfdcId(group.sfAccountId);
          const res = await gateway.from('accounts').insert({
            name: firstRow.accountName,
            salesforce_account_id: sfAccountId || null,
            primary_se_email: firstRow.seEmail || null,
            relationship_status: 'cold',
          }).select('id').single().execute();

          if (res.error) throw new Error(res.error.message);
          const newId = (res.data as any).id;
          createdAccountIds.set(key, newId);
          accountsCreated++;
          addLog('success', `✨ Created: ${firstRow.accountName}`);
        }
      } catch (err: any) {
        addLog('error', `❌ Account "${firstRow.accountName}": ${err.message}`);
        errors.push(`Account "${firstRow.accountName}": ${err.message}`);
        failed++;
      }
    }

    // Process opportunities (with throttling to prevent backend overload)
    const importDelay = (ms: number) => new Promise(r => setTimeout(r, ms));
    for (let oppIdx = 0; oppIdx < oppMatches.length; oppIdx++) {
      const oppMatch = oppMatches[oppIdx];
      // Throttle: delay every 3 operations to prevent 503 overload
      if (oppIdx > 0 && oppIdx % 3 === 0) {
        await importDelay(500);
      }
      processCount++;
      const { row, existing, needsCreate, updates } = oppMatch;
      
      setImportPhase({ phase: 'processing', message: `Opportunity: ${row.opportunityName || row.opportunityId}`, current: processCount, total: accountGroups.size + oppMatches.length });

      try {
        if (existing) {
          // Update existing opportunity - only if there are actual updates
          if (Object.keys(updates).length > 0) {
            const res = await gateway.from('opportunities').update(updates).eq('id', existing.id).execute();
            if (res.error) throw new Error(res.error.message);
            opportunitiesUpdated++;
            addLog('info', `📝 Updated opp: ${row.opportunityName || row.opportunityId} (${Object.keys(updates).join(', ')})`);
          } else {
            addLog('info', `⏭️ Skipped opp (no changes): ${row.opportunityName || row.opportunityId}`);
            skipped++;
          }
        } else if (needsCreate) {
          // Find account ID
          const accountKey = row.accountId || row.accountName;
          const accountMatch = accountMatches.get(accountKey);
          const accountId = accountMatch?.existing?.id || createdAccountIds.get(accountKey);
          
          if (!accountId) {
            skipped++;
            continue;
          }

          const oppId = normalizeSfdcId(row.opportunityId);
          
          // Map product interest to module IDs for new opportunities too
          let mappedModuleIds: string[] | null = null;
          if (row.initialProductInterest?.length) {
            mappedModuleIds = [];
            for (const product of row.initialProductInterest) {
              const normalizedName = product.toLowerCase().trim();
              const moduleId = moduleByName.get(normalizedName);
              if (moduleId && !mappedModuleIds.includes(moduleId)) {
                mappedModuleIds.push(moduleId);
              }
            }
          }
          
          const res = await gateway.from('opportunities').insert({
            account_id: accountId,
            name: row.opportunityName,
            salesforce_opportunity_id: oppId || null,
            sales_stage: updates.sales_stage || 'stage_1',
            pre_sales_stage: updates.pre_sales_stage || 'Discovery',
            close_date: row.closeDate || null,
            value: typeof row.arrUsd === 'number' ? row.arrUsd : null,
            owner_email: row.ownerEmail || null,
            primary_se_email: row.seEmail || null,
            tcv: typeof row.tcv === 'number' ? row.tcv : null,
            tcv_currency: row.tcvCurrency || null,
            next_step: row.nextStep || null,
            opportunity_type: row.opportunityType || null,
            initial_product_interest: row.initialProductInterest || null,
            included_module_ids: mappedModuleIds,
            is_archived: updates.is_archived || false,
            primary_eval_quote: row.primaryEvalQuote || null,
            eval_start_date: row.evalStartDate || null,
            eval_end_date: row.evalEndDate || null,
            eval_type: row.evalType || null,
            eval_notes: row.evalDocumentsNotes || null,
          }).select('id').execute();

          if (res.error) throw new Error(res.error.message);
          const newOppId = (res.data as any)?.[0]?.id || (res.data as any)?.id;
          if (newOppId) createdOppIds.set(oppIdx, newOppId);
          opportunitiesCreated++;
          addLog('success', `✨ Created opp: ${row.opportunityName}`);
        } else {
          skipped++;
        }
      } catch (err: any) {
        addLog('error', `❌ Opp "${row.opportunityName || row.opportunityId}": ${err.message}`);
        errors.push(`Opp "${row.opportunityName || row.opportunityId}": ${err.message}`);
        failed++;
      }
    }

    // ============ PHASE 4: Process eval documents & SE notes ============
    addLog('info', '📄 Processing eval documents and SE notes...');
    
    // Helper: extract URLs from free text (separated by commas, spaces, newlines, or mixed)
    const extractUrls = (text: string): string[] => {
      const urlRegex = /https?:\/\/[^\s,;|"'<>]+/gi;
      const matches = text.match(urlRegex);
      return matches ? [...new Set(matches.map(u => u.replace(/[.)]+$/, '')))] : [];
    };

    let docsCreated = 0;
    let seNotesUpserted = 0;

    for (let oppIdx = 0; oppIdx < oppMatches.length; oppIdx++) {
      const { row, existing } = oppMatches[oppIdx];
      const oppId = existing?.id || createdOppIds.get(oppIdx) || null;
      
      const accountKey = row.accountId || row.accountName;
      const accountMatch = accountMatches.get(accountKey);
      const accountId = accountMatch?.existing?.id || createdAccountIds.get(accountKey);

      // Process eval documents/notes - extract URLs and create document entries
      if (row.evalDocumentsNotes && oppId && accountId) {
        const urls = extractUrls(row.evalDocumentsNotes);
        for (const url of urls) {
          try {
            // Derive document name from URL
            const urlObj = new URL(url);
            const pathParts = urlObj.pathname.split('/').filter(Boolean);
            const docName = decodeURIComponent(pathParts[pathParts.length - 1] || urlObj.hostname);
            
            await gateway.from('account_documents').insert({
              account_id: accountId,
              opportunity_id: oppId,
              name: docName,
              type: 'eval_document',
              file_url: url,
              is_external_url: true,
              status: 'active',
              tags: ['eval', 'imported'],
            }).execute();
            docsCreated++;
          } catch (err: any) {
            addLog('warning', `⚠️ Failed to create doc for ${url}: ${err.message}`);
          }
        }
      }

      // Process SE Notes - upsert into opportunity_se_updates
      if (row.seNotes && oppId) {
        try {
          await gateway.from('opportunity_se_updates').upsert({
            opportunity_id: oppId,
            updated_by: row.seEmail || row.ownerEmail || 'import',
            weekly_update: row.seNotes,
          }, { onConflict: 'opportunity_id' }).execute();
          seNotesUpserted++;
        } catch (err: any) {
          addLog('warning', `⚠️ Failed to save SE notes for ${row.opportunityName}: ${err.message}`);
        }
      }

      // Throttle
      if (oppIdx > 0 && oppIdx % 10 === 0) {
        await importDelay(200);
      }
    }

    if (docsCreated > 0) addLog('success', `📄 Created ${docsCreated} eval documents from URLs`);
    if (seNotesUpserted > 0) addLog('success', `📝 Updated ${seNotesUpserted} SE notes`);


    addLog('success', `🎉 Import complete! Created ${accountsCreated} accounts, ${opportunitiesCreated} opportunities. Updated ${accountsUpdated} accounts, ${opportunitiesUpdated} opportunities.`);
    
    setImportResults({ accountsCreated, accountsUpdated, opportunitiesCreated, opportunitiesUpdated, accountsReactivated, docsCreated, seNotesUpserted, skipped, failed, errors });
    setImportPhase({ phase: 'complete', message: 'Import complete', current: 100, total: 100 });
    setStep('complete');
  };

  const downloadSampleCSV = () => {
    const blob = new Blob([SAMPLE_CSV], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample_salesforce_export.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const MappingSelect = ({ label, field, required = false }: { label: string; field: keyof ColumnMapping; required?: boolean }) => (
    <div className="space-y-2">
      <Label>{label} {required && '*'}</Label>
      <Select value={mapping[field] || '__none__'} onValueChange={(v) => setMapping(m => ({ ...m, [field]: v === '__none__' ? '' : v }))}>
        <SelectTrigger>
          <SelectValue placeholder={required ? "Select column" : "Select column (optional)"} />
        </SelectTrigger>
        <SelectContent>
          {!required && <SelectItem value="__none__">-- None --</SelectItem>}
          {headers.filter(h => h.trim()).map(h => (
            <SelectItem key={h} value={h}>{h}</SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );

  // Count unique accounts and opportunities
  const uniqueAccounts = new Set(parsedRows.map(r => r.accountName)).size;
  const opportunityCount = parsedRows.filter(r => r.opportunityName || r.opportunityId).length;

  const getPhaseIcon = () => {
    switch (importPhase.phase) {
      case 'fetching': return <Database className="w-5 h-5 animate-pulse" />;
      case 'matching': return <Zap className="w-5 h-5 animate-pulse" />;
      case 'processing': return <RefreshCw className="w-5 h-5 animate-spin" />;
      case 'complete': return <CheckCheck className="w-5 h-5 text-green-500" />;
      default: return <RefreshCw className="w-5 h-5 animate-spin" />;
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Import Accounts & Opportunities from CSV
          </DialogTitle>
          <DialogDescription>
            Import Salesforce-exported accounts and opportunities from a CSV file
          </DialogDescription>
        </DialogHeader>

        {step === 'upload' && (
          <div className="space-y-6 py-4">
            <div
              className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:border-primary transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                type="file"
                accept=".csv"
                className="hidden"
                ref={fileInputRef}
                onChange={handleFileUpload}
              />
              <FileText className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-medium">Drop your CSV file here or click to browse</p>
              <p className="text-sm text-muted-foreground mt-2">
                Supports Salesforce Report exports with Accounts & Opportunities
              </p>
            </div>

            <div className="flex flex-col gap-3">
              <p className="text-sm text-muted-foreground">
                <strong>Expected columns:</strong> Account Name*, Account ID, Opportunity Name, Opportunity ID, Stage, PreSales Stage, Close Date, ARR (USD), Owner Email, Primary Sales Engineer, TCV Currency, TCV, Next Step, Type, Initial Product Interest, Eval Documents/Notes, SE Notes
              </p>
              <Button variant="outline" onClick={downloadSampleCSV} className="self-start">
                <Download className="w-4 h-4 mr-2" />
                Download Sample CSV
              </Button>
            </div>
          </div>
        )}

        {step === 'mapping' && (
          <div className="space-y-4 py-4">
            <p className="text-sm text-muted-foreground">
              Map your CSV columns to the import fields. Only Account Name is required.
            </p>
            <ScrollArea className="h-[400px] pr-4">
              <div className="grid grid-cols-2 gap-4">
                <MappingSelect label="Account Name" field="accountName" required />
                <MappingSelect label="Account ID (Salesforce)" field="accountId" />
                <MappingSelect label="Opportunity Name" field="opportunityName" />
                <MappingSelect label="Opportunity ID (Salesforce)" field="opportunityId" />
                <MappingSelect label="Stage" field="salesStage" />
                <MappingSelect label="Pre-Sales Stage" field="preSalesStage" />
                <MappingSelect label="Close Date" field="closeDate" />
                <MappingSelect label="ARR (USD)" field="arrUsd" />
                <MappingSelect label="Owner Email" field="ownerEmail" />
                <MappingSelect label="Primary Sales Engineer" field="seEmail" />
                <MappingSelect label="TCV Currency" field="tcvCurrency" />
                <MappingSelect label="TCV" field="tcv" />
                <MappingSelect label="Next Step" field="nextStep" />
                <MappingSelect label="Opportunity Type" field="opportunityType" />
                <MappingSelect label="Initial Product Interest" field="initialProductInterest" />
                <MappingSelect label="Primary Eval Quote" field="primaryEvalQuote" />
                <MappingSelect label="Eval Start Date" field="evalStartDate" />
                <MappingSelect label="Eval End Date" field="evalEndDate" />
                <MappingSelect label="Evaluation Type" field="evalType" />
                <MappingSelect label="Eval Documents/Notes" field="evalDocumentsNotes" />
                <MappingSelect label="SE Notes" field="seNotes" />
              </div>
            </ScrollArea>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setStep('upload')}>Back</Button>
              <Button onClick={handleMappingComplete}>Preview Import</Button>
            </div>
          </div>
        )}

        {step === 'preview' && (
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex gap-4">
                <Badge variant="secondary" className="text-base px-3 py-1">
                  {uniqueAccounts} Accounts
                </Badge>
                <Badge variant="secondary" className="text-base px-3 py-1">
                  {opportunityCount} Opportunities
                </Badge>
              </div>
              
              <div className="flex items-center gap-3 p-3 border rounded-lg bg-muted/50">
                <div className="flex flex-col">
                  <Label htmlFor="update-only-mode" className="text-sm font-medium">
                    Update existing only
                  </Label>
                  <span className="text-xs text-muted-foreground">
                    {updateOnlyMode ? 'Skip records not in system' : 'Create new records if missing'}
                  </span>
                </div>
                <Switch
                  id="update-only-mode"
                  checked={updateOnlyMode}
                  onCheckedChange={setUpdateOnlyMode}
                />
              </div>
            </div>
            
            <ScrollArea className="h-[300px] border rounded-lg">
              <table className="w-full text-sm">
                <thead className="bg-muted sticky top-0">
                  <tr>
                    <th className="text-left p-2">Account</th>
                    <th className="text-left p-2">Opportunity</th>
                    <th className="text-left p-2">Stage</th>
                    <th className="text-right p-2">ARR (USD)</th>
                    <th className="text-left p-2">Type</th>
                    <th className="text-left p-2">Products</th>
                  </tr>
                </thead>
                <tbody>
                  {parsedRows.slice(0, 50).map((row, i) => (
                    <tr key={i} className="border-t">
                      <td className="p-2">{row.accountName}</td>
                      <td className="p-2">{row.opportunityName || '-'}</td>
                      <td className="p-2">
                        <Badge variant={isClosedOpportunityStage(row.salesStage) ? 'secondary' : 'outline'} className="text-xs">
                          {row.salesStage || '-'}
                        </Badge>
                      </td>
                      <td className="p-2 text-right">
                        {row.arrUsd ? `$${row.arrUsd.toLocaleString()}` : '-'}
                      </td>
                      <td className="p-2">{row.opportunityType || '-'}</td>
                      <td className="p-2">
                        {row.initialProductInterest?.length ? (
                          <div className="flex gap-1 flex-wrap">
                            {row.initialProductInterest.slice(0, 2).map((p, j) => (
                              <Badge key={j} variant="outline" className="text-xs">{p}</Badge>
                            ))}
                            {row.initialProductInterest.length > 2 && (
                              <Badge variant="outline" className="text-xs">+{row.initialProductInterest.length - 2}</Badge>
                            )}
                          </div>
                        ) : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {parsedRows.length > 50 && (
                <p className="text-center text-muted-foreground py-2">
                  ... and {parsedRows.length - 50} more rows
                </p>
              )}
            </ScrollArea>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setStep('mapping')}>Back</Button>
              <Button onClick={handleImport}>
                {updateOnlyMode ? 'Update' : 'Import'} {parsedRows.length} Records
              </Button>
            </div>
          </div>
        )}

        {step === 'importing' && (
          <div className="flex-1 flex flex-col gap-4 py-4 min-h-0">
            {/* Phase indicator */}
            <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
              {getPhaseIcon()}
              <div className="flex-1">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium capitalize">{importPhase.phase.replace('_', ' ')}</span>
                  <span className="text-sm text-muted-foreground">
                    {importPhase.current} / {importPhase.total}
                  </span>
                </div>
                <Progress 
                  value={importPhase.total > 0 ? (importPhase.current / importPhase.total) * 100 : 0} 
                  className="h-2"
                />
                {importPhase.currentItem && (
                  <p className="text-xs text-muted-foreground mt-1 truncate">
                    {importPhase.message}
                  </p>
                )}
              </div>
            </div>

            {/* Activity log */}
            <div className="flex-1 min-h-0">
              <Label className="text-sm font-medium mb-2 block">Activity Log</Label>
              <ScrollArea className="h-[250px] border rounded-lg bg-muted/20 p-2">
                <div className="space-y-1 font-mono text-xs">
                  {activityLog.map((entry, i) => (
                    <div 
                      key={i} 
                      className={`py-0.5 ${
                        entry.type === 'error' ? 'text-destructive' : 
                        entry.type === 'success' ? 'text-green-600 dark:text-green-400' : 
                        entry.type === 'warning' ? 'text-yellow-600 dark:text-yellow-400' : 
                        'text-muted-foreground'
                      }`}
                    >
                      {entry.message}
                    </div>
                  ))}
                  {activityLog.length === 0 && (
                    <div className="text-muted-foreground">Starting import...</div>
                  )}
                </div>
              </ScrollArea>
            </div>
          </div>
        )}

        {step === 'complete' && (
          <div className="space-y-6 py-4">
            <div className="text-center">
              {importResults.failed > 0 ? (
                <AlertCircle className="w-12 h-12 mx-auto mb-4 text-yellow-500" />
              ) : (
                <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-500" />
              )}
              <p className="text-lg font-medium">Import Complete</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-2xl font-bold text-green-600">{importResults.accountsCreated}</p>
                <p className="text-sm text-muted-foreground">Accounts Created</p>
              </div>
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-2xl font-bold text-blue-600">{importResults.accountsUpdated}</p>
                <p className="text-sm text-muted-foreground">Accounts Updated</p>
              </div>
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-2xl font-bold text-green-600">{importResults.opportunitiesCreated}</p>
                <p className="text-sm text-muted-foreground">Opportunities Created</p>
              </div>
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-2xl font-bold text-blue-600">{importResults.opportunitiesUpdated}</p>
                <p className="text-sm text-muted-foreground">Opportunities Updated</p>
              </div>
            </div>

            {(importResults.accountsReactivated > 0 || importResults.docsCreated > 0 || importResults.seNotesUpserted > 0) && (
              <div className="flex gap-4 justify-center text-sm text-muted-foreground">
                {importResults.accountsReactivated > 0 && (
                  <span>{importResults.accountsReactivated} whitespace account(s) reactivated</span>
                )}
                {importResults.docsCreated > 0 && (
                  <span>{importResults.docsCreated} eval document(s) linked</span>
                )}
                {importResults.seNotesUpserted > 0 && (
                  <span>{importResults.seNotesUpserted} SE note(s) updated</span>
                )}
              </div>
            )}

            {(importResults.skipped > 0 || importResults.failed > 0) && (
              <div className="flex gap-4 justify-center text-sm">
                {importResults.skipped > 0 && (
                  <span className="text-muted-foreground">{importResults.skipped} skipped</span>
                )}
                {importResults.failed > 0 && (
                  <span className="text-destructive">{importResults.failed} failed</span>
                )}
              </div>
            )}

            {importResults.errors.length > 0 && (
              <ScrollArea className="h-[100px] border rounded-lg p-2">
                <div className="space-y-1 text-sm text-destructive">
                  {importResults.errors.map((err, i) => (
                    <p key={i}>{err}</p>
                  ))}
                </div>
              </ScrollArea>
            )}

            <div className="flex justify-end">
              <Button onClick={handleClose}>Close</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

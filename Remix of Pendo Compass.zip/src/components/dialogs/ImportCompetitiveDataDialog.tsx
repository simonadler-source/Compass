import { useState, useCallback } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Upload, FileSpreadsheet, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';
import { useQueryClient } from '@tanstack/react-query';
import ExcelJS from 'exceljs';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { encryptedUpsert, encryptedUpdate } from '@/lib/encryptedDb';

interface ImportResult {
  competitors: number;
  categories: number;
  features: number;
  scores: number;
  errors: string[];
}

// Helper to convert ExcelJS worksheet to 2D array (similar to xlsx sheet_to_json with header: 1)
function worksheetToArray(worksheet: ExcelJS.Worksheet): any[][] {
  const result: any[][] = [];
  worksheet.eachRow({ includeEmpty: true }, (row, rowNumber) => {
    const rowData: any[] = [];
    row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
      // Ensure we fill gaps for empty cells
      while (rowData.length < colNumber - 1) {
        rowData.push(undefined);
      }
      rowData.push(cell.value);
    });
    result[rowNumber - 1] = rowData;
  });
  return result;
}

export function ImportCompetitiveDataDialog({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<ImportResult | null>(null);
  const queryClient = useQueryClient();

  const parseAndImport = useCallback(async (file: File) => {
    setImporting(true);
    setProgress(0);
    setResult(null);

    const errors: string[] = [];
    let competitorsCount = 0;
    let categoriesCount = 0;
    let featuresCount = 0;
    let scoresCount = 0;

    try {
      const data = await file.arrayBuffer();
      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.load(data);
      
      // Expected sheets: Master Scoring, Feature Maturity Model, Rationale
      const masterSheet = workbook.getWorksheet('Master Scoring') || workbook.worksheets[0];
      const maturitySheet = workbook.getWorksheet('Feature Maturity Model') || workbook.worksheets[1];
      const rationaleSheet = workbook.getWorksheet('Rationale') || workbook.worksheets[3];

      if (!masterSheet) {
        throw new Error('Could not find Master Scoring sheet');
      }

      setProgress(10);

      // Parse Master Scoring sheet - extract competitors and their total scores
      const masterData = worksheetToArray(masterSheet);
      
      // First row contains competitor names (starting from column B or C)
      const headerRow = masterData[0] || [];
      const competitorNames: string[] = [];
      const competitorColMap = new Map<number, string>();
      
      for (let i = 1; i < headerRow.length; i++) {
        const name = String(headerRow[i] || '').trim();
        if (name && name !== '' && !name.toLowerCase().includes('category') && !name.toLowerCase().includes('feature')) {
          competitorNames.push(name);
          competitorColMap.set(i, name);
        }
      }

      setProgress(20);

      // Upsert competitors
      for (const name of competitorNames) {
        const { error } = await gateway
          .from('competitors')
          .upsert({ name, is_primary_competitor: true })
          .execute();
        if (error) {
          errors.push(`Failed to upsert competitor ${name}: ${getErrorMessage(error)}`);
        } else {
          competitorsCount++;
        }
      }

      setProgress(30);

      // Parse categories and features from master sheet
      let currentCategory = '';
      const categoryFeatures = new Map<string, string[]>();
      
      for (let row = 1; row < masterData.length; row++) {
        const rowData = masterData[row];
        if (!rowData || rowData.length === 0) continue;
        
        const firstCell = String(rowData[0] || '').trim();
        
        // Check if this is a category row (usually has "Total" or is bold/formatted differently)
        // Categories typically don't have scores in subsequent columns or have aggregate scores
        const hasScores = rowData.slice(1).some(cell => typeof cell === 'number' && cell > 0 && cell <= 5);
        
        if (firstCell && !hasScores && !firstCell.toLowerCase().includes('total') && firstCell.length > 3) {
          // This might be a category
          currentCategory = firstCell;
          if (!categoryFeatures.has(currentCategory)) {
            categoryFeatures.set(currentCategory, []);
          }
        } else if (firstCell && hasScores && currentCategory) {
          // This is a feature under the current category
          categoryFeatures.get(currentCategory)?.push(firstCell);
        }
      }

      setProgress(40);

      // Upsert categories
      const categoryIdMap = new Map<string, string>();
      let sortOrder = 1;
      
      for (const [categoryName] of categoryFeatures) {
        const { data: catData, error } = await gateway
          .from('competitive_categories')
          .upsert({ name: categoryName, sort_order: sortOrder++ })
          .select('id')
          .execute();
        
        if (error) {
          errors.push(`Failed to upsert category ${categoryName}: ${getErrorMessage(error)}`);
        } else if (catData && catData.length > 0) {
          categoryIdMap.set(categoryName, catData[0].id);
          categoriesCount++;
        }
      }

      setProgress(50);

      // Parse maturity model if available
      const maturityMap = new Map<string, { level1?: string; level3?: string; level5?: string }>();
      
      if (maturitySheet) {
        const maturityData = worksheetToArray(maturitySheet);
        
        for (let row = 1; row < maturityData.length; row++) {
          const rowData = maturityData[row];
          if (!rowData || rowData.length < 2) continue;
          
          const featureName = String(rowData[0] || '').trim();
          if (featureName) {
            maturityMap.set(featureName, {
              level1: String(rowData[1] || ''),
              level3: String(rowData[3] || ''),
              level5: String(rowData[5] || ''),
            });
          }
        }
      }

      setProgress(60);

      // Upsert features
      const featureIdMap = new Map<string, string>();
      
      for (const [categoryName, features] of categoryFeatures) {
        const categoryId = categoryIdMap.get(categoryName);
        if (!categoryId) continue;
        
        let featureSortOrder = 1;
        for (const featureName of features) {
          const maturity = maturityMap.get(featureName) || {};
          
          const { data: featData, error } = await gateway
            .from('competitive_features')
            .upsert({
              category_id: categoryId,
              name: featureName,
              sort_order: featureSortOrder++,
              maturity_level_1: maturity.level1 || null,
              maturity_level_3: maturity.level3 || null,
              maturity_level_5: maturity.level5 || null,
            })
            .select('id')
            .execute();
          
          if (error) {
            errors.push(`Failed to upsert feature ${featureName}: ${getErrorMessage(error)}`);
          } else if (featData && featData.length > 0) {
            featureIdMap.set(`${categoryName}|${featureName}`, featData[0].id);
            featuresCount++;
          }
        }
      }

      setProgress(70);

      // Get competitor IDs
      const { data: allCompetitors } = await gateway.from('competitors').select('id, name').execute();
      const competitorIdMap = new Map((allCompetitors || []).map((c: any) => [c.name.toLowerCase(), c.id]));

      // Parse scores from master sheet
      for (let row = 1; row < masterData.length; row++) {
        const rowData = masterData[row];
        if (!rowData || rowData.length === 0) continue;
        
        const featureName = String(rowData[0] || '').trim();
        
        // Find which category this feature belongs to
        let featureCategoryName = '';
        for (const [catName, features] of categoryFeatures) {
          if (features.includes(featureName)) {
            featureCategoryName = catName;
            break;
          }
        }
        
        if (!featureCategoryName) continue;
        
        const featureId = featureIdMap.get(`${featureCategoryName}|${featureName}`);
        if (!featureId) continue;
        
        // Extract scores for each competitor
        for (const [colIdx, compName] of competitorColMap) {
          const score = rowData[colIdx];
          if (typeof score !== 'number' || score < 0 || score > 5) continue;
          
          const competitorId = competitorIdMap.get(compName.toLowerCase());
          if (!competitorId) continue;
          
          const { error } = await encryptedUpsert('competitor_scores', {
            competitor_id: competitorId,
            feature_id: featureId,
            score: Math.round(score),
          });
          
          if (!error) {
            scoresCount++;
          }
        }
      }

      setProgress(85);

      // Parse rationale if available
      if (rationaleSheet) {
        const rationaleData = worksheetToArray(rationaleSheet);
        
        for (let row = 1; row < rationaleData.length; row++) {
          const rowData = rationaleData[row];
          if (!rowData || rowData.length < 3) continue;
          
          const compName = String(rowData[0] || '').trim();
          const featureName = String(rowData[1] || '').trim();
          const rationale = String(rowData[2] || '').trim();
          
          if (!compName || !featureName || !rationale) continue;
          
          const competitorId = competitorIdMap.get(compName.toLowerCase());
          if (!competitorId) continue;
          
          // Find feature ID
          let featureId: string | undefined;
          for (const [key, id] of featureIdMap) {
            if (key.endsWith(`|${featureName}`)) {
              featureId = id;
              break;
            }
          }
          if (!featureId) continue;
          
          // Get existing score record
          const { data: existing } = await gateway
            .from('competitor_scores')
            .select('id')
            .eq('competitor_id', competitorId)
            .eq('feature_id', featureId)
            .single()
            .execute();
          
          if (existing) {
            await encryptedUpdate('competitor_scores', existing.id, { rationale });
          }
        }
      }

      setProgress(100);

      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ['competitors'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-analysis'] });
      queryClient.invalidateQueries({ queryKey: ['pendo-competitive-advantages'] });

      setResult({
        competitors: competitorsCount,
        categories: categoriesCount,
        features: featuresCount,
        scores: scoresCount,
        errors,
      });

      if (errors.length === 0) {
        toast.success(`Imported ${scoresCount} scores across ${competitorsCount} competitors`);
      } else {
        toast.warning(`Import completed with ${errors.length} warnings`);
      }
    } catch (error) {
      console.error('Import error:', error);
      toast.error(`Import failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      setResult({
        competitors: competitorsCount,
        categories: categoriesCount,
        features: featuresCount,
        scores: scoresCount,
        errors: [...errors, String(error)],
      });
    } finally {
      setImporting(false);
    }
  }, [queryClient]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      parseAndImport(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && (file.name.endsWith('.xlsx') || file.name.endsWith('.xls'))) {
      parseAndImport(file);
    } else {
      toast.error('Please drop an Excel file (.xlsx or .xls)');
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5" />
            Import Competitive Intelligence
          </DialogTitle>
          <DialogDescription>
            Upload the competitive master spreadsheet to update scores, features, and rationale.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {!importing && !result && (
            <div
              className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer"
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              onClick={() => document.getElementById('competitive-file-input')?.click()}
            >
              <Upload className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
              <p className="text-sm text-foreground font-medium">
                Drop your XLSX file here or click to browse
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Expected sheets: Master Scoring, Feature Maturity Model, Rationale
              </p>
              <input
                id="competitive-file-input"
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleFileChange}
              />
            </div>
          )}

          {importing && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3">
                <Loader2 className="w-5 h-5 animate-spin text-primary" />
                <span className="text-sm text-foreground">Importing competitive data...</span>
              </div>
              <Progress value={progress} className="h-2" />
              <p className="text-xs text-muted-foreground">
                {progress < 30 && 'Parsing competitors...'}
                {progress >= 30 && progress < 50 && 'Processing categories...'}
                {progress >= 50 && progress < 70 && 'Updating features & maturity levels...'}
                {progress >= 70 && progress < 90 && 'Importing scores...'}
                {progress >= 90 && 'Finalizing...'}
              </p>
            </div>
          )}

          {result && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-muted/50 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-foreground">{result.competitors}</p>
                  <p className="text-xs text-muted-foreground">Competitors</p>
                </div>
                <div className="bg-muted/50 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-foreground">{result.categories}</p>
                  <p className="text-xs text-muted-foreground">Categories</p>
                </div>
                <div className="bg-muted/50 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-foreground">{result.features}</p>
                  <p className="text-xs text-muted-foreground">Features</p>
                </div>
                <div className="bg-muted/50 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-foreground">{result.scores}</p>
                  <p className="text-xs text-muted-foreground">Scores</p>
                </div>
              </div>

              {result.errors.length > 0 && (
                <div className="bg-destructive/10 rounded-lg p-3">
                  <div className="flex items-center gap-2 text-destructive mb-2">
                    <AlertCircle className="w-4 h-4" />
                    <span className="text-sm font-medium">{result.errors.length} warnings</span>
                  </div>
                  <ScrollArea className="h-24">
                    <ul className="text-xs text-muted-foreground space-y-1">
                      {result.errors.map((err, i) => (
                        <li key={i}>• {err}</li>
                      ))}
                    </ul>
                  </ScrollArea>
                </div>
              )}

              {result.errors.length === 0 && (
                <div className="flex items-center gap-2 text-green-600 bg-green-500/10 rounded-lg p-3">
                  <CheckCircle2 className="w-5 h-5" />
                  <span className="text-sm font-medium">Import completed successfully</span>
                </div>
              )}

              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => {
                  setResult(null);
                  setProgress(0);
                }}
              >
                Import Another File
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

import React, { useState, useMemo } from 'react';
import { Import, ChevronRight, Lightbulb, Target, ClipboardList, Calendar, CheckSquare, AlertTriangle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import {
  useSiblingOpportunities,
  useImportFromOpportunity,
  type SiblingOpportunity,
  type ImportCategory,
} from '@/hooks/useImportFromOpportunity';

interface Props {
  accountId: string;
  opportunityId: string;
  opportunityName: string;
}

const categoryConfig: Record<ImportCategory, { label: string; icon: React.ElementType; description: string }> = {
  use_cases: { label: 'Use Cases', icon: Lightbulb, description: 'Business use cases and requirements' },
  success_criteria: { label: 'Success Criteria', icon: Target, description: 'Success metrics and deliverables' },
  technical_readiness: { label: 'Technical Readiness', icon: ClipboardList, description: 'Apps and readiness answers' },
  timeline: { label: 'Timeline', icon: Calendar, description: 'Milestones and schedule' },
  validation_tasks: { label: 'Validation Tasks', icon: CheckSquare, description: 'Validation checklist items' },
  risks: { label: 'Risks & Issues', icon: AlertTriangle, description: 'Technical risks and mitigations' },
};

export function ImportFromOpportunityDialog({ accountId, opportunityId, opportunityName }: Props) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<'select-source' | 'select-data'>('select-source');
  const [selectedSource, setSelectedSource] = useState<SiblingOpportunity | null>(null);
  const [selectedCategories, setSelectedCategories] = useState<Set<ImportCategory>>(new Set());

  const { data: siblings, isLoading } = useSiblingOpportunities(accountId, opportunityId);
  const importMutation = useImportFromOpportunity();

  const availableCategories = useMemo((): ImportCategory[] => {
    if (!selectedSource) return [];
    const categories: ImportCategory[] = [];
    if (selectedSource.useCaseCount > 0) categories.push('use_cases');
    if (selectedSource.successCriteriaCount > 0) categories.push('success_criteria');
    if (selectedSource.readinessAppCount > 0) categories.push('technical_readiness');
    if (selectedSource.milestoneCount > 0) categories.push('timeline');
    if (selectedSource.validationTaskCount > 0) categories.push('validation_tasks');
    if (selectedSource.riskCount > 0) categories.push('risks');
    return categories;
  }, [selectedSource]);

  const handleSelectSource = (opp: SiblingOpportunity) => {
    setSelectedSource(opp);
    setSelectedCategories(new Set());
    setStep('select-data');
  };

  const toggleCategory = (cat: ImportCategory) => {
    setSelectedCategories(prev => {
      const next = new Set(prev);
      if (next.has(cat)) {
        next.delete(cat);
      } else {
        next.add(cat);
      }
      return next;
    });
  };

  const selectAll = () => {
    setSelectedCategories(new Set(availableCategories));
  };

  const handleImport = async () => {
    if (!selectedSource || selectedCategories.size === 0) return;

    await importMutation.mutateAsync({
      sourceOpportunityId: selectedSource.id,
      targetOpportunityId: opportunityId,
      targetAccountId: accountId,
      categories: Array.from(selectedCategories),
    });

    setOpen(false);
    resetState();
  };

  const resetState = () => {
    setStep('select-source');
    setSelectedSource(null);
    setSelectedCategories(new Set());
  };

  const getCategoryCount = (cat: ImportCategory): number => {
    if (!selectedSource) return 0;
    switch (cat) {
      case 'use_cases': return selectedSource.useCaseCount;
      case 'success_criteria': return selectedSource.successCriteriaCount;
      case 'technical_readiness': return selectedSource.readinessAppCount;
      case 'timeline': return selectedSource.milestoneCount;
      case 'validation_tasks': return selectedSource.validationTaskCount;
      case 'risks': return selectedSource.riskCount;
      default: return 0;
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) resetState(); }}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Import className="w-4 h-4" />
          Import Data
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Import className="w-5 h-5" />
            Import from Another Opportunity
          </DialogTitle>
          <DialogDescription>
            {step === 'select-source' 
              ? 'Select an opportunity to import data from'
              : `Importing to: ${opportunityName}`
            }
          </DialogDescription>
        </DialogHeader>

        {step === 'select-source' && (
          <div className="space-y-2 max-h-80 overflow-y-auto py-2">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : siblings && siblings.length > 0 ? (
              siblings.map((opp) => (
                <button
                  key={opp.id}
                  onClick={() => handleSelectSource(opp)}
                  className="w-full flex items-center justify-between p-3 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-colors text-left"
                >
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{opp.name}</div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {opp.useCaseCount > 0 && (
                        <Badge variant="secondary" className="text-xs">{opp.useCaseCount} use cases</Badge>
                      )}
                      {opp.successCriteriaCount > 0 && (
                        <Badge variant="secondary" className="text-xs">{opp.successCriteriaCount} criteria</Badge>
                      )}
                      {opp.readinessAppCount > 0 && (
                        <Badge variant="secondary" className="text-xs">{opp.readinessAppCount} apps</Badge>
                      )}
                      {opp.milestoneCount > 0 && (
                        <Badge variant="secondary" className="text-xs">{opp.milestoneCount} milestones</Badge>
                      )}
                      {opp.validationTaskCount > 0 && (
                        <Badge variant="secondary" className="text-xs">{opp.validationTaskCount} tasks</Badge>
                      )}
                      {opp.riskCount > 0 && (
                        <Badge variant="secondary" className="text-xs">{opp.riskCount} risks</Badge>
                      )}
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0 ml-2" />
                </button>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Import className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>No other opportunities with data found</p>
                <p className="text-sm">Create use cases, milestones, or other data in another opportunity first</p>
              </div>
            )}
          </div>
        )}

        {step === 'select-data' && selectedSource && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setStep('select-source')}
                className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1"
              >
                ← Back
              </button>
              <Button variant="ghost" size="sm" onClick={selectAll}>
                Select All
              </Button>
            </div>

            <div className="p-3 rounded-lg bg-muted/50 border border-border">
              <div className="text-sm font-medium">Source: {selectedSource.name}</div>
            </div>

            <div className="space-y-2">
              {availableCategories.map((cat) => {
                const config = categoryConfig[cat];
                const Icon = config.icon;
                const count = getCategoryCount(cat);
                const isSelected = selectedCategories.has(cat);

                return (
                  <div
                    key={cat}
                    onClick={() => toggleCategory(cat)}
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors",
                      isSelected 
                        ? "border-primary bg-primary/5" 
                        : "border-border hover:border-muted-foreground"
                    )}
                  >
                    <Checkbox checked={isSelected} />
                    <Icon className={cn("w-5 h-5", isSelected ? "text-primary" : "text-muted-foreground")} />
                    <div className="flex-1">
                      <div className="font-medium">{config.label}</div>
                      <div className="text-sm text-muted-foreground">{config.description}</div>
                    </div>
                    <Badge variant="outline">{count}</Badge>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {step === 'select-data' && (
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleImport} 
              disabled={selectedCategories.size === 0 || importMutation.isPending}
            >
              {importMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Importing...
                </>
              ) : (
                <>Import {selectedCategories.size} categories</>
              )}
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}

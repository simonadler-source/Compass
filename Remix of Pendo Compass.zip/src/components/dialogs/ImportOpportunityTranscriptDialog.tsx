import { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Mail, Loader2, Upload, Calendar, Clock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { encryptedInsert, encryptedUpsert } from '@/lib/encryptedDb';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { fetchCompetitorsForAnalysis } from '@/hooks/useCompetitorsList';
import { inferActivityType, detectContentType, inferEmailType } from '@/hooks/useOpportunityActivities';
import { saveInsightsWithEnrichment } from '@/hooks/useInsightEnrichment';
import { dateTimeToISO, inferContentTimestamp, extractLatestEmailTimestamp, extractAllEmailTimestamps, parseEmailThreadWithTimestamps } from '@/lib/emailTemporal';

// Meeting types for meetings
const MEETING_TYPES = [
  { value: 'discovery', label: 'Discovery Call' },
  { value: 'demo', label: 'Demo' },
  { value: 'reverse_demo', label: 'Reverse Demo' },
  { value: 'technical', label: 'Technical Deep Dive' },
  { value: 'workshop', label: 'Workshop' },
  { value: 'executive_playback', label: 'Executive Playback' },
  { value: 'scoping', label: 'Scoping Call' },
  { value: 'evaluation', label: 'Evaluation / Trial' },
  { value: 'commercial', label: 'Commercial Discussion' },
  { value: 'check_in', label: 'Check-in' },
  { value: 'training', label: 'Training' },
] as const;

// Email types for emails
const EMAIL_TYPES = [
  { value: 'email_followup', label: 'Follow-up Email' },
  { value: 'email_proposal', label: 'Proposal Email' },
  { value: 'email_introduction', label: 'Introduction Email' },
  { value: 'email_status_update', label: 'Status Update Email' },
  { value: 'email_technical', label: 'Technical Email' },
  { value: 'email_scheduling', label: 'Scheduling Email' },
  { value: 'email_other', label: 'Other Email' },
] as const;

interface ImportOpportunityTranscriptDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  opportunityId: string;
  accountId: string;
}

export function ImportOpportunityTranscriptDialog({
  open,
  onOpenChange,
  opportunityId,
  accountId,
}: ImportOpportunityTranscriptDialogProps) {
  const queryClient = useQueryClient();
  const [contentType, setContentType] = useState<'meeting' | 'email'>('meeting');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [meetingType, setMeetingType] = useState('discovery');
  const [emailType, setEmailType] = useState('email_followup');
  const [meetingDate, setMeetingDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [meetingTime, setMeetingTime] = useState(format(new Date(), 'HH:mm'));
  const [detectedTimestamps, setDetectedTimestamps] = useState<string[]>([]);
  
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importStage, setImportStage] = useState('');

  // Auto-detect content type and extract timestamps when content changes
  useEffect(() => {
    if (content.length > 100) {
      const detected = detectContentType(content);
      setContentType(detected);
      
      if (detected === 'email') {
        const inferredType = inferEmailType(title, content);
        setEmailType(inferredType);
        
        // Extract timestamps from email thread for display
        const timestamps = extractAllEmailTimestamps(content);
        setDetectedTimestamps(timestamps);
      } else {
        setDetectedTimestamps([]);
      }
    }
  }, [content, title]);

  const resetForm = () => {
    setTitle('');
    setContent('');
    setMeetingType('discovery');
    setEmailType('email_followup');
    setMeetingDate(format(new Date(), 'yyyy-MM-dd'));
    setMeetingTime(format(new Date(), 'HH:mm'));
    setContentType('meeting');
    setImportProgress(0);
    setImportStage('');
    setIsImporting(false);
    setDetectedTimestamps([]);
  };

  const importMutation = useMutation({
    mutationFn: async () => {
      if (!content.trim()) {
        throw new Error('Please paste transcript or email content');
      }
      if (!title.trim()) {
        throw new Error('Please enter a title');
      }

      setIsImporting(true);
      setImportProgress(5);
      setImportStage('Preparing content...');

      const selectedType = contentType === 'email' ? emailType : meetingType;
      const transcriptLen = content.length;
      const analysisTranscript = transcriptLen > 120000 ? content.slice(0, 120000) : content;

      setImportProgress(10);
      setImportStage('Creating transcript record...');

      // Use inferContentTimestamp for accurate datetime handling
      const occurredAt = inferContentTimestamp(contentType, content, meetingDate, meetingTime);

      // Create transcript record with retry logic (encrypt-pii can be flaky under load)
      let transcriptData: any = null;
      let transcriptError: Error | null = null;
      const MAX_INSERT_ATTEMPTS = 3;
      
      for (let attempt = 0; attempt < MAX_INSERT_ATTEMPTS; attempt++) {
        const result = await encryptedInsert('transcript_reviews', {
          transcript_content: content,
          meeting_title: title,
          meeting_type: selectedType,
          status: 'approved',
          final_account_id: accountId,
          opportunity_id: opportunityId,
          file_name: `manual_${Date.now()}`,
          created_at: occurredAt,
        });
        
        transcriptData = result.data;
        transcriptError = result.error;
        
        if (!transcriptError && transcriptData?.id) break;
        
        console.warn(`[Import] Insert attempt ${attempt + 1} failed:`, transcriptError?.message);
        if (attempt < MAX_INSERT_ATTEMPTS - 1) {
          setImportStage(`Retrying save (attempt ${attempt + 2})...`);
          await new Promise(r => setTimeout(r, (attempt + 1) * 2000));
        }
      }

      if (transcriptError || !transcriptData?.id) {
        throw new Error(transcriptError?.message || 'Failed to save transcript after multiple attempts');
      }
      const transcriptReviewId = transcriptData.id;

      setImportProgress(20);
      setImportStage('Fetching context...');

      // Fetch competitors for analysis (used by the streaming endpoint internally)
      await fetchCompetitorsForAnalysis();

      setImportProgress(30);
      setImportStage('Analyzing content (this may take a minute)...');

      // Analyze transcript using the unified-transcript-analysis endpoint (with pipeline logging)
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

      let analysis: any = null;

      try {
        const response = await fetch(`${supabaseUrl}/functions/v1/unified-transcript-analysis`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${supabaseKey}`,
            'apikey': supabaseKey,
          },
          body: JSON.stringify({
            transcript: analysisTranscript,
            transcriptReviewId,
            accountId,
            opportunityId,
            skipEnrichment: false,
            streaming: true,
          }),
        });

        if (!response.ok) {
          throw new Error(`Analysis failed: ${response.status}`);
        }

        const reader = response.body?.getReader();
        const decoder = new TextDecoder();

        if (!reader) throw new Error('No response stream');

        let buffer = '';
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n\n');
          buffer = lines.pop() || '';

          for (const chunk of lines) {
            if (!chunk.trim()) continue;

            const eventMatch = chunk.match(/^event: (\w+)\ndata: (.+)$/s);
            if (!eventMatch) continue;

            const [, eventType, dataStr] = eventMatch;
            try {
              const data = JSON.parse(dataStr);

              switch (eventType) {
                case 'progress':
                  const baseProgress = 30;
                  const progressRange = 60; // 30-90
                  setImportProgress(baseProgress + (data.progress / 100) * progressRange);
                  setImportStage(data.stage);
                  break;

                case 'core_complete':
                  analysis = data.result;
                  break;

                case 'error':
                  console.error('Analysis error:', data.message);
                  break;
              }
            } catch (parseErr) {
              console.warn('Failed to parse SSE event:', parseErr);
            }
          }
        }
      } catch (analysisError) {
        console.error('Analysis error:', analysisError);
        // Transcript was saved, but analysis failed — inform user
        toast.warning('Transcript saved but analysis failed. You can re-analyze it from the transcripts tab.');
      }

      setImportProgress(90);
      setImportStage('Saving insights...');

      // Update transcript with analysis results
      if (analysis) {
        await gateway
          .from('transcript_reviews')
          .update({
            extracted_technologies: analysis?.technologies ?? null,
            extracted_insights: {
              painPoints: analysis?.insights?.painPoints ?? [],
              useCases: analysis?.insights?.useCases ?? [],
              competitorMentions: analysis?.insights?.competitorMentions ?? [],
              operationalMetrics: analysis?.operationalMetrics ?? [],
              commercialInsights: analysis?.commercialInsights ?? [],
              nextBestActions: analysis?.nbas ?? [],
              people: analysis?.people ?? [],
              detectionRuleMatches: analysis?.detectionRuleMatches ?? [],
            },
            last_analyzed_at: new Date().toISOString(),
          })
          .eq('id', transcriptReviewId)
          .execute();

        // Save NBAs with deduplication (check both field names for compatibility)
        const nbas = analysis?.nbas || analysis?.nextBestActions || [];
        if (nbas.length > 0) {
          const { saveNBAsWithDeduplication } = await import('@/hooks/useInsightEnrichment');
          await saveNBAsWithDeduplication(
            accountId,
            nbas,
            opportunityId,
            transcriptReviewId
          );
        }

        // Save use cases and pain points with enrichment
        const useCases = analysis?.insights?.useCases ?? [];
        const painPoints = analysis?.insights?.painPoints ?? [];

        if (useCases.length > 0 || painPoints.length > 0) {
          const themedUseCases = useCases.map((uc: any) => ({
            description: typeof uc === 'string' ? uc : uc.description || uc.name || uc,
            businessTheme: typeof uc === 'object' ? uc.businessTheme : 'operational_efficiency',
            priority: typeof uc === 'object' ? uc.priority : 'medium',
            confidence: 0.5,
          }));

          const themedPainPoints = painPoints.map((pp: any) => ({
            description: typeof pp === 'string' ? pp : pp.description || pp,
            businessTheme: typeof pp === 'object' ? pp.businessTheme : 'operational_efficiency',
            severity: typeof pp === 'object' ? pp.severity : 'medium',
            confidence: 0.5,
          }));

          await saveInsightsWithEnrichment(
            accountId,
            themedPainPoints,
            themedUseCases,
            opportunityId,
            transcriptReviewId
          );
        }

        // Save contacts - fetch all contacts first and match in memory
        // (name column is encrypted, so we can't filter by it in the query)
        const people = analysis?.people || [];
        if (people.length > 0) {
          const { data: existingContacts } = await gateway
            .from('account_contacts')
            .select('id, name, email')
            .eq('account_id', accountId)
            .execute();
          
          const existingNames = new Set(
            (existingContacts || [])
              .map(c => c.name?.toLowerCase().trim())
              .filter(Boolean)
          );
          const existingEmails = new Set(
            (existingContacts || [])
              .map(c => c.email?.toLowerCase().trim())
              .filter(Boolean)
          );

          for (const person of people) {
            if (person.isInternal) continue;
            
            const personName = person.name?.toLowerCase().trim();
            const personEmail = person.email?.toLowerCase().trim();
            
            // Check if contact already exists by name or email
            const exists = (personName && existingNames.has(personName)) ||
                         (personEmail && existingEmails.has(personEmail));

            if (!exists) {
              await encryptedInsert('account_contacts', {
                account_id: accountId,
                opportunity_id: opportunityId,
                name: person.name,
                role: person.role,
                email: person.email,
                notes: person.context,
                source: contentType === 'email' ? 'email' : 'transcript',
                stakeholder_type: person.stakeholderType || 'unknown',
                influence_level: person.influenceLevel,
                sentiment: person.sentiment,
                champion_score: person.championScore,
              });
              // Add to sets to avoid duplicate inserts in same batch
              if (personName) existingNames.add(personName);
              if (personEmail) existingEmails.add(personEmail);
            }
          }
        }
      }

      setImportProgress(95);
      setImportStage('Creating activity records...');

      // Get AE and SE from opportunity
      const { data: oppData } = await gateway
        .from('opportunities')
        .select('owner_email, primary_se_email')
        .eq('id', opportunityId)
        .single()
        .execute();

      // Fetch existing contacts and team members for sender attribution
      const [contactsRes, teamMembersRes] = await Promise.all([
        gateway.from('account_contacts').select('id, name, email').eq('account_id', accountId).execute(),
        gateway.from('account_team_members').select('id, team_member_email').eq('account_id', accountId).execute(),
      ]);
      const existingContacts = contactsRes.data || [];
      const teamMemberEmails = new Set((teamMembersRes.data || []).map(tm => tm.team_member_email?.toLowerCase()).filter(Boolean));

      if (contentType === 'email') {
        // Parse email thread into individual messages for separate activities
        const parsedMessages = parseEmailThreadWithTimestamps(content);
        
        for (let i = 0; i < parsedMessages.length; i++) {
          const msg = parsedMessages[i];
          const msgTimestamp = msg.timestamp || inferContentTimestamp('email', msg.body, meetingDate, meetingTime);
          
          // Extract email from sender string (e.g., "John Doe <john@example.com>")
          const emailMatch = msg.sender.match(/<([^>]+)>/) || msg.sender.match(/([^\s]+@[^\s]+)/);
          const senderEmail = emailMatch?.[1]?.toLowerCase();
          const senderName = msg.sender.replace(/<[^>]+>/, '').trim() || msg.sender;
          
          // Determine if sender is internal (team member) or external (customer)
          const isInternal = senderEmail ? teamMemberEmails.has(senderEmail) : false;
          
          // Find matching contact for external senders
          const matchingContact = !isInternal && senderEmail 
            ? existingContacts.find(c => c.email?.toLowerCase() === senderEmail)
            : null;
          
          // Determine activity type based on direction
          const msgActivityType = isInternal ? 'email_sent' : 'email_received';
          const { data: activityTypeData } = await gateway
            .from('activity_types')
            .select('id')
            .eq('name', msgActivityType)
            .single()
            .execute();
          
          // Fallback to general email type if specific not found
          const activityTypeId = activityTypeData?.id || (await gateway
            .from('activity_types')
            .select('id')
            .eq('name', emailType)
            .single()
            .execute()).data?.id;

          if (activityTypeId) {
            await gateway.insert('opportunity_activities', {
              opportunity_id: opportunityId,
              account_id: accountId,
              transcript_id: transcriptReviewId,
              activity_type_id: activityTypeId,
              activity_date: msgTimestamp,
              title: `${title}${parsedMessages.length > 1 ? ` (${i + 1}/${parsedMessages.length})` : ''}`,
              notes: senderName ? `From: ${senderName}` : null,
              detection_source: 'manual_import',
              ae_email: isInternal ? senderEmail : oppData?.owner_email,
              se_email: oppData?.primary_se_email,
            });
          }
        }
      } else {
        // Meeting - single activity
        const activityTypeName = inferActivityType(title, content);
        const { data: activityType } = await gateway
          .from('activity_types')
          .select('id')
          .eq('name', activityTypeName)
          .single()
          .execute();

        if (activityType) {
          await gateway.insert('opportunity_activities', {
            opportunity_id: opportunityId,
            account_id: accountId,
            transcript_id: transcriptReviewId,
            activity_type_id: activityType.id,
            activity_date: occurredAt,
            title: title,
            detection_source: 'manual_import',
            ae_email: oppData?.owner_email,
            se_email: oppData?.primary_se_email,
          });
        }
      }

      setImportProgress(100);
      setImportStage('Complete!');

      return { transcriptId: transcriptReviewId };
    },
    onSuccess: () => {
      toast.success(`${contentType === 'email' ? 'Email' : 'Meeting transcript'} imported and analyzed successfully`);
      queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-activities', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-contacts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-strategic-themes', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-pain-points', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-themed-use-cases', opportunityId] });
      resetForm();
      onOpenChange(false);
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : 'Import failed');
      setIsImporting(false);
    },
  });

  const handleImport = () => {
    importMutation.mutate();
  };

  const isValid = title.trim() && content.trim();

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      if (isImporting) return; // Prevent closing during import
      if (!isOpen) resetForm();
      onOpenChange(isOpen);
    }}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Import Content to Opportunity
          </DialogTitle>
          <DialogDescription>
            Paste a meeting transcript or email to analyze and attach to this opportunity
          </DialogDescription>
        </DialogHeader>

        {isImporting && (
          <div className="rounded-lg border bg-primary/5 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-primary flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                {importStage}
              </span>
              <span className="text-xs text-muted-foreground">{Math.round(importProgress)}%</span>
            </div>
            <Progress value={importProgress} className="h-2" />
          </div>
        )}

        <div className="space-y-4">
          {/* Content Type Tabs */}
          <Tabs value={contentType} onValueChange={(v) => setContentType(v as 'meeting' | 'email')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="meeting" className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Meeting Transcript
              </TabsTrigger>
              <TabsTrigger value="email" className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Email
              </TabsTrigger>
            </TabsList>

            <TabsContent value="meeting" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Meeting Title</Label>
                  <Input
                    placeholder="e.g., Discovery Call - Acme Corp"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    disabled={isImporting}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Meeting Type</Label>
                  <Select value={meetingType} onValueChange={setMeetingType} disabled={isImporting}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MEETING_TYPES.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="email" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Email Subject</Label>
                  <Input
                    placeholder="e.g., RE: Follow-up on demo"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    disabled={isImporting}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email Type</Label>
                  <Select value={emailType} onValueChange={setEmailType} disabled={isImporting}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {EMAIL_TYPES.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                {contentType === 'email' ? 'Fallback Date' : 'Meeting Date'}
              </Label>
              <Input
                type="date"
                value={meetingDate}
                onChange={(e) => setMeetingDate(e.target.value)}
                disabled={isImporting}
              />
            </div>
            {contentType === 'meeting' && (
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Meeting Time
                </Label>
                <Input
                  type="time"
                  value={meetingTime}
                  onChange={(e) => setMeetingTime(e.target.value)}
                  disabled={isImporting}
                />
              </div>
            )}
            {contentType === 'email' && detectedTimestamps.length > 0 && (
              <div className="space-y-2">
                <Label className="text-xs text-muted-foreground">
                  Detected {detectedTimestamps.length} timestamp{detectedTimestamps.length !== 1 ? 's' : ''} in thread
                </Label>
                <div className="text-xs text-primary bg-primary/10 rounded px-2 py-1">
                  Latest: {format(new Date(detectedTimestamps[detectedTimestamps.length - 1]), 'PPp')}
                </div>
              </div>
            )}
          </div>

          {/* Content */}
          <div className="space-y-2">
            <Label>
              {contentType === 'email' ? 'Email Content' : 'Transcript Content'}
            </Label>
            <Textarea
              placeholder={contentType === 'email' 
                ? "Paste the full email thread here..." 
                : "Paste the meeting transcript here..."
              }
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[200px] font-mono text-sm"
              disabled={isImporting}
            />
            <p className="text-xs text-muted-foreground">
              {content.length.toLocaleString()} characters
              {content.length > 120000 && ' (will be truncated for analysis)'}
            </p>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isImporting}
            >
              Cancel
            </Button>
            <Button
              onClick={handleImport}
              disabled={!isValid || isImporting}
            >
              {isImporting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Import & Analyze
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
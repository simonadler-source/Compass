import { useState, useRef, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Upload, FileText, CheckCircle2, AlertCircle, Loader2, PlusCircle } from 'lucide-react';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

interface ParsedRow {
  date: string;
  dueTime: string;
  assigned: string;
  accountId: string;
  company: string;
  opportunity: string;
  opportunityStage: string;
  relatedTo: string;
  contact: string;
  subject: string;
  assignedRole: string;
  duration: number;
  activityType: string;
}

type ImportState = 'idle' | 'parsing' | 'matching' | 'reviewing' | 'creating_accounts' | 'importing' | 'done';

interface ImportResult {
  imported: number;
  skippedDedup: number;
  skippedNoAccount: number;
  linkedToOpportunity: number;
  accountOnly: number;
  accountsCreated: number;
}

interface UnmatchedCompany {
  key: string;
  name: string;
  rowCount: number;
  assignedTo: string[];
  opportunities: string[];
  salesforceId: string;
}

// Shared parsing state passed from matching to importing
interface MatchingContext {
  rows: ParsedRow[];
  allAccounts: { id: string; name: string; salesforce_account_id: string | null }[];
  debugLog: string[];
}

function parseCSV(text: string): ParsedRow[] {
  const lines = text.split('\n').filter(l => l.trim());
  if (lines.length < 2) return [];

  const parseLine = (line: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
        else inQuotes = !inQuotes;
      } else if (ch === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += ch;
      }
    }
    result.push(current.trim());
    return result;
  };

  const rows: ParsedRow[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = parseLine(lines[i]);
    if (cols.length < 12) continue;
    rows.push({
      date: cols[0],
      dueTime: cols[1],
      assigned: cols[2],
      accountId: cols[3],
      company: cols[4],
      opportunity: cols[5],
      opportunityStage: cols[6],
      relatedTo: cols[7],
      contact: cols[8],
      subject: cols[9],
      assignedRole: cols[10],
      duration: parseFloat(cols[11]) || 0,
      activityType: cols[12] || '',
    });
  }
  return rows;
}

function parseDateFromRow(row: ParsedRow): Date | null {
  try {
    if (row.dueTime) {
      const d = new Date(row.dueTime);
      if (!isNaN(d.getTime())) return d;
    }
    if (row.date) {
      const d = new Date(row.date);
      if (!isNaN(d.getTime())) return d;
    }
  } catch { /* ignore */ }
  return null;
}

export default function ImportSalesforceActivitiesDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [state, setState] = useState<ImportState>('idle');
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [fileName, setFileName] = useState('');
  const [debugLog, setDebugLog] = useState<string[]>([]);

  // Review state
  const [unmatchedCompanies, setUnmatchedCompanies] = useState<UnmatchedCompany[]>([]);
  const [selectedCompanies, setSelectedCompanies] = useState<Set<string>>(new Set());
  const [matchingCtx, setMatchingCtx] = useState<MatchingContext | null>(null);

  const addLog = (msg: string) => setDebugLog(prev => [...prev, msg]);

  const toggleCompany = (companyKey: string) => {
    setSelectedCompanies(prev => {
      const next = new Set(prev);
      if (next.has(companyKey)) next.delete(companyKey); else next.add(companyKey);
      return next;
    });
  };

  const toggleAll = () => {
    if (selectedCompanies.size === unmatchedCompanies.length) {
      setSelectedCompanies(new Set());
    } else {
      setSelectedCompanies(new Set(unmatchedCompanies.map(c => c.key)));
    }
  };

  const normalizeSalesforceId = (value?: string | null) => {
    if (!value) return '';
    return value.trim().toUpperCase();
  };

  const normalizeCompanyName = (value?: string | null) => {
    if (!value) return '';
    const stopWords = new Set([
      'the', 'inc', 'incorporated', 'llc', 'ltd', 'limited', 'gmbh', 'plc', 'corp', 'corporation',
      'co', 'company', 'group', 'holdings', 'uk', 'usa', 'us', 'ag', 'bv', 'pty'
    ]);

    return value
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .map(token => token.trim())
      .filter(token => token.length > 1 && !stopWords.has(token))
      .join(' ')
      .trim();
  };

  const buildAccountMaps = (accounts: { id: string; name: string; salesforce_account_id: string | null }[]) => {
    const accountBySfId = new Map<string, { id: string; name: string }>();
    const accountsByNameLower = new Map<string, { id: string; name: string }[]>();
    const accountsByNameNormalized = new Map<string, { id: string; name: string }[]>();

    accounts.forEach(a => {
      if (a.salesforce_account_id) {
        const normalizedId = normalizeSalesforceId(a.salesforce_account_id);
        if (normalizedId) {
          accountBySfId.set(normalizedId, { id: a.id, name: a.name });
          // Also support 15-char Salesforce IDs
          accountBySfId.set(normalizedId.slice(0, 15), { id: a.id, name: a.name });
          // Support truncated IDs (CSV may drop last 3 chars)
          if (normalizedId.length >= 6) {
            accountBySfId.set(normalizedId.slice(0, -3), { id: a.id, name: a.name });
          }
          if (normalizedId.length >= 18) {
            accountBySfId.set(normalizedId.slice(0, 12), { id: a.id, name: a.name });
          }
        }
      }

      const nameLower = a.name.toLowerCase().trim();
      if (!accountsByNameLower.has(nameLower)) accountsByNameLower.set(nameLower, []);
      accountsByNameLower.get(nameLower)!.push({ id: a.id, name: a.name });

      const normalizedName = normalizeCompanyName(a.name);
      if (normalizedName) {
        if (!accountsByNameNormalized.has(normalizedName)) accountsByNameNormalized.set(normalizedName, []);
        accountsByNameNormalized.get(normalizedName)!.push({ id: a.id, name: a.name });
      }
    });

    return { accountBySfId, accountsByNameLower, accountsByNameNormalized };
  };

  const resolveAccount = (
    row: ParsedRow,
    allAccounts: { id: string; name: string; salesforce_account_id: string | null }[],
    accountBySfId: Map<string, { id: string; name: string }>,
    accountsByNameLower: Map<string, { id: string; name: string }[]>,
    accountsByNameNormalized: Map<string, { id: string; name: string }[]>,
  ): { id: string; name: string; matchMethod: string } | null => {
    const normalizedRowSfId = normalizeSalesforceId(row.accountId);

    if (normalizedRowSfId) {
      // Try exact match first
      const sfMatch = accountBySfId.get(normalizedRowSfId) || accountBySfId.get(normalizedRowSfId.slice(0, 15));
      if (sfMatch) return { ...sfMatch, matchMethod: 'salesforce_id' };

      // CSV IDs may be truncated (missing last 3 chars) — try matching as a prefix
      const prefixMatches = allAccounts.filter(a => {
        if (!a.salesforce_account_id) return false;
        const dbId = normalizeSalesforceId(a.salesforce_account_id);
        // CSV id is a prefix of the DB id (truncated by up to 3 chars)
        return dbId.startsWith(normalizedRowSfId) && (dbId.length - normalizedRowSfId.length) <= 3;
      });
      if (prefixMatches.length === 1) return { id: prefixMatches[0].id, name: prefixMatches[0].name, matchMethod: 'salesforce_id_prefix' };

      // If prefix gives multiple matches, use company name to disambiguate
      if (prefixMatches.length > 1 && row.company) {
        const companyLower = row.company.toLowerCase().trim();
        const nameDisambiguated = prefixMatches.find(a => a.name.toLowerCase().trim() === companyLower);
        if (nameDisambiguated) return { id: nameDisambiguated.id, name: nameDisambiguated.name, matchMethod: 'salesforce_id_prefix_name' };

        const normalizedCompany = normalizeCompanyName(row.company);
        if (normalizedCompany) {
          const normDisambiguated = prefixMatches.find(a => normalizeCompanyName(a.name) === normalizedCompany);
          if (normDisambiguated) return { id: normDisambiguated.id, name: normDisambiguated.name, matchMethod: 'salesforce_id_prefix_name_normalized' };
        }
      }

      // No match on this SFDC ID — fall through to name matching instead of returning null
    }

    // Fallback matching for legacy rows without Salesforce Account ID
    if (row.company) {
      const companyLower = row.company.toLowerCase().trim();
      const nameMatches = accountsByNameLower.get(companyLower);
      if (nameMatches && nameMatches.length === 1) return { ...nameMatches[0], matchMethod: 'name_exact' };

      const normalizedCompany = normalizeCompanyName(row.company);
      if (normalizedCompany) {
        const normalizedMatches = accountsByNameNormalized.get(normalizedCompany);
        if (normalizedMatches && normalizedMatches.length === 1) {
          return { ...normalizedMatches[0], matchMethod: 'name_normalized' };
        }

        const partialMatches = allAccounts.filter(a => {
          const aNorm = normalizeCompanyName(a.name);
          return aNorm && (aNorm.includes(normalizedCompany) || normalizedCompany.includes(aNorm));
        });
        if (partialMatches.length === 1) {
          return { id: partialMatches[0].id, name: partialMatches[0].name, matchMethod: 'name_partial' };
        }
      }
    }

    if (row.relatedTo) {
      const relatedLower = row.relatedTo.toLowerCase().trim();
      const relatedMatches = accountsByNameLower.get(relatedLower);
      if (relatedMatches && relatedMatches.length === 1) return { ...relatedMatches[0], matchMethod: 'related_to' };

      const relatedNormalized = normalizeCompanyName(row.relatedTo);
      if (relatedNormalized) {
        const relatedNormMatches = accountsByNameNormalized.get(relatedNormalized);
        if (relatedNormMatches && relatedNormMatches.length === 1) {
          return { ...relatedNormMatches[0], matchMethod: 'related_to_normalized' };
        }
      }
    }

    return null;
  };

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user?.id) return;
    setFileName(file.name);
    setDebugLog([]);
    setState('parsing');
    setProgress(5);

    try {
      const text = await file.text();
      const rows = parseCSV(text);
      if (rows.length === 0) { toast.error('No data rows found in CSV'); setState('idle'); return; }
      addLog(`Parsed ${rows.length} rows from CSV`);

      setState('matching');
      setProgress(15);

      // Fetch ALL accounts (paginate past Supabase 1000-row default limit)
      let allAccountsRaw: { id: string; name: string; salesforce_account_id: string | null }[] = [];
      let page = 0;
      const pageSize = 1000;
      while (true) {
        const { data: batch } = await supabase
          .from('accounts')
          .select('id, name, salesforce_account_id')
          .order('id', { ascending: true })
          .range(page * pageSize, (page + 1) * pageSize - 1);
        if (!batch || batch.length === 0) break;
        allAccountsRaw = allAccountsRaw.concat(batch);
        if (batch.length < pageSize) break;
        page++;
      }

      const accts = allAccountsRaw;
      const { accountBySfId, accountsByNameLower, accountsByNameNormalized } = buildAccountMaps(accts);

      addLog(`Loaded ${accts.length} accounts (${accountBySfId.size} SF ID keys)`);

      // Resolve all rows
      const rowAccounts = rows.map(row => resolveAccount(row, accts, accountBySfId, accountsByNameLower, accountsByNameNormalized));

      const matchMethodCounts: Record<string, number> = {};
      rowAccounts.forEach(a => {
        if (a) matchMethodCounts[a.matchMethod] = (matchMethodCounts[a.matchMethod] || 0) + 1;
      });
      addLog(`Account matching: ${JSON.stringify(matchMethodCounts)}, unmatched: ${rowAccounts.filter(a => !a).length}`);

      // Collect account-creation candidates strictly by missing Salesforce Account ID
      const unmatchedGrouped = new Map<string, { name: string; rowCount: number; assignedTo: Set<string>; opportunities: Set<string>; salesforceId: string }>();
      rows.forEach((row, i) => {
        const normalizedSfId = normalizeSalesforceId(row.accountId);
        if (!normalizedSfId || rowAccounts[i]) return;

        const key = normalizedSfId.slice(0, 15);
        const displayName = row.company?.trim() || `SFDC ${normalizedSfId}`;

        if (!unmatchedGrouped.has(key)) {
          unmatchedGrouped.set(key, {
            name: displayName,
            rowCount: 0,
            assignedTo: new Set(),
            opportunities: new Set(),
            salesforceId: normalizedSfId,
          });
        }

        const group = unmatchedGrouped.get(key)!;
        group.rowCount++;
        if (row.assigned && row.assigned.trim()) group.assignedTo.add(row.assigned.trim());
        if (row.opportunity && row.opportunity.trim()) group.opportunities.add(row.opportunity.trim());
      });

      const unmatchedList: UnmatchedCompany[] = [...unmatchedGrouped.entries()]
        .map(([key, g]) => ({
          key,
          name: g.name,
          rowCount: g.rowCount,
          assignedTo: [...g.assignedTo],
          opportunities: [...g.opportunities],
          salesforceId: g.salesforceId,
        }))
        .sort((a, b) => b.rowCount - a.rowCount);

      addLog(`SFDC ID candidates to create: ${unmatchedList.length}`);

      setProgress(40);

      if (unmatchedList.length > 0) {
        // Show review step
        setUnmatchedCompanies(unmatchedList);
        setSelectedCompanies(new Set(unmatchedList.map(c => c.key))); // select all by default
        setMatchingCtx({ rows, allAccounts: accts, debugLog: [] });
        setState('reviewing');
        return;
      }

      // No unmatched — proceed directly
      await runImport(rows, accts);
    } catch (err: any) {
      console.error('Import error:', err);
      toast.error('Import failed: ' + (err.message || 'Unknown error'));
      setState('idle');
    }
  };

  const handleCreateAndImport = async () => {
    if (!matchingCtx || !user?.id) return;

    setState('creating_accounts');
    setProgress(45);

    const toCreate = unmatchedCompanies.filter(c => selectedCompanies.has(c.key));
    let accountsCreated = 0;
    const updatedAccounts = [...matchingCtx.allAccounts];

    for (let i = 0; i < toCreate.length; i++) {
      try {
        const insertData: any = {
          name: toCreate[i].name,
          owner_id: user.id,
        };
        if (toCreate[i].salesforceId) {
          insertData.salesforce_account_id = toCreate[i].salesforceId;
        }
        const res = await gateway.from('accounts').insert(insertData).execute();

        if (res.data?.[0]) {
          updatedAccounts.push({ id: res.data[0].id, name: toCreate[i].name, salesforce_account_id: toCreate[i].salesforceId || null });
          accountsCreated++;
        }
      } catch (err: any) {
        addLog(`Failed to create account "${toCreate[i].name}": ${err.message}`);
      }
      setProgress(45 + Math.round((i / toCreate.length) * 15));
    }

    addLog(`Created ${accountsCreated} new accounts`);
    queryClient.invalidateQueries({ queryKey: ['accounts'] });

    await runImport(matchingCtx.rows, updatedAccounts, accountsCreated);
  };

  const handleSkipAndImport = async () => {
    if (!matchingCtx) return;
    await runImport(matchingCtx.rows, matchingCtx.allAccounts);
  };

  const runImport = async (
    rows: ParsedRow[],
    allAccounts: { id: string; name: string; salesforce_account_id: string | null }[],
    accountsCreated = 0,
  ) => {
    setState('importing');
    setProgress(60);

    try {
      const { accountBySfId, accountsByNameLower, accountsByNameNormalized } = buildAccountMaps(allAccounts);
      const rowAccounts = rows.map(row => resolveAccount(row, allAccounts, accountBySfId, accountsByNameLower, accountsByNameNormalized));

      const matchedAccountIds = [...new Set(rowAccounts.filter(Boolean).map(a => a!.id))];

      const { data: momentumMeetings } = await supabase
        .from('momentum_meetings')
        .select('matched_account_id, start_time')
        .in('matched_account_id', matchedAccountIds.length > 0 ? matchedAccountIds : ['00000000-0000-0000-0000-000000000000']);

      const existingMeetingDates = new Set<string>();
      (momentumMeetings || []).forEach(m => {
        if (m.matched_account_id && m.start_time) {
          existingMeetingDates.add(`${m.matched_account_id}:${new Date(m.start_time).toISOString().slice(0, 10)}`);
        }
      });

      // Manual meetings are now in momentum_meetings with meeting_context='manual'
      // The momentum_meetings dedup check above already covers these

      const { data: opportunities } = await supabase
        .from('opportunities')
        .select('id, name, account_id, is_archived')
        .in('account_id', matchedAccountIds.length > 0 ? matchedAccountIds : ['00000000-0000-0000-0000-000000000000'])
        .eq('is_archived', false);

      const oppIds = (opportunities || []).map(o => o.id);
      let decryptedContacts: { name: string; opportunity_id: string }[] = [];
      try {
        const contactResult = await gateway.from('account_contacts')
          .select('id, name_encrypted, opportunity_id, is_internal')
          .in('opportunity_id', oppIds.length > 0 ? oppIds : ['00000000-0000-0000-0000-000000000000'])
          .eq('is_internal', false)
          .limit(500)
          .execute();
        decryptedContacts = (contactResult.data || [])
          .filter((c: any) => c.name_encrypted && c.opportunity_id)
          .map((c: any) => ({ name: (c.name_encrypted || '').toLowerCase(), opportunity_id: c.opportunity_id }));
      } catch { /* fallback */ }

      const normalizePersonName = (value?: string | null) =>
        (value || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

      const assigneeNameToEmail = new Map<string, string>();
      const recordAssignee = (name?: string | null, email?: string | null) => {
        const normalizedName = normalizePersonName(name);
        const normalizedEmail = email?.toLowerCase().trim();
        if (!normalizedName || !normalizedEmail) return;
        if (!assigneeNameToEmail.has(normalizedName)) {
          assigneeNameToEmail.set(normalizedName, normalizedEmail);
        }
      };

      try {
        const [teamMembersResult, profilesResult] = await Promise.all([
          gateway
            .from('team_members')
            .select('member_email, member_name')
            .eq('is_active', true)
            .limit(5000)
            .execute(),
          gateway
            .from('profiles')
            .select('email, full_name')
            .limit(5000)
            .execute(),
        ]);

        (teamMembersResult.data || []).forEach((member: any) => {
          recordAssignee(member.member_name, member.member_email);
        });

        (profilesResult.data || []).forEach((profile: any) => {
          recordAssignee(profile.full_name, profile.email);
        });
      } catch {
        // fallback to notes-based attribution in analytics hooks when lookup data isn't accessible
      }

      const resolveAssigneeEmail = (assigned?: string | null) => {
        if (!assigned) return null;
        const trimmed = assigned.trim();
        if (!trimmed) return null;
        if (trimmed.includes('@')) return trimmed.toLowerCase();
        return assigneeNameToEmail.get(normalizePersonName(trimmed)) || null;
      };

      setProgress(70);

      const importResult: ImportResult = {
        imported: 0, skippedDedup: 0, skippedNoAccount: 0,
        linkedToOpportunity: 0, accountOnly: 0, accountsCreated,
      };
      const toInsert: any[] = [];

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const account = rowAccounts[i];
        if (!account) { importResult.skippedNoAccount++; continue; }

        const meetingDate = parseDateFromRow(row);
        if (!meetingDate) { importResult.skippedNoAccount++; continue; }

        const dateKey = `${account.id}:${meetingDate.toISOString().slice(0, 10)}`;
        if (existingMeetingDates.has(dateKey)) { importResult.skippedDedup++; continue; }
        existingMeetingDates.add(dateKey);

        let linkedOppId: string | null = null;

        if (row.opportunity) {
          const oppNameLower = row.opportunity.toLowerCase().trim();
          const matchedOpp = (opportunities || []).find(o =>
            o.account_id === account.id && o.name.toLowerCase().includes(oppNameLower)
          );
          if (matchedOpp) linkedOppId = matchedOpp.id;
        }

        if (!linkedOppId && row.contact) {
          const contactNameLower = row.contact.toLowerCase().trim();
          const nameParts = contactNameLower.split(/\s+/);
          const matchedContact = decryptedContacts.find(c => {
            const accOpps = (opportunities || []).filter(o => o.account_id === account.id);
            const oppIdSet = new Set(accOpps.map(o => o.id));
            if (!oppIdSet.has(c.opportunity_id)) return false;
            return nameParts.every(p => c.name.includes(p));
          });
          if (matchedContact) linkedOppId = matchedContact.opportunity_id;
        }

        if (!linkedOppId && row.subject) {
          const subjectLower = row.subject.toLowerCase();
          const accountOpps = (opportunities || []).filter(o => o.account_id === account.id);
          for (const opp of accountOpps) {
            const oppWords = opp.name.toLowerCase().split(/[\s\-|/]+/).filter(w => w.length > 3);
            const matchScore = oppWords.filter(w => subjectLower.includes(w)).length;
            if (matchScore >= 2 || (oppWords.length <= 2 && matchScore >= 1)) {
              linkedOppId = opp.id;
              break;
            }
          }
        }

        if (!linkedOppId) {
          const accountOpps = (opportunities || []).filter(o => o.account_id === account.id);
          if (accountOpps.length === 1) linkedOppId = accountOpps[0].id;
        }

        if (linkedOppId) importResult.linkedToOpportunity++;
        else importResult.accountOnly++;

        const assignedName = row.assigned?.trim() || null;
        const assignedEmail = resolveAssigneeEmail(assignedName);
        const durationHours = Number.isFinite(row.duration) && row.duration > 0 ? row.duration : 1;

        toInsert.push({
          momentum_id: `manual_${crypto.randomUUID()}`,
          start_time: meetingDate.toISOString(),
          end_time: new Date(meetingDate.getTime() + durationHours * 60 * 60 * 1000).toISOString(),
          title: row.subject || 'Unrecorded Call',
          host_email: assignedEmail,
          host_name: assignedName,
          attendees: assignedName
            ? [{ name: assignedName, ...(assignedEmail ? { email: assignedEmail } : {}) }]
            : [],
          status: 'imported',
          meeting_context: 'manual',
          manual_meeting_type: 'unrecorded_call',
          is_highlighted: false,
          notes: `${row.subject}${row.contact ? `\nContact: ${row.contact}` : ''}${row.assigned ? `\nAssigned: ${row.assigned}` : ''}${row.duration ? `\nDuration: ${row.duration}h` : ''}`,
          matched_account_id: account.id,
          opportunity_id: linkedOppId,
        });
      }

      addLog(`Ready to insert: ${toInsert.length}, skipped: ${importResult.skippedNoAccount} no account, ${importResult.skippedDedup} dedup`);

      setProgress(75);
      const batchSize = 20;
      for (let i = 0; i < toInsert.length; i += batchSize) {
        const batch = toInsert.slice(i, i + batchSize);
        const res = await gateway.from('momentum_meetings').insert(batch).select().execute();
        if (res.error) console.error('Batch insert error:', getErrorMessage(res.error));
        importResult.imported += batch.length;
        setProgress(75 + Math.round((i / toInsert.length) * 20));
      }

      setProgress(100);
      setResult(importResult);
      setState('done');
      queryClient.invalidateQueries({ queryKey: ['manual-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['team-manual-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['weekly-activity-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['team-member-meetings'] });
      toast.success(`Imported ${importResult.imported} meetings`);
    } catch (err: any) {
      console.error('Import error:', err);
      toast.error('Import failed: ' + (err.message || 'Unknown error'));
      setState('idle');
    }
  };

  const handleClose = () => {
    setState('idle');
    setProgress(0);
    setResult(null);
    setDebugLog([]);
    setFileName('');
    setUnmatchedCompanies([]);
    setSelectedCompanies(new Set());
    setMatchingCtx(null);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5 text-primary" />
            Import Salesforce Activities
          </DialogTitle>
        </DialogHeader>

        {state === 'idle' && (
          <div className="space-y-4 py-4">
            <p className="text-sm text-muted-foreground">
              Upload a Salesforce activity CSV export. Meetings will be matched against existing records to avoid duplicates, and linked to opportunities where possible.
            </p>
            <div
              className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => fileRef.current?.click()}
            >
              <FileText className="h-10 w-10 mx-auto mb-3 text-muted-foreground/50" />
              <p className="text-sm font-medium">Click to select CSV file</p>
              <p className="text-xs text-muted-foreground mt-1">Salesforce Activity Report export</p>
            </div>
            <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={handleFile} />
          </div>
        )}

        {(state === 'parsing' || state === 'matching' || state === 'creating_accounts' || state === 'importing') && (
          <div className="space-y-4 py-4">
            <div className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin text-primary" />
              <p className="text-sm font-medium">
                {state === 'parsing' && 'Parsing CSV...'}
                {state === 'matching' && 'Matching accounts & deduplicating...'}
                {state === 'creating_accounts' && 'Creating new accounts...'}
                {state === 'importing' && 'Importing meetings...'}
              </p>
            </div>
            {fileName && <p className="text-xs text-muted-foreground">{fileName}</p>}
            <Progress value={progress} className="h-2" />
          </div>
        )}

        {state === 'reviewing' && (
          <div className="space-y-4 py-2 overflow-hidden flex flex-col">
            <div className="flex items-start gap-2 text-sm">
              <AlertCircle className="h-4 w-4 mt-0.5 shrink-0 text-amber-500" />
              <p className="text-muted-foreground">
                <strong className="text-foreground">{unmatchedCompanies.length} Salesforce accounts</strong> from the CSV are missing in Compass by Salesforce Account ID.
                Select the ones you'd like to create so their meetings can be imported.
              </p>
            </div>

            <div className="flex items-center justify-between">
              <button
                onClick={toggleAll}
                className="text-xs text-primary hover:underline"
              >
                {selectedCompanies.size === unmatchedCompanies.length ? 'Deselect all' : 'Select all'}
              </button>
              <Badge variant="secondary" className="text-xs">
                {selectedCompanies.size} selected
              </Badge>
            </div>

            <div className="border rounded-md overflow-auto max-h-[40vh] divide-y divide-border">
              {unmatchedCompanies.map(c => (
                <label
                  key={c.key}
                  className="flex items-start gap-3 px-3 py-2.5 hover:bg-muted/50 cursor-pointer transition-colors"
                >
                  <Checkbox
                    className="mt-0.5"
                    checked={selectedCompanies.has(c.key)}
                    onCheckedChange={() => toggleCompany(c.key)}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium truncate">{c.name}</span>
                      <span className="text-xs text-muted-foreground shrink-0">
                        {c.rowCount} {c.rowCount === 1 ? 'meeting' : 'meetings'}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground truncate">
                      SFDC ID: {c.salesforceId}
                    </p>
                    {c.assignedTo.length > 0 && (
                      <p className="text-xs text-muted-foreground mt-0.5 truncate">
                        Assigned: {c.assignedTo.join(', ')}
                      </p>
                    )}
                    {c.opportunities.length > 0 && (
                      <p className="text-xs text-muted-foreground truncate">
                        Opps: {c.opportunities.join(', ')}
                      </p>
                    )}
                  </div>
                </label>
              ))}
            </div>
          </div>
        )}

        {state === 'done' && result && (
          <div className="space-y-4 py-4">
            <div className="flex items-center gap-2 text-green-600">
              <CheckCircle2 className="h-5 w-5" />
              <p className="font-medium">Import Complete</p>
            </div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="bg-muted/50 rounded-lg p-3">
                <p className="text-xs text-muted-foreground">Imported</p>
                <p className="text-lg font-semibold">{result.imported}</p>
              </div>
              <div className="bg-muted/50 rounded-lg p-3">
                <p className="text-xs text-muted-foreground">Linked to Opportunity</p>
                <p className="text-lg font-semibold text-primary">{result.linkedToOpportunity}</p>
              </div>
              <div className="bg-muted/50 rounded-lg p-3">
                <p className="text-xs text-muted-foreground">Account-level Only</p>
                <p className="text-lg font-semibold">{result.accountOnly}</p>
              </div>
              <div className="bg-muted/50 rounded-lg p-3">
                <p className="text-xs text-muted-foreground">Skipped (Duplicates)</p>
                <p className="text-lg font-semibold">{result.skippedDedup}</p>
              </div>
            </div>
            {result.accountsCreated > 0 && (
              <div className="flex items-start gap-2 text-xs text-green-600">
                <PlusCircle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                <span>{result.accountsCreated} new accounts created</span>
              </div>
            )}
            {result.skippedNoAccount > 0 && (
              <div className="flex items-start gap-2 text-xs text-muted-foreground">
                <AlertCircle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                <span>{result.skippedNoAccount} rows skipped — account not found in system</span>
              </div>
            )}
            {debugLog.length > 0 && (
              <details className="text-xs">
                <summary className="cursor-pointer text-muted-foreground hover:text-foreground">Show matching details</summary>
                <div className="mt-2 bg-muted/30 rounded p-2 space-y-0.5 font-mono max-h-40 overflow-auto">
                  {debugLog.map((line, i) => (
                    <p key={i} className="text-muted-foreground">{line}</p>
                  ))}
                </div>
              </details>
            )}
          </div>
        )}

        <DialogFooter>
          {state === 'reviewing' ? (
            <div className="flex gap-2 w-full justify-end">
              <Button variant="outline" onClick={handleSkipAndImport}>
                Skip — import matched only
              </Button>
              <Button
                onClick={handleCreateAndImport}
                disabled={selectedCompanies.size === 0}
              >
                <PlusCircle className="h-4 w-4 mr-1.5" />
                Create {selectedCompanies.size} & Import
              </Button>
            </div>
          ) : state === 'done' ? (
            <Button onClick={handleClose}>Close</Button>
          ) : state === 'idle' ? (
            <Button variant="outline" onClick={handleClose}>Cancel</Button>
          ) : null}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

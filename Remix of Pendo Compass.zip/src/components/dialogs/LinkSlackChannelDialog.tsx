import { useState } from 'react';
import { Hash, X, MessageSquare, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { useSlackIntegration, SlackChannel } from '@/hooks/useSlackIntegration';
import { SlackChannelPicker } from '@/components/SlackChannelPicker';

interface LinkSlackChannelDialogProps {
  accountId?: string;
  opportunityId?: string;
  purpose: 'account' | 'opportunity';
}

export function LinkSlackChannelDialog({ accountId, opportunityId, purpose }: LinkSlackChannelDialogProps) {
  const { isSlackEnabled, channels, getLinkedChannels, addChannel, removeChannel } = useSlackIntegration();
  const [open, setOpen] = useState(false);
  const [showPicker, setShowPicker] = useState(false);

  if (!isSlackEnabled) return null;

  const linkedChannels = getLinkedChannels({ accountId, opportunityId });
  const existingIds = channels.map(c => c.id);

  const handleSelect = async (ch: { id: string; name: string }) => {
    const newChannel: SlackChannel = {
      id: ch.id,
      name: ch.name,
      purpose,
      ...(accountId && { linked_account_id: accountId }),
      ...(opportunityId && { linked_opportunity_id: opportunityId }),
    };
    await addChannel(newChannel);
    setShowPicker(false);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setShowPicker(false); }}>
      <Tooltip>
        <TooltipTrigger asChild>
          <DialogTrigger asChild>
            <Button variant="ghost" size="icon" className="relative">
              <MessageSquare className="w-4 h-4 text-muted-foreground" />
              {linkedChannels.length > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-primary text-primary-foreground text-[10px] flex items-center justify-center">
                  {linkedChannels.length}
                </span>
              )}
            </Button>
          </DialogTrigger>
        </TooltipTrigger>
        <TooltipContent>
          <p className="text-xs">Link Slack Channel</p>
        </TooltipContent>
      </Tooltip>

      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Linked Slack Channels
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {linkedChannels.length > 0 ? (
            <div className="space-y-2">
              {linkedChannels.map(ch => (
                <div key={ch.id} className="flex items-center justify-between bg-muted/50 rounded-lg px-3 py-2">
                  <div className="flex items-center gap-2">
                    <Hash className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{ch.name}</span>
                    {ch.last_sync_status === 'success' && (
                      <Badge variant="outline" className="text-xs bg-primary/10 text-primary border-primary/20">
                        Synced
                      </Badge>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-muted-foreground hover:text-destructive"
                    onClick={() => removeChannel(ch.id)}
                  >
                    <X className="w-3.5 h-3.5" />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              No Slack channels linked yet. Signals from linked channels will be automatically analyzed and associated with this {purpose}.
            </p>
          )}

          {showPicker ? (
            <div className="pt-2 border-t border-border">
              <SlackChannelPicker onSelect={handleSelect} excludeIds={existingIds} />
            </div>
          ) : (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowPicker(true)}
              className="w-full gap-2"
            >
              <Plus className="w-4 h-4" />
              Link a Channel
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

import { useState, useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link2, Plus, Briefcase, Loader2, Check, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { ScrollArea } from '@/components/ui/scroll-area';

import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';
import { mapMeetingTypeToActivity, inferActivityType } from '@/hooks/useOpportunityActivities';

interface LinkToOpportunityDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  accountId: string;
  transcriptReviewId?: string | null; // Optional — may not exist for unanalyzed meetings
  momentumMeetingId?: string | null;  // Internal meeting UUID for meeting-only linking
  meetingTitle?: string;
  meetingSfOppId?: string; // Salesforce Opportunity ID from the meeting
  onLinked?: (opportunityId: string) => void;
}

export function LinkToOpportunityDialog({
  open,
  onOpenChange,
  accountId,
  transcriptReviewId,
  momentumMeetingId,
  meetingTitle,
  meetingSfOppId,
  onLinked,
}: LinkToOpportunityDialogProps) {
  const queryClient = useQueryClient();
  const [selectedOpportunityId, setSelectedOpportunityId] = useState<string>('');
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newOpportunityName, setNewOpportunityName] = useState('');

  const hasTranscript = !!transcriptReviewId;

  // Fetch opportunities for this account (include salesforce_opportunity_id for matching)
  const { data: opportunities, isLoading: loadingOpportunities } = useQuery({
    queryKey: ['account-opportunities-for-linking', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunities')
        .select('id, name, stage, value, created_at, salesforce_opportunity_id')
        .eq('account_id', accountId)
        .order('created_at', { ascending: false })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    enabled: open,
  });

  // Auto-select opportunity based on SFDC ID match when dialog opens
  useEffect(() => {
    if (open && opportunities && meetingSfOppId) {
      const matchingOpp = opportunities.find(
        opp => opp.salesforce_opportunity_id === meetingSfOppId
      );
      if (matchingOpp) {
        setSelectedOpportunityId(matchingOpp.id);
        setIsCreatingNew(false);
      }
    }
  }, [open, opportunities, meetingSfOppId]);

  // Link to existing opportunity
  const linkMutation = useMutation({
    mutationFn: async (opportunityId: string) => {
      // If we have a transcript, link it and migrate insights
      if (transcriptReviewId) {
        // 1. Update transcript_reviews to link to opportunity
        const { error: linkError } = await gateway
          .from('transcript_reviews')
          .update({ opportunity_id: opportunityId })
          .eq('id', transcriptReviewId)
          .execute();
        if (linkError) throw new Error(getErrorMessage(linkError));

        // 2. Get transcript details for activity creation
        const { data: transcript } = await gateway
          .from('transcript_reviews')
          .select('file_name, extracted_insights, meeting_type, created_at')
          .eq('id', transcriptReviewId)
          .single()
          .execute();

        // 3. Get opportunity details for activity
        const { data: oppData } = await gateway
          .from('opportunities')
          .select('owner_email, primary_se_email')
          .eq('id', opportunityId)
          .single()
          .execute();

        // 4. Create activity for timeline
        const activityTypeName = transcript?.meeting_type 
          ? mapMeetingTypeToActivity(transcript.meeting_type)
          : inferActivityType(meetingTitle || 'Meeting');

        const { data: activityType } = await gateway
          .from('activity_types')
          .select('id')
          .eq('name', activityTypeName)
          .single()
          .execute();

        if (activityType?.id) {
          await gateway.from('opportunity_activities').upsert({
            opportunity_id: opportunityId,
            account_id: accountId,
            transcript_id: transcriptReviewId,
            activity_type_id: activityType.id,
            activity_date: transcript?.created_at || new Date().toISOString(),
            title: meetingTitle || 'Linked Meeting',
            detection_source: 'link_dialog',
            ae_email: oppData?.owner_email,
            se_email: oppData?.primary_se_email,
          }, { onConflict: 'transcript_id' }).execute();
        }

        // 5. Migrate contacts from this transcript to the opportunity
        if (transcript?.file_name) {
          await gateway
            .from('account_contacts')
            .update({ opportunity_id: opportunityId })
            .eq('account_id', accountId)
            .is('opportunity_id', null)
            .execute();

          await gateway
            .from('account_nbas')
            .update({ opportunity_id: opportunityId })
            .eq('source_transcript_id', transcriptReviewId)
            .is('opportunity_id', null)
            .execute();

          await gateway
            .from('account_use_cases')
            .update({ opportunity_id: opportunityId })
            .eq('source_transcript_id', transcriptReviewId)
            .is('opportunity_id', null)
            .execute();

          await gateway
            .from('account_metrics')
            .update({ opportunity_id: opportunityId })
            .eq('source_transcript_id', transcriptReviewId)
            .is('opportunity_id', null)
            .execute();

          await gateway
            .from('detection_rule_matches')
            .update({ opportunity_id: opportunityId })
            .eq('transcript_id', transcriptReviewId)
            .is('opportunity_id', null)
            .execute();
        }
      }

      // If we have a momentum meeting ID, link the meeting record and any associated transcript_reviews
      if (momentumMeetingId && momentumMeetingId !== 'null' && momentumMeetingId !== 'undefined') {
        // Update the momentum_meetings table directly
        await gateway
          .from('momentum_meetings')
          .update({ opportunity_id: opportunityId })
          .eq('id', momentumMeetingId)
          .execute();

        // Also update any transcript_reviews linked to this meeting
        await gateway
          .from('transcript_reviews')
          .update({ opportunity_id: opportunityId })
          .eq('momentum_meeting_id', momentumMeetingId)
          .execute();
      }

      return opportunityId;
    },
    onSuccess: (opportunityId) => {
      toast.success(hasTranscript 
        ? 'Transcript linked and insights migrated to opportunity'
        : 'Meeting linked to opportunity');
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', accountId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-momentum-meetings', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-contacts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-activities', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['account-activities', accountId] });
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings-account', accountId] });
      onLinked?.(opportunityId);
      onOpenChange(false);
    },
    onError: (error) => {
      console.error('Link error:', error);
      toast.error('Failed to link to opportunity');
    },
  });

  // Create new opportunity and link
  const createAndLinkMutation = useMutation({
    mutationFn: async (name: string) => {
      const { data: inserted, error: createError } = await gateway
        .from('opportunities')
        .insert({
          account_id: accountId,
          name,
          stage: 'identified',
          priority: 'medium',
          salesforce_opportunity_id: meetingSfOppId || null,
        })
        .execute();
      
      if (createError) throw new Error(getErrorMessage(createError));
      const newOpp = Array.isArray(inserted) ? inserted[0] : inserted;
      if (!newOpp?.id) throw new Error('Failed to create opportunity');
      
      await linkMutation.mutateAsync(newOpp.id);
      
      return newOpp.id;
    },
    onSuccess: (opportunityId) => {
      toast.success('New opportunity created and linked');
      queryClient.invalidateQueries({ queryKey: ['account-opportunities', accountId] });
      onLinked?.(opportunityId);
      onOpenChange(false);
    },
    onError: (error) => {
      console.error('Create error:', error);
      toast.error('Failed to create opportunity');
    },
  });

  const handleSubmit = () => {
    if (isCreatingNew) {
      if (!newOpportunityName.trim()) {
        toast.error('Please enter an opportunity name');
        return;
      }
      createAndLinkMutation.mutate(newOpportunityName.trim());
    } else {
      if (!selectedOpportunityId) {
        toast.error('Please select an opportunity');
        return;
      }
      linkMutation.mutate(selectedOpportunityId);
    }
  };

  const isSubmitting = linkMutation.isPending || createAndLinkMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Link2 className="w-5 h-5" />
            Link to Opportunity
          </DialogTitle>
          <DialogDescription>
            {meetingTitle 
              ? `Link "${meetingTitle}" to an opportunity.${hasTranscript ? ' Insights and contacts will be migrated.' : ''}`
              : `Link this ${hasTranscript ? 'transcript' : 'meeting'} to an opportunity.`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {loadingOpportunities ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <>
              <RadioGroup
                value={isCreatingNew ? 'new' : selectedOpportunityId}
                onValueChange={(value) => {
                  if (value === 'new') {
                    setIsCreatingNew(true);
                    setSelectedOpportunityId('');
                  } else {
                    setIsCreatingNew(false);
                    setSelectedOpportunityId(value);
                  }
                }}
              >
                {/* Existing opportunities */}
                {opportunities && opportunities.length > 0 && (
                  <ScrollArea className="max-h-[200px]">
                    <div className="space-y-2">
                      {opportunities.map((opp) => {
                        const isSfMatch = meetingSfOppId && opp.salesforce_opportunity_id === meetingSfOppId;
                        return (
                          <div 
                            key={opp.id}
                            className={`flex items-center space-x-3 p-3 rounded-lg border cursor-pointer ${
                              isSfMatch 
                                ? 'border-green-500/50 bg-green-500/5 hover:bg-green-500/10' 
                                : 'border-border hover:bg-muted/50'
                            }`}
                            onClick={() => {
                              setIsCreatingNew(false);
                              setSelectedOpportunityId(opp.id);
                            }}
                          >
                            <RadioGroupItem value={opp.id} id={opp.id} />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <label htmlFor={opp.id} className="font-medium text-sm cursor-pointer">
                                  {opp.name}
                                </label>
                                {isSfMatch && (
                                  <Badge variant="outline" className="text-xs bg-green-500/10 text-green-600 border-green-500/30">
                                    <Zap className="w-3 h-3 mr-1" />
                                    SFDC Match
                                  </Badge>
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground">
                                {opp.stage && `Stage: ${opp.stage}`}
                                {opp.value && ` • $${(opp.value / 1000).toFixed(0)}k`}
                              </p>
                            </div>
                            {selectedOpportunityId === opp.id && !isCreatingNew && (
                              <Check className="w-4 h-4 text-primary" />
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </ScrollArea>
                )}

                {/* Create new option */}
                <div 
                  className="flex items-center space-x-3 p-3 rounded-lg border border-dashed border-primary/50 hover:bg-primary/5 cursor-pointer"
                  onClick={() => setIsCreatingNew(true)}
                >
                  <RadioGroupItem value="new" id="new-opportunity" />
                  <div className="flex-1">
                    <label htmlFor="new-opportunity" className="font-medium text-sm cursor-pointer flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      Create New Opportunity
                    </label>
                  </div>
                </div>
              </RadioGroup>

              {/* New opportunity name input */}
              {isCreatingNew && (
                <div className="space-y-2 pt-2">
                  <Label htmlFor="new-opp-name">Opportunity Name</Label>
                  <Input
                    id="new-opp-name"
                    placeholder="Enter opportunity name..."
                    value={newOpportunityName}
                    onChange={(e) => setNewOpportunityName(e.target.value)}
                    autoFocus
                  />
                </div>
              )}
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting || loadingOpportunities}>
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {isCreatingNew ? 'Creating...' : 'Linking...' }
              </>
            ) : (
              <>
                {isCreatingNew ? <Plus className="w-4 h-4 mr-2" /> : <Link2 className="w-4 h-4 mr-2" />}
                {isCreatingNew ? 'Create & Link' : 'Link to Opportunity'}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useState, useMemo } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Building2, Link2, Plus, Loader2, Check, Search, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';
import { mapMeetingTypeToActivity, inferActivityType } from '@/hooks/useOpportunityActivities';

interface MoveToAccountDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  transcriptIds: string[];
  currentAccountId: string;
  meetingTitles?: string[];
  onMoved?: () => void;
}

export function MoveToAccountDialog({
  open,
  onOpenChange,
  transcriptIds,
  currentAccountId,
  meetingTitles = [],
  onMoved,
}: MoveToAccountDialogProps) {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [selectedOpportunityId, setSelectedOpportunityId] = useState<string>('');
  const [isCreatingNewOpp, setIsCreatingNewOpp] = useState(false);
  const [newOpportunityName, setNewOpportunityName] = useState('');
  const [step, setStep] = useState<'account' | 'opportunity'>('account');

  // Fetch all accounts using gateway for proper access control
  const { data: accounts, isLoading: loadingAccounts } = useQuery({
    queryKey: ['all-accounts-for-move'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('accounts')
        .select('id, name, industry, status')
        .order('name', { ascending: true })
        .execute();
      if (error) throw error;
      return data;
    },
    enabled: open,
  });

  // Filter accounts based on search
  const filteredAccounts = useMemo(() => {
    if (!accounts) return [];
    const query = searchQuery.toLowerCase().trim();
    if (!query) return accounts.filter(a => a.id !== currentAccountId);
    return accounts.filter(a => 
      a.id !== currentAccountId && 
      a.name.toLowerCase().includes(query)
    );
  }, [accounts, searchQuery, currentAccountId]);

  // Fetch opportunities for selected account using gateway
  const { data: opportunities, isLoading: loadingOpportunities } = useQuery({
    queryKey: ['account-opportunities-for-move', selectedAccountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunities')
        .select('id, name, stage, value, created_at')
        .eq('account_id', selectedAccountId)
        .order('created_at', { ascending: false })
        .execute();
      if (error) throw error;
      return data;
    },
    enabled: !!selectedAccountId && step === 'opportunity',
  });

  const selectedAccountName = accounts?.find(a => a.id === selectedAccountId)?.name || '';

  // Move transcripts mutation
  const moveMutation = useMutation({
    mutationFn: async () => {
      const opportunityId = isCreatingNewOpp ? null : (selectedOpportunityId || null);
      let finalOpportunityId = opportunityId;

      // If creating a new opportunity, create it first
      if (isCreatingNewOpp && newOpportunityName.trim()) {
        const { data: inserted, error: createError } = await gateway
          .from('opportunities')
          .insert({
            account_id: selectedAccountId,
            name: newOpportunityName.trim(),
            stage: 'identified',
            priority: 'medium',
          })
          .execute();
        
        if (createError) throw new Error(getErrorMessage(createError));
        const newOpp = Array.isArray(inserted) ? inserted[0] : inserted;
        if (!newOpp?.id) throw new Error('Failed to create opportunity');
        finalOpportunityId = newOpp.id;
      }

      // Move each transcript
      for (const transcriptId of transcriptIds) {
        // 1. Update the transcript_reviews record
        const { error: updateError } = await supabase
          .from('transcript_reviews')
          .update({ 
            final_account_id: selectedAccountId,
            opportunity_id: finalOpportunityId,
          })
          .eq('id', transcriptId);
        
        if (updateError) throw updateError;

        // 2. Get transcript details for activity update
        const { data: transcript } = await supabase
          .from('transcript_reviews')
          .select('file_name, meeting_type, meeting_title, created_at')
          .eq('id', transcriptId)
          .single();

        // 3. If linking to an opportunity, create/update activity
        if (finalOpportunityId) {
          const { data: oppData } = await supabase
            .from('opportunities')
            .select('owner_email, primary_se_email')
            .eq('id', finalOpportunityId)
            .single();

          const activityTypeName = transcript?.meeting_type 
            ? mapMeetingTypeToActivity(transcript.meeting_type)
            : inferActivityType(transcript?.meeting_title || 'Meeting');

          const { data: activityType } = await gateway
            .from('activity_types')
            .select('id')
            .eq('name', activityTypeName)
            .single()
            .execute();

          if (activityType?.id) {
            // Delete any old activity for this transcript, then create new
            await gateway.from('opportunity_activities')
              .delete()
              .eq('transcript_id', transcriptId)
              .execute();

            await gateway.from('opportunity_activities').insert({
              opportunity_id: finalOpportunityId,
              account_id: selectedAccountId,
              transcript_id: transcriptId,
              activity_type_id: activityType.id,
              activity_date: transcript?.created_at || new Date().toISOString(),
              title: transcript?.meeting_title || 'Moved Meeting',
              detection_source: 'move_dialog',
              ae_email: oppData?.owner_email,
              se_email: oppData?.primary_se_email,
            }).execute();
          }
        }

        // 4. Update related insights to point to new account/opportunity
        // NBAs
        await supabase
          .from('account_nbas')
          .update({ 
            account_id: selectedAccountId,
            opportunity_id: finalOpportunityId 
          })
          .eq('source_transcript_id', transcriptId);

        // Pain points
        await supabase
          .from('account_pain_points')
          .update({ 
            account_id: selectedAccountId,
            opportunity_id: finalOpportunityId 
          })
          .eq('source_transcript_id', transcriptId);

        // Use cases
        await supabase
          .from('account_use_cases')
          .update({ 
            account_id: selectedAccountId,
            opportunity_id: finalOpportunityId 
          })
          .eq('source_transcript_id', transcriptId);

        // Metrics
        await supabase
          .from('account_metrics')
          .update({ 
            account_id: selectedAccountId,
            opportunity_id: finalOpportunityId 
          })
          .eq('source_transcript_id', transcriptId);

        // Detection rule matches
        await supabase
          .from('detection_rule_matches')
          .update({ opportunity_id: finalOpportunityId })
          .eq('transcript_id', transcriptId);
      }

      return { 
        movedCount: transcriptIds.length, 
        accountId: selectedAccountId,
        opportunityId: finalOpportunityId 
      };
    },
    onSuccess: ({ movedCount, accountId, opportunityId }) => {
      toast.success(`${movedCount} transcript${movedCount > 1 ? 's' : ''} moved to ${selectedAccountName}`);
      
      // Invalidate queries for both old and new accounts
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', currentAccountId] });
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', accountId] });
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings-account', currentAccountId] });
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings-account', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account', currentAccountId] });
      queryClient.invalidateQueries({ queryKey: ['account', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', currentAccountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      
      if (opportunityId) {
        queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', opportunityId] });
        queryClient.invalidateQueries({ queryKey: ['opportunity-activities', opportunityId] });
      }
      
      onMoved?.();
      handleClose();
    },
    onError: (error) => {
      console.error('Move error:', error);
      toast.error('Failed to move transcript(s)');
    },
  });

  const handleClose = () => {
    setSearchQuery('');
    setSelectedAccountId('');
    setSelectedOpportunityId('');
    setIsCreatingNewOpp(false);
    setNewOpportunityName('');
    setStep('account');
    onOpenChange(false);
  };

  const handleNextStep = () => {
    if (!selectedAccountId) {
      toast.error('Please select an account');
      return;
    }
    setStep('opportunity');
  };

  const handleMove = () => {
    if (isCreatingNewOpp && !newOpportunityName.trim()) {
      toast.error('Please enter an opportunity name');
      return;
    }
    moveMutation.mutate();
  };

  const isSubmitting = moveMutation.isPending;
  const transcriptCount = transcriptIds.length;
  const displayTitle = meetingTitles.length === 1 
    ? meetingTitles[0] 
    : `${transcriptCount} transcript${transcriptCount > 1 ? 's' : ''}`;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            Move to Different Account
          </DialogTitle>
          <DialogDescription>
            {step === 'account' 
              ? `Select the destination account for "${displayTitle}".`
              : `Select an opportunity on ${selectedAccountName} (optional).`
            }
          </DialogDescription>
        </DialogHeader>

        {step === 'account' ? (
          <div className="space-y-4 py-4">
            {/* Search input */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search accounts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>

            {loadingAccounts ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <ScrollArea className="max-h-[300px]">
                <RadioGroup
                  value={selectedAccountId}
                  onValueChange={setSelectedAccountId}
                  className="space-y-2"
                >
                  {filteredAccounts.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      {searchQuery ? 'No matching accounts found' : 'No other accounts available'}
                    </p>
                  ) : (
                    filteredAccounts.map((account) => (
                      <div 
                        key={account.id}
                        className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer"
                        onClick={() => setSelectedAccountId(account.id)}
                      >
                        <RadioGroupItem value={account.id} id={account.id} />
                        <div className="flex-1 min-w-0">
                          <label htmlFor={account.id} className="font-medium text-sm cursor-pointer">
                            {account.name}
                          </label>
                          {account.industry && (
                            <p className="text-xs text-muted-foreground">
                              {account.industry}
                            </p>
                          )}
                        </div>
                        {selectedAccountId === account.id && (
                          <Check className="w-4 h-4 text-primary" />
                        )}
                      </div>
                    ))
                  )}
                </RadioGroup>
              </ScrollArea>
            )}
          </div>
        ) : (
          <div className="space-y-4 py-4">
            {loadingOpportunities ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <>
                <RadioGroup
                  value={isCreatingNewOpp ? 'new' : (selectedOpportunityId || 'none')}
                  onValueChange={(value) => {
                    if (value === 'new') {
                      setIsCreatingNewOpp(true);
                      setSelectedOpportunityId('');
                    } else if (value === 'none') {
                      setIsCreatingNewOpp(false);
                      setSelectedOpportunityId('');
                    } else {
                      setIsCreatingNewOpp(false);
                      setSelectedOpportunityId(value);
                    }
                  }}
                >
                  {/* No opportunity option */}
                  <div 
                    className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer"
                    onClick={() => {
                      setIsCreatingNewOpp(false);
                      setSelectedOpportunityId('');
                    }}
                  >
                    <RadioGroupItem value="none" id="no-opportunity" />
                    <div className="flex-1">
                      <label htmlFor="no-opportunity" className="font-medium text-sm cursor-pointer">
                        No opportunity (account-level only)
                      </label>
                    </div>
                  </div>

                  {/* Existing opportunities */}
                  {opportunities && opportunities.length > 0 && (
                    <ScrollArea className="max-h-[180px]">
                      <div className="space-y-2">
                        {opportunities.map((opp) => (
                          <div 
                            key={opp.id}
                            className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer"
                            onClick={() => {
                              setIsCreatingNewOpp(false);
                              setSelectedOpportunityId(opp.id);
                            }}
                          >
                            <RadioGroupItem value={opp.id} id={opp.id} />
                            <div className="flex-1 min-w-0">
                              <label htmlFor={opp.id} className="font-medium text-sm cursor-pointer">
                                {opp.name}
                              </label>
                              <p className="text-xs text-muted-foreground">
                                {opp.stage && `Stage: ${opp.stage}`}
                                {opp.value && ` • $${(opp.value / 1000).toFixed(0)}k`}
                              </p>
                            </div>
                            {selectedOpportunityId === opp.id && !isCreatingNewOpp && (
                              <Check className="w-4 h-4 text-primary" />
                            )}
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  )}

                  {/* Create new option */}
                  <div 
                    className="flex items-center space-x-3 p-3 rounded-lg border border-dashed border-primary/50 hover:bg-primary/5 cursor-pointer"
                    onClick={() => setIsCreatingNewOpp(true)}
                  >
                    <RadioGroupItem value="new" id="new-opportunity" />
                    <div className="flex-1">
                      <label htmlFor="new-opportunity" className="font-medium text-sm cursor-pointer flex items-center gap-2">
                        <Plus className="w-4 h-4" />
                        Create New Opportunity
                      </label>
                    </div>
                  </div>
                </RadioGroup>

                {/* New opportunity name input */}
                {isCreatingNewOpp && (
                  <div className="space-y-2 pt-2">
                    <Label htmlFor="new-opp-name">Opportunity Name</Label>
                    <Input
                      id="new-opp-name"
                      placeholder="Enter opportunity name..."
                      value={newOpportunityName}
                      onChange={(e) => setNewOpportunityName(e.target.value)}
                      autoFocus
                    />
                  </div>
                )}
              </>
            )}
          </div>
        )}

        <DialogFooter>
          {step === 'opportunity' && (
            <Button variant="ghost" onClick={() => setStep('account')} disabled={isSubmitting}>
              Back
            </Button>
          )}
          <Button variant="outline" onClick={handleClose} disabled={isSubmitting}>
            Cancel
          </Button>
          {step === 'account' ? (
            <Button onClick={handleNextStep} disabled={!selectedAccountId || loadingAccounts}>
              <ArrowRight className="w-4 h-4 mr-2" />
              Next
            </Button>
          ) : (
            <Button onClick={handleMove} disabled={isSubmitting || loadingOpportunities}>
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Moving...
                </>
              ) : (
                <>
                  <Building2 className="w-4 h-4 mr-2" />
                  Move {transcriptCount > 1 ? `${transcriptCount} Transcripts` : 'Transcript'}
                </>
              )}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useState, useMemo } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowRightLeft, Check, Loader2, Plus, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { ScrollArea } from '@/components/ui/scroll-area';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { mapMeetingTypeToActivity, inferActivityType } from '@/hooks/useOpportunityActivities';

interface MoveToOpportunityDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  transcriptId: string;
  transcriptTitle: string;
  accountId: string;
  currentOpportunityId?: string | null;
  onMoved?: () => void;
}

export function MoveToOpportunityDialog({
  open,
  onOpenChange,
  transcriptId,
  transcriptTitle,
  accountId,
  currentOpportunityId,
  onMoved,
}: MoveToOpportunityDialogProps) {
  const queryClient = useQueryClient();
  const [selectedOpportunityId, setSelectedOpportunityId] = useState<string>('');
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newOpportunityName, setNewOpportunityName] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch opportunities for this account
  const { data: opportunities, isLoading } = useQuery({
    queryKey: ['account-opportunities-for-move-opp', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunities')
        .select('id, name, stage, value, is_archived')
        .eq('account_id', accountId)
        .order('created_at', { ascending: false })
        .execute();
      if (error) throw error;
      return (data || []).filter((o: any) => !o.is_archived);
    },
    enabled: open,
  });

  const filteredOpportunities = useMemo(() => {
    if (!opportunities) return [];
    const q = searchQuery.toLowerCase().trim();
    const filtered = opportunities.filter((o: any) => o.id !== currentOpportunityId);
    if (!q) return filtered;
    return filtered.filter((o: any) => o.name.toLowerCase().includes(q));
  }, [opportunities, searchQuery, currentOpportunityId]);

  const moveMutation = useMutation({
    mutationFn: async () => {
      let targetOpportunityId = isCreatingNew ? null : (selectedOpportunityId || null);

      // Create new opportunity if needed
      if (isCreatingNew && newOpportunityName.trim()) {
        const { data: inserted, error: createError } = await gateway
          .from('opportunities')
          .insert({
            account_id: accountId,
            name: newOpportunityName.trim(),
            stage: 'identified',
            priority: 'medium',
          })
          .execute();
        if (createError) throw new Error(getErrorMessage(createError));
        const newOpp = Array.isArray(inserted) ? inserted[0] : inserted;
        if (!newOpp?.id) throw new Error('Failed to create opportunity');
        targetOpportunityId = newOpp.id;
      }

      if (!targetOpportunityId) throw new Error('Please select an opportunity');

      // 1. Update the transcript_reviews record
      const { error: updateError } = await supabase
        .from('transcript_reviews')
        .update({ opportunity_id: targetOpportunityId })
        .eq('id', transcriptId);
      if (updateError) throw updateError;

      // 2. Also update the momentum_meeting if linked
      const { data: transcript } = await supabase
        .from('transcript_reviews')
        .select('file_name, meeting_type, meeting_title, created_at, momentum_meeting_id')
        .eq('id', transcriptId)
        .single();

      if (transcript?.momentum_meeting_id) {
        await gateway
          .from('momentum_meetings')
          .update({ opportunity_id: targetOpportunityId })
          .eq('id', transcript.momentum_meeting_id)
          .execute();
      }

      // 3. Move linked insights to new opportunity
      await Promise.all([
        supabase
          .from('account_nbas')
          .update({ opportunity_id: targetOpportunityId })
          .eq('source_transcript_id', transcriptId),
        supabase
          .from('account_pain_points')
          .update({ opportunity_id: targetOpportunityId })
          .eq('source_transcript_id', transcriptId),
        supabase
          .from('account_use_cases')
          .update({ opportunity_id: targetOpportunityId })
          .eq('source_transcript_id', transcriptId),
        supabase
          .from('account_metrics')
          .update({ opportunity_id: targetOpportunityId })
          .eq('source_transcript_id', transcriptId),
        supabase
          .from('detection_rule_matches')
          .update({ opportunity_id: targetOpportunityId })
          .eq('transcript_id', transcriptId),
        supabase
          .from('account_captured_insights')
          .update({ opportunity_id: targetOpportunityId })
          .eq('source_transcript_id', transcriptId),
      ]);

      // 4. Update activity record
      const { data: oppData } = await supabase
        .from('opportunities')
        .select('owner_email, primary_se_email')
        .eq('id', targetOpportunityId)
        .single();

      const activityTypeName = transcript?.meeting_type
        ? mapMeetingTypeToActivity(transcript.meeting_type)
        : inferActivityType(transcript?.meeting_title || 'Meeting');

      const { data: activityType } = await gateway
        .from('activity_types')
        .select('id')
        .eq('name', activityTypeName)
        .single()
        .execute();

      if (activityType?.id) {
        await gateway.from('opportunity_activities')
          .delete()
          .eq('transcript_id', transcriptId)
          .execute();

        await gateway.from('opportunity_activities').insert({
          opportunity_id: targetOpportunityId,
          account_id: accountId,
          transcript_id: transcriptId,
          activity_type_id: activityType.id,
          activity_date: transcript?.created_at || new Date().toISOString(),
          title: transcript?.meeting_title || 'Moved Meeting',
          detection_source: 'move_dialog',
          ae_email: oppData?.owner_email,
          se_email: oppData?.primary_se_email,
        }).execute();
      }

      return targetOpportunityId;
    },
    onSuccess: (targetOpportunityId) => {
      const targetName = isCreatingNew
        ? newOpportunityName
        : opportunities?.find((o: any) => o.id === targetOpportunityId)?.name || 'opportunity';
      toast.success(`Transcript moved to "${targetName}"`);

      // Invalidate relevant queries
      if (currentOpportunityId) {
        queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', currentOpportunityId] });
        queryClient.invalidateQueries({ queryKey: ['opportunity-activities', currentOpportunityId] });
      }
      queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-activities', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', accountId] });
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings-account', accountId] });

      onMoved?.();
      handleClose();
    },
    onError: (error) => {
      console.error('Move error:', error);
      toast.error('Failed to move transcript');
    },
  });

  const handleClose = () => {
    setSelectedOpportunityId('');
    setIsCreatingNew(false);
    setNewOpportunityName('');
    setSearchQuery('');
    onOpenChange(false);
  };

  const handleMove = () => {
    if (isCreatingNew && !newOpportunityName.trim()) {
      toast.error('Please enter an opportunity name');
      return;
    }
    if (!isCreatingNew && !selectedOpportunityId) {
      toast.error('Please select an opportunity');
      return;
    }
    moveMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5" />
            Move to Opportunity
          </DialogTitle>
          <DialogDescription>
            Move "{transcriptTitle}" and its linked insights to a different opportunity.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search opportunities..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <RadioGroup
              value={isCreatingNew ? 'new' : selectedOpportunityId}
              onValueChange={(value) => {
                if (value === 'new') {
                  setIsCreatingNew(true);
                  setSelectedOpportunityId('');
                } else {
                  setIsCreatingNew(false);
                  setSelectedOpportunityId(value);
                }
              }}
            >
              <ScrollArea className="max-h-[250px]">
                <div className="space-y-2">
                  {filteredOpportunities.length === 0 && !isCreatingNew ? (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      {searchQuery ? 'No matching opportunities found' : 'No other opportunities available'}
                    </p>
                  ) : (
                    filteredOpportunities.map((opp: any) => (
                      <div
                        key={opp.id}
                        className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer"
                        onClick={() => {
                          setIsCreatingNew(false);
                          setSelectedOpportunityId(opp.id);
                        }}
                      >
                        <RadioGroupItem value={opp.id} id={`opp-${opp.id}`} />
                        <div className="flex-1 min-w-0">
                          <label htmlFor={`opp-${opp.id}`} className="font-medium text-sm cursor-pointer">
                            {opp.name}
                          </label>
                          <p className="text-xs text-muted-foreground">
                            {opp.stage && `Stage: ${opp.stage}`}
                            {opp.value && ` • $${(opp.value / 1000).toFixed(0)}k`}
                          </p>
                        </div>
                        {selectedOpportunityId === opp.id && !isCreatingNew && (
                          <Check className="w-4 h-4 text-primary" />
                        )}
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>

              {/* Create new */}
              <div
                className="flex items-center space-x-3 p-3 rounded-lg border border-dashed border-primary/50 hover:bg-primary/5 cursor-pointer"
                onClick={() => setIsCreatingNew(true)}
              >
                <RadioGroupItem value="new" id="new-opp-move" />
                <label htmlFor="new-opp-move" className="font-medium text-sm cursor-pointer flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Create New Opportunity
                </label>
              </div>
            </RadioGroup>
          )}

          {isCreatingNew && (
            <div className="space-y-2 pt-2">
              <Label htmlFor="new-opp-name-move">Opportunity Name</Label>
              <Input
                id="new-opp-name-move"
                placeholder="Enter opportunity name..."
                value={newOpportunityName}
                onChange={(e) => setNewOpportunityName(e.target.value)}
              />
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={moveMutation.isPending}>
            Cancel
          </Button>
          <Button onClick={handleMove} disabled={moveMutation.isPending}>
            {moveMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Moving...
              </>
            ) : (
              'Move Transcript'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { BookOpen, Copy, Plus, Trash2, ExternalLink, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface ShareOpportunityDigestDialogProps {
  opportunityId: string;
  opportunityName: string;
}

export function ShareOpportunityDigestDialog({ opportunityId, opportunityName }: ShareOpportunityDigestDialogProps) {
  const [open, setOpen] = useState(false);
  const [label, setLabel] = useState('NotebookLM');
  const queryClient = useQueryClient();

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;

  const { data: shareLinks, isLoading } = useQuery({
    queryKey: ['opportunity-share-links', opportunityId],
    queryFn: async () => {
      const res = await gateway
        .from('opportunity_share_links')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .is('revoked_at', null)
        .order('created_at', { ascending: false })
        .execute();
      if (res.error) throw new Error(getErrorMessage(res.error));
      return res.data || [];
    },
    enabled: open,
  });

  const createLink = useMutation({
    mutationFn: async () => {
      const res = await gateway
        .from('opportunity_share_links')
        .insert({
          opportunity_id: opportunityId,
          label: label || null,
        })
        .select()
        .single()
        .execute();
      if (res.error) throw new Error(getErrorMessage(res.error));
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-share-links', opportunityId] });
      toast.success('Share link created');
      setLabel('NotebookLM');
    },
    onError: () => toast.error('Failed to create share link'),
  });

  const revokeLink = useMutation({
    mutationFn: async (linkId: string) => {
      const res = await gateway
        .from('opportunity_share_links')
        .update({ revoked_at: new Date().toISOString() })
        .eq('id', linkId)
        .execute();
      if (res.error) throw new Error(getErrorMessage(res.error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-share-links', opportunityId] });
      toast.success('Share link revoked');
    },
    onError: () => toast.error('Failed to revoke link'),
  });

  const getShareUrl = (token: string) =>
    `${supabaseUrl}/functions/v1/render-opportunity-digest?token=${token}`;

  const copyUrl = (token: string) => {
    navigator.clipboard.writeText(getShareUrl(token));
    toast.success('URL copied to clipboard');
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Tooltip>
        <TooltipTrigger asChild>
          <DialogTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </Button>
          </DialogTrigger>
        </TooltipTrigger>
        <TooltipContent>Share digest for NotebookLM</TooltipContent>
      </Tooltip>

      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Share Opportunity Digest</DialogTitle>
          <DialogDescription>
            Generate a public URL that renders a full HTML digest of this opportunity. 
            Use it as a web source in Google NotebookLM or any AI tool.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Create new link */}
          <div className="flex gap-2 items-end">
            <div className="flex-1">
              <Label htmlFor="link-label">Label (optional)</Label>
              <Input
                id="link-label"
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="e.g. NotebookLM, Research"
              />
            </div>
            <Button onClick={() => createLink.mutate()} disabled={createLink.isPending}>
              {createLink.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4 mr-1" />}
              Create Link
            </Button>
          </div>

          {/* Existing links */}
          {isLoading ? (
            <div className="flex justify-center py-4">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : shareLinks && shareLinks.length > 0 ? (
            <div className="space-y-3">
              <Label>Active Links</Label>
              {shareLinks.map((link: any) => (
                <div key={link.id} className="border border-border rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {link.label && <Badge variant="secondary">{link.label}</Badge>}
                      <span className="text-xs text-muted-foreground">
                        Created {format(new Date(link.created_at), 'MMM d, yyyy')}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-xs text-muted-foreground">
                        {link.access_count} view{link.access_count !== 1 ? 's' : ''}
                      </span>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => copyUrl(link.share_token)}>
                            <Copy className="h-3.5 w-3.5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Copy URL</TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7" asChild>
                            <a href={getShareUrl(link.share_token)} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="h-3.5 w-3.5" />
                            </a>
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Preview in browser</TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-muted-foreground hover:text-destructive"
                            onClick={() => revokeLink.mutate(link.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Revoke link</TooltipContent>
                      </Tooltip>
                    </div>
                  </div>
                  <div className="bg-muted rounded px-2 py-1.5">
                    <code className="text-xs break-all text-muted-foreground select-all">
                      {getShareUrl(link.share_token)}
                    </code>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              No active share links. Create one above.
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

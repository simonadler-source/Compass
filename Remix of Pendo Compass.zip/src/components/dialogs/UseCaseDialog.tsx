import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCreateUseCase, useUpdateUseCase, AccountUseCase } from '@/hooks/useAccountUseCases';
import { useFunctionalAreas } from '@/hooks/useTechnologyRepository';

interface UseCaseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  accountId: string;
  opportunityId?: string;
  functionalArea?: string;
  existingUseCase?: AccountUseCase;
}

const STATUS_OPTIONS = [
  { value: 'identified', label: 'Identified' },
  { value: 'validated', label: 'Validated' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'implemented', label: 'Implemented' },
  { value: 'blocked', label: 'Blocked' },
];

const PRIORITY_OPTIONS = [
  { value: 'critical', label: 'Critical' },
  { value: 'high', label: 'High' },
  { value: 'medium', label: 'Medium' },
  { value: 'low', label: 'Low' },
];

export function UseCaseDialog({ 
  open, 
  onOpenChange, 
  accountId,
  opportunityId,
  functionalArea,
  existingUseCase 
}: UseCaseDialogProps) {
  const [useCase, setUseCase] = useState(existingUseCase?.use_case || '');
  const [description, setDescription] = useState(existingUseCase?.description || '');
  const [selectedArea, setSelectedArea] = useState(existingUseCase?.functional_area || functionalArea || '');
  const [status, setStatus] = useState(existingUseCase?.status || 'identified');
  const [priority, setPriority] = useState(existingUseCase?.priority || 'medium');

  const { data: functionalAreas } = useFunctionalAreas();
  const createUseCase = useCreateUseCase();
  const updateUseCase = useUpdateUseCase();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!useCase.trim() || !selectedArea) return;

    if (existingUseCase) {
      await updateUseCase.mutateAsync({
        id: existingUseCase.id,
        accountId,
        use_case: useCase,
        description: description || null,
        functional_area: selectedArea,
        status,
        priority,
      });
    } else {
      await createUseCase.mutateAsync({
        account_id: accountId,
        opportunity_id: opportunityId || null,
        functional_area: selectedArea,
        use_case: useCase,
        description: description || null,
        status,
        priority,
        source: 'manual',
        source_transcript_id: null,
        sort_order: 0,
        radar_x: null,
        radar_y: null,
      });
    }

    onOpenChange(false);
    setUseCase('');
    setDescription('');
    setStatus('identified');
    setPriority('medium');
  };

  const isLoading = createUseCase.isPending || updateUseCase.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{existingUseCase ? 'Edit Use Case' : 'Add Use Case'}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="functional-area">Functional Area</Label>
            <Select value={selectedArea} onValueChange={setSelectedArea}>
              <SelectTrigger>
                <SelectValue placeholder="Select functional area" />
              </SelectTrigger>
              <SelectContent>
                {functionalAreas?.map(area => (
                  <SelectItem key={area.id} value={area.name}>
                    {area.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="use-case">Use Case</Label>
            <Input
              id="use-case"
              value={useCase}
              onChange={(e) => setUseCase(e.target.value)}
              placeholder="e.g., Track feature adoption rates"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description (optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the use case in more detail..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Priority</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRIORITY_OPTIONS.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading || !useCase.trim() || !selectedArea}>
              {isLoading ? 'Saving...' : existingUseCase ? 'Update' : 'Add Use Case'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

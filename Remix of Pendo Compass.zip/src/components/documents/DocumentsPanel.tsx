import { useState, useMemo } from 'react';
import { 
  FileText, Link2, Plus, ExternalLink, MoreVertical, Edit, Trash2, 
  Filter, Building2, Target, Calendar, Tag, AlertCircle, Sparkles, Loader2, Pencil 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
 import { Badge } from '@/components/ui/badge';
 import { Input } from '@/components/ui/input';
 import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
 } from '@/components/ui/select';
  import {
   DropdownMenu,
   DropdownMenuContent,
   DropdownMenuItem,
   DropdownMenuSeparator,
   DropdownMenuTrigger,
 } from '@/components/ui/dropdown-menu';
 import {
   Dialog,
   DialogContent,
   DialogDescription,
   DialogFooter,
   DialogHeader,
   DialogTitle,
 } from '@/components/ui/dialog';
 import {
   AlertDialog,
   AlertDialogAction,
   AlertDialogCancel,
   AlertDialogContent,
   AlertDialogDescription,
   AlertDialogFooter,
   AlertDialogHeader,
   AlertDialogTitle,
 } from '@/components/ui/alert-dialog';
 import { Skeleton } from '@/components/ui/skeleton';
 import { cn } from '@/lib/utils';
 import { 
   Document, 
   useAccountDocuments, 
   useOpportunityDocuments,
   useDeleteDocument,
   useUpdateDocument 
  } from '@/hooks/useDocuments';
 import type { UpdateDocumentInput } from '@/hooks/useDocuments';
import { AddDocumentDialog } from '@/components/dialogs/AddDocumentDialog';
import { useAnalyzeDocumentCriteria } from '@/hooks/useAnalyzeDocumentCriteria';
import { gateway } from '@/lib/apiGateway';
 
 interface DocumentsPanelProps {
   accountId: string;
   accountName?: string;
   opportunityId?: string | null;
   opportunityName?: string;
   context: 'account' | 'opportunity';
 }
 
 const typeIcons: Record<string, string> = {
   proposal: '📄',
   contract: '📝',
   presentation: '📊',
   technical_spec: '⚙️',
   case_study: '📚',
   screenshot: '🖼️',
   meeting_notes: '📋',
   reference: '🔗',
   other: '📁',
 };
 
 const statusColors: Record<string, string> = {
  draft: 'bg-muted text-muted-foreground border-muted',
  active: 'bg-primary/20 text-primary border-primary/30',
  archived: 'bg-muted text-muted-foreground border-muted',
  expired: 'bg-destructive/20 text-destructive border-destructive/30',
 };
 
  export function DocumentsPanel({
   accountId,
   accountName,
   opportunityId,
   opportunityName,
   context,
 }: DocumentsPanelProps) {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [scopeFilter, setScopeFilter] = useState<'all' | 'account' | 'opportunity'>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [deleteDocId, setDeleteDocId] = useState<string | null>(null);
  const [analyzingDocId, setAnalyzingDocId] = useState<string | null>(null);
  const [editingDoc, setEditingDoc] = useState<Document | null>(null);

  const deleteDocument = useDeleteDocument();
  const updateDocument = useUpdateDocument();
  const analyzeDocument = useAnalyzeDocumentCriteria();
 
   // Fetch documents based on context
   const accountDocsQuery = useAccountDocuments(context === 'account' ? accountId : null);
   const opportunityDocsQuery = useOpportunityDocuments(
     context === 'opportunity' ? opportunityId || null : null,
     context === 'opportunity' ? accountId : null
   );
 
   const isLoading = context === 'account' ? accountDocsQuery.isLoading : opportunityDocsQuery.isLoading;
 
   // Combine and categorize documents
   const { allDocuments, accountDocs, opportunityDocs } = useMemo(() => {
     if (context === 'account') {
       const docs = accountDocsQuery.data || [];
       const accDocs = docs.filter(d => !d.opportunity_id);
       const oppDocs = docs.filter(d => d.opportunity_id);
       return { allDocuments: docs, accountDocs: accDocs, opportunityDocs: oppDocs };
     } else {
       const oppDocs = opportunityDocsQuery.data?.opportunityDocs || [];
       const accDocs = opportunityDocsQuery.data?.accountDocs || [];
       return { allDocuments: [...oppDocs, ...accDocs], accountDocs: accDocs, opportunityDocs: oppDocs };
     }
   }, [context, accountDocsQuery.data, opportunityDocsQuery.data]);
 
   // Filter documents
   const filteredDocuments = useMemo(() => {
     let docs = allDocuments;
 
     // Scope filter
     if (scopeFilter === 'account') {
       docs = accountDocs;
     } else if (scopeFilter === 'opportunity') {
       docs = opportunityDocs;
     }
 
     // Type filter
     if (typeFilter !== 'all') {
       docs = docs.filter(d => d.type === typeFilter);
     }
 
     // Status filter
     if (statusFilter !== 'all') {
       docs = docs.filter(d => d.status === statusFilter);
     }
 
     // Search filter
     if (searchQuery.trim()) {
       const query = searchQuery.toLowerCase();
       docs = docs.filter(d => 
         d.name.toLowerCase().includes(query) ||
         d.description?.toLowerCase().includes(query) ||
         d.tags?.some(t => t.toLowerCase().includes(query))
       );
     }
 
     return docs;
   }, [allDocuments, accountDocs, opportunityDocs, scopeFilter, typeFilter, statusFilter, searchQuery]);
 
   // Check for expired documents
   const expiredCount = useMemo(() => {
     const now = new Date();
     return allDocuments.filter(d => d.expiry_date && new Date(d.expiry_date) < now).length;
   }, [allDocuments]);
 
  const handleOpenDocument = (doc: Document) => {
    if (!doc.file_url) return;
    const url = doc.file_url.trim();
    if (!url) return;

    // Use a temporary anchor element to reliably open in a new tab,
    // bypassing iframe sandbox restrictions.
    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleAnalyzeDocument = async (doc: Document) => {
    if (!opportunityId || context !== 'opportunity') return;
    setAnalyzingDocId(doc.id);
    try {
      // Get document content: either from content field, or fetch from URL description
      let content = '';
      
      // Try to get content from the document record itself
      const result = await gateway.from('account_documents')
        .select('content, description, name')
        .eq('id', doc.id)
        .single()
        .execute();
      
      const docData = result.data as any;
      content = docData?.content || docData?.description || '';
      
      if (!content && doc.file_url && !doc.is_external_url) {
        content = `[Document: ${doc.name}] - Content not available for direct analysis. Description: ${doc.description || 'No description provided.'}`;
      }
      
      if (!content || content.length < 20) {
        // Fallback: use description + name as minimal context
        content = `Document: ${doc.name}\nType: ${doc.type}\nDescription: ${doc.description || 'No description'}\nTags: ${doc.tags?.join(', ') || 'None'}`;
      }

      await analyzeDocument.mutateAsync({
        opportunityId: opportunityId!,
        documentContent: content,
        documentName: doc.name,
      });
    } finally {
      setAnalyzingDocId(null);
    }
  };

  const handleArchiveDocument = async (doc: Document) => {
     await updateDocument.mutateAsync({
       id: doc.id,
       status: doc.status === 'archived' ? 'active' : 'archived',
     });
   };
 
   const handleDeleteConfirm = async () => {
     if (deleteDocId) {
       await deleteDocument.mutateAsync(deleteDocId);
       setDeleteDocId(null);
     }
   };
 
   const uniqueTypes = useMemo(() => {
     const types = new Set(allDocuments.map(d => d.type));
     return Array.from(types);
   }, [allDocuments]);
 
   if (isLoading) {
     return (
       <div className="space-y-4">
         <Skeleton className="h-10 w-full" />
         <Skeleton className="h-24 w-full" />
         <Skeleton className="h-24 w-full" />
       </div>
     );
   }
 
   return (
     <div className="space-y-6">
       {/* Header */}
       <div className="flex items-center justify-between">
         <div>
           <h2 className="text-xl font-semibold text-foreground">Documents & Links</h2>
           <p className="text-sm text-muted-foreground">
             {context === 'account' 
               ? 'All documents across this account and its opportunities'
               : 'Documents for this opportunity and inherited account documents'}
           </p>
         </div>
         <Button onClick={() => setShowAddDialog(true)}>
           <Plus className="w-4 h-4 mr-2" />
           Add Document
         </Button>
       </div>
 
       {/* Expired Warning */}
       {expiredCount > 0 && (
         <div className="flex items-center gap-2 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
           <AlertCircle className="w-4 h-4 text-amber-500" />
           <span className="text-sm text-amber-600">
             {expiredCount} document{expiredCount > 1 ? 's have' : ' has'} expired
           </span>
         </div>
       )}
 
       {/* Filters */}
       <div className="flex flex-wrap items-center gap-3">
         <div className="flex-1 min-w-[200px]">
           <Input
             placeholder="Search documents..."
             value={searchQuery}
             onChange={(e) => setSearchQuery(e.target.value)}
             className="w-full"
           />
         </div>
 
         <Select value={scopeFilter} onValueChange={(v) => setScopeFilter(v as typeof scopeFilter)}>
           <SelectTrigger className="w-[150px]">
             <Filter className="w-4 h-4 mr-2" />
             <SelectValue placeholder="Scope" />
           </SelectTrigger>
           <SelectContent>
             <SelectItem value="all">All Documents</SelectItem>
             <SelectItem value="account">
               <span className="flex items-center gap-2">
                 <Building2 className="w-3 h-3" />
                 Account Level
               </span>
             </SelectItem>
             {context === 'account' && (
               <SelectItem value="opportunity">
                 <span className="flex items-center gap-2">
                   <Target className="w-3 h-3" />
                   Opportunities
                 </span>
               </SelectItem>
             )}
             {context === 'opportunity' && (
               <SelectItem value="opportunity">
                 <span className="flex items-center gap-2">
                   <Target className="w-3 h-3" />
                   This Opportunity
                 </span>
               </SelectItem>
             )}
           </SelectContent>
         </Select>
 
         {uniqueTypes.length > 0 && (
           <Select value={typeFilter} onValueChange={setTypeFilter}>
             <SelectTrigger className="w-[140px]">
               <SelectValue placeholder="Type" />
             </SelectTrigger>
             <SelectContent>
               <SelectItem value="all">All Types</SelectItem>
               {uniqueTypes.map(type => (
                 <SelectItem key={type} value={type}>
                   {typeIcons[type] || '📁'} {type.replace('_', ' ')}
                 </SelectItem>
               ))}
             </SelectContent>
           </Select>
         )}
 
         <Select value={statusFilter} onValueChange={setStatusFilter}>
           <SelectTrigger className="w-[120px]">
             <SelectValue placeholder="Status" />
           </SelectTrigger>
           <SelectContent>
             <SelectItem value="all">All Status</SelectItem>
             <SelectItem value="active">Active</SelectItem>
             <SelectItem value="draft">Draft</SelectItem>
             <SelectItem value="archived">Archived</SelectItem>
             <SelectItem value="expired">Expired</SelectItem>
           </SelectContent>
         </Select>
       </div>
 
       {/* Document Summary */}
       <div className="flex gap-4 text-sm">
         <span className="text-muted-foreground">
           <span className="font-medium text-foreground">{filteredDocuments.length}</span> document{filteredDocuments.length !== 1 ? 's' : ''}
         </span>
         {context === 'opportunity' && accountDocs.length > 0 && scopeFilter !== 'opportunity' && (
           <span className="text-muted-foreground">
             • <span className="font-medium text-foreground">{accountDocs.length}</span> inherited from account
           </span>
         )}
       </div>
 
       {/* Document List */}
       {filteredDocuments.length === 0 ? (
         <div className="glass rounded-xl p-8 text-center">
           <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
           <p className="text-muted-foreground">No documents found</p>
           <p className="text-sm text-muted-foreground mt-1">
             {searchQuery || typeFilter !== 'all' || statusFilter !== 'all'
               ? 'Try adjusting your filters'
               : 'Add documents, proposals, or external links'}
           </p>
         </div>
       ) : (
          <div className="grid gap-3">
            {filteredDocuments.map((doc) => (
              <DocumentCard
                key={doc.id}
                document={doc}
                context={context}
                isInherited={context === 'opportunity' && !doc.opportunity_id}
                isAnalyzing={analyzingDocId === doc.id}
                showAnalyze={context === 'opportunity' && !!opportunityId}
                onOpen={handleOpenDocument}
                onEdit={setEditingDoc}
                onArchive={handleArchiveDocument}
                onDelete={setDeleteDocId}
                onAnalyze={handleAnalyzeDocument}
              />
            ))}
          </div>
       )}
 
       {/* Add Document Dialog */}
       <AddDocumentDialog
         open={showAddDialog}
         onOpenChange={setShowAddDialog}
         accountId={accountId}
         opportunityId={context === 'opportunity' ? opportunityId : undefined}
         opportunityName={opportunityName}
       />
 
       {/* Delete Confirmation */}
       <AlertDialog open={!!deleteDocId} onOpenChange={() => setDeleteDocId(null)}>
         <AlertDialogContent>
           <AlertDialogHeader>
             <AlertDialogTitle>Delete Document?</AlertDialogTitle>
             <AlertDialogDescription>
               This action cannot be undone. The document will be permanently removed.
             </AlertDialogDescription>
           </AlertDialogHeader>
           <AlertDialogFooter>
             <AlertDialogCancel>Cancel</AlertDialogCancel>
             <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive text-destructive-foreground">
               Delete
             </AlertDialogAction>
           </AlertDialogFooter>
         </AlertDialogContent>
        </AlertDialog>

        {/* Edit Document Dialog */}
        <EditDocumentDialog
          document={editingDoc}
          onClose={() => setEditingDoc(null)}
          onSave={async (updates) => {
            await updateDocument.mutateAsync(updates);
            setEditingDoc(null);
          }}
        />
      </div>
    );
  }
 
interface DocumentCardProps {
  document: Document;
  context: 'account' | 'opportunity';
  isInherited: boolean;
  isAnalyzing: boolean;
  showAnalyze: boolean;
  onOpen: (doc: Document) => void;
  onEdit: (doc: Document) => void;
  onArchive: (doc: Document) => void;
  onDelete: (id: string) => void;
  onAnalyze: (doc: Document) => void;
}

function DocumentCard({ document, context, isInherited, isAnalyzing, showAnalyze, onOpen, onEdit, onArchive, onDelete, onAnalyze }: DocumentCardProps) {
   const isExpired = document.expiry_date && new Date(document.expiry_date) < new Date();
   const effectiveStatus = isExpired ? 'expired' : document.status;
 
   return (
     <div 
       className={cn(
         "glass rounded-xl p-4 hover:bg-accent/5 transition-colors cursor-pointer group",
         isInherited && "border-l-2 border-l-primary/30"
       )}
       onClick={() => onOpen(document)}
     >
       <div className="flex items-start justify-between gap-4">
         <div className="flex items-start gap-3 flex-1 min-w-0">
           <div className="text-2xl">{typeIcons[document.type] || '📁'}</div>
           <div className="flex-1 min-w-0">
             <div className="flex items-center gap-2 flex-wrap">
               <span className="font-medium text-foreground truncate">{document.name}</span>
               {document.is_external_url && (
                 <ExternalLink className="w-3 h-3 text-muted-foreground flex-shrink-0" />
               )}
               {isInherited && (
                 <Badge variant="outline" className="text-xs gap-1">
                   <Building2 className="w-3 h-3" />
                   Account
                 </Badge>
               )}
             </div>
             {document.description && (
               <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{document.description}</p>
             )}
             <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground flex-wrap">
               <Badge variant="secondary" className={cn("text-xs", statusColors[effectiveStatus])}>
                 {effectiveStatus}
               </Badge>
               <span>v{document.version}</span>
               <span className="flex items-center gap-1">
                 <Calendar className="w-3 h-3" />
                 {new Date(document.created_at).toLocaleDateString()}
               </span>
               {document.expiry_date && (
                 <span className={cn("flex items-center gap-1", isExpired && "text-destructive")}>
                   Expires: {new Date(document.expiry_date).toLocaleDateString()}
                 </span>
               )}
             </div>
             {document.tags && document.tags.length > 0 && (
               <div className="flex items-center gap-1 mt-2 flex-wrap">
                 <Tag className="w-3 h-3 text-muted-foreground" />
                 {document.tags.map(tag => (
                   <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                 ))}
               </div>
             )}
           </div>
         </div>
 
         <DropdownMenu>
           <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
             <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
               <MoreVertical className="w-4 h-4" />
             </Button>
           </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {document.file_url && (
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onOpen(document); }}>
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open Link
                </DropdownMenuItem>
              )}
              {showAnalyze && (
                <DropdownMenuItem 
                  onClick={(e) => { e.stopPropagation(); onAnalyze(document); }}
                  disabled={isAnalyzing}
                >
                  {isAnalyzing ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4 mr-2 text-violet-500" />
                  )}
                  {isAnalyzing ? 'Analyzing...' : 'Analyze for Criteria'}
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onEdit(document); }}>
                <Pencil className="w-4 h-4 mr-2" />
                Edit Details
              </DropdownMenuItem>
              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onArchive(document); }}>
               <Edit className="w-4 h-4 mr-2" />
               {document.status === 'archived' ? 'Unarchive' : 'Archive'}
             </DropdownMenuItem>
             <DropdownMenuSeparator />
             <DropdownMenuItem 
               onClick={(e) => { e.stopPropagation(); onDelete(document.id); }}
               className="text-destructive focus:text-destructive"
             >
               <Trash2 className="w-4 h-4 mr-2" />
               Delete
             </DropdownMenuItem>
           </DropdownMenuContent>
         </DropdownMenu>
       </div>
     </div>
   );
 }

// ─── Edit Document Dialog ────────────────────────────────────────────────────
interface EditDocumentDialogProps {
  document: Document | null;
  onClose: () => void;
  onSave: (updates: UpdateDocumentInput) => Promise<void>;
}

function EditDocumentDialog({ document, onClose, onSave }: EditDocumentDialogProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [saving, setSaving] = useState(false);

  // Reset form when document changes
  useMemo(() => {
    if (document) {
      setName(document.name || '');
      setDescription(document.description || '');
      setFileUrl(document.file_url || '');
    }
  }, [document?.id]);

  const handleSave = async () => {
    if (!document || !name.trim()) return;
    setSaving(true);
    try {
      await onSave({
        id: document.id,
        name: name.trim(),
        description: description.trim() || null,
        file_url: fileUrl.trim() || null,
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={!!document} onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Document</DialogTitle>
          <DialogDescription>Update the document name, description, or URL.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="doc-name">Name</Label>
            <Input
              id="doc-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Document name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="doc-description">Description</Label>
            <Input
              id="doc-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description (optional)"
            />
          </div>
          {document?.is_external_url && (
            <div className="space-y-2">
              <Label htmlFor="doc-url">URL</Label>
              <Input
                id="doc-url"
                value={fileUrl}
                onChange={(e) => setFileUrl(e.target.value)}
                placeholder="https://..."
              />
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving || !name.trim()}>
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
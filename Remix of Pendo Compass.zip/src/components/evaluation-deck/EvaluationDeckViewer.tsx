import React, { useState, useRef, useCallback, useMemo } from 'react';
import { X, ChevronLeft, ChevronRight, Download, Share2, Maximize2, Minimize2, FileText, FileSpreadsheet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useEvaluationDeckData, type EvaluationDeckData } from '@/hooks/useEvaluationDeckData';
import { SlideOverview } from './slides/SlideOverview';
import { SlideStrategicThemes } from './slides/SlideStrategicThemes';
import { SlideUseCases } from './slides/SlideUseCases';
import { SlideSuccessCriteriaPage, paginateSuccessCriteria } from './slides/SlideSuccessCriteria';
import { SlideReadinessPage, paginateReadiness } from './slides/SlideReadiness';
import { SlideTimeline } from './slides/SlideTimeline';
import { SlideValidationTasks } from './slides/SlideValidationTasks';
import { SlideRisks } from './slides/SlideRisks';
import { getOpportunityUrl } from '@/lib/appUrl';
import { Skeleton } from '@/components/ui/skeleton';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import pendoLogo from '@/assets/pendo-logo.png';

interface EvaluationDeckViewerProps {
  opportunityId: string;
  accountId: string;
  accountName: string;
  opportunityName: string;
  onClose: () => void;
}

const SLIDE_WIDTH = 1920;
const SLIDE_HEIGHT = 1080;

type SlideEntry = {
  title: string;
  render: (slideNumber: number, totalSlides: number) => React.ReactNode;
};

function buildSlideList(data: EvaluationDeckData, oppUrl: string): SlideEntry[] {
  const slides: SlideEntry[] = [];

  // 1. Overview
  slides.push({
    title: 'Evaluation Overview',
    render: (sn, ts) => <SlideOverview data={data} oppUrl={oppUrl} />,
  });

  // 2. Strategic Themes
  slides.push({
    title: 'Strategic Themes',
    render: (sn, ts) => <SlideStrategicThemes data={data} oppUrl={oppUrl} />,
  });

  // 3. Use Cases
  slides.push({
    title: 'Evaluation Use Cases',
    render: (sn, ts) => <SlideUseCases data={data} oppUrl={oppUrl} />,
  });

  // 4. Success Criteria (paginated)
  const criteriaPages = paginateSuccessCriteria(data.successCriteria);
  criteriaPages.forEach((page, i) => {
    slides.push({
      title: i === 0 ? 'Success Criteria' : `Success Criteria (${i + 1})`,
      render: (sn, ts) => (
        <SlideSuccessCriteriaPage
          data={data}
          oppUrl={oppUrl}
          criteria={page}
          pageIndex={i}
          totalPages={criteriaPages.length}
          slideNumber={sn}
          totalSlides={ts}
        />
      ),
    });
  });

  // 5. Technical Readiness (paginated)
  const readinessPages = data.readiness
    ? paginateReadiness(data.readiness.questions)
    : [[]];
  readinessPages.forEach((page, i) => {
    slides.push({
      title: i === 0 ? 'Technical Readiness' : `Technical Readiness (${i + 1})`,
      render: (sn, ts) => (
        <SlideReadinessPage
          data={data}
          oppUrl={oppUrl}
          categories={page}
          pageIndex={i}
          totalPages={readinessPages.length}
          slideNumber={sn}
          totalSlides={ts}
        />
      ),
    });
  });

  // 6. Timeline
  slides.push({
    title: 'MAP Timeline',
    render: (sn, ts) => <SlideTimeline data={data} oppUrl={oppUrl} />,
  });

  // 7. Validation Tasks
  slides.push({
    title: 'Validation Tasks',
    render: (sn, ts) => <SlideValidationTasks data={data} oppUrl={oppUrl} />,
  });

  // 8. Risks
  slides.push({
    title: 'Risks & Issues',
    render: (sn, ts) => <SlideRisks data={data} oppUrl={oppUrl} />,
  });

  return slides;
}

export function EvaluationDeckViewer({
  opportunityId, accountId, accountName, opportunityName, onClose,
}: EvaluationDeckViewerProps) {
  const { data, isLoading } = useEvaluationDeckData(opportunityId, accountId, accountName, opportunityName, true);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const slideRefs = useRef<(HTMLDivElement | null)[]>([]);
  const [isExporting, setIsExporting] = useState(false);

  const oppUrl = getOpportunityUrl(opportunityId);

  const slideList = useMemo(() => {
    if (!data) return [];
    return buildSlideList(data, oppUrl);
  }, [data, oppUrl]);

  const totalSlides = slideList.length;

  const goNext = () => setCurrentSlide(s => Math.min(s + 1, totalSlides - 1));
  const goPrev = () => setCurrentSlide(s => Math.max(s - 1, 0));

  const toggleFullscreen = () => {
    if (!isFullscreen) {
      containerRef.current?.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  React.useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  // Keyboard navigation
  React.useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') { e.preventDefault(); goNext(); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); goPrev(); }
      if (e.key === 'Escape' && isFullscreen) { document.exitFullscreen?.(); }
      if (e.key === 'Escape' && !isFullscreen) onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isFullscreen, totalSlides]);

  const exportPDF = async () => {
    if (!data) return;
    setIsExporting(true);
    try {
      const pdf = new jsPDF({ orientation: 'landscape', unit: 'px', format: [SLIDE_WIDTH, SLIDE_HEIGHT] });
      
      for (let i = 0; i < totalSlides; i++) {
        setCurrentSlide(i);
        await new Promise(r => setTimeout(r, 300));
        
        const slideEl = slideRefs.current[i];
        if (!slideEl) continue;
        
        const canvas = await html2canvas(slideEl, {
          width: SLIDE_WIDTH,
          height: SLIDE_HEIGHT,
          scale: 2,
          useCORS: true,
          backgroundColor: '#ffffff',
        });
        
        const imgData = canvas.toDataURL('image/png');
        if (i > 0) pdf.addPage([SLIDE_WIDTH, SLIDE_HEIGHT], 'landscape');
        pdf.addImage(imgData, 'PNG', 0, 0, SLIDE_WIDTH, SLIDE_HEIGHT);
      }
      
      pdf.save(`${accountName} - Evaluation Deck.pdf`);
    } catch (err) {
      console.error('PDF export failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const exportPPTX = async () => {
    if (!data) return;
    setIsExporting(true);
    try {
      const { generateEvaluationPPTX } = await import('@/lib/exportEvaluationDeck');
      await generateEvaluationPPTX(data, oppUrl);
    } catch (err) {
      console.error('PPTX export failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div 
      ref={containerRef}
      className={cn(
        "fixed inset-0 z-50 bg-black/95 flex flex-col",
        isFullscreen && "bg-black"
      )}
    >
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-black/80 border-b border-white/10">
        <div className="flex items-center gap-3">
          <img src={pendoLogo} alt="Pendo" className="h-6" />
          <span className="text-white/90 text-sm font-medium">
            {accountName} — Evaluation Deck
          </span>
          <Badge variant="outline" className="text-white/60 border-white/20 text-xs">
            {currentSlide + 1} / {totalSlides}
          </Badge>
        </div>

        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="ghost" className="text-white/80 hover:text-white hover:bg-white/10" disabled={isExporting}>
                <Download className="w-4 h-4 mr-1.5" />
                {isExporting ? 'Exporting...' : 'Export'}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={exportPPTX}>
                <FileSpreadsheet className="w-4 h-4 mr-2" />
                Download as PPTX
              </DropdownMenuItem>
              <DropdownMenuItem onClick={exportPDF}>
                <FileText className="w-4 h-4 mr-2" />
                Download as PDF
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button size="sm" variant="ghost" className="text-white/80 hover:text-white hover:bg-white/10" onClick={toggleFullscreen}>
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </Button>

          <Button size="sm" variant="ghost" className="text-white/80 hover:text-white hover:bg-white/10" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Slide area */}
      <div className="flex-1 flex items-center justify-center relative overflow-hidden">
        {isLoading ? (
          <div className="flex flex-col items-center gap-4">
            <Skeleton className="w-[960px] h-[540px] bg-white/10" />
            <p className="text-white/60 text-sm">Loading deck data...</p>
          </div>
        ) : (
          <>
            {/* Navigation arrows */}
            <button
              onClick={goPrev}
              disabled={currentSlide === 0}
              className="absolute left-4 z-10 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white disabled:opacity-20 transition-all"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <button
              onClick={goNext}
              disabled={currentSlide === totalSlides - 1}
              className="absolute right-4 z-10 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white disabled:opacity-20 transition-all"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Slide container with scaling */}
            <div className="relative" style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <ScaledSlide slideRef={(el) => { slideRefs.current[currentSlide] = el; }}>
                {slideList[currentSlide]?.render(currentSlide + 1, totalSlides)}
              </ScaledSlide>
            </div>
          </>
        )}
      </div>

      {/* Bottom thumbnail strip */}
      <div className="flex items-center gap-2 px-4 py-2 bg-black/80 border-t border-white/10 overflow-x-auto">
        {slideList.map((slide, i) => (
          <button
            key={i}
            onClick={() => setCurrentSlide(i)}
            className={cn(
              "flex-shrink-0 px-3 py-1.5 rounded text-xs transition-all",
              i === currentSlide
                ? "bg-primary text-white"
                : "bg-white/10 text-white/60 hover:bg-white/20 hover:text-white/80"
            )}
          >
            {i + 1}. {slide.title}
          </button>
        ))}
      </div>
    </div>
  );
}

// Scaled slide container - renders at 1920x1080 and scales to fit
function ScaledSlide({ children, slideRef }: { children: React.ReactNode; slideRef: (el: HTMLDivElement | null) => void }) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(0.5);

  React.useEffect(() => {
    const updateScale = () => {
      if (!wrapperRef.current) return;
      const parent = wrapperRef.current.parentElement;
      if (!parent) return;
      const scaleX = (parent.clientWidth - 120) / SLIDE_WIDTH;
      const scaleY = (parent.clientHeight - 40) / SLIDE_HEIGHT;
      setScale(Math.min(scaleX, scaleY, 1));
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    const observer = new ResizeObserver(updateScale);
    if (wrapperRef.current?.parentElement) observer.observe(wrapperRef.current.parentElement);
    return () => { window.removeEventListener('resize', updateScale); observer.disconnect(); };
  }, []);

  return (
    <div ref={wrapperRef} className="flex items-center justify-center" style={{ width: '100%', height: '100%' }}>
      <div
        ref={slideRef}
        className="bg-white rounded-lg shadow-2xl overflow-hidden"
        style={{
          width: SLIDE_WIDTH,
          height: SLIDE_HEIGHT,
          transform: `scale(${scale})`,
          transformOrigin: 'center center',
          flexShrink: 0,
        }}
      >
        {children}
      </div>
    </div>
  );
}

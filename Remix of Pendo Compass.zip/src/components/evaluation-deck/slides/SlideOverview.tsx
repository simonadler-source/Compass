import React from 'react';
import { type EvaluationDeckData } from '@/hooks/useEvaluationDeckData';
import pendoLogo from '@/assets/pendo-logo.png';

interface SlideProps {
  data: EvaluationDeckData;
  oppUrl: string;
}

export function SlideOverview({ data, oppUrl }: SlideProps) {
  const painPoints = data.painPoints.slice(0, 6);
  const useCases = data.useCases.slice(0, 6);

  return (
    <div className="w-full h-full flex flex-col" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* Header */}
      <div className="px-16 pt-12 pb-6 flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #1B2A4A 0%, #2D3E5F 100%)' }}>
        <div>
          <h1 className="text-[48px] font-bold text-white leading-tight">{data.accountName}</h1>
          <p className="text-[24px] text-white/70 mt-1">Evaluation Overview</p>
        </div>
        <img src={pendoLogo} alt="Pendo" className="h-12 opacity-90" />
      </div>

      {/* Executive summary */}
      <div className="px-16 py-8 flex-1 flex flex-col gap-8">
        {data.customerSynopsis && (
          <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100">
            <h2 className="text-[22px] font-bold text-gray-800 mb-3">Executive Synopsis</h2>
            <p className="text-[17px] text-gray-600 leading-relaxed">{data.customerSynopsis}</p>
          </div>
        )}

        {/* Current vs Future State */}
        <div className="flex-1 grid grid-cols-2 gap-8">
          {/* Current State */}
          <div className="bg-red-50/60 rounded-2xl p-8 border border-red-100">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center">
                <span className="text-red-500 text-[18px]">✕</span>
              </div>
              <h3 className="text-[20px] font-bold text-gray-800">Current State — Challenges</h3>
            </div>
            <ul className="space-y-3">
              {painPoints.map((pp, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="text-red-400 mt-1 text-[16px]">✕</span>
                  <span className="text-[16px] text-gray-700 leading-snug">{pp.pain_point}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Future State */}
          <div className="bg-emerald-50/60 rounded-2xl p-8 border border-emerald-100">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center">
                <span className="text-emerald-500 text-[18px]">✓</span>
              </div>
              <h3 className="text-[20px] font-bold text-gray-800">Future State — Potential Outcomes</h3>
            </div>
            <ul className="space-y-3">
              {useCases.map((uc, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="text-emerald-500 mt-1 text-[16px]">✓</span>
                  <span className="text-[16px] text-gray-700 leading-snug">{uc.use_case || uc.functional_area}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Footer */}
      <SlideFooter oppUrl={oppUrl} slideNumber={1} totalSlides={8} />
    </div>
  );
}

export function SlideFooter({ oppUrl, slideNumber, totalSlides }: { oppUrl: string; slideNumber: number; totalSlides: number }) {
  return (
    <div className="px-16 py-4 flex items-center justify-between border-t border-gray-200 bg-gray-50/50">
      <span className="text-[13px] text-gray-400">
        <a href={oppUrl} className="text-blue-400 hover:underline">{oppUrl}</a>
      </span>
      <span className="text-[13px] text-gray-400 font-medium">{slideNumber} / {totalSlides}</span>
    </div>
  );
}

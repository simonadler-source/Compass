import React from 'react';
import { type EvaluationDeckData, type ReadinessQuestionDetail, type ReadinessSummary } from '@/hooks/useEvaluationDeckData';
import { SlideFooter } from './SlideOverview';
import pendoLogo from '@/assets/pendo-logo.png';

interface SlideProps {
  data: EvaluationDeckData;
  oppUrl: string;
  slideNumber: number;
  totalSlides: number;
}

const FLAG_STYLES: Record<string, { dot: string; bg: string; border: string }> = {
  green: { dot: '#16A34A', bg: '#F0FDF4', border: '#BBF7D0' },
  amber: { dot: '#F59E0B', bg: '#FFFBEB', border: '#FDE68A' },
  red: { dot: '#DC2626', bg: '#FEF2F2', border: '#FECACA' },
};

function FlagDot({ type }: { type: string }) {
  const color = FLAG_STYLES[type]?.dot || '#9CA3AF';
  return (
    <span
      className="inline-block w-3 h-3 rounded-full flex-shrink-0"
      style={{ backgroundColor: color }}
    />
  );
}

interface CategoryGroup {
  name: string;
  questions: ReadinessQuestionDetail[];
}

/**
 * Paginate readiness questions into slides, preserving category groupings.
 * Each page holds roughly 12-14 question rows.
 */
export function paginateReadiness(questions: ReadinessQuestionDetail[]): CategoryGroup[][] {
  // Group by category
  const byCategory: Record<string, ReadinessQuestionDetail[]> = {};
  questions.forEach(q => {
    const cat = q.categoryName || 'General';
    if (!byCategory[cat]) byCategory[cat] = [];
    byCategory[cat].push(q);
  });
  const categories: CategoryGroup[] = Object.entries(byCategory).map(([name, qs]) => ({ name, questions: qs }));

  if (categories.length === 0) return [[]];

  // With 2 columns, we can fit ~28 question rows per page
  const MAX_ROWS = 28;
  const pages: CategoryGroup[][] = [];
  let currentPage: CategoryGroup[] = [];
  let currentRows = 0;

  for (const cat of categories) {
    const catRows = cat.questions.length + 1; // +1 for header
    if (currentRows > 0 && currentRows + catRows > MAX_ROWS) {
      if (catRows <= MAX_ROWS) {
        pages.push(currentPage);
        currentPage = [cat];
        currentRows = catRows;
      } else {
        pages.push(currentPage);
        let remaining = [...cat.questions];
        while (remaining.length > 0) {
          const chunk = remaining.slice(0, MAX_ROWS - 1);
          remaining = remaining.slice(MAX_ROWS - 1);
          currentPage = [{ name: cat.name, questions: chunk }];
          if (remaining.length > 0) {
            pages.push(currentPage);
            currentPage = [];
            currentRows = 0;
          } else {
            currentRows = chunk.length + 1;
          }
        }
      }
    } else {
      currentPage.push(cat);
      currentRows += catRows;
    }
  }
  if (currentPage.length > 0) pages.push(currentPage);
  return pages;
}

export function SlideReadiness({ data, oppUrl, slideNumber, totalSlides }: SlideProps) {
  return <SlideReadinessPage data={data} oppUrl={oppUrl} categories={[]} pageIndex={0} totalPages={1} slideNumber={slideNumber} totalSlides={totalSlides} />;
}

interface PageProps {
  data: EvaluationDeckData;
  oppUrl: string;
  categories: CategoryGroup[];
  pageIndex: number;
  totalPages: number;
  slideNumber: number;
  totalSlides: number;
}

function countAllRows(cats: CategoryGroup[]): number {
  return cats.reduce((sum, c) => sum + c.questions.length + 1, 0); // +1 per category header
}

export function SlideReadinessPage({ data, oppUrl, categories, pageIndex, slideNumber, totalSlides }: PageProps) {
  const r = data.readiness;
  const continued = pageIndex > 0;

  if (!r) {
    return (
      <div className="w-full h-full flex flex-col" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
        <div className="px-16 pt-10 pb-5 flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #1B2A4A 0%, #2D3E5F 100%)' }}>
          <div>
            <h1 className="text-[42px] font-bold text-white">Technical Readiness</h1>
            <p className="text-[20px] text-white/60 mt-1">{data.accountName}</p>
          </div>
          <img src={pendoLogo} alt="Pendo" className="h-10 opacity-90" />
        </div>
        <div className="flex-1 flex items-center justify-center">
          <p className="text-[24px] text-gray-400">No readiness data available</p>
        </div>
        <SlideFooter oppUrl={oppUrl} slideNumber={slideNumber} totalSlides={totalSlides} />
      </div>
    );
  }

  return (
    <div className="w-full h-full flex flex-col" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* Header */}
      <div className="px-16 pt-8 pb-4 flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #1B2A4A 0%, #2D3E5F 100%)' }}>
        <div>
          <h1 className="text-[36px] font-bold text-white">
            Technical Readiness{continued ? ' (continued)' : ''}
          </h1>
          <p className="text-[18px] text-white/60 mt-1">{data.accountName}</p>
        </div>
        <img src={pendoLogo} alt="Pendo" className="h-10 opacity-90" />
      </div>

      {/* Score bar */}
      <div className="px-16 py-4 flex items-center gap-8 border-b" style={{ borderColor: '#e5e7eb', backgroundColor: '#f9fafb' }}>
        <div className="flex items-center gap-3">
          <span
            className="text-[36px] font-bold"
            style={{ color: r.score >= 70 ? '#16A34A' : r.score >= 40 ? '#F59E0B' : '#DC2626' }}
          >
            {r.score}%
          </span>
          <span className="text-[14px] text-gray-500">
            {r.answered}/{r.total} answered
            {r.excluded > 0 ? ` · ${r.excluded} excluded` : ''}
          </span>
        </div>
        <div className="flex items-center gap-4 ml-auto">
          <span className="flex items-center gap-1.5 text-[13px] font-medium"><FlagDot type="green" /> {r.greenCount} Green</span>
          <span className="flex items-center gap-1.5 text-[13px] font-medium"><FlagDot type="amber" /> {r.amberCount} Amber</span>
          <span className="flex items-center gap-1.5 text-[13px] font-medium"><FlagDot type="red" /> {r.redCount} Red</span>
        </div>
      </div>

      {/* Question list by category — 2 columns */}
      <div className="flex-1 px-10 py-4 overflow-hidden">
        <div className="grid grid-cols-2 gap-x-6 gap-y-0 h-full" style={{ gridAutoFlow: 'column', gridTemplateRows: `repeat(${Math.ceil(countAllRows(categories) / 2)}, auto)` }}>
          {categories.flatMap((cat) => [
            <div key={`hdr-${cat.name}`} className="pt-3 pb-1">
              <h4 className="text-[13px] font-bold text-gray-700 uppercase tracking-wide">{cat.name}</h4>
            </div>,
            ...cat.questions.map((q, qi) => {
              const style = FLAG_STYLES[q.flagType] || FLAG_STYLES.red;
              return (
                <div
                  key={`q-${cat.name}-${qi}`}
                  className="flex items-start gap-2.5 px-3 py-2 border-b"
                  style={{
                    backgroundColor: qi % 2 === 0 ? style.bg : '#ffffff',
                    borderColor: '#e5e7eb',
                  }}
                >
                  <FlagDot type={q.flagType} />
                  <div className="flex-1 min-w-0">
                    <p className="text-[12px] font-semibold text-gray-800 leading-tight">{q.questionText}</p>
                    {q.answer && (
                      <p className="text-[11px] text-gray-500 leading-snug mt-0.5 line-clamp-2">{q.answer}</p>
                    )}
                  </div>
                </div>
              );
            }),
          ])}
        </div>
      </div>

      <SlideFooter oppUrl={oppUrl} slideNumber={slideNumber} totalSlides={totalSlides} />
    </div>
  );
}

import React from 'react';
import { type EvaluationDeckData } from '@/hooks/useEvaluationDeckData';
import { SlideFooter } from './SlideOverview';
import pendoLogo from '@/assets/pendo-logo.png';

interface SlideProps {
  data: EvaluationDeckData;
  oppUrl: string;
}

const severityColors: Record<string, { bg: string; border: string; text: string; label: string }> = {
  critical: { bg: '#FEE2E2', border: '#FECACA', text: '#991B1B', label: 'Critical' },
  high: { bg: '#FFF7ED', border: '#FED7AA', text: '#9A3412', label: 'High' },
  medium: { bg: '#FFFBEB', border: '#FDE68A', text: '#92400E', label: 'Medium' },
  low: { bg: '#EFF6FF', border: '#BFDBFE', text: '#1E40AF', label: 'Low' },
};

const statusLabels: Record<string, string> = {
  new: 'New',
  in_review: 'In Review',
  awaiting_feedback: 'Awaiting Feedback',
  mitigated: 'Mitigated',
  accepted: 'Accepted',
  closed: 'Closed',
};

export function SlideRisks({ data, oppUrl }: SlideProps) {
  const risks = data.risks;

  return (
    <div className="w-full h-full flex flex-col" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <div className="px-16 pt-10 pb-5 flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #1B2A4A 0%, #2D3E5F 100%)' }}>
        <div>
          <h1 className="text-[42px] font-bold text-white">Risks & Issues</h1>
          <p className="text-[20px] text-white/60 mt-1">{data.accountName} — {risks.length} logged</p>
        </div>
        <img src={pendoLogo} alt="Pendo" className="h-10 opacity-90" />
      </div>

      <div className="flex-1 px-16 py-8 overflow-hidden">
        {risks.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full">
            <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-4">
              <span className="text-[32px]">🛡️</span>
            </div>
            <p className="text-[24px] text-gray-400">No risks or issues logged yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {risks.slice(0, 6).map((risk, i) => {
              const sev = severityColors[risk.severity] || severityColors.medium;
              return (
                <div key={i} className="rounded-xl p-5 border" style={{ backgroundColor: sev.bg, borderColor: sev.border }}>
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <h3 className="text-[17px] font-semibold text-gray-800 flex-1">{risk.risk_description}</h3>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="px-2 py-0.5 rounded text-[12px] font-medium" style={{ backgroundColor: `${sev.text}20`, color: sev.text }}>
                        {sev.label}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[12px] font-medium bg-gray-100 text-gray-600">
                        {statusLabels[risk.status] || risk.status}
                      </span>
                    </div>
                  </div>
                  {risk.mitigation_plan && (
                    <p className="text-[14px] text-gray-600 mt-2"><span className="font-medium">Mitigation:</span> {risk.mitigation_plan}</p>
                  )}
                  {risk.owner_email && (
                    <p className="text-[13px] text-gray-400 mt-1">Owner: {risk.owner_email}</p>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <SlideFooter oppUrl={oppUrl} slideNumber={8} totalSlides={8} />
    </div>
  );
}

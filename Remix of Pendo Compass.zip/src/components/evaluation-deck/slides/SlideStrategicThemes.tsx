import React from 'react';
import { type EvaluationDeckData } from '@/hooks/useEvaluationDeckData';
import { SlideFooter } from './SlideOverview';
import pendoLogo from '@/assets/pendo-logo.png';

interface SlideProps {
  data: EvaluationDeckData;
  oppUrl: string;
}

const impactBadgeColors: Record<string, string> = {
  critical: 'bg-red-100 text-red-700 border-red-200',
  high: 'bg-orange-100 text-orange-700 border-orange-200',
  medium: 'bg-amber-100 text-amber-700 border-amber-200',
  low: 'bg-gray-100 text-gray-600 border-gray-200',
};

export function SlideStrategicThemes({ data, oppUrl }: SlideProps) {
  // Use opportunity-level themes if available, otherwise account-level
  const challenges = data.opportunityChallenges.length > 0 ? data.opportunityChallenges : data.strategicChallenges;
  const initiatives = data.opportunityInitiatives.length > 0 ? data.opportunityInitiatives : data.strategicInitiatives;

  return (
    <div className="w-full h-full flex flex-col" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* Header */}
      <div className="px-16 pt-10 pb-5 flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #1B2A4A 0%, #2D3E5F 100%)' }}>
        <div>
          <h1 className="text-[42px] font-bold text-white">Strategic Themes</h1>
          <p className="text-[20px] text-white/60 mt-1">{data.accountName}</p>
        </div>
        <img src={pendoLogo} alt="Pendo" className="h-10 opacity-90" />
      </div>

      {/* Content - two columns */}
      <div className="flex-1 px-16 py-8 grid grid-cols-2 gap-10">
        {/* Challenges */}
        <div>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center">
              <span className="text-amber-600 text-[18px]">⚠</span>
            </div>
            <h2 className="text-[24px] font-bold text-gray-800">Strategic Challenges</h2>
            <span className="text-[16px] text-gray-400 font-medium">({challenges.length})</span>
          </div>
          <div className="space-y-4">
            {challenges.slice(0, 4).map((theme, i) => (
              <ThemeCard key={i} theme={theme} />
            ))}
          </div>
        </div>

        {/* Initiatives */}
        <div>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
              <span className="text-blue-600 text-[18px]">💡</span>
            </div>
            <h2 className="text-[24px] font-bold text-gray-800">Strategic Initiatives</h2>
            <span className="text-[16px] text-gray-400 font-medium">({initiatives.length})</span>
          </div>
          <div className="space-y-4">
            {initiatives.slice(0, 4).map((theme, i) => (
              <ThemeCard key={i} theme={theme} isInitiative />
            ))}
          </div>
        </div>
      </div>

      <SlideFooter oppUrl={oppUrl} slideNumber={2} totalSlides={8} />
    </div>
  );
}

function ThemeCard({ theme, isInitiative }: { theme: any; isInitiative?: boolean }) {
  const impact = theme.impact_level || 'medium';
  return (
    <div className={`rounded-xl p-5 border ${isInitiative ? 'bg-blue-50/50 border-blue-100' : 'bg-amber-50/50 border-amber-100'}`}>
      <div className="flex items-start justify-between gap-3 mb-2">
        <h3 className="text-[17px] font-semibold text-gray-800 leading-snug">{theme.theme_name}</h3>
        <span className={`px-2 py-0.5 rounded text-[12px] font-medium border ${impactBadgeColors[impact] || impactBadgeColors.medium}`}>
          {impact}
        </span>
      </div>
      <p className="text-[14px] text-gray-600 leading-relaxed line-clamp-2">{theme.description}</p>
      {theme.supporting_evidence && theme.supporting_evidence.length > 0 && (
        <div className="mt-3 space-y-1">
          {(theme.supporting_evidence as string[]).slice(0, 2).map((ev, i) => (
            <p key={i} className="text-[13px] text-gray-500 flex items-start gap-2">
              <span className="text-gray-300 mt-0.5">›</span>
              <span className="line-clamp-1">{ev}</span>
            </p>
          ))}
        </div>
      )}
    </div>
  );
}

import React from 'react';
import { type EvaluationDeckData, type SuccessCriterionDeck } from '@/hooks/useEvaluationDeckData';
import { SlideFooter } from './SlideOverview';
import pendoLogo from '@/assets/pendo-logo.png';

interface SlideProps {
  data: EvaluationDeckData;
  oppUrl: string;
  slideNumber: number;
  totalSlides: number;
}

const statusColors: Record<string, { bg: string; text: string; label: string; dot: string }> = {
  new: { bg: 'bg-gray-100', text: 'text-gray-600', label: 'New', dot: 'bg-gray-400' },
  in_review: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'In Review', dot: 'bg-blue-500' },
  awaiting_feedback: { bg: 'bg-orange-100', text: 'text-orange-700', label: 'Awaiting Feedback', dot: 'bg-orange-500' },
  met: { bg: 'bg-emerald-100', text: 'text-emerald-700', label: 'Met', dot: 'bg-emerald-500' },
  at_risk: { bg: 'bg-red-100', text: 'text-red-700', label: 'At Risk', dot: 'bg-red-500' },
  not_met: { bg: 'bg-red-100', text: 'text-red-700', label: 'Not Met', dot: 'bg-red-500' },
  closed: { bg: 'bg-gray-100', text: 'text-gray-500', label: 'Closed', dot: 'bg-gray-400' },
  proposed: { bg: 'bg-violet-100', text: 'text-violet-700', label: 'AI Proposed', dot: 'bg-violet-500' },
};

/**
 * Paginate criteria into slides. Each page fits ~4 criteria with full deliverables.
 */
export function paginateSuccessCriteria(criteria: SuccessCriterionDeck[]): SuccessCriterionDeck[][] {
  if (criteria.length === 0) return [[]];
  const pages: SuccessCriterionDeck[][] = [];
  let current: SuccessCriterionDeck[] = [];
  let heightBudget = 0;
  // Approximate row heights (at 1080p): header+summary ~200px, footer ~50px → ~830px content
  // Each criterion card: ~100px base + ~20px per deliverable row (3 per row)
  const MAX_HEIGHT = 780;

  for (const c of criteria) {
    const deliverableRows = Math.ceil(c.deliverables.length / 3);
    const cardHeight = 110 + (c.notes ? 20 : 0) + (deliverableRows * 24);
    if (current.length > 0 && heightBudget + cardHeight > MAX_HEIGHT) {
      pages.push(current);
      current = [];
      heightBudget = 0;
    }
    current.push(c);
    heightBudget += cardHeight;
  }
  if (current.length > 0) pages.push(current);
  return pages;
}

export function SlideSuccessCriteria({ data, oppUrl, slideNumber, totalSlides }: SlideProps) {
  return <SlideSuccessCriteriaPage data={data} oppUrl={oppUrl} criteria={data.successCriteria} pageIndex={0} totalPages={1} slideNumber={slideNumber} totalSlides={totalSlides} />;
}

interface PageProps {
  data: EvaluationDeckData;
  oppUrl: string;
  criteria: SuccessCriterionDeck[];
  pageIndex: number;
  totalPages: number;
  slideNumber: number;
  totalSlides: number;
}

export function SlideSuccessCriteriaPage({ data, oppUrl, criteria: pageCriteria, pageIndex, totalPages, slideNumber, totalSlides }: PageProps) {
  const allCriteria = data.successCriteria;
  const metCount = allCriteria.filter(c => c.status === 'met').length;
  const atRiskCount = allCriteria.filter(c => c.status === 'at_risk' || c.status === 'not_met').length;
  const inProgressCount = allCriteria.filter(c => c.status === 'in_review' || c.status === 'awaiting_feedback').length;
  const newCount = allCriteria.length - metCount - inProgressCount - atRiskCount;
  const totalDeliverables = allCriteria.reduce((sum, c) => sum + c.deliverables.length, 0);
  const completedDeliverables = allCriteria.reduce((sum, c) => sum + c.deliverables.filter(d => d.is_completed).length, 0);
  const continued = pageIndex > 0;

  return (
    <div className="w-full h-full flex flex-col" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* Header */}
      <div className="px-16 pt-8 pb-4 flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #1B2A4A 0%, #2D3E5F 100%)' }}>
        <div>
          <h1 className="text-[38px] font-bold text-white">
            Success Criteria{continued ? ' (continued)' : ''}
          </h1>
          <p className="text-[18px] text-white/60 mt-1">{data.accountName}</p>
        </div>
        <img src={pendoLogo} alt="Pendo" className="h-10 opacity-90" />
      </div>

      {/* Summary bar */}
      <div className="px-16 py-3 flex items-center gap-6 border-b" style={{ borderColor: '#e5e7eb', backgroundColor: '#f9fafb' }}>
        <StatPill color="bg-emerald-500" label="Met" value={metCount} />
        <StatPill color="bg-blue-500" label="In Progress" value={inProgressCount} />
        <StatPill color="bg-red-500" label="At Risk" value={atRiskCount} />
        <StatPill color="bg-gray-400" label="New" value={newCount} />
        <div className="ml-auto flex items-center gap-2">
          <span className="text-[13px] text-gray-500 font-medium">
            Deliverables: {completedDeliverables}/{totalDeliverables}
          </span>
          <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-emerald-500 rounded-full"
              style={{ width: `${totalDeliverables > 0 ? (completedDeliverables / totalDeliverables) * 100 : 0}%` }}
            />
          </div>
        </div>
      </div>

      {/* Criteria cards */}
      <div className="flex-1 px-16 py-4 overflow-hidden">
        <div className="space-y-3">
          {pageCriteria.map((c, i) => {
            const status = statusColors[c.status] || statusColors.new;
            const completedDel = c.deliverables.filter(d => d.is_completed).length;
            return (
              <div key={i} className="rounded-xl p-4 border" style={{ backgroundColor: '#fff', borderColor: '#e5e7eb' }}>
                <div className="flex items-start gap-4">
                  {/* Left: dot + text */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`w-3 h-3 rounded-full flex-shrink-0 ${status.dot}`} />
                      <h3 className="text-[16px] font-bold" style={{ color: statusTitleColor(c.status) }}>
                        {c.criterion}
                      </h3>
                    </div>
                    {c.notes && (
                      <p className="text-[13px] text-gray-500 leading-relaxed ml-[20px]">{c.notes}</p>
                    )}
                    <div className="ml-[20px] mt-1">
                      <span className="text-[12px] text-gray-400 font-medium">
                        Deliverables {completedDel}/{c.deliverables.length}
                      </span>
                    </div>
                  </div>

                  {/* Right: deliverables grid + status badge */}
                  <div className="flex items-start gap-4 flex-shrink-0" style={{ maxWidth: '60%' }}>
                    {c.deliverables.length > 0 && (
                      <div className="flex flex-wrap gap-x-4 gap-y-1">
                        {c.deliverables.map((d, di) => (
                          <div key={di} className="flex items-start gap-1.5" style={{ width: '220px' }}>
                            <span className={`w-4 h-4 rounded flex-shrink-0 flex items-center justify-center text-[10px] border mt-0.5 ${
                              d.is_completed 
                                ? 'bg-emerald-500 border-emerald-500 text-white' 
                                : 'bg-white border-gray-300 text-transparent'
                            }`}>
                              {d.is_completed ? '✓' : ''}
                            </span>
                            <span className={`text-[12px] leading-tight ${d.is_completed ? 'text-gray-400 line-through' : 'text-gray-600'}`}>
                              {d.title}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                    <span className={`px-3 py-1 rounded-full text-[12px] font-semibold flex-shrink-0 whitespace-nowrap ${status.bg} ${status.text}`}>
                      {status.label}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <SlideFooter oppUrl={oppUrl} slideNumber={slideNumber} totalSlides={totalSlides} />
    </div>
  );
}

function statusTitleColor(status: string): string {
  switch (status) {
    case 'met': return '#047857';
    case 'at_risk': case 'not_met': return '#DC2626';
    case 'in_review': case 'awaiting_feedback': return '#2563EB';
    default: return '#EC407A'; // pink for new/proposed
  }
}

function StatPill({ color, label, value }: { color: string; label: string; value: number }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className={`w-2.5 h-2.5 rounded-full ${color}`} />
      <span className="text-[13px] text-gray-600 font-medium">{value} {label}</span>
    </div>
  );
}

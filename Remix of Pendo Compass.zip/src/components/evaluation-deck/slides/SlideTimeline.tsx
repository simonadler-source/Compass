import React from 'react';
import { type EvaluationDeckData } from '@/hooks/useEvaluationDeckData';
import { SlideFooter } from './SlideOverview';
import { format } from 'date-fns';
import pendoLogo from '@/assets/pendo-logo.png';

interface SlideProps {
  data: EvaluationDeckData;
  oppUrl: string;
}

const phaseColors: Record<string, { bg: string; border: string; text: string }> = {
  'Value Discovery': { bg: '#FFF7ED', border: '#FDBA74', text: '#C2410C' },
  'Eval Planning': { bg: '#FEFCE8', border: '#FDE047', text: '#A16207' },
  'Eval Deployment': { bg: '#F0FDFA', border: '#5EEAD4', text: '#0F766E' },
  'Eval Workshops': { bg: '#FFF1F2', border: '#FDA4AF', text: '#BE123C' },
  'Conclusion': { bg: '#EFF6FF', border: '#93C5FD', text: '#1D4ED8' },
  'Procurement & Contracting': { bg: '#FFFBEB', border: '#FCD34D', text: '#92400E' },
  'Go Live & Value Realization': { bg: '#F0FDF4', border: '#86EFAC', text: '#166534' },
};

const statusIcons: Record<string, string> = {
  completed: '✅',
  in_progress: '▶',
  scheduled: '📅',
  not_scheduled: '○',
  skipped: '⏭',
};

export function SlideTimeline({ data, oppUrl }: SlideProps) {
  const milestones = data.milestones;
  
  // Group by phase
  const grouped: Record<string, typeof milestones> = {};
  milestones.forEach(m => {
    if (!grouped[m.phase]) grouped[m.phase] = [];
    grouped[m.phase].push(m);
  });

  return (
    <div className="w-full h-full flex flex-col" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <div className="px-16 pt-10 pb-5 flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #1B2A4A 0%, #2D3E5F 100%)' }}>
        <div>
          <h1 className="text-[42px] font-bold text-white">Mutual Action Plan Timeline</h1>
          <p className="text-[20px] text-white/60 mt-1">{data.accountName}</p>
        </div>
        <img src={pendoLogo} alt="Pendo" className="h-10 opacity-90" />
      </div>

      <div className="flex-1 px-16 py-6 overflow-hidden">
        <div className="space-y-4">
          {Object.entries(grouped).slice(0, 6).map(([phase, items]) => {
            const colors = phaseColors[phase] || phaseColors['Conclusion'];
            const completed = items.filter(m => m.status === 'completed').length;
            return (
              <div key={phase}>
                <div className="flex items-center justify-between mb-2 px-3 py-2 rounded-lg" style={{ backgroundColor: colors.bg, borderLeft: `4px solid ${colors.border}` }}>
                  <span className="text-[17px] font-bold" style={{ color: colors.text }}>{phase}</span>
                  <span className="text-[14px] font-medium" style={{ color: colors.text }}>{completed} / {items.length}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 ml-4">
                  {items.slice(0, 4).map((m, i) => (
                    <div key={i} className="flex items-center gap-3 py-2 px-3 bg-white rounded-lg border border-gray-100">
                      <span className="text-[14px]">{statusIcons[m.status] || '○'}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-[14px] font-medium text-gray-800 truncate">{m.name}</p>
                      </div>
                      {m.scheduled_date && (
                        <span className="text-[12px] text-gray-400 flex-shrink-0">
                          {format(new Date(m.scheduled_date), 'MMM d')}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <SlideFooter oppUrl={oppUrl} slideNumber={6} totalSlides={8} />
    </div>
  );
}

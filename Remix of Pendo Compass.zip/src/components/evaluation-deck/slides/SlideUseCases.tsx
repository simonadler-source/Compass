import React from 'react';
import { type EvaluationDeckData } from '@/hooks/useEvaluationDeckData';
import { SlideFooter } from './SlideOverview';
import pendoLogo from '@/assets/pendo-logo.png';

interface SlideProps {
  data: EvaluationDeckData;
  oppUrl: string;
}

const outcomeIcons: Record<string, string> = {
  'Increase Revenue': '📈',
  'Cut Costs': '✂️',
  'Reduce Risk': '🛡️',
  'Improve Experience': '✨',
  'Drive Efficiency': '⚡',
};

const priorityBadge: Record<string, { bg: string; text: string }> = {
  high: { bg: 'bg-red-100', text: 'text-red-700' },
  medium: { bg: 'bg-amber-100', text: 'text-amber-700' },
  low: { bg: 'bg-gray-100', text: 'text-gray-500' },
};

const statusBadge: Record<string, { bg: string; text: string; label: string }> = {
  identified: { bg: 'bg-blue-50', text: 'text-blue-600', label: 'Identified' },
  validated: { bg: 'bg-emerald-50', text: 'text-emerald-700', label: 'Validated' },
  accepted: { bg: 'bg-emerald-100', text: 'text-emerald-700', label: 'Accepted' },
  proposed: { bg: 'bg-violet-50', text: 'text-violet-600', label: 'Proposed' },
  rejected: { bg: 'bg-red-50', text: 'text-red-600', label: 'Rejected' },
};

export function SlideUseCases({ data, oppUrl }: SlideProps) {
  const useCases = data.useCases;
  
  // Group by business_outcome
  const grouped: Record<string, typeof useCases> = {};
  useCases.forEach(uc => {
    const outcome = (uc as any).business_outcome || 'Other';
    if (!grouped[outcome]) grouped[outcome] = [];
    grouped[outcome].push(uc);
  });

  // Calculate total slots available to decide layout density
  const totalUCs = useCases.length;
  const compact = totalUCs > 8;

  return (
    <div className="w-full h-full flex flex-col" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <div className="px-16 pt-10 pb-5 flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #1B2A4A 0%, #2D3E5F 100%)' }}>
        <div>
          <h1 className="text-[42px] font-bold text-white">Evaluation Use Cases</h1>
          <p className="text-[20px] text-white/60 mt-1">{data.accountName} — {useCases.length} use cases</p>
        </div>
        <img src={pendoLogo} alt="Pendo" className="h-10 opacity-90" />
      </div>

      <div className="flex-1 px-16 py-5 overflow-hidden">
        <div className="space-y-4">
          {Object.entries(grouped).slice(0, 5).map(([outcome, ucs]) => (
            <div key={outcome}>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[18px]">{outcomeIcons[outcome] || '💡'}</span>
                <h3 className="text-[18px] font-bold" style={{ color: '#EC407A' }}>{outcome}</h3>
                <span className="text-[14px] text-gray-400 font-medium">{ucs.length}</span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {ucs.slice(0, 4).map((uc, i) => {
                  const ucAny = uc as any;
                  const prio = priorityBadge[ucAny.priority || ''] || null;
                  const stat = statusBadge[ucAny.status || ''] || null;
                  // Use decrypted use_case as title; exclude encrypted-looking strings
                  const rawTitle = uc.use_case || '';
                  const isEncrypted = !rawTitle || rawTitle.includes('/') && rawTitle.length > 40 && !rawTitle.includes(' ');
                  const title = isEncrypted ? (ucAny.solution_description || 'Untitled Use Case') : rawTitle;
                  // Only show description if it's different from the title
                  const rawDesc = ucAny.description || ucAny.solution_description || null;
                  const desc = rawDesc && rawDesc !== title ? rawDesc : null;

                  return (
                    <div key={i} className="bg-blue-50/50 rounded-xl border border-blue-100 p-4 flex flex-col gap-1.5">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-[15px] font-semibold text-gray-800 leading-snug flex-1 line-clamp-2">{title}</h4>
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          {prio && (
                            <span className={`px-2 py-0.5 rounded text-[11px] font-semibold uppercase ${prio.bg} ${prio.text}`}>
                              {ucAny.priority}
                            </span>
                          )}
                          {stat && (
                            <span className={`px-2 py-0.5 rounded text-[11px] font-medium ${stat.bg} ${stat.text}`}>
                              {stat.label}
                            </span>
                          )}
                        </div>
                      </div>
                      {desc && !compact && (
                        <p className="text-[12px] text-gray-500 leading-relaxed line-clamp-2">{desc}</p>
                      )}
                      <div className="flex items-center gap-2 mt-auto">
                        {uc.functional_area && (
                          <span className="inline-block px-2 py-0.5 rounded bg-gray-100 text-[11px] text-gray-600 font-medium">
                            {uc.functional_area}
                          </span>
                        )}
                        {ucAny.business_theme && ucAny.business_theme !== outcome && (
                          <span className="inline-block px-2 py-0.5 rounded bg-pink-50 text-[11px] text-pink-600 font-medium">
                            {ucAny.business_theme}
                          </span>
                        )}
                        {ucAny.confidence_score != null && (
                          <span className="text-[11px] text-gray-400 ml-auto">
                            {Math.round(ucAny.confidence_score * 100)}% conf
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              {ucs.length > 4 && (
                <p className="text-[12px] text-gray-400 mt-1 ml-1">+ {ucs.length - 4} more</p>
              )}
            </div>
          ))}
        </div>
      </div>

      <SlideFooter oppUrl={oppUrl} slideNumber={3} totalSlides={8} />
    </div>
  );
}
import React from 'react';
import { type EvaluationDeckData } from '@/hooks/useEvaluationDeckData';
import { SlideFooter } from './SlideOverview';
import pendoLogo from '@/assets/pendo-logo.png';

interface SlideProps {
  data: EvaluationDeckData;
  oppUrl: string;
}

const statusColors: Record<string, { bg: string; text: string; label: string }> = {
  not_started: { bg: 'bg-gray-100', text: 'text-gray-600', label: 'Not Started' },
  in_progress: { bg: 'bg-amber-100', text: 'text-amber-700', label: 'In Progress' },
  completed: { bg: 'bg-emerald-100', text: 'text-emerald-700', label: 'Completed' },
  blocked: { bg: 'bg-red-100', text: 'text-red-700', label: 'Blocked' },
  skipped: { bg: 'bg-gray-100', text: 'text-gray-500', label: 'Skipped' },
};

export function SlideValidationTasks({ data, oppUrl }: SlideProps) {
  const tasks = data.validationTasks;
  const completed = tasks.filter(t => t.status === 'completed').length;
  const inProgress = tasks.filter(t => t.status === 'in_progress').length;
  const blocked = tasks.filter(t => t.status === 'blocked').length;
  
  // Group by module
  const grouped: Record<string, typeof tasks> = {};
  tasks.forEach(t => {
    if (!grouped[t.module]) grouped[t.module] = [];
    grouped[t.module].push(t);
  });

  return (
    <div className="w-full h-full flex flex-col" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <div className="px-16 pt-10 pb-5 flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #1B2A4A 0%, #2D3E5F 100%)' }}>
        <div>
          <h1 className="text-[42px] font-bold text-white">Validation Tasks</h1>
          <p className="text-[20px] text-white/60 mt-1">{data.accountName}</p>
        </div>
        <img src={pendoLogo} alt="Pendo" className="h-10 opacity-90" />
      </div>

      <div className="flex-1 px-16 py-6 overflow-hidden">
        {/* KPI row */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <KPICard label="Total Tasks" value={tasks.length} color="#1E293B" />
          <KPICard label="Completed" value={completed} color="#16A34A" />
          <KPICard label="In Progress" value={inProgress} color="#F59E0B" />
          <KPICard label="Blocked" value={blocked} color="#DC2626" />
        </div>

        {/* Progress bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[16px] font-semibold text-gray-700">Overall Progress</span>
            <span className="text-[14px] text-gray-500">{completed} of {tasks.length} completed</span>
          </div>
          <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${tasks.length > 0 ? (completed / tasks.length) * 100 : 0}%` }} />
          </div>
        </div>

        {/* Module breakdown */}
        <div className="grid grid-cols-2 gap-4">
          {Object.entries(grouped).slice(0, 6).map(([module, moduleTasks]) => {
            const moduleCompleted = moduleTasks.filter(t => t.status === 'completed').length;
            return (
              <div key={module} className="bg-gray-50 rounded-xl p-4 border border-gray-100">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-[15px] font-semibold text-gray-800">{module}</h3>
                  <span className="text-[13px] text-gray-400">{moduleCompleted}/{moduleTasks.length}</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${(moduleCompleted / moduleTasks.length) * 100}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <SlideFooter oppUrl={oppUrl} slideNumber={7} totalSlides={8} />
    </div>
  );
}

function KPICard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="bg-white rounded-xl p-5 border border-gray-200 shadow-sm text-center">
      <div className="text-[36px] font-bold" style={{ color }}>{value}</div>
      <p className="text-[14px] text-gray-500">{label}</p>
    </div>
  );
}

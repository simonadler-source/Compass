import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Zap, 
  AlertTriangle, 
  Activity, 
  TrendingDown,
  TrendingUp,
  ArrowRight,
  Clock,
  Filter,
  Building2,
  Target
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, isToday, isYesterday, isThisWeek, parseISO } from 'date-fns';
import type { HomeEvent, HomeNBA, HomeKPIs } from '@/hooks/useHomeData';

interface ActivityFeedViewProps {
  data: {
    events: HomeEvent[];
    nbas: HomeNBA[];
    kpis: HomeKPIs;
    isLoading: boolean;
  };
}

type EventFilter = 'all' | 'nba_due' | 'signal_detected' | 'stage_change' | 'sentiment_change' | 'stalled';

const EVENT_FILTERS: { value: EventFilter; label: string; icon: React.ElementType }[] = [
  { value: 'all', label: 'All', icon: Activity },
  { value: 'nba_due', label: 'Actions', icon: Zap },
  { value: 'signal_detected', label: 'Signals', icon: Activity },
  { value: 'stage_change', label: 'Stage Changes', icon: ArrowRight },
  { value: 'sentiment_change', label: 'Sentiment', icon: TrendingDown },
  { value: 'stalled', label: 'Stalled', icon: AlertTriangle },
];

export function ActivityFeedView({ data }: ActivityFeedViewProps) {
  const navigate = useNavigate();
  const { events, nbas, kpis, isLoading } = data;
  const [activeFilter, setActiveFilter] = useState<EventFilter>('all');

  // Filter events
  const filteredEvents = useMemo(() => {
    if (activeFilter === 'all') return events;
    return events.filter(e => e.type === activeFilter);
  }, [events, activeFilter]);

  // Group events by time period
  const groupedEvents = useMemo(() => {
    const groups: { label: string; events: HomeEvent[] }[] = [
      { label: 'Today', events: [] },
      { label: 'Yesterday', events: [] },
      { label: 'This Week', events: [] },
      { label: 'Earlier', events: [] },
    ];

    filteredEvents.forEach(event => {
      const date = parseISO(event.timestamp);
      if (isToday(date)) {
        groups[0].events.push(event);
      } else if (isYesterday(date)) {
        groups[1].events.push(event);
      } else if (isThisWeek(date)) {
        groups[2].events.push(event);
      } else {
        groups[3].events.push(event);
      }
    });

    return groups.filter(g => g.events.length > 0);
  }, [filteredEvents]);

  // Pinned items (overdue NBAs + critical alerts)
  const pinnedItems = useMemo(() => {
    return nbas
      .filter(n => n.is_overdue || n.priority === 'high')
      .slice(0, 5);
  }, [nbas]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="flex gap-6">
      {/* Main Feed */}
      <div className="flex-1 space-y-4">
        {/* Pinned Section */}
        {pinnedItems.length > 0 && (
          <Card className="bg-destructive/5 border-destructive/20">
            <CardHeader className="py-3">
              <CardTitle className="text-sm flex items-center gap-2 text-destructive">
                <AlertTriangle className="w-4 h-4" />
                Requires Immediate Attention
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {pinnedItems.map(nba => (
                  <PinnedNBAItem key={nba.id} nba={nba} />
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Event Feed */}
        <Card className="bg-card/50 backdrop-blur">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Activity Feed</CardTitle>
              <div className="flex items-center gap-1">
                {EVENT_FILTERS.map(filter => (
                  <Button
                    key={filter.value}
                    variant={activeFilter === filter.value ? 'default' : 'ghost'}
                    size="sm"
                    className="h-8 text-xs"
                    onClick={() => setActiveFilter(filter.value)}
                  >
                    <filter.icon className="w-3 h-3 mr-1" />
                    {filter.label}
                  </Button>
                ))}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-6">
                {groupedEvents.map(group => (
                  <div key={group.label}>
                    <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 sticky top-0 bg-card/80 backdrop-blur py-1">
                      {group.label}
                    </h3>
                    <div className="space-y-2">
                      {group.events.map(event => (
                        <EventItem key={event.id} event={event} />
                      ))}
                    </div>
                  </div>
                ))}
                
                {filteredEvents.length === 0 && (
                  <div className="text-center py-12 text-muted-foreground">
                    <Activity className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>No activity to show</p>
                    <p className="text-sm">Try adjusting your filters or time range</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Sidebar Stats */}
      <div className="w-64 shrink-0 space-y-4">
        <Card className="bg-card/50 backdrop-blur">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Quick Stats</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <StatRow label="Open Actions" value={kpis.openNBAs} icon={Zap} />
            <StatRow label="Overdue" value={kpis.overdueNBAs} icon={Clock} variant="danger" />
            <StatRow label="Stalled Deals" value={kpis.stalledOpportunities} icon={AlertTriangle} variant="warning" />
            <StatRow label="New Signals" value={kpis.newSignalsThisWeek} icon={Activity} variant="success" />
            <StatRow label="Active Opps" value={kpis.activeOpportunities} icon={Target} />
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Event Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {EVENT_FILTERS.filter(f => f.value !== 'all').map(filter => {
              const count = events.filter(e => e.type === filter.value).length;
              return (
                <div 
                  key={filter.value}
                  className="flex items-center justify-between text-sm cursor-pointer hover:bg-accent/50 p-2 rounded-lg transition-colors"
                  onClick={() => setActiveFilter(filter.value)}
                >
                  <span className="flex items-center gap-2 text-muted-foreground">
                    <filter.icon className="w-3 h-3" />
                    {filter.label}
                  </span>
                  <Badge variant="secondary" className="text-xs">{count}</Badge>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Sub-components

function PinnedNBAItem({ nba }: { nba: HomeNBA }) {
  const navigate = useNavigate();
  
  return (
    <div 
      className="p-3 rounded-lg bg-background/50 border border-destructive/20 cursor-pointer hover:bg-background/80 transition-colors"
      onClick={() => navigate(nba.opportunity_id ? `/opportunities/${nba.opportunity_id}` : `/accounts/${nba.account_id}`)}
    >
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-full bg-destructive/10 flex items-center justify-center shrink-0">
          <Zap className="w-4 h-4 text-destructive" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{nba.action}</p>
          <p className="text-xs text-muted-foreground truncate">
            {nba.opportunity_name || nba.account_name}
          </p>
          {nba.due_date && (
            <p className="text-xs text-destructive mt-1">
              Due {format(parseISO(nba.due_date), 'MMM d')}
            </p>
          )}
        </div>
        <Badge variant="destructive" className="text-[10px] shrink-0">
          {nba.is_overdue ? 'Overdue' : nba.priority}
        </Badge>
      </div>
    </div>
  );
}

function EventItem({ event }: { event: HomeEvent }) {
  const navigate = useNavigate();
  
  const getEventIcon = () => {
    switch (event.type) {
      case 'nba_due': return Zap;
      case 'signal_detected': return Activity;
      case 'stage_change': return ArrowRight;
      case 'sentiment_change': return event.metadata?.direction === 'up' ? TrendingUp : TrendingDown;
      case 'stalled': return AlertTriangle;
      default: return Activity;
    }
  };

  const getEventColor = () => {
    switch (event.type) {
      case 'nba_due': return event.priority === 'high' ? 'text-destructive bg-destructive/10' : 'text-amber-500 bg-amber-500/10';
      case 'signal_detected': return 'text-emerald-500 bg-emerald-500/10';
      case 'stage_change': return 'text-blue-500 bg-blue-500/10';
      case 'sentiment_change': return event.metadata?.direction === 'up' ? 'text-emerald-500 bg-emerald-500/10' : 'text-destructive bg-destructive/10';
      case 'stalled': return 'text-destructive bg-destructive/10';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  const Icon = getEventIcon();
  const colorClass = getEventColor();

  return (
    <div 
      className="p-3 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer flex items-start gap-3"
      onClick={() => event.opportunity_id ? navigate(`/opportunities/${event.opportunity_id}`) : event.account_id ? navigate(`/accounts/${event.account_id}`) : null}
    >
      <div className={cn("w-8 h-8 rounded-full flex items-center justify-center shrink-0", colorClass)}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium">{event.title}</p>
        <p className="text-xs text-muted-foreground truncate">{event.description}</p>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-xs text-muted-foreground">
            {event.opportunity_name || event.account_name}
          </span>
          <span className="text-xs text-muted-foreground">·</span>
          <span className="text-xs text-muted-foreground">
            {format(parseISO(event.timestamp), 'h:mm a')}
          </span>
        </div>
      </div>
    </div>
  );
}

interface StatRowProps {
  label: string;
  value: number;
  icon: React.ElementType;
  variant?: 'default' | 'success' | 'warning' | 'danger';
}

function StatRow({ label, value, icon: Icon, variant = 'default' }: StatRowProps) {
  const variantStyles = {
    default: 'text-muted-foreground',
    success: 'text-emerald-500',
    warning: 'text-amber-500',
    danger: 'text-destructive',
  };

  return (
    <div className="flex items-center justify-between">
      <span className="flex items-center gap-2 text-sm text-muted-foreground">
        <Icon className={cn("w-4 h-4", variantStyles[variant])} />
        {label}
      </span>
      <span className={cn("text-sm font-medium", value > 0 && variant !== 'default' ? variantStyles[variant] : '')}>
        {value}
      </span>
    </div>
  );
}

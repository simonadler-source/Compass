import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Zap, 
  AlertTriangle, 
  Activity, 
  TrendingDown,
  Building2,
  Target,
  ChevronRight,
  Clock,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow, differenceInDays } from 'date-fns';
import type { HomeNBA, HomeOpportunity, HomeSignal, HomeKPIs } from '@/hooks/useHomeData';

interface MissionControlViewProps {
  data: {
    kpis: HomeKPIs;
    nbas: HomeNBA[];
    opportunities: HomeOpportunity[];
    signals: HomeSignal[];
    isLoading: boolean;
  };
}

export function MissionControlView({ data }: MissionControlViewProps) {
  const navigate = useNavigate();
  const { kpis, nbas, opportunities, signals, isLoading } = data;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const overdueNBAs = nbas.filter(n => n.is_overdue);
  const dueTodayNBAs = nbas.filter(n => {
    if (!n.due_date || n.is_overdue) return false;
    const due = new Date(n.due_date);
    const today = new Date();
    return due.toDateString() === today.toDateString();
  });
  const upcomingNBAs = nbas.filter(n => {
    if (!n.due_date || n.is_overdue) return false;
    const due = new Date(n.due_date);
    const today = new Date();
    return due > today && due.toDateString() !== today.toDateString();
  }).slice(0, 5);
  // NBAs without due dates - show high priority first
  const noDueDateNBAs = nbas
    .filter(n => !n.due_date)
    .sort((a, b) => {
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      return (priorityOrder[a.priority] || 2) - (priorityOrder[b.priority] || 2);
    })
    .slice(0, 5);

  const stalledOpps = opportunities.filter(o => o.is_stalled);
  const atRiskOpps = opportunities.filter(o => 
    (o.engagement_score && o.engagement_score < 40) || 
    (o.momentum_score && o.momentum_score < 30)
  );
  // Low readiness opportunities (close date within 60 days but readiness < 50%)
  const lowReadinessOpps = opportunities.filter(o => {
    if (!o.close_date || !o.readiness_score) return false;
    const daysToClose = differenceInDays(new Date(o.close_date), new Date());
    return daysToClose <= 60 && daysToClose >= 0 && o.readiness_score < 50;
  });

  return (
    <div className="space-y-6">
      {/* KPI Header */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
        <KPICard
          title="Open Actions"
          value={kpis.openNBAs}
          icon={Zap}
          variant={kpis.overdueNBAs > 0 ? 'warning' : 'default'}
          subtext={kpis.overdueNBAs > 0 ? `${kpis.overdueNBAs} overdue` : undefined}
          onClick={() => navigate('/nba')}
        />
        <KPICard
          title="Stalled Deals"
          value={kpis.stalledOpportunities}
          icon={AlertTriangle}
          variant={kpis.stalledOpportunities > 0 ? 'danger' : 'default'}
          subtext="> 14 days inactive"
        />
        <KPICard
          title="New Signals"
          value={kpis.newSignalsThisWeek}
          icon={Activity}
          variant="success"
          subtext="This week"
          onClick={() => navigate('/activity-signals')}
        />
        <KPICard
          title="Active Opps"
          value={kpis.activeOpportunities}
          icon={Target}
          variant="default"
        />
        <KPICard
          title="Sentiment Changes"
          value={kpis.sentimentChanges}
          icon={TrendingDown}
          variant={kpis.sentimentChanges > 0 ? 'warning' : 'default'}
          subtext="Recent"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Action Center */}
        <Card className="bg-card/50 backdrop-blur">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Zap className="w-5 h-5 text-primary" />
              Action Center
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={() => navigate('/nba')}>
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[320px] pr-4">
              <div className="space-y-4">
                {/* Overdue Section */}
                {overdueNBAs.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-destructive uppercase tracking-wider mb-2">
                      Overdue ({overdueNBAs.length})
                    </h4>
                    <div className="space-y-2">
                      {overdueNBAs.slice(0, 3).map(nba => (
                        <NBAItem key={nba.id} nba={nba} variant="overdue" />
                      ))}
                    </div>
                  </div>
                )}

                {/* Due Today Section */}
                {dueTodayNBAs.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-amber-500 uppercase tracking-wider mb-2">
                      Due Today ({dueTodayNBAs.length})
                    </h4>
                    <div className="space-y-2">
                      {dueTodayNBAs.slice(0, 3).map(nba => (
                        <NBAItem key={nba.id} nba={nba} variant="today" />
                      ))}
                    </div>
                  </div>
                )}

                {/* Upcoming Section */}
                {upcomingNBAs.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                      Upcoming
                    </h4>
                    <div className="space-y-2">
                      {upcomingNBAs.map(nba => (
                        <NBAItem key={nba.id} nba={nba} variant="upcoming" />
                      ))}
                    </div>
                  </div>
                )}

                {/* No Due Date Section */}
                {noDueDateNBAs.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-blue-500 uppercase tracking-wider mb-2">
                      Pending - No Due Date ({noDueDateNBAs.length})
                    </h4>
                    <div className="space-y-2">
                      {noDueDateNBAs.map(nba => (
                        <NBAItem key={nba.id} nba={nba} variant="upcoming" />
                      ))}
                    </div>
                  </div>
                )}

                {nbas.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Zap className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p>No pending actions</p>
                  </div>
                )}

                {nbas.length > 0 && overdueNBAs.length === 0 && dueTodayNBAs.length === 0 && upcomingNBAs.length === 0 && noDueDateNBAs.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Zap className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p>All actions scheduled</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Attention Needed */}
        <Card className="bg-card/50 backdrop-blur">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              Attention Needed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[320px] pr-4">
              <div className="space-y-4">
                {/* Stalled Opportunities */}
                {stalledOpps.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-destructive uppercase tracking-wider mb-2">
                      Stalled Deals ({stalledOpps.length})
                    </h4>
                    <div className="space-y-2">
                      {stalledOpps.slice(0, 4).map(opp => (
                        <OpportunityItem key={opp.id} opportunity={opp} variant="stalled" />
                      ))}
                    </div>
                  </div>
                )}

                {/* At Risk */}
                {atRiskOpps.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-amber-500 uppercase tracking-wider mb-2">
                      Low Engagement ({atRiskOpps.length})
                    </h4>
                    <div className="space-y-2">
                      {atRiskOpps.slice(0, 4).map(opp => (
                        <OpportunityItem key={opp.id} opportunity={opp} variant="at-risk" />
                      ))}
                    </div>
                  </div>
                )}

                {/* Low Readiness with upcoming close */}
                {lowReadinessOpps.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-purple-500 uppercase tracking-wider mb-2">
                      Low Readiness - Closing Soon ({lowReadinessOpps.length})
                    </h4>
                    <div className="space-y-2">
                      {lowReadinessOpps.slice(0, 4).map(opp => (
                        <OpportunityItem key={opp.id} opportunity={opp} variant="at-risk" />
                      ))}
                    </div>
                  </div>
                )}

                {stalledOpps.length === 0 && atRiskOpps.length === 0 && lowReadinessOpps.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <AlertTriangle className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p>All deals are healthy</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Signals */}
        <Card className="bg-card/50 backdrop-blur">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Activity className="w-5 h-5 text-emerald-500" />
              Recent Signals
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={() => navigate('/activity-signals')}>
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[200px] pr-4">
              <div className="space-y-2">
                {signals.slice(0, 8).map(signal => (
                  <SignalItem key={signal.id} signal={signal} />
                ))}
                {signals.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Activity className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p>No recent signals</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* My Portfolio Quick Access */}
        <Card className="bg-card/50 backdrop-blur">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-500" />
              My Portfolio
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={() => navigate('/accounts')}>
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[200px] pr-4">
              <div className="space-y-2">
                {opportunities.slice(0, 8).map(opp => (
                  <PortfolioItem key={opp.id} opportunity={opp} />
                ))}
                {opportunities.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Building2 className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p>No opportunities assigned</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Sub-components

interface KPICardProps {
  title: string;
  value: number;
  icon: React.ElementType;
  variant?: 'default' | 'success' | 'warning' | 'danger';
  subtext?: string;
  onClick?: () => void;
}

function KPICard({ title, value, icon: Icon, variant = 'default', subtext, onClick }: KPICardProps) {
  const variantStyles = {
    default: 'border-border',
    success: 'border-emerald-500/30 bg-emerald-500/5',
    warning: 'border-amber-500/30 bg-amber-500/5',
    danger: 'border-destructive/30 bg-destructive/5',
  };

  const iconStyles = {
    default: 'text-muted-foreground',
    success: 'text-emerald-500',
    warning: 'text-amber-500',
    danger: 'text-destructive',
  };

  return (
    <Card 
      className={cn(
        "bg-card/50 backdrop-blur cursor-pointer hover:bg-card/80 transition-colors",
        variantStyles[variant]
      )}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">{title}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            {subtext && (
              <p className={cn(
                "text-xs mt-1",
                variant === 'danger' ? 'text-destructive' : 
                variant === 'warning' ? 'text-amber-500' : 
                'text-muted-foreground'
              )}>
                {subtext}
              </p>
            )}
          </div>
          <Icon className={cn("w-8 h-8", iconStyles[variant])} />
        </div>
      </CardContent>
    </Card>
  );
}

interface NBAItemProps {
  nba: HomeNBA;
  variant: 'overdue' | 'today' | 'upcoming';
}

const ACTION_TYPE_LABELS: Record<string, { label: string; color: string }> = {
  follow_up: { label: 'Follow-up', color: 'bg-blue-500/20 text-blue-600' },
  demo: { label: 'Demo', color: 'bg-purple-500/20 text-purple-600' },
  discovery: { label: 'Discovery', color: 'bg-emerald-500/20 text-emerald-600' },
  proposal: { label: 'Proposal', color: 'bg-amber-500/20 text-amber-600' },
  technical: { label: 'Technical', color: 'bg-cyan-500/20 text-cyan-600' },
  meeting: { label: 'Meeting', color: 'bg-indigo-500/20 text-indigo-600' },
  email: { label: 'Email', color: 'bg-pink-500/20 text-pink-600' },
  call: { label: 'Call', color: 'bg-orange-500/20 text-orange-600' },
  default: { label: 'Action', color: 'bg-muted text-muted-foreground' },
};

function NBAItem({ nba, variant }: NBAItemProps) {
  const navigate = useNavigate();
  
  const variantStyles = {
    overdue: 'border-l-destructive bg-destructive/5',
    today: 'border-l-amber-500 bg-amber-500/5',
    upcoming: 'border-l-muted-foreground/30',
  };

  const actionTypeInfo = ACTION_TYPE_LABELS[nba.action_type] || ACTION_TYPE_LABELS.default;

  return (
    <div 
      className={cn(
        "p-3 rounded-lg border-l-2 cursor-pointer hover:bg-accent/50 transition-colors",
        variantStyles[variant]
      )}
      onClick={() => navigate(nba.opportunity_id ? `/opportunities/${nba.opportunity_id}` : `/accounts/${nba.account_id}`)}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className={cn("text-[10px] px-1.5 py-0.5 rounded font-medium", actionTypeInfo.color)}>
              {actionTypeInfo.label}
            </span>
            <Badge variant={nba.priority === 'high' ? 'destructive' : 'secondary'} className="text-[10px]">
              {nba.priority}
            </Badge>
          </div>
          <p className="text-sm font-medium line-clamp-2">{nba.action}</p>
          <p className="text-xs text-muted-foreground truncate mt-1">
            {nba.opportunity_name || nba.account_name}
          </p>
        </div>
      </div>
      <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
        {nba.due_date && (
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {formatDistanceToNow(new Date(nba.due_date), { addSuffix: true })}
          </span>
        )}
        {nba.assigned_to && (
          <span className="truncate max-w-[120px]" title={nba.assigned_to}>
            → {nba.assigned_to.split('@')[0]}
          </span>
        )}
      </div>
    </div>
  );
}

interface OpportunityItemProps {
  opportunity: HomeOpportunity;
  variant: 'stalled' | 'at-risk';
}

function OpportunityItem({ opportunity, variant }: OpportunityItemProps) {
  const navigate = useNavigate();
  
  const stage = opportunity.pre_sales_stage || opportunity.sales_stage;
  const formattedValue = opportunity.value 
    ? `$${(opportunity.value / 1000).toFixed(0)}k` 
    : null;
  
  return (
    <div 
      className={cn(
        "p-3 rounded-lg cursor-pointer hover:bg-accent/50 transition-colors",
        variant === 'stalled' ? 'border-l-2 border-l-destructive bg-destructive/5' : 'border-l-2 border-l-amber-500 bg-amber-500/5'
      )}
      onClick={() => navigate(`/opportunities/${opportunity.id}`)}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{opportunity.name}</p>
          <p className="text-xs text-muted-foreground truncate">{opportunity.account_name}</p>
          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
            {stage && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                {stage}
              </span>
            )}
            {formattedValue && (
              <span className="text-[10px] font-medium text-foreground">
                {formattedValue}
              </span>
            )}
            {opportunity.readiness_score !== null && (
              <span className={cn(
                "text-[10px] px-1.5 py-0.5 rounded",
                opportunity.readiness_score >= 70 ? 'bg-emerald-500/20 text-emerald-600' :
                opportunity.readiness_score >= 40 ? 'bg-amber-500/20 text-amber-600' :
                'bg-destructive/20 text-destructive'
              )}>
                {opportunity.readiness_score}% ready
              </span>
            )}
          </div>
        </div>
        <div className="flex flex-col items-end gap-1 shrink-0">
          {variant === 'stalled' && opportunity.days_since_activity && (
            <Badge variant="destructive" className="text-[10px]">
              {opportunity.days_since_activity}d inactive
            </Badge>
          )}
          {variant === 'at-risk' && (
            <div className="flex flex-col items-end gap-0.5">
              {opportunity.engagement_score !== null && (
                <div className="flex items-center gap-1 text-amber-500">
                  <TrendingDown className="w-3 h-3" />
                  <span className="text-[10px]">Eng: {opportunity.engagement_score}%</span>
                </div>
              )}
              {opportunity.momentum_score !== null && opportunity.momentum_score < 30 && (
                <div className="flex items-center gap-1 text-amber-500">
                  <ArrowDownRight className="w-3 h-3" />
                  <span className="text-[10px]">Mom: {opportunity.momentum_score}%</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

interface SignalItemProps {
  signal: HomeSignal;
}

function SignalItem({ signal }: SignalItemProps) {
  const navigate = useNavigate();
  
  return (
    <div 
      className="p-2 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer flex items-center gap-3"
      onClick={() => navigate(`/opportunities/${signal.opportunity_id}`)}
    >
      <div className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm truncate">
          <span className="font-medium">{signal.rule_name}</span>
          <span className="text-muted-foreground"> · {signal.opportunity_name}</span>
        </p>
      </div>
      <span className="text-xs text-muted-foreground shrink-0">
        {formatDistanceToNow(new Date(signal.first_detected_at), { addSuffix: true })}
      </span>
    </div>
  );
}

interface PortfolioItemProps {
  opportunity: HomeOpportunity;
}

function PortfolioItem({ opportunity }: PortfolioItemProps) {
  const navigate = useNavigate();
  
  const getHealthColor = () => {
    if (opportunity.is_stalled) return 'bg-destructive';
    if (opportunity.readiness_score && opportunity.readiness_score >= 70) return 'bg-emerald-500';
    if (opportunity.readiness_score && opportunity.readiness_score >= 40) return 'bg-amber-500';
    return 'bg-muted-foreground';
  };
  
  return (
    <div 
      className="p-2 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer flex items-center gap-3"
      onClick={() => navigate(`/opportunities/${opportunity.id}`)}
    >
      <div className={cn("w-2 h-2 rounded-full shrink-0", getHealthColor())} />
      <div className="flex-1 min-w-0">
        <p className="text-sm truncate">
          <span className="font-medium">{opportunity.name}</span>
        </p>
        <p className="text-xs text-muted-foreground truncate">
          {opportunity.account_name} · {opportunity.pre_sales_stage || opportunity.sales_stage || 'No stage'}
        </p>
      </div>
      {opportunity.value && (
        <span className="text-xs text-muted-foreground shrink-0">
          ${(opportunity.value / 1000).toFixed(0)}k
        </span>
      )}
    </div>
  );
}

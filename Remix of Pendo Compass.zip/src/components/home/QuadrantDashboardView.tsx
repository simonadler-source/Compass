import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { 
  Zap, 
  AlertTriangle, 
  Activity, 
  Building2,
  Target,
  ChevronRight,
  Clock,
  Maximize2,
  Minimize2,
  TrendingUp,
  TrendingDown
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow, format, parseISO } from 'date-fns';
import type { HomeNBA, HomeOpportunity, HomeSignal, HomeStageChange, HomeSentimentChange } from '@/hooks/useHomeData';

interface QuadrantDashboardViewProps {
  data: {
    nbas: HomeNBA[];
    opportunities: HomeOpportunity[];
    signals: HomeSignal[];
    stageChanges: HomeStageChange[];
    sentimentChanges: HomeSentimentChange[];
    isLoading: boolean;
  };
}

type ExpandedQuadrant = 'nbas' | 'signals' | 'pipeline' | 'portfolio' | null;

export function QuadrantDashboardView({ data }: QuadrantDashboardViewProps) {
  const { nbas, opportunities, signals, stageChanges, sentimentChanges, isLoading } = data;
  const [expanded, setExpanded] = useState<ExpandedQuadrant>(null);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const toggleExpand = (quadrant: ExpandedQuadrant) => {
    setExpanded(prev => prev === quadrant ? null : quadrant);
  };

  // Group NBAs by account
  const nbasByAccount = nbas.reduce((acc, nba) => {
    const key = nba.account_id;
    if (!acc[key]) {
      acc[key] = { accountName: nba.account_name, nbas: [] };
    }
    acc[key].nbas.push(nba);
    return acc;
  }, {} as Record<string, { accountName: string; nbas: HomeNBA[] }>);

  const stalledOpps = opportunities.filter(o => o.is_stalled);
  const completedNBAs = nbas.filter(n => n.status === 'completed').length;
  const totalNBAs = nbas.length + completedNBAs;
  const completionRate = totalNBAs > 0 ? Math.round((completedNBAs / totalNBAs) * 100) : 0;

  const isExpanded = (quadrant: ExpandedQuadrant) => expanded === quadrant;
  const isCollapsed = (quadrant: ExpandedQuadrant) => expanded !== null && expanded !== quadrant;

  return (
    <div className={cn(
      "grid gap-4 transition-all duration-300",
      expanded ? "grid-cols-1" : "grid-cols-1 lg:grid-cols-2"
    )}>
      {/* Q1: NBAs */}
      {!isCollapsed('nbas') && (
        <Card className={cn(
          "bg-card/50 backdrop-blur transition-all duration-300",
          isExpanded('nbas') && "col-span-full"
        )}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Zap className="w-5 h-5 text-primary" />
              My Actions
              <Badge variant="secondary" className="ml-2">{nbas.length}</Badge>
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => toggleExpand('nbas')}>
                {isExpanded('nbas') ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-muted-foreground">Completion Progress</span>
                <span className="font-medium">{completionRate}%</span>
              </div>
              <Progress value={completionRate} className="h-2" />
            </div>
            <ScrollArea className={cn("pr-4", isExpanded('nbas') ? "h-[500px]" : "h-[280px]")}>
              <div className="space-y-4">
                {Object.entries(nbasByAccount).map(([accountId, { accountName, nbas: accountNbas }]) => (
                  <AccountNBAGroup 
                    key={accountId} 
                    accountId={accountId}
                    accountName={accountName} 
                    nbas={accountNbas} 
                  />
                ))}
                {nbas.length === 0 && (
                  <EmptyState icon={Zap} message="No pending actions" />
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Q2: Signals & Alerts */}
      {!isCollapsed('signals') && (
        <Card className={cn(
          "bg-card/50 backdrop-blur transition-all duration-300",
          isExpanded('signals') && "col-span-full"
        )}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Activity className="w-5 h-5 text-emerald-500" />
              Signals & Alerts
              <Badge variant="secondary" className="ml-2">{signals.length + stageChanges.length + sentimentChanges.length}</Badge>
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => toggleExpand('signals')}>
                {isExpanded('signals') ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className={cn("pr-4", isExpanded('signals') ? "h-[500px]" : "h-[320px]")}>
              <div className="space-y-4">
                {/* Signals */}
                {signals.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-emerald-500 uppercase tracking-wider mb-2">
                      New Signals ({signals.length})
                    </h4>
                    <div className="space-y-2">
                      {signals.slice(0, isExpanded('signals') ? 20 : 5).map(signal => (
                        <SignalItem key={signal.id} signal={signal} />
                      ))}
                    </div>
                  </div>
                )}

                {/* Stage Changes */}
                {stageChanges.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-blue-500 uppercase tracking-wider mb-2">
                      Stage Changes ({stageChanges.length})
                    </h4>
                    <div className="space-y-2">
                      {stageChanges.slice(0, isExpanded('signals') ? 10 : 3).map(change => (
                        <StageChangeItem key={change.id} change={change} />
                      ))}
                    </div>
                  </div>
                )}

                {/* Sentiment Changes */}
                {sentimentChanges.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-amber-500 uppercase tracking-wider mb-2">
                      Sentiment Shifts ({sentimentChanges.length})
                    </h4>
                    <div className="space-y-2">
                      {sentimentChanges.slice(0, isExpanded('signals') ? 10 : 3).map(change => (
                        <SentimentChangeItem key={change.id} change={change} />
                      ))}
                    </div>
                  </div>
                )}

                {signals.length === 0 && stageChanges.length === 0 && sentimentChanges.length === 0 && (
                  <EmptyState icon={Activity} message="No recent signals" />
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Q3: Pipeline Health */}
      {!isCollapsed('pipeline') && (
        <Card className={cn(
          "bg-card/50 backdrop-blur transition-all duration-300",
          isExpanded('pipeline') && "col-span-full"
        )}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              Pipeline Health
              {stalledOpps.length > 0 && (
                <Badge variant="destructive" className="ml-2">{stalledOpps.length} at risk</Badge>
              )}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => toggleExpand('pipeline')}>
                {isExpanded('pipeline') ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className={cn("pr-4", isExpanded('pipeline') ? "h-[500px]" : "h-[320px]")}>
              <div className="space-y-4">
                {/* Stalled */}
                {stalledOpps.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-destructive uppercase tracking-wider mb-2">
                      Stalled ({stalledOpps.length})
                    </h4>
                    <div className="space-y-2">
                      {stalledOpps.slice(0, isExpanded('pipeline') ? 20 : 5).map(opp => (
                        <PipelineOpportunityItem key={opp.id} opportunity={opp} variant="stalled" />
                      ))}
                    </div>
                  </div>
                )}

                {/* Low Readiness */}
                {opportunities.filter(o => !o.is_stalled && o.readiness_score && o.readiness_score < 40).length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-amber-500 uppercase tracking-wider mb-2">
                      Low Readiness
                    </h4>
                    <div className="space-y-2">
                      {opportunities
                        .filter(o => !o.is_stalled && o.readiness_score && o.readiness_score < 40)
                        .slice(0, isExpanded('pipeline') ? 10 : 3)
                        .map(opp => (
                          <PipelineOpportunityItem key={opp.id} opportunity={opp} variant="low-readiness" />
                        ))}
                    </div>
                  </div>
                )}

                {stalledOpps.length === 0 && (
                  <EmptyState icon={Target} message="All opportunities are healthy" variant="success" />
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Q4: My Portfolio */}
      {!isCollapsed('portfolio') && (
        <Card className={cn(
          "bg-card/50 backdrop-blur transition-all duration-300",
          isExpanded('portfolio') && "col-span-full"
        )}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-500" />
              My Portfolio
              <Badge variant="secondary" className="ml-2">{opportunities.length}</Badge>
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => toggleExpand('portfolio')}>
                {isExpanded('portfolio') ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className={cn("pr-4", isExpanded('portfolio') ? "h-[500px]" : "h-[320px]")}>
              <div className="space-y-2">
                {opportunities.slice(0, isExpanded('portfolio') ? 50 : 10).map(opp => (
                  <PortfolioOpportunityItem key={opp.id} opportunity={opp} />
                ))}
                {opportunities.length === 0 && (
                  <EmptyState icon={Building2} message="No opportunities assigned" />
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Sub-components

function AccountNBAGroup({ accountId, accountName, nbas }: { accountId: string; accountName: string; nbas: HomeNBA[] }) {
  const navigate = useNavigate();
  const completed = nbas.filter(n => n.status === 'completed').length;
  const total = nbas.length;
  const progress = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <div className="p-3 rounded-lg bg-accent/30">
      <div className="flex items-center justify-between mb-2">
        <span 
          className="text-sm font-medium cursor-pointer hover:text-primary transition-colors"
          onClick={() => navigate(`/accounts/${accountId}`)}
        >
          {accountName}
        </span>
        <span className="text-xs text-muted-foreground">{completed}/{total}</span>
      </div>
      <Progress value={progress} className="h-1.5 mb-2" />
      <div className="space-y-1">
        {nbas.slice(0, 3).map(nba => (
          <div 
            key={nba.id} 
            className="flex items-center gap-2 text-xs cursor-pointer hover:bg-accent/50 p-1 rounded transition-colors"
            onClick={() => navigate(nba.opportunity_id ? `/opportunities/${nba.opportunity_id}` : `/accounts/${nba.account_id}`)}
          >
            <div className={cn(
              "w-1.5 h-1.5 rounded-full shrink-0",
              nba.is_overdue ? 'bg-destructive' : nba.priority === 'high' ? 'bg-amber-500' : 'bg-muted-foreground'
            )} />
            <span className="truncate flex-1">{nba.action}</span>
            {nba.is_overdue && <Badge variant="destructive" className="text-[8px] px-1">Overdue</Badge>}
          </div>
        ))}
        {nbas.length > 3 && (
          <p className="text-xs text-muted-foreground pl-3">+{nbas.length - 3} more</p>
        )}
      </div>
    </div>
  );
}

function SignalItem({ signal }: { signal: HomeSignal }) {
  const navigate = useNavigate();
  
  return (
    <div 
      className="p-2 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer flex items-center gap-3"
      onClick={() => navigate(`/opportunities/${signal.opportunity_id}`)}
    >
      <div className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm truncate">
          <span className="font-medium">{signal.rule_name}</span>
          <span className="text-muted-foreground"> · {signal.opportunity_name}</span>
        </p>
      </div>
      <span className="text-xs text-muted-foreground shrink-0">
        {formatDistanceToNow(parseISO(signal.first_detected_at), { addSuffix: true })}
      </span>
    </div>
  );
}

function StageChangeItem({ change }: { change: HomeStageChange }) {
  const navigate = useNavigate();
  
  return (
    <div 
      className="p-2 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer flex items-center gap-3"
      onClick={() => navigate(`/opportunities/${change.opportunity_id}`)}
    >
      <div className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm truncate">
          <span className="font-medium">{change.opportunity_name}</span>
        </p>
        <p className="text-xs text-muted-foreground">
          {change.old_value || 'None'} → {change.new_value}
        </p>
      </div>
    </div>
  );
}

function SentimentChangeItem({ change }: { change: HomeSentimentChange }) {
  const isUp = change.change_direction === 'up';
  
  return (
    <div className="p-2 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer flex items-center gap-3">
      <div className={cn(
        "w-6 h-6 rounded-full flex items-center justify-center shrink-0",
        isUp ? 'bg-emerald-500/10 text-emerald-500' : 'bg-destructive/10 text-destructive'
      )}>
        {isUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm truncate">
          <span className="font-medium">{change.contact_name}</span>
          <span className="text-muted-foreground"> · {change.account_name}</span>
        </p>
      </div>
    </div>
  );
}

function PipelineOpportunityItem({ opportunity, variant }: { opportunity: HomeOpportunity; variant: 'stalled' | 'low-readiness' }) {
  const navigate = useNavigate();
  
  return (
    <div 
      className={cn(
        "p-3 rounded-lg cursor-pointer hover:bg-accent/50 transition-colors border-l-2",
        variant === 'stalled' ? 'border-l-destructive bg-destructive/5' : 'border-l-amber-500 bg-amber-500/5'
      )}
      onClick={() => navigate(`/opportunities/${opportunity.id}`)}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{opportunity.name}</p>
          <p className="text-xs text-muted-foreground truncate">{opportunity.account_name}</p>
        </div>
        {variant === 'stalled' && opportunity.days_since_activity && (
          <Badge variant="destructive" className="text-[10px] shrink-0">
            {opportunity.days_since_activity}d stuck
          </Badge>
        )}
        {variant === 'low-readiness' && opportunity.readiness_score !== null && (
          <Badge variant="outline" className="text-[10px] shrink-0 border-amber-500 text-amber-500">
            {opportunity.readiness_score}% ready
          </Badge>
        )}
      </div>
    </div>
  );
}

function PortfolioOpportunityItem({ opportunity }: { opportunity: HomeOpportunity }) {
  const navigate = useNavigate();
  
  const getHealthColor = () => {
    if (opportunity.is_stalled) return 'bg-destructive';
    if (opportunity.readiness_score && opportunity.readiness_score >= 70) return 'bg-emerald-500';
    if (opportunity.readiness_score && opportunity.readiness_score >= 40) return 'bg-amber-500';
    return 'bg-muted-foreground';
  };
  
  return (
    <div 
      className="p-2 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer flex items-center gap-3"
      onClick={() => navigate(`/opportunities/${opportunity.id}`)}
    >
      <div className={cn("w-2 h-2 rounded-full shrink-0", getHealthColor())} />
      <div className="flex-1 min-w-0">
        <p className="text-sm truncate font-medium">{opportunity.name}</p>
        <p className="text-xs text-muted-foreground truncate">
          {opportunity.account_name} · {opportunity.pre_sales_stage || opportunity.sales_stage || 'No stage'}
        </p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        {opportunity.readiness_score !== null && (
          <div className="w-12">
            <Progress value={opportunity.readiness_score} className="h-1.5" />
          </div>
        )}
        {opportunity.value && (
          <span className="text-xs text-muted-foreground">
            ${(opportunity.value / 1000).toFixed(0)}k
          </span>
        )}
      </div>
    </div>
  );
}

function EmptyState({ icon: Icon, message, variant = 'default' }: { icon: React.ElementType; message: string; variant?: 'default' | 'success' }) {
  return (
    <div className="text-center py-8 text-muted-foreground">
      <Icon className={cn(
        "w-8 h-8 mx-auto mb-2 opacity-30",
        variant === 'success' && 'text-emerald-500 opacity-50'
      )} />
      <p className={cn(variant === 'success' && 'text-emerald-600')}>{message}</p>
    </div>
  );
}

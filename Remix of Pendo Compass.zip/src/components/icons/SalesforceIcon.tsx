import * as React from 'react';

interface SalesforceIconProps extends React.SVGProps<SVGSVGElement> {
  className?: string;
}

export const SalesforceIcon: React.FC<SalesforceIconProps> = ({ className, ...props }) => (
  <svg
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <path
      d="M20.048 9.6c1.776-1.848 4.248-2.992 6.984-2.992 3.648 0 6.84 2.04 8.472 5.04a10.44 10.44 0 0 1 4.032-.816c5.784 0 10.464 4.68 10.464 10.464 0 5.784-4.68 10.464-10.464 10.464a10.38 10.38 0 0 1-2.376-.276c-1.44 2.544-4.176 4.272-7.32 4.272-1.32 0-2.568-.304-3.672-.84A9.024 9.024 0 0 1 17.76 41.4c-1.008 0-1.98-.168-2.88-.472-1.56 2.328-4.2 3.872-7.2 3.872C3.432 44.8 0 41.368 0 37.12c0-2.664 1.368-5.016 3.432-6.384a9.07 9.07 0 0 1-.624-3.336c0-5.016 4.08-9.096 9.096-9.096.84 0 1.656.12 2.424.336A9.876 9.876 0 0 1 20.048 9.6z"
      fill="#00A1E0"
    />
  </svg>
);

export default SalesforceIcon;

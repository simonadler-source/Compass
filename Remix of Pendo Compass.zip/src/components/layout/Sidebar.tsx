import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation } from 'react-router-dom';
import { 
  Building2, 
  Target, 
  FileText, 
  Settings, 
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Link2,
  BookOpen,
  LogOut,
  Cog,
  User,
  Zap,
  Layers,
  Library,
  LayoutGrid,
  Video,
  AlertCircle,
  GitBranch,
  Users,
  Clock,
  Activity,
  X,
  BarChart3,
  Home,
  Shield
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { supabase } from '@/integrations/supabase/client';
import { NotificationBell } from '@/components/NotificationBell';
import { useRecentItems } from '@/hooks/useRecentItems';
import { GlobalSearchCommand } from '@/components/GlobalSearchCommand';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import pendoLogo from '@/assets/pendo-logo.png';

const navItems = [
  { id: 'home', path: '/home', icon: Home, label: 'Home' },
  { id: 'accounts', path: '/accounts', icon: Building2, label: 'Accounts' },
  { id: 'nba', path: '/nba', icon: Zap, label: 'Next Best Actions' },
  { id: 'manager', path: '/manager', icon: Users, label: 'Team Dashboard' },
  { id: 'activity-signals', path: '/activity-signals', icon: Activity, label: 'Activity Signals' },
  { id: 'product-analytics', path: '/product-analytics', icon: BarChart3, label: 'Product Analytics' },
  { id: 'momentum', path: '/momentum', icon: Video, label: 'Momentum Meetings' },
  { id: 'transcripts', path: '/transcripts', icon: FileText, label: 'AI Discovery' },
  { id: 'stories', path: '/customer-stories', icon: BookOpen, label: 'Customer Stories' },
  { id: 'competitive', path: '/competitive-scorecard', icon: Shield, label: 'Competitive Intel' },
];

const configItems = [
  { id: 'functional-areas', path: '/functional-areas', icon: LayoutGrid, label: 'Functional Areas' },
  { id: 'reference', path: '/reference-architecture', icon: Layers, label: 'Reference Architecture' },
  { id: 'library', path: '/technology-library', icon: Library, label: 'Technology Library' },
  
  { id: 'detection-rules', path: '/detection-rules', icon: GitBranch, label: 'Detection Rules' },
  { id: 'alert-rules', path: '/alert-rules', icon: AlertCircle, label: 'Alert Rules' },
  { id: 'readiness-questions', path: '/readiness-questions', icon: FileText, label: 'Readiness Questions' },
  { id: 'validation-tasks', path: '/validation-tasks', icon: Target, label: 'Validation Tasks' },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const [recentsOpen, setRecentsOpen] = useState(true);
  const [recentsExpanded, setRecentsExpanded] = useState(false);
  const [configOpen, setConfigOpen] = useState(false);
  const { user, signOut } = useAuth();
  const { isAdmin, profile } = useUserRole();
  const location = useLocation();
  const { recentItems, clearRecentItems } = useRecentItems();
  
  // Check if user has MFA enabled - use profile from database, fallback to AuthContext user
  // The profile query may fail if session token isn't ready, so we use user.mfa_enabled as fallback
  // Google SSO users are exempt from MFA requirement (consistent with ProtectedRoute logic)
  const isGoogleSSO = user?.auth_provider === 'google';
  const hasMfaEnabled = isGoogleSSO || profile?.mfa_enabled === true || user?.mfa_enabled === true;

  // Check if any config item is active to auto-expand
  const isConfigActive = configItems.some(item => location.pathname.startsWith(item.path));

  // Keep the sidebar badge aligned with the Momentum page tab counts by
  // reusing the same persisted filters (including My Meetings toggle).
  const MOMENTUM_FILTERS_STORAGE_KEY = 'momentum-meetings-filters';
  const [momentumFiltersVersion, setMomentumFiltersVersion] = useState(0);

  useEffect(() => {
    const handler = () => setMomentumFiltersVersion((v) => v + 1);
    window.addEventListener('momentum-meetings-filters-changed', handler as EventListener);
    return () => window.removeEventListener('momentum-meetings-filters-changed', handler as EventListener);
  }, []);

  // Fetch momentum meetings menu count (Pending + Orphaned + Ignored)
  const { data: momentumMenuCount } = useQuery({
    queryKey: ['momentum-menu-count', user?.id, user?.email, momentumFiltersVersion],
    queryFn: async () => {
      if (!user) return 0;

      let persisted: any = null;
      try {
        const raw = localStorage.getItem(MOMENTUM_FILTERS_STORAGE_KEY);
        persisted = raw ? JSON.parse(raw) : null;
      } catch {
        persisted = null;
      }

      const myMeetingsOnly = persisted?.myMeetingsOnly ?? true;

      // If "My Meetings" is on, we need an email to apply the filter.
      if (myMeetingsOnly && !user.email) return 0;

      const { data, error } = await supabase.functions.invoke('search-meetings', {
        body: {
          searchQuery: persisted?.searchQuery || undefined,
          attendeeFilter: persisted?.attendeeFilter || undefined,
          dateFrom: persisted?.dateFrom || undefined,
          dateTo: persisted?.dateTo || undefined,
          myMeetingsOnly,
          userEmail: myMeetingsOnly ? user.email : undefined,
          statuses: ['pending', 'processing', 'ignored', 'imported'],
          limit: 10000,
        },
      });

      if (error) {
        console.error('Error fetching momentum meetings menu count:', error);
        return 0;
      }

      const results = (data?.results as any[]) || [];
      const pendingCount = results.filter((r) => r?.status === 'pending' || r?.status === 'processing').length;
      const ignoredCount = results.filter((r) => r?.status === 'ignored').length;
      const orphanedCount = results.filter((r) => r?.status === 'imported' && !r?.matched_account_id).length;

      return pendingCount + ignoredCount + orphanedCount;
    },
    enabled: !!user,
    refetchInterval: 60000,
  });

  // Fetch pending users count (for admins only)
  const { data: pendingUsersCount } = useQuery({
    queryKey: ['pending-users-count'],
    queryFn: async () => {
      const { count, error } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');
      if (error) return 0;
      return count || 0;
    },
    enabled: isAdmin,
    refetchInterval: 60000,
  });

  const isActive = (path: string) => location.pathname.startsWith(path);

  return (
    <aside 
      className={cn(
        "flex flex-col h-screen bg-sidebar border-r border-sidebar-border transition-all duration-300",
        collapsed ? "w-16" : "w-64"
      )}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 p-4 border-b border-sidebar-border">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-[#e83e8c]/10 overflow-hidden">
          <img src={pendoLogo} alt="Pendo" className="w-6 h-6 object-contain" />
        </div>
        {!collapsed && (
          <div className="animate-fade-in flex-1">
            <h1 className="font-bold text-lg text-foreground">Compass</h1>
            <p className="text-xs text-muted-foreground">Pendo Platform</p>
          </div>
        )}
        {!collapsed && <NotificationBell />}
      </div>

      {/* Global Search */}
      {!collapsed && hasMfaEnabled && (
        <div className="px-3 py-2 border-b border-sidebar-border">
          <GlobalSearchCommand />
        </div>
      )}

      {/* Navigation - Only show if MFA is enabled */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {!hasMfaEnabled ? (
          // Show message when MFA not enabled
          <div className="px-3 py-4 text-center">
            <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-[hsl(var(--pendo-pink))]/10 flex items-center justify-center">
              <Settings className="w-6 h-6 text-[hsl(var(--pendo-pink))]" />
            </div>
            {!collapsed && (
              <p className="text-xs text-muted-foreground">
                Enable 2FA in Settings to access the platform
              </p>
            )}
          </div>
        ) : (
          <>
            {/* Recents Section */}
            {recentItems.length > 0 && !collapsed && (
              <Collapsible open={recentsOpen} onOpenChange={setRecentsOpen} className="mb-2">
                <CollapsibleTrigger asChild>
                  <button className="flex items-center gap-2 w-full px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider hover:text-foreground transition-colors">
                    <Clock className="w-3.5 h-3.5" />
                    <span className="flex-1 text-left">Recents</span>
                    <ChevronDown className={cn(
                      "w-3.5 h-3.5 transition-transform",
                      recentsOpen ? "" : "-rotate-90"
                    )} />
                  </button>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-0.5">
                  {(recentsExpanded ? recentItems : recentItems.slice(0, 5)).map((item) => (
                    <Link
                      key={`${item.type}-${item.id}`}
                      to={item.path}
                      className={cn(
                        "flex items-center gap-2 w-full px-3 py-1.5 rounded-md text-xs transition-colors",
                        "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                      )}
                    >
                      {item.type === 'account' ? (
                        <Building2 className="w-3.5 h-3.5 shrink-0" />
                      ) : (
                        <Target className="w-3.5 h-3.5 shrink-0" />
                      )}
                      <span className="truncate flex-1">{item.name}</span>
                    </Link>
                  ))}
                  {recentItems.length > 5 && (
                    <button
                      onClick={() => setRecentsExpanded(!recentsExpanded)}
                      className="flex items-center gap-2 w-full px-3 py-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <ChevronDown className={cn(
                        "w-3 h-3 transition-transform",
                        recentsExpanded ? "rotate-180" : ""
                      )} />
                      {recentsExpanded ? 'Show less' : `+${recentItems.length - 5} more`}
                    </button>
                  )}
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      clearRecentItems();
                    }}
                    className="flex items-center gap-2 w-full px-3 py-1 text-xs text-muted-foreground hover:text-destructive transition-colors"
                  >
                    <X className="w-3 h-3" />
                    Clear recents
                  </button>
                </CollapsibleContent>
              </Collapsible>
            )}

            {/* Collapsed recents indicator */}
            {recentItems.length > 0 && collapsed && (
              <div className="flex justify-center py-2 mb-2 border-b border-sidebar-border">
                <Clock className="w-4 h-4 text-muted-foreground" />
              </div>
            )}

            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              const showBadge = item.id === 'momentum' && (momentumMenuCount ?? 0) > 0;
              
              return (
                <Link
                  key={item.id}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 w-full px-3 py-2.5 rounded-lg transition-all duration-200",
                    active 
                      ? "bg-primary/10 text-primary" 
                      : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}
                >
                  <Icon className={cn("w-5 h-5 shrink-0", active && "text-primary")} />
                  {!collapsed && (
                    <span className="font-medium animate-fade-in flex-1 text-left">{item.label}</span>
                  )}
                  {!collapsed && showBadge && (
                    <Badge variant="secondary" className="ml-auto text-xs animate-fade-in">
                      {momentumMenuCount}
                    </Badge>
                  )}
                </Link>
              );
            })}
            
            {/* Configuration Section */}
            <Collapsible open={configOpen || isConfigActive} onOpenChange={setConfigOpen} className="mt-2">
              <CollapsibleTrigger asChild>
                <button className={cn(
                  "flex items-center gap-3 w-full px-3 py-2.5 rounded-lg transition-all duration-200",
                  isConfigActive 
                    ? "bg-primary/10 text-primary" 
                    : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                )}>
                  <Cog className={cn("w-5 h-5 shrink-0", isConfigActive && "text-primary")} />
                  {!collapsed && (
                    <>
                      <span className="font-medium flex-1 text-left">Configuration</span>
                      <ChevronDown className={cn(
                        "w-4 h-4 transition-transform",
                        (configOpen || isConfigActive) ? "" : "-rotate-90"
                      )} />
                    </>
                  )}
                </button>
              </CollapsibleTrigger>
              <CollapsibleContent className="space-y-0.5 ml-4">
                {configItems.map((item) => {
                  const Icon = item.icon;
                  const active = isActive(item.path);
                  
                  return (
                    <Link
                      key={item.id}
                      to={item.path}
                      className={cn(
                        "flex items-center gap-3 w-full px-3 py-2 rounded-lg transition-all duration-200",
                        active 
                          ? "bg-primary/10 text-primary" 
                          : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                      )}
                    >
                      <Icon className={cn("w-4 h-4 shrink-0", active && "text-primary")} />
                      {!collapsed && (
                        <span className="text-sm animate-fade-in flex-1 text-left">{item.label}</span>
                      )}
                    </Link>
                  );
                })}
              </CollapsibleContent>
            </Collapsible>
          </>
        )}
      </nav>

      {/* User & Settings */}
      <div className="p-3 border-t border-sidebar-border space-y-1">
        {/* User info */}
        {user && !collapsed && (
          <div className="px-3 py-2 mb-2">
            <div className="flex items-center gap-2 text-sm">
              <User className="w-4 h-4 text-muted-foreground" />
              <span className="text-muted-foreground truncate text-xs">
                {user.email}
              </span>
            </div>
          </div>
        )}
        
        <Link
          to="/settings"
          className={cn(
            "flex items-center gap-3 w-full px-3 py-2.5 rounded-lg transition-all duration-200 relative",
            isActive('/settings') 
              ? "bg-primary/10 text-primary" 
              : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
          )}
        >
          <div className="relative shrink-0">
            <Settings className="w-5 h-5" />
            {isAdmin && pendingUsersCount && pendingUsersCount > 0 && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-yellow-500 rounded-full animate-pulse" />
            )}
          </div>
          {!collapsed && (
            <>
              <span className="font-medium flex-1 text-left whitespace-nowrap">Settings</span>
              {isAdmin && pendingUsersCount !== undefined && pendingUsersCount > 0 && (
                <Badge className="text-xs bg-yellow-500/20 text-yellow-500 border-yellow-500/30 shrink-0">
                  <AlertCircle className="w-3 h-3 mr-1" />
                  {pendingUsersCount}
                </Badge>
              )}
            </>
          )}
        </Link>

        <button
          onClick={() => signOut()}
          className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg transition-all duration-200 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
        >
          <LogOut className="w-5 h-5 shrink-0" />
          {!collapsed && <span className="font-medium">Sign Out</span>}
        </button>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCollapsed(!collapsed)}
          className="w-full justify-center"
        >
          {collapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <>
              <ChevronLeft className="w-4 h-4" />
              <span>Collapse</span>
            </>
          )}
        </Button>
      </div>
    </aside>
  );
}
import { forwardRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { format } from 'date-fns';
import { MAPCoverPage } from './sections/MAPCoverPage';
import { MAPExecutiveSummary } from './sections/MAPExecutiveSummary';
import { MAPCurrentArchitecture } from './sections/MAPCurrentArchitecture';
import { MAPFutureState } from './sections/MAPFutureState';
import { MAPUseCases } from './sections/MAPUseCases';
import { MAPPriorityRadar } from './sections/MAPPriorityRadar';
import { MAPMilestones } from './sections/MAPMilestones';
import { MAPTechnicalReadiness } from './sections/MAPTechnicalReadiness';
import { MAPValidationTasks } from './sections/MAPValidationTasks';
import { MAPAccountInsights } from './sections/MAPAccountInsights';
import { MAPCompetitors } from './sections/MAPCompetitors';
import { MAPActions } from './sections/MAPActions';
import { MAPStakeholderMap } from './sections/MAPStakeholderMap';
import { MAPActivitySignals } from './sections/MAPActivitySignals';
import { MAPEvaluationPlan } from './sections/MAPEvaluationPlan';

interface MAPDocumentProps {
  accountId: string;
  accountName: string;
  selectedSections: Set<string>;
  prospectLogoUrl?: string;
  opportunityId?: string; // Optional specific opportunity
}

// Landscape A4 page dimensions for PDF (in pixels at 96 DPI)
const PAGE_WIDTH = 1123;
const PAGE_HEIGHT = 794;

export const MAPDocument = forwardRef<HTMLDivElement, MAPDocumentProps>(
  ({ accountId, accountName, selectedSections, prospectLogoUrl, opportunityId }, ref) => {
    // Fetch account data - staleTime: 0 ensures fresh data for each export
    const { data: account } = useQuery({
      queryKey: ['map-account', accountId],
      queryFn: async () => {
        const { data, error } = await supabase
          .from('accounts')
          .select('*')
          .eq('id', accountId)
          .single();
        if (error) throw error;
        return data;
      },
      staleTime: 0,
    });

    // Fetch technologies
    const { data: technologies = [] } = useQuery({
      queryKey: ['map-technologies', accountId],
      queryFn: async () => {
        const result = await gateway
          .from('account_technologies')
          .select('*')
          .eq('account_id', accountId)
          .execute();
        if (result.error) throw new Error(getErrorMessage(result.error));
        return result.data || [];
      },
      staleTime: 0,
    });

    // Fetch use cases (all for account, with opportunity filter option) - use gateway for decryption
    const { data: useCases = [] } = useQuery({
      queryKey: ['map-use-cases', accountId, opportunityId],
      queryFn: async () => {
        const { data, error } = await gateway
          .from('account_use_cases')
          .select('*')
          .eq('account_id', accountId)
          .order('priority', { ascending: true })
          .execute();
        
        if (error) throw new Error(getErrorMessage(error));
        return data || [];
      },
      staleTime: 0,
    });

    // Fetch opportunities for milestones
    const { data: opportunities = [] } = useQuery({
      queryKey: ['map-opportunities', accountId],
      queryFn: async () => {
        const { data, error } = await supabase
          .from('opportunities')
          .select('id, name, created_at')
          .eq('account_id', accountId);
        if (error) throw error;
        return data;
      },
      staleTime: 0,
    });

    // Use provided opportunityId or primary opportunity
    const primaryOpportunityId = opportunityId || opportunities[0]?.id;

    // Fetch milestones for primary opportunity
    const { data: milestones = [] } = useQuery({
      queryKey: ['map-milestones', primaryOpportunityId],
      queryFn: async () => {
        if (!primaryOpportunityId) return [];
        const result = await gateway
          .from('opportunity_milestones')
          .select('*')
          .eq('opportunity_id', primaryOpportunityId)
          .order('sort_order')
          .execute();
        if (result.error) throw new Error(getErrorMessage(result.error));
        return result.data || [];
      },
      enabled: !!primaryOpportunityId,
      staleTime: 0,
    });

    // Fetch milestone templates for default timeline
    const { data: milestoneTemplates = [] } = useQuery({
      queryKey: ['map-milestone-templates'],
      queryFn: async () => {
        const { data, error } = await supabase
          .from('milestone_templates')
          .select('*')
          .order('sort_order');
        if (error) throw error;
        return data;
      },
      staleTime: 0,
    });

    // Fetch readiness categories with questions
    const { data: readinessCategories = [] } = useQuery({
      queryKey: ['map-readiness-categories'],
      queryFn: async () => {
        const { data: categories, error: catError } = await supabase
          .from('readiness_template_categories')
          .select('*')
          .order('sort_order');
        if (catError) throw catError;
        if (!categories || categories.length === 0) return [];

        const categoryIds = categories.map(c => c.id);
        const { data: questions, error: qError } = await supabase
          .from('readiness_template_questions')
          .select('*')
          .in('category_id', categoryIds)
          .order('sort_order');
        if (qError) throw qError;

        return categories.map(cat => ({
          ...cat,
          questions: (questions || []).filter(q => q.category_id === cat.id),
        }));
      },
      staleTime: 0,
    });

    // Fetch readiness answers for primary opportunity
    const { data: readinessAnswers = [] } = useQuery({
      queryKey: ['map-readiness-answers', primaryOpportunityId],
      queryFn: async () => {
        if (!primaryOpportunityId) return [];
        const result = await gateway
          .from('opportunity_readiness_answers')
          .select('*')
          .eq('opportunity_id', primaryOpportunityId)
          .execute();
        if (result.error) throw new Error(getErrorMessage(result.error));
        return result.data || [];
      },
      enabled: !!primaryOpportunityId,
      staleTime: 0,
    });

    // Fetch validation tasks for primary opportunity
    const { data: validationTasks = [] } = useQuery({
      queryKey: ['map-validation-tasks', primaryOpportunityId],
      queryFn: async () => {
        if (!primaryOpportunityId) return [];
        const { data, error } = await supabase
          .from('opportunity_validation_tasks')
          .select('*')
          .eq('opportunity_id', primaryOpportunityId)
          .order('sort_order');
        if (error) throw error;
        return data;
      },
      enabled: !!primaryOpportunityId,
      staleTime: 0,
    });

    // Fetch validation task templates for default
    const { data: validationTemplates = [] } = useQuery({
      queryKey: ['map-validation-templates'],
      queryFn: async () => {
        const { data, error } = await supabase
          .from('validation_task_templates')
          .select('*')
          .order('sort_order');
        if (error) throw error;
        return data;
      },
      staleTime: 0,
    });

    // Fetch team members
    const { data: teamMembers = [] } = useQuery({
      queryKey: ['map-team', accountId],
      queryFn: async () => {
        const result = await gateway
          .from('account_team_members')
          .select('*')
          .eq('account_id', accountId)
          .execute();
        if (result.error) throw new Error(getErrorMessage(result.error));
        return result.data || [];
      },
      staleTime: 0,
    });

    // Fetch contacts - use gateway for decryption
    const { data: contacts = [] } = useQuery({
      queryKey: ['map-contacts', accountId],
      queryFn: async () => {
        const { data, error } = await gateway
          .from('account_contacts')
          .select('*')
          .eq('account_id', accountId)
          .eq('is_internal', false)
          .not('is_ignored', 'is', true)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        return data || [];
      },
      staleTime: 0,
    });

    // Fetch functional areas for architecture
    const { data: functionalAreas = [] } = useQuery({
      queryKey: ['map-functional-areas'],
      queryFn: async () => {
        const { data, error } = await supabase
          .from('functional_areas')
          .select('*')
          .order('layer')
          .order('sort_order');
        if (error) throw error;
        return data;
      },
      staleTime: 0,
    });

    // Fetch layers
    const { data: layers = [] } = useQuery({
      queryKey: ['map-layers'],
      queryFn: async () => {
        const { data, error } = await supabase
          .from('layers')
          .select('*')
          .order('sort_order');
        if (error) throw error;
        return data;
      },
      staleTime: 0,
    });

    // NEW: Fetch pain points
    const { data: painPoints = [] } = useQuery({
      queryKey: ['map-pain-points', accountId],
      queryFn: async () => {
        const { data, error } = await gateway
          .from('account_pain_points')
          .select('*')
          .eq('account_id', accountId)
          .order('severity')
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        return data || [];
      },
      staleTime: 0,
    });

    // NEW: Fetch metrics
    const { data: metrics = [] } = useQuery({
      queryKey: ['map-metrics', accountId],
      queryFn: async () => {
        const { data, error } = await gateway
          .from('account_metrics')
          .select('*')
          .eq('account_id', accountId)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        return data || [];
      },
      staleTime: 0,
    });

    // NEW: Fetch strategic themes
    const { data: strategicThemes = [] } = useQuery({
      queryKey: ['map-strategic-themes', accountId],
      queryFn: async () => {
        const { data, error } = await gateway
          .from('account_strategic_themes')
          .select('*')
          .eq('account_id', accountId)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        return data || [];
      },
      staleTime: 0,
    });

    // NEW: Fetch exec summary
    const { data: execSummary } = useQuery({
      queryKey: ['map-exec-summary', accountId],
      queryFn: async () => {
        const { data, error } = await gateway
          .from('account_exec_summaries')
          .select('*')
          .eq('account_id', accountId)
          .maybeSingle()
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        return data;
      },
      staleTime: 0,
    });

    // NEW: Fetch account competitors (from product_mentions with mention_type = 'competitive')
    const { data: accountCompetitors = [] } = useQuery({
      queryKey: ['map-account-competitors', accountId],
      queryFn: async () => {
        const { data, error } = await gateway
          .from('product_mentions')
          .select('id, product_name, confidence_score, created_at')
          .eq('account_id', accountId)
          .eq('mention_type', 'competitive')
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        // Dedupe by product name and return formatted
        const uniqueCompetitors = new Map<string, any>();
        (data || []).forEach((c: any) => {
          const name = c.product_name?.toLowerCase();
          if (name && !uniqueCompetitors.has(name)) {
            uniqueCompetitors.set(name, {
              id: c.id,
              competitor_id: c.id,
              competitor_name: c.product_name,
              detected_at: c.created_at,
              threat_level: c.confidence_score >= 0.8 ? 'high' : c.confidence_score >= 0.5 ? 'medium' : 'low',
            });
          }
        });
        return Array.from(uniqueCompetitors.values());
      },
      staleTime: 0,
    });

    // NEW: Fetch NBAs (combined account + opportunity)
    const { data: nbas = [] } = useQuery({
      queryKey: ['map-nbas', accountId],
      queryFn: async () => {
        const { data, error } = await gateway
          .from('account_nbas')
          .select('*')
          .eq('account_id', accountId)
          .order('created_at', { ascending: false })
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        
        // Add opportunity names
        const oppMap = new Map(opportunities.map((o: any) => [o.id, o.name]));
        return (data || []).map((n: any) => ({
          ...n,
          opportunity_name: n.opportunity_id ? oppMap.get(n.opportunity_id) || 'Unknown' : 'Account Level',
        }));
      },
      staleTime: 0,
    });

    // NEW: Fetch activities
    const { data: activities = [] } = useQuery({
      queryKey: ['map-activities', accountId],
      queryFn: async () => {
        const { data, error } = await gateway
          .from('opportunity_activities')
          .select('*, activity_type:activity_types(*)')
          .eq('account_id', accountId)
          .order('activity_date', { ascending: false })
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        return data || [];
      },
      staleTime: 0,
    });

    // Fetch competitive plays for evaluation plan
    const { data: competitivePlays = [] } = useQuery({
      queryKey: ['map-competitive-plays', primaryOpportunityId],
      queryFn: async () => {
        if (!primaryOpportunityId) return [];
        const { data, error } = await gateway
          .from('competitive_play_suggestions')
          .select('*')
          .eq('opportunity_id', primaryOpportunityId)
          .neq('status', 'dismissed')
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        return (data || []).map((p: any) => ({
          id: p.id,
          playType: p.play_type,
          playStrategy: p.play_strategy,
          playTitle: p.play_title,
          playDescription: p.play_description,
          talkingPoints: p.talking_points || [],
          competitorName: p.competitor_id ? null : null, // resolved below if needed
          linkedUseCaseIds: p.linked_use_case_ids || [],
        }));
      },
      enabled: !!primaryOpportunityId,
      staleTime: 0,
    });

    // NEW: Fetch signals for the opportunity
    const { data: signalsData } = useQuery({
      queryKey: ['map-signals', primaryOpportunityId],
      queryFn: async () => {
        if (!primaryOpportunityId) return { signals: [], signalTypes: [] };
        
        // Fetch activity signal rules
        const { data: rules, error: rulesError } = await supabase
          .from('detection_rules')
          .select('id, name, signal_field_name')
          .eq('tree_id', 'f5e4d3c2-b1a0-9876-5432-fedcba098765')
          .eq('is_active', true)
          .order('sort_order');
        
        if (rulesError) throw rulesError;
        
        const ruleIds = (rules || []).map((r: any) => r.id);
        const signalColors = ['#8B5CF6', '#F97316', '#0EA5E9', '#10B981', '#EF4444', '#F59E0B', '#EC4899', '#6366F1'];
        
        const signalTypes = (rules || []).map((rule: any, i: number) => ({
          id: rule.id,
          name: rule.name.replace(' Signals', '').replace(' Signal', ''),
          key: rule.signal_field_name || rule.name.toLowerCase().replace(/\s+/g, '_'),
          color: signalColors[i % signalColors.length],
        }));
        
        // Fetch matches
        const { data: matches, error: matchesError } = await gateway
          .from('detection_rule_matches')
          .select('*')
          .eq('opportunity_id', primaryOpportunityId)
          .execute();
        
        if (matchesError) throw new Error(getErrorMessage(matchesError));
        
        const signals = (matches || [])
          .filter((m: any) => ruleIds.includes(m.rule_id))
          .map((m: any) => {
            const rule = rules?.find((r: any) => r.id === m.rule_id);
            return {
              id: m.id,
              ruleName: (rule?.name || 'Unknown').replace(' Signals', '').replace(' Signal', ''),
              ruleKey: rule?.signal_field_name || (rule?.name || '').toLowerCase().replace(/\s+/g, '_'),
              detectedAt: m.first_detected_at || m.created_at,
              confidenceScore: m.confidence_score || 0,
              matchedPhrases: m.matched_phrases || [],
            };
          });
        
        return { signals, signalTypes };
      },
      enabled: !!primaryOpportunityId,
      staleTime: 0,
    });

    const generatedDate = format(new Date(), 'MMMM d, yyyy');

    // Filter use cases - linked to opportunity + high confidence suggested
    const linkedUseCases = useCases.filter(uc => uc.opportunity_id === primaryOpportunityId);
    const suggestedUseCases = useCases.filter(
      uc => !uc.opportunity_id && (uc.confidence_score || 0) >= 0.7
    );
    const combinedUseCases = [...linkedUseCases, ...suggestedUseCases];

    // Page wrapper component for consistent sizing and page breaks (LANDSCAPE)
    const Page = ({ children, isFirst = false }: { children: React.ReactNode; isFirst?: boolean }) => (
      <div
        style={{
          width: `${PAGE_WIDTH}px`,
          minHeight: `${PAGE_HEIGHT}px`,
          height: `${PAGE_HEIGHT}px`,
          pageBreakAfter: 'always',
          pageBreakInside: 'avoid',
          breakAfter: 'page',
          breakInside: 'avoid',
          overflow: 'hidden',
          position: 'relative',
          boxSizing: 'border-box',
        }}
      >
        {children}
        {/* Page footer */}
        <div 
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            padding: '8px 32px',
            borderTop: '1px solid #e5e7eb',
            backgroundColor: 'white',
            fontSize: '10px',
            color: '#6b7280',
            display: 'flex',
            justifyContent: 'space-between',
          }}
        >
          <span>Generated on {generatedDate}</span>
          <span>Confidential - {accountName}</span>
        </div>
      </div>
    );

    return (
      <div
        ref={ref}
        className="bg-white text-gray-900"
        style={{ 
          fontFamily: 'system-ui, -apple-system, sans-serif',
          width: `${PAGE_WIDTH}px`,
        }}
      >
        {/* Cover Page */}
        <Page isFirst>
          <MAPCoverPage
            accountName={accountName}
            industry={account?.industry}
            generatedDate={generatedDate}
            prospectLogoUrl={prospectLogoUrl}
          />
        </Page>

        {/* Executive Summary */}
        {selectedSections.has('executive-summary') && (
          <Page>
            <MAPExecutiveSummary
              accountName={accountName}
              industry={account?.industry}
              stage={account?.stage}
              arr={account?.arr}
              engagementScore={account?.engagement_score}
              momentumScore={account?.momentum_score}
              relationshipStatus={account?.relationship_status}
              useCasesCount={useCases.length}
              stakeholdersCount={contacts.length}
              painPointsCount={painPoints.length}
              topPainPoints={painPoints.filter(p => p.severity === 'critical' || p.severity === 'high').slice(0, 3)}
              topOpportunities={strategicThemes.filter(t => t.theme_type === 'initiative').slice(0, 3)}
              nextMilestone={milestones.find(m => m.status !== 'completed') || null}
              opportunityCreatedAt={opportunities[0]?.created_at}
              execSummary={execSummary}
            />
          </Page>
        )}

        {/* Account Insights (NEW) */}
        {selectedSections.has('account-insights') && (
          <Page>
            <MAPAccountInsights
              accountName={accountName}
              painPoints={painPoints}
              metrics={metrics}
              strategicThemes={strategicThemes}
              execSummary={execSummary}
              engagementScore={account?.engagement_score}
              momentumScore={account?.momentum_score}
              useCasesCount={useCases.length}
            />
          </Page>
        )}

        {/* Current Architecture */}
        {selectedSections.has('current-architecture') && (
          <Page>
            <MAPCurrentArchitecture
              technologies={technologies}
              functionalAreas={functionalAreas}
              layers={layers}
            />
          </Page>
        )}

        {/* Future State */}
        {selectedSections.has('future-state') && (
          <Page>
            <MAPFutureState
              accountName={accountName}
              painPoints={painPoints}
              strategicThemes={strategicThemes}
              execSummary={execSummary}
            />
          </Page>
        )}

        {/* Competitors (NEW) */}
        {selectedSections.has('competitors') && (
          <Page>
            <MAPCompetitors accountCompetitors={accountCompetitors} />
          </Page>
        )}

        {/* Use Cases */}
        {selectedSections.has('use-cases') && (
          <Page>
            <MAPUseCases useCases={useCases} opportunityId={primaryOpportunityId} />
          </Page>
        )}

        {/* Priority Radar */}
        {selectedSections.has('priority-radar') && (
          <Page>
            <MAPPriorityRadar useCases={useCases} />
          </Page>
        )}

        {/* Stakeholder Map (NEW - enhanced) */}
        {selectedSections.has('stakeholder-map') && (
          <Page>
            <MAPStakeholderMap contacts={contacts} />
          </Page>
        )}

        {/* Actions/NBAs (NEW) */}
        {selectedSections.has('actions') && (
          <Page>
            <MAPActions nbas={nbas} />
          </Page>
        )}

        {/* Technical Readiness */}
        {selectedSections.has('technical-readiness') && (
          <Page>
            <MAPTechnicalReadiness 
              categories={readinessCategories} 
              answers={readinessAnswers} 
            />
          </Page>
        )}

        {/* Milestones */}
        {selectedSections.has('milestones') && (
          <Page>
            <MAPMilestones 
              milestones={milestones} 
              templates={milestoneTemplates}
            />
          </Page>
        )}

        {/* Validation Tasks */}
        {selectedSections.has('validation-tasks') && (
          <Page>
            <MAPValidationTasks 
              tasks={validationTasks}
              templates={validationTemplates}
            />
          </Page>
        )}

        {/* Activity Signals (NEW) */}
        {selectedSections.has('activity-signals') && (
          <Page>
            <MAPActivitySignals 
              activities={activities}
              signals={signalsData?.signals || []}
              signalTypes={signalsData?.signalTypes || []}
            />
          </Page>
        )}

        {/* Evaluation Plan */}
        {selectedSections.has('evaluation-plan') && (
          <Page>
            <MAPEvaluationPlan
              accountName={accountName}
              painPoints={painPoints}
              useCases={combinedUseCases}
              metrics={metrics}
              competitors={accountCompetitors}
              competitivePlays={competitivePlays}
              opportunityId={primaryOpportunityId}
            />
          </Page>
        )}
      </div>
    );
  }
);

MAPDocument.displayName = 'MAPDocument';

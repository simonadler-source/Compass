import { useMemo } from 'react';
import { Brain, TrendingUp, AlertTriangle, Users, Heart, Activity, Sparkles } from 'lucide-react';


interface PainPoint {
  id: string;
  pain_point: string;
  severity: string;
  pain_category?: string | null;
  business_impact?: string[] | null;
  confidence_score?: number | null;
  business_theme?: string | null;
}

interface StrategicTheme {
  id: string;
  theme_name: string;
  theme_type: string;
  description?: string | null;
  impact_level?: string | null;
  item_count?: number | null;
  supporting_evidence?: { items?: string[] } | null;
}

interface ExecSummary {
  summary_narrative?: string | null;
  key_risks?: string[] | null;
  key_opportunities?: string[] | null;
  health_indicators?: Record<string, string> | null;
}

interface MAPAccountInsightsProps {
  accountName: string;
  painPoints: PainPoint[];
  metrics: { id: string; metric_name: string; metric_value: string | null; metric_category: string }[];
  strategicThemes: StrategicTheme[];
  execSummary?: ExecSummary | null;
  engagementScore?: number | null;
  momentumScore?: number | null;
  useCasesCount?: number;
}

// Match the synthesis-to-score mapping from useAccountHealthMetrics
const ENGAGEMENT_LEVEL_SCORES: Record<string, number> = {
  'high': 85, 'moderate': 55, 'low': 25,
  'improving': 80, 'stable': 55, 'declining': 25,
};
const MOMENTUM_LEVEL_SCORES: Record<string, number> = {
  'accelerating': 85, 'steady': 55, 'stalled': 30, 'declining': 15,
};
const RELATIONSHIP_STATUS_MAP: Record<string, string> = {
  'strong': 'Champion', 'stable': 'Warm', 'at_risk': 'At Risk', 'critical': 'Cold',
};

function getScoreLabel(score: number | null | undefined, type: 'engagement' | 'momentum'): { label: string; color: string; bg: string } {
  if (score === null || score === undefined) return { label: 'Baseline', color: '#6b7280', bg: '#f3f4f6' };
  if (type === 'engagement') {
    if (score >= 70) return { label: 'Strong', color: '#16a34a', bg: '#dcfce7' };
    if (score >= 40) return { label: 'Warm', color: '#f59e0b', bg: '#fef3c7' };
    return { label: 'Cold', color: '#dc2626', bg: '#fef2f2' };
  }
  // momentum
  if (score >= 70) return { label: 'Champion', color: '#7c3aed', bg: '#f3e8ff' };
  if (score >= 40) return { label: 'Growing', color: '#2563eb', bg: '#dbeafe' };
  return { label: 'Starting', color: '#6b7280', bg: '#f3f4f6' };
}

export function MAPAccountInsights({ 
  accountName, 
  painPoints, 
  metrics, 
  strategicThemes, 
  execSummary,
  engagementScore,
  momentumScore,
  useCasesCount = 0
}: MAPAccountInsightsProps) {
  // Derive scores from synthesis if account values are null (matching useAccountHealthMetrics logic)
  const derivedScores = useMemo(() => {
    const hi = execSummary?.health_indicators as Record<string, string> | null;
    
    // Engagement: account value -> synthesis fallback
    let eng = engagementScore ?? null;
    if (eng === null && hi) {
      const key = hi.engagementTrend || hi.engagementLevel;
      if (key) eng = ENGAGEMENT_LEVEL_SCORES[key] ?? null;
    }
    
    // Momentum: account value -> synthesis fallback
    let mom = momentumScore ?? null;
    if (mom === null && hi?.opportunityMomentum) {
      mom = MOMENTUM_LEVEL_SCORES[hi.opportunityMomentum] ?? null;
    }
    
    // Relationship: synthesis -> mapped label
    let rel = 'Champion';
    if (hi?.relationshipHealth) {
      rel = RELATIONSHIP_STATUS_MAP[hi.relationshipHealth] || hi.relationshipHealth;
    }
    
    return { engagement: eng, momentum: mom, relationship: rel };
  }, [engagementScore, momentumScore, execSummary]);

  const engagementInfo = getScoreLabel(derivedScores.engagement, 'engagement');
  const momentumInfo = getScoreLabel(derivedScores.momentum, 'momentum');

  // Separate themes into challenges (pain_theme) and initiatives
  const challenges = strategicThemes.filter(t => t.theme_type === 'pain_theme');
  const initiatives = strategicThemes.filter(t => t.theme_type === 'initiative');

  return (
    <div className="p-8 h-full flex flex-col pb-12">
      {/* Section Header */}
      <div className="flex items-start justify-between mb-5">
        <div className="flex items-center gap-3">
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ backgroundColor: '#8b5cf620' }}
          >
            <Brain className="w-5 h-5" style={{ color: '#8b5cf6' }} />
          </div>
          <h2 className="text-xl font-bold text-gray-900">Account Intelligence</h2>
        </div>
        
        <div className="text-xs text-gray-500">
          {painPoints.length} pain points • {useCasesCount} use cases
        </div>
      </div>

      {/* Metric Cards Row - Matching screenshot style */}
      <div className="grid grid-cols-3 gap-4 mb-5">
        {/* Engagement */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-gray-400" />
              <span className="text-xs text-gray-600">Engagement</span>
            </div>
            <span 
              className="text-[10px] px-2 py-0.5 rounded-full font-medium"
              style={{ backgroundColor: '#dbeafe', color: '#2563eb' }}
            >
              Baseline
            </span>
          </div>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-3xl font-bold text-gray-900">{derivedScores.engagement !== null ? `${derivedScores.engagement}%` : '—'}</p>
              <span 
                className="text-xs px-2 py-0.5 rounded-full font-medium mt-1 inline-block"
                style={{ backgroundColor: engagementInfo.bg, color: engagementInfo.color }}
              >
                {engagementInfo.label}
              </span>
            </div>
            {/* Mini sparkline placeholder */}
            <div className="w-20 h-8 flex items-end gap-0.5">
              {[40, 55, 45, 60, 50, 55].map((h, i) => (
                <div key={i} className="flex-1 bg-gray-200 rounded-t" style={{ height: `${h}%` }} />
              ))}
            </div>
          </div>
        </div>

        {/* Momentum */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-gray-400" />
              <span className="text-xs text-gray-600">Momentum</span>
            </div>
            <span 
              className="text-[10px] px-2 py-0.5 rounded-full font-medium"
              style={{ backgroundColor: '#dbeafe', color: '#2563eb' }}
            >
              Baseline
            </span>
          </div>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-3xl font-bold text-gray-900">{derivedScores.momentum !== null ? `${derivedScores.momentum}%` : '—'}</p>
              <span 
                className="text-xs px-2 py-0.5 rounded-full font-medium mt-1 inline-block"
                style={{ backgroundColor: momentumInfo.bg, color: momentumInfo.color }}
              >
                {momentumInfo.label}
              </span>
            </div>
            <div className="w-20 h-8 flex items-end gap-0.5">
              {[50, 65, 70, 75, 80, 85].map((h, i) => (
                <div key={i} className="flex-1 bg-purple-200 rounded-t" style={{ height: `${h}%` }} />
              ))}
            </div>
          </div>
        </div>

        {/* Relationship */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Heart className="w-4 h-4 text-gray-400" />
              <span className="text-xs text-gray-600">Relationship</span>
            </div>
            <span 
              className="text-[10px] px-2 py-0.5 rounded-full font-medium"
              style={{ backgroundColor: '#dbeafe', color: '#2563eb' }}
            >
              Baseline
            </span>
          </div>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-900">{derivedScores.relationship}</p>
              <span 
                className="text-xs px-2 py-0.5 rounded-full font-medium mt-1 inline-block"
                style={{ 
                  backgroundColor: derivedScores.relationship === 'At Risk' ? '#fef2f2' : 
                    derivedScores.relationship === 'Cold' ? '#f3f4f6' : '#dcfce7',
                  color: derivedScores.relationship === 'At Risk' ? '#dc2626' : 
                    derivedScores.relationship === 'Cold' ? '#6b7280' : '#16a34a'
                }}
              >
                {derivedScores.relationship}
              </span>
            </div>
            <div className="w-20 h-8 flex items-end gap-0.5">
              {[60, 70, 75, 80, 85, 90].map((h, i) => (
                <div key={i} className="flex-1 bg-green-200 rounded-t" style={{ height: `${h}%` }} />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* AI Narrative */}
      {execSummary?.summary_narrative && (
        <div className="bg-gradient-to-r from-gray-50 to-white rounded-xl p-4 mb-5 border border-gray-200">
          <p className="text-sm text-gray-700 leading-relaxed">
            {execSummary.summary_narrative}
          </p>
        </div>
      )}

      {/* Key Risks & Opportunities Row */}
      <div className="grid grid-cols-2 gap-4 mb-5">
        {/* Key Risks */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4 text-red-500" />
            <span className="text-xs font-semibold text-red-600 uppercase tracking-wide">Key Risks</span>
          </div>
          <ul className="space-y-1.5">
            {(execSummary?.key_risks || []).slice(0, 3).map((risk, i) => (
              <li key={i} className="text-xs text-gray-700 flex items-start gap-2">
                <span className="text-red-400 mt-0.5">•</span>
                <span>{risk}</span>
              </li>
            ))}
            {(!execSummary?.key_risks || execSummary.key_risks.length === 0) && (
              <li className="text-xs text-gray-400 italic">No key risks identified</li>
            )}
          </ul>
        </div>

        {/* Key Opportunities */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-green-500" />
            <span className="text-xs font-semibold text-green-600 uppercase tracking-wide">Key Opportunities</span>
          </div>
          <ul className="space-y-1.5">
            {(execSummary?.key_opportunities || []).slice(0, 3).map((opp, i) => (
              <li key={i} className="text-xs text-gray-700 flex items-start gap-2">
                <span className="text-green-400 mt-0.5">•</span>
                <span>{opp}</span>
              </li>
            ))}
            {(!execSummary?.key_opportunities || execSummary.key_opportunities.length === 0) && (
              <li className="text-xs text-gray-400 italic">No key opportunities identified</li>
            )}
          </ul>
        </div>
      </div>

      {/* Strategic Themes - Two Column Layout */}
      <div className="grid grid-cols-2 gap-4 flex-1 overflow-hidden">
        {/* Left Column: Strategic Challenges */}
        <div className="flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-red-500" />
            <span className="text-sm font-semibold text-gray-900">Strategic Challenges ({challenges.length})</span>
          </div>
          
          <div className="space-y-2 overflow-auto flex-1">
            {challenges.map(theme => {
              const severityColor = theme.impact_level === 'critical' ? '#dc2626' : 
                                    theme.impact_level === 'high' ? '#f59e0b' : '#6b7280';
              const evidence = (theme.supporting_evidence as any)?.items || [];
              
              return (
                <div 
                  key={theme.id} 
                  className="rounded-lg border overflow-hidden bg-red-50"
                  style={{ borderColor: `${severityColor}30` }}
                >
                  <div className="p-3">
                    <div className="flex items-start gap-2 mb-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" style={{ color: severityColor }} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-semibold text-gray-900">{theme.theme_name}</span>
                          {theme.impact_level && (
                            <span 
                              className="text-[9px] px-1.5 py-0.5 rounded font-medium uppercase"
                              style={{ backgroundColor: `${severityColor}20`, color: severityColor }}
                            >
                              {theme.impact_level}
                            </span>
                          )}
                        </div>
                        {theme.description && (
                          <p className="text-[11px] text-gray-600 mt-1 leading-snug">{theme.description}</p>
                        )}
                      </div>
                    </div>
                    
                    {/* Always show evidence if available */}
                    {evidence.length > 0 && (
                      <div className="mt-2 pt-2 border-t border-red-100">
                        <p className="text-[9px] text-gray-500 uppercase font-semibold mb-1.5">Evidence</p>
                        <ul className="space-y-1">
                          {evidence.slice(0, 3).map((item: string, i: number) => (
                            <li key={i} className="text-[10px] text-gray-700 flex items-start gap-1.5">
                              <span className="text-red-400 mt-0.5">•</span>
                              <span className="leading-snug">{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            
            {challenges.length === 0 && (
              <div className="text-center py-6 text-gray-400 bg-gray-50 rounded-lg border border-gray-200">
                <AlertTriangle className="w-6 h-6 mx-auto mb-1.5 opacity-40" />
                <p className="text-[10px]">No strategic challenges identified</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Strategic Initiatives */}
        <div className="flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-green-500" />
            <span className="text-sm font-semibold text-gray-900">Strategic Initiatives ({initiatives.length})</span>
          </div>
          
          <div className="space-y-2 overflow-auto flex-1">
            {initiatives.map(theme => {
              const evidence = (theme.supporting_evidence as any)?.items || [];
              
              return (
                <div 
                  key={theme.id} 
                  className="rounded-lg border border-green-200 overflow-hidden bg-green-50"
                >
                  <div className="p-3">
                    <div className="flex items-start gap-2 mb-1.5">
                      <Sparkles className="w-3.5 h-3.5 shrink-0 mt-0.5 text-green-500" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-semibold text-gray-900">{theme.theme_name}</span>
                          {theme.impact_level && (
                            <span className="text-[9px] px-1.5 py-0.5 rounded font-medium uppercase bg-green-100 text-green-700">
                              {theme.impact_level}
                            </span>
                          )}
                        </div>
                        {theme.description && (
                          <p className="text-[11px] text-gray-600 mt-1 leading-snug">{theme.description}</p>
                        )}
                      </div>
                    </div>
                    
                    {/* Always show evidence if available */}
                    {evidence.length > 0 && (
                      <div className="mt-2 pt-2 border-t border-green-100">
                        <p className="text-[9px] text-gray-500 uppercase font-semibold mb-1.5">Evidence</p>
                        <ul className="space-y-1">
                          {evidence.slice(0, 3).map((item: string, i: number) => (
                            <li key={i} className="text-[10px] text-gray-700 flex items-start gap-1.5">
                              <span className="text-green-400 mt-0.5">•</span>
                              <span className="leading-snug">{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            
            {initiatives.length === 0 && (
              <div className="text-center py-6 text-gray-400 bg-gray-50 rounded-lg border border-gray-200">
                <Sparkles className="w-6 h-6 mx-auto mb-1.5 opacity-40" />
                <p className="text-[10px]">No strategic initiatives identified</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
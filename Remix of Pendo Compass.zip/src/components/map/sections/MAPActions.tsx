import { CheckSquare, Clock, AlertCircle, User, Calendar } from 'lucide-react';
import { format } from 'date-fns';

interface NBA {
  id: string;
  action: string;
  action_type: string;
  priority: string | null;
  status: string | null;
  due_date: string | null;
  assigned_to: string | null;
  notes: string | null;
  opportunity_name?: string;
}

interface MAPActionsProps {
  nbas: NBA[];
  showOpportunityName?: boolean;
}

const PRIORITY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  high: { bg: '#fef2f2', text: '#dc2626', border: '#fecaca' },
  medium: { bg: '#fffbeb', text: '#d97706', border: '#fde68a' },
  low: { bg: '#f0fdf4', text: '#16a34a', border: '#bbf7d0' },
};

const STATUS_ICONS: Record<string, { icon: React.ElementType; color: string }> = {
  pending: { icon: Clock, color: '#f59e0b' },
  in_progress: { icon: AlertCircle, color: '#3b82f6' },
  completed: { icon: CheckSquare, color: '#16a34a' },
  cancelled: { icon: CheckSquare, color: '#6b7280' },
};

const ACTION_TYPE_LABELS: Record<string, string> = {
  follow_up_meeting: 'Follow-up Meeting',
  send_content: 'Send Content',
  poc_setup: 'POC Setup',
  technical_deepdive: 'Technical Deep-dive',
  security_assessment: 'Security Assessment',
  architecture_doc: 'Architecture Doc',
  integration_review: 'Integration Review',
  api_exploration: 'API Exploration',
  performance_benchmark: 'Performance Benchmark',
  internal_discussion: 'Internal Discussion',
  follow_up: 'Follow Up',
};

export function MAPActions({ nbas, showOpportunityName = true }: MAPActionsProps) {
  // Separate by status
  const pending = nbas.filter(n => n.status === 'pending' || n.status === 'in_progress');
  const completed = nbas.filter(n => n.status === 'completed');

  // Sort pending by priority then due date
  const priorityOrder: Record<string, number> = { high: 0, medium: 1, low: 2 };
  pending.sort((a, b) => {
    const aPri = priorityOrder[a.priority || 'medium'] ?? 1;
    const bPri = priorityOrder[b.priority || 'medium'] ?? 1;
    if (aPri !== bPri) return aPri - bPri;
    if (a.due_date && b.due_date) return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
    return 0;
  });

  return (
    <div className="p-10 h-full flex flex-col pb-16">
      {/* Section Header */}
      <div className="flex items-center gap-3 mb-6">
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: '#3b82f620' }}
        >
          <CheckSquare className="w-5 h-5" style={{ color: '#3b82f6' }} />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Next Best Actions</h2>
          <p className="text-sm text-gray-500">{pending.length} pending · {completed.length} completed</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 flex-1">
        {/* Pending Actions */}
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900 flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-600" />
            Pending Actions ({pending.length})
          </h3>
          
          <div className="space-y-2 max-h-[420px] overflow-hidden">
            {pending.length === 0 ? (
              <div className="bg-gray-50 rounded-lg p-4 text-center">
                <p className="text-sm text-gray-500">No pending actions</p>
              </div>
            ) : (
              pending.slice(0, 10).map(nba => {
                const colors = PRIORITY_COLORS[nba.priority || 'medium'] || PRIORITY_COLORS.medium;
                const statusInfo = STATUS_ICONS[nba.status || 'pending'] || STATUS_ICONS.pending;
                const StatusIcon = statusInfo.icon;
                const isOverdue = nba.due_date && new Date(nba.due_date) < new Date();

                return (
                  <div 
                    key={nba.id}
                    className="bg-white border rounded-lg p-3"
                    style={{ borderLeftWidth: 4, borderLeftColor: colors.text }}
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex-1">
                        <p className="text-xs font-medium text-gray-900">{nba.action}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[9px] text-gray-500">
                            {ACTION_TYPE_LABELS[nba.action_type] || nba.action_type}
                          </span>
                          {showOpportunityName && nba.opportunity_name && (
                            <span className="text-[9px] text-blue-600">• {nba.opportunity_name}</span>
                          )}
                        </div>
                      </div>
                      <span 
                        className="text-[8px] font-medium px-1.5 py-0.5 rounded uppercase shrink-0"
                        style={{ backgroundColor: colors.bg, color: colors.text }}
                      >
                        {nba.priority || 'medium'}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-[9px] text-gray-500">
                      {nba.assigned_to && (
                        <div className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          <span className="truncate max-w-[100px]">{nba.assigned_to}</span>
                        </div>
                      )}
                      {nba.due_date && (
                        <div className={`flex items-center gap-1 ${isOverdue ? 'text-red-600 font-medium' : ''}`}>
                          <Calendar className="w-3 h-3" />
                          <span>{format(new Date(nba.due_date), 'MMM d')}</span>
                          {isOverdue && <span className="text-[8px]">(overdue)</span>}
                        </div>
                      )}
                      <StatusIcon className="w-3 h-3 ml-auto" style={{ color: statusInfo.color }} />
                    </div>
                  </div>
                );
              })
            )}
            {pending.length > 10 && (
              <p className="text-[10px] text-gray-500 text-center">+{pending.length - 10} more actions</p>
            )}
          </div>
        </div>

        {/* Completed Actions */}
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900 flex items-center gap-2">
            <CheckSquare className="w-4 h-4 text-green-600" />
            Completed ({completed.length})
          </h3>
          
          <div className="space-y-2 max-h-[420px] overflow-hidden">
            {completed.length === 0 ? (
              <div className="bg-gray-50 rounded-lg p-4 text-center">
                <p className="text-sm text-gray-500">No completed actions yet</p>
              </div>
            ) : (
              completed.slice(0, 12).map(nba => (
                <div 
                  key={nba.id}
                  className="bg-green-50 border border-green-200 rounded-lg p-2.5"
                >
                  <div className="flex items-center gap-2">
                    <CheckSquare className="w-3.5 h-3.5 text-green-600 shrink-0" />
                    <p className="text-[10px] text-green-800 flex-1">{nba.action}</p>
                  </div>
                  <div className="flex items-center gap-2 mt-1 ml-5">
                    <span className="text-[8px] text-green-600">
                      {ACTION_TYPE_LABELS[nba.action_type] || nba.action_type}
                    </span>
                    {showOpportunityName && nba.opportunity_name && (
                      <span className="text-[8px] text-green-700">• {nba.opportunity_name}</span>
                    )}
                  </div>
                </div>
              ))
            )}
            {completed.length > 12 && (
              <p className="text-[10px] text-gray-500 text-center">+{completed.length - 12} more completed</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

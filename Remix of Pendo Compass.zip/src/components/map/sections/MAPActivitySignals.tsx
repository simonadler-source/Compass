import { Activity, Zap, Calendar, TrendingUp, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';

interface ActivityItem {
  id: string;
  activity_date: string;
  title: string | null;
  activity_type?: {
    name: string;
    label: string;
    color: string;
    icon: string;
  } | null;
  sentiment_label?: string | null;
  detection_source?: string;
}

interface Signal {
  id: string;
  ruleName: string;
  ruleKey: string;
  detectedAt: string;
  confidenceScore: number;
  matchedPhrases?: string[];
}

interface SignalType {
  id: string;
  name: string;
  key: string;
  color: string;
}

interface MAPActivitySignalsProps {
  activities: ActivityItem[];
  signals: Signal[];
  signalTypes: SignalType[];
}

const ACTIVITY_ICONS: Record<string, string> = {
  discovery: '🔍',
  demo: '📺',
  technical: '⚙️',
  workshop: '🛠️',
  commercial: '💰',
  evaluation: '📊',
  training: '📚',
  check_in: '✅',
  executive_playback: '👔',
  email_followup: '📧',
  email_proposal: '📝',
  email_introduction: '👋',
};

export function MAPActivitySignals({ activities, signals, signalTypes }: MAPActivitySignalsProps) {
  // Sort activities by date descending
  const sortedActivities = [...activities].sort((a, b) => 
    new Date(b.activity_date).getTime() - new Date(a.activity_date).getTime()
  );

  // Group signals by type
  const signalsByType = signals.reduce((acc, s) => {
    if (!acc[s.ruleKey]) acc[s.ruleKey] = [];
    acc[s.ruleKey].push(s);
    return acc;
  }, {} as Record<string, Signal[]>);

  // Sort signals by date descending
  const sortedSignals = [...signals].sort((a, b) => 
    new Date(b.detectedAt).getTime() - new Date(a.detectedAt).getTime()
  );

  return (
    <div className="p-10 h-full flex flex-col pb-16">
      {/* Section Header */}
      <div className="flex items-center gap-3 mb-6">
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: '#f5910920' }}
        >
          <Activity className="w-5 h-5" style={{ color: '#f59e0b' }} />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Activity Timeline & Signals</h2>
          <p className="text-sm text-gray-500">
            {activities.length} activities · {signals.length} signals detected
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 flex-1">
        {/* Activity Timeline */}
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-600" />
            Activity Timeline
          </h3>
          
          <div className="relative space-y-0 max-h-[400px] overflow-hidden">
            {/* Timeline line */}
            <div className="absolute left-3 top-2 bottom-2 w-0.5 bg-gray-200" />
            
            {sortedActivities.length === 0 ? (
              <div className="bg-gray-50 rounded-lg p-4 text-center ml-6">
                <p className="text-sm text-gray-500">No activities recorded</p>
              </div>
            ) : (
              sortedActivities.slice(0, 12).map((activity, index) => {
                const activityType = activity.activity_type;
                const color = activityType?.color || '#6366f1';
                const icon = ACTIVITY_ICONS[activityType?.name || 'discovery'] || '📅';

                return (
                  <div key={activity.id} className="relative flex items-start gap-3 pb-3">
                    {/* Timeline dot */}
                    <div 
                      className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 z-10 text-xs"
                      style={{ backgroundColor: `${color}20`, border: `2px solid ${color}` }}
                    >
                      {icon}
                    </div>

                    {/* Content */}
                    <div className="flex-1 bg-white border rounded-lg p-2 shadow-sm">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span 
                          className="text-[9px] font-semibold px-1.5 py-0.5 rounded"
                          style={{ backgroundColor: `${color}20`, color }}
                        >
                          {activityType?.label || 'Activity'}
                        </span>
                        <span className="text-[9px] text-gray-500">
                          {format(new Date(activity.activity_date), 'MMM d, yyyy')}
                        </span>
                      </div>
                      <p className="text-[10px] text-gray-800">{activity.title || 'Untitled activity'}</p>
                      {activity.sentiment_label && (
                        <span className="text-[8px] text-gray-500 mt-1 block">
                          Sentiment: {activity.sentiment_label}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
            {sortedActivities.length > 12 && (
              <p className="text-[10px] text-gray-500 text-center ml-6">
                +{sortedActivities.length - 12} more activities
              </p>
            )}
          </div>
        </div>

        {/* Signals Detected */}
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900 flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-600" />
            Signals Detected
          </h3>

          {/* Signal Types Summary */}
          <div className="flex flex-wrap gap-2 mb-3">
            {signalTypes.map(type => {
              const count = signalsByType[type.key]?.length || 0;
              if (count === 0) return null;
              return (
                <div 
                  key={type.id}
                  className="flex items-center gap-1.5 px-2 py-1 rounded-full text-[10px] font-medium"
                  style={{ backgroundColor: `${type.color}20`, color: type.color }}
                >
                  <div 
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: type.color }}
                  />
                  {type.name}: {count}
                </div>
              );
            })}
          </div>
          
          <div className="space-y-2 max-h-[350px] overflow-hidden">
            {sortedSignals.length === 0 ? (
              <div className="bg-gray-50 rounded-lg p-4 text-center">
                <p className="text-sm text-gray-500">No signals detected</p>
                <p className="text-xs text-gray-400 mt-1">Signals are extracted from transcript analysis</p>
              </div>
            ) : (
              sortedSignals.slice(0, 10).map(signal => {
                const typeInfo = signalTypes.find(t => t.key === signal.ruleKey);
                const color = typeInfo?.color || '#6366f1';

                return (
                  <div 
                    key={signal.id}
                    className="bg-white border rounded-lg p-3"
                    style={{ borderLeftWidth: 4, borderLeftColor: color }}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-2">
                        <Zap className="w-3.5 h-3.5" style={{ color }} />
                        <span className="text-[11px] font-semibold text-gray-900">{signal.ruleName}</span>
                      </div>
                      <span className="text-[9px] text-gray-500">
                        {format(new Date(signal.detectedAt), 'MMM d, yyyy')}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-[9px] text-gray-500">
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        <span>{Math.round(signal.confidenceScore * 100)}% confidence</span>
                      </div>
                    </div>

                    {signal.matchedPhrases && signal.matchedPhrases.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {signal.matchedPhrases.slice(0, 3).map((phrase, i) => (
                          <span 
                            key={i}
                            className="text-[8px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-600 italic"
                          >
                            "{phrase}"
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })
            )}
            {sortedSignals.length > 10 && (
              <p className="text-[10px] text-gray-500 text-center">
                +{sortedSignals.length - 10} more signals
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

import { Swords, Shield, AlertTriangle, TrendingUp } from 'lucide-react';

interface AccountCompetitor {
  id: string;
  competitor_id: string;
  competitor_name: string;
  relationship_status?: string | null;
  threat_level?: string | null;
  notes?: string | null;
  detected_at?: string | null;
}

interface CompetitorComparison {
  featureName: string;
  categoryName: string;
  pendoScore: number;
  competitorScore: number;
  pendoAdvantage: number;
}

interface MAPCompetitorsProps {
  accountCompetitors: AccountCompetitor[];
  strengths?: CompetitorComparison[];
  threats?: CompetitorComparison[];
}

const THREAT_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  high: { bg: '#fef2f2', text: '#dc2626', border: '#fecaca' },
  medium: { bg: '#fffbeb', text: '#d97706', border: '#fde68a' },
  low: { bg: '#f0fdf4', text: '#16a34a', border: '#bbf7d0' },
};

const STATUS_COLORS: Record<string, { bg: string; text: string }> = {
  active: { bg: '#fef2f2', text: '#dc2626' },
  potential: { bg: '#fffbeb', text: '#d97706' },
  historical: { bg: '#f3f4f6', text: '#6b7280' },
  incumbent: { bg: '#fef2f2', text: '#dc2626' },
  evaluating: { bg: '#dbeafe', text: '#2563eb' },
};

export function MAPCompetitors({ accountCompetitors, strengths = [], threats = [] }: MAPCompetitorsProps) {
  return (
    <div className="p-10 h-full flex flex-col pb-16">
      {/* Section Header */}
      <div className="flex items-center gap-3 mb-6">
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: '#ef444420' }}
        >
          <Swords className="w-5 h-5" style={{ color: '#ef4444' }} />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Competitive Landscape</h2>
          <p className="text-sm text-gray-500">Detected competitors and positioning analysis</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 flex-1">
        {/* Competitors Detected */}
        <div className="space-y-4">
          <h3 className="font-semibold text-gray-900 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            Competitors in Account ({accountCompetitors.length})
          </h3>
          
          {accountCompetitors.length === 0 ? (
            <div className="bg-gray-50 rounded-lg p-4 text-center">
              <p className="text-sm text-gray-500">No competitors detected yet</p>
              <p className="text-xs text-gray-400 mt-1">Competitors will be identified from transcript analysis</p>
            </div>
          ) : (
            <div className="space-y-2">
              {accountCompetitors.map(comp => {
                const threatColors = THREAT_COLORS[comp.threat_level || 'medium'] || THREAT_COLORS.medium;
                const statusColors = STATUS_COLORS[comp.relationship_status || 'active'] || STATUS_COLORS.active;
                
                return (
                  <div 
                    key={comp.id}
                    className="bg-white border rounded-lg p-3"
                    style={{ borderLeftWidth: 4, borderLeftColor: threatColors.text }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-900">{comp.competitor_name}</span>
                      <div className="flex items-center gap-2">
                        {comp.threat_level && (
                          <span 
                            className="text-[9px] font-medium px-1.5 py-0.5 rounded uppercase"
                            style={{ backgroundColor: threatColors.bg, color: threatColors.text }}
                          >
                            {comp.threat_level} threat
                          </span>
                        )}
                        {comp.relationship_status && (
                          <span 
                            className="text-[9px] font-medium px-1.5 py-0.5 rounded"
                            style={{ backgroundColor: statusColors.bg, color: statusColors.text }}
                          >
                            {comp.relationship_status}
                          </span>
                        )}
                      </div>
                    </div>
                    {comp.notes && (
                      <p className="text-[10px] text-gray-600">{comp.notes}</p>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Competitive Positioning */}
        <div className="space-y-4">
          {/* Our Strengths */}
          <div>
            <h3 className="font-semibold text-gray-900 flex items-center gap-2 mb-3">
              <Shield className="w-4 h-4 text-green-600" />
              Our Competitive Strengths
            </h3>
            
            {strengths.length === 0 ? (
              <div className="bg-green-50 rounded-lg p-3 text-center">
                <p className="text-xs text-green-600">Run competitive analysis to see strengths</p>
              </div>
            ) : (
              <div className="space-y-1.5">
                {strengths.slice(0, 5).map((s, i) => (
                  <div key={i} className="bg-green-50 border border-green-200 rounded-md p-2 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-medium text-green-800">{s.featureName}</p>
                      <p className="text-[8px] text-green-600">{s.categoryName}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="w-3 h-3 text-green-600" />
                      <span className="text-[10px] font-bold text-green-700">+{s.pendoAdvantage}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Competitive Threats */}
          <div>
            <h3 className="font-semibold text-gray-900 flex items-center gap-2 mb-3">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              Areas to Address
            </h3>
            
            {threats.length === 0 ? (
              <div className="bg-red-50 rounded-lg p-3 text-center">
                <p className="text-xs text-red-600">Run competitive analysis to see threats</p>
              </div>
            ) : (
              <div className="space-y-1.5">
                {threats.slice(0, 5).map((t, i) => (
                  <div key={i} className="bg-red-50 border border-red-200 rounded-md p-2 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-medium text-red-800">{t.featureName}</p>
                      <p className="text-[8px] text-red-600">{t.categoryName}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="w-3 h-3 text-red-600 rotate-180" />
                      <span className="text-[10px] font-bold text-red-700">{t.pendoAdvantage}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

import pendoLogo from '@/assets/pendo-logo.png';

interface MAPCoverPageProps {
  accountName: string;
  industry?: string | null;
  generatedDate: string;
  prospectLogoUrl?: string;
}

export function MAPCoverPage({ 
  accountName, 
  industry, 
  generatedDate,
  prospectLogoUrl 
}: MAPCoverPageProps) {
  return (
    <div 
      className="relative flex flex-col items-center justify-center text-center px-12"
      style={{
        height: '100%',
        background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
      }}
    >
      {/* Co-branded logos */}
      <div className="flex items-center justify-center gap-8 mb-12">
        {/* Pendo Logo */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
          <img 
            src={pendoLogo} 
            alt="Pendo" 
            className="h-12 w-auto"
          />
        </div>
        
        {/* Plus symbol */}
        <div className="text-white/60 text-4xl font-light">+</div>
        
        {/* Prospect Logo or Name */}
        {prospectLogoUrl ? (
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
            <img 
              src={prospectLogoUrl} 
              alt={accountName} 
              className="h-12 w-auto"
            />
          </div>
        ) : (
          <div className="bg-white/10 backdrop-blur-sm rounded-xl px-6 py-4">
            <span className="text-white text-2xl font-bold">{accountName}</span>
          </div>
        )}
      </div>

      {/* Title */}
      <h1 className="text-4xl font-bold text-white mb-4">
        Mutual Activity Plan
      </h1>
      
      <p className="text-xl text-white/80 mb-2">
        {accountName}
      </p>
      
      {industry && (
        <p className="text-lg text-white/60 mb-8">
          {industry}
        </p>
      )}

      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-br from-pink-500/20 to-transparent rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-0 w-64 h-64 bg-gradient-to-tr from-blue-500/20 to-transparent rounded-full blur-3xl" />
    </div>
  );
}

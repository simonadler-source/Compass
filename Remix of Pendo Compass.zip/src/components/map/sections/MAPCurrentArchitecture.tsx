import { Layers } from 'lucide-react';

interface Technology {
  id: string;
  name: string;
  layer: string;
  category: string;
  priority?: string | null;
  relationship_status?: string | null;
}

interface FunctionalArea {
  id: string;
  name: string;
  layer: string;
  color?: string | null;
}

interface Layer {
  name: string;
  label: string;
  color: string;
  bg_color: string;
}

interface MAPCurrentArchitectureProps {
  technologies: Technology[];
  functionalAreas: FunctionalArea[];
  layers: Layer[];
}

const DEFAULT_LAYERS = [
  { name: 'host', label: 'Host', color: '#3b82f6', bg_color: '#3b82f620' },
  { name: 'build', label: 'Build', color: '#f59e0b', bg_color: '#f59e0b20' },
  { name: 'adopt', label: 'Adopt', color: '#10b981', bg_color: '#10b98120' },
  { name: 'growth', label: 'Growth', color: '#8b5cf6', bg_color: '#8b5cf620' },
];

export function MAPCurrentArchitecture({
  technologies,
  functionalAreas,
  layers,
}: MAPCurrentArchitectureProps) {
  const effectiveLayers = layers.length > 0 ? layers : DEFAULT_LAYERS;

  // Group technologies by layer and category
  const techByLayer: Record<string, Record<string, Technology[]>> = {};
  
  effectiveLayers.forEach(layer => {
    techByLayer[layer.name] = {};
  });

  technologies.forEach(tech => {
    const layerName = tech.layer.toLowerCase();
    if (!techByLayer[layerName]) {
      techByLayer[layerName] = {};
    }
    if (!techByLayer[layerName][tech.category]) {
      techByLayer[layerName][tech.category] = [];
    }
    techByLayer[layerName][tech.category].push(tech);
  });

  const getRelationshipColor = (status?: string | null) => {
    switch (status) {
      case 'competitor': return '#ef4444';
      case 'partner': return '#10b981';
      case 'customer': return '#3b82f6';
      default: return '#6b7280';
    }
  };

  const getPriorityBorder = (priority?: string | null) => {
    switch (priority) {
      case 'critical': return '2px solid #ef4444';
      case 'high': return '2px solid #f97316';
      case 'medium': return '2px solid #eab308';
      case 'low': return '2px solid #22c55e';
      default: return '1px solid #e5e7eb';
    }
  };

  // Filter to only layers with technologies
  const layersWithTech = effectiveLayers.filter(layer => {
    const layerTechs = techByLayer[layer.name] || {};
    return Object.keys(layerTechs).length > 0;
  });

  return (
    <div className="p-10 h-full flex flex-col pb-16">
      {/* Section Header */}
      <div className="flex items-center gap-3 mb-4">
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: '#8b5cf620' }}
        >
          <Layers className="w-5 h-5" style={{ color: '#8b5cf6' }} />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Current State Architecture</h2>
      </div>

      {/* Architecture Diagram */}
      <div className="space-y-3 flex-1 overflow-hidden">
        {layersWithTech.slice(0, 4).map(layer => {
          const layerTechs = techByLayer[layer.name] || {};
          const categories = Object.keys(layerTechs);

          return (
            <div 
              key={layer.name}
              className="rounded-lg overflow-hidden"
              style={{ backgroundColor: layer.bg_color }}
            >
              {/* Layer Header */}
              <div 
                className="px-3 py-1.5 font-semibold text-white text-sm"
                style={{ backgroundColor: layer.color }}
              >
                {layer.label}
              </div>

              {/* Categories */}
              <div className="p-3 flex flex-wrap gap-3">
                {categories.slice(0, 4).map(category => (
                  <div 
                    key={category}
                    className="bg-white rounded-lg p-3 min-w-[150px] max-w-[200px]"
                    style={{ border: '1px solid #e5e7eb' }}
                  >
                    <h4 className="text-xs font-medium text-gray-600 mb-2 pb-1 border-b border-gray-100">
                      {category}
                    </h4>
                    <div className="flex flex-wrap gap-1">
                      {layerTechs[category].slice(0, 4).map(tech => (
                        <div
                          key={tech.id}
                          className="px-2 py-1 rounded text-xs font-medium"
                          style={{
                            backgroundColor: `${getRelationshipColor(tech.relationship_status)}15`,
                            color: getRelationshipColor(tech.relationship_status),
                            border: getPriorityBorder(tech.priority),
                          }}
                        >
                          {tech.name}
                        </div>
                      ))}
                      {layerTechs[category].length > 4 && (
                        <span className="text-xs text-gray-400">+{layerTechs[category].length - 4}</span>
                      )}
                    </div>
                  </div>
                ))}
                {categories.length > 4 && (
                  <span className="text-xs text-gray-500 self-center">+{categories.length - 4} more</span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="mt-4 flex items-center gap-4 text-xs text-gray-500">
        <span className="font-medium">Priority:</span>
        <div className="flex items-center gap-1">
          <div className="w-2.5 h-2.5 rounded" style={{ border: '2px solid #ef4444' }} />
          <span>Critical</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2.5 h-2.5 rounded" style={{ border: '2px solid #f97316' }} />
          <span>High</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2.5 h-2.5 rounded" style={{ border: '2px solid #eab308' }} />
          <span>Medium</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2.5 h-2.5 rounded" style={{ border: '2px solid #22c55e' }} />
          <span>Low</span>
        </div>
      </div>
    </div>
  );
}

import { 
  FileText, AlertTriangle, Lightbulb, Target, BarChart3, 
  MessageSquare, Swords, Shield, Users, TrendingUp, ChevronRight,
  Zap
} from 'lucide-react';

interface PainPoint {
  id: string;
  pain_point: string | null;
  severity: string | null;
  business_impact: string[] | null;
  pain_category: string | null;
  confidence_score: number | null;
  source: string | null;
  business_theme: string | null;
  validation_count: number | null;
}

interface UseCase {
  id: string;
  use_case: string | null;
  description: string | null;
  functional_area: string | null;
  business_theme: string | null;
  priority: string | null;
  status: string;
  opportunity_id?: string | null;
}

interface Metric {
  id: string;
  metric_name: string;
  metric_value: string | null;
  metric_category: string;
  metric_numeric_value: number | null;
}

interface CompetitorInfo {
  id: string;
  competitor_name: string;
  threat_level?: string | null;
}

interface CompetitivePlay {
  id: string;
  playType: string;
  playStrategy: string;
  playTitle: string;
  playDescription: string | null;
  talkingPoints: string[];
  competitorName: string | null;
  linkedUseCaseIds: string[];
}

interface MAPEvaluationPlanProps {
  accountName: string;
  painPoints: PainPoint[];
  useCases: UseCase[];
  metrics: Metric[];
  competitors: CompetitorInfo[];
  competitivePlays: CompetitivePlay[];
  opportunityId?: string;
  generatedDate?: string;
}

const SEVERITY_STYLES: Record<string, { bg: string; text: string; border: string; label: string }> = {
  critical: { bg: '#fef2f2', text: '#dc2626', border: '#fecaca', label: 'Critical' },
  high: { bg: '#fff7ed', text: '#ea580c', border: '#fed7aa', label: 'Urgent' },
  medium: { bg: '#fefce8', text: '#ca8a04', border: '#fef08a', label: 'Concerned' },
  low: { bg: '#f0fdf4', text: '#16a34a', border: '#bbf7d0', label: 'Noted' },
};

export function MAPEvaluationPlan({
  accountName,
  painPoints,
  useCases,
  metrics,
  competitors,
  competitivePlays,
  opportunityId,
}: MAPEvaluationPlanProps) {
  // Get top 3 pain points by severity as the "Problems"
  const severityOrder = ['critical', 'high', 'medium', 'low'];
  const sortedPainPoints = [...painPoints]
    .filter(p => p.pain_point)
    .sort((a, b) => {
      const aIdx = severityOrder.indexOf(a.severity || 'low');
      const bIdx = severityOrder.indexOf(b.severity || 'low');
      return aIdx - bIdx;
    });

  const topProblems = sortedPainPoints.slice(0, 3);

  // Get landmine questions from competitive plays
  const landmines = competitivePlays.filter(p => p.playType === 'landmine');

  // Match use cases to pain points by business_theme or functional_area
  function getRelatedUseCases(painPoint: PainPoint): UseCase[] {
    return useCases.filter(uc => {
      if (!uc.use_case) return false;
      // Match by business theme
      if (painPoint.business_theme && uc.business_theme && 
          painPoint.business_theme.toLowerCase() === uc.business_theme.toLowerCase()) return true;
      // Match by category/functional area overlap
      if (painPoint.pain_category && uc.functional_area &&
          painPoint.pain_category.toLowerCase().includes(uc.functional_area.toLowerCase())) return true;
      if (painPoint.pain_category && uc.functional_area &&
          uc.functional_area.toLowerCase().includes(painPoint.pain_category.toLowerCase())) return true;
      return false;
    }).slice(0, 3);
  }

  // Match metrics to pain points by category
  function getRelatedMetrics(painPoint: PainPoint): Metric[] {
    return metrics.filter(m => {
      if (painPoint.pain_category && m.metric_category &&
          painPoint.pain_category.toLowerCase().includes(m.metric_category.toLowerCase())) return true;
      if (painPoint.business_theme && m.metric_category &&
          m.metric_category.toLowerCase().includes(painPoint.business_theme.toLowerCase())) return true;
      return false;
    }).slice(0, 3);
  }

  return (
    <div className="h-full flex flex-col" style={{ padding: '28px 32px 48px' }}>
      {/* Section Header */}
      <div className="flex items-start gap-4 mb-5">
        <div 
          className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
          style={{ backgroundColor: '#6366f120' }}
        >
          <FileText className="w-6 h-6" style={{ color: '#6366f1' }} />
        </div>
        <div className="flex-1">
          <h2 className="text-2xl font-bold text-gray-900">Evaluation Plan</h2>
          <p className="text-sm text-gray-500 mt-0.5">
            Based on discovery conversations with {accountName}, we've identified {topProblems.length} critical 
            business challenges where Pendo can drive measurable impact.
          </p>
        </div>
      </div>

      {/* Problems */}
      <div className="flex-1 overflow-hidden space-y-4">
        {topProblems.map((problem, idx) => {
          const severity = SEVERITY_STYLES[problem.severity || 'low'] || SEVERITY_STYLES.low;
          const relatedUseCases = getRelatedUseCases(problem);
          const relatedMetrics = getRelatedMetrics(problem);

          return (
            <div
              key={problem.id}
              className="bg-white rounded-xl border overflow-hidden shadow-sm"
              style={{ borderLeftWidth: 4, borderLeftColor: severity.text }}
            >
              {/* Problem Header */}
              <div className="px-4 py-3 bg-gradient-to-r from-gray-50 to-white border-b border-gray-100">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span 
                      className="text-xs font-bold px-2 py-0.5 rounded"
                      style={{ backgroundColor: severity.bg, color: severity.text }}
                    >
                      Problem {idx + 1}
                    </span>
                    <h3 className="font-semibold text-gray-900 text-sm">{problem.pain_point}</h3>
                  </div>
                  <div className="flex items-center gap-2">
                    {problem.validation_count && problem.validation_count > 1 && (
                      <span className="text-[9px] text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded">
                        Mentioned {problem.validation_count}x
                      </span>
                    )}
                    <span 
                      className="text-[9px] font-medium px-1.5 py-0.5 rounded"
                      style={{ backgroundColor: severity.bg, color: severity.text }}
                    >
                      {severity.label}
                    </span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 divide-x divide-gray-100">
                {/* Left: What We Heard */}
                <div className="p-3 space-y-2">
                  <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1">
                    <MessageSquare className="w-3 h-3" />
                    What We Heard
                  </h4>
                  
                  {/* Business Impact */}
                  {problem.business_impact && problem.business_impact.length > 0 && (
                    <div className="space-y-1">
                      {problem.business_impact.slice(0, 3).map((impact, i) => (
                        <div key={i} className="flex items-start gap-1.5">
                          <ChevronRight className="w-3 h-3 text-gray-400 mt-0.5 shrink-0" />
                          <p className="text-[10px] text-gray-700 leading-snug">{impact}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Theme/Category */}
                  {(problem.pain_category || problem.business_theme) && (
                    <div className="flex items-center gap-1 mt-1">
                      <Users className="w-3 h-3 text-gray-400" />
                      <span className="text-[9px] text-gray-500">
                        {problem.pain_category || problem.business_theme}
                      </span>
                    </div>
                  )}

                  {/* Success Metrics */}
                  {relatedMetrics.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-gray-100">
                      <h4 className="text-[9px] font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1 mb-1">
                        <BarChart3 className="w-3 h-3" />
                        Success Metrics
                      </h4>
                      <div className="space-y-1">
                        {relatedMetrics.map(m => (
                          <div key={m.id} className="flex items-center gap-1.5">
                            <Target className="w-2.5 h-2.5 text-blue-500 shrink-0" />
                            <span className="text-[10px] text-gray-700">
                              {m.metric_name}: <strong>{m.metric_value}</strong>
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Right: Pendo Solution */}
                <div className="p-3 space-y-2">
                  <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1">
                    <Lightbulb className="w-3 h-3" />
                    Pendo Approach
                  </h4>

                  {relatedUseCases.length > 0 ? (
                    <div className="space-y-1.5">
                      {relatedUseCases.map(uc => (
                        <div 
                          key={uc.id}
                          className="bg-blue-50 border border-blue-200 rounded-md p-2"
                        >
                          <p className="text-[10px] font-medium text-blue-900">{uc.use_case}</p>
                          {uc.description && (
                            <p className="text-[9px] text-blue-700 mt-0.5 line-clamp-2">{uc.description}</p>
                          )}
                          <div className="flex items-center gap-1.5 mt-1">
                            {uc.functional_area && (
                              <span className="text-[8px] bg-blue-100 text-blue-700 px-1 py-0.5 rounded">
                                {uc.functional_area}
                              </span>
                            )}
                            {uc.priority && (
                              <span className="text-[8px] bg-gray-100 text-gray-600 px-1 py-0.5 rounded uppercase">
                                {uc.priority}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[10px] text-gray-400 italic">
                      Use cases will be mapped during evaluation kickoff
                    </p>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {/* Competitive Positioning & Landmine Questions */}
        {(competitors.length > 0 || landmines.length > 0) && (
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
            <div className="px-4 py-2.5 bg-gradient-to-r from-red-50 to-white border-b border-gray-100">
              <div className="flex items-center gap-2">
                <Swords className="w-4 h-4 text-red-600" />
                <h3 className="font-semibold text-gray-900 text-sm">Competitive Positioning</h3>
              </div>
            </div>

            <div className="grid grid-cols-2 divide-x divide-gray-100">
              {/* Competitors & Gaps */}
              <div className="p-3 space-y-2">
                {competitors.length > 0 && (
                  <>
                    <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                      Competitors Detected ({competitors.length})
                    </h4>
                    <div className="space-y-1">
                      {competitors.slice(0, 4).map(comp => (
                        <div key={comp.id} className="flex items-center justify-between text-[10px]">
                          <span className="font-medium text-gray-800">{comp.competitor_name}</span>
                          {comp.threat_level && (
                            <span className={`text-[8px] px-1.5 py-0.5 rounded font-medium ${
                              comp.threat_level === 'high' ? 'bg-red-100 text-red-700' :
                              comp.threat_level === 'medium' ? 'bg-amber-100 text-amber-700' :
                              'bg-green-100 text-green-700'
                            }`}>
                              {comp.threat_level}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </>
                )}

                {/* Defend plays as "Gaps & Mitigations" */}
                {competitivePlays.filter(p => p.playStrategy === 'defend').slice(0, 3).map(play => (
                  <div key={play.id} className="mt-2 bg-amber-50 border border-amber-200 rounded-md p-2">
                    <div className="flex items-center gap-1 mb-0.5">
                      <Shield className="w-3 h-3 text-amber-600" />
                      <span className="text-[9px] font-medium text-amber-800">Gap</span>
                    </div>
                    <p className="text-[10px] text-gray-700">{play.playTitle}</p>
                    {play.talkingPoints?.[0] && (
                      <p className="text-[9px] text-amber-700 mt-0.5 italic">
                        Mitigation: {play.talkingPoints[0]}
                      </p>
                    )}
                  </div>
                ))}
              </div>

              {/* Landmine Questions */}
              <div className="p-3 space-y-2">
                <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1">
                  <Zap className="w-3 h-3 text-red-500" />
                  Landmine Questions
                </h4>
                {landmines.length > 0 ? (
                  <div className="space-y-1.5">
                    {landmines.slice(0, 5).map((lm, i) => (
                      <div key={lm.id} className="flex items-start gap-1.5">
                        <span className="text-[10px] font-bold text-red-600 mt-0.5 shrink-0">{i + 1}.</span>
                        <p className="text-[10px] text-gray-700">{lm.playTitle}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[10px] text-gray-400 italic">
                    Landmine questions will be generated from competitive analysis
                  </p>
                )}

                {/* Attack plays as "Pendo Strengths" */}
                {competitivePlays.filter(p => p.playStrategy === 'attack').length > 0 && (
                  <div className="mt-2 pt-2 border-t border-gray-100">
                    <h4 className="text-[9px] font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1 mb-1">
                      <TrendingUp className="w-3 h-3 text-green-600" />
                      Pendo Strengths
                    </h4>
                    {competitivePlays.filter(p => p.playStrategy === 'attack').slice(0, 3).map(play => (
                      <div key={play.id} className="flex items-start gap-1.5 mb-1">
                        <ChevronRight className="w-3 h-3 text-green-500 mt-0.5 shrink-0" />
                        <p className="text-[10px] text-gray-700">{play.playTitle}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {topProblems.length === 0 && (
          <div className="text-center py-12 flex-1 flex flex-col items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-indigo-50 flex items-center justify-center mb-4">
              <FileText className="w-8 h-8 text-indigo-300" />
            </div>
            <p className="text-gray-500">No evaluation plan data available yet</p>
            <p className="text-xs text-gray-400 mt-1">Pain points and use cases will populate this section from transcript analysis</p>
          </div>
        )}
      </div>
    </div>
  );
}

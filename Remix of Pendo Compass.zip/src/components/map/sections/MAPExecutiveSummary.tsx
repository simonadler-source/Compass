import { Building2, TrendingUp, AlertTriangle, Clock, Target, Users, Calendar, Activity, ArrowRight, Sparkles, DollarSign, Zap } from 'lucide-react';
import { format, differenceInDays } from 'date-fns';

interface PainPoint {
  id: string;
  pain_point: string;
  severity: string;
  business_theme?: string | null;
}

interface StrategicTheme {
  id: string;
  theme_name: string;
  theme_type: string;
  impact_level?: string | null;
}

interface Milestone {
  id: string;
  name: string;
  scheduled_date?: string | null;
  completed_date?: string | null;
  target_date?: string | null;
  due_date?: string | null;
  status: string;
}

interface ExecSummary {
  summary_narrative?: string | null;
  key_risks?: string[] | null;
  key_opportunities?: string[] | null;
}

interface MAPExecutiveSummaryProps {
  accountName: string;
  industry?: string | null;
  stage?: string | null;
  arr?: number | null;
  engagementScore?: number | null;
  momentumScore?: number | null;
  relationshipStatus?: string | null;
  useCasesCount: number;
  stakeholdersCount: number;
  painPointsCount: number;
  topPainPoints: PainPoint[];
  topOpportunities: StrategicTheme[];
  nextMilestone?: Milestone | null;
  opportunityCreatedAt?: string | null;
  execSummary?: ExecSummary | null;
}

function formatCurrency(value: number | null | undefined): string {
  if (value === null || value === undefined) return '—';
  if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
  return `$${value.toFixed(0)}`;
}

function getScoreColor(score: number | null | undefined): string {
  if (score === null || score === undefined) return '#9ca3af';
  if (score >= 70) return '#16a34a';
  if (score >= 40) return '#f59e0b';
  return '#dc2626';
}

// Fix missing spaces in AI-generated text
function normalizeText(text: string): string {
  if (!text) return '';
  
  // Add space before capital letters that follow lowercase letters (camelCase words)
  let normalized = text.replace(/([a-z])([A-Z])/g, '$1 $2');
  
  // Add space after periods/commas that are immediately followed by a letter
  normalized = normalized.replace(/([.,])([A-Za-z])/g, '$1 $2');
  
  // Add space after common sentence endings followed by capital letters
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Fix common concatenated words (add space before common words)
  const commonWords = ['the', 'and', 'with', 'for', 'their', 'that', 'this', 'from', 'they', 'have', 'has', 'are', 'was', 'were', 'been', 'being', 'could', 'would', 'should', 'about', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'between', 'under', 'around', 'among'];
  commonWords.forEach(word => {
    // Add space before common lowercase words when preceded by a letter
    const regex = new RegExp(`([a-zA-Z])(${word})\\b`, 'gi');
    normalized = normalized.replace(regex, '$1 $2');
  });
  
  // Clean up any double spaces
  normalized = normalized.replace(/\s+/g, ' ').trim();
  
  return normalized;
}

function getRelationshipColor(status: string | null | undefined): { bg: string; text: string } {
  const statusColors: Record<string, { bg: string; text: string }> = {
    'new': { bg: '#dbeafe', text: '#1d4ed8' },
    'engaged': { bg: '#dcfce7', text: '#16a34a' },
    'evaluating': { bg: '#fef3c7', text: '#b45309' },
    'negotiating': { bg: '#e0e7ff', text: '#4338ca' },
    'at_risk': { bg: '#fee2e2', text: '#dc2626' },
    'customer': { bg: '#d1fae5', text: '#047857' },
  };
  return statusColors[status || ''] || { bg: '#f3f4f6', text: '#6b7280' };
}

export function MAPExecutiveSummary({
  accountName,
  industry,
  stage,
  arr,
  engagementScore,
  momentumScore,
  relationshipStatus,
  useCasesCount,
  stakeholdersCount,
  painPointsCount,
  topPainPoints,
  topOpportunities,
  nextMilestone,
  opportunityCreatedAt,
  execSummary,
}: MAPExecutiveSummaryProps) {
  const relationshipColors = getRelationshipColor(relationshipStatus);
  const daysInCycle = opportunityCreatedAt 
    ? differenceInDays(new Date(), new Date(opportunityCreatedAt))
    : null;

  // Build a narrative if not provided by AI - normalize text to fix missing spaces
  const rawNarrative = execSummary?.summary_narrative || 
    `${accountName} represents a ${stage === 'customer' ? 'strategic expansion' : 'high-value'} opportunity in the ${industry || 'enterprise'} sector. ` +
    `With ${useCasesCount} identified use cases and ${stakeholdersCount} engaged stakeholders, ` +
    `the account shows ${momentumScore && momentumScore >= 60 ? 'strong momentum' : 'developing interest'} in our solution. ` +
    `Key focus areas include addressing ${painPointsCount} documented pain points while building relationships with decision makers.`;
  const narrativeText = normalizeText(rawNarrative);

  return (
    <div className="p-8 h-full flex flex-col pb-12">
      {/* Header with Account Identity */}
      <div className="flex items-start gap-4 mb-5">
        <div 
          className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
          style={{ backgroundColor: '#3b82f620' }}
        >
          <Building2 className="w-6 h-6" style={{ color: '#3b82f6' }} />
        </div>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-gray-900">{accountName}</h1>
          <div className="flex items-center gap-3 mt-1">
            {industry && (
              <span className="text-sm text-gray-600">{industry}</span>
            )}
            {stage && (
              <span 
                className="px-2.5 py-0.5 rounded-full text-xs font-medium capitalize"
                style={{ 
                  backgroundColor: stage === 'customer' ? '#d1fae5' : '#dbeafe',
                  color: stage === 'customer' ? '#047857' : '#1d4ed8'
                }}
              >
                {stage}
              </span>
            )}
            {relationshipStatus && (
              <span 
                className="px-2.5 py-0.5 rounded-full text-xs font-medium capitalize"
                style={{ backgroundColor: relationshipColors.bg, color: relationshipColors.text }}
              >
                {relationshipStatus.replace(/_/g, ' ')}
              </span>
            )}
          </div>
        </div>
        <div className="text-right">
          <p className="text-[10px] text-gray-400 uppercase tracking-wide">Executive Summary</p>
          <p className="text-xs text-gray-500">{format(new Date(), 'MMMM d, yyyy')}</p>
        </div>
      </div>

      {/* Key Metrics Bar */}
      <div className="grid grid-cols-5 gap-3 mb-5">
        <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-lg p-3 border border-emerald-200">
          <div className="flex items-center gap-1.5 mb-1">
            <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
            <span className="text-[10px] text-emerald-700 font-medium">ARR</span>
          </div>
          <p className="text-xl font-bold text-emerald-800">{formatCurrency(arr)}</p>
        </div>
        
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-3 border border-blue-200">
          <div className="flex items-center gap-1.5 mb-1">
            <Activity className="w-3.5 h-3.5 text-blue-600" />
            <span className="text-[10px] text-blue-700 font-medium">Engagement</span>
          </div>
          <p className="text-xl font-bold" style={{ color: getScoreColor(engagementScore) }}>
            {engagementScore ?? '—'}
          </p>
        </div>
        
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-3 border border-purple-200">
          <div className="flex items-center gap-1.5 mb-1">
            <Zap className="w-3.5 h-3.5 text-purple-600" />
            <span className="text-[10px] text-purple-700 font-medium">Momentum</span>
          </div>
          <p className="text-xl font-bold" style={{ color: getScoreColor(momentumScore) }}>
            {momentumScore ?? '—'}
          </p>
        </div>
        
        <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg p-3 border border-amber-200">
          <div className="flex items-center gap-1.5 mb-1">
            <Users className="w-3.5 h-3.5 text-amber-600" />
            <span className="text-[10px] text-amber-700 font-medium">Stakeholders</span>
          </div>
          <p className="text-xl font-bold text-amber-800">{stakeholdersCount}</p>
        </div>
        
        <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-3 border border-gray-200">
          <div className="flex items-center gap-1.5 mb-1">
            <Clock className="w-3.5 h-3.5 text-gray-600" />
            <span className="text-[10px] text-gray-700 font-medium">Days in Cycle</span>
          </div>
          <p className="text-xl font-bold text-gray-800">{daysInCycle ?? '—'}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 flex-1">
        {/* Left Column: Narrative + Timeline */}
        <div className="col-span-2 space-y-4">
          {/* AI-Generated Narrative */}
          <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl p-4 border border-slate-200">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-indigo-500" />
              <h3 className="text-sm font-semibold text-gray-800">Account Overview</h3>
            </div>
            <p className="text-sm text-gray-700 leading-relaxed">{narrativeText}</p>
          </div>

          {/* Timeline Summary */}
          <div className="bg-white rounded-xl p-4 border border-gray-200">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="w-4 h-4 text-blue-500" />
              <h3 className="text-sm font-semibold text-gray-800">Timeline</h3>
            </div>
            
            {nextMilestone ? (
              <div className="flex items-center gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500" />
                    <p className="text-sm font-medium text-gray-900">{nextMilestone.name}</p>
                    <span 
                      className="text-[10px] px-2 py-0.5 rounded-full capitalize"
                      style={{
                        backgroundColor: nextMilestone.status === 'completed' ? '#d1fae5' : 
                          nextMilestone.status === 'in_progress' ? '#dbeafe' : '#f3f4f6',
                        color: nextMilestone.status === 'completed' ? '#047857' : 
                          nextMilestone.status === 'in_progress' ? '#1d4ed8' : '#6b7280',
                      }}
                    >
                      {nextMilestone.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                  {(nextMilestone.scheduled_date || nextMilestone.target_date || nextMilestone.due_date) && (
                    <p className="text-xs text-gray-500 ml-5 mt-1">
                      Target: {format(new Date((nextMilestone.scheduled_date || nextMilestone.target_date || nextMilestone.due_date)!), 'MMMM d, yyyy')}
                      {differenceInDays(new Date((nextMilestone.scheduled_date || nextMilestone.target_date || nextMilestone.due_date)!), new Date()) > 0 && (
                        <span className="text-blue-600 ml-2">
                          ({differenceInDays(new Date((nextMilestone.scheduled_date || nextMilestone.target_date || nextMilestone.due_date)!), new Date())} days away)
                        </span>
                      )}
                    </p>
                  )}
                </div>
                <ArrowRight className="w-5 h-5 text-gray-300" />
              </div>
            ) : (
              <p className="text-sm text-gray-500 italic">No milestones defined yet</p>
            )}
          </div>

          {/* Stats Summary */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-amber-50 rounded-lg p-3 border border-amber-200 text-center">
              <p className="text-2xl font-bold text-amber-700">{useCasesCount}</p>
              <p className="text-[10px] text-amber-600 font-medium">Use Cases</p>
            </div>
            <div className="bg-red-50 rounded-lg p-3 border border-red-200 text-center">
              <p className="text-2xl font-bold text-red-700">{painPointsCount}</p>
              <p className="text-[10px] text-red-600 font-medium">Pain Points</p>
            </div>
            <div className="bg-green-50 rounded-lg p-3 border border-green-200 text-center">
              <p className="text-2xl font-bold text-green-700">{topOpportunities.length}</p>
              <p className="text-[10px] text-green-600 font-medium">Opportunities</p>
            </div>
          </div>
        </div>

        {/* Right Column: Key Insights */}
        <div className="space-y-4">
          {/* Top Pain Points */}
          <div className="bg-red-50 rounded-xl p-4 border border-red-200">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="w-4 h-4 text-red-500" />
              <h3 className="text-sm font-semibold text-red-800">Top Pain Points</h3>
            </div>
            {topPainPoints.length > 0 ? (
              <ul className="space-y-2">
                {topPainPoints.slice(0, 3).map((pp, index) => (
                  <li key={pp.id} className="flex items-start gap-2">
                    <span 
                      className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5"
                      style={{
                        backgroundColor: pp.severity === 'critical' ? '#dc2626' :
                          pp.severity === 'high' ? '#ea580c' : '#f59e0b',
                        color: 'white'
                      }}
                    >
                      {index + 1}
                    </span>
                    <div>
                      <p className="text-xs text-gray-800 leading-snug">{normalizeText(pp.pain_point || '')}</p>
                      <p className="text-[10px] text-red-600 capitalize">{pp.severity}</p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-red-600 italic">No pain points captured yet</p>
            )}
          </div>

          {/* Top Opportunities */}
          <div className="bg-green-50 rounded-xl p-4 border border-green-200">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-4 h-4 text-green-500" />
              <h3 className="text-sm font-semibold text-green-800">Key Opportunities</h3>
            </div>
            {topOpportunities.length > 0 ? (
              <ul className="space-y-2">
                {topOpportunities.slice(0, 3).map((opp, index) => (
                  <li key={opp.id} className="flex items-start gap-2">
                    <span 
                      className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5 bg-green-600 text-white"
                    >
                      {index + 1}
                    </span>
                    <div>
                      <p className="text-xs text-gray-800 leading-snug">{normalizeText(opp.theme_name || '')}</p>
                      {opp.impact_level && (
                        <p className="text-[10px] text-green-600 capitalize">{opp.impact_level} impact</p>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            ) : execSummary?.key_opportunities?.length ? (
              <ul className="space-y-2">
                {execSummary.key_opportunities.slice(0, 3).map((opp, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5 bg-green-600 text-white">
                      {index + 1}
                    </span>
                    <p className="text-xs text-gray-800 leading-snug">{normalizeText(opp)}</p>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-green-600 italic">Analyzing opportunities...</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

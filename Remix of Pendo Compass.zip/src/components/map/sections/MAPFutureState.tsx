import { ArrowRight, Layers, X, Check, Sparkles } from 'lucide-react';

interface PainPoint {
  id: string;
  pain_point: string;
  severity: string;
}

interface StrategicTheme {
  id: string;
  theme_name: string;
  theme_type: string;
  description?: string | null;
}

interface ExecSummary {
  key_opportunities?: string[] | null;
}

interface MAPFutureStateProps {
  accountName: string;
  painPoints?: PainPoint[];
  strategicThemes?: StrategicTheme[];
  execSummary?: ExecSummary | null;
}

// Text normalization to fix missing spaces
function normalizeText(text: string): string {
  if (!text) return '';
  let normalized = text.replace(/([a-z])([A-Z])/g, '$1 $2');
  normalized = normalized.replace(/([.,])([A-Za-z])/g, '$1 $2');
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');
  const commonWords = ['the', 'and', 'with', 'for', 'their', 'that', 'this', 'from', 'they', 'have', 'has', 'are', 'was', 'were', 'been', 'being', 'could', 'would', 'should', 'about', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'between', 'under', 'around', 'among'];
  commonWords.forEach(word => {
    const regex = new RegExp(`([a-zA-Z])(${word})\\b`, 'gi');
    normalized = normalized.replace(regex, '$1 $2');
  });
  normalized = normalized.replace(/\s+/g, ' ').trim();
  return normalized;
}

export function MAPFutureState({ accountName, painPoints = [], strategicThemes = [], execSummary }: MAPFutureStateProps) {
  // Get challenges from pain points
  const challenges = painPoints.slice(0, 6);
  
  // Get outcomes from strategic themes (initiatives) or exec summary opportunities
  const initiatives = strategicThemes.filter(t => t.theme_type === 'initiative');
  
  const outcomes = initiatives.length > 0 
    ? initiatives.slice(0, 6).map(t => t.theme_name || t.description || '')
    : (execSummary?.key_opportunities || []).slice(0, 6);

  return (
    <div style={{ padding: '24px 32px', paddingBottom: '40px', height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Section Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
        <div 
          style={{ 
            width: '36px', 
            height: '36px', 
            borderRadius: '8px', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            backgroundColor: '#f3f4f6'
          }}
        >
          <Layers size={18} style={{ color: '#6b7280' }} />
        </div>
        <h2 style={{ fontSize: '18px', fontWeight: 700, color: '#111827', margin: 0 }}>
          Current vs Future State
        </h2>
      </div>

      {/* Main Content - Simple Two Column Layout */}
      <div style={{ 
        flex: 1, 
        display: 'grid', 
        gridTemplateColumns: '1fr auto 1fr', 
        gap: '24px',
        alignItems: 'stretch',
      }}>
        
        {/* Left Column: Current State - Challenges */}
        <div style={{ 
          backgroundColor: '#fef2f2', 
          borderRadius: '12px', 
          padding: '20px',
          border: '1px solid #fecaca',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
            <div style={{ 
              width: '20px', 
              height: '20px', 
              borderRadius: '50%', 
              backgroundColor: '#fee2e2',
              border: '1px solid #fca5a5',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <X size={12} style={{ color: '#dc2626' }} />
            </div>
            <h3 style={{ fontSize: '13px', fontWeight: 600, color: '#111827', margin: 0 }}>
              Current State — Challenges
            </h3>
          </div>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {challenges.length > 0 ? (
              challenges.map((pp, i) => (
                <div key={pp.id || i} style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                  <X size={14} style={{ color: '#ef4444', flexShrink: 0, marginTop: '2px' }} />
                  <span style={{ fontSize: '11px', color: '#374151', lineHeight: '1.5' }}>
                    {normalizeText(pp.pain_point || '')}
                  </span>
                </div>
              ))
            ) : (
              <p style={{ fontSize: '11px', color: '#9ca3af', fontStyle: 'italic', margin: 0 }}>
                No challenges identified yet
              </p>
            )}
          </div>
        </div>

        {/* Center Arrow */}
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center',
          padding: '0 8px',
        }}>
          <div style={{ 
            width: '36px', 
            height: '36px', 
            borderRadius: '8px', 
            backgroundColor: '#dbeafe',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
            <ArrowRight size={18} style={{ color: '#2563eb' }} />
          </div>
        </div>

        {/* Right Column: Future State - Potential Outcomes */}
        <div style={{ 
          backgroundColor: '#f0fdf4', 
          borderRadius: '12px', 
          padding: '20px',
          border: '1px solid #bbf7d0',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
            <div style={{ 
              width: '20px', 
              height: '20px', 
              borderRadius: '50%', 
              backgroundColor: '#dcfce7',
              border: '1px solid #86efac',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <Sparkles size={12} style={{ color: '#16a34a' }} />
            </div>
            <h3 style={{ fontSize: '13px', fontWeight: 600, color: '#111827', margin: 0 }}>
              Future State — Potential Outcomes
            </h3>
          </div>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {outcomes.length > 0 ? (
              outcomes.map((outcome, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                  <Check size={14} style={{ color: '#22c55e', flexShrink: 0, marginTop: '2px' }} />
                  <span style={{ fontSize: '11px', color: '#374151', lineHeight: '1.5' }}>
                    {normalizeText(typeof outcome === 'string' ? outcome : '')}
                  </span>
                </div>
              ))
            ) : (
              <>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                  <Check size={14} style={{ color: '#22c55e', flexShrink: 0, marginTop: '2px' }} />
                  <span style={{ fontSize: '11px', color: '#374151', lineHeight: '1.5' }}>
                    Consolidated platform for improved efficiency and cost-effectiveness
                  </span>
                </div>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                  <Check size={14} style={{ color: '#22c55e', flexShrink: 0, marginTop: '2px' }} />
                  <span style={{ fontSize: '11px', color: '#374151', lineHeight: '1.5' }}>
                    Enhanced analytics and insights into user behavior
                  </span>
                </div>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                  <Check size={14} style={{ color: '#22c55e', flexShrink: 0, marginTop: '2px' }} />
                  <span style={{ fontSize: '11px', color: '#374151', lineHeight: '1.5' }}>
                    Data-driven product decisions and roadmap planning
                  </span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

import { Calendar, CheckCircle2, Clock, Play, SkipForward } from 'lucide-react';
import { format } from 'date-fns';

interface Milestone {
  id: string;
  name: string;
  phase: string;
  status: string;
  scheduled_date?: string | null;
  completed_date?: string | null;
  description?: string | null;
}

interface MilestoneTemplate {
  id: string;
  phase: string;
  name: string;
  description: string | null;
}

interface MAPMilestonesProps {
  milestones: Milestone[];
  templates?: MilestoneTemplate[];
}

const phaseColors: Record<string, { bg: string; border: string; text: string }> = {
  'Value Discovery': { bg: '#dbeafe', border: '#3b82f6', text: '#1d4ed8' },
  'Eval Planning': { bg: '#fef3c7', border: '#f59e0b', text: '#d97706' },
  'Eval Deployment': { bg: '#d1fae5', border: '#10b981', text: '#059669' },
  'Eval Workshops': { bg: '#ede9fe', border: '#8b5cf6', text: '#7c3aed' },
  'Conclusion': { bg: '#fce7f3', border: '#ec4899', text: '#db2777' },
  'Procurement & Contracting': { bg: '#fef9c3', border: '#eab308', text: '#ca8a04' },
  'Go Live & Value Realization': { bg: '#dcfce7', border: '#22c55e', text: '#16a34a' },
};

const statusConfig: Record<string, { icon: typeof CheckCircle2; color: string }> = {
  not_scheduled: { icon: Clock, color: '#9ca3af' },
  scheduled: { icon: Calendar, color: '#3b82f6' },
  in_progress: { icon: Play, color: '#f59e0b' },
  completed: { icon: CheckCircle2, color: '#10b981' },
  skipped: { icon: SkipForward, color: '#9ca3af' },
};

export function MAPMilestones({ milestones, templates = [] }: MAPMilestonesProps) {
  // Use milestones if available, otherwise convert templates to display format
  const displayMilestones: Milestone[] = milestones.length > 0 
    ? milestones 
    : templates.map(t => ({
        id: t.id,
        name: t.name,
        phase: t.phase,
        status: 'not_scheduled',
        description: t.description,
      }));

  // Group by phase
  const groupedMilestones: { phase: string; items: Milestone[] }[] = [];
  let currentPhase = '';
  
  displayMilestones.forEach(m => {
    if (m.phase !== currentPhase) {
      currentPhase = m.phase;
      groupedMilestones.push({ phase: currentPhase, items: [] });
    }
    groupedMilestones[groupedMilestones.length - 1].items.push(m);
  });

  return (
    <div style={{ padding: '24px 32px', paddingBottom: '40px', height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Section Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
        <div 
          style={{ 
            width: '36px', 
            height: '36px', 
            borderRadius: '8px', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            backgroundColor: '#10b98120'
          }}
        >
          <Calendar size={18} style={{ color: '#10b981' }} />
        </div>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 700, color: '#111827', margin: 0 }}>
            Mutual Action Plan Timeline
          </h2>
          <p style={{ fontSize: '11px', color: '#6b7280', margin: 0 }}>
            {displayMilestones.length} milestones across {groupedMilestones.length} phases
          </p>
        </div>
      </div>

      {/* Timeline - Horizontal Layout for Landscape */}
      <div style={{ flex: 1, display: 'flex', gap: '12px', overflow: 'hidden' }}>
        {groupedMilestones.map(({ phase, items }) => {
          const colors = phaseColors[phase] || { bg: '#f3f4f6', border: '#9ca3af', text: '#6b7280' };
          const completedCount = items.filter(m => m.status === 'completed').length;
          const progress = Math.round((completedCount / items.length) * 100);

          return (
            <div 
              key={phase} 
              style={{ 
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                borderRadius: '8px',
                overflow: 'hidden',
                border: `1px solid ${colors.border}`,
                minWidth: 0,
              }}
            >
              {/* Phase Header */}
              <div 
                style={{ 
                  padding: '10px 12px',
                  backgroundColor: colors.bg,
                  borderBottom: `1px solid ${colors.border}`,
                }}
              >
                <h3 style={{ 
                  fontSize: '11px', 
                  fontWeight: 600, 
                  color: colors.text,
                  margin: 0,
                  marginBottom: '6px',
                }}>
                  {phase}
                </h3>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div 
                    style={{ 
                      flex: 1,
                      height: '4px',
                      borderRadius: '2px',
                      backgroundColor: `${colors.border}40`,
                      overflow: 'hidden',
                    }}
                  >
                    <div 
                      style={{ 
                        height: '100%',
                        width: `${progress}%`,
                        backgroundColor: colors.border,
                        borderRadius: '2px',
                        transition: 'width 0.3s',
                      }}
                    />
                  </div>
                  <span style={{ fontSize: '9px', fontWeight: 500, color: colors.text }}>
                    {completedCount}/{items.length}
                  </span>
                </div>
              </div>

              {/* Milestones */}
              <div style={{ 
                flex: 1, 
                backgroundColor: 'white',
                padding: '8px',
                display: 'flex',
                flexDirection: 'column',
                gap: '4px',
                overflow: 'hidden',
              }}>
                {items.map(milestone => {
                  const status = statusConfig[milestone.status] || statusConfig.not_scheduled;
                  const StatusIcon = status.icon;

                  return (
                    <div 
                      key={milestone.id}
                      style={{ 
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        padding: '6px 8px',
                        borderRadius: '4px',
                        backgroundColor: milestone.status === 'completed' ? '#f0fdf4' : '#f9fafb',
                        border: '1px solid #e5e7eb',
                      }}
                    >
                      <StatusIcon size={12} style={{ color: status.color, flexShrink: 0 }} />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p 
                          style={{ 
                            fontSize: '8px',
                            fontWeight: 500,
                            margin: 0,
                            textDecoration: milestone.status === 'completed' ? 'line-through' : 'none',
                            color: milestone.status === 'completed' ? '#9ca3af' : '#111827',
                            lineHeight: '1.3',
                            wordBreak: 'break-word',
                          }}
                        >
                          {milestone.name}
                        </p>
                      </div>
                      {milestone.scheduled_date && (
                        <span style={{ 
                          fontSize: '8px', 
                          color: '#6b7280',
                          flexShrink: 0,
                        }}>
                          {format(new Date(milestone.scheduled_date), 'MMM d')}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {displayMilestones.length === 0 && (
        <div style={{ 
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#6b7280',
        }}>
          <Calendar size={40} style={{ marginBottom: '12px', color: '#d1d5db' }} />
          <p style={{ fontSize: '12px', margin: 0 }}>No milestones configured yet</p>
        </div>
      )}
    </div>
  );
}

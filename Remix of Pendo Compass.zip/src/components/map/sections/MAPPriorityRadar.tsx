import { Target, Table, CheckCircle, Circle } from 'lucide-react';

// Text normalization to fix missing spaces
function normalizeText(text: string): string {
  if (!text) return '';
  let normalized = text.replace(/([a-z])([A-Z])/g, '$1 $2');
  normalized = normalized.replace(/([.,])([A-Za-z])/g, '$1 $2');
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');
  const commonWords = ['the', 'and', 'with', 'for', 'their', 'that', 'this', 'from', 'they', 'have', 'has', 'are', 'was', 'were', 'been', 'being', 'could', 'would', 'should', 'about', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'between', 'under', 'around', 'among'];
  commonWords.forEach(word => {
    const regex = new RegExp(`([a-zA-Z])(${word})\\b`, 'gi');
    normalized = normalized.replace(regex, '$1 $2');
  });
  normalized = normalized.replace(/\s+/g, ' ').trim();
  return normalized;
}

interface UseCase {
  id: string;
  use_case: string;
  description?: string | null;
  functional_area: string;
  priority?: string | null;
  status?: string | null;
  confidence_score?: number | null;
  radar_x?: number | null;
  radar_y?: number | null;
  opportunity_id?: string | null;
}

interface MAPPriorityRadarProps {
  useCases: UseCase[];
}

const priorityRings = [
  { priority: 'critical', radius: 60, color: '#ef4444', label: 'Critical' },
  { priority: 'high', radius: 110, color: '#f97316', label: 'High' },
  { priority: 'medium', radius: 160, color: '#eab308', label: 'Medium' },
  { priority: 'low', radius: 210, color: '#22c55e', label: 'Low' },
];

const AREA_COLORS: Record<string, string> = {
  'Analytics & Insights': '#3b82f6',
  'CRM': '#ef4444',
  'Digital Adoption & Guides': '#ec4899',
  'Customer Success': '#10b981',
  'Marketing Automation': '#8b5cf6',
  'Data Infrastructure': '#0ea5e9',
  'Communication': '#f59e0b',
  'Support & Ticketing': '#f97316',
  'Other': '#6b7280',
};

const STATUS_COLORS: Record<string, { bg: string; text: string }> = {
  identified: { bg: '#f3f4f6', text: '#374151' },
  validated: { bg: '#dbeafe', text: '#1d4ed8' },
  in_progress: { bg: '#fef3c7', text: '#b45309' },
  accepted: { bg: '#d1fae5', text: '#047857' },
  rejected: { bg: '#fee2e2', text: '#b91c1c' },
};

export function MAPPriorityRadar({ useCases }: MAPPriorityRadarProps) {
  const CENTER = 180;
  const SIZE = 360;

  // Filter use cases with priority set
  const prioritizedUseCases = useCases.filter(uc => uc.priority && uc.use_case);

  // Group by priority for listing
  const byPriority: Record<string, typeof useCases> = {
    critical: [],
    high: [],
    medium: [],
    low: [],
  };

  prioritizedUseCases.forEach(uc => {
    if (uc.priority && byPriority[uc.priority]) {
      byPriority[uc.priority].push(uc);
    }
  });

  // Position use cases on radar
  const getPosition = (uc: typeof useCases[0], index: number, total: number) => {
    // If radar position is set, use it (scaled down)
    if (uc.radar_x !== null && uc.radar_y !== null) {
      return { x: (uc.radar_x / 300) * CENTER, y: (uc.radar_y / 300) * CENTER };
    }

    // Otherwise, calculate based on priority
    const ring = priorityRings.find(r => r.priority === uc.priority);
    if (!ring) return { x: CENTER, y: CENTER };

    // Distribute evenly around the ring
    const angle = (index / Math.max(total, 1)) * 2 * Math.PI - Math.PI / 2;
    const radius = ring.radius - 15 + Math.random() * 30;
    return {
      x: CENTER + Math.cos(angle) * radius * 0.8,
      y: CENTER + Math.sin(angle) * radius * 0.8,
    };
  };

  return (
    <div className="p-10 h-full flex flex-col pb-16">
      {/* Section Header */}
      <div className="flex items-center gap-3 mb-4">
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: '#ef444420' }}
        >
          <Target className="w-5 h-5" style={{ color: '#ef4444' }} />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Priority Radar</h2>
          <p className="text-sm text-gray-500">
            {prioritizedUseCases.length} prioritized use cases · {useCases.filter(u => u.opportunity_id).length} linked · {useCases.filter(u => !u.opportunity_id && (u.confidence_score || 0) >= 0.7).length} suggested
          </p>
        </div>
      </div>

      <div className="flex gap-6 flex-1">
        {/* Radar Visualization */}
        <div className="flex items-center justify-center shrink-0">
          <svg width={SIZE} height={SIZE}>
            {/* Background rings */}
            {priorityRings.map((ring) => (
              <g key={ring.priority}>
                <circle
                  cx={CENTER}
                  cy={CENTER}
                  r={ring.radius * 0.8}
                  fill={`${ring.color}10`}
                  stroke={ring.color}
                  strokeWidth={1.5}
                  strokeDasharray="3 3"
                />
                <text
                  x={CENTER}
                  y={CENTER - ring.radius * 0.8 + 12}
                  textAnchor="middle"
                  className="text-[9px] font-medium"
                  fill={ring.color}
                >
                  {ring.label}
                </text>
              </g>
            ))}

            {/* Center point */}
            <circle cx={CENTER} cy={CENTER} r={5} fill="#1a1a2e" />

            {/* Cross lines */}
            <line x1={CENTER} y1={15} x2={CENTER} y2={SIZE - 15} stroke="#e5e7eb" strokeWidth={1} />
            <line x1={15} y1={CENTER} x2={SIZE - 15} y2={CENTER} stroke="#e5e7eb" strokeWidth={1} />

            {/* Use case dots */}
            {Object.entries(byPriority).map(([priority, ucs]) =>
              ucs.slice(0, 5).map((uc, index) => {
                const pos = getPosition(uc, index, ucs.length);
                const color = AREA_COLORS[uc.functional_area] || AREA_COLORS['Other'];
                
                return (
                  <g key={uc.id}>
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r={14}
                      fill={`${color}30`}
                      stroke={color}
                      strokeWidth={1.5}
                    />
                    <text
                      x={pos.x}
                      y={pos.y}
                      textAnchor="middle"
                      dominantBaseline="central"
                      className="text-[7px] font-medium"
                      fill={color}
                    >
                      {(uc.use_case || '').slice(0, 5)}
                    </text>
                  </g>
                );
              })
            )}
          </svg>
        </div>

        {/* Use Cases Table */}
        <div className="flex-1 space-y-3 overflow-hidden">
          <h3 className="font-semibold text-gray-900 text-sm flex items-center gap-2">
            <Table className="w-4 h-4" />
            Use Cases Detail
          </h3>
          
          <div className="space-y-3 max-h-[380px] overflow-hidden">
            {priorityRings.map(ring => {
              const ucs = byPriority[ring.priority] || [];
              if (ucs.length === 0) return null;

              return (
                <div key={ring.priority}>
                  {/* Priority header */}
                  <div 
                    className="flex items-center gap-2 px-3 py-1.5 rounded-t"
                    style={{ backgroundColor: `${ring.color}15` }}
                  >
                    <div 
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: ring.color }}
                    />
                    <span className="text-xs font-semibold" style={{ color: ring.color }}>
                      {ring.label} Priority ({ucs.length})
                    </span>
                  </div>

                  {/* Use cases in this priority */}
                  <div className="bg-white border border-t-0 rounded-b divide-y divide-gray-100">
                    {ucs.slice(0, 4).map(uc => {
                      const areaColor = AREA_COLORS[uc.functional_area] || AREA_COLORS['Other'];
                      const statusInfo = STATUS_COLORS[uc.status || 'identified'] || STATUS_COLORS.identified;
                      const isLinked = !!uc.opportunity_id;
                      const confidence = uc.confidence_score ? Math.round(uc.confidence_score * 100) : null;

                      return (
                        <div key={uc.id} className="px-3 py-2 flex items-start gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-medium text-gray-900 leading-snug">
                              {normalizeText(uc.use_case || '')}
                            </p>
                            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                              <span className="text-[10px] text-gray-500">{uc.functional_area}</span>
                              {isLinked ? (
                                <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-medium">Linked</span>
                              ) : confidence !== null && (
                                <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-700 font-medium">{confidence}% conf</span>
                              )}
                            </div>
                          </div>
                          <span 
                            className="text-[10px] px-2 py-0.5 rounded shrink-0"
                            style={{ backgroundColor: statusInfo.bg, color: statusInfo.text }}
                          >
                            {uc.status || 'identified'}
                          </span>
                        </div>
                      );
                    })}
                    {ucs.length > 4 && (
                      <div className="px-3 py-1.5 text-center">
                        <span className="text-[10px] text-gray-500">+{ucs.length - 4} more</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

import { Users, Crown, Shield, Eye, Target, AlertTriangle, Briefcase, UserCheck, Activity, Heart } from 'lucide-react';

interface Contact {
  id: string;
  name?: string;
  role?: string;
  email?: string;
  stakeholder_type?: string | null;
  influence_level?: number | null;
  sentiment?: number | null;
  champion_score?: number | null;
}

interface MAPStakeholderMapProps {
  contacts: Contact[];
}

const STAKEHOLDER_TYPES: Record<string, { label: string; icon: React.ElementType; color: string; bg: string }> = {
  'Champion': { label: 'Champion', icon: Crown, color: '#16a34a', bg: '#f0fdf4' },
  'Economic Buyer': { label: 'Economic Buyer', icon: Briefcase, color: '#7c3aed', bg: '#f5f3ff' },
  'Technical Buyer': { label: 'Technical Buyer', icon: Shield, color: '#2563eb', bg: '#dbeafe' },
  'Decision Criteria Owner': { label: 'Decision Criteria', icon: Target, color: '#0891b2', bg: '#ecfeff' },
  'Coach': { label: 'Coach', icon: UserCheck, color: '#059669', bg: '#d1fae5' },
  'Influencer': { label: 'Influencer', icon: Eye, color: '#f59e0b', bg: '#fef3c7' },
  'Blocker': { label: 'Blocker', icon: AlertTriangle, color: '#dc2626', bg: '#fef2f2' },
  'Detractor': { label: 'Detractor', icon: AlertTriangle, color: '#ea580c', bg: '#fff7ed' },
  'End User': { label: 'End User', icon: Users, color: '#6b7280', bg: '#f3f4f6' },
  'Unknown': { label: 'Unknown', icon: Users, color: '#9ca3af', bg: '#f9fafb' },
};

function getSentimentColor(sentiment: number | null | undefined): string {
  if (sentiment === null || sentiment === undefined) return '#9ca3af';
  if (sentiment >= 70) return '#16a34a';
  if (sentiment >= 40) return '#f59e0b';
  return '#dc2626';
}

function getInfluenceTier(influence: number | null | undefined): { label: string; level: number } {
  if (influence === null || influence === undefined) return { label: 'Unknown', level: 0 };
  if (influence >= 75) return { label: 'Executive', level: 4 };
  if (influence >= 50) return { label: 'Senior', level: 3 };
  if (influence >= 25) return { label: 'Mid-Level', level: 2 };
  return { label: 'Individual', level: 1 };
}

export function MAPStakeholderMap({ contacts }: MAPStakeholderMapProps) {
  // Calculate key stats
  const champions = contacts.filter(c => c.stakeholder_type === 'Champion').length;
  const buyers = contacts.filter(c => c.stakeholder_type === 'Economic Buyer' || c.stakeholder_type === 'Technical Buyer').length;
  const highInfluence = contacts.filter(c => (c.influence_level || 0) >= 60).length;
  const avgSentiment = contacts.length > 0 
    ? Math.round(contacts.reduce((sum, c) => sum + (c.sentiment || 50), 0) / contacts.length)
    : 0;

  return (
    <div className="p-8 h-full flex flex-col pb-12">
      {/* Section Header */}
      <div className="flex items-start gap-4 mb-5">
        <div 
          className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
          style={{ backgroundColor: '#6366f120' }}
        >
          <Users className="w-6 h-6" style={{ color: '#6366f1' }} />
        </div>
        <div className="flex-1">
          <h2 className="text-2xl font-bold text-gray-900">Stakeholder Map</h2>
          <p className="text-sm text-gray-500 mt-0.5">
            Key relationships and influence dynamics
          </p>
        </div>
      </div>

      {/* Key Stats Bar - Matching screenshot style */}
      <div className="grid grid-cols-5 gap-3 mb-6">
        <div className="bg-gray-50 rounded-xl p-4 border border-gray-200 text-center">
          <p className="text-3xl font-bold text-gray-800">{contacts.length}</p>
          <p className="text-xs text-gray-500 mt-1">Total Stakeholders</p>
        </div>
        <div className="bg-yellow-50 rounded-xl p-4 border border-yellow-200 text-center">
          <p className="text-3xl font-bold text-yellow-600">{champions}</p>
          <p className="text-xs text-yellow-600 mt-1">Champions</p>
        </div>
        <div className="bg-purple-50 rounded-xl p-4 border border-purple-200 text-center">
          <p className="text-3xl font-bold text-purple-600">{buyers}</p>
          <p className="text-xs text-purple-600 mt-1">Buyers</p>
        </div>
        <div className="bg-blue-50 rounded-xl p-4 border border-blue-200 text-center">
          <p className="text-3xl font-bold text-blue-600">{highInfluence}</p>
          <p className="text-xs text-blue-600 mt-1">High Influence</p>
        </div>
        <div 
          className="rounded-xl p-4 border text-center"
          style={{ 
            backgroundColor: `${getSentimentColor(avgSentiment)}10`,
            borderColor: `${getSentimentColor(avgSentiment)}40`
          }}
        >
          <p className="text-3xl font-bold" style={{ color: getSentimentColor(avgSentiment) }}>{avgSentiment}</p>
          <p className="text-xs mt-1" style={{ color: getSentimentColor(avgSentiment) }}>Avg Sentiment</p>
        </div>
      </div>

      {/* Main Content - Chart + Details */}
      <div className="grid grid-cols-2 gap-6 flex-1 overflow-hidden">
        {/* Left: Influence vs Sentiment Scatter Plot */}
        <div>
          <h3 className="font-semibold text-gray-900 text-sm flex items-center gap-2 mb-3">
            <Activity className="w-4 h-4 text-indigo-500" />
            Influence vs Sentiment Map
          </h3>
          
          <div className="bg-white rounded-xl border border-gray-200 p-3">
            {/* Legend */}
            <div className="flex items-center gap-4 mb-2 text-[9px]">
              <span className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded-full bg-[#3b82f6]" />
                Potential Champions
              </span>
              <span className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded-full bg-[#ef4444]" />
                Blockers
              </span>
              <span className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded-full bg-[#ec4899]" />
                Supporters
              </span>
              <span className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded-full bg-[#94a3b8]" />
                Detractors
              </span>
            </div>
            
            {/* Scatter Plot SVG */}
            <svg width="100%" height="280" viewBox="0 0 400 280" className="overflow-visible">
              {/* Background quadrants */}
              <rect x="0" y="0" width="200" height="140" fill="#fef2f2" />
              <rect x="200" y="0" width="200" height="140" fill="#eff6ff" />
              <rect x="0" y="140" width="200" height="140" fill="#f5f5f5" />
              <rect x="200" y="140" width="200" height="140" fill="#fdf2f8" />
              
              {/* Grid lines */}
              <line x1="200" y1="0" x2="200" y2="280" stroke="#e5e7eb" strokeWidth="1" />
              <line x1="0" y1="140" x2="400" y2="140" stroke="#e5e7eb" strokeWidth="1" />
              
              {/* Quadrant labels */}
              <text x="10" y="20" className="text-[10px] font-medium" fill="#ef4444">Blockers</text>
              <text x="350" y="20" className="text-[10px] font-medium" fill="#3b82f6">Champions</text>
              <text x="10" y="270" className="text-[10px] font-medium" fill="#94a3b8">Detractors</text>
              <text x="340" y="270" className="text-[10px] font-medium" fill="#ec4899">Supporters</text>
              
              {/* Axis labels */}
              <text x="5" y="145" className="text-[8px]" fill="#6b7280" transform="rotate(-90, 10, 145)">INFLUENCE →</text>
              <text x="140" y="278" className="text-[8px]" fill="#6b7280">← Negative | SENTIMENT | Positive →</text>
              
              {/* Plot contacts */}
              {contacts.map((contact, index) => {
                const sentiment = contact.sentiment || 50;
                const influence = contact.influence_level || 30;
                const championScore = contact.champion_score || 20;
                
                // Map to coordinates (sentiment: 0-100 -> 0-400, influence: 0-100 -> 280-0)
                const x = (sentiment / 100) * 400;
                const y = 280 - (influence / 100) * 280;
                
                // Determine color based on quadrant
                const isHighInfluence = influence >= 50;
                const isPositiveSentiment = sentiment >= 50;
                let color = '#94a3b8'; // Detractor (low influence, low sentiment)
                if (isHighInfluence && isPositiveSentiment) color = '#3b82f6'; // Champion
                else if (isHighInfluence && !isPositiveSentiment) color = '#ef4444'; // Blocker
                else if (!isHighInfluence && isPositiveSentiment) color = '#ec4899'; // Supporter
                
                // Size based on champion score
                const radius = Math.max(12, Math.min(30, 12 + (championScore / 100) * 20));
                
                // Get initials
                const initials = (contact.name || 'U')
                  .split(' ')
                  .map(n => n[0])
                  .join('')
                  .substring(0, 2)
                  .toUpperCase();
                
                return (
                  <g key={contact.id}>
                    <circle
                      cx={x}
                      cy={y}
                      r={radius}
                      fill={`${color}30`}
                      stroke={color}
                      strokeWidth={2}
                    />
                    <text
                      x={x}
                      y={y}
                      textAnchor="middle"
                      dominantBaseline="central"
                      className="text-[9px] font-bold"
                      fill={color}
                    >
                      {initials}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Right: Relationship Health by Role */}
        <div>
          <h3 className="font-semibold text-gray-900 text-sm flex items-center gap-2 mb-3">
            <Heart className="w-4 h-4 text-rose-500" />
            Relationship Health
          </h3>
          
          <div className="space-y-2 max-h-[310px] overflow-hidden">
            {Object.entries(
              contacts.reduce((acc, c) => {
                const type = c.stakeholder_type || 'Unknown';
                if (!acc[type]) acc[type] = [];
                acc[type].push(c);
                return acc;
              }, {} as Record<string, Contact[]>)
            ).slice(0, 5).map(([type, typeContacts]) => {
              const typeInfo = STAKEHOLDER_TYPES[type] || STAKEHOLDER_TYPES['Unknown'];
              const TypeIcon = typeInfo.icon;
              
              return (
                <div key={type} className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
                  <div 
                    className="flex items-center gap-2 px-3 py-2"
                    style={{ background: `linear-gradient(135deg, ${typeInfo.bg}, white)` }}
                  >
                    <TypeIcon className="w-4 h-4" style={{ color: typeInfo.color }} />
                    <span className="text-xs font-semibold" style={{ color: typeInfo.color }}>
                      {typeInfo.label}
                    </span>
                    <span className="text-[10px] text-gray-500 ml-auto">{typeContacts.length} people</span>
                  </div>
                  
                  <div className="divide-y divide-gray-50">
                    {typeContacts.slice(0, 3).map(contact => (
                      <div key={contact.id} className="px-3 py-2 flex items-center gap-3">
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-gray-900 truncate">{contact.name || 'Unknown'}</p>
                          <p className="text-[9px] text-gray-500 truncate">{contact.role || contact.email || '—'}</p>
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          {contact.influence_level != null && (
                            <div className="text-center">
                              <p className="text-[8px] text-gray-400 uppercase">Influence</p>
                              <p className="text-xs font-bold text-indigo-600">{contact.influence_level}</p>
                            </div>
                          )}
                          {contact.sentiment != null && (
                            <div className="text-center">
                              <p className="text-[8px] text-gray-400 uppercase">Sentiment</p>
                              <p className="text-xs font-bold" style={{ color: getSentimentColor(contact.sentiment) }}>
                                {contact.sentiment}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                    {typeContacts.length > 3 && (
                      <div className="px-3 py-1.5 text-center bg-gray-50">
                        <span className="text-[9px] text-gray-500">+{typeContacts.length - 3} more</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Risk Indicator for Blockers */}
      {contacts.some(c => c.stakeholder_type === 'Blocker' || c.stakeholder_type === 'Detractor') && (
        <div className="mt-4 p-3 bg-red-50 rounded-xl border border-red-200 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-red-500" />
          <div>
            <p className="text-sm font-medium text-red-800">
              {contacts.filter(c => c.stakeholder_type === 'Blocker' || c.stakeholder_type === 'Detractor').length} potential blocker(s) identified
            </p>
            <p className="text-xs text-red-600">Requires mitigation strategy</p>
          </div>
        </div>
      )}
    </div>
  );
}
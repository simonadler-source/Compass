import { Users, UserCircle } from 'lucide-react';

interface TeamMember {
  id: string;
  team_member_email: string;
  role: string;
}

interface Contact {
  id: string;
  name: string;
  role?: string | null;
  email?: string | null;
}

interface MAPTeamProps {
  teamMembers: TeamMember[];
  contacts: Contact[];
}

const roleLabels: Record<string, string> = {
  owner: 'Account Owner',
  member: 'Team Member',
  se: 'Solutions Engineer',
  csm: 'Customer Success Manager',
};

export function MAPTeam({ teamMembers, contacts }: MAPTeamProps) {
  // Limit display to fit on page
  const displayTeamMembers = teamMembers.slice(0, 6);
  const displayContacts = contacts.slice(0, 10);

  return (
    <div className="p-10 h-full flex flex-col pb-16">
      {/* Section Header */}
      <div className="flex items-center gap-3 mb-6">
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: '#06b6d420' }}
        >
          <Users className="w-5 h-5" style={{ color: '#06b6d4' }} />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Team & Contacts</h2>
          <p className="text-sm text-gray-500">
            {teamMembers.length} internal team members, {contacts.length} external contacts
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 flex-1">
        {/* Internal Team */}
        <div>
          <h3 className="text-base font-semibold text-gray-800 mb-3 pb-2 border-b border-gray-200 flex items-center gap-2">
            <Users className="w-4 h-4" />
            Internal Team
          </h3>
          {displayTeamMembers.length > 0 ? (
            <div className="space-y-2">
              {displayTeamMembers.map(member => (
                <div 
                  key={member.id}
                  className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg"
                >
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: '#3b82f620' }}
                  >
                    <Users className="w-4 h-4" style={{ color: '#3b82f6' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">
                      {member.team_member_email.split('@')[0]}
                    </p>
                    <p className="text-xs text-gray-500">
                      {roleLabels[member.role] || member.role}
                    </p>
                  </div>
                </div>
              ))}
              {teamMembers.length > 6 && (
                <p className="text-xs text-gray-500 text-center">
                  +{teamMembers.length - 6} more team members
                </p>
              )}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8 text-sm">No team members assigned</p>
          )}
        </div>

        {/* External Contacts */}
        <div>
          <h3 className="text-base font-semibold text-gray-800 mb-3 pb-2 border-b border-gray-200 flex items-center gap-2">
            <UserCircle className="w-4 h-4" />
            Key Contacts
          </h3>
          {displayContacts.length > 0 ? (
            <div className="space-y-2">
              {displayContacts.map(contact => (
                <div 
                  key={contact.id}
                  className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg"
                >
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: '#10b98120' }}
                  >
                    <UserCircle className="w-4 h-4" style={{ color: '#10b981' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm">{contact.name}</p>
                    {contact.role && (
                      <p className="text-xs text-gray-500 truncate">{contact.role}</p>
                    )}
                  </div>
                </div>
              ))}
              {contacts.length > 10 && (
                <p className="text-xs text-gray-500 text-center">
                  +{contacts.length - 10} more contacts
                </p>
              )}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8 text-sm">No contacts extracted yet</p>
          )}
        </div>
      </div>
    </div>
  );
}

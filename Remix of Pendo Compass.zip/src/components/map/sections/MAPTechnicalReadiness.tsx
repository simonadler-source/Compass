import { CheckCircle, XCircle, HelpCircle, AlertTriangle } from 'lucide-react';

interface ReadinessCategory {
  id: string;
  name: string;
  questions: ReadinessQuestion[];
}

interface ReadinessQuestion {
  id: string;
  question: string;
}

interface ReadinessAnswer {
  question_id: string;
  answer: string | null;
  answer_encrypted?: string | null;
  is_red_flag: boolean | null;
  manual_flag_status?: string | null;
  confidence_score?: number | null;
}

interface MAPTechnicalReadinessProps {
  categories: ReadinessCategory[];
  answers: ReadinessAnswer[];
}

export function MAPTechnicalReadiness({ categories, answers }: MAPTechnicalReadinessProps) {
  const getAnswerForQuestion = (questionId: string) => {
    return answers.find(a => a.question_id === questionId);
  };

  const getStatusIcon = (answer: ReadinessAnswer | undefined) => {
    // No answer at all - show gray question mark (unknown)
    if (!answer || (!answer.answer && !answer.answer_encrypted)) {
      return <HelpCircle size={10} style={{ color: '#9ca3af' }} />;
    }
    // is_red_flag = true means "Not Relevant" / disabled
    if (answer.is_red_flag === true) {
      return <HelpCircle size={10} style={{ color: '#9ca3af' }} />;
    }
    // Manual override takes priority
    if (answer.manual_flag_status === 'green') {
      return <CheckCircle size={10} style={{ color: '#16a34a' }} />;
    }
    if (answer.manual_flag_status === 'red') {
      return <XCircle size={10} style={{ color: '#dc2626' }} />;
    }
    if (answer.manual_flag_status === 'amber') {
      return <AlertTriangle size={10} style={{ color: '#f59e0b' }} />;
    }
    if (answer.manual_flag_status === 'disabled') {
      return <HelpCircle size={10} style={{ color: '#9ca3af' }} />;
    }
    // AI confidence scoring
    if (answer.confidence_score != null) {
      if (answer.confidence_score >= 85) return <CheckCircle size={10} style={{ color: '#16a34a' }} />;
      if (answer.confidence_score >= 60) return <AlertTriangle size={10} style={{ color: '#f59e0b' }} />;
      return <XCircle size={10} style={{ color: '#dc2626' }} />;
    }
    // Has answer but no confidence/manual = amber (needs validation)
    return <AlertTriangle size={10} style={{ color: '#f59e0b' }} />;
  };

  // Helper to count questions recursively including sub-questions
  const countAllQuestions = (questions: ReadinessQuestion[]): number => {
    return questions.reduce((sum, q) => sum + 1, 0);
  };
  
  // Calculate summary stats - count all questions including nested ones
  const totalQuestions = categories.reduce((sum, cat) => sum + cat.questions.length, 0);
  const answeredQuestions = answers.filter(a => (a.answer || a.answer_encrypted) && !a.is_red_flag).length;
  const redFlags = answers.filter(a => {
    if (a.is_red_flag) return false; // "Not Relevant" - excluded
    if (a.manual_flag_status === 'red') return true;
    if (a.manual_flag_status) return false;
    if (a.confidence_score != null) return a.confidence_score < 60;
    return false;
  }).length;
  const completionPercentage = totalQuestions > 0 ? Math.round((answeredQuestions / totalQuestions) * 100) : 0;

  return (
    <div style={{ padding: '24px 32px', paddingBottom: '40px', height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div 
            style={{ 
              width: '36px', 
              height: '36px', 
              borderRadius: '8px', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center',
              backgroundColor: '#3b82f620'
            }}
          >
            <AlertTriangle size={18} style={{ color: '#3b82f6' }} />
          </div>
          <div>
            <h2 style={{ fontSize: '18px', fontWeight: 700, color: '#111827', margin: 0 }}>
              Technical Readiness Assessment
            </h2>
            <p style={{ fontSize: '11px', color: '#6b7280', margin: 0 }}>
              Deployment readiness qualification status
            </p>
          </div>
        </div>

        {/* Summary Stats */}
        <div style={{ display: 'flex', gap: '12px' }}>
          <div style={{ textAlign: 'center', padding: '8px 16px', backgroundColor: '#f0fdf4', borderRadius: '8px' }}>
            <div style={{ fontSize: '18px', fontWeight: 700, color: '#16a34a' }}>{completionPercentage}%</div>
            <div style={{ fontSize: '9px', color: '#166534' }}>Complete</div>
          </div>
          <div style={{ textAlign: 'center', padding: '8px 16px', backgroundColor: '#eff6ff', borderRadius: '8px' }}>
            <div style={{ fontSize: '18px', fontWeight: 700, color: '#2563eb' }}>{answeredQuestions}/{totalQuestions}</div>
            <div style={{ fontSize: '9px', color: '#1e40af' }}>Answered</div>
          </div>
          {redFlags > 0 && (
            <div style={{ textAlign: 'center', padding: '8px 16px', backgroundColor: '#fef2f2', borderRadius: '8px' }}>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#dc2626' }}>{redFlags}</div>
              <div style={{ fontSize: '9px', color: '#991b1b' }}>Red Flags</div>
            </div>
          )}
        </div>
      </div>

      {/* Categories Grid - All questions displayed */}
      <div style={{ 
        flex: 1, 
        display: 'grid', 
        gridTemplateColumns: 'repeat(3, 1fr)', 
        gap: '12px',
        overflow: 'hidden',
      }}>
        {categories.map((category) => (
          <div 
            key={category.id}
            style={{ 
              backgroundColor: '#f9fafb', 
              borderRadius: '6px',
              padding: '10px',
              border: '1px solid #e5e7eb',
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
            }}
          >
            <h3 style={{ 
              fontSize: '11px', 
              fontWeight: 600, 
              color: '#111827',
              marginBottom: '8px',
              borderBottom: '1px solid #e5e7eb',
              paddingBottom: '6px',
            }}>
              {category.name}
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', flex: 1, overflow: 'hidden' }}>
              {category.questions.map((question) => {
                const answer = getAnswerForQuestion(question.id);
                return (
                  <div 
                    key={question.id}
                    style={{ 
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '6px',
                      padding: '4px 6px',
                      backgroundColor: answer?.is_red_flag ? '#fef2f2' : 'white',
                      borderRadius: '4px',
                      border: `1px solid ${answer?.is_red_flag ? '#fecaca' : '#e5e7eb'}`,
                    }}
                  >
                    <div style={{ flexShrink: 0, marginTop: '1px' }}>
                      {getStatusIcon(answer)}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ 
                        fontSize: '8px', 
                        color: '#374151',
                        lineHeight: '1.2',
                        marginBottom: answer?.answer ? '2px' : 0,
                      }}>
                        {question.question.length > 80 
                          ? question.question.substring(0, 80) + '...' 
                          : question.question}
                      </div>
                      {answer?.answer && (
                        <div style={{ 
                          fontSize: '7px', 
                          color: answer.is_red_flag ? '#dc2626' : '#059669',
                          fontWeight: 500,
                        }}>
                          {answer.answer.length > 50 
                            ? answer.answer.substring(0, 50) + '...' 
                            : answer.answer}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {categories.length === 0 && (
        <div style={{ 
          flex: 1,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#6b7280',
          fontSize: '12px',
        }}>
          No readiness categories configured
        </div>
      )}
    </div>
  );
}

import { Lightbulb, CheckCircle2, Circle, Sparkles, User, Users, Link2, Target } from 'lucide-react';

interface UseCase {
  id: string;
  use_case: string;
  functional_area: string;
  description?: string | null;
  priority?: string | null;
  status: string;
  source?: string | null;
  confidence_score?: number | null;
  acceptance_status?: string | null;
  mentioned_by_type?: string | null;
  opportunity_id?: string | null;
}

interface MAPUseCasesProps {
  useCases: UseCase[];
  opportunityId?: string;
}

const PRIORITY_STYLES: Record<string, { bg: string; text: string; border: string; gradient: string }> = {
  critical: { bg: '#fef2f2', text: '#dc2626', border: '#fecaca', gradient: 'from-red-50 to-red-100' },
  high: { bg: '#fff7ed', text: '#ea580c', border: '#fed7aa', gradient: 'from-orange-50 to-orange-100' },
  medium: { bg: '#fefce8', text: '#ca8a04', border: '#fef08a', gradient: 'from-yellow-50 to-yellow-100' },
  low: { bg: '#f0fdf4', text: '#16a34a', border: '#bbf7d0', gradient: 'from-green-50 to-green-100' },
};

const STATUS_CONFIG: Record<string, { icon: typeof CheckCircle2; color: string; label: string }> = {
  identified: { icon: Circle, color: '#6b7280', label: 'Identified' },
  validated: { icon: Sparkles, color: '#f59e0b', label: 'Validated' },
  in_progress: { icon: Sparkles, color: '#3b82f6', label: 'In Progress' },
  implemented: { icon: CheckCircle2, color: '#10b981', label: 'Implemented' },
  completed: { icon: CheckCircle2, color: '#10b981', label: 'Completed' },
};

const ACCEPTANCE_STYLES: Record<string, { bg: string; text: string; label: string; icon: typeof User }> = {
  validated: { bg: '#dcfce7', text: '#15803d', label: 'Prospect Mentioned', icon: User },
  accepted: { bg: '#dbeafe', text: '#1d4ed8', label: 'Prospect Confirmed', icon: User },
  proposed: { bg: '#fef3c7', text: '#b45309', label: 'Team Proposed', icon: Users },
};

export function MAPUseCases({ useCases, opportunityId }: MAPUseCasesProps) {
  // Separate linked vs suggested
  const linkedUseCases = useCases.filter(uc => uc.opportunity_id === opportunityId);
  const suggestedUseCases = useCases.filter(
    uc => !uc.opportunity_id && (uc.confidence_score || 0) >= 0.7
  );
  
  // Include ALL use cases that have content (linked first, then suggested)
  const allDisplayUseCases = [
    ...linkedUseCases,
    ...suggestedUseCases,
    ...useCases.filter(uc => 
      uc.use_case && 
      !linkedUseCases.includes(uc) && 
      !suggestedUseCases.includes(uc)
    )
  ].filter(uc => uc.use_case);

  // Group by functional area
  const groupedUseCases: Record<string, UseCase[]> = {};
  allDisplayUseCases.forEach(uc => {
    const area = uc.functional_area || 'Other';
    if (!groupedUseCases[area]) {
      groupedUseCases[area] = [];
    }
    groupedUseCases[area].push(uc);
  });

  // Sort areas by number of use cases
  const sortedAreas = Object.entries(groupedUseCases)
    .sort((a, b) => b[1].length - a[1].length);

  // Calculate stats
  const prospectConfirmed = allDisplayUseCases.filter(uc => 
    uc.acceptance_status === 'validated' || uc.acceptance_status === 'accepted'
  ).length;
  const implemented = allDisplayUseCases.filter(uc => 
    uc.status === 'implemented' || uc.status === 'completed'
  ).length;

  return (
    <div className="p-8 h-full flex flex-col pb-12">
      {/* Section Header */}
      <div className="flex items-start gap-4 mb-5">
        <div 
          className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
          style={{ backgroundColor: '#f59e0b20' }}
        >
          <Lightbulb className="w-6 h-6" style={{ color: '#f59e0b' }} />
        </div>
        <div className="flex-1">
          <h2 className="text-2xl font-bold text-gray-900">Use Cases</h2>
          <p className="text-sm text-gray-500 mt-0.5">
            Identified opportunities for value delivery
          </p>
        </div>
      </div>

      {/* Stats Summary Row */}
      <div className="grid grid-cols-5 gap-3 mb-5">
        <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-3 border border-gray-200 text-center">
          <p className="text-2xl font-bold text-gray-800">{allDisplayUseCases.length}</p>
          <p className="text-[10px] text-gray-600 font-medium">Total Use Cases</p>
        </div>
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-3 border border-blue-200 text-center">
          <p className="text-2xl font-bold text-blue-700">{linkedUseCases.length}</p>
          <p className="text-[10px] text-blue-600 font-medium">Linked to Opp</p>
        </div>
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-3 border border-purple-200 text-center">
          <p className="text-2xl font-bold text-purple-700">{suggestedUseCases.length}</p>
          <p className="text-[10px] text-purple-600 font-medium">AI Suggested</p>
        </div>
        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-3 border border-green-200 text-center">
          <p className="text-2xl font-bold text-green-700">{prospectConfirmed}</p>
          <p className="text-[10px] text-green-600 font-medium">Prospect Confirmed</p>
        </div>
        <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-lg p-3 border border-emerald-200 text-center">
          <p className="text-2xl font-bold text-emerald-700">{implemented}</p>
          <p className="text-[10px] text-emerald-600 font-medium">Implemented</p>
        </div>
      </div>

      {/* Use Cases by Area - Full Width Layout */}
      <div className="flex-1 overflow-hidden space-y-4">
        {sortedAreas.map(([area, areaUseCases]) => (
          <div 
            key={area} 
            className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm"
          >
            {/* Area Header */}
            <div className="px-4 py-2.5 bg-gradient-to-r from-gray-50 to-white border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-gray-500" />
                  <h3 className="font-semibold text-gray-800 text-sm">{area}</h3>
                </div>
                <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
                  {areaUseCases.length}
                </span>
              </div>
            </div>
            
            {/* Use Case Grid - Full Width */}
            <div className="p-3 grid grid-cols-2 gap-2">
              {areaUseCases.map(uc => {
                const priority = PRIORITY_STYLES[uc.priority || 'low'] || PRIORITY_STYLES.low;
                const statusInfo = STATUS_CONFIG[uc.status] || STATUS_CONFIG.identified;
                const StatusIcon = statusInfo.icon;
                const acceptance = uc.acceptance_status ? ACCEPTANCE_STYLES[uc.acceptance_status] : null;
                const isLinked = linkedUseCases.includes(uc);
                const isSuggested = suggestedUseCases.includes(uc);

                return (
                  <div
                    key={uc.id}
                    className="rounded-lg p-3"
                    style={{
                      background: `linear-gradient(135deg, ${priority.bg}, white)`,
                      border: `1px solid ${priority.border}`,
                    }}
                  >
                    {/* Main Content Row */}
                    <div className="flex items-start gap-2">
                      <StatusIcon 
                        className="w-4 h-4 mt-0.5 shrink-0" 
                        style={{ color: statusInfo.color }}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 text-xs leading-snug">
                          {uc.use_case}
                        </p>
                        
                        {/* Description if available */}
                        {uc.description && (
                          <p className="text-[10px] text-gray-600 mt-1 line-clamp-2">
                            {uc.description}
                          </p>
                        )}
                        
                        {/* Tags Row */}
                        <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                          {/* Priority Badge */}
                          {uc.priority && (
                            <span 
                              className="text-[9px] font-semibold px-1.5 py-0.5 rounded uppercase"
                              style={{ 
                                backgroundColor: priority.text + '15',
                                color: priority.text 
                              }}
                            >
                              {uc.priority}
                            </span>
                          )}
                          
                          {/* Linked/Suggested Badge */}
                          {isLinked && (
                            <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-medium">
                              <Link2 className="w-2.5 h-2.5" />
                              Linked
                            </span>
                          )}
                          {isSuggested && (
                            <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.5 rounded bg-purple-100 text-purple-700 font-medium">
                              <Sparkles className="w-2.5 h-2.5" />
                              {Math.round((uc.confidence_score || 0) * 100)}% match
                            </span>
                          )}
                          
                          {/* Acceptance Badge */}
                          {acceptance && (
                            <span 
                              className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.5 rounded font-medium"
                              style={{ backgroundColor: acceptance.bg, color: acceptance.text }}
                            >
                              <acceptance.icon className="w-2.5 h-2.5" />
                              {acceptance.label}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {allDisplayUseCases.length === 0 && (
        <div className="text-center py-12 flex-1 flex flex-col items-center justify-center">
          <div className="w-16 h-16 rounded-full bg-amber-50 flex items-center justify-center mb-4">
            <Lightbulb className="w-8 h-8 text-amber-300" />
          </div>
          <p className="text-gray-500">No use cases identified yet</p>
          <p className="text-xs text-gray-400 mt-1">Use cases will appear as they are discovered in meetings</p>
        </div>
      )}
    </div>
  );
}

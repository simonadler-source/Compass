import { CheckCircle, Clock, Circle, AlertCircle, ClipboardList } from 'lucide-react';

interface ValidationTask {
  id: string;
  module: string;
  sub_module: string | null;
  activity: string;
  owner: string | null;
  status: string;
  completed_at: string | null;
}

interface ValidationTemplate {
  id: string;
  module: string;
  sub_module: string | null;
  activity: string;
  default_owner: string | null;
}

interface MAPValidationTasksProps {
  tasks: ValidationTask[];
  templates?: ValidationTemplate[];
}

export function MAPValidationTasks({ tasks, templates = [] }: MAPValidationTasksProps) {
  // Use tasks if available, otherwise convert templates to display format
  const displayTasks: ValidationTask[] = tasks.length > 0 
    ? tasks 
    : templates.map(t => ({
        id: t.id,
        module: t.module,
        sub_module: t.sub_module,
        activity: t.activity,
        owner: t.default_owner,
        status: 'not_started',
        completed_at: null,
      }));

  // Group tasks by module
  const tasksByModule = displayTasks.reduce((acc, task) => {
    if (!acc[task.module]) {
      acc[task.module] = [];
    }
    acc[task.module].push(task);
    return acc;
  }, {} as Record<string, ValidationTask[]>);

  const modules = Object.keys(tasksByModule);

  // Calculate stats
  const completedTasks = displayTasks.filter(t => t.status === 'completed').length;
  const inProgressTasks = displayTasks.filter(t => t.status === 'in_progress').length;
  const blockedTasks = displayTasks.filter(t => t.status === 'blocked').length;
  const notStartedTasks = displayTasks.filter(t => t.status === 'not_started').length;
  const totalTasks = displayTasks.length;
  const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle size={9} style={{ color: '#16a34a' }} />;
      case 'in_progress':
        return <Clock size={9} style={{ color: '#2563eb' }} />;
      case 'blocked':
        return <AlertCircle size={9} style={{ color: '#dc2626' }} />;
      default:
        return <Circle size={9} style={{ color: '#9ca3af' }} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return { bg: '#dcfce7', text: '#166534' };
      case 'in_progress':
        return { bg: '#dbeafe', text: '#1e40af' };
      case 'blocked':
        return { bg: '#fef2f2', text: '#991b1b' };
      default:
        return { bg: '#f3f4f6', text: '#4b5563' };
    }
  };

  return (
    <div style={{ padding: '24px 32px', paddingBottom: '40px', height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div 
            style={{ 
              width: '36px', 
              height: '36px', 
              borderRadius: '8px', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center',
              backgroundColor: '#8b5cf620'
            }}
          >
            <ClipboardList size={18} style={{ color: '#8b5cf6' }} />
          </div>
          <div>
            <h2 style={{ fontSize: '18px', fontWeight: 700, color: '#111827', margin: 0 }}>
              Validation Tasks
            </h2>
            <p style={{ fontSize: '11px', color: '#6b7280', margin: 0 }}>
              Technical validation activities and progress
            </p>
          </div>
        </div>

        {/* Summary Stats */}
        <div style={{ display: 'flex', gap: '10px' }}>
          <div style={{ textAlign: 'center', padding: '6px 12px', backgroundColor: '#f0fdf4', borderRadius: '6px' }}>
            <div style={{ fontSize: '16px', fontWeight: 700, color: '#16a34a' }}>{completionPercentage}%</div>
            <div style={{ fontSize: '8px', color: '#166534' }}>Complete</div>
          </div>
          <div style={{ textAlign: 'center', padding: '6px 12px', backgroundColor: '#dcfce7', borderRadius: '6px' }}>
            <div style={{ fontSize: '16px', fontWeight: 700, color: '#166534' }}>{completedTasks}</div>
            <div style={{ fontSize: '8px', color: '#166534' }}>Done</div>
          </div>
          <div style={{ textAlign: 'center', padding: '6px 12px', backgroundColor: '#dbeafe', borderRadius: '6px' }}>
            <div style={{ fontSize: '16px', fontWeight: 700, color: '#1e40af' }}>{inProgressTasks}</div>
            <div style={{ fontSize: '8px', color: '#1e40af' }}>In Progress</div>
          </div>
          {blockedTasks > 0 && (
            <div style={{ textAlign: 'center', padding: '6px 12px', backgroundColor: '#fef2f2', borderRadius: '6px' }}>
              <div style={{ fontSize: '16px', fontWeight: 700, color: '#dc2626' }}>{blockedTasks}</div>
              <div style={{ fontSize: '8px', color: '#991b1b' }}>Blocked</div>
            </div>
          )}
          <div style={{ textAlign: 'center', padding: '6px 12px', backgroundColor: '#f3f4f6', borderRadius: '6px' }}>
            <div style={{ fontSize: '16px', fontWeight: 700, color: '#6b7280' }}>{notStartedTasks}</div>
            <div style={{ fontSize: '8px', color: '#4b5563' }}>Pending</div>
          </div>
        </div>
      </div>

      {/* Tasks Grid by Module - All tasks displayed */}
      <div style={{ 
        flex: 1, 
        display: 'grid', 
        gridTemplateColumns: 'repeat(3, 1fr)', 
        gap: '12px',
        overflow: 'hidden',
      }}>
        {modules.map((module) => {
          const moduleTasks = tasksByModule[module];
          const moduleCompleted = moduleTasks.filter(t => t.status === 'completed').length;
          
          return (
            <div 
              key={module}
              style={{ 
                backgroundColor: '#f9fafb', 
                borderRadius: '6px',
                padding: '10px',
                border: '1px solid #e5e7eb',
                display: 'flex',
                flexDirection: 'column',
                overflow: 'hidden',
              }}
            >
              <div style={{ 
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: '8px',
                borderBottom: '1px solid #e5e7eb',
                paddingBottom: '6px',
              }}>
                <h3 style={{ 
                  fontSize: '11px', 
                  fontWeight: 600, 
                  color: '#111827',
                  margin: 0,
                }}>
                  {module}
                </h3>
                <span style={{ 
                  fontSize: '9px', 
                  color: '#6b7280',
                  backgroundColor: '#e5e7eb',
                  padding: '2px 6px',
                  borderRadius: '4px',
                }}>
                  {moduleCompleted}/{moduleTasks.length}
                </span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', flex: 1, overflow: 'hidden' }}>
                {moduleTasks.map((task) => {
                  const statusColors = getStatusColor(task.status);
                  return (
                    <div 
                      key={task.id}
                      style={{ 
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '6px',
                        padding: '4px 6px',
                        backgroundColor: 'white',
                        borderRadius: '4px',
                        border: '1px solid #e5e7eb',
                      }}
                    >
                      <div style={{ flexShrink: 0, marginTop: '2px' }}>
                        {getStatusIcon(task.status)}
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ 
                          fontSize: '8px', 
                          color: '#374151',
                          lineHeight: '1.2',
                        }}>
                          {task.activity.length > 60 
                            ? task.activity.substring(0, 60) + '...' 
                            : task.activity}
                        </div>
                        <div style={{ 
                          display: 'flex',
                          alignItems: 'center',
                          gap: '4px',
                          marginTop: '2px',
                        }}>
                          <span style={{ 
                            fontSize: '7px',
                            padding: '1px 4px',
                            borderRadius: '2px',
                            backgroundColor: statusColors.bg,
                            color: statusColors.text,
                            textTransform: 'capitalize',
                          }}>
                            {task.status.replace('_', ' ')}
                          </span>
                          {task.owner && (
                            <span style={{ 
                              fontSize: '7px', 
                              color: '#6b7280',
                            }}>
                              {task.owner}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {modules.length === 0 && (
        <div style={{ 
          flex: 1,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#6b7280',
          fontSize: '12px',
        }}>
          No validation tasks configured
        </div>
      )}
    </div>
  );
}

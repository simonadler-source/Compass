import { useState, useMemo } from 'react';
import { Info, Users, ChevronDown, ChevronRight, Filter } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useTeamLeaders, useTeamMemberEmails } from '@/hooks/useTeamFilterEmails';
import type { DealCycleBleedResult, ProductBleedRow, PersonBleedData } from '@/hooks/useDealCycleBleedData';

type MentionFilter = 'all' | 'owned' | 'competitive';

/* ── Colour helpers ───────────────────────────────────── */

/** Cool → hot: transparent → blue → cyan → green → yellow → orange → red */
function heatColor(intensity: number): string {
  if (intensity <= 0) return 'transparent';
  // Clamp
  const t = Math.min(1, intensity);
  // HSL hue: 240 (blue) → 0 (red)
  const hue = Math.round((1 - t) * 240);
  const sat = 70 + Math.round(t * 20);
  const light = 58 - Math.round(t * 18);
  return `hsl(${hue}, ${sat}%, ${light}%)`;
}

function productTypeLabel(type: string) {
  switch (type) {
    case 'owned': return 'Pendo';
    case 'competitive': return 'Comp';
    case 'complementary': return 'Compl';
    default: return type;
  }
}

function productTypeBadgeClass(type: string) {
  switch (type) {
    case 'owned': return 'bg-primary/10 text-primary border-primary/20';
    case 'competitive': return 'bg-destructive/10 text-destructive border-destructive/20';
    case 'complementary': return 'bg-green-500/10 text-green-600 border-green-500/20';
    default: return 'bg-muted text-muted-foreground';
  }
}

/* ── Colour-scale legend ──────────────────────────────── */

function ColorScaleLegend() {
  const stops = 40;
  return (
    <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
      <span>Low</span>
      <div className="flex h-3 rounded-sm overflow-hidden" style={{ width: 160 }}>
        {Array.from({ length: stops }, (_, i) => (
          <div
            key={i}
            className="flex-1"
            style={{ backgroundColor: heatColor((i + 1) / stops) }}
          />
        ))}
      </div>
      <span>High</span>
    </div>
  );
}

/* ── X-axis header ────────────────────────────────────── */

function XAxisHeader({ bucketCount }: { bucketCount: number }) {
  const markers = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
  return (
    <div className="flex items-end border-b border-border/50 bg-muted/20">
      <div className="w-48 flex-shrink-0 px-3 py-1.5 text-xs font-medium text-muted-foreground border-r border-border/50">
        Rep
      </div>
      <div className="flex-1 relative h-6">
        {markers.map((pct) => (
          <span
            key={pct}
            className="absolute text-[9px] text-muted-foreground -translate-x-1/2"
            style={{ left: `${pct}%`, bottom: 2 }}
          >
            {pct}%
          </span>
        ))}
      </div>
    </div>
  );
}

/* ── Product stripe (for expanded view) ───────────────── */

function ProductStripe({
  product,
  globalMax,
  bucketCount,
}: {
  product: ProductBleedRow;
  globalMax: number;
  bucketCount: number;
}) {
  return (
    <div className="flex items-center h-6 group">
      <div className="w-48 flex-shrink-0 flex items-center gap-1.5 px-3 pl-10 truncate border-r border-border/30">
        <Badge variant="outline" className={cn('text-[9px] px-1 py-0 leading-tight', productTypeBadgeClass(product.mentionType))}>
          {productTypeLabel(product.mentionType)}
        </Badge>
        <span className="text-[11px] truncate text-muted-foreground">{product.productName}</span>
      </div>
      <div className="flex-1 flex">
        {product.buckets.map((b) => {
          const intensity = globalMax > 0 ? b.mentionCount / globalMax : 0;
          return (
            <Tooltip key={b.bucket}>
              <TooltipTrigger asChild>
                <div
                  className="flex-1 h-full transition-opacity hover:opacity-80"
                  style={{ backgroundColor: heatColor(intensity) }}
                />
              </TooltipTrigger>
              <TooltipContent side="top" className="text-xs max-w-52">
                <p className="font-medium">{product.productName}</p>
                <p>Deal cycle: {b.pctStart.toFixed(0)}–{b.pctEnd.toFixed(0)}%</p>
                <p>{b.mentionCount} mention{b.mentionCount !== 1 ? 's' : ''}</p>
              </TooltipContent>
            </Tooltip>
          );
        })}
      </div>
    </div>
  );
}

/* ── Person row (continuous aggregate stripe) ─────────── */

interface PersonRowProps {
  person: PersonBleedData;
  aggregateBuckets: number[];
  filteredProducts: ProductBleedRow[];
  globalMax: number;
  bucketCount: number;
}

function PersonRow({ person, aggregateBuckets, filteredProducts, globalMax, bucketCount }: PersonRowProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <Collapsible open={expanded} onOpenChange={setExpanded}>
      <CollapsibleTrigger asChild>
        <div className="flex items-center cursor-pointer hover:bg-muted/20 transition-colors">
          {/* Label */}
          <div className="w-48 flex-shrink-0 flex items-center gap-2 px-3 py-0.5 border-r border-border/30">
            <Button variant="ghost" size="sm" className="h-4 w-4 p-0 shrink-0">
              {expanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            </Button>
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-semibold text-primary shrink-0">
              {person.personName.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-medium truncate leading-tight">{person.personName}</p>
              <p className="text-[10px] text-muted-foreground leading-tight">
                {person.opportunityCount} opp{person.opportunityCount !== 1 ? 's' : ''} · {person.totalMentions} mentions
              </p>
            </div>
          </div>

          {/* Aggregate stripe */}
          <div className="flex-1 flex h-8">
            {aggregateBuckets.map((count, i) => {
              const intensity = globalMax > 0 ? count / globalMax : 0;
              const pctStart = (i / bucketCount) * 100;
              const pctEnd = ((i + 1) / bucketCount) * 100;
              return (
                <Tooltip key={i}>
                  <TooltipTrigger asChild>
                    <div
                      className="flex-1 h-full transition-opacity hover:opacity-80"
                      style={{ backgroundColor: heatColor(intensity) }}
                    />
                  </TooltipTrigger>
                  <TooltipContent side="top" className="text-xs">
                    <p className="font-medium">{person.personName}</p>
                    <p>Deal cycle: {pctStart.toFixed(0)}–{pctEnd.toFixed(0)}%</p>
                    <p>{count} mention{count !== 1 ? 's' : ''}</p>
                  </TooltipContent>
                </Tooltip>
              );
            })}
          </div>
        </div>
      </CollapsibleTrigger>

      <CollapsibleContent>
        <div className="border-t border-border/20 bg-muted/5">
          {filteredProducts.map((product) => (
            <ProductStripe
              key={product.productName}
              product={product}
              globalMax={globalMax}
              bucketCount={bucketCount}
            />
          ))}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

/* ── Main component ───────────────────────────────────── */

interface DealCycleBleedPlotProps {
  data: DealCycleBleedResult | undefined;
  isLoading: boolean;
}

export function DealCycleBleedPlot({ data, isLoading }: DealCycleBleedPlotProps) {
  const [mentionFilter, setMentionFilter] = useState<MentionFilter>('all');
  const [selectedLeader, setSelectedLeader] = useState<string>('all-teams');

  // Team hierarchy lookups
  const { data: leaders } = useTeamLeaders();
  const { data: teamEmails } = useTeamMemberEmails(selectedLeader && selectedLeader !== 'all-teams' ? selectedLeader : undefined);

  // Filter persons by team leader
  const visiblePersons = useMemo(() => {
    if (!data) return [];
    let persons = data.persons;
    if (teamEmails?.length) {
      persons = persons.filter((p) => teamEmails.includes(p.personEmail));
    }
    return persons;
  }, [data, teamEmails]);

  // Compute aggregate buckets per person (filtered by mention type)
  const personRows = useMemo(() => {
    const bc = data?.bucketCount || 100;
    return visiblePersons
      .map((person) => {
        const products =
          mentionFilter === 'all'
            ? person.products
            : person.products.filter((p) => p.mentionType === mentionFilter);

        const aggBuckets = Array.from({ length: bc }, (_, i) =>
          products.reduce((sum, p) => sum + (p.buckets[i]?.mentionCount || 0), 0),
        );
        const filteredTotal = products.reduce((s, p) => s + p.totalMentions, 0);

        return { person, products, aggBuckets, filteredTotal };
      })
      .filter((r) => r.filteredTotal > 0)
      .sort((a, b) => b.filteredTotal - a.filteredTotal);
  }, [visiblePersons, mentionFilter, data?.bucketCount]);

  // Global max for colour consistency
  const globalMax = useMemo(() => {
    let max = 1;
    personRows.forEach((r) => r.aggBuckets.forEach((v) => { if (v > max) max = v; }));
    return max;
  }, [personRows]);

  /* ── Loading / empty states ─────────────────────────── */

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex items-center justify-center gap-3">
            <div className="animate-spin w-6 h-6 border-4 border-primary border-t-transparent rounded-full" />
            <p className="text-muted-foreground">Normalising deal cycles…</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!data || data.persons.length === 0) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="text-center text-muted-foreground">
            <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>No product mentions linked to opportunities found</p>
            <p className="text-sm mt-1">Mentions need a transcript date and linked opportunity with an owner</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <TooltipProvider delayDuration={100}>
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Deal Cycle Bleed by Rep
              </CardTitle>
              <CardDescription>
                When each rep mentions products across their normalised deal lifecycle (0 → 100&nbsp;%)
              </CardDescription>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {/* Team leader filter */}
              {leaders && leaders.length > 0 && (
                <Select value={selectedLeader} onValueChange={setSelectedLeader}>
                  <SelectTrigger className="w-[180px] h-8 text-xs">
                    <Filter className="h-3 w-3 mr-1 shrink-0" />
                    <SelectValue placeholder="All teams" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-teams">All teams</SelectItem>
                    {leaders.map((l) => (
                      <SelectItem key={l.id} value={l.id}>
                        {l.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              {/* Mention type */}
              <ToggleGroup
                type="single"
                value={mentionFilter}
                onValueChange={(v) => v && setMentionFilter(v as MentionFilter)}
                className="bg-muted rounded-md p-0.5"
              >
                <ToggleGroupItem value="all" className="text-xs h-7 px-2.5 data-[state=on]:bg-background">
                  All
                </ToggleGroupItem>
                <ToggleGroupItem value="owned" className="text-xs h-7 px-2.5 data-[state=on]:bg-background">
                  Pendo
                </ToggleGroupItem>
                <ToggleGroupItem value="competitive" className="text-xs h-7 px-2.5 data-[state=on]:bg-background">
                  Competitive
                </ToggleGroupItem>
              </ToggleGroup>

              <ColorScaleLegend />
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          {/* X-axis header */}
          <XAxisHeader bucketCount={data.bucketCount} />

          {/* Person rows */}
          <ScrollArea className="max-h-[640px]">
            <div className="divide-y divide-border/20">
              {personRows.map((row) => (
                <PersonRow
                  key={row.person.personEmail}
                  person={row.person}
                  aggregateBuckets={row.aggBuckets}
                  filteredProducts={row.products}
                  globalMax={globalMax}
                  bucketCount={data.bucketCount}
                />
              ))}
            </div>
          </ScrollArea>

          {/* Summary footer */}
          <div className="flex items-center justify-between px-4 py-2 border-t border-border/50 bg-muted/10 text-xs text-muted-foreground">
            <span>
              {personRows.length} rep{personRows.length !== 1 ? 's' : ''} ·{' '}
              {personRows.reduce((s, r) => s + r.filteredTotal, 0)} total mentions
            </span>
            <span>Click a row to expand product breakdown</span>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
}

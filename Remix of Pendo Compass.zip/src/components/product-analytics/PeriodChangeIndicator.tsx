import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PeriodChangeIndicatorProps {
  current: number;
  previous: number;
  className?: string;
}

export function PeriodChangeIndicator({ current, previous, className }: PeriodChangeIndicatorProps) {
  if (previous === 0 && current === 0) {
    return (
      <span className={cn('inline-flex items-center gap-1 text-xs text-muted-foreground', className)}>
        <Minus className="h-3 w-3" />
        No change
      </span>
    );
  }

  if (previous === 0) {
    return (
      <span className={cn('inline-flex items-center gap-1 text-xs text-green-600', className)}>
        <TrendingUp className="h-3 w-3" />
        New
      </span>
    );
  }

  const pctChange = ((current - previous) / previous) * 100;
  const isPositive = pctChange > 0;
  const isNeutral = Math.abs(pctChange) < 1;

  if (isNeutral) {
    return (
      <span className={cn('inline-flex items-center gap-1 text-xs text-muted-foreground', className)}>
        <Minus className="h-3 w-3" />
        ~0%
      </span>
    );
  }

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 text-xs',
        isPositive ? 'text-green-600' : 'text-destructive',
        className
      )}
    >
      {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
      {isPositive ? '+' : ''}{pctChange.toFixed(0)}%
    </span>
  );
}

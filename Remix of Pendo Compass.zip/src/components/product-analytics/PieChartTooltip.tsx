export interface OtherBreakdownItem {
  name: string;
  value: number;
}

interface PieChartTooltipProps {
  active?: boolean;
  payload?: Array<{
    name: string;
    value: number;
    payload: { fill: string; name: string; value: number; otherBreakdown?: OtherBreakdownItem[] };
  }>;
  total: number;
}

export function PieChartTooltip({ active, payload, total }: PieChartTooltipProps) {
  if (!active || !payload?.length) return null;

  const entry = payload[0];
  const pct = total > 0 ? ((entry.value / total) * 100).toFixed(1) : '0';
  const otherBreakdown = entry.payload.otherBreakdown;

  // "Other" segment — show each rolled-up product
  if (entry.name === 'Other' && otherBreakdown?.length) {
    return (
      <div className="rounded-lg border bg-popover px-3 py-2 text-popover-foreground shadow-md text-xs space-y-1.5 max-h-64 overflow-y-auto min-w-[180px]">
        <div className="font-medium text-muted-foreground pb-0.5 border-b border-border mb-1">
          Other ({entry.value.toLocaleString()} mentions, {pct}%)
        </div>
        {otherBreakdown.map((item) => {
          const itemPct = total > 0 ? ((item.value / total) * 100).toFixed(1) : '0';
          return (
            <div key={item.name} className="flex items-center justify-between gap-3">
              <span className="truncate">{item.name}</span>
              <span className="text-muted-foreground whitespace-nowrap">
                {item.value.toLocaleString()} <span className="text-[10px]">({itemPct}%)</span>
              </span>
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="rounded-lg border bg-popover px-3 py-2 text-popover-foreground shadow-md text-xs space-y-1">
      <div className="flex items-center gap-2 font-medium">
        <span
          className="inline-block h-2.5 w-2.5 rounded-full shrink-0"
          style={{ backgroundColor: entry.payload.fill }}
        />
        {entry.name}
      </div>
      <div className="flex items-center justify-between gap-4 text-muted-foreground">
        <span>Mentions</span>
        <span className="font-semibold text-foreground">{entry.value.toLocaleString()}</span>
      </div>
      <div className="flex items-center justify-between gap-4 text-muted-foreground">
        <span>Share</span>
        <span className="font-semibold text-foreground">{pct}%</span>
      </div>
    </div>
  );
}

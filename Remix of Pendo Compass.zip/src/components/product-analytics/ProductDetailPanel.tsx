import { useState } from 'react';
import { format } from 'date-fns';
import { MessageSquare, ExternalLink, Package, Swords } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useProductExcerpts, type DateRange } from '@/hooks/useProductMentions';

const SENTIMENT_CONFIG: Record<string, { bgClass: string }> = {
  positive: { bgClass: 'bg-green-500/20 text-green-600 border-green-500/30' },
  neutral: { bgClass: 'bg-muted text-muted-foreground' },
  negative: { bgClass: 'bg-destructive/20 text-destructive border-destructive/30' },
  mixed: { bgClass: 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30' },
};

interface ProductDetailPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  productName: string;
  mentionType: 'owned' | 'competitive';
  dateRange: DateRange;
}

export function ProductDetailPanel({ open, onOpenChange, productName, mentionType, dateRange }: ProductDetailPanelProps) {
  const navigate = useNavigate();
  const { data: excerpts, isLoading } = useProductExcerpts(productName, dateRange);

  const handleNavigateToTranscript = (accountId: string | null, transcriptId: string) => {
    if (accountId) {
      navigate(`/accounts/${accountId}?tab=transcripts&transcript=${transcriptId}`);
      onOpenChange(false);
    }
  };

  const Icon = mentionType === 'owned' ? Package : Swords;
  const iconColor = mentionType === 'owned' ? 'text-primary' : 'text-destructive';

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-[520px] sm:max-w-[520px]">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Icon className={cn('h-5 w-5', iconColor)} />
            {productName}
          </SheetTitle>
          <SheetDescription>
            {excerpts && excerpts.length > 0 ? (
              <>
                {excerpts.reduce((sum, e) => sum + (e.mention_count || 1), 0)} mentions across {excerpts.length} transcript{excerpts.length !== 1 ? 's' : ''}
              </>
            ) : (
              <>Transcript excerpts mentioning this {mentionType === 'owned' ? 'product' : 'competitor'}</>
            )}
          </SheetDescription>
        </SheetHeader>

        <ScrollArea className="h-[calc(100vh-180px)] mt-6">
          {isLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="space-y-2 p-4 border rounded-lg">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-3 w-48" />
                </div>
              ))}
            </div>
          ) : !excerpts || excerpts.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <MessageSquare className="h-10 w-10 mx-auto mb-3 opacity-40" />
              <p>No excerpts found for {productName} in this period</p>
            </div>
          ) : (
            <div className="space-y-3 pr-4">
              <p className="text-xs text-muted-foreground mb-4">
                {excerpts.reduce((sum, e) => sum + (e.mention_count || 1), 0)} total mentions across {excerpts.length} transcript{excerpts.length !== 1 ? 's' : ''}
              </p>
              {excerpts.map((excerpt) => (
                <div
                  key={excerpt.id}
                  className="p-4 border rounded-lg hover:bg-muted/30 transition-colors space-y-3"
                >
                  {/* Sentiment badge */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {excerpt.account_name && (
                        <Badge variant="secondary" className="text-xs">
                          {excerpt.account_name}
                        </Badge>
                      )}
                      {(excerpt.mention_count || 1) > 1 && (
                        <Badge variant="outline" className="text-xs">
                          {excerpt.mention_count}× mentioned
                        </Badge>
                      )}
                    </div>
                    {excerpt.sentiment_label && (
                      <Badge
                        variant="outline"
                        className={cn('text-xs capitalize', SENTIMENT_CONFIG[excerpt.sentiment_label]?.bgClass)}
                      >
                        {excerpt.sentiment_label}
                      </Badge>
                    )}
                  </div>

                  {/* Excerpt */}
                  {excerpt.context_snippet ? (
                    <blockquote className="text-sm text-muted-foreground italic leading-relaxed border-l-2 border-primary/30 pl-3">
                      "{excerpt.context_snippet}"
                    </blockquote>
                  ) : (
                    <p className="text-sm text-muted-foreground/60 italic">
                      No excerpt captured for this mention
                    </p>
                  )}

                  {/* Footer */}
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-2">
                      {excerpt.transcript_date && (
                        <span>{format(new Date(excerpt.transcript_date), 'MMM d, yyyy')}</span>
                      )}
                    </div>
                    {excerpt.account_id && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2 text-xs gap-1"
                        onClick={() => handleNavigateToTranscript(excerpt.account_id, excerpt.transcript_id)}
                      >
                        View <ExternalLink className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}

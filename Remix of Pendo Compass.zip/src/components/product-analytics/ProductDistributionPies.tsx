import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, Swords, Info } from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  Legend,
} from 'recharts';
import type { ProductStats } from '@/hooks/useProductMentions';
import { PieChartTooltip, type OtherBreakdownItem } from './PieChartTooltip';

// Distinct color palettes for the two pies
const PENDO_COLORS = [
  'hsl(var(--primary))',
  'hsl(210 80% 55%)',
  'hsl(190 70% 50%)',
  'hsl(230 70% 60%)',
  'hsl(250 60% 55%)',
  'hsl(170 60% 45%)',
  'hsl(200 65% 50%)',
  'hsl(220 55% 65%)',
  'hsl(240 50% 60%)',
  'hsl(180 55% 40%)',
  'hsl(260 45% 55%)',
  'hsl(210 50% 70%)',
];

const COMPETITOR_COLORS = [
  'hsl(var(--destructive))',
  'hsl(0 60% 55%)',
  'hsl(20 70% 50%)',
  'hsl(340 65% 50%)',
  'hsl(10 55% 55%)',
  'hsl(350 60% 45%)',
  'hsl(30 65% 50%)',
  'hsl(15 50% 55%)',
  'hsl(355 55% 60%)',
  'hsl(5 45% 55%)',
  'hsl(25 50% 45%)',
  'hsl(345 40% 55%)',
];

interface ProductDistributionPiesProps {
  stats: ProductStats[];
  isLoading: boolean;
  onProductClick?: (productName: string, mentionType: 'owned' | 'competitive') => void;
}

interface PieDataEntry {
  name: string;
  value: number;
  fill: string;
  otherBreakdown?: OtherBreakdownItem[];
}

function buildPieData(products: ProductStats[], colors: string[], maxSlices = 10): PieDataEntry[] {
  const sorted = [...products].sort((a, b) => b.total_mentions - a.total_mentions);
  const topProducts = sorted.slice(0, maxSlices);
  const otherProducts = sorted.slice(maxSlices);
  const otherTotal = otherProducts.reduce((sum, p) => sum + p.total_mentions, 0);

  const data: PieDataEntry[] = topProducts.map((p, i) => ({
    name: p.product_name,
    value: p.total_mentions,
    fill: colors[i % colors.length],
  }));

  if (otherTotal > 0) {
    data.push({
      name: 'Other',
      value: otherTotal,
      fill: 'hsl(var(--muted-foreground))',
      otherBreakdown: otherProducts
        .sort((a, b) => b.total_mentions - a.total_mentions)
        .map(p => ({ name: p.product_name, value: p.total_mentions })),
    });
  }

  return data;
}

const renderCustomLabel = ({ name, percent }: { name: string; percent: number }) => {
  if (percent < 0.05) return null;
  return `${name} ${(percent * 100).toFixed(0)}%`;
};

export function ProductDistributionPies({ stats, isLoading, onProductClick }: ProductDistributionPiesProps) {
  const ownedProducts = useMemo(() => stats.filter(s => s.mention_type === 'owned'), [stats]);
  const competitiveProducts = useMemo(() => stats.filter(s => s.mention_type === 'competitive'), [stats]);

  const ownedPieData = useMemo(() => buildPieData(ownedProducts, PENDO_COLORS), [ownedProducts]);
  const competitivePieData = useMemo(() => buildPieData(competitiveProducts, COMPETITOR_COLORS), [competitiveProducts]);

  const ownedTotal = ownedPieData.reduce((s, d) => s + d.value, 0);
  const competitiveTotal = competitivePieData.reduce((s, d) => s + d.value, 0);

  return (
    <>
      {/* Pendo Products Pie */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Package className="h-4 w-4 text-primary" />
            Pendo Product Mentions
          </CardTitle>
          <CardDescription className="text-xs">Click a segment for conversation excerpts</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="h-[260px] flex items-center justify-center">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
            </div>
          ) : ownedPieData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={ownedPieData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={80}
                  paddingAngle={2}
                  label={renderCustomLabel}
                  labelLine={{ strokeWidth: 1 }}
                  fontSize={10}
                  onClick={(data) => data?.name && onProductClick?.(data.name, 'owned')}
                  className="cursor-pointer"
                >
                  {ownedPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <RechartsTooltip content={<PieChartTooltip total={ownedTotal} />} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[260px] flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <Info className="h-8 w-8 mx-auto mb-2 opacity-40" />
                <p className="text-sm">No Pendo product mentions</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Competitor Products Pie */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Swords className="h-4 w-4 text-destructive" />
            Competitor Mentions
          </CardTitle>
          <CardDescription className="text-xs">Click a segment for conversation excerpts</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="h-[260px] flex items-center justify-center">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
            </div>
          ) : competitivePieData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={competitivePieData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={80}
                  paddingAngle={2}
                  label={renderCustomLabel}
                  labelLine={{ strokeWidth: 1 }}
                  fontSize={10}
                  onClick={(data) => data?.name && onProductClick?.(data.name, 'competitive')}
                  className="cursor-pointer"
                >
                  {competitivePieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <RechartsTooltip content={<PieChartTooltip total={competitiveTotal} />} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[260px] flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <Info className="h-8 w-8 mx-auto mb-2 opacity-40" />
                <p className="text-sm">No competitor mentions</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}

import { useState } from 'react';
import { format } from 'date-fns';
import { MessageSquare, ExternalLink, Users, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useSentimentExcerpts, type DateRange } from '@/hooks/useProductMentions';

const SENTIMENT_LABELS = ['positive', 'neutral', 'negative', 'mixed'] as const;

const SENTIMENT_CONFIG: Record<string, { label: string; color: string; bgClass: string }> = {
  positive: { label: 'Positive', color: 'hsl(var(--success))', bgClass: 'bg-green-500/20 text-green-600 border-green-500/30' },
  neutral: { label: 'Neutral', color: 'hsl(var(--muted-foreground))', bgClass: 'bg-muted text-muted-foreground' },
  negative: { label: 'Negative', color: 'hsl(var(--destructive))', bgClass: 'bg-destructive/20 text-destructive border-destructive/30' },
  mixed: { label: 'Mixed', color: 'hsl(var(--warning))', bgClass: 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30' },
};

interface SentimentDetailPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  dateRange: DateRange;
  initialSentiment?: string;
}

export function SentimentDetailPanel({ open, onOpenChange, dateRange, initialSentiment }: SentimentDetailPanelProps) {
  const [activeSentiment, setActiveSentiment] = useState(initialSentiment || 'positive');
  const navigate = useNavigate();

  // Fetch excerpts for the active sentiment
  const { data: excerpts, isLoading } = useSentimentExcerpts(activeSentiment, dateRange);

  const handleNavigateToTranscript = (accountId: string | null, transcriptId: string) => {
    if (accountId) {
      navigate(`/accounts/${accountId}?tab=transcripts&transcript=${transcriptId}`);
      onOpenChange(false);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-[520px] sm:max-w-[520px]">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" />
            Sentiment Details
          </SheetTitle>
          <SheetDescription>
            Transcript excerpts grouped by sentiment classification
          </SheetDescription>
        </SheetHeader>

        <Tabs value={activeSentiment} onValueChange={setActiveSentiment} className="mt-6">
          <TabsList className="w-full grid grid-cols-4">
            {SENTIMENT_LABELS.map((s) => (
              <TabsTrigger key={s} value={s} className="text-xs capitalize">
                {s}
              </TabsTrigger>
            ))}
          </TabsList>

          {SENTIMENT_LABELS.map((sentiment) => (
            <TabsContent key={sentiment} value={sentiment} className="mt-4">
              <ScrollArea className="h-[calc(100vh-220px)]">
                {isLoading ? (
                  <div className="space-y-4">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="space-y-2 p-4 border rounded-lg">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-16 w-full" />
                        <Skeleton className="h-3 w-48" />
                      </div>
                    ))}
                  </div>
                ) : !excerpts || excerpts.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <MessageSquare className="h-10 w-10 mx-auto mb-3 opacity-40" />
                    <p>No {sentiment} excerpts found in this period</p>
                  </div>
                ) : (
                  <div className="space-y-3 pr-4">
                    <p className="text-xs text-muted-foreground mb-4">
                      {excerpts.length} excerpt{excerpts.length !== 1 ? 's' : ''} found
                    </p>
                    {excerpts.map((excerpt) => (
                      <div
                        key={excerpt.id}
                        className="p-4 border rounded-lg hover:bg-muted/30 transition-colors space-y-3"
                      >
                        {/* Product & Account */}
                        <div className="flex items-center justify-between gap-2">
                          <Badge variant="secondary" className="text-xs">
                            {excerpt.product_name}
                          </Badge>
                          <Badge
                            variant="outline"
                            className={cn('text-xs', SENTIMENT_CONFIG[sentiment]?.bgClass)}
                          >
                            {sentiment}
                          </Badge>
                        </div>

                        {/* Excerpt */}
                        {excerpt.context_snippet && (
                          <blockquote className="text-sm text-muted-foreground italic leading-relaxed border-l-2 border-primary/30 pl-3">
                            "{excerpt.context_snippet}"
                          </blockquote>
                        )}

                        {/* Footer: Account + Transcript Link */}
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <div className="flex items-center gap-2">
                            {excerpt.account_name && (
                              <span className="font-medium text-foreground">{excerpt.account_name}</span>
                            )}
                            {excerpt.transcript_date && (
                              <span>• {format(new Date(excerpt.transcript_date), 'MMM d, yyyy')}</span>
                            )}
                          </div>
                          {excerpt.account_id && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 px-2 text-xs gap-1"
                              onClick={() => handleNavigateToTranscript(excerpt.account_id, excerpt.transcript_id)}
                            >
                              View <ExternalLink className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
          ))}
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}

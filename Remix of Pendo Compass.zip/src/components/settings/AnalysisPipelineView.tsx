import { useState, useMemo, useEffect } from 'react';
import { 
  useAnalysisPipelines, 
  useAnalysisPasses, 
  usePassDependencies,
  useDetectionRulePassLinks,
  useUpdatePass,
  useReorderPasses,
  useCreatePass,
  useDeletePass,
  useUpdatePassDependencies,
  AnalysisPass,
  PassDependency
} from '@/hooks/useAnalysisPipeline';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  ArrowRight, 
  ChevronDown, 
  ChevronUp, 
  Clock, 
  Code, 
  GitBranch, 
  Loader2, 
  Play, 
  Radar, 
  Save,
  Zap,
  Link2,
  AlertTriangle,
  CheckCircle2,
  Plus,
  Trash2,
  GripVertical,
  ArrowUp,
  ArrowDown,
  Info
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

// Pipeline flow visualization
function PipelineFlowDiagram({ 
  passes, 
  dependencies,
  onSelectPass 
}: { 
  passes: AnalysisPass[];
  dependencies: PassDependency[];
  onSelectPass: (pass: AnalysisPass) => void;
}) {
  // Group passes by sync vs async
  const syncPasses = passes.filter(p => !p.is_async);
  const asyncPasses = passes.filter(p => p.is_async);
  
  // Build dependency map
  const dependencyMap = useMemo(() => {
    const map = new Map<string, string[]>();
    dependencies.forEach(dep => {
      if (!map.has(dep.pass_id)) {
        map.set(dep.pass_id, []);
      }
      map.get(dep.pass_id)!.push(dep.depends_on_pass_id);
    });
    return map;
  }, [dependencies]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'inactive': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'deprecated': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const PassNode = ({ pass, showArrow = true }: { pass: AnalysisPass; showArrow?: boolean }) => {
    const deps = dependencyMap.get(pass.id) || [];
    const hasRequiredDeps = dependencies.some(d => d.pass_id === pass.id && d.dependency_type === 'required');
    const conditionConfig = (pass as any).condition_config as { meeting_types?: string[] } | null;
    const isConditional = !!conditionConfig?.meeting_types?.length;
    
    return (
      <div className="flex items-center gap-2">
        <button
          onClick={() => onSelectPass(pass)}
          className={cn(
            "relative flex flex-col items-start p-3 rounded-lg border-2 transition-all hover:scale-105 cursor-pointer min-w-[160px]",
            pass.is_async ? "border-dashed" : "border-solid",
            isConditional
              ? "border-dashed border-amber-500/50 bg-amber-500/5 hover:bg-amber-500/10"
              : pass.status === 'active' 
                ? "border-[hsl(var(--pendo-pink))]/50 bg-[hsl(var(--pendo-pink))]/5 hover:bg-[hsl(var(--pendo-pink))]/10" 
                : "border-border bg-muted/30 hover:bg-muted/50"
          )}
        >
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono text-muted-foreground">
              {isConditional ? 'Conditional' : `Pass ${pass.sort_order}`}
            </span>
            <Badge variant="outline" className={cn("text-[10px] px-1 py-0", getStatusColor(pass.status))}>
              {pass.status}
            </Badge>
          </div>
          <span className="font-medium text-sm text-foreground">{pass.name}</span>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {pass.timeout_seconds}s
            </span>
            {pass.is_async && (
              <Badge variant="outline" className="text-[10px] px-1 py-0 bg-blue-500/10 text-blue-400 border-blue-500/30">
                Async
              </Badge>
            )}
            {isConditional && (
              <Badge variant="outline" className="text-[10px] px-1 py-0 bg-amber-500/10 text-amber-400 border-amber-500/30">
                Conditional
              </Badge>
            )}
          </div>
          {isConditional && conditionConfig?.meeting_types && (
            <div className="flex flex-wrap gap-1 mt-1.5">
              {conditionConfig.meeting_types.map(type => (
                <Badge key={type} variant="outline" className="text-[9px] px-1 py-0 bg-amber-500/10 text-amber-400 border-amber-500/30">
                  {type.replace(/_/g, ' ')}
                </Badge>
              ))}
            </div>
          )}
          {deps.length > 0 && (
            <div className="absolute -top-2 -right-2">
              <Badge 
                variant="outline" 
                className={cn(
                  "text-[10px] px-1 py-0",
                  hasRequiredDeps ? "bg-amber-500/20 text-amber-400 border-amber-500/30" : "bg-muted"
                )}
              >
                <GitBranch className="w-3 h-3 mr-0.5" />
                {deps.length}
              </Badge>
            </div>
          )}
        </button>
        {showArrow && <ArrowRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Synchronous Pipeline */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Play className="w-4 h-4 text-green-400" />
          <span className="text-sm font-medium text-foreground">Synchronous Pipeline</span>
          <span className="text-xs text-muted-foreground">(runs in sequence during import)</span>
        </div>
        <div className="flex items-center gap-1 overflow-x-auto pb-2">
          {syncPasses.map((pass, idx) => (
            <PassNode 
              key={pass.id} 
              pass={pass} 
              showArrow={idx < syncPasses.length - 1}
            />
          ))}
        </div>
      </div>

      {/* Async Enrichment */}
      {asyncPasses.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-blue-400" />
            <span className="text-sm font-medium text-foreground">Asynchronous Enrichment</span>
            <span className="text-xs text-muted-foreground">(runs in background after import)</span>
          </div>
          <div className="flex items-center gap-1 overflow-x-auto pb-2">
            {asyncPasses.map((pass, idx) => (
              <PassNode 
                key={pass.id} 
                pass={pass} 
                showArrow={idx < asyncPasses.length - 1}
              />
            ))}
          </div>
        </div>
      )}

    </div>
  );
}

// Create Pass Dialog
function CreatePassDialog({
  pipelineId,
  nextSortOrder,
  open,
  onOpenChange
}: {
  pipelineId: string;
  nextSortOrder: number;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [name, setName] = useState('');
  const [passKey, setPassKey] = useState('');
  const [description, setDescription] = useState('');
  const [systemPrompt, setSystemPrompt] = useState('');
  const [isAsync, setIsAsync] = useState(false);
  const [timeout, setTimeout] = useState(45);
  const createPass = useCreatePass();

  const handleCreate = () => {
    createPass.mutate({
      pipelineId,
      name,
      passKey: passKey || name.toLowerCase().replace(/\s+/g, '_'),
      description,
      systemPrompt,
      isAsync,
      timeoutSeconds: timeout,
      sortOrder: nextSortOrder,
    }, {
      onSuccess: () => {
        onOpenChange(false);
        setName('');
        setPassKey('');
        setDescription('');
        setSystemPrompt('');
        setIsAsync(false);
        setTimeout(45);
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            Create New Pass
          </DialogTitle>
          <DialogDescription>
            Add a new analysis pass to the pipeline.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-4 pr-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="new-pass-name">Name *</Label>
              <Input
                id="new-pass-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Custom Extraction"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-pass-key">Pass Key</Label>
              <Input
                id="new-pass-key"
                value={passKey}
                onChange={(e) => setPassKey(e.target.value)}
                placeholder="auto-generated from name"
                className="font-mono"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="new-pass-description">Description</Label>
            <Input
              id="new-pass-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What does this pass extract?"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="new-pass-timeout">Timeout (seconds)</Label>
              <Input
                id="new-pass-timeout"
                type="number"
                value={timeout}
                onChange={(e) => setTimeout(parseInt(e.target.value) || 45)}
                min={10}
                max={300}
              />
            </div>
            <div className="flex items-center gap-4 pt-6">
              <Switch
                checked={isAsync}
                onCheckedChange={setIsAsync}
              />
              <Label>Run Asynchronously</Label>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="new-pass-prompt">System Prompt *</Label>
            <Textarea
              id="new-pass-prompt"
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              className="font-mono text-sm min-h-[200px]"
              placeholder="Enter the system prompt for this analysis pass..."
            />
          </div>
        </div>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            variant="glow" 
            onClick={handleCreate}
            disabled={!name || !systemPrompt || createPass.isPending}
          >
            {createPass.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Creating...
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" />
                Create Pass
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Pass Editor Dialog
function PassEditorDialog({
  pass,
  dependencies,
  linkedRules,
  open,
  onOpenChange,
  allPasses,
  pipelineId
}: {
  pass: AnalysisPass | null;
  dependencies: PassDependency[];
  linkedRules: any[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  allPasses: AnalysisPass[];
  pipelineId: string;
}) {
  const [editedPrompt, setEditedPrompt] = useState('');
  const [editedName, setEditedName] = useState('');
  const [editedDescription, setEditedDescription] = useState('');
  const [editedTimeout, setEditedTimeout] = useState(45);
  const [editedIsAsync, setEditedIsAsync] = useState(false);
  const [editedConditionConfig, setEditedConditionConfig] = useState<{ meeting_types?: string[] } | null>(null);
  const [selectedDependencies, setSelectedDependencies] = useState<{ id: string; type: string }[]>([]);
  const [activeTab, setActiveTab] = useState('prompt');

  const AVAILABLE_MEETING_TYPES = [
    { value: 'discovery', label: 'Discovery' },
    { value: 'demo', label: 'Demo' },
    { value: 'reverse_demo', label: 'Reverse Demo' },
    { value: 'technical_deep_dive', label: 'Technical Deep Dive' },
    { value: 'evaluation_workshop', label: 'Evaluation / POC' },
    { value: 'dry_run', label: 'Dry Run' },
    { value: 'business_review', label: 'Business Review' },
    { value: 'implementation_planning', label: 'Implementation Planning' },
    { value: 'executive_briefing', label: 'Executive Briefing' },
    { value: 'training', label: 'Training' },
    { value: 'support_escalation', label: 'Support Escalation' },
    { value: 'internal_team', label: 'Internal Team' },
    { value: 'follow_up', label: 'Follow Up' },
  ];
  
  const updatePass = useUpdatePass();
  const updateDependencies = useUpdatePassDependencies();
  const deletePass = useDeletePass();

  // Reset form when pass changes
  useEffect(() => {
    if (pass) {
      setEditedPrompt(pass.system_prompt);
      setEditedName(pass.name);
      setEditedDescription(pass.description || '');
      setEditedTimeout(pass.timeout_seconds);
      setEditedIsAsync(pass.is_async);
      setEditedConditionConfig(pass.condition_config || null);
      
      const passDeps = dependencies.filter(d => d.pass_id === pass.id);
      setSelectedDependencies(passDeps.map(d => ({ 
        id: d.depends_on_pass_id, 
        type: d.dependency_type 
      })));
    }
  }, [pass, dependencies]);

  if (!pass) return null;

  // Get available passes for dependencies (only those before this pass in order)
  const availableDependencies = allPasses.filter(p => p.sort_order < pass.sort_order);

  const handleSave = async () => {
    // Build updates including condition_config
    const updates: any = {
      system_prompt: editedPrompt,
      name: editedName,
      description: editedDescription,
      timeout_seconds: editedTimeout,
    };
    
    // Include condition_config (set to null to clear)
    if (editedConditionConfig && editedConditionConfig.meeting_types?.length) {
      updates.condition_config = editedConditionConfig;
    } else {
      updates.condition_config = null;
    }

    await updatePass.mutateAsync({ passId: pass.id, updates });

    // Update dependencies
    await updateDependencies.mutateAsync({
      passId: pass.id,
      pipelineId,
      dependencies: selectedDependencies.map(d => ({
        depends_on_pass_id: d.id,
        dependency_type: d.type,
      })),
    });

    onOpenChange(false);
  };

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this pass? This cannot be undone.')) {
      deletePass.mutate({ passId: pass.id, pipelineId }, {
        onSuccess: () => onOpenChange(false)
      });
    }
  };

  const toggleDependency = (depPassId: string) => {
    setSelectedDependencies(prev => {
      const exists = prev.find(d => d.id === depPassId);
      if (exists) {
        return prev.filter(d => d.id !== depPassId);
      }
      return [...prev, { id: depPassId, type: 'optional' }];
    });
  };

  const setDependencyType = (depPassId: string, type: string) => {
    setSelectedDependencies(prev => 
      prev.map(d => d.id === depPassId ? { ...d, type } : d)
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Code className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            Edit Pass: {pass.name}
            <Badge variant="outline" className="ml-2">v{pass.version}</Badge>
          </DialogTitle>
          <DialogDescription>
            Configure the prompt, dependencies, and behavior for this analysis pass.
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 overflow-hidden flex flex-col">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="prompt">Prompt</TabsTrigger>
            <TabsTrigger value="conditions">Conditions</TabsTrigger>
            <TabsTrigger value="dependencies">Dependencies</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-y-auto mt-4">
            <TabsContent value="prompt" className="space-y-4 m-0">
              {/* Linked Detection Rules Info */}
              {linkedRules.length > 0 && (
                <div className="rounded-lg border border-[hsl(var(--pendo-pink))]/30 bg-[hsl(var(--pendo-pink))]/5 p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Radar className="w-4 h-4 text-[hsl(var(--pendo-pink))]" />
                    <span className="text-sm font-medium text-[hsl(var(--pendo-pink))]">Linked Detection Rules</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {linkedRules.map(link => (
                      <Badge 
                        key={link.id} 
                        variant="outline" 
                        className="text-xs border-[hsl(var(--pendo-pink))]/50"
                      >
                        <Link2 className="w-3 h-3 mr-1" />
                        {(link.detection_rules as any)?.name || 'Unknown Rule'}
                      </Badge>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    These detection rules provide context to this pass. The rules define patterns to detect in transcripts.
                  </p>
                </div>
              )}

              {/* System Prompt Editor */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="pass-prompt">System Prompt</Label>
                  <span className="text-xs text-muted-foreground">
                    {editedPrompt.length} characters
                  </span>
                </div>
                <Textarea
                  id="pass-prompt"
                  value={editedPrompt}
                  onChange={(e) => setEditedPrompt(e.target.value)}
                  className="font-mono text-sm min-h-[400px]"
                  placeholder="Enter the system prompt for this analysis pass..."
                />
              </div>
            </TabsContent>

            <TabsContent value="conditions" className="space-y-4 m-0">
              <div className="rounded-lg border border-border bg-muted/30 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Info className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    When conditions are set, this pass only runs if the meeting classification matches one of the selected types. 
                    If no conditions are set, the pass runs for all transcripts.
                  </span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">Meeting Type Triggers</Label>
                  <Badge variant="outline" className={cn(
                    "text-xs",
                    editedConditionConfig?.meeting_types?.length 
                      ? "bg-amber-500/10 text-amber-400 border-amber-500/30" 
                      : "bg-muted text-muted-foreground"
                  )}>
                    {editedConditionConfig?.meeting_types?.length 
                      ? `${editedConditionConfig.meeting_types.length} selected` 
                      : 'No conditions (runs always)'}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {AVAILABLE_MEETING_TYPES.map(mt => {
                    const isChecked = editedConditionConfig?.meeting_types?.includes(mt.value) ?? false;
                    return (
                      <div 
                        key={mt.value}
                        className={cn(
                          "flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors",
                          isChecked 
                            ? "border-amber-500/50 bg-amber-500/5" 
                            : "border-border bg-muted/30 hover:bg-muted/50"
                        )}
                        onClick={() => {
                          setEditedConditionConfig(prev => {
                            const current = prev?.meeting_types || [];
                            const next = isChecked
                              ? current.filter(t => t !== mt.value)
                              : [...current, mt.value];
                            return next.length > 0 ? { meeting_types: next } : null;
                          });
                        }}
                      >
                        <Checkbox checked={isChecked} />
                        <span className="text-sm text-foreground">{mt.label}</span>
                      </div>
                    );
                  })}
                </div>

                {editedConditionConfig?.meeting_types?.length ? (
                  <div className="pt-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-xs text-muted-foreground"
                      onClick={() => setEditedConditionConfig(null)}
                    >
                      Clear all conditions
                    </Button>
                  </div>
                ) : null}
              </div>
            </TabsContent>

            <TabsContent value="dependencies" className="space-y-4 m-0">
              <div className="rounded-lg border border-border bg-muted/30 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Info className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    Dependencies determine which passes must complete before this one runs. 
                    Output from dependency passes is included in this pass's context.
                  </span>
                </div>
              </div>

              {availableDependencies.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <GitBranch className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>This is the first pass - no dependencies available.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {availableDependencies.map(depPass => {
                    const isSelected = selectedDependencies.some(d => d.id === depPass.id);
                    const selectedDep = selectedDependencies.find(d => d.id === depPass.id);
                    
                    return (
                      <div 
                        key={depPass.id}
                        className={cn(
                          "flex items-center justify-between p-3 rounded-lg border",
                          isSelected 
                            ? "border-[hsl(var(--pendo-pink))]/50 bg-[hsl(var(--pendo-pink))]/5" 
                            : "border-border bg-muted/30"
                        )}
                      >
                        <div className="flex items-center gap-3">
                          <Checkbox
                            checked={isSelected}
                            onCheckedChange={() => toggleDependency(depPass.id)}
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-mono text-muted-foreground">
                                Pass {depPass.sort_order}
                              </span>
                              <span className="font-medium text-foreground">{depPass.name}</span>
                            </div>
                            <p className="text-xs text-muted-foreground">{depPass.description}</p>
                          </div>
                        </div>
                        {isSelected && (
                          <Select
                            value={selectedDep?.type || 'optional'}
                            onValueChange={(value) => setDependencyType(depPass.id, value)}
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="optional">Optional</SelectItem>
                              <SelectItem value="required">Required</SelectItem>
                              <SelectItem value="conditional">Conditional</SelectItem>
                            </SelectContent>
                          </Select>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            <TabsContent value="settings" className="space-y-4 m-0">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="pass-name">Name</Label>
                  <Input
                    id="pass-name"
                    value={editedName}
                    onChange={(e) => setEditedName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pass-timeout">Timeout (seconds)</Label>
                  <Input
                    id="pass-timeout"
                    type="number"
                    value={editedTimeout}
                    onChange={(e) => setEditedTimeout(parseInt(e.target.value) || 45)}
                    min={10}
                    max={300}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="pass-description">Description</Label>
                <Input
                  id="pass-description"
                  value={editedDescription}
                  onChange={(e) => setEditedDescription(e.target.value)}
                  placeholder="What does this pass extract?"
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border">
                <div>
                  <p className="text-sm font-medium">Async Execution</p>
                  <p className="text-xs text-muted-foreground">
                    Runs in background after main analysis completes
                  </p>
                </div>
                <Switch checked={editedIsAsync} onCheckedChange={setEditedIsAsync} />
              </div>

              <div className="pt-4 border-t border-border">
                <Button 
                  variant="destructive" 
                  size="sm"
                  onClick={handleDelete}
                  disabled={deletePass.isPending}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Pass
                </Button>
              </div>
            </TabsContent>
          </div>
        </Tabs>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            variant="glow" 
            onClick={handleSave}
            disabled={updatePass.isPending || updateDependencies.isPending}
          >
            {(updatePass.isPending || updateDependencies.isPending) ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function AnalysisPipelineView() {
  const { data: pipelines, isLoading: pipelinesLoading } = useAnalysisPipelines();
  const defaultPipeline = pipelines?.find(p => p.is_default) || pipelines?.[0];
  
  const { data: passes, isLoading: passesLoading } = useAnalysisPasses(defaultPipeline?.id || null);
  const { data: dependencies } = usePassDependencies(defaultPipeline?.id || null);
  const { data: ruleLinks } = useDetectionRulePassLinks(defaultPipeline?.id || null);

  const [selectedPass, setSelectedPass] = useState<AnalysisPass | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  const reorderPasses = useReorderPasses();

  const handleSelectPass = (pass: AnalysisPass) => {
    setSelectedPass(pass);
    setShowEditor(true);
  };

  const handleMovePass = (passId: string, direction: 'up' | 'down') => {
    if (!passes || !defaultPipeline) return;
    
    const passIndex = passes.findIndex(p => p.id === passId);
    if (passIndex === -1) return;
    
    const newIndex = direction === 'up' ? passIndex - 1 : passIndex + 1;
    if (newIndex < 0 || newIndex >= passes.length) return;

    // Swap sort orders
    const newOrders = passes.map(p => ({ id: p.id, sort_order: p.sort_order }));
    const temp = newOrders[passIndex].sort_order;
    newOrders[passIndex].sort_order = newOrders[newIndex].sort_order;
    newOrders[newIndex].sort_order = temp;

    reorderPasses.mutate({
      pipelineId: defaultPipeline.id,
      passOrders: newOrders,
    });
  };

  if (pipelinesLoading || passesLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-32 w-full" />
        <div className="grid gap-4">
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-24 w-full" />
        </div>
      </div>
    );
  }

  if (!defaultPipeline || !passes) {
    return (
      <Card className="glass border-border">
        <CardContent className="py-12 text-center">
          <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No analysis pipeline configured.</p>
        </CardContent>
      </Card>
    );
  }

  const passRuleLinks = (passId: string) => 
    ruleLinks?.filter(link => link.pass_id === passId) || [];

  const nextSortOrder = passes.length > 0 
    ? Math.max(...passes.map(p => p.sort_order)) + 1 
    : 1;

  return (
    <div className="space-y-6">
      {/* Pipeline Header */}
      <Card className="glass border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Code className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                {defaultPipeline.name}
              </CardTitle>
              <CardDescription>{defaultPipeline.description}</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-green-500/20 text-green-400 border-green-500/30">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Active
              </Badge>
              <Badge variant="outline">
                {passes.length} Passes
              </Badge>
              <Button variant="outline" size="sm" onClick={() => setShowCreateDialog(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Pass
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <PipelineFlowDiagram 
            passes={passes}
            dependencies={dependencies || []}
            onSelectPass={handleSelectPass}
          />
        </CardContent>
      </Card>

      {/* How Detection Rules Work */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Radar className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            How Detection Rules Integrate
          </CardTitle>
          <CardDescription>
            Detection rules for Readiness Questions and Product Tracking are linked to specific passes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg border border-border bg-muted/30">
              <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                Readiness Questions
              </h4>
              <p className="text-sm text-muted-foreground mb-3">
                Detection rules linked to the <strong>enrichment_readiness</strong> pass automatically populate 
                readiness question answers when specific patterns are detected in transcripts.
              </p>
              <p className="text-xs text-muted-foreground">
                Configure rules in Detection Rules → Readiness Mappings
              </p>
            </div>
            <div className="p-4 rounded-lg border border-border bg-muted/30">
              <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                <Radar className="w-4 h-4 text-blue-400" />
                Product Tracking
              </h4>
              <p className="text-sm text-muted-foreground mb-3">
                Detection rules linked to the <strong>enrichment_detection</strong> pass identify product mentions, 
                competitive intel, and key signals during transcript analysis.
              </p>
              <p className="text-xs text-muted-foreground">
                Configure rules in Detection Rules → Capture Fields
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pass List */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="text-lg">Analysis Passes</CardTitle>
          <CardDescription>
            Click on any pass to edit its prompt and configuration. Use arrows to reorder.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {passes.map((pass, index) => {
              const passDeps = dependencies?.filter(d => d.pass_id === pass.id) || [];
              const passLinks = passRuleLinks(pass.id);
              
              return (
                <Collapsible key={pass.id}>
                  <div className="flex items-center gap-2">
                    {/* Reorder buttons */}
                    <div className="flex flex-col gap-0.5">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => handleMovePass(pass.id, 'up')}
                        disabled={index === 0 || reorderPasses.isPending}
                      >
                        <ArrowUp className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => handleMovePass(pass.id, 'down')}
                        disabled={index === passes.length - 1 || reorderPasses.isPending}
                      >
                        <ArrowDown className="w-3 h-3" />
                      </Button>
                    </div>
                    
                    <CollapsibleTrigger asChild>
                      <button className="flex-1 flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border hover:bg-muted/50 transition-colors text-left">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-[hsl(var(--pendo-pink))]/20 text-[hsl(var(--pendo-pink))] font-mono text-sm">
                            {pass.sort_order}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-foreground">{pass.name}</span>
                              {pass.is_async && (
                                <Badge variant="outline" className="text-[10px] bg-blue-500/10 text-blue-400 border-blue-500/30">
                                  Async
                                </Badge>
                              )}
                              {passDeps.length > 0 && (
                                <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-400 border-amber-500/30">
                                  <GitBranch className="w-3 h-3 mr-0.5" />
                                  {passDeps.length} dep{passDeps.length > 1 ? 's' : ''}
                                </Badge>
                              )}
                              {passLinks.length > 0 && (
                                <Badge variant="outline" className="text-[10px] bg-[hsl(var(--pendo-pink))]/10 text-[hsl(var(--pendo-pink))] border-[hsl(var(--pendo-pink))]/30">
                                  <Radar className="w-3 h-3 mr-0.5" />
                                  {passLinks.length} rule{passLinks.length > 1 ? 's' : ''}
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">{pass.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <div className="text-xs text-muted-foreground flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {pass.timeout_seconds}s timeout
                            </div>
                            <div className="text-xs text-muted-foreground">
                              v{pass.version}
                            </div>
                          </div>
                          <ChevronDown className="w-4 h-4 text-muted-foreground" />
                        </div>
                      </button>
                    </CollapsibleTrigger>
                  </div>
                  <CollapsibleContent>
                    <div className="ml-10 p-4 border-x border-b border-border rounded-b-lg bg-muted/10">
                      <div className="space-y-4">
                        {/* Dependencies */}
                        {passDeps.length > 0 && (
                          <div>
                            <h4 className="text-sm font-medium text-foreground mb-2 flex items-center gap-2">
                              <GitBranch className="w-4 h-4 text-amber-400" />
                              Depends On
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {passDeps.map(dep => {
                                const depPass = passes.find(p => p.id === dep.depends_on_pass_id);
                                return (
                                  <Badge 
                                    key={dep.id} 
                                    variant="outline"
                                    className={cn(
                                      "text-xs",
                                      dep.dependency_type === 'required' ? "border-red-500/50" : ""
                                    )}
                                  >
                                    {depPass?.name || 'Unknown'}
                                    {dep.dependency_type === 'required' && (
                                      <span className="ml-1 text-red-400">required</span>
                                    )}
                                    {dep.field_mappings && (
                                      <span className="ml-1 text-muted-foreground">
                                        ({Object.keys(dep.field_mappings).join(', ')})
                                      </span>
                                    )}
                                  </Badge>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        {/* Linked Rules */}
                        {passLinks.length > 0 && (
                          <div>
                            <h4 className="text-sm font-medium text-foreground mb-2 flex items-center gap-2">
                              <Radar className="w-4 h-4 text-[hsl(var(--pendo-pink))]" />
                              Linked Detection Rules
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {passLinks.map(link => (
                                <Badge 
                                  key={link.id} 
                                  variant="outline"
                                  className="text-xs border-[hsl(var(--pendo-pink))]/50"
                                >
                                  {(link.detection_rules as any)?.name || 'Unknown'}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Prompt Preview */}
                        <div>
                          <h4 className="text-sm font-medium text-foreground mb-2">System Prompt Preview</h4>
                          <ScrollArea className="h-32 rounded border border-border bg-muted/30 p-3">
                            <pre className="text-xs text-muted-foreground whitespace-pre-wrap font-mono">
                              {pass.system_prompt.slice(0, 500)}
                              {pass.system_prompt.length > 500 && '...'}
                            </pre>
                          </ScrollArea>
                        </div>

                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleSelectPass(pass)}
                        >
                          <Code className="w-4 h-4 mr-2" />
                          Edit Full Prompt
                        </Button>
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Pass Editor Dialog */}
      <PassEditorDialog
        pass={selectedPass}
        dependencies={dependencies || []}
        linkedRules={selectedPass ? passRuleLinks(selectedPass.id) : []}
        open={showEditor}
        onOpenChange={setShowEditor}
        allPasses={passes}
        pipelineId={defaultPipeline.id}
      />

      {/* Create Pass Dialog */}
      <CreatePassDialog
        pipelineId={defaultPipeline.id}
        nextSortOrder={nextSortOrder}
        open={showCreateDialog}
        onOpenChange={setShowCreateDialog}
      />
    </div>
  );
}

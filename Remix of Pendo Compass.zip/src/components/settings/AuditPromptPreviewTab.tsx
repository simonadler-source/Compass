import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Copy, Play, Eye, FileText, Link2, Brain, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { gateway } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { useCompetitorVendors, useCompetitiveRubric, type CompetitiveRubric } from '@/hooks/useCompetitiveScorecard';
import { formatDistanceToNow } from 'date-fns';

const SCORE_TERMS: Record<number, string> = {
  1: 'Fragmented & Reactive',
  2: 'Consolidating & Proving',
  3: 'Scaling & Systematic',
  4: 'Integrated & Governed',
  5: 'Predictive & Strategic',
};

function buildPreviewPrompt(
  vendorName: string,
  sourceUrls: { url: string; description: string; alignment: string }[],
  rubric: CompetitiveRubric[],
  currentScores: { subcategory: string; category: string; score: number }[],
  internalEvidence: { type: string; detail: string }[],
): string {
  const rubricByCategory = rubric.reduce((acc, r) => {
    if (!acc[r.category]) acc[r.category] = [];
    acc[r.category].push(r);
    return acc;
  }, {} as Record<string, CompetitiveRubric[]>);

  const rubricText = Object.entries(rubricByCategory)
    .map(([category, entries]) => {
      const subcatText = entries.map(e => {
        const currentScore = currentScores.find(
          s => s.subcategory === e.subcategory && s.category === e.category
        )?.score ?? 0;
        return `  "${e.subcategory}" (Current: ${currentScore}/5)
    L1: ${e.level_1_description || 'N/A'}
    L2: ${e.level_2_description || 'N/A'}
    L3: ${e.level_3_description || 'N/A'}
    L4: ${e.level_4_description || 'N/A'}
    L5: ${e.level_5_description || 'N/A'}`;
      }).join('\n\n');
      return `### ${category}\n${subcatText}`;
    }).join('\n\n');

  const sourcesText = sourceUrls.length > 0
    ? sourceUrls.map((s, i) => `  ${i + 1}. ${s.url}\n     ${s.description} | Covers: ${s.alignment}`).join('\n')
    : '  No vendor-specific sources. Use your general knowledge and open web.';

  const evidenceText = internalEvidence.length > 0
    ? internalEvidence.map((e, i) => `  ${i + 1}. [${e.type}] ${e.detail}`).join('\n')
    : '  No internal evidence available.';

  return `You are a competitive intelligence analyst evaluating "${vendorName}" against a structured maturity rubric.

## RESEARCH SOURCES
Visit these URLs to gather evidence about "${vendorName}":

${sourcesText}

You may also search the open web to fill gaps, but prioritize the curated sources above. Clearly mark supplementary findings.

## INTERNAL FIELD INTELLIGENCE

${evidenceText}

## SCORING RUBRIC

${rubricText}

## INSTRUCTIONS

1. Research each subcategory using the source URLs and gather specific evidence.
2. Cross-reference evidence against the 5 maturity level descriptions. Score at the HIGHEST level where "${vendorName}" demonstrably meets ALL criteria.
3. Weight evidence: Customer transcripts > Vendor docs > Third-party reviews (G2, Gartner) > Blogs/PR > General knowledge.
4. Score conservatively — under-scoring is preferred over over-scoring based on marketing claims.
5. If insufficient evidence exists, keep current score and mark confidence "low".
6. Rationale must cite specific evidence with URLs or source types.

## OUTPUT FORMAT

Return ONLY a JSON array. Include ONLY subcategories where you propose a score CHANGE (different from the current score). If no scores need changing, return an empty array \`[]\`.

Each entry:
{
  "subcategory": "exact subcategory name",
  "category": "exact category name",
  "proposed_score": 4,
  "proposed_score_term": "Integrated & Governed",
  "rationale": "Specific evidence citing URLs or sources...",
  "evidence_sources": ["https://...", "field_intel"],
  "confidence": "high"
}

Score terms: 1="${SCORE_TERMS[1]}", 2="${SCORE_TERMS[2]}", 3="${SCORE_TERMS[3]}", 4="${SCORE_TERMS[4]}", 5="${SCORE_TERMS[5]}"
Confidence: "high" (multiple sources), "medium" (single source), "low" (insufficient evidence)

Return ONLY the JSON array. No markdown fences, no commentary.`;
}

export function AuditPromptPreviewTab() {
  const [selectedVendor, setSelectedVendor] = useState<string>('');
  const [isRunning, setIsRunning] = useState(false);

  const { data: allVendors, isLoading: vendorsLoading } = useCompetitorVendors();
  const { data: rubric } = useCompetitiveRubric();

  // Fetch sources for selected vendor
  const { data: sources } = useQuery({
    queryKey: ['audit-sources', selectedVendor],
    queryFn: async () => {
      const { data } = await gateway
        .from('competitive_sources')
        .select('source_url, source_description, subcategory_alignment, source_name')
        .or(`source_name.ilike.%${selectedVendor}%,source_name.eq.All Vendors,source_name.ilike.%Multiple%`)
        .execute();
      return (data || [])
        .filter((s: any) => s.source_url?.startsWith('http'))
        .map((s: any) => ({
          url: s.source_url,
          description: s.source_description || s.source_name || '',
          alignment: s.subcategory_alignment || '[All Categories]',
        }));
    },
    enabled: !!selectedVendor,
  });

  // Fetch current scores for selected vendor
  const { data: scores } = useQuery({
    queryKey: ['audit-scores', selectedVendor],
    queryFn: async () => {
      const { data } = await gateway
        .from('competitive_scorecard')
        .select('subcategory, category, score')
        .eq('vendor_name', selectedVendor)
        .execute();
      return (data || []).map((s: any) => ({
        subcategory: s.subcategory,
        category: s.category,
        score: s.score ?? 0,
      }));
    },
    enabled: !!selectedVendor,
  });

  // Fetch internal evidence
  const { data: evidence } = useQuery({
    queryKey: ['audit-evidence', selectedVendor],
    queryFn: async () => {
      const [transcriptRes, auditRes] = await Promise.all([
        gateway
          .from('opportunity_competitive_insights')
          .select('feature_discussed, pendo_position, comparison_notes, sentiment')
          .eq('competitor_name', selectedVendor)
          .limit(30)
          .execute(),
        gateway
          .from('competitive_audit_log')
          .select('subcategory, rationale, validated_score, evidence_source, source_type')
          .eq('vendor_name', selectedVendor)
          .eq('status', 'approved')
          .limit(30)
          .execute(),
      ]);

      const items: { type: string; detail: string }[] = [];
      for (const i of (transcriptRes.data || []) as any[]) {
        items.push({
          type: 'transcript',
          detail: `Feature: "${i.feature_discussed}" — Position: ${i.pendo_position || 'N/A'}, Sentiment: ${i.sentiment || 'N/A'}, Notes: ${i.comparison_notes || 'N/A'}`,
        });
      }
      for (const a of (auditRes.data || []) as any[]) {
        items.push({
          type: a.source_type || 'previous_audit',
          detail: `"${a.subcategory}" — Score: ${a.validated_score}, Source: ${a.evidence_source || 'N/A'}, Rationale: ${a.rationale || 'N/A'}`,
        });
      }
      return items;
    },
    enabled: !!selectedVendor,
  });

  // Fetch last audited date for selected vendor
  const { data: lastAuditedAt } = useQuery({
    queryKey: ['vendor-last-audited', selectedVendor],
    queryFn: async () => {
      const { data } = await gateway
        .from('competitive_scorecard')
        .select('last_audited_at')
        .eq('vendor_name', selectedVendor)
        .not('last_audited_at', 'is', null)
        .order('last_audited_at', { ascending: false })
        .limit(1)
        .execute();
      return data?.[0]?.last_audited_at || null;
    },
    enabled: !!selectedVendor,
  });

  // Build the prompt preview
  const prompt = useMemo(() => {
    if (!selectedVendor || !rubric) return '';
    return buildPreviewPrompt(
      selectedVendor,
      sources || [],
      rubric,
      scores || [],
      evidence || [],
    );
  }, [selectedVendor, sources, rubric, scores, evidence]);

  const tokenEstimate = useMemo(() => Math.round(prompt.length / 4), [prompt]);

  const handleCopy = () => {
    navigator.clipboard.writeText(prompt);
    toast.success('Prompt copied to clipboard');
  };

  const handleRunAudit = async () => {
    if (!selectedVendor) return;
    setIsRunning(true);
    try {
      const { data, error } = await supabase.functions.invoke('audit-competitive-scores', {
        body: { vendorName: selectedVendor, dryRun: false },
      });
      if (error) throw error;
      toast.success(`Audit complete for ${selectedVendor}: ${data?.proposals_count || 0} score proposals generated`);
    } catch (err: any) {
      toast.error(`Audit failed: ${err?.message || 'Unknown error'}`);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">AI Audit Prompt Preview</h3>
        <p className="text-sm text-muted-foreground">
          Preview the exact prompt sent to the AI model for competitive audit research. Select a vendor to see the full prompt with rubric, sources, and internal evidence.
        </p>
      </div>

      {/* Vendor selector + actions */}
      <div className="flex gap-3 items-end flex-wrap">
        <div className="min-w-[250px]">
          <label className="text-sm font-medium text-muted-foreground mb-1 block">Vendor</label>
          <Select value={selectedVendor} onValueChange={setSelectedVendor}>
            <SelectTrigger className="h-9">
              <SelectValue placeholder="Select a vendor..." />
            </SelectTrigger>
            <SelectContent>
              {vendorsLoading ? (
                <SelectItem value="_loading" disabled>Loading...</SelectItem>
              ) : (
                (allVendors || []).map(v => (
                  <SelectItem key={v} value={v}>{v}</SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        </div>

        {selectedVendor && (
          <>
            {lastAuditedAt && (
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground bg-muted px-3 py-2 rounded-md h-9">
                <Clock className="w-3.5 h-3.5" />
                Last researched {formatDistanceToNow(new Date(lastAuditedAt), { addSuffix: true })}
              </div>
            )}
            {!lastAuditedAt && (
              <div className="flex items-center gap-1.5 text-xs text-amber-600 bg-amber-50 dark:bg-amber-950/30 dark:text-amber-400 px-3 py-2 rounded-md h-9">
                <Clock className="w-3.5 h-3.5" />
                Never audited
              </div>
            )}
            <Button variant="outline" size="sm" onClick={handleCopy}>
              <Copy className="w-3.5 h-3.5 mr-1.5" />
              Copy Prompt
            </Button>
            <Button
              size="sm"
              onClick={handleRunAudit}
              disabled={isRunning}
              variant="default"
            >
              {isRunning ? (
                <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> Running Audit...</>
              ) : (
                <><Play className="w-3.5 h-3.5 mr-1.5" /> Run Audit for {selectedVendor}</>
              )}
            </Button>
          </>
        )}
      </div>

      {/* Stats cards */}
      {selectedVendor && (
        <div className="grid grid-cols-4 gap-3">
          <Card>
            <CardContent className="py-3 px-4 flex items-center gap-3">
              <Link2 className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-xl font-bold">{sources?.length || 0}</p>
                <p className="text-xs text-muted-foreground">Source URLs</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="py-3 px-4 flex items-center gap-3">
              <FileText className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-xl font-bold">{rubric?.length || 0}</p>
                <p className="text-xs text-muted-foreground">Subcategories</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="py-3 px-4 flex items-center gap-3">
              <Eye className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-xl font-bold">{evidence?.length || 0}</p>
                <p className="text-xs text-muted-foreground">Internal Evidence</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="py-3 px-4 flex items-center gap-3">
              <Brain className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-xl font-bold">~{tokenEstimate.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Est. Tokens</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Prompt preview */}
      {!selectedVendor && (
        <div className="flex flex-col items-center justify-center py-16 border border-dashed border-border rounded-lg">
          <Eye className="h-12 w-12 text-muted-foreground/30 mb-3" />
          <p className="text-muted-foreground text-sm">Select a vendor to preview the audit prompt</p>
        </div>
      )}

      {selectedVendor && prompt && (
        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Brain className="w-4 h-4 text-primary" />
              Full Prompt for "{selectedVendor}"
              <Badge variant="outline" className="text-[10px] ml-auto">
                {prompt.length.toLocaleString()} chars
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[500px]">
              <pre className="text-xs font-mono leading-relaxed p-4 whitespace-pre-wrap break-words text-muted-foreground">
                {prompt}
              </pre>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

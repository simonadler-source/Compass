import { useState, useEffect, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Save, RotateCcw, Scale } from 'lucide-react';
import { gateway } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const DIMENSIONS = [
  { key: 'pov_challenge', label: 'POV Challenge', description: 'Executive framing, challenge articulation, and offering a unique perspective aligned to business objectives.' },
  { key: 'ownership_control', label: 'Ownership & Control', description: 'Story flow & structure — defining the path to success with a logical, consultative delivery.' },
  { key: 'storytelling_proof', label: 'Storytelling & Proof', description: 'Use case alignment — anchoring features to specific customer outcomes and stated use cases.' },
  { key: 'reverse_demo', label: 'Reverse Demo', description: 'Did the SE uncover negative business consequences?' },
  { key: 'champion_arming', label: 'Champion Arming', description: 'Did the SE provide internal ammunition?' },
  { key: 'objection_handling', label: 'Objection Handling', description: 'Did the SE handle objections constructively?' },
  { key: 'pain_quantification', label: 'Pain Quantification', description: 'Negative consequence — quantifying business pain in dollars, time, or risk, and articulating cost of inaction.' },
  { key: 'questioning', label: 'Questioning', description: 'Discovery quality — questions that deepen understanding, reframe thinking, and influence the prospect\'s point of view.' },
  { key: 'differentiation', label: 'Differentiation', description: 'Clear articulation of concrete differentiators (e.g. actionability vs. analytics-only).' },
  { key: 'strategy_rigor', label: 'Strategy & Rigor', description: 'Account context & business relevance — thoroughness of preparation and demonstrated understanding of the prospect\'s business.' },
  { key: 'technical_competency', label: 'Technical Competency', description: 'Confidence & delivery — effective in-product demonstration with confident, natural pacing. Prospect affirmations and engagement signals.' },
  { key: 'value_anchoring', label: 'Value Anchoring', description: 'PBO clarity — connecting features to the prospect\'s specific needs with quantified positive business outcomes.' },
  { key: 'energy_inspiration', label: 'Energy & Inspiration', description: 'Prospect activation — enthusiasm, vision-painting, and inspirational delivery that energises prospects to act.' },
] as const;

const DEFAULT_WEIGHTS: Record<string, number> = {
  pov_challenge: 10,
  ownership_control: 10,
  storytelling_proof: 10,
  reverse_demo: 10,
  champion_arming: 10,
  objection_handling: 10,
  pain_quantification: 10,
  questioning: 10,
  differentiation: 10,
  strategy_rigor: 10,
  technical_competency: 10,
  value_anchoring: 15,
  energy_inspiration: 12,
};

const SETTING_KEY = 'coaching_dimension_weights';

export function CoachingWeightsTab() {
  const queryClient = useQueryClient();
  const [hasChanges, setHasChanges] = useState(false);
  const [reScoring, setReScoring] = useState(false);

  const { data: savedWeights, isLoading } = useQuery({
    queryKey: ['ai-settings', SETTING_KEY],
    queryFn: async () => {
      const result = await gateway.from('ai_settings')
        .select('setting_value')
        .eq('setting_key', SETTING_KEY)
        .single()
        .execute();
      if (result.error || !result.data) return null;
      try {
        return JSON.parse((result.data as any).setting_value) as Record<string, number>;
      } catch { return null; }
    },
  });

  // Derive effective weights: saved values merged over defaults
  const weights = useMemo(() => {
    if (!savedWeights) return DEFAULT_WEIGHTS;
    return { ...DEFAULT_WEIGHTS, ...savedWeights };
  }, [savedWeights]);

  // Local overrides while user is editing (before save)
  const [localOverrides, setLocalOverrides] = useState<Record<string, number> | null>(null);
  const effectiveWeights = localOverrides ?? weights;

  // Reset local overrides when saved data changes (e.g. after save)
  useEffect(() => {
    setLocalOverrides(null);
    setHasChanges(false);
  }, [savedWeights]);

  const totalWeight = useMemo(() => Object.values(effectiveWeights).reduce((a, b) => a + b, 0), [effectiveWeights]);

  const normalizedWeights = useMemo(() => {
    const result: Record<string, number> = {};
    for (const [k, v] of Object.entries(effectiveWeights)) {
      result[k] = totalWeight > 0 ? Math.round((v / totalWeight) * 1000) / 10 : 0;
    }
    return result;
  }, [effectiveWeights, totalWeight]);

  const handleWeightChange = (key: string, value: number[]) => {
    setLocalOverrides(prev => ({ ...(prev ?? weights), [key]: value[0] }));
    setHasChanges(true);
  };

  const saveMutation = useMutation({
    mutationFn: async () => {
      const json = JSON.stringify(effectiveWeights);
      // Upsert into ai_settings
      const { data: existing } = await gateway.from('ai_settings')
        .select('id')
        .eq('setting_key', SETTING_KEY)
        .single()
        .execute();

      if (existing) {
        const result = await gateway.from('ai_settings')
          .update({ setting_value: json, updated_at: new Date().toISOString() })
          .eq('setting_key', SETTING_KEY)
          .execute();
        if (result.error) throw new Error(result.error.message);
      } else {
        const result = await gateway.from('ai_settings')
          .insert({ setting_key: SETTING_KEY, setting_value: json })
          .execute();
        if (result.error) throw new Error(result.error.message);
      }
    },
    onSuccess: async () => {
      queryClient.invalidateQueries({ queryKey: ['ai-settings', SETTING_KEY] });
      setHasChanges(false);
      toast.success('Coaching weights saved');
      // Trigger re-scoring of all existing coaching records
      await reScoreAll();
    },
    onError: (err: any) => toast.error('Failed to save: ' + err.message),
  });

  const reScoreAll = async () => {
    setReScoring(true);
    try {
      // Get all coaching scores
      const result = await gateway
        .from('se_coaching_scores')
        .select('id, transcript_id, meeting_type, pov_challenge_score, ownership_control_score, storytelling_proof_score, reverse_demo_score, champion_arming_score, objection_handling_score, pain_quantification_score, questioning_score, differentiation_score, strategy_rigor_score, technical_competency_score, value_anchoring_score, energy_inspiration_score')
        .order('analyzed_at', { ascending: false })
        .execute();

      const scores = result.data as any[];
      if (result.error) throw result.error;
      if (!scores || scores.length === 0) {
        toast.info('No existing coaching scores to re-calculate');
        return;
      }

      // Normalize weights to fractions
      const total = Object.values(effectiveWeights).reduce((a, b) => a + b, 0);
      const fractionalWeights: Record<string, number> = {};
      for (const [k, v] of Object.entries(effectiveWeights)) {
        fractionalWeights[k] = total > 0 ? v / total : 0;
      }

      const scoreFields: Record<string, string> = {
        pov_challenge: 'pov_challenge_score',
        ownership_control: 'ownership_control_score',
        storytelling_proof: 'storytelling_proof_score',
        reverse_demo: 'reverse_demo_score',
        champion_arming: 'champion_arming_score',
        objection_handling: 'objection_handling_score',
        pain_quantification: 'pain_quantification_score',
        questioning: 'questioning_score',
        differentiation: 'differentiation_score',
        strategy_rigor: 'strategy_rigor_score',
        technical_competency: 'technical_competency_score',
        value_anchoring: 'value_anchoring_score',
        energy_inspiration: 'energy_inspiration_score',
      };

      // Re-calculate scores locally without re-running AI
      let updated = 0;
      for (const score of scores) {
        let weightedSum = 0;
        let weightSum = 0;
        for (const [dim, weight] of Object.entries(fractionalWeights)) {
          const fieldName = scoreFields[dim];
          const val = score[fieldName];
          if (val != null && typeof val === 'number') {
            weightedSum += val * weight;
            weightSum += weight;
          }
        }
        const newOverall = weightSum > 0 ? Math.round((weightedSum / weightSum) * 10) / 10 : null;

        await gateway
          .from('se_coaching_scores')
          .update({ overall_score: newOverall, weights_used: fractionalWeights })
          .eq('id', score.id)
          .execute();
        updated++;
      }

      toast.success(`Re-scored ${updated} coaching records with new weights`);
      queryClient.invalidateQueries({ queryKey: ['se-coaching'] });
    } catch (err: any) {
      toast.error('Re-scoring failed: ' + err.message);
    } finally {
      setReScoring(false);
    }
  };

  const handleReset = () => {
    setLocalOverrides(DEFAULT_WEIGHTS);
    setHasChanges(true);
  };

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <Card className="glass border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Scale className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
          Coaching Dimension Weights
        </CardTitle>
        <CardDescription>
          Configure how each SE coaching dimension contributes to the overall score. 
          Weights are relative — they'll be normalized to percentages automatically.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-5">
          {DIMENSIONS.map(dim => (
            <div key={dim.key} className="space-y-1.5">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">{dim.label}</Label>
                  <p className="text-xs text-muted-foreground">{dim.description}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="font-mono text-xs min-w-[3rem] justify-center">
                    {normalizedWeights[dim.key]}%
                  </Badge>
                </div>
              </div>
              <Slider
                value={[effectiveWeights[dim.key] ?? 10]}
                onValueChange={(v) => handleWeightChange(dim.key, v)}
                min={0}
                max={50}
                step={1}
                className="w-full"
              />
            </div>
          ))}
        </div>

        <Alert className="border-border bg-muted/30">
          <AlertDescription className="text-muted-foreground text-sm">
            Total weight points: <strong>{totalWeight}</strong>. 
            All weights are normalized to percentages for scoring. Setting a dimension to 0 excludes it from the overall score.
          </AlertDescription>
        </Alert>

        <div className="flex items-center gap-3">
          <Button
            variant="glow"
            onClick={() => saveMutation.mutate()}
            disabled={!hasChanges || saveMutation.isPending || reScoring}
          >
            {saveMutation.isPending || reScoring ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" />{reScoring ? 'Re-scoring...' : 'Saving...'}</>
            ) : (
              <><Save className="w-4 h-4 mr-2" />Save & Re-score</>
            )}
          </Button>
          <Button variant="outline" onClick={handleReset} disabled={saveMutation.isPending || reScoring}>
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset to Equal
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

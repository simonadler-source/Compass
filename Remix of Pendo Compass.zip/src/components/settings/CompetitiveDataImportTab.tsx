import { useState } from 'react';
import { Upload, FileSpreadsheet, RefreshCw, CheckCircle, AlertCircle, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useImportCompetitiveData } from '@/hooks/useCompetitiveScorecard';
import { gateway } from '@/lib/apiGateway';
import { useQuery } from '@tanstack/react-query';

export function CompetitiveDataImportTab() {
  const { toast } = useToast();
  const importMutation = useImportCompetitiveData();
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);

  // Fetch current data stats via gateway
  const { data: stats, refetch: refetchStats } = useQuery({
    queryKey: ['competitive-stats'],
    queryFn: async () => {
      const [rubricRes, scorecardRes, sourcesRes] = await Promise.all([
        gateway.from('competitive_rubric').select('id').execute(),
        gateway.from('competitive_scorecard').select('id, vendor_name').execute(),
        gateway.from('competitive_sources').select('id').execute(),
      ]);

      const scorecardData = scorecardRes.data || [];
      const uniqueVendors = new Set((scorecardData as any[]).map((d: any) => d.vendor_name)).size;

      return {
        rubricCategories: (rubricRes.data as any[])?.length || 0,
        scorecardEntries: scorecardData.length,
        uniqueVendors,
        sources: (sourcesRes.data as any[])?.length || 0,
      };
    },
  });

  const handleImportFromProject = async () => {
    setImporting(true);
    setImportProgress(10);

    try {
      // Fetch CSV files from public folder
      const [rubricRes, scorecardRes, sourcesRes] = await Promise.all([
        fetch('/data/competitive-rubric.csv'),
        fetch('/data/competitive-scorecard.csv'),
        fetch('/data/competitive-sources.csv'),
      ]);

      setImportProgress(30);

      const [rubricCsv, scorecardCsv, sourcesCsv] = await Promise.all([
        rubricRes.text(),
        scorecardRes.text(),
        sourcesRes.text(),
      ]);

      setImportProgress(50);

      // Import via edge function
      const result = await importMutation.mutateAsync({
        rubricCsv,
        scorecardCsv,
        sourcesCsv,
      });

      setImportProgress(100);

      toast({
        title: 'Import Complete',
        description: `Imported ${result.summary?.rubricCategories || 0} rubric items, ${result.summary?.scorecardEntries || 0} scores, and ${result.summary?.sources || 0} sources`,
      });

      refetchStats();
    } catch (error) {
      console.error('Import error:', error);
      toast({
        title: 'Import Failed',
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: 'destructive',
      });
    } finally {
      setImporting(false);
      setImportProgress(0);
    }
  };

  const handleFileUpload = async (fileType: 'rubric' | 'scorecard' | 'sources') => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv';
    
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const text = await file.text();
      
      try {
        const payload = {
          rubricCsv: fileType === 'rubric' ? text : undefined,
          scorecardCsv: fileType === 'scorecard' ? text : undefined,
          sourcesCsv: fileType === 'sources' ? text : undefined,
        };

        const result = await importMutation.mutateAsync(payload);

        toast({
          title: `${fileType} Import Complete`,
          description: `Successfully imported ${file.name}`,
        });

        refetchStats();
      } catch (error) {
        toast({
          title: 'Import Failed',
          description: error instanceof Error ? error.message : 'Unknown error',
          variant: 'destructive',
        });
      }
    };

    input.click();
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Competitive Intelligence Data</h3>
        <p className="text-sm text-muted-foreground">
          Import and manage your competitive scorecard, maturity rubric, and evidence sources.
        </p>
      </div>

      {/* Current Data Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{stats?.rubricCategories || 0}</p>
                <p className="text-xs text-muted-foreground">Rubric Items</p>
              </div>
              <FileSpreadsheet className="h-8 w-8 text-muted-foreground/50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{stats?.uniqueVendors || 0}</p>
                <p className="text-xs text-muted-foreground">Vendors</p>
              </div>
              <Database className="h-8 w-8 text-muted-foreground/50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{stats?.scorecardEntries || 0}</p>
                <p className="text-xs text-muted-foreground">Scores</p>
              </div>
              <CheckCircle className="h-8 w-8 text-muted-foreground/50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{stats?.sources || 0}</p>
                <p className="text-xs text-muted-foreground">Sources</p>
              </div>
              <AlertCircle className="h-8 w-8 text-muted-foreground/50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Import Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Import Data</CardTitle>
          <CardDescription>
            Import competitive intelligence data from CSV files
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Quick Import */}
          <div className="flex items-center justify-between p-4 border rounded-lg bg-muted/30">
            <div>
              <p className="font-medium">Import All Data</p>
              <p className="text-sm text-muted-foreground">
                Import rubric, scorecard, and sources from project files
              </p>
            </div>
            <Button 
              onClick={handleImportFromProject}
              disabled={importing}
            >
              {importing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Import All
                </>
              )}
            </Button>
          </div>

          {importing && (
            <div className="space-y-2">
              <Progress value={importProgress} className="h-2" />
              <p className="text-xs text-muted-foreground text-center">
                {importProgress < 30 ? 'Fetching files...' : 
                 importProgress < 50 ? 'Parsing data...' :
                 importProgress < 100 ? 'Importing to database...' : 'Complete!'}
              </p>
            </div>
          )}

          {/* Individual File Uploads */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t">
            <div className="text-center">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => handleFileUpload('rubric')}
              >
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                Upload Rubric
              </Button>
              <p className="text-xs text-muted-foreground mt-1">
                Maturity definitions
              </p>
            </div>
            <div className="text-center">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => handleFileUpload('scorecard')}
              >
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                Upload Scorecard
              </Button>
              <p className="text-xs text-muted-foreground mt-1">
                Vendor scores
              </p>
            </div>
            <div className="text-center">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => handleFileUpload('sources')}
              >
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                Upload Sources
              </Button>
              <p className="text-xs text-muted-foreground mt-1">
                Evidence links
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Format Info */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Expected CSV Formats</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-sm">
          <div>
            <Badge variant="outline" className="mb-2">Rubric</Badge>
            <p className="text-muted-foreground">
              Category, Subcategory, Score 1 description, Score 2 description, Score 3 description, Score 4 description, Score 5 description
            </p>
          </div>
          <div>
            <Badge variant="outline" className="mb-2">Scorecard</Badge>
            <p className="text-muted-foreground">
              Category, Subcategory, [Vendor1], [Vendor2], ... (vendor columns with numeric scores)
            </p>
          </div>
          <div>
            <Badge variant="outline" className="mb-2">Sources</Badge>
            <p className="text-muted-foreground">
              Reference Number, Source Name, Description, Subcategory Alignment, URL, Status, Added by, Date Added, Last Used Date, Key Takeaways
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

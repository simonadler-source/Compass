import { useState, useMemo } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useCompetitiveRubric, type CompetitiveRubric } from '@/hooks/useCompetitiveScorecard';
import { ChevronDown, ChevronRight, Search, Save, Pencil, Plus, BookOpen, Layers } from 'lucide-react';

interface CategoryGroup {
  category: string;
  items: CompetitiveRubric[];
}

interface RubricEdit {
  id: string;
  level_1_description: string;
  level_2_description: string;
  level_3_description: string;
  level_4_description: string;
  level_5_description: string;
}

export function CompetitiveRubricTab() {
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [editingRubric, setEditingRubric] = useState<RubricEdit | null>(null);
  const [showAddSubcategory, setShowAddSubcategory] = useState(false);
  const [newSubcategory, setNewSubcategory] = useState('');
  const [newCategory, setNewCategory] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [isNewCategory, setIsNewCategory] = useState(false);

  const { data: rubrics, isLoading } = useCompetitiveRubric();

  // Fetch all vendors to seed scorecard rows
  const { data: allVendors } = useQuery({
    queryKey: ['all-scorecard-vendors'],
    queryFn: async () => {
      const { data } = await gateway
        .from('competitive_scorecard')
        .select('vendor_name')
        .execute();
      return [...new Set((data || []).map((d: any) => d.vendor_name))];
    },
  });

  // Group rubrics by category
  const categoryGroups = useMemo(() => {
    if (!rubrics) return [];

    const filtered = searchTerm
      ? rubrics.filter(r =>
          r.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
          r.subcategory.toLowerCase().includes(searchTerm.toLowerCase())
        )
      : rubrics;

    const groups = new Map<string, CategoryGroup>();
    for (const rubric of filtered) {
      if (!groups.has(rubric.category)) {
        groups.set(rubric.category, { category: rubric.category, items: [] });
      }
      groups.get(rubric.category)!.items.push(rubric);
    }

    return Array.from(groups.values()).sort((a, b) => a.category.localeCompare(b.category));
  }, [rubrics, searchTerm]);

  const existingCategories = useMemo(() => {
    return [...new Set(rubrics?.map(r => r.category) || [])].sort();
  }, [rubrics]);

  const totalSubcategories = rubrics?.length || 0;
  const totalCategories = new Set(rubrics?.map(r => r.category)).size;
  const definedCount = rubrics?.filter(r =>
    r.level_1_description || r.level_2_description || r.level_3_description ||
    r.level_4_description || r.level_5_description
  ).length || 0;

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(category)) next.delete(category);
      else next.add(category);
      return next;
    });
  };

  const expandAll = () => setExpandedCategories(new Set(categoryGroups.map(g => g.category)));
  const collapseAll = () => setExpandedCategories(new Set());

  const openEditor = (rubric: CompetitiveRubric) => {
    setEditingRubric({
      id: rubric.id,
      level_1_description: rubric.level_1_description || '',
      level_2_description: rubric.level_2_description || '',
      level_3_description: rubric.level_3_description || '',
      level_4_description: rubric.level_4_description || '',
      level_5_description: rubric.level_5_description || '',
    });
  };

  const saveMutation = useMutation({
    mutationFn: async (edit: RubricEdit) => {
      const result = await gateway.from('competitive_rubric')
        .update({
          level_1_description: edit.level_1_description || null,
          level_2_description: edit.level_2_description || null,
          level_3_description: edit.level_3_description || null,
          level_4_description: edit.level_4_description || null,
          level_5_description: edit.level_5_description || null,
        })
        .eq('id', edit.id)
        .execute();
      if (result.error) throw new Error(getErrorMessage(result.error));
    },
    onSuccess: () => {
      toast.success('Rubric updated');
      setEditingRubric(null);
      queryClient.invalidateQueries({ queryKey: ['competitive-rubric'] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  // Add new subcategory + seed scorecard for all vendors
  const addSubcategoryMutation = useMutation({
    mutationFn: async ({ category, subcategory }: { category: string; subcategory: string }) => {
      // Insert into rubric
      const rubricRes = await gateway.from('competitive_rubric')
        .insert({ category, subcategory })
        .select('id')
        .execute();
      if (rubricRes.error) throw new Error(getErrorMessage(rubricRes.error));

      const rubricId = (rubricRes.data as any[])?.[0]?.id;

      // Seed scorecard entries for all vendors
      if (allVendors && allVendors.length > 0) {
        const scorecardRows = allVendors.map(vendor => ({
          vendor_name: vendor,
          category,
          subcategory,
          score: 0,
          rubric_id: rubricId,
        }));

        // Batch insert in chunks
        for (let i = 0; i < scorecardRows.length; i += 50) {
          const batch = scorecardRows.slice(i, i + 50);
          const res = await gateway.from('competitive_scorecard').insert(batch).execute();
          if (res.error) console.error('Scorecard seed error:', res.error);
        }
      }
    },
    onSuccess: () => {
      toast.success('Subcategory added and scorecard entries seeded for all vendors');
      setShowAddSubcategory(false);
      setNewSubcategory('');
      setNewCategory('');
      setSelectedCategory('');
      setIsNewCategory(false);
      queryClient.invalidateQueries({ queryKey: ['competitive-rubric'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-scores'] });
      queryClient.invalidateQueries({ queryKey: ['heatmap-scores'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-stats'] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const handleAddSubcategory = () => {
    const category = isNewCategory ? newCategory.trim() : selectedCategory;
    const subcategory = newSubcategory.trim();
    if (!category || !subcategory) {
      toast.error('Both category and subcategory are required');
      return;
    }
    // Check for duplicate
    if (rubrics?.some(r => r.category === category && r.subcategory === subcategory)) {
      toast.error('This subcategory already exists in that category');
      return;
    }
    addSubcategoryMutation.mutate({ category, subcategory });
  };

  const getLevelCompleteness = (rubric: CompetitiveRubric) => {
    let filled = 0;
    if (rubric.level_1_description) filled++;
    if (rubric.level_2_description) filled++;
    if (rubric.level_3_description) filled++;
    if (rubric.level_4_description) filled++;
    if (rubric.level_5_description) filled++;
    return filled;
  };

  const levelLabels = ['Basic', 'Developing', 'Competent', 'Advanced', 'Leading'];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Scoring Rubric</h3>
          <p className="text-sm text-muted-foreground">
            Define what each maturity level (1–5) means for every subcategory. This rubric drives consistent scoring across all vendors.
          </p>
        </div>
        <Button size="sm" onClick={() => setShowAddSubcategory(true)}>
          <Plus className="w-3.5 h-3.5 mr-1.5" />
          Add Subcategory
        </Button>
      </div>

      {/* Summary stats */}
      <div className="flex gap-4">
        <Card className="flex-1">
          <CardContent className="py-3 px-4 flex items-center gap-3">
            <Layers className="w-4 h-4 text-muted-foreground" />
            <div>
              <p className="text-2xl font-bold">{totalCategories}</p>
              <p className="text-xs text-muted-foreground">Categories</p>
            </div>
          </CardContent>
        </Card>
        <Card className="flex-1">
          <CardContent className="py-3 px-4 flex items-center gap-3">
            <BookOpen className="w-4 h-4 text-muted-foreground" />
            <div>
              <p className="text-2xl font-bold">{totalSubcategories}</p>
              <p className="text-xs text-muted-foreground">Subcategories</p>
            </div>
          </CardContent>
        </Card>
        <Card className="flex-1">
          <CardContent className="py-3 px-4 flex items-center gap-3">
            <Pencil className="w-4 h-4 text-muted-foreground" />
            <div>
              <p className="text-2xl font-bold">{definedCount}<span className="text-sm font-normal text-muted-foreground">/{totalSubcategories}</span></p>
              <p className="text-xs text-muted-foreground">Defined</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search + controls */}
      <div className="flex gap-4 items-end">
        <div className="flex-1 max-w-sm relative">
          <label className="text-sm font-medium text-muted-foreground mb-1 block">Search</label>
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Filter by category or subcategory..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" onClick={expandAll}>Expand All</Button>
          <Button variant="ghost" size="sm" onClick={collapseAll}>Collapse All</Button>
        </div>
      </div>

      {/* Loading state */}
      {isLoading && (
        <div className="space-y-4">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-16 w-full" />)}
        </div>
      )}

      {/* Empty state */}
      {!isLoading && categoryGroups.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <BookOpen className="h-12 w-12 text-muted-foreground/40 mb-3" />
            <p className="text-muted-foreground text-sm">
              {searchTerm ? 'No matching rubric entries found' : 'No rubric data available. Import competitive data first.'}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Category groups */}
      <TooltipProvider>
        <div className="space-y-2">
          {categoryGroups.map(group => {
            const isExpanded = expandedCategories.has(group.category);
            const avgCompleteness = group.items.reduce((sum, r) => sum + getLevelCompleteness(r), 0) / group.items.length;

            return (
              <Collapsible key={group.category} open={isExpanded} onOpenChange={() => toggleCategory(group.category)}>
                <CollapsibleTrigger className="w-full">
                  <Card className="hover:bg-muted/30 transition-colors cursor-pointer">
                    <CardContent className="py-3 px-4 flex items-center gap-4">
                      {isExpanded
                        ? <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
                        : <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />}
                      <span className="font-medium text-sm flex-1 text-left">{group.category}</span>
                      <span className="text-xs text-muted-foreground">{group.items.length} subcategories</span>
                      <Badge
                        variant="outline"
                        className={avgCompleteness >= 4 ? 'text-green-400 border-green-500/30' : avgCompleteness >= 2 ? 'text-yellow-400 border-yellow-500/30' : 'text-muted-foreground border-border'}
                      >
                        {avgCompleteness.toFixed(1)}/5 levels defined
                      </Badge>
                    </CardContent>
                  </Card>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="ml-4 border-l border-border pl-4 mt-1 space-y-1">
                    {/* Header */}
                    <div className="grid grid-cols-[1fr_repeat(5,60px)_40px] gap-2 px-3 py-1.5 text-xs font-medium text-muted-foreground">
                      <span>Subcategory</span>
                      {levelLabels.map((label, i) => (
                        <Tooltip key={i}>
                          <TooltipTrigger asChild>
                            <span className="text-center cursor-help">{i + 1}</span>
                          </TooltipTrigger>
                          <TooltipContent><p className="text-xs">{label}</p></TooltipContent>
                        </Tooltip>
                      ))}
                      <span />
                    </div>

                    {group.items.map(rubric => {
                      const completeness = getLevelCompleteness(rubric);
                      return (
                        <div
                          key={rubric.id}
                          className="grid grid-cols-[1fr_repeat(5,60px)_40px] gap-2 items-center px-3 py-2 rounded-md text-sm hover:bg-muted/20"
                        >
                          <span className="truncate" title={rubric.subcategory}>{rubric.subcategory}</span>

                          {[1, 2, 3, 4, 5].map(level => {
                            const desc = rubric[`level_${level}_description` as keyof CompetitiveRubric] as string | null;
                            return (
                              <div key={level} className="flex justify-center">
                                {desc ? (
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <div className="w-5 h-5 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center cursor-help">
                                        <span className="text-[10px] font-mono text-primary">{level}</span>
                                      </div>
                                    </TooltipTrigger>
                                    <TooltipContent side="top" className="max-w-xs">
                                      <p className="text-xs font-medium mb-1">Level {level}: {levelLabels[level - 1]}</p>
                                      <p className="text-xs text-muted-foreground">{desc}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                ) : (
                                  <div className="w-5 h-5 rounded-full bg-muted/30 border border-border/50" />
                                )}
                              </div>
                            );
                          })}

                          <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => openEditor(rubric)}>
                            <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            );
          })}
        </div>
      </TooltipProvider>

      {/* Edit rubric dialog */}
      <Dialog open={!!editingRubric} onOpenChange={(open) => { if (!open) setEditingRubric(null); }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-primary" />
              Edit Maturity Rubric
            </DialogTitle>
          </DialogHeader>
          {editingRubric && (
            <div className="space-y-4 py-2">
              <p className="text-sm text-muted-foreground">
                Define what each maturity level means for this subcategory. Descriptions appear as guidance when scoring vendors.
              </p>
              {[1, 2, 3, 4, 5].map(level => (
                <div key={level} className="space-y-1.5">
                  <Label className="text-xs flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px] px-1.5 font-mono">{level}</Badge>
                    {levelLabels[level - 1]}
                  </Label>
                  <Textarea
                    placeholder={`Describe level ${level} (${levelLabels[level - 1]}) maturity...`}
                    value={(editingRubric as any)[`level_${level}_description`] || ''}
                    onChange={(e) =>
                      setEditingRubric(prev => prev ? { ...prev, [`level_${level}_description`]: e.target.value } : null)
                    }
                    rows={2}
                    className="text-sm"
                  />
                </div>
              ))}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingRubric(null)}>Cancel</Button>
            <Button
              onClick={() => editingRubric && saveMutation.mutate(editingRubric)}
              disabled={saveMutation.isPending}
            >
              <Save className="w-4 h-4 mr-2" />
              {saveMutation.isPending ? 'Saving...' : 'Save'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add subcategory dialog */}
      <Dialog open={showAddSubcategory} onOpenChange={setShowAddSubcategory}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-primary" />
              Add Subcategory
            </DialogTitle>
            <DialogDescription>
              Add a new subcategory to the rubric. This will also create scorecard entries (score 0) for all existing vendors.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-sm">Category</Label>
              <div className="flex gap-2 items-center">
                {!isNewCategory ? (
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select existing category..." />
                    </SelectTrigger>
                    <SelectContent>
                      {existingCategories.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    placeholder="New category name..."
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="flex-1"
                  />
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setIsNewCategory(!isNewCategory);
                    setSelectedCategory('');
                    setNewCategory('');
                  }}
                  className="text-xs shrink-0"
                >
                  {isNewCategory ? 'Use Existing' : '+ New'}
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-sm">Subcategory Name</Label>
              <Input
                placeholder="e.g., AI Copilot, Feature Flags..."
                value={newSubcategory}
                onChange={(e) => setNewSubcategory(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddSubcategory(false)}>Cancel</Button>
            <Button
              onClick={handleAddSubcategory}
              disabled={addSubcategoryMutation.isPending || (!selectedCategory && !newCategory.trim()) || !newSubcategory.trim()}
            >
              <Plus className="w-4 h-4 mr-2" />
              {addSubcategoryMutation.isPending ? 'Adding...' : 'Add Subcategory'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { ArrowUp, ArrowDown, Minus, ExternalLink, Search, Filter, FileText, Bot, User } from 'lucide-react';
import { gateway } from '@/lib/apiGateway';
import { formatDistanceToNow, format } from 'date-fns';

const SCORE_TERMS: Record<number, string> = {
  1: 'Fragmented & Reactive',
  2: 'Consolidating & Proving',
  3: 'Scaling & Systematic',
  4: 'Integrated & Governed',
  5: 'Predictive & Strategic',
};

const SCORE_COLORS: Record<number, string> = {
  0: 'bg-muted text-muted-foreground',
  1: 'bg-red-500/20 text-red-400 border-red-500/30',
  2: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  3: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  4: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  5: 'bg-green-500/20 text-green-400 border-green-500/30',
};

interface AuditEntry {
  id: string;
  vendor_name: string;
  subcategory: string;
  current_score: number | null;
  validated_score: number | null;
  validated_score_term: string | null;
  rationale: string | null;
  evidence_source: string | null;
  evidence_url: string | null;
  source_type: string | null;
  audit_datetime: string;
  type: string | null;
  evidence_confidence_weight: number;
}

function ScoreDelta({ from, to }: { from: number | null; to: number | null }) {
  const f = from ?? 0;
  const t = to ?? 0;
  const delta = t - f;

  if (delta > 0) return (
    <span className="inline-flex items-center gap-0.5 text-emerald-400 font-semibold text-xs">
      <ArrowUp className="w-3 h-3" /> +{delta}
    </span>
  );
  if (delta < 0) return (
    <span className="inline-flex items-center gap-0.5 text-red-400 font-semibold text-xs">
      <ArrowDown className="w-3 h-3" /> {delta}
    </span>
  );
  return (
    <span className="inline-flex items-center gap-0.5 text-muted-foreground text-xs">
      <Minus className="w-3 h-3" /> 0
    </span>
  );
}

function SourceBadge({ sourceType }: { sourceType: string | null }) {
  if (sourceType === 'ai_audit') return (
    <Badge variant="outline" className="text-[10px] gap-1"><Bot className="w-2.5 h-2.5" />AI Audit</Badge>
  );
  if (sourceType === 'transcript') return (
    <Badge variant="outline" className="text-[10px] gap-1"><FileText className="w-2.5 h-2.5" />Transcript</Badge>
  );
  if (sourceType === 'manual') return (
    <Badge variant="outline" className="text-[10px] gap-1"><User className="w-2.5 h-2.5" />Manual</Badge>
  );
  return (
    <Badge variant="outline" className="text-[10px]">{sourceType || 'Unknown'}</Badge>
  );
}

export function CompetitiveScoreChangelogTab() {
  const [vendorFilter, setVendorFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const { data: entries, isLoading } = useQuery({
    queryKey: ['competitive-audit-changelog'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('competitive_audit_log')
        .select('id, vendor_name, subcategory, current_score, validated_score, validated_score_term, rationale, evidence_source, evidence_url, source_type, audit_datetime, type, evidence_confidence_weight')
        .order('audit_datetime', { ascending: false })
        .limit(500)
        .execute();
      if (error) throw error;
      return (data || []) as AuditEntry[];
    },
  });

  const vendors = useMemo(() => {
    if (!entries) return [];
    return [...new Set(entries.map(e => e.vendor_name))].sort();
  }, [entries]);

  const filtered = useMemo(() => {
    if (!entries) return [];
    let result = entries;
    if (vendorFilter !== 'all') result = result.filter(e => e.vendor_name === vendorFilter);
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(e =>
        e.subcategory?.toLowerCase().includes(q) ||
        e.rationale?.toLowerCase().includes(q) ||
        e.vendor_name.toLowerCase().includes(q)
      );
    }
    return result;
  }, [entries, vendorFilter, searchQuery]);

  // Group by date for visual separation
  const grouped = useMemo(() => {
    const groups: Record<string, AuditEntry[]> = {};
    for (const entry of filtered) {
      const dateKey = format(new Date(entry.audit_datetime), 'yyyy-MM-dd');
      if (!groups[dateKey]) groups[dateKey] = [];
      groups[dateKey].push(entry);
    }
    return Object.entries(groups);
  }, [filtered]);

  // Summary stats
  const stats = useMemo(() => {
    if (!filtered.length) return { total: 0, upgrades: 0, downgrades: 0, vendors: 0 };
    let upgrades = 0, downgrades = 0;
    const vendorSet = new Set<string>();
    for (const e of filtered) {
      vendorSet.add(e.vendor_name);
      const delta = (e.validated_score ?? 0) - (e.current_score ?? 0);
      if (delta > 0) upgrades++;
      if (delta < 0) downgrades++;
    }
    return { total: filtered.length, upgrades, downgrades, vendors: vendorSet.size };
  }, [filtered]);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Score Changelog</h3>
        <p className="text-sm text-muted-foreground">
          Historical record of all competitive scorecard changes with before/after scores, rationale, and evidence sources.
        </p>
      </div>

      {/* Filters */}
      <div className="flex gap-3 items-end flex-wrap">
        <div className="min-w-[220px]">
          <label className="text-sm font-medium text-muted-foreground mb-1 block">Vendor</label>
          <Select value={vendorFilter} onValueChange={setVendorFilter}>
            <SelectTrigger className="h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Vendors</SelectItem>
              {vendors.map(v => (
                <SelectItem key={v} value={v}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="min-w-[250px]">
          <label className="text-sm font-medium text-muted-foreground mb-1 block">Search</label>
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              className="h-9 pl-8"
              placeholder="Search subcategory or rationale..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        <Card>
          <CardContent className="py-3 px-4">
            <p className="text-xl font-bold">{stats.total}</p>
            <p className="text-xs text-muted-foreground">Total Changes</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="py-3 px-4">
            <p className="text-xl font-bold text-emerald-400">{stats.upgrades}</p>
            <p className="text-xs text-muted-foreground">Score Upgrades</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="py-3 px-4">
            <p className="text-xl font-bold text-red-400">{stats.downgrades}</p>
            <p className="text-xs text-muted-foreground">Score Downgrades</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="py-3 px-4">
            <p className="text-xl font-bold">{stats.vendors}</p>
            <p className="text-xs text-muted-foreground">Vendors Affected</p>
          </CardContent>
        </Card>
      </div>

      {/* Changelog entries */}
      {isLoading && (
        <div className="flex items-center justify-center py-16 text-muted-foreground text-sm">Loading changelog...</div>
      )}

      {!isLoading && filtered.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 border border-dashed border-border rounded-lg">
          <Filter className="h-12 w-12 text-muted-foreground/30 mb-3" />
          <p className="text-muted-foreground text-sm">No score changes found</p>
        </div>
      )}

      {!isLoading && grouped.length > 0 && (
        <ScrollArea className="h-[600px]">
          <div className="space-y-6">
            {grouped.map(([dateKey, items]) => (
              <div key={dateKey}>
                <div className="sticky top-0 bg-background/95 backdrop-blur-sm z-10 py-1.5 mb-2">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    {format(new Date(dateKey), 'EEEE, MMMM d, yyyy')}
                    <Badge variant="secondary" className="ml-2 text-[10px]">{items.length} changes</Badge>
                  </p>
                </div>
                <div className="space-y-2">
                  {items.map(entry => (
                    <Card key={entry.id} className="border-border/50">
                      <CardContent className="py-3 px-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap mb-1">
                              <span className="font-medium text-sm text-foreground">{entry.vendor_name}</span>
                              <span className="text-muted-foreground text-xs">→</span>
                              <span className="text-sm text-muted-foreground">{entry.subcategory}</span>
                            </div>

                            {/* Score change */}
                            <div className="flex items-center gap-2 mb-2">
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger>
                                    <Badge className={`text-[10px] ${SCORE_COLORS[entry.current_score ?? 0]}`}>
                                      {entry.current_score ?? 0}
                                    </Badge>
                                  </TooltipTrigger>
                                  <TooltipContent side="top">
                                    <p className="text-xs">Previous: {SCORE_TERMS[entry.current_score ?? 0] || 'Not Scored'}</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                              <span className="text-muted-foreground">→</span>
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger>
                                    <Badge className={`text-[10px] ${SCORE_COLORS[entry.validated_score ?? 0]}`}>
                                      {entry.validated_score ?? 0}
                                    </Badge>
                                  </TooltipTrigger>
                                  <TooltipContent side="top">
                                    <p className="text-xs">{entry.validated_score_term || SCORE_TERMS[entry.validated_score ?? 0] || 'Not Scored'}</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                              <ScoreDelta from={entry.current_score} to={entry.validated_score} />
                              <SourceBadge sourceType={entry.source_type} />
                            </div>

                            {/* Rationale */}
                            {entry.rationale && (
                              <p className="text-xs text-muted-foreground leading-relaxed line-clamp-3">
                                {entry.rationale}
                              </p>
                            )}

                            {/* Evidence link */}
                            {entry.evidence_source && (
                              <div className="mt-1.5 flex items-center gap-1 text-[10px] text-muted-foreground/70">
                                <ExternalLink className="w-2.5 h-2.5" />
                                <span className="truncate max-w-[400px]">{entry.evidence_source}</span>
                              </div>
                            )}
                          </div>

                          <div className="text-right shrink-0">
                            <p className="text-[10px] text-muted-foreground">
                              {formatDistanceToNow(new Date(entry.audit_datetime), { addSuffix: true })}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}

import { useState, useMemo, useCallback, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { toast } from 'sonner';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Search, Save, ChevronDown, Users, BarChart3, FileText, ExternalLink, Clock } from 'lucide-react';
import { format } from 'date-fns';
import {
  getHeatmapStyle,
  useHeatmapScores,
  useHeatmapAudits,
  useHeatmapRows,
  useVendorTotals,
  useRubricMap,
  useCompetitorVendors,
  type ScoreCell,
  type AuditEntry,
  type CompetitiveRubric,
} from '@/components/competitive/CompetitiveHeatmapShared';

// ── Score Cell Editor Component ───────────────────────────────────

interface ScoreCellProps {
  cell: ScoreCell;
  lastAudit: AuditEntry | undefined;
  onSave: (cellId: string, newScore: number, rationale: string, evidenceUrl: string, sourceType: string) => void;
  isSaving: boolean;
}

function ScoreCellEditor({ cell, lastAudit, onSave, isSaving }: ScoreCellProps) {
  const [open, setOpen] = useState(false);
  const [score, setScore] = useState(cell.score);
  const [rationale, setRationale] = useState('');
  const [evidenceUrl, setEvidenceUrl] = useState('');
  const [sourceType, setSourceType] = useState('manual');

  useEffect(() => {
    if (open) {
      setScore(cell.score);
      setRationale('');
      setEvidenceUrl('');
      setSourceType('manual');
    }
  }, [open, cell.score]);

  const handleSubmit = () => {
    onSave(cell.id, score, rationale, evidenceUrl, sourceType);
    setOpen(false);
  };

  const hasChanged = score !== cell.score;

  return (
    <Tooltip>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <TooltipTrigger asChild>
            <button
              className="w-full px-2 py-1.5 text-xs font-mono cursor-pointer transition-all hover:ring-1 hover:ring-primary/40 relative"
              style={getHeatmapStyle(cell.score, false)}
            >
              {cell.score}
              {lastAudit?.rationale && (
                <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-primary/70" />
              )}
            </button>
          </TooltipTrigger>
        </PopoverTrigger>
        <PopoverContent className="w-80 p-3 space-y-3" side="bottom" align="center">
          <div className="space-y-1">
            <p className="text-xs font-medium">{cell.vendor} — {cell.subcategory}</p>
            <p className="text-[10px] text-muted-foreground">{cell.category}</p>
          </div>

          <div className="space-y-1">
            <Label className="text-xs">Score</Label>
            <div className="flex gap-1">
              {[0, 1, 2, 3, 4, 5].map(s => (
                <button
                  key={s}
                  onClick={() => setScore(s)}
                  className={`flex-1 py-1.5 text-xs font-mono rounded border transition-all ${
                    score === s
                      ? 'border-primary bg-primary/20 text-primary font-bold'
                      : 'border-border hover:border-primary/40'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1">
            <Label className="text-xs">Rationale <span className="text-muted-foreground">(required for changes)</span></Label>
            <Textarea
              placeholder="Why is this score justified?"
              value={rationale}
              onChange={(e) => setRationale(e.target.value)}
              rows={2}
              className="text-xs"
            />
          </div>

          <div className="space-y-1">
            <Label className="text-xs">Source Type</Label>
            <Select value={sourceType} onValueChange={setSourceType}>
              <SelectTrigger className="h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="manual">Manual Assessment</SelectItem>
                <SelectItem value="web_research">Web Research</SelectItem>
                <SelectItem value="transcript">Call Transcript</SelectItem>
                <SelectItem value="analyst_report">Analyst Report</SelectItem>
                <SelectItem value="product_demo">Product Demo</SelectItem>
                <SelectItem value="customer_feedback">Customer Feedback</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1">
            <Label className="text-xs">Evidence URL <span className="text-muted-foreground">(optional)</span></Label>
            <Input
              placeholder="https://..."
              value={evidenceUrl}
              onChange={(e) => setEvidenceUrl(e.target.value)}
              className="h-8 text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <Button variant="ghost" size="sm" className="text-xs h-7" onClick={() => setOpen(false)}>Cancel</Button>
            <Button
              size="sm"
              className="text-xs h-7"
              onClick={handleSubmit}
              disabled={isSaving || (hasChanged && !rationale.trim())}
            >
              <Save className="w-3 h-3 mr-1" />
              {isSaving ? 'Saving...' : 'Save'}
            </Button>
          </div>
        </PopoverContent>
      </Popover>

      {lastAudit && !open && (
        <TooltipContent side="top" className="max-w-xs p-3 space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-medium">
            <FileText className="w-3 h-3 text-primary" />
            Last Justification
          </div>
          {lastAudit.rationale && (
            <p className="text-xs text-muted-foreground">{lastAudit.rationale}</p>
          )}
          <div className="flex flex-wrap gap-2 text-[10px] text-muted-foreground">
            {lastAudit.source_type && (
              <Badge variant="outline" className="text-[9px] px-1 py-0">{lastAudit.source_type}</Badge>
            )}
            {lastAudit.evidence_url && (
              <a
                href={lastAudit.evidence_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-0.5 text-primary hover:underline"
                onClick={(e) => e.stopPropagation()}
              >
                <ExternalLink className="w-2.5 h-2.5" /> Source
              </a>
            )}
            <span className="flex items-center gap-0.5">
              <Clock className="w-2.5 h-2.5" />
              {format(new Date(lastAudit.audit_datetime), 'MMM d, yyyy')}
            </span>
          </div>
          {lastAudit.current_score != null && lastAudit.validated_score != null && lastAudit.current_score !== lastAudit.validated_score && (
            <p className="text-[10px] text-muted-foreground">
              Changed: {lastAudit.current_score} → {lastAudit.validated_score}
            </p>
          )}
        </TooltipContent>
      )}
    </Tooltip>
  );
}

// ── Main Editor Component ─────────────────────────────────────────

export function CompetitiveScorecardEditorTab() {
  const queryClient = useQueryClient();
  const [selectedVendors, setSelectedVendors] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [vendorSearch, setVendorSearch] = useState('');

  const { data: allVendors, isLoading: vendorsLoading } = useCompetitorVendors();

  const activeVendors = useMemo(() => ['Pendo', ...selectedVendors], [selectedVendors]);

  const { data: allScores, isLoading: scoresLoading } = useHeatmapScores(activeVendors);
  const { data: auditData } = useHeatmapAudits(activeVendors);
  const auditMap = auditData?.auditMap;
  const rows = useHeatmapRows(allScores, searchTerm, activeVendors);
  const vendorTotals = useVendorTotals(allScores, activeVendors);
  const rubricMap = useRubricMap();

  // Save single score with audit trail
  const saveCellMutation = useMutation({
    mutationFn: async (params: { cellId: string; newScore: number; rationale: string; evidenceUrl: string; sourceType: string; oldScore: number; vendorName: string; subcategory: string }) => {
      const updateRes = await gateway.from('competitive_scorecard')
        .update({ score: params.newScore, last_validated_at: new Date().toISOString() })
        .eq('id', params.cellId)
        .execute();
      if (updateRes.error) throw new Error(getErrorMessage(updateRes.error));

      const auditRes = await gateway.from('competitive_audit_log')
        .insert({
          vendor_name: params.vendorName,
          subcategory: params.subcategory,
          current_score: params.oldScore,
          validated_score: params.newScore,
          validated_score_term: String(params.newScore),
          rationale: params.rationale || null,
          evidence_url: params.evidenceUrl || null,
          source_type: params.sourceType,
          type: 'manual_edit',
          status: 'approved',
          audit_datetime: new Date().toISOString(),
        })
        .execute();
      if (auditRes.error) throw new Error(getErrorMessage(auditRes.error));
    },
    onSuccess: () => {
      toast.success('Score updated with audit trail');
      queryClient.invalidateQueries({ queryKey: ['heatmap-scores'] });
      queryClient.invalidateQueries({ queryKey: ['heatmap-audits'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-scores'] });
      queryClient.invalidateQueries({ queryKey: ['vendor-comparison'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-stats'] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const handleCellSave = useCallback((cellId: string, newScore: number, rationale: string, evidenceUrl: string, sourceType: string) => {
    if (!allScores) return;
    for (const [, vendorScores] of allScores.entries()) {
      for (const [, cell] of vendorScores.entries()) {
        if (cell.id === cellId) {
          saveCellMutation.mutate({
            cellId,
            newScore,
            rationale,
            evidenceUrl,
            sourceType,
            oldScore: cell.score,
            vendorName: cell.vendor,
            subcategory: cell.subcategory,
          });
          return;
        }
      }
    }
  }, [allScores, saveCellMutation]);

  const toggleVendor = (vendor: string) => {
    setSelectedVendors(prev =>
      prev.includes(vendor) ? prev.filter(v => v !== vendor) : [...prev, vendor]
    );
  };

  const filteredVendors = useMemo(() => {
    if (!allVendors) return [];
    if (!vendorSearch) return allVendors;
    return allVendors.filter(v => v.toLowerCase().includes(vendorSearch.toLowerCase()));
  }, [allVendors, vendorSearch]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Scorecard Heatmap</h3>
          <p className="text-sm text-muted-foreground">
            Compare vendor maturity scores side-by-side. Click any cell to edit with rationale and source tracking.
          </p>
        </div>
      </div>

      {/* Controls row */}
      <div className="flex gap-3 items-end flex-wrap">
        <div className="min-w-[220px]">
          <label className="text-sm font-medium text-muted-foreground mb-1 block">Vendors to compare</label>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-between text-sm h-9">
                <span className="flex items-center gap-2">
                  <Users className="w-3.5 h-3.5" />
                  {selectedVendors.length === 0
                    ? 'Select vendors...'
                    : `${selectedVendors.length} vendor${selectedVendors.length !== 1 ? 's' : ''} + Pendo`}
                </span>
                <ChevronDown className="w-3.5 h-3.5 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-64 p-0" align="start">
              <div className="p-2 border-b border-border">
                <Input placeholder="Search vendors..." value={vendorSearch} onChange={(e) => setVendorSearch(e.target.value)} className="h-8 text-sm" />
              </div>
              <ScrollArea className="h-64">
                <div className="p-2 space-y-1">
                  <div className="flex items-center gap-2 px-2 py-1.5 rounded-md bg-primary/10">
                    <Checkbox checked disabled className="opacity-50" />
                    <span className="text-sm font-medium">Pendo</span>
                    <Badge variant="outline" className="text-[10px] ml-auto">Always shown</Badge>
                  </div>
                  {vendorsLoading ? (
                    <div className="space-y-2 p-2">{[1, 2, 3].map(i => <Skeleton key={i} className="h-6 w-full" />)}</div>
                  ) : (
                    filteredVendors.map(vendor => (
                      <label key={vendor} className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-muted/50 cursor-pointer">
                        <Checkbox checked={selectedVendors.includes(vendor)} onCheckedChange={() => toggleVendor(vendor)} />
                        <span className="text-sm">{vendor}</span>
                      </label>
                    ))
                  )}
                </div>
              </ScrollArea>
              {selectedVendors.length > 0 && (
                <div className="p-2 border-t border-border">
                  <Button variant="ghost" size="sm" className="w-full text-xs" onClick={() => setSelectedVendors([])}>Clear all</Button>
                </div>
              )}
            </PopoverContent>
          </Popover>
        </div>

        <div className="flex-1 max-w-xs">
          <label className="text-sm font-medium text-muted-foreground mb-1 block">Filter</label>
          <div className="relative">
            <Search className="absolute left-2.5 top-2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search categories..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-9 h-9" />
          </div>
        </div>

        <div className="flex gap-1">
          <Button variant="ghost" size="sm" className="text-xs" onClick={() => setSelectedVendors(allVendors?.slice(0, 5) || [])}>Top 5</Button>
          <Button variant="ghost" size="sm" className="text-xs" onClick={() => setSelectedVendors(allVendors || [])}>All</Button>
        </div>
      </div>

      {/* Empty state */}
      {selectedVendors.length === 0 && !scoresLoading && (
        <div className="flex flex-col items-center justify-center py-16 border border-dashed border-border rounded-lg">
          <BarChart3 className="h-12 w-12 text-muted-foreground/30 mb-3" />
          <p className="text-muted-foreground text-sm">Select vendors above to view the comparison heatmap</p>
          <p className="text-muted-foreground/60 text-xs mt-1">Pendo is always included as the baseline</p>
        </div>
      )}

      {scoresLoading && selectedVendors.length > 0 && (
        <div className="space-y-2">{[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-10 w-full" />)}</div>
      )}

      {/* Heatmap table */}
      {selectedVendors.length > 0 && !scoresLoading && rows.length > 0 && (
        <TooltipProvider delayDuration={300}>
          <div className="border border-border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-muted/50 border-b border-border">
                    <th className="text-left px-3 py-2.5 font-medium text-muted-foreground text-xs sticky left-0 bg-muted/50 z-10 min-w-[160px]">Category</th>
                    <th className="text-left px-3 py-2.5 font-medium text-muted-foreground text-xs sticky left-[160px] bg-muted/50 z-10 min-w-[180px]">Subcategory</th>
                    {activeVendors.map(vendor => (
                      <th key={vendor} className={`text-center px-2 py-2.5 font-medium text-xs min-w-[90px] max-w-[110px] ${vendor === 'Pendo' ? 'bg-primary/10 text-primary' : 'text-muted-foreground'}`}>
                        <span className="truncate block" title={vendor}>{vendor}</span>
                      </th>
                    ))}
                  </tr>
                  <tr className="border-b-2 border-border bg-muted/30">
                    <td className="px-3 py-2 font-bold text-xs sticky left-0 bg-muted/30 z-10" colSpan={2}>Product Totals</td>
                    {activeVendors.map(vendor => {
                      const total = vendorTotals.get(vendor) || 0;
                      return (
                        <td key={vendor} className="text-center px-2 py-2">
                          <span className="font-bold text-sm" style={getHeatmapStyle(total / 20, true)}>{total.toFixed(1)}</span>
                        </td>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, idx) => {
                    const isFirst = idx === 0 || rows[idx - 1]?.category !== row.category;
                    const rowKey = `${row.category}|${row.subcategory}`;
                    const rubric = rubricMap.get(rowKey);

                    return (
                      <tr
                        key={`${row.category}-${row.subcategory}-${row.isAverage}`}
                        className={row.isAverage ? 'bg-muted/40 font-semibold border-t-2 border-border' : 'border-b border-border/50 hover:bg-muted/10'}
                      >
                        <td className={`px-3 py-1.5 text-xs sticky left-0 z-10 ${row.isAverage ? 'bg-muted/40 font-semibold' : 'bg-background text-muted-foreground'}`}>
                          {row.isAverage ? row.category : (isFirst ? row.category : '')}
                        </td>
                        <td className={`px-3 py-1.5 text-xs sticky left-[160px] z-10 ${row.isAverage ? 'bg-muted/40 font-semibold' : 'bg-background'}`}>
                          {row.isAverage ? (
                            <span className="italic">Category Average</span>
                          ) : (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="cursor-help truncate block max-w-[170px]" title={row.subcategory}>{row.subcategory}</span>
                              </TooltipTrigger>
                              {rubric && (
                                <TooltipContent side="right" className="max-w-sm p-3 space-y-1.5">
                                  <p className="font-medium text-xs mb-2">{rubric.subcategory}</p>
                                  {[1, 2, 3, 4, 5].map(level => {
                                    const desc = rubric[`level_${level}_description` as keyof CompetitiveRubric] as string;
                                    if (!desc) return null;
                                    return (
                                      <div key={level} className="text-xs text-muted-foreground">
                                        <span className="font-mono mr-1 font-medium">{level}:</span>{desc}
                                      </div>
                                    );
                                  })}
                                </TooltipContent>
                              )}
                            </Tooltip>
                          )}
                        </td>

                        {activeVendors.map(vendor => {
                          const cell = row.scores.get(vendor);
                          if (!cell) {
                            return <td key={vendor} className="text-center px-0 py-0"><div className="px-2 py-1.5 text-xs text-muted-foreground/40">—</div></td>;
                          }

                          if (row.isAverage) {
                            return (
                              <td key={vendor} className={`text-center px-0 py-0 ${vendor === 'Pendo' ? 'border-l-2 border-r-2 border-primary/20' : ''}`}>
                                <div className="px-2 py-1.5 font-bold text-xs" style={getHeatmapStyle(cell.score, true)}>
                                  {cell.score.toFixed(2)}
                                </div>
                              </td>
                            );
                          }

                          const auditKey = `${vendor}|${cell.subcategory}`;
                          const lastAudit = auditMap?.get(auditKey);

                          return (
                            <td key={vendor} className={`text-center px-0 py-0 ${vendor === 'Pendo' ? 'border-l-2 border-r-2 border-primary/20' : ''}`}>
                              <ScoreCellEditor
                                cell={cell}
                                lastAudit={lastAudit}
                                onSave={handleCellSave}
                                isSaving={saveCellMutation.isPending}
                              />
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </TooltipProvider>
      )}
    </div>
  );
}

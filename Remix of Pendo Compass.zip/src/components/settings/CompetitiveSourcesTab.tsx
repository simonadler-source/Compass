import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Plus, Pencil, Trash2, ExternalLink, Globe, FileText, Search, MessageSquare, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';

interface CompetitiveSource {
  id: string;
  reference_number: string | null;
  source_name: string;
  source_description: string | null;
  subcategory_alignment: string | null;
  source_url: string | null;
  status: string | null;
  added_by: string | null;
  date_added: string | null;
  last_used_date: string | null;
  key_takeaways: string | null;
  created_at: string;
  updated_at: string;
}

const EMPTY_FORM = {
  source_name: '',
  source_description: '',
  subcategory_alignment: '',
  source_url: '',
  status: 'Active',
  added_by: '',
  key_takeaways: '',
};

export function CompetitiveSourcesTab() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [intelDialogOpen, setIntelDialogOpen] = useState(false);
  const [intelText, setIntelText] = useState('');
  const [intelAuthor, setIntelAuthor] = useState('');
  const [editingSource, setEditingSource] = useState<CompetitiveSource | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);

  const ingestManualMutation = useMutation({
    mutationFn: async ({ text, author }: { text: string; author: string }) => {
      const { data, error } = await supabase.functions.invoke('ingest-competitive-slack', {
        body: { manualText: text, authorName: author },
      });
      if (error) throw new Error(error.message);
      if (!data?.success) throw new Error(data?.error || 'Ingestion failed');
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['competitive-sources-all'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-sources'] });
      toast.success(`Extracted ${data.signals_inserted} competitive signals`);
      setIntelDialogOpen(false);
      setIntelText('');
      setIntelAuthor('');
    },
    onError: (err: any) => toast.error(err.message || 'Failed to process intel'),
  });

  const pullSlackMutation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke('ingest-competitive-slack', {
        body: { channelId: 'C0GBWPBFV', lookbackHours: 48 },
      });
      if (error) throw new Error(error.message);
      if (!data?.success) throw new Error(data?.error || 'Pull failed');
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['competitive-sources-all'] });
      toast.success(`Processed ${data.processed} messages, extracted ${data.signals_inserted} signals`);
    },
    onError: (err: any) => toast.error(err.message || 'Failed to pull from Slack'),
  });

  const { data: sources = [], isLoading } = useQuery({
    queryKey: ['competitive-sources-all'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('competitive_sources')
        .select('*')
        .order('source_name', { ascending: true })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as CompetitiveSource[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (formData: typeof EMPTY_FORM & { id?: string }) => {
      const payload = {
        source_name: formData.source_name,
        source_description: formData.source_description || null,
        subcategory_alignment: formData.subcategory_alignment || null,
        source_url: formData.source_url || null,
        status: formData.status,
        added_by: formData.added_by || null,
        key_takeaways: formData.key_takeaways || null,
      };

      if (formData.id) {
        const { error } = await gateway
          .from('competitive_sources')
          .update(payload)
          .eq('id', formData.id)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      } else {
        const { error } = await gateway
          .from('competitive_sources')
          .insert({ ...payload, date_added: new Date().toISOString().split('T')[0] })
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['competitive-sources-all'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-sources'] });
      toast.success(editingSource ? 'Source updated' : 'Source added');
      handleCloseDialog();
    },
    onError: (err: any) => toast.error(err.message || 'Failed to save source'),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway
        .from('competitive_sources')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['competitive-sources-all'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-sources'] });
      toast.success('Source deleted');
    },
    onError: (err: any) => toast.error(err.message || 'Failed to delete source'),
  });

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingSource(null);
    setForm(EMPTY_FORM);
  };

  const handleEdit = (source: CompetitiveSource) => {
    setEditingSource(source);
    setForm({
      source_name: source.source_name,
      source_description: source.source_description || '',
      subcategory_alignment: source.subcategory_alignment || '',
      source_url: source.source_url || '',
      status: source.status || 'Active',
      added_by: source.added_by || '',
      key_takeaways: source.key_takeaways || '',
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!form.source_name.trim()) {
      toast.error('Vendor name is required');
      return;
    }
    saveMutation.mutate({ ...form, id: editingSource?.id });
  };

  const filtered = sources.filter(
    (s) =>
      s.source_name.toLowerCase().includes(search.toLowerCase()) ||
      (s.source_url || '').toLowerCase().includes(search.toLowerCase()) ||
      (s.source_description || '').toLowerCase().includes(search.toLowerCase())
  );

  const vendorGroups = filtered.reduce<Record<string, CompetitiveSource[]>>((acc, s) => {
    const key = s.source_name;
    if (!acc[key]) acc[key] = [];
    acc[key].push(s);
    return acc;
  }, {});

  return (
    <Card className="glass border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-primary" />
              Competitive Sources
            </CardTitle>
            <CardDescription>
              Manage web URLs and references used as evidence in the weekly AI competitive audit. Higher confidence weights produce stronger score influence.
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => pullSlackMutation.mutate()}
              disabled={pullSlackMutation.isPending}
            >
              {pullSlackMutation.isPending ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <MessageSquare className="w-4 h-4 mr-1" />}
              Pull from Slack
            </Button>
            <Button size="sm" variant="outline" onClick={() => setIntelDialogOpen(true)}>
              <MessageSquare className="w-4 h-4 mr-1" /> Paste Intel
            </Button>
            <Button size="sm" variant="glow" onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-1" /> Add Source
            </Button>
          </div>
        </div>
        <div className="relative mt-2 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search sources..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8"
          />
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading sources…</p>
        ) : filtered.length === 0 ? (
          <p className="text-sm text-muted-foreground py-8 text-center">
            {search ? 'No sources match your search.' : 'No competitive sources yet. Click "Add Source" to get started.'}
          </p>
        ) : (
          <div className="rounded-md border border-border overflow-auto max-h-[600px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[140px]">Vendor</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead className="w-[200px]">URL</TableHead>
                  <TableHead className="w-[160px]">Alignment</TableHead>
                  <TableHead className="w-[80px]">Status</TableHead>
                  <TableHead className="w-[90px] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(vendorGroups).map(([vendor, items]) =>
                  items.map((source, idx) => (
                    <TableRow key={source.id}>
                      {idx === 0 && (
                        <TableCell rowSpan={items.length} className="font-medium align-top border-r border-border/50">
                          {vendor}
                          <span className="block text-xs text-muted-foreground mt-0.5">{items.length} source{items.length > 1 ? 's' : ''}</span>
                        </TableCell>
                      )}
                      <TableCell className="text-sm">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="line-clamp-2 cursor-default">{source.source_description || '—'}</span>
                            </TooltipTrigger>
                            {source.key_takeaways && (
                              <TooltipContent side="bottom" className="max-w-xs">
                                <p className="text-xs font-medium mb-1">Key Takeaways</p>
                                <p className="text-xs">{source.key_takeaways}</p>
                              </TooltipContent>
                            )}
                          </Tooltip>
                        </TooltipProvider>
                      </TableCell>
                      <TableCell>
                        {source.source_url ? (
                          <a
                            href={source.source_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-primary hover:underline flex items-center gap-1 max-w-[180px] truncate"
                          >
                            <ExternalLink className="w-3 h-3 shrink-0" />
                            <span className="truncate">{new URL(source.source_url).hostname}</span>
                          </a>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <span className="text-xs text-muted-foreground line-clamp-1">
                          {source.subcategory_alignment || '—'}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge variant={source.status === 'Active' ? 'default' : 'secondary'} className="text-[10px]">
                          {source.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEdit(source)}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-destructive hover:text-destructive"
                            onClick={() => {
                              if (confirm('Delete this source?')) deleteMutation.mutate(source.id);
                            }}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      {/* Add / Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={(o) => { if (!o) handleCloseDialog(); else setDialogOpen(true); }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              {editingSource ? 'Edit Source' : 'Add Competitive Source'}
            </DialogTitle>
            <DialogDescription>
              Sources are used as evidence during the weekly AI competitive audit. Web sources receive a 0.4 confidence weight (vs 1.0 for transcripts).
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-2">
              <Label>Vendor / Source Name *</Label>
              <Input
                placeholder="e.g. Pendo, WalkMe, All Vendors"
                value={form.source_name}
                onChange={(e) => setForm({ ...form, source_name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label>Source URL</Label>
              <Input
                placeholder="https://..."
                value={form.source_url}
                onChange={(e) => setForm({ ...form, source_url: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>Description / Category</Label>
                <Input
                  placeholder="e.g. G2 Reviews, Support Portal"
                  value={form.source_description}
                  onChange={(e) => setForm({ ...form, source_description: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label>Subcategory Alignment</Label>
              <Input
                placeholder="e.g. [Analytics, Guides] or All Categories"
                value={form.subcategory_alignment}
                onChange={(e) => setForm({ ...form, subcategory_alignment: e.target.value })}
              />
              <p className="text-[10px] text-muted-foreground">Which scorecard subcategories this source is relevant to.</p>
            </div>
            <div className="grid gap-2">
              <Label>Key Takeaways</Label>
              <Textarea
                placeholder="What makes this source useful for competitive scoring?"
                value={form.key_takeaways}
                onChange={(e) => setForm({ ...form, key_takeaways: e.target.value })}
                rows={3}
              />
            </div>
            <div className="grid gap-2">
              <Label>Added By</Label>
              <Input
                placeholder="e.g. Your name"
                value={form.added_by}
                onChange={(e) => setForm({ ...form, added_by: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCloseDialog}>Cancel</Button>
            <Button variant="glow" onClick={handleSave} disabled={saveMutation.isPending}>
              {saveMutation.isPending ? 'Saving…' : editingSource ? 'Update' : 'Add Source'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Paste Intel Dialog */}
      <Dialog open={intelDialogOpen} onOpenChange={setIntelDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              Submit Competitive Intel
            </DialogTitle>
            <DialogDescription>
              Paste a Slack thread, email, or internal note containing competitive intelligence. AI will extract competitor signals and add them to the audit pipeline.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-2">
              <Label>Author / Source</Label>
              <Input
                placeholder="e.g. Benoit Delalande — Slack #competition"
                value={intelAuthor}
                onChange={(e) => setIntelAuthor(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label>Intel Content *</Label>
              <Textarea
                placeholder="Paste the full Slack thread or email content here..."
                value={intelText}
                onChange={(e) => setIntelText(e.target.value)}
                rows={10}
                className="font-mono text-xs"
              />
              <p className="text-[10px] text-muted-foreground">
                Include the full conversation with replies for best extraction results.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIntelDialogOpen(false)}>Cancel</Button>
            <Button
              variant="glow"
              onClick={() => {
                if (!intelText.trim()) { toast.error('Content is required'); return; }
                ingestManualMutation.mutate({ text: intelText, author: intelAuthor });
              }}
              disabled={ingestManualMutation.isPending}
            >
              {ingestManualMutation.isPending ? (
                <><Loader2 className="w-4 h-4 mr-1 animate-spin" /> Extracting…</>
              ) : 'Extract & Submit'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

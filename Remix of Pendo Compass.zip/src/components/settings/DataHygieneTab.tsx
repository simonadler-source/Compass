import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Trash2, Search, Loader2, CheckCircle2, AlertTriangle, Zap } from 'lucide-react';

interface CleanupResult {
  success: boolean;
  dryRun: boolean;
  message: string;
  stats: {
    staleCandidates: number;
    staleCompleted: number;
    duplicateCandidates: number;
    duplicatesRemoved: number;
    accountsProcessed: number;
  };
  duplicateGroups: any[];
  staleItems: any[];
  errors: string[];
}

export function DataHygieneTab() {
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<CleanupResult | null>(null);
  const [staleDays, setStaleDays] = useState('60');
  const [autoCompleteStale, setAutoCompleteStale] = useState(true);
  const [deduplicateNBAs, setDeduplicateNBAs] = useState(true);

  const runCleanup = async (dryRun: boolean) => {
    setRunning(true);
    setResult(null);
    try {
      const { data, error } = await supabase.functions.invoke('deduplicate-nbas', {
        body: {
          dryRun,
          bulkAll: true,
          staleDays: parseInt(staleDays),
          autoCompleteStale,
          deduplicateNBAs,
          keepStrategy: 'oldest',
        },
      });

      if (error) throw error;
      setResult(data);
      
      if (dryRun) {
        toast.info(`Preview: ${data.stats.staleCandidates} stale + ${data.stats.duplicateCandidates} duplicate NBAs found`);
      } else {
        toast.success(data.message);
      }
    } catch (err: any) {
      toast.error('Cleanup failed: ' + (err?.message || 'Unknown error'));
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            NBA Bulk Cleanup
          </CardTitle>
          <CardDescription>
            Consolidate duplicate NBAs and auto-cancel stale action items across all accounts using AI-powered analysis.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Configuration */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label htmlFor="dedup-toggle" className="text-sm font-medium">AI Deduplication</Label>
                <Switch
                  id="dedup-toggle"
                  checked={deduplicateNBAs}
                  onCheckedChange={setDeduplicateNBAs}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Uses AI to identify semantically identical NBAs and merge them, keeping the oldest.
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label htmlFor="stale-toggle" className="text-sm font-medium">Auto-cancel Stale</Label>
                <Switch
                  id="stale-toggle"
                  checked={autoCompleteStale}
                  onCheckedChange={setAutoCompleteStale}
                />
              </div>
              <div className="flex items-center gap-2">
                <p className="text-xs text-muted-foreground">Cancel pending NBAs older than</p>
                <Select value={staleDays} onValueChange={setStaleDays}>
                  <SelectTrigger className="w-[100px] h-7 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 days</SelectItem>
                    <SelectItem value="60">60 days</SelectItem>
                    <SelectItem value="90">90 days</SelectItem>
                    <SelectItem value="120">120 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <Separator />

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => runCleanup(true)}
              disabled={running || (!autoCompleteStale && !deduplicateNBAs)}
              className="flex items-center gap-2"
            >
              {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              Preview Changes
            </Button>
            <Button
              variant="glow"
              onClick={() => runCleanup(false)}
              disabled={running || (!autoCompleteStale && !deduplicateNBAs) || !result}
              className="flex items-center gap-2"
            >
              {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              Execute Cleanup
            </Button>
          </div>

          {!result && !running && (
            <Alert className="border-border bg-muted/30">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-muted-foreground text-sm">
                Click "Preview Changes" first to see what would be affected. No data will be modified until you click "Execute Cleanup".
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Results */}
      {result && (
        <Card className="glass border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <CheckCircle2 className="w-5 h-5 text-green-400" />
              {result.dryRun ? 'Preview Results' : 'Cleanup Results'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Stats */}
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="p-3 rounded-lg bg-muted/30 border border-border text-center">
                <p className="text-2xl font-bold text-foreground">
                  {result.dryRun ? result.stats.staleCandidates : result.stats.staleCompleted}
                </p>
                <p className="text-xs text-muted-foreground">Stale NBAs {result.dryRun ? 'to cancel' : 'cancelled'}</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/30 border border-border text-center">
                <p className="text-2xl font-bold text-foreground">
                  {result.dryRun ? result.stats.duplicateCandidates : result.stats.duplicatesRemoved}
                </p>
                <p className="text-xs text-muted-foreground">Duplicates {result.dryRun ? 'to remove' : 'removed'}</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/30 border border-border text-center">
                <p className="text-2xl font-bold text-foreground">{result.stats.accountsProcessed}</p>
                <p className="text-xs text-muted-foreground">Accounts processed</p>
              </div>
            </div>

            {/* Errors */}
            {result.errors.length > 0 && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  {result.errors.map((e, i) => <p key={i} className="text-xs">{e}</p>)}
                </AlertDescription>
              </Alert>
            )}

            {/* Duplicate groups preview */}
            {result.duplicateGroups.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-foreground">Duplicate Groups ({result.duplicateGroups.length})</h4>
                <div className="max-h-64 overflow-y-auto space-y-2">
                  {result.duplicateGroups.slice(0, 20).map((group, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-muted/20 border border-border text-xs space-y-1">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-[10px] border-green-500/30 text-green-400">Keep</Badge>
                        <span className="text-foreground truncate">{group.keep.action}</span>
                      </div>
                      {group.remove.map((r: any, ri: number) => (
                        <div key={ri} className="flex items-center gap-2 pl-2">
                          <Badge variant="outline" className="text-[10px] border-red-500/30 text-red-400">Remove</Badge>
                          <span className="text-muted-foreground truncate">{r.action}</span>
                        </div>
                      ))}
                      <p className="text-muted-foreground italic pl-2">↳ {group.reason}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Stale items preview */}
            {result.staleItems.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-foreground">Stale NBAs (sample of {result.stats.staleCandidates})</h4>
                <div className="max-h-48 overflow-y-auto space-y-1">
                  {result.staleItems.slice(0, 15).map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs p-2 rounded bg-muted/20 border border-border">
                      <Badge variant="outline" className="text-[10px] shrink-0">
                        {new Date(item.created_at).toLocaleDateString()}
                      </Badge>
                      <span className="text-muted-foreground truncate">{item.action}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Mail, FileText, Eye, Save, Bell, CheckCircle2, AlertTriangle, Clock, History, ExternalLink } from 'lucide-react';
import { useEmailTemplates, useEmailLog, EmailTemplate } from '@/hooks/useEmailTemplates';
import { toast } from 'sonner';
import { format } from 'date-fns';

// Sample data for preview
const SAMPLE_PREVIEW_DATA = {
  greeting: 'Good morning, Sarah!',
  date: format(new Date(), 'MMMM d, yyyy'),
  userName: 'Sarah Johnson',
  content: `
    <div style="margin-bottom: 18px;">
      <h2 style="color: #1e293b; font-size: 15px; margin: 0 0 10px 0; display: flex; align-items: center; gap: 8px;">
        <span style="color: #ef4444;">⚠</span> Overdue Actions (3)
      </h2>

      <!-- Account Group -->
      <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 12px; margin-bottom: 10px;">
        <div style="display: flex; align-items: baseline; gap: 10px; margin-bottom: 8px;">
          <span style="font-weight: 600; color: #1e293b;">Acme Corporation</span>
          <a href="#" style="color: #ec4899; font-size: 12px; text-decoration: none;">View Account →</a>
        </div>

        <div style="margin-left: 12px;">
          <div style="font-size: 13px; color: #64748b; margin-bottom: 6px;">Enterprise Renewal Q1</div>

          <!-- Action Item -->
          <div style="background: #ffffff; border-radius: 8px; padding: 10px 10px; margin-bottom: 6px; border: 1px solid #e2e8f0;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
              <div style="flex: 1; min-width: 220px;">
                <p style="margin: 0 0 2px 0; font-weight: 600; color: #0f172a; font-size: 14px;">Follow up on security questionnaire</p>
                <p style="margin: 0; font-size: 12px; color: #ef4444;">Due: Jan 15 (3d overdue)</p>
              </div>
              <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                <a href="#" style="display: inline-block; padding: 6px 10px; background: #22c55e; color: white; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">✓ Done</a>
                <a href="#" style="display: inline-block; padding: 6px 10px; background: #ef4444; color: white; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">✕</a>
                <a href="#" style="display: inline-block; padding: 6px 9px; background: #f1f5f9; color: #64748b; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">+1d</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div style="margin-bottom: 18px;">
      <h2 style="color: #1e293b; font-size: 15px; margin: 0 0 10px 0; display: flex; align-items: center; gap: 8px;">
        <span style="color: #f59e0b;">📋</span> Due Today (2)
      </h2>

      <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 12px; margin-bottom: 10px;">
        <div style="display: flex; align-items: baseline; gap: 10px; margin-bottom: 8px;">
          <span style="font-weight: 600; color: #1e293b;">TechStart Inc</span>
          <a href="#" style="color: #ec4899; font-size: 12px; text-decoration: none;">View Account →</a>
        </div>

        <div style="margin-left: 12px;">
          <div style="font-size: 13px; color: #64748b; margin-bottom: 6px;">New Business - Analytics Platform</div>

          <div style="background: #ffffff; border-radius: 8px; padding: 10px 10px; margin-bottom: 6px; border: 1px solid #e2e8f0;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
              <div style="flex: 1; min-width: 220px;">
                <p style="margin: 0 0 2px 0; font-weight: 600; color: #0f172a; font-size: 14px;">Send POC environment credentials</p>
                <p style="margin: 0; font-size: 12px; color: #f59e0b;">Due: Today</p>
              </div>
              <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                <a href="#" style="display: inline-block; padding: 6px 10px; background: #22c55e; color: white; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">✓ Done</a>
                <a href="#" style="display: inline-block; padding: 6px 10px; background: #ef4444; color: white; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">✕</a>
                <a href="#" style="display: inline-block; padding: 6px 9px; background: #f1f5f9; color: #64748b; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">+1d</a>
                <a href="#" style="display: inline-block; padding: 6px 9px; background: #f1f5f9; color: #64748b; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">+2d</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div style="margin-bottom: 18px;">
      <h2 style="color: #1e293b; font-size: 15px; margin: 0 0 10px 0; display: flex; align-items: center; gap: 8px;">
        <span style="color: #0ea5e9;">🗓</span> Timeline Tasks (2)
      </h2>

      <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 12px; margin-bottom: 10px;">
        <div style="display: flex; align-items: baseline; gap: 10px; margin-bottom: 8px;">
          <span style="font-weight: 600; color: #1e293b;">Global Logistics Co</span>
          <a href="#" style="color: #ec4899; font-size: 12px; text-decoration: none;">View Account →</a>
        </div>

        <div style="margin-left: 12px;">
          <div style="font-size: 13px; color: #64748b; margin-bottom: 6px;">Digital Transformation Initiative</div>

          <div style="background: #ffffff; border-radius: 8px; padding: 10px 10px; margin-bottom: 6px; border: 1px solid #e2e8f0;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
              <div style="flex: 1; min-width: 220px;">
                <p style="margin: 0 0 2px 0; font-weight: 600; color: #0f172a; font-size: 14px;">Eval Deployment kickoff</p>
                <p style="margin: 0; font-size: 12px; color: #f59e0b;">Target: Today</p>
              </div>
              <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                <a href="#" style="display: inline-block; padding: 6px 10px; background: #22c55e; color: white; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">✓ Done</a>
                <a href="#" style="display: inline-block; padding: 6px 10px; background: #0ea5e9; color: white; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">▶ In progress</a>
                <a href="#" style="display: inline-block; padding: 6px 10px; background: #f1f5f9; color: #64748b; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">Skip</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div>
      <h2 style="color: #1e293b; font-size: 15px; margin: 0 0 10px 0; display: flex; align-items: center; gap: 8px;">
        <span style="color: #22c55e;">📅</span> Upcoming This Week (4)
      </h2>

      <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 12px;">
        <div style="display: flex; align-items: baseline; gap: 10px; margin-bottom: 8px;">
          <span style="font-weight: 600; color: #1e293b;">Global Logistics Co</span>
          <a href="#" style="color: #ec4899; font-size: 12px; text-decoration: none;">View Account →</a>
        </div>

        <div style="margin-left: 12px;">
          <div style="font-size: 13px; color: #64748b; margin-bottom: 6px;">Digital Transformation Initiative</div>

          <div style="background: #ffffff; border-radius: 8px; padding: 10px 10px; margin-bottom: 6px; border: 1px solid #e2e8f0;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
              <div style="flex: 1; min-width: 220px;">
                <p style="margin: 0 0 2px 0; font-weight: 600; color: #0f172a; font-size: 14px;">Prepare architecture review deck</p>
                <p style="margin: 0; font-size: 12px; color: #16a34a;">Due: Jan 20</p>
              </div>
              <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                <a href="#" style="display: inline-block; padding: 6px 10px; background: #22c55e; color: white; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">✓ Done</a>
                <a href="#" style="display: inline-block; padding: 6px 10px; background: #ef4444; color: white; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: 600;">✕</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
};

interface TemplateEditorProps {
  template: EmailTemplate;
  onSave: (updates: Partial<EmailTemplate>) => void;
  isSaving: boolean;
}

function TemplateEditor({ template, onSave, isSaving }: TemplateEditorProps) {
  const [subject, setSubject] = useState(template.subject);
  const [htmlTemplate, setHtmlTemplate] = useState(template.html_template);
  const [showPreview, setShowPreview] = useState(false);

  const renderPreview = () => {
    let html = htmlTemplate;
    Object.entries(SAMPLE_PREVIEW_DATA).forEach(([key, value]) => {
      html = html.replace(new RegExp(`{{${key}}}`, 'g'), value);
    });
    return html;
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Email Subject</Label>
        <Input
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="Subject line with {{date}} placeholder"
          className="bg-background"
        />
        <p className="text-xs text-muted-foreground">Use {'{{date}}'} for current date</p>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label>HTML Template</Label>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowPreview(!showPreview)}
          >
            <Eye className="w-4 h-4 mr-2" />
            {showPreview ? 'Edit' : 'Preview'}
          </Button>
        </div>

        {showPreview ? (
          <div className="border rounded-lg overflow-hidden">
            <div className="bg-muted/50 px-4 py-2 border-b text-sm text-muted-foreground">
              Preview
            </div>
            <iframe
              srcDoc={renderPreview()}
              className="w-full h-[500px] bg-white"
              title="Email Preview"
            />
          </div>
        ) : (
          <Textarea
            value={htmlTemplate}
            onChange={(e) => setHtmlTemplate(e.target.value)}
            placeholder="HTML template..."
            className="font-mono text-xs h-[400px] bg-background"
          />
        )}
        <p className="text-xs text-muted-foreground">
          Available placeholders: {'{{greeting}}'}, {'{{content}}'}, {'{{date}}'}
        </p>
      </div>

      <Button
        onClick={() => onSave({ subject, html_template: htmlTemplate })}
        disabled={isSaving}
        variant="glow"
      >
        <Save className="w-4 h-4 mr-2" />
        {isSaving ? 'Saving...' : 'Save Template'}
      </Button>
    </div>
  );
}

export function EmailNotificationsTab() {
  const { templates, notificationTypes, isLoading, updateTemplate, toggleNotificationType } = useEmailTemplates();
  const { data: emailLog = [], isLoading: logLoading } = useEmailLog(100);
  const [selectedTemplate, setSelectedTemplate] = useState<EmailTemplate | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [selectedLogEntry, setSelectedLogEntry] = useState<string | null>(null);

  const getPreviewHtml = () => {
    const template = templates.find(t => t.template_key === 'action_digest');
    if (!template) return '';

    let html = template.html_template;
    Object.entries(SAMPLE_PREVIEW_DATA).forEach(([key, value]) => {
      html = html.replace(new RegExp(`{{${key}}}`, 'g'), value);
    });
    return html;
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/3" />
          <div className="h-64 bg-muted rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="types" className="space-y-4">
        <TabsList>
          <TabsTrigger value="types" className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            Notification Types
          </TabsTrigger>
          <TabsTrigger value="templates" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Email Templates
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Preview
          </TabsTrigger>
          <TabsTrigger value="log" className="flex items-center gap-2">
            <History className="w-4 h-4" />
            Email Log
          </TabsTrigger>
        </TabsList>

        <TabsContent value="types" className="space-y-4">
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle>Notification Types</CardTitle>
              <CardDescription>Enable or disable notification types for all users</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {notificationTypes.map(type => (
                <div
                  key={type.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border"
                >
                  <div className="flex items-center gap-3">
                    {type.type_key === 'alerts' && <Bell className="w-5 h-5 text-purple-500" />}
                    {type.type_key === 'sentiment_change' && <AlertTriangle className="w-5 h-5 text-amber-500" />}
                    {type.type_key === 'new_action' && <CheckCircle2 className="w-5 h-5 text-green-500" />}
                    {type.type_key === 'overdue_reminder' && <Clock className="w-5 h-5 text-red-500" />}
                    <div>
                      <p className="font-medium text-foreground">{type.name}</p>
                      <p className="text-sm text-muted-foreground">{type.description}</p>
                    </div>
                  </div>
                  <Switch
                    checked={type.is_enabled}
                    onCheckedChange={(checked) => toggleNotificationType.mutate({ id: type.id, is_enabled: checked })}
                  />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle>Email Templates</CardTitle>
              <CardDescription>Customize the email templates sent to users</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {templates.map(template => (
                  <div
                    key={template.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border"
                  >
                    <div className="flex items-center gap-3">
                      <Mail className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                      <div>
                        <p className="font-medium text-foreground">{template.name}</p>
                        <p className="text-sm text-muted-foreground">{template.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Subject: {template.subject}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={template.is_active ? 'default' : 'secondary'}>
                        {template.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>Edit Template: {template.name}</DialogTitle>
                            <DialogDescription>{template.description}</DialogDescription>
                          </DialogHeader>
                          <TemplateEditor
                            template={template}
                            onSave={(updates) => updateTemplate.mutate({ id: template.id, ...updates })}
                            isSaving={updateTemplate.isPending}
                          />
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview" className="space-y-4">
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                Email Preview
              </CardTitle>
              <CardDescription>
                Preview how the action digest email will look to users
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden bg-white">
                <div className="bg-muted/50 px-4 py-3 border-b flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">Your Action Items - {format(new Date(), 'MMMM d, yyyy')}</p>
                    <p className="text-xs text-muted-foreground">to: sarah.johnson@company.com</p>
                  </div>
                  <Badge variant="outline">Sample Data</Badge>
                </div>
                <iframe
                  srcDoc={getPreviewHtml()}
                  className="w-full h-[600px]"
                  title="Email Preview"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="log" className="space-y-4">
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                Email Log
              </CardTitle>
              <CardDescription>
                History of all sent email notifications with recipient, status, and content
              </CardDescription>
            </CardHeader>
            <CardContent>
              {logLoading ? (
                <div className="animate-pulse space-y-2">
                  {[1, 2, 3, 4, 5].map(i => (
                    <div key={i} className="h-12 bg-muted rounded" />
                  ))}
                </div>
              ) : emailLog.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Mail className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No emails have been sent yet</p>
                </div>
              ) : (
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Sent At</TableHead>
                        <TableHead>Recipient</TableHead>
                        <TableHead>Subject</TableHead>
                        <TableHead>Template</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {emailLog.map((entry) => (
                        <TableRow key={entry.id}>
                          <TableCell className="whitespace-nowrap">
                            <div className="text-sm">
                              {format(new Date(entry.created_at), 'MMM d, yyyy')}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {format(new Date(entry.created_at), 'h:mm a')}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Mail className="w-4 h-4 text-muted-foreground" />
                              <span className="text-sm">{entry.recipient_email}</span>
                            </div>
                          </TableCell>
                          <TableCell className="max-w-[300px]">
                            <span className="text-sm truncate block">{entry.subject}</span>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">
                              {entry.template_key.replace(/_/g, ' ')}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={entry.status === 'sent' ? 'default' : 'destructive'}
                              className={entry.status === 'sent' ? 'bg-green-500/10 text-green-600 border-green-500/20' : ''}
                            >
                              {entry.status === 'sent' ? (
                                <CheckCircle2 className="w-3 h-3 mr-1" />
                              ) : (
                                <AlertTriangle className="w-3 h-3 mr-1" />
                              )}
                              {entry.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              {entry.resend_id && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  asChild
                                >
                                  <a
                                    href={`https://resend.com/emails/${entry.resend_id}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex items-center gap-1"
                                  >
                                    <ExternalLink className="w-3 h-3" />
                                    <span className="text-xs">Resend</span>
                                  </a>
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { format, formatDistanceToNow } from 'date-fns';
import { Key, Plus, Trash2, Copy, Eye, EyeOff, Activity, Shield, Clock, AlertTriangle, CheckCircle2, XCircle, Server } from 'lucide-react';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

// ==================== API KEY MANAGEMENT ====================

function generateApiKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let key = 'sk_mcp_';
  for (let i = 0; i < 48; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return key;
}

async function hashKey(key: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(key);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

interface ApiKey {
  id: string;
  name: string;
  description: string | null;
  key_prefix: string;
  permissions: { read: boolean; write: boolean; coaching?: boolean };
  allowed_tools: string[] | null;
  is_active: boolean;
  last_used_at: string | null;
  request_count: number;
  expires_at: string | null;
  created_at: string;
}

interface AccessLog {
  id: string;
  api_key_name: string | null;
  tool_name: string;
  response_status: string;
  error_message: string | null;
  execution_time_ms: number | null;
  created_at: string;
}

function useApiKeys() {
  return useQuery({
    queryKey: ['mcp-api-keys'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('mcp_api_keys')
        .select('*')
        .order('created_at', { ascending: false })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as ApiKey[];
    },
  });
}

function useAccessLogs(limit = 100) {
  return useQuery({
    queryKey: ['mcp-access-logs', limit],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('mcp_access_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(limit)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as AccessLog[];
    },
    refetchInterval: 30000,
  });
}

// ==================== CREATE KEY DIALOG ====================

function CreateKeyDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const queryClient = useQueryClient();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [canWrite, setCanWrite] = useState(false);
  const [canCoaching, setCanCoaching] = useState(false);
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const handleCreate = async () => {
    if (!name.trim()) { toast.error('Name is required'); return; }
    setCreating(true);
    try {
      const rawKey = generateApiKey();
      const keyHash = await hashKey(rawKey);
      const keyPrefix = rawKey.substring(0, 12) + '...';

      const { error } = await gateway.from('mcp_api_keys').insert({
        name: name.trim(),
        description: description.trim() || null,
        key_hash: keyHash,
        key_prefix: keyPrefix,
        permissions: { read: true, write: canWrite, coaching: canCoaching },
      }).execute();

      if (error) throw new Error(getErrorMessage(error));

      setGeneratedKey(rawKey);
      queryClient.invalidateQueries({ queryKey: ['mcp-api-keys'] });
      toast.success('API key created');
    } catch (err: any) {
      toast.error('Failed to create key: ' + (err?.message || 'Unknown'));
    } finally {
      setCreating(false);
    }
  };

  const handleClose = () => {
    setName('');
    setDescription('');
    setCanWrite(false);
    setCanCoaching(false);
    setGeneratedKey(null);
    onOpenChange(false);
  };

  const handleCopy = () => {
    if (generatedKey) {
      navigator.clipboard.writeText(generatedKey);
      toast.success('API key copied to clipboard');
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Key className="w-5 h-5 text-primary" />
            {generatedKey ? 'API Key Created' : 'Create MCP API Key'}
          </DialogTitle>
          <DialogDescription>
            {generatedKey
              ? 'Copy this key now. It will not be shown again.'
              : 'Create a new API key for external MCP access.'}
          </DialogDescription>
        </DialogHeader>

        {generatedKey ? (
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/30">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-4 h-4 text-destructive" />
                <span className="text-sm font-medium text-destructive">Save this key securely</span>
              </div>
              <p className="text-xs text-muted-foreground">This is the only time this key will be displayed. Store it in a secure location.</p>
            </div>
            <div className="flex items-center gap-2">
              <Input value={generatedKey} readOnly className="font-mono text-xs" />
              <Button size="icon" variant="outline" onClick={handleCopy}><Copy className="w-4 h-4" /></Button>
            </div>
            <DialogFooter>
              <Button onClick={handleClose}>Done</Button>
            </DialogFooter>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <Label>Name *</Label>
              <Input placeholder="e.g. Salesforce Integration" value={name} onChange={e => setName(e.target.value)} />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea placeholder="What will this key be used for?" value={description} onChange={e => setDescription(e.target.value)} rows={2} />
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border">
              <div>
                <p className="text-sm font-medium">Write Access</p>
                <p className="text-xs text-muted-foreground">Allow creating and updating records</p>
              </div>
              <Switch checked={canWrite} onCheckedChange={setCanWrite} />
            </div>
             <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border">
               <div>
                 <p className="text-sm font-medium">Coaching Data Access</p>
                 <p className="text-xs text-muted-foreground">Allow access to SE coaching scores and performance data (sensitive)</p>
               </div>
               <Switch checked={canCoaching} onCheckedChange={setCanCoaching} />
             </div>
            <DialogFooter>
              <Button variant="outline" onClick={handleClose}>Cancel</Button>
              <Button onClick={handleCreate} disabled={creating}>
                {creating ? 'Creating...' : 'Create Key'}
              </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ==================== MAIN COMPONENT ====================

export function MCPSettingsTab() {
  const queryClient = useQueryClient();
  const { data: apiKeys = [], isLoading: keysLoading } = useApiKeys();
  const { data: accessLogs = [], isLoading: logsLoading } = useAccessLogs();
  const [createOpen, setCreateOpen] = useState(false);
  const [subTab, setSubTab] = useState('keys');

  const mcpEndpoint = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/mcp-server`;

  const handleToggleKey = async (keyId: string, isActive: boolean) => {
    try {
      const { error } = await gateway.from('mcp_api_keys').update({ is_active: !isActive }).eq('id', keyId).execute();
      if (error) throw new Error(getErrorMessage(error));
      queryClient.invalidateQueries({ queryKey: ['mcp-api-keys'] });
      toast.success(isActive ? 'API key deactivated' : 'API key activated');
    } catch (err: any) {
      toast.error(err?.message || 'Failed to update key');
    }
  };

  const handleDeleteKey = async (keyId: string) => {
    if (!confirm('Are you sure? This will permanently revoke this API key.')) return;
    try {
      const { error } = await gateway.from('mcp_api_keys').delete().eq('id', keyId).execute();
      if (error) throw new Error(getErrorMessage(error));
      queryClient.invalidateQueries({ queryKey: ['mcp-api-keys'] });
      toast.success('API key deleted');
    } catch (err: any) {
      toast.error(err?.message || 'Failed to delete key');
    }
  };

  const statusIcon = (status: string) => {
    if (status === 'success') return <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />;
    if (status === 'denied') return <Shield className="w-3.5 h-3.5 text-yellow-500" />;
    return <XCircle className="w-3.5 h-3.5 text-destructive" />;
  };

  // Stats
  const totalRequests = apiKeys.reduce((s, k) => s + (k.request_count || 0), 0);
  const activeKeys = apiKeys.filter(k => k.is_active).length;
  const recentErrors = accessLogs.filter(l => l.response_status === 'error').length;

  return (
    <div className="space-y-6">
      {/* Connection Details */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="w-5 h-5 text-primary" />
            MCP Connection Details
          </CardTitle>
          <CardDescription>Use these details to connect external systems via the Model Context Protocol.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3">
            <div className="p-3 rounded-lg bg-muted/30 border border-border">
              <Label className="text-xs text-muted-foreground">MCP Endpoint URL</Label>
              <div className="flex items-center gap-2 mt-1">
                <code className="text-xs font-mono text-foreground flex-1 break-all">{mcpEndpoint}</code>
                <Button size="icon" variant="ghost" className="shrink-0" onClick={() => { navigator.clipboard.writeText(mcpEndpoint); toast.success('Endpoint copied'); }}>
                  <Copy className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-muted/30 border border-border">
              <Label className="text-xs text-muted-foreground">Transport Protocol</Label>
              <p className="text-sm font-medium mt-1">Streamable HTTP (JSON-RPC 2.0)</p>
            </div>
            <div className="p-3 rounded-lg bg-muted/30 border border-border">
              <Label className="text-xs text-muted-foreground">Authentication</Label>
              <p className="text-sm mt-1">Set <code className="text-xs bg-muted px-1 py-0.5 rounded">x-mcp-api-key</code> header or <code className="text-xs bg-muted px-1 py-0.5 rounded">Authorization: Bearer &lt;key&gt;</code></p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="glass border-border">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <Key className="w-8 h-8 text-primary/60" />
              <div>
                <p className="text-2xl font-bold">{activeKeys}</p>
                <p className="text-xs text-muted-foreground">Active Keys</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass border-border">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <Activity className="w-8 h-8 text-primary/60" />
              <div>
                <p className="text-2xl font-bold">{totalRequests.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Total Requests</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass border-border">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-8 h-8 text-destructive/60" />
              <div>
                <p className="text-2xl font-bold">{recentErrors}</p>
                <p className="text-xs text-muted-foreground">Recent Errors</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={subTab} onValueChange={setSubTab}>
        <TabsList className="bg-muted/50">
          <TabsTrigger value="keys" className="text-xs">API Keys</TabsTrigger>
          <TabsTrigger value="logs" className="text-xs">Access Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="keys" className="mt-4 space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">Manage API keys for external MCP consumers.</p>
            <Button size="sm" onClick={() => setCreateOpen(true)}>
              <Plus className="w-4 h-4 mr-1" /> Create Key
            </Button>
          </div>

          <Card className="glass border-border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Key</TableHead>
                  <TableHead>Permissions</TableHead>
                  <TableHead>Requests</TableHead>
                  <TableHead>Last Used</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-[80px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {keysLoading ? (
                  <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">Loading...</TableCell></TableRow>
                ) : apiKeys.length === 0 ? (
                  <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No API keys created yet.</TableCell></TableRow>
                ) : apiKeys.map(key => (
                  <TableRow key={key.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium text-sm">{key.name}</p>
                        {key.description && <p className="text-xs text-muted-foreground truncate max-w-[200px]">{key.description}</p>}
                      </div>
                    </TableCell>
                    <TableCell><code className="text-xs text-muted-foreground">{key.key_prefix}</code></TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        <Badge variant="outline" className="text-xs">Read</Badge>
                        {key.permissions?.write && <Badge variant="outline" className="text-xs border-yellow-500/30 text-yellow-600 dark:text-yellow-400">Write</Badge>}
                        {key.permissions?.coaching && <Badge variant="outline" className="text-xs border-violet-500/30 text-violet-600 dark:text-violet-400">Coaching</Badge>}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{(key.request_count || 0).toLocaleString()}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {key.last_used_at ? formatDistanceToNow(new Date(key.last_used_at), { addSuffix: true }) : 'Never'}
                    </TableCell>
                    <TableCell>
                      <Switch checked={key.is_active} onCheckedChange={() => handleToggleKey(key.id, key.is_active)} />
                    </TableCell>
                    <TableCell>
                      <Button size="icon" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => handleDeleteKey(key.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="mt-4 space-y-4">
          <p className="text-sm text-muted-foreground">Recent MCP access activity (last 100 requests, auto-refreshes every 30s).</p>

          <Card className="glass border-border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[40px]">Status</TableHead>
                  <TableHead>Key</TableHead>
                  <TableHead>Tool</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Error</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logsLoading ? (
                  <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">Loading...</TableCell></TableRow>
                ) : accessLogs.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No access logs yet.</TableCell></TableRow>
                ) : accessLogs.map(log => (
                  <TableRow key={log.id}>
                    <TableCell>{statusIcon(log.response_status)}</TableCell>
                    <TableCell className="text-xs">{log.api_key_name || '—'}</TableCell>
                    <TableCell><code className="text-xs">{log.tool_name}</code></TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(log.created_at), { addSuffix: true })}
                    </TableCell>
                    <TableCell className="text-xs">
                      {log.execution_time_ms != null ? `${log.execution_time_ms}ms` : '—'}
                    </TableCell>
                    <TableCell className="text-xs text-destructive truncate max-w-[200px]">{log.error_message || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>

      <CreateKeyDialog open={createOpen} onOpenChange={setCreateOpen} />
    </div>
  );
}

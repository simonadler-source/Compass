import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Bell, Clock, Calendar, Save } from 'lucide-react';
import { useNotificationPreferences, NotificationPreferences } from '@/hooks/useNotificationPreferences';

const DAYS_OF_WEEK = [
  { value: 0, label: 'Sunday' },
  { value: 1, label: 'Monday' },
  { value: 2, label: 'Tuesday' },
  { value: 3, label: 'Wednesday' },
  { value: 4, label: 'Thursday' },
  { value: 5, label: 'Friday' },
  { value: 6, label: 'Saturday' },
];

export function NotificationPreferencesCard() {
  const { preferences, isLoading, savePreferences } = useNotificationPreferences();
  const [localPrefs, setLocalPrefs] = useState<Partial<NotificationPreferences>>({});
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    if (preferences) {
      setLocalPrefs(preferences);
    }
  }, [preferences]);

  const updatePref = <K extends keyof NotificationPreferences>(key: K, value: NotificationPreferences[K]) => {
    setLocalPrefs(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const handleSave = () => {
    savePreferences.mutate(localPrefs);
    setHasChanges(false);
  };

  if (isLoading) {
    return (
      <Card className="glass border-border">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-1/3" />
            <div className="h-10 bg-muted rounded" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
          Email Notifications
        </CardTitle>
        <CardDescription>Configure how and when you receive email notifications</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Master toggle */}
        <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border">
          <div>
            <p className="font-medium text-foreground">Email Notifications</p>
            <p className="text-sm text-muted-foreground">Receive email updates about your accounts and actions</p>
          </div>
          <Switch
            checked={localPrefs.email_enabled ?? true}
            onCheckedChange={(checked) => updatePref('email_enabled', checked)}
          />
        </div>

        {localPrefs.email_enabled && (
          <>
            {/* Frequency */}
            <div className="space-y-3">
              <Label className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                Notification Frequency
              </Label>
              <Select
                value={localPrefs.frequency || 'daily'}
                onValueChange={(value) => updatePref('frequency', value as 'realtime' | 'daily' | 'weekly')}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="realtime">Real-time (immediate)</SelectItem>
                  <SelectItem value="daily">Daily digest</SelectItem>
                  <SelectItem value="weekly">Weekly digest</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Digest settings */}
            {(localPrefs.frequency === 'daily' || localPrefs.frequency === 'weekly') && (
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Delivery Time</Label>
                  <Input
                    type="time"
                    value={localPrefs.digest_time?.substring(0, 5) || '08:00'}
                    onChange={(e) => updatePref('digest_time', e.target.value + ':00')}
                    className="bg-background"
                  />
                </div>

                {localPrefs.frequency === 'weekly' && (
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      Delivery Day
                    </Label>
                    <Select
                      value={String(localPrefs.digest_day ?? 1)}
                      onValueChange={(value) => updatePref('digest_day', parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {DAYS_OF_WEEK.map(day => (
                          <SelectItem key={day.value} value={String(day.value)}>
                            {day.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            )}

            {/* Quiet hours */}
            <div className="space-y-3">
              <Label>Quiet Hours (optional)</Label>
              <p className="text-sm text-muted-foreground">Pause real-time notifications during these hours</p>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Start</Label>
                  <Input
                    type="time"
                    value={localPrefs.quiet_hours_start?.substring(0, 5) || ''}
                    onChange={(e) => updatePref('quiet_hours_start', e.target.value ? e.target.value + ':00' : null)}
                    className="bg-background"
                    placeholder="e.g., 22:00"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">End</Label>
                  <Input
                    type="time"
                    value={localPrefs.quiet_hours_end?.substring(0, 5) || ''}
                    onChange={(e) => updatePref('quiet_hours_end', e.target.value ? e.target.value + ':00' : null)}
                    className="bg-background"
                    placeholder="e.g., 08:00"
                  />
                </div>
              </div>
            </div>

            {/* Notification types */}
            <div className="space-y-3">
              <Label>Notification Types</Label>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/20 border border-border/50">
                  <div>
                    <p className="text-sm font-medium text-foreground">Alerts</p>
                    <p className="text-xs text-muted-foreground">Triggered alerts for your accounts and opportunities (e.g., stalled stages, sentiment changes)</p>
                  </div>
                  <Switch
                    checked={localPrefs.notify_alerts ?? true}
                    onCheckedChange={(checked) => updatePref('notify_alerts', checked)}
                  />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/20 border border-border/50">
                  <div>
                    <p className="text-sm font-medium text-foreground">New & Updated Actions</p>
                    <p className="text-xs text-muted-foreground">When actions are created or assigned to you</p>
                  </div>
                  <Switch
                    checked={localPrefs.notify_new_actions ?? true}
                    onCheckedChange={(checked) => updatePref('notify_new_actions', checked)}
                  />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/20 border border-border/50">
                  <div>
                    <p className="text-sm font-medium text-foreground">Overdue Reminders</p>
                    <p className="text-xs text-muted-foreground">Daily reminder of overdue actions</p>
                  </div>
                  <Switch
                    checked={localPrefs.notify_overdue_reminders ?? true}
                    onCheckedChange={(checked) => updatePref('notify_overdue_reminders', checked)}
                  />
                </div>
              </div>
            </div>
          </>
        )}

        {hasChanges && (
          <Button
            onClick={handleSave}
            disabled={savePreferences.isPending}
            className="w-full"
            variant="glow"
          >
            <Save className="w-4 h-4 mr-2" />
            {savePreferences.isPending ? 'Saving...' : 'Save Preferences'}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

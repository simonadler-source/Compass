import { usePipelineHealthStats, useFlaggedTranscripts } from '@/hooks/useAnalysisRunLogs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle2, XCircle, Clock, Activity, AlertTriangle, TrendingUp, RotateCcw } from 'lucide-react';
import { useState } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import { gateway } from '@/lib/apiGateway';
import { decryptTranscript } from '@/lib/encryption';
import { toast } from 'sonner';
import { useQueryClient } from '@tanstack/react-query';
import { cn } from '@/lib/utils';

export function PipelineHealthTab() {
  const [daysBack, setDaysBack] = useState(7);
  const [retrying, setRetrying] = useState<Record<string, boolean>>({});
  const { data: stats, isLoading } = usePipelineHealthStats(daysBack);
  const { data: flagged } = useFlaggedTranscripts(20);
  const queryClient = useQueryClient();

  const handleRetryTranscript = async (transcriptId: string) => {
    setRetrying(prev => ({ ...prev, [transcriptId]: true }));
    try {
      // Get the failed pass keys for this transcript
      const failedEntry = flagged?.find(f => f.transcriptId === transcriptId);
      const failedPassKeys = failedEntry?.failedPassKeys || [];

      // Fetch the transcript content
      const { data: review, error: fetchError } = await gateway
        .from('transcript_reviews')
        .select('transcript_content, final_account_id, opportunity_id, is_encrypted')
        .eq('id', transcriptId)
        .maybeSingle();

      if (fetchError) throw new Error(`Failed to fetch transcript: ${fetchError.message}`);

      let transcriptContent = review?.transcript_content;

      if ((!transcriptContent || review?.is_encrypted) && transcriptId) {
        transcriptContent = await decryptTranscript(transcriptId, 'transcript_reviews');
      }

      if (!transcriptContent || !transcriptContent.trim()) {
        throw new Error('Transcript content is empty or could not be decrypted');
      }

      const { error } = await supabase.functions.invoke('unified-transcript-analysis', {
        body: {
          transcript: transcriptContent.slice(0, 120000),
          transcriptReviewId: transcriptId,
          accountId: review?.final_account_id || undefined,
          opportunityId: review?.opportunity_id || undefined,
          retryPassKeys: failedPassKeys.length > 0 ? failedPassKeys : undefined,
          streaming: false,
        },
      });
      if (error) throw error;
      toast.success(`Retrying ${failedPassKeys.length || 'all'} failed stage(s)`);
      queryClient.invalidateQueries({ queryKey: ['pipeline-health-stats'] });
      queryClient.invalidateQueries({ queryKey: ['flagged-transcripts'] });
      queryClient.invalidateQueries({ queryKey: ['analysis-run-logs', transcriptId] });
    } catch (err: any) {
      toast.error(`Retry failed: ${err.message || 'Unknown error'}`);
    } finally {
      setRetrying(prev => ({ ...prev, [transcriptId]: false }));
    }
  };

  if (isLoading) return <div className="space-y-4 p-4">{[1,2,3].map(i => <Skeleton key={i} className="h-24 w-full" />)}</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Pipeline Health</h3>
          <p className="text-sm text-muted-foreground">Analysis pass success rates, timing, and failure diagnostics</p>
        </div>
        <Select value={String(daysBack)} onValueChange={v => setDaysBack(Number(v))}>
          <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="1">Last 24h</SelectItem>
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1"><Activity className="h-4 w-4" />Total Runs</div>
            <div className="text-2xl font-bold">{stats?.totalRuns || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1"><TrendingUp className="h-4 w-4" />Success Rate</div>
            <div className={`text-2xl font-bold ${(stats?.successRate || 0) >= 90 ? 'text-green-500' : (stats?.successRate || 0) >= 70 ? 'text-yellow-500' : 'text-destructive'}`}>
              {stats?.successRate || 0}%
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1"><Clock className="h-4 w-4" />Avg Duration</div>
            <div className="text-2xl font-bold">{((stats?.avgDurationMs || 0) / 1000).toFixed(1)}s</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1"><XCircle className="h-4 w-4" />Failed</div>
            <div className="text-2xl font-bold text-destructive">{stats?.failedRuns || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Failures by Pass */}
      {stats && Object.keys(stats.failuresByPass).length > 0 && (
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-sm">Failures by Pass</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-2">
              {Object.entries(stats.failuresByPass).sort(([,a],[,b]) => b - a).map(([pass, count]) => (
                <div key={pass} className="flex items-center justify-between text-sm">
                  <span className="font-mono">{pass}</span>
                  <Badge variant="destructive">{count}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Failures by Category */}
      {stats && Object.keys(stats.failuresByCategory).length > 0 && (
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-sm">Failure Categories</CardTitle></CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {Object.entries(stats.failuresByCategory).map(([cat, count]) => (
                <Badge key={cat} variant="outline" className="text-sm">
                  {cat}: {count}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Flagged Transcripts */}
      {flagged && flagged.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              Flagged Transcripts ({flagged.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
               {flagged.map(f => (
                 <div key={f.transcriptId} className="flex items-center justify-between text-sm border-b border-border pb-2">
                   <div>
                     <span className="font-mono text-xs">{f.transcriptId.substring(0, 8)}…</span>
                     <span className="ml-2 text-muted-foreground">{f.latestFailure.pass_name || f.latestFailure.pass_key}</span>
                   </div>
                   <div className="flex items-center gap-2">
                     <Badge variant="outline" className="text-xs">{f.latestFailure.error_category || 'unknown'}</Badge>
                      <Badge variant="destructive" className="text-xs">{f.failedPasses} failures</Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2 text-xs"
                        disabled={retrying[f.transcriptId]}
                        onClick={() => handleRetryTranscript(f.transcriptId)}
                        title={`Retry failed: ${f.failedPassKeys.join(', ')}`}
                      >
                        <RotateCcw className={cn('h-3 w-3 mr-1', retrying[f.transcriptId] && 'animate-spin')} />
                        Retry {f.failedPasses} stage{f.failedPasses > 1 ? 's' : ''}
                      </Button>
                   </div>
                 </div>
               ))}
            </div>
          </CardContent>
        </Card>
      )}

      {stats?.totalRuns === 0 && (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            <CheckCircle2 className="h-8 w-8 mx-auto mb-2 text-green-500" />
            <p>No analysis runs recorded in this period. Process a transcript to start collecting pipeline data.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

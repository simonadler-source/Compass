import { useMemo } from 'react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  MessageSquareQuote, 
  Calendar,
  FileText,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

interface ContactMeetingSnapshot {
  id: string;
  contact_id: string;
  transcript_id: string;
  meeting_date: string;
  meeting_type: string;
  sentiment: number | null;
  influence_level: number | null;
  champion_score: number | null;
  key_quotes: string[] | null;
  notes: string | null;
  concerns_raised: string[] | null;
  action_items: string[] | null;
  topics_discussed: string[] | null;
  meeting_title?: string | null;
}

interface ScoreHistoryPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contactName: string;
  metric: 'sentiment' | 'influence_level' | 'champion_score';
  snapshots: ContactMeetingSnapshot[];
  contactId: string;
  currentValue: number | null;
}

const METRIC_LABELS: Record<string, string> = {
  sentiment: 'Sentiment',
  influence_level: 'Influence',
  champion_score: 'Champion Score',
};

const METRIC_DESCRIPTIONS: Record<string, string> = {
  sentiment: 'How positively or negatively this stakeholder views the engagement',
  influence_level: 'The stakeholder\'s ability to impact decisions and outcomes',
  champion_score: 'Likelihood this stakeholder will actively advocate for your solution',
};

const MEETING_TYPE_LABELS: Record<string, { label: string; color: string }> = {
  discovery: { label: 'Discovery', color: 'bg-blue-100 text-blue-800' },
  demo: { label: 'Demo', color: 'bg-purple-100 text-purple-800' },
  technical: { label: 'Technical', color: 'bg-orange-100 text-orange-800' },
  workshop: { label: 'Workshop', color: 'bg-green-100 text-green-800' },
  executive: { label: 'Executive', color: 'bg-red-100 text-red-800' },
  commercial: { label: 'Commercial', color: 'bg-yellow-100 text-yellow-800' },
  negotiation: { label: 'Negotiation', color: 'bg-pink-100 text-pink-800' },
  default: { label: 'Meeting', color: 'bg-gray-100 text-gray-800' },
};

export function ScoreHistoryPanel({
  open,
  onOpenChange,
  contactName,
  metric,
  snapshots,
  contactId,
  currentValue,
}: ScoreHistoryPanelProps) {
  const { history, trend, stats } = useMemo(() => {
    const contactSnapshots = snapshots
      .filter(s => s.contact_id === contactId && s[metric] !== null)
      .sort((a, b) => new Date(b.meeting_date).getTime() - new Date(a.meeting_date).getTime());

    if (contactSnapshots.length === 0) {
      return { history: [], trend: 'unknown' as const, stats: null };
    }

    // Calculate trend
    let trend: 'improving' | 'stable' | 'declining' | 'unknown' = 'unknown';
    if (contactSnapshots.length >= 2) {
      const first = contactSnapshots[contactSnapshots.length - 1][metric] as number;
      const last = contactSnapshots[0][metric] as number;
      const change = last - first;
      trend = Math.abs(change) <= 5 ? 'stable' : change > 0 ? 'improving' : 'declining';
    }

    // Calculate stats
    const values = contactSnapshots.map(s => s[metric] as number);
    const stats = {
      min: Math.min(...values),
      max: Math.max(...values),
      avg: Math.round(values.reduce((a, b) => a + b, 0) / values.length),
      total: contactSnapshots.length,
      firstDate: contactSnapshots[contactSnapshots.length - 1].meeting_date,
      lastDate: contactSnapshots[0].meeting_date,
    };

    return { history: contactSnapshots, trend, stats };
  }, [snapshots, contactId, metric]);

  const TrendIcon = trend === 'improving' ? TrendingUp : trend === 'declining' ? TrendingDown : Minus;
  const trendColor = trend === 'improving' ? 'text-primary' : trend === 'declining' ? 'text-destructive' : 'text-muted-foreground';
  const trendLabel = trend === 'improving' ? 'Improving' : trend === 'declining' ? 'Declining' : 'Stable';

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            {METRIC_LABELS[metric]} History
          </SheetTitle>
          <SheetDescription>
            {contactName} • {METRIC_DESCRIPTIONS[metric]}
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Current Score Summary */}
          <div className="bg-muted/30 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-muted-foreground">Current Score</div>
                <div className="text-3xl font-bold">{currentValue ?? '—'}%</div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1.5 justify-end">
                  <TrendIcon className={cn("h-5 w-5", trendColor)} />
                  <span className={cn("font-medium", trendColor)}>{trendLabel}</span>
                </div>
                {stats && (
                  <div className="text-xs text-muted-foreground mt-1">
                    Range: {stats.min}% – {stats.max}% (avg {stats.avg}%)
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Stats bar */}
          {stats && (
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>{stats.total} meetings tracked</span>
              <span>
                {format(new Date(stats.firstDate), 'MMM d, yyyy')} – {format(new Date(stats.lastDate), 'MMM d, yyyy')}
              </span>
            </div>
          )}

          <Separator />

          {/* Timeline */}
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-4">
              {history.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  No historical data available
                </div>
              ) : (
                history.map((snapshot, index) => {
                  const prevValue = history[index + 1]?.[metric] as number | undefined;
                  const currentVal = snapshot[metric] as number;
                  const change = prevValue !== undefined ? currentVal - prevValue : null;
                  const meetingTypeInfo = MEETING_TYPE_LABELS[snapshot.meeting_type] || MEETING_TYPE_LABELS.default;

                  return (
                    <div key={snapshot.id} className="relative pl-6 pb-4">
                      {/* Timeline line */}
                      {index < history.length - 1 && (
                        <div className="absolute left-[9px] top-6 bottom-0 w-px bg-border" />
                      )}
                      
                      {/* Timeline dot */}
                      <div className={cn(
                        "absolute left-0 top-1.5 h-[18px] w-[18px] rounded-full border-2 flex items-center justify-center",
                        change !== null && change > 0 
                          ? "border-primary bg-primary/10" 
                          : change !== null && change < 0 
                            ? "border-destructive bg-destructive/10"
                            : "border-muted-foreground bg-muted"
                      )}>
                        {change !== null && change !== 0 && (
                          change > 0 
                            ? <TrendingUp className="h-2.5 w-2.5 text-primary" />
                            : <TrendingDown className="h-2.5 w-2.5 text-destructive" />
                        )}
                      </div>

                      {/* Content */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex flex-col gap-0.5">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                              <span className="text-sm font-medium">
                                {format(new Date(snapshot.meeting_date), 'MMM d, yyyy')}
                              </span>
                              <Badge variant="secondary" className={cn("text-xs", meetingTypeInfo.color)}>
                                {meetingTypeInfo.label}
                              </Badge>
                            </div>
                            {snapshot.meeting_title && (
                              <span className="text-xs text-muted-foreground ml-5 truncate max-w-[280px]" title={snapshot.meeting_title}>
                                {snapshot.meeting_title}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-lg font-bold">{currentVal}%</span>
                            {change !== null && change !== 0 && (
                              <span className={cn(
                                "text-xs font-medium",
                                change > 0 ? "text-primary" : "text-destructive"
                              )}>
                                ({change > 0 ? '+' : ''}{change})
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Notes/Reasoning */}
                        {snapshot.notes && (
                          <div className="bg-muted/40 rounded-md p-2.5 text-sm">
                            <div className="flex items-start gap-2">
                              <FileText className="h-3.5 w-3.5 mt-0.5 text-muted-foreground shrink-0" />
                              <p className="text-muted-foreground">{snapshot.notes}</p>
                            </div>
                          </div>
                        )}

                        {/* Key Quotes */}
                        {snapshot.key_quotes && snapshot.key_quotes.length > 0 && (
                          <div className="space-y-1">
                            {snapshot.key_quotes.slice(0, 2).map((quote, i) => (
                              <div key={i} className="flex items-start gap-2 text-sm">
                                <MessageSquareQuote className="h-3.5 w-3.5 mt-0.5 text-primary/60 shrink-0" />
                                <p className="italic text-muted-foreground">"{quote}"</p>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Concerns */}
                        {snapshot.concerns_raised && snapshot.concerns_raised.length > 0 && (
                          <div className="flex items-start gap-2 text-sm">
                            <AlertTriangle className="h-3.5 w-3.5 mt-0.5 text-amber-500 shrink-0" />
                            <p className="text-muted-foreground">{snapshot.concerns_raised[0]}</p>
                          </div>
                        )}

                        {/* Action Items */}
                        {snapshot.action_items && snapshot.action_items.length > 0 && (
                          <div className="flex items-start gap-2 text-sm">
                            <CheckCircle className="h-3.5 w-3.5 mt-0.5 text-green-500 shrink-0" />
                            <p className="text-muted-foreground">{snapshot.action_items[0]}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </ScrollArea>
        </div>
      </SheetContent>
    </Sheet>
  );
}

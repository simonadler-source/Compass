import { useMemo } from 'react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { TrendingUp, TrendingDown, Minus, MessageSquareQuote } from 'lucide-react';

interface ContactMeetingSnapshot {
  id: string;
  contact_id: string;
  transcript_id: string;
  meeting_date: string;
  meeting_type: string;
  sentiment: number | null;
  influence_level: number | null;
  champion_score: number | null;
  key_quotes: string[] | null;
  notes: string | null;
  concerns_raised: string[] | null;
  meeting_title?: string | null;
}

interface ScoreReasoningTooltipProps {
  children: React.ReactNode;
  value: number | null;
  label: string;
  metric: 'sentiment' | 'influence_level' | 'champion_score';
  snapshots: ContactMeetingSnapshot[];
  contactId: string;
  onClickDetails?: () => void;
}

function computeTrend(values: number[]): 'improving' | 'stable' | 'declining' | 'unknown' {
  if (values.length < 2) return 'unknown';
  const first = values[values.length - 1];
  const last = values[0];
  const change = last - first;
  // Use a relative threshold: stable if change is within ±5 points
  if (Math.abs(change) <= 5) return 'stable';
  return change > 0 ? 'improving' : 'declining';
}

export function ScoreReasoningTooltip({
  children,
  value,
  label,
  metric,
  snapshots,
  contactId,
  onClickDetails,
}: ScoreReasoningTooltipProps) {
  const { recentSnapshot, trend, historyPreview, latestReason } = useMemo(() => {
    const contactSnapshots = snapshots
      .filter(s => s.contact_id === contactId && s[metric] !== null)
      .sort((a, b) => new Date(b.meeting_date).getTime() - new Date(a.meeting_date).getTime());

    if (contactSnapshots.length === 0) {
      return { recentSnapshot: null, trend: 'unknown', historyPreview: [], latestReason: null };
    }

    const recentSnapshot = contactSnapshots[0];
    const historyPreview = contactSnapshots.slice(0, 5);

    const trend = computeTrend(contactSnapshots.map(s => s[metric] as number));

    // Get reason from notes or key_quotes
    let latestReason: string | null = null;
    if (recentSnapshot.notes) {
      latestReason = recentSnapshot.notes;
    } else if (recentSnapshot.key_quotes && recentSnapshot.key_quotes.length > 0) {
      latestReason = `"${recentSnapshot.key_quotes[0]}"`;
    } else if (recentSnapshot.concerns_raised && recentSnapshot.concerns_raised.length > 0) {
      latestReason = `Concern: ${recentSnapshot.concerns_raised[0]}`;
    }

    return { recentSnapshot, trend, historyPreview, latestReason };
  }, [snapshots, contactId, metric]);

  const TrendIcon = trend === 'improving' ? TrendingUp : trend === 'declining' ? TrendingDown : Minus;
  const trendColor = trend === 'improving' ? 'text-primary' : trend === 'declining' ? 'text-destructive' : 'text-muted-foreground';

  if (!recentSnapshot) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>{children}</TooltipTrigger>
          <TooltipContent side="top" className="max-w-xs">
            <p className="text-xs text-muted-foreground">No assessment data available yet</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>{children}</TooltipTrigger>
        <TooltipContent side="top" className="max-w-sm p-3">
          <div className="space-y-2">
            {/* Header with current score and trend */}
            <div className="flex items-center justify-between gap-4">
              <div className="font-medium">{label}</div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg font-semibold">{value}%</span>
                <TrendIcon className={cn("h-4 w-4", trendColor)} />
              </div>
            </div>

            {/* Latest reason/evidence */}
            {latestReason && (
              <div className="bg-muted/50 rounded-md p-2 text-xs">
                <div className="flex items-start gap-1.5">
                  <MessageSquareQuote className="h-3 w-3 mt-0.5 text-muted-foreground shrink-0" />
                  <p className="line-clamp-2 text-muted-foreground italic">
                    {latestReason}
                  </p>
                </div>
              </div>
            )}

            {/* Recent history preview with meeting names */}
            {historyPreview.length > 1 && (
              <div className="space-y-1">
                <div className="text-xs text-muted-foreground font-medium">Recent History</div>
                <div className="space-y-1">
                  {historyPreview.map((snapshot) => (
                    <div key={snapshot.id} className="flex items-center justify-between gap-3 text-xs">
                      <div className="flex flex-col min-w-0 flex-1">
                        <span className="text-muted-foreground">
                          {format(new Date(snapshot.meeting_date), 'MMM d')}
                        </span>
                        {snapshot.meeting_title && (
                          <span className="text-muted-foreground/70 truncate text-[10px] leading-tight" title={snapshot.meeting_title}>
                            {snapshot.meeting_title}
                          </span>
                        )}
                      </div>
                      <span className="font-medium shrink-0">{snapshot[metric]}%</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Click for more hint */}
            {onClickDetails && (
              <div className="text-xs text-muted-foreground text-center pt-1 border-t border-border/50">
                Click for full history
              </div>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
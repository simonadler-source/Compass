import { useMemo, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { ChevronDown, ChevronRight, Crown, DollarSign, Target, AlertTriangle, User, Users, MessageSquare, UserCircle } from 'lucide-react';

interface Contact {
  id: string;
  name: string;
  role: string | null;
  email: string | null;
  influence_level: number | null;
  sentiment: number | null;
  champion_score: number | null;
  stakeholder_type: string | null;
}

interface StakeholderOrgChartProps {
  contacts: Contact[];
  onContactClick?: (contact: Contact) => void;
}

const STAKEHOLDER_TYPE_CONFIG: Record<string, { icon: typeof Crown; color: string; priority: number }> = {
  economic_buyer: { icon: DollarSign, color: 'text-green-500', priority: 1 },
  champion: { icon: Crown, color: 'text-yellow-500', priority: 2 },
  decision_maker: { icon: Target, color: 'text-blue-500', priority: 3 },
  technical_buyer: { icon: User, color: 'text-purple-500', priority: 4 },
  coach: { icon: MessageSquare, color: 'text-cyan-500', priority: 5 },
  influencer: { icon: Users, color: 'text-indigo-500', priority: 6 },
  end_user: { icon: UserCircle, color: 'text-gray-500', priority: 7 },
  blocker: { icon: AlertTriangle, color: 'text-red-500', priority: 8 },
  unknown: { icon: User, color: 'text-muted-foreground', priority: 9 },
};

// Group contacts by influence tier (like org levels)
interface InfluenceTier {
  level: 'executive' | 'senior' | 'mid' | 'individual';
  label: string;
  minInfluence: number;
  contacts: Contact[];
}

export function StakeholderOrgChart({ contacts, onContactClick }: StakeholderOrgChartProps) {
  const [expandedTiers, setExpandedTiers] = useState<Set<string>>(new Set(['executive', 'senior', 'mid', 'individual']));

  // Organize contacts into influence tiers
  const tiers = useMemo((): InfluenceTier[] => {
    const tierDefs: Array<Omit<InfluenceTier, 'contacts'>> = [
      { level: 'executive', label: 'Executive (High Influence)', minInfluence: 75 },
      { level: 'senior', label: 'Senior (Medium-High Influence)', minInfluence: 50 },
      { level: 'mid', label: 'Mid-Level (Medium Influence)', minInfluence: 25 },
      { level: 'individual', label: 'Individual Contributors', minInfluence: 0 },
    ];

    return tierDefs.map(def => {
      const tierContacts = contacts
        .filter(c => {
          const influence = c.influence_level ?? 0;
          if (def.level === 'executive') return influence >= 75;
          if (def.level === 'senior') return influence >= 50 && influence < 75;
          if (def.level === 'mid') return influence >= 25 && influence < 50;
          return influence < 25;
        })
        .sort((a, b) => {
          // Sort by stakeholder type priority, then by influence
          const typeA = STAKEHOLDER_TYPE_CONFIG[a.stakeholder_type || 'unknown'];
          const typeB = STAKEHOLDER_TYPE_CONFIG[b.stakeholder_type || 'unknown'];
          if (typeA.priority !== typeB.priority) return typeA.priority - typeB.priority;
          return (b.influence_level ?? 0) - (a.influence_level ?? 0);
        });

      return { ...def, contacts: tierContacts };
    }).filter(tier => tier.contacts.length > 0);
  }, [contacts]);

  const toggleTier = (level: string) => {
    setExpandedTiers(prev => {
      const next = new Set(prev);
      if (next.has(level)) {
        next.delete(level);
      } else {
        next.add(level);
      }
      return next;
    });
  };

  const getSentimentColor = (sentiment: number | null) => {
    if (sentiment === null) return 'bg-muted';
    if (sentiment >= 60) return 'bg-green-500/20 border-green-500/30';
    if (sentiment >= 40) return 'bg-yellow-500/20 border-yellow-500/30';
    return 'bg-red-500/20 border-red-500/30';
  };

  if (contacts.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground border-2 border-dashed border-border rounded-lg">
        <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
        <p>No stakeholders to display in chart</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {tiers.map((tier, tierIndex) => {
        const isExpanded = expandedTiers.has(tier.level);
        
        return (
          <div key={tier.level} className="relative">
            {/* Tier header */}
            <div 
              className={cn(
                "flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors",
                "bg-muted/50 hover:bg-muted"
              )}
              onClick={() => toggleTier(tier.level)}
            >
              <Button variant="ghost" size="sm" className="w-6 h-6 p-0">
                {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              </Button>
              <span className="font-medium text-sm">{tier.label}</span>
              <Badge variant="secondary" className="ml-auto">
                {tier.contacts.length}
              </Badge>
            </div>

            {/* Tier contacts */}
            {isExpanded && (
              <div className={cn(
                "mt-2 ml-4 pl-4 border-l-2 border-border",
                tierIndex === 0 && "border-primary/50"
              )}>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {tier.contacts.map((contact) => {
                    const typeConfig = STAKEHOLDER_TYPE_CONFIG[contact.stakeholder_type || 'unknown'];
                    const TypeIcon = typeConfig.icon;
                    
                    return (
                      <Card 
                        key={contact.id} 
                        className={cn(
                          "p-3 cursor-pointer transition-all hover:shadow-md border",
                          getSentimentColor(contact.sentiment)
                        )}
                        onClick={() => onContactClick?.(contact)}
                      >
                        <div className="flex items-start gap-2">
                          <div className={cn(
                            "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                            "bg-background/80"
                          )}>
                            <TypeIcon className={cn("w-4 h-4", typeConfig.color)} />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{contact.name}</p>
                            {contact.role && (
                              <p className="text-xs text-muted-foreground truncate">{contact.role}</p>
                            )}
                            
                            <div className="flex items-center gap-2 mt-1 flex-wrap">
                              {contact.champion_score != null && contact.champion_score > 40 && (
                                <Badge variant="outline" className="text-[10px] px-1 py-0 h-4 bg-yellow-500/10 text-yellow-600 border-yellow-500/30">
                                  <Crown className="w-2.5 h-2.5 mr-0.5" />
                                  {contact.champion_score}%
                                </Badge>
                              )}
                              {contact.influence_level != null && (
                                <span className="text-[10px] text-muted-foreground">
                                  Influence: {contact.influence_level}%
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

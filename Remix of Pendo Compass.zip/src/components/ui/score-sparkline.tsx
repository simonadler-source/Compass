import { useMemo } from 'react';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { format } from 'date-fns';

interface DataPoint {
  date: string;
  value: number;
}

interface ScoreSparklineProps {
  data: DataPoint[];
  height?: number;
  width?: number;
  colorStart?: string;
  colorEnd?: string;
  className?: string;
  showTooltip?: boolean;
  label?: string;
}

export function ScoreSparkline({
  data,
  height = 24,
  width = 60,
  colorStart = 'hsl(var(--muted-foreground))',
  colorEnd = 'hsl(var(--primary))',
  className,
  showTooltip = true,
  label,
}: ScoreSparklineProps) {
  const sortedData = useMemo(() => {
    return [...data].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [data]);

  const { path, trend, min, max, currentValue, firstValue } = useMemo(() => {
    if (sortedData.length === 0) {
      return { path: '', trend: 'stable' as const, min: 0, max: 100, currentValue: null, firstValue: null };
    }

    const values = sortedData.map(d => d.value);
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = max - min || 1;
    
    const padding = 2;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    
    const points = sortedData.map((d, i) => {
      const x = padding + (i / Math.max(sortedData.length - 1, 1)) * chartWidth;
      const y = padding + chartHeight - ((d.value - min) / range) * chartHeight;
      return { x, y };
    });

    const pathD = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
    
    // Calculate trend — stable if change is within ±5 points
    const first = values[0];
    const last = values[values.length - 1];
    const change = last - first;
    const trend = Math.abs(change) <= 5 ? 'stable' : change > 0 ? 'improving' : 'declining';
    
    return { 
      path: pathD, 
      trend, 
      min, 
      max, 
      currentValue: last,
      firstValue: first,
    };
  }, [sortedData, width, height]);

  if (sortedData.length < 2) {
    return (
      <div 
        className={cn("flex items-center justify-center text-xs text-muted-foreground", className)}
        style={{ width, height }}
      >
        —
      </div>
    );
  }

  const strokeColor = trend === 'improving' 
    ? 'hsl(var(--primary))' 
    : trend === 'declining' 
      ? 'hsl(var(--destructive))' 
      : 'hsl(var(--muted-foreground))';

  const sparkline = (
    <svg 
      width={width} 
      height={height} 
      className={cn("inline-block", className)}
      viewBox={`0 0 ${width} ${height}`}
    >
      <path
        d={path}
        fill="none"
        stroke={strokeColor}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* End point dot */}
      {sortedData.length > 0 && (
        <circle
          cx={width - 2}
          cy={2 + (height - 4) - ((currentValue! - min) / (max - min || 1)) * (height - 4)}
          r={2}
          fill={strokeColor}
        />
      )}
    </svg>
  );

  if (!showTooltip) return sparkline;

  const change = (currentValue ?? 0) - (firstValue ?? 0);
  const changeLabel = change > 0 ? `+${change}` : String(change);

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          {sparkline}
        </TooltipTrigger>
        <TooltipContent side="top" className="text-xs">
          <div className="space-y-1">
            {label && <div className="font-medium">{label}</div>}
            <div className="flex items-center gap-2">
              <span>{firstValue}%</span>
              <span>→</span>
              <span className={cn(
                "font-medium",
                trend === 'improving' && "text-primary",
                trend === 'declining' && "text-destructive"
              )}>
                {currentValue}%
              </span>
              <span className={cn(
                "text-xs",
                change > 0 && "text-primary",
                change < 0 && "text-destructive"
              )}>
                ({changeLabel})
              </span>
            </div>
            <div className="text-muted-foreground">
              {sortedData.length} meetings • {format(new Date(sortedData[0].date), 'MMM d')} - {format(new Date(sortedData[sortedData.length - 1].date), 'MMM d')}
            </div>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface MultiScoreSparklineProps {
  influence: DataPoint[];
  sentiment: DataPoint[];
  champion: DataPoint[];
  height?: number;
  className?: string;
}

export function MultiScoreSparkline({
  influence,
  sentiment,
  champion,
  height = 24,
  className,
}: MultiScoreSparklineProps) {
  const hasData = influence.length >= 2 || sentiment.length >= 2 || champion.length >= 2;
  
  if (!hasData) {
    return (
      <div className={cn("flex items-center gap-1 text-xs text-muted-foreground", className)}>
        <span>No trend data</span>
      </div>
    );
  }

  return (
    <div className={cn("flex items-center gap-2", className)}>
      {influence.length >= 2 && (
        <ScoreSparkline 
          data={influence} 
          height={height} 
          width={48} 
          label="Influence"
        />
      )}
      {sentiment.length >= 2 && (
        <ScoreSparkline 
          data={sentiment} 
          height={height} 
          width={48}
          label="Sentiment"
        />
      )}
      {champion.length >= 2 && (
        <ScoreSparkline 
          data={champion} 
          height={height} 
          width={48}
          label="Champion"
        />
      )}
    </div>
  );
}

import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { Check, X, AlertCircle, Camera, Layers, Map as MapIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TechnologyPalette } from '@/components/canvas/TechnologyPalette';
import html2canvas from 'html2canvas';
import { FunctionalAreaCanvas, CanvasTechNode, CanvasAreaNode, CanvasConnection } from '@/components/canvas/FunctionalAreaCanvas';
import { ValueMapDiagram } from './ValueMapDiagram';
import { 
  useCreateAccountTechnology, 
  useDeleteAccountTechnology,
  useUpdateAccountTechnology,
  DbAccountTechnology 
} from '@/hooks/useAccounts';
import { useFunctionalAreas, useCreateFunctionalArea, useUpdateFunctionalArea, useDeleteFunctionalArea, TechnologyRepoItem } from '@/hooks/useTechnologyRepository';
import { useLayers } from '@/hooks/useLayers';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface AccountArchitectureCanvasProps {
  accountId: string;
  technologies?: DbAccountTechnology[];
  opportunityId?: string;
}

export function AccountArchitectureCanvas({ accountId, technologies = [], opportunityId }: AccountArchitectureCanvasProps) {
  const [activeView, setActiveView] = useState<'architecture' | 'value-map'>('architecture');
  const createTechnology = useCreateAccountTechnology();
  const deleteTechnology = useDeleteAccountTechnology();
  const updateTechnology = useUpdateAccountTechnology();
  const { data: functionalAreas } = useFunctionalAreas();
  const { data: layers } = useLayers();
  const createArea = useCreateFunctionalArea();
  const updateArea = useUpdateFunctionalArea();
  const deleteArea = useDeleteFunctionalArea();
  
  // We don't persist per-chip or per-area positions; we only care that technologies belong to a functional area.
  // Connections can still be persisted locally.
  const [connections, setConnections] = useState<CanvasConnection[]>([]);
  const [showTechDialog, setShowTechDialog] = useState(false);
  const [pendingTech, setPendingTech] = useState<{ tech: TechnologyRepoItem; x: number; y: number; areaId: string } | null>(null);
  const [ownerName, setOwnerName] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('');
  const [relationshipStatus, setRelationshipStatus] = useState('neutral');
  const canvasRef = useRef<HTMLDivElement>(null);

  const handleSaveAsImage = useCallback(async () => {
    if (!canvasRef.current) return;

    try {
      const canvas = await html2canvas(canvasRef.current, {
        backgroundColor: '#ffffff',
        scale: 2,
      });

      const link = document.createElement('a');
      link.download = `account_${accountId}_architecture.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();

      toast.success('Architecture image saved');
    } catch (error) {
      console.error('Failed to save image:', error);
      toast.error('Failed to save image');
    }
  }, [accountId]);

  const connectionsKey = `account-${accountId}-connections`;

  // Load/save connections only
  useEffect(() => {
    const savedConnections = localStorage.getItem(connectionsKey);
    if (savedConnections) {
      try {
        setConnections(JSON.parse(savedConnections));
      } catch {
        // ignore
      }
    }
  }, [connectionsKey]);

  useEffect(() => {
    localStorage.setItem(connectionsKey, JSON.stringify(connections));
  }, [connections, connectionsKey]);

  // Filter pending and active technologies
  const pendingTechnologies = technologies.filter(t => (t as any).status === 'pending' || (t as any).status === 'unconfirmed');
  const activeTechnologies = technologies.filter(t => (t as any).status !== 'rejected');

  // Count technologies per functional area (for sizing)
  const techCountByArea = useMemo(() => {
    const counts: Record<string, number> = {};
    if (!functionalAreas) return counts;
    
    functionalAreas.forEach(area => {
      counts[area.name] = activeTechnologies.filter(t => t.category === area.name).length;
    });
    return counts;
  }, [activeTechnologies, functionalAreas]);

  // Calculate dynamic layer heights based on functional areas with multi-row support
  const dynamicLayerHeights = useMemo(() => {
    const heights: Record<string, number> = {};

    const MIN_LAYER_HEIGHT = 180;
    const TOP_OFFSET = 25;
    const BOTTOM_PADDING = 30;
    const ROW_GAP = 20;
    const CANVAS_WIDTH = 1400;
    const LEFT_MARGIN = 170;
    const GAP_BETWEEN_AREAS = 15;

    const TECH_CHIP_HEIGHT = 36;
    const HEADER_HEIGHT = 28;
    const GAP = 10;
    const AREA_PADDING = 12;
    const CHAR_WIDTH = 7;
    const MIN_CHIP_WIDTH = 100;
    const MAX_CHIP_WIDTH = 160;
    const MAX_ROWS = 4;

    // Initialize with default heights from layers data
    if (layers) {
      layers.forEach((layer) => {
        heights[layer.name] = Math.max(layer.height, MIN_LAYER_HEIGHT);
      });
    }

    if (!functionalAreas) return heights;

    // Group areas by layer
    const areasByLayer: Record<string, typeof functionalAreas> = {};
    functionalAreas.forEach(area => {
      if (!areasByLayer[area.layer]) areasByLayer[area.layer] = [];
      areasByLayer[area.layer].push(area);
    });

    // Sort areas (same logic as areaNodes to ensure consistency)
    Object.values(areasByLayer).forEach(layerAreas => {
      layerAreas.sort((a, b) => {
        const orderA = a.sort_order ?? 999;
        const orderB = b.sort_order ?? 999;
        if (orderA !== orderB) return orderA - orderB;
        
        const countA = activeTechnologies.filter(t => t.category === a.name).length;
        const countB = activeTechnologies.filter(t => t.category === b.name).length;
        return countB - countA;
      });
    });

    // Calculate required height per layer considering multi-row layout
    Object.entries(areasByLayer).forEach(([layerName, layerAreas]) => {
      let xOffset = LEFT_MARGIN;
      let currentRowY = 0;
      let maxRowHeight = 100;

      layerAreas.forEach((area) => {
        const areaTechs = activeTechnologies.filter((t) => t.category === area.name);
        const techCount = areaTechs.length;

        const defaultWidth = area.default_width ?? 200;
        const defaultHeight = area.default_height ?? 100;

        let areaWidth = defaultWidth;
        let areaHeight = defaultHeight;

        if (techCount > 0) {
          const maxChipWidth = Math.max(
            MIN_CHIP_WIDTH,
            ...areaTechs.map((t) =>
              Math.max(MIN_CHIP_WIDTH, Math.min(MAX_CHIP_WIDTH, t.name.length * CHAR_WIDTH + 24))
            )
          );

          // Calculate columns to keep rows within MAX_ROWS
          let cols = 1;
          let rows = techCount;
          while (rows > MAX_ROWS && cols < techCount) {
            cols++;
            rows = Math.ceil(techCount / cols);
          }

          areaWidth = Math.max(defaultWidth, AREA_PADDING * 2 + cols * maxChipWidth + (cols - 1) * GAP);
          const chipsHeight = rows * TECH_CHIP_HEIGHT + (rows - 1) * GAP;
          areaHeight = Math.max(defaultHeight, HEADER_HEIGHT + AREA_PADDING + chipsHeight + AREA_PADDING);
        }

        // Check if we need to wrap to next row
        if (xOffset + areaWidth > CANVAS_WIDTH && xOffset > LEFT_MARGIN) {
          currentRowY += maxRowHeight + ROW_GAP;
          xOffset = LEFT_MARGIN;
          maxRowHeight = areaHeight;
        } else {
          maxRowHeight = Math.max(maxRowHeight, areaHeight);
        }

        xOffset += areaWidth + GAP_BETWEEN_AREAS;
      });

      const requiredLayerHeight = TOP_OFFSET + currentRowY + maxRowHeight + BOTTOM_PADDING;
      heights[layerName] = Math.max(
        heights[layerName] ?? MIN_LAYER_HEIGHT,
        requiredLayerHeight,
        MIN_LAYER_HEIGHT
      );
    });

    return heights;
  }, [layers, functionalAreas, activeTechnologies]);

  // Calculate layer Y offsets dynamically from calculated heights (matching reference architecture)
  const layerYOffsets = useMemo(() => {
    const offsets: Record<string, number> = {};
    if (layers && layers.length > 0) {
      let currentY = 0;
      layers.forEach(layer => {
        offsets[layer.name] = currentY;
        currentY += dynamicLayerHeights[layer.name] || layer.height;
      });
    } else {
      // Fallback defaults
      offsets['host'] = 0;
      offsets['build'] = 160;
      offsets['adopt'] = 320;
      offsets['growth'] = 480;
      offsets['operations'] = 640;
    }
    return offsets;
  }, [layers, dynamicLayerHeights]);

  // Calculate total canvas height
  const totalCanvasHeight = useMemo(() => {
    if (!layers) return 850;
    return layers.reduce((sum, layer) => sum + (dynamicLayerHeights[layer.name] || layer.height), 0);
  }, [layers, dynamicLayerHeights]);

  // Calculate dynamic area dimensions - prioritize width over height
  const getAreaDimensions = (areaName: string, defaultWidth: number, defaultHeight: number) => {
    const areaTechs = activeTechnologies.filter(t => t.category === areaName);
    const techCount = areaTechs.length;
    
    const TECH_CHIP_HEIGHT = 36;
    const PADDING = 12;
    const HEADER_HEIGHT = 28;
    const GAP = 10;
    const MIN_CHIP_WIDTH = 100;
    const MAX_CHIP_WIDTH = 160;
    const CHAR_WIDTH = 7;
    const MAX_ROWS = 4; // Limit vertical growth - force more columns instead
    
    if (techCount === 0) {
      return { width: defaultWidth, height: defaultHeight };
    }
    
    // Calculate width needed for each tech based on its name
    const techWidths = areaTechs.map(tech => {
      const textWidth = tech.name.length * CHAR_WIDTH + 24;
      return Math.max(MIN_CHIP_WIDTH, Math.min(MAX_CHIP_WIDTH, textWidth));
    });
    
    // Find max chip width needed for this area
    const maxChipWidth = Math.max(...techWidths);
    
    // Calculate how many rows we'd need with minimum columns
    // Then increase columns to stay within MAX_ROWS
    let cols = 1;
    let rows = techCount;
    
    // Keep increasing columns until we're within MAX_ROWS or can't fit more
    while (rows > MAX_ROWS && cols < techCount) {
      cols++;
      rows = Math.ceil(techCount / cols);
    }
    
    // Calculate required width and height based on optimal columns
    // Add extra padding to ensure chips don't overflow
    const width = Math.max(defaultWidth, PADDING * 2 + cols * maxChipWidth + (cols - 1) * GAP + 10);
    const height = Math.max(defaultHeight, HEADER_HEIGHT + PADDING + rows * TECH_CHIP_HEIGHT + (rows - 1) * GAP + PADDING + 5);
    
    return { width, height };
  };

  // Calculate coverage percentage - use category list for stable dependency
  const technologyCategories = technologies.map(t => t.category).join(',');
  
  const coveragePercent = useMemo(() => {
    if (!functionalAreas || functionalAreas.length === 0) return 0;
    
    const coveredAreas = new Set(technologies.map(t => t.category));
    const totalAreas = new Set(functionalAreas.map(a => a.name));
    
    let covered = 0;
    totalAreas.forEach(area => {
      if (coveredAreas.has(area)) covered++;
    });
    
    return Math.round((covered / totalAreas.size) * 100);
  }, [technologies, functionalAreas, technologyCategories]);

  // Get priority for a functional area based on its technologies
  const getAreaPriority = (areaName: string): string | null => {
    const areaTechs = technologies.filter(t => t.category === areaName);
    if (areaTechs.length === 0) return null;
    
    // Return the highest priority found (critical > high > medium > low)
    const priorities = ['critical', 'high', 'medium', 'low'];
    for (const p of priorities) {
      if (areaTechs.some(t => (t as any).priority === p)) {
        return p;
      }
    }
    return null;
  };

  // Convert functional areas to canvas nodes with smart grid layout
  const areaNodes: CanvasAreaNode[] = useMemo(() => {
    if (!functionalAreas) return [];
    
    const CANVAS_WIDTH = 1400; // Maximum usable width for areas
    const LEFT_MARGIN = 170;
    const GAP_BETWEEN_AREAS = 15;
    const ROW_GAP = 20;
    const TOP_OFFSET = 25;
    
    const areasByLayer: Record<string, typeof functionalAreas> = {};
    functionalAreas.forEach(area => {
      if (!areasByLayer[area.layer]) areasByLayer[area.layer] = [];
      areasByLayer[area.layer].push(area);
    });

    // Sort areas within each layer: first by sort_order, then by tech count (most populated first)
    Object.values(areasByLayer).forEach(layerAreas => {
      layerAreas.sort((a, b) => {
        // Primary sort by sort_order if available
        const orderA = a.sort_order ?? 999;
        const orderB = b.sort_order ?? 999;
        if (orderA !== orderB) return orderA - orderB;
        
        // Secondary sort by tech count (descending)
        const countA = techCountByArea[a.name] || 0;
        const countB = techCountByArea[b.name] || 0;
        return countB - countA;
      });
    });

    const result: CanvasAreaNode[] = [];

    // Position areas with wrapping within each layer
    Object.entries(areasByLayer).forEach(([layerName, layerAreas]) => {
      let xOffset = LEFT_MARGIN;
      let currentRowY = 0;
      let maxRowHeight = 100;
      const baseY = layerYOffsets[layerName] ?? 0;
      
      layerAreas.forEach((area) => {
        const { width, height } = getAreaDimensions(
          area.name,
          area.default_width ?? 200,
          area.default_height ?? 100
        );
        const priority = getAreaPriority(area.name);

        // Check if we need to wrap to next row
        if (xOffset + width > CANVAS_WIDTH && xOffset > LEFT_MARGIN) {
          currentRowY += maxRowHeight + ROW_GAP;
          xOffset = LEFT_MARGIN;
          maxRowHeight = height;
        } else {
          maxRowHeight = Math.max(maxRowHeight, height);
        }

        result.push({
          id: area.id,
          name: area.name,
          layer: area.layer,
          x: xOffset,
          y: baseY + TOP_OFFSET + currentRowY,
          width,
          height,
          color: area.color ?? '#fef9c3',
          priority: priority as 'critical' | 'high' | 'medium' | 'low' | undefined,
        });

        xOffset += width + GAP_BETWEEN_AREAS;
      });
    });
    
    return result;
  }, [functionalAreas, layerYOffsets, techCountByArea]);

  // Convert technologies to canvas tech nodes - positioned within their areas
  const techNodes: CanvasTechNode[] = useMemo(() => {
    const TECH_CHIP_HEIGHT = 36;
    const PADDING = 12;
    const HEADER_HEIGHT = 28;
    const GAP = 10;
    const MIN_CHIP_WIDTH = 100;
    const MAX_CHIP_WIDTH = 160;
    const CHAR_WIDTH = 7;
    const MAX_ROWS = 4;
    
    // Group techs by their functional area
    const techsByArea: Record<string, typeof activeTechnologies> = {};
    activeTechnologies.forEach(tech => {
      if (!techsByArea[tech.category]) techsByArea[tech.category] = [];
      techsByArea[tech.category].push(tech);
    });
    
    // Calculate chip width and columns per area
    const areaLayout: Record<string, { chipWidth: number; cols: number }> = {};
    Object.entries(techsByArea).forEach(([areaName, techs]) => {
      const maxTextWidth = Math.max(...techs.map(t => t.name.length * CHAR_WIDTH + 24));
      const chipWidth = Math.max(MIN_CHIP_WIDTH, Math.min(MAX_CHIP_WIDTH, maxTextWidth));
      
      // Calculate columns to keep rows within MAX_ROWS
      let cols = 1;
      let rows = techs.length;
      while (rows > MAX_ROWS && cols < techs.length) {
        cols++;
        rows = Math.ceil(techs.length / cols);
      }
      
      areaLayout[areaName] = { chipWidth, cols };
    });
    
    return activeTechnologies.map((tech) => {
      // Find the area this tech belongs to
      const area = areaNodes.find(a => a.name === tech.category);
      if (!area) {
        return {
          id: tech.id,
          techId: (tech as any).repository_tech_id || tech.id,
          name: tech.name,
          functionalArea: tech.category,
          layer: tech.layer,
          x: 200,
          y: (layerYOffsets[tech.layer] ?? 0) + 60,
          isCompetitor: (tech as any).relationship_status === 'competitor',
          relationshipStatus: (tech as any).relationship_status || 'neutral',
          ownerName: (tech as any).owner_name,
          status: (tech as any).status || 'confirmed',
          priority: (tech as any).priority,
        };
      }
      
      // Calculate position within area using grid layout
      const techsInArea = techsByArea[tech.category] || [];
      const indexInArea = techsInArea.findIndex(t => t.id === tech.id);
      const layout = areaLayout[tech.category] || { chipWidth: MIN_CHIP_WIDTH, cols: 1 };
      const { chipWidth, cols } = layout;
      
      const col = indexInArea % cols;
      const row = Math.floor(indexInArea / cols);
      
      const x = area.x + PADDING + col * (chipWidth + GAP);
      const y = area.y + HEADER_HEIGHT + row * (TECH_CHIP_HEIGHT + GAP);
      
      return {
        id: tech.id,
        techId: (tech as any).repository_tech_id || tech.id,
        name: tech.name,
        functionalArea: tech.category,
        layer: tech.layer,
        x,
        y,
        isCompetitor: (tech as any).relationship_status === 'competitor',
        relationshipStatus: (tech as any).relationship_status || 'neutral',
        ownerName: (tech as any).owner_name,
        status: (tech as any).status || 'confirmed',
        priority: (tech as any).priority,
      };
    });
  }, [activeTechnologies, areaNodes, layerYOffsets]);

  const handleAreasChange = (_updated: CanvasAreaNode[]) => {
    // No-op: we don't persist functional area positioning/sizing.
  };

  const handleTechsChange = (updated: CanvasTechNode[]) => {
    // Only persist containment updates (moving a tech into a different functional area)
    const prevById = new Map(techNodes.map(t => [t.id, t] as const));
    updated.forEach((next) => {
      const prev = prevById.get(next.id);
      if (!prev) return;

      const areaChanged = prev.functionalArea !== next.functionalArea;
      const layerChanged = prev.layer !== next.layer;
      if (!areaChanged && !layerChanged) return;

      updateTechnology.mutate({
        id: next.id,
        accountId,
        category: next.functionalArea,
        layer: next.layer,
      } as any);
    });
  };

  const handleDropTechnology = (tech: TechnologyRepoItem, areaId: string, x: number, y: number) => {
    setPendingTech({ tech, areaId, x, y });
    setRelationshipStatus(tech.is_competitor ? 'competitor' : 'neutral');
    setShowTechDialog(true);
  };

  const handleAddTechnology = async () => {
    if (!pendingTech) return;

    try {
      const targetArea = functionalAreas?.find(a => a.id === pendingTech.areaId);
      const category = targetArea?.name ?? pendingTech.tech.functional_area;
      const layer = targetArea?.layer ?? pendingTech.tech.layer;

      const created = await createTechnology.mutateAsync({
        account_id: accountId,
        name: pendingTech.tech.name,
        layer,
        category,
        notes: pendingTech.tech.description || null,
        owner_name: ownerName || null,
        owner_email: ownerEmail || null,
        relationship_status: relationshipStatus,
        repository_tech_id: pendingTech.tech.id,
      } as any);

      // Don't save position - let the grid layout auto-position the tech
      // The techNodes useMemo will calculate the correct position within the area

      toast.success(`Added ${pendingTech.tech.name} to account`);
    } catch (error) {
      console.error('Failed to add technology:', error);
    } finally {
      setPendingTech(null);
      setOwnerName('');
      setOwnerEmail('');
      setRelationshipStatus('neutral');
      setShowTechDialog(false);
    }
  };

  const handleRemoveTechnology = async (techNodeId: string) => {
    try {
      await deleteTechnology.mutateAsync({ id: techNodeId, accountId });
      toast.success('Technology removed');
    } catch (error) {
      console.error('Failed to remove technology:', error);
    }
  };

  const handleConfirmTechnology = async (techId: string) => {
    try {
      await updateTechnology.mutateAsync({ id: techId, accountId, status: 'confirmed' } as any);
      toast.success('Technology confirmed');
    } catch (error) {
      console.error('Failed to confirm technology:', error);
    }
  };

  const handleRejectTechnology = async (techId: string) => {
    try {
      await deleteTechnology.mutateAsync({ id: techId, accountId });
      toast.success('Technology removed');
    } catch (error) {
      console.error('Failed to reject technology:', error);
    }
  };

  const handleConfirmAll = async () => {
    try {
      for (const tech of pendingTechnologies) {
        await updateTechnology.mutateAsync({ id: tech.id, accountId, status: 'confirmed' } as any);
      }
      toast.success(`Confirmed ${pendingTechnologies.length} technologies`);
    } catch (error) {
      console.error('Failed to confirm technologies:', error);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-200px)]">
      {/* View Tabs */}
      <div className="flex items-center gap-4 px-4 py-2 border-b bg-background">
        <Tabs value={activeView} onValueChange={(v) => setActiveView(v as 'architecture' | 'value-map')}>
          <TabsList>
            <TabsTrigger value="architecture" className="gap-2">
              <Layers className="w-4 h-4" />
              Architecture
            </TabsTrigger>
            <TabsTrigger value="value-map" className="gap-2">
              <MapIcon className="w-4 h-4" />
              Value Map
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {activeView === 'value-map' ? (
        <div className="flex-1 overflow-hidden p-4">
          <ValueMapDiagram accountId={accountId} opportunityId={opportunityId} />
        </div>
      ) : (
        <div className="flex flex-1 overflow-hidden">
          {/* Left Palette */}
          <div className="w-72 flex-shrink-0">
            <TechnologyPalette 
              onDragStart={() => {}} 
            />
          </div>

          {/* Main Content */}
          <div className="flex-1 flex flex-col p-4 space-y-4 overflow-auto">
            {/* Coverage Bar */}
            <div className="bg-card rounded-xl p-4 border border-border">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className="font-semibold text-foreground">Knowledge Coverage</h3>
                  <p className="text-sm text-muted-foreground">
                    Functional areas with mapped technologies
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-3xl font-bold text-primary">{coveragePercent}%</span>
                  <p className="text-xs text-muted-foreground">
                    {technologies.length} technologies mapped
                  </p>
                </div>
              </div>
              <Progress value={coveragePercent} className="h-3" />
        </div>

        {/* Pending Technologies Alert */}
        {pendingTechnologies.length > 0 && (
          <div className="bg-orange-50 dark:bg-orange-950/30 border border-orange-200 dark:border-orange-800 rounded-xl p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-orange-500 mt-0.5" />
                <div>
                  <h4 className="font-medium text-orange-900 dark:text-orange-100">
                    {pendingTechnologies.length} technologies pending review
                  </h4>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {pendingTechnologies.map((tech) => (
                      <Badge 
                        key={tech.id} 
                        variant="outline" 
                        className="bg-orange-100 dark:bg-orange-900/50 border-orange-300 text-orange-800"
                      >
                        <span className="mr-2">{tech.name}</span>
                        <button onClick={() => handleConfirmTechnology(tech.id)} className="hover:text-green-600">
                          <Check className="w-3 h-3" />
                        </button>
                        <button onClick={() => handleRejectTechnology(tech.id)} className="ml-1 hover:text-red-600">
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
              <Button size="sm" variant="outline" onClick={handleConfirmAll}>
                <Check className="w-4 h-4 mr-1" />
                Confirm All
              </Button>
            </div>
          </div>
        )}

        {/* Canvas */}
        <div ref={canvasRef} className="flex-1 bg-card rounded-xl border border-border overflow-hidden relative">
          <Button
            variant="outline"
            size="sm"
            onClick={handleSaveAsImage}
            className="absolute top-2 right-2 z-10"
            title="Save as image"
          >
            <Camera className="w-4 h-4 mr-1" />
            Save Image
          </Button>
          <FunctionalAreaCanvas
            areas={areaNodes}
            technologies={techNodes}
            connections={connections}
            layers={layers}
            layerHeights={dynamicLayerHeights}
            onAreasChange={handleAreasChange}
            onTechnologiesChange={handleTechsChange}
            onConnectionsChange={setConnections}
            onDropTechnology={handleDropTechnology}
            onRemoveTechnology={handleRemoveTechnology}
            onAddArea={async (area) => {
              await createArea.mutateAsync({
                name: area.name,
                layer: area.layer,
                color: area.color,
                description: null,
                default_width: 200,
                default_height: 100,
                sort_order: functionalAreas?.length || 0,
              });
            }}
            onEditArea={async (id, updates) => {
              await updateArea.mutateAsync({ id, ...updates });
            }}
            onDeleteArea={async (id) => {
              await deleteArea.mutateAsync(id);
            }}
            mode="account"
            height={Math.max(650, totalCanvasHeight + 50)}
          />
        </div>
      </div>
        </div>
      )}

      {/* Add Technology Dialog */}
      <Dialog open={showTechDialog} onOpenChange={setShowTechDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add {pendingTech?.tech.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Relationship Status</Label>
              <Select value={relationshipStatus} onValueChange={setRelationshipStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="neutral">Neutral</SelectItem>
                  <SelectItem value="competitor">Competitor</SelectItem>
                  <SelectItem value="complementary">Complementary</SelectItem>
                  <SelectItem value="complementary_risk">Complementary (with risk)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Owner Name (optional)</Label>
              <Input
                placeholder="e.g., John Smith"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Owner Email (optional)</Label>
              <Input
                type="email"
                placeholder="e.g., john@company.com"
                value={ownerEmail}
                onChange={(e) => setOwnerEmail(e.target.value)}
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setShowTechDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddTechnology}>
                Add to Account
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

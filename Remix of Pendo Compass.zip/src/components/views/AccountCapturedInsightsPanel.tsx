import { useState } from 'react';
import { ChevronDown, ChevronRight, Database, ExternalLink, Trash2, BarChart3 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useAccountCapturedInsights } from '@/hooks/useDetectionRules';
import { format } from 'date-fns';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

interface AccountCapturedInsightsPanelProps {
  accountId: string;
}

export function AccountCapturedInsightsPanel({ accountId }: AccountCapturedInsightsPanelProps) {
  const [isInsightsOpen, setIsInsightsOpen] = useState(false);
  const { data: insights = [], isLoading } = useAccountCapturedInsights(accountId);
  const queryClient = useQueryClient();

  const deleteInsight = useMutation({
    mutationFn: async (insightId: string) => {
      const { error } = await gateway
        .from('account_captured_insights')
        .delete()
        .eq('id', insightId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['account-captured-insights', accountId] });
      toast.success('Insight removed');
    },
    onError: () => {
      toast.error('Failed to remove insight');
    },
  });

  // Group insights by rule name
  const insightsArray = insights as any[];
  const groupedInsights = insightsArray.reduce((acc: Record<string, any[]>, insight: any) => {
    const ruleName = insight.capture_field?.rule?.name || 'Unknown Rule';
    if (!acc[ruleName]) acc[ruleName] = [];
    acc[ruleName].push(insight);
    return acc;
  }, {});

  if (isLoading) {
    return (
      <div className="glass rounded-xl p-6">
        <div className="flex items-center gap-2 text-muted-foreground">
          <BarChart3 className="w-5 h-5" />
          <span>Loading account intelligence...</span>
        </div>
      </div>
    );
  }

  // If no insights, don't render anything
  if (insights.length === 0) {
    return null;
  }

  return (
    <div className="glass rounded-xl p-6 space-y-4">
      {/* Captured Insights Section */}
      <Collapsible open={isInsightsOpen} onOpenChange={setIsInsightsOpen}>
        <CollapsibleTrigger asChild>
          <div className="flex items-center justify-between cursor-pointer hover:bg-muted/50 transition-colors rounded-lg p-2 -mx-2">
            <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Database className="w-4 h-4" />
              Captured Insights
              <Badge variant="secondary" className="text-xs">{insights.length}</Badge>
            </h3>
            {isInsightsOpen ? (
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            )}
          </div>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="pt-3 space-y-4">
            <p className="text-sm text-muted-foreground">
              Insights automatically extracted from transcripts based on detection rules.
            </p>
            
            {Object.entries(groupedInsights).map(([ruleName, ruleInsights]) => (
              <div key={ruleName} className="space-y-2">
                <h4 className="text-sm font-medium text-muted-foreground">{ruleName}</h4>
                <div className="space-y-2">
                  {(ruleInsights as any[]).map((insight: any) => {
                    const captureField = insight.capture_field as any;
                    const sourceTranscript = insight.source_transcript as any;
                    
                    return (
                      <div 
                        key={insight.id} 
                        className="flex items-start gap-3 p-3 bg-muted/30 rounded-lg border border-border/50 group"
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium text-sm">{captureField?.field_name || 'Unknown Field'}</span>
                            <Badge variant="outline" className="text-xs">{captureField?.field_type || 'text'}</Badge>
                            {insight.confidence_score && (
                              <Badge variant="secondary" className="text-xs">
                                {Math.round((insight.confidence_score as number) * 100)}% confident
                              </Badge>
                            )}
                          </div>
                          <div className="mt-1 text-foreground">
                            {insight.value_json ? (
                              <pre className="text-sm whitespace-pre-wrap bg-muted/50 p-2 rounded mt-1">
                                {JSON.stringify(insight.value_json, null, 2)}
                              </pre>
                            ) : (
                              <p className="text-sm">{insight.value || '—'}</p>
                            )}
                          </div>
                          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                            <span>
                              Extracted: {format(new Date(insight.extracted_at), 'MMM d, yyyy')}
                            </span>
                            {sourceTranscript && (
                              <span className="flex items-center gap-1">
                                <ExternalLink className="w-3 h-3" />
                                {sourceTranscript.file_name || 'Transcript'}
                              </span>
                            )}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => deleteInsight.mutate(insight.id)}
                        >
                          <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}

import { useState, useMemo, useEffect, useRef } from 'react';
import { ArrowLeft, Building2, Target, FileText, Image, Plus, Trash2, Mic, Lightbulb, BookOpen, BarChart3, User, Users, Zap, ChevronRight, FileDown } from 'lucide-react';
import { useWhitespaceNBAs } from '@/hooks/useWhitespaceNBAs';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { ExportMAPDialog } from '@/components/dialogs/ExportMAPDialog';

import { 
  useAccountWithDetails, 
  useCreateOpportunity, 
  useDeleteOpportunity,
  useUpdateAccount, 
  useCreateAccountTechnology,
  useDeleteAccountTechnology,
  useUpdateAccountTechnology,
  useTranscriptReviews,
  DbOpportunity 
} from '@/hooks/useAccounts';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useAccountUseCases } from '@/hooks/useAccountUseCases';
import { useFunctionalAreas } from '@/hooks/useTechnologyRepository';
import { Skeleton } from '@/components/ui/skeleton';
import { AccountArchitectureCanvas } from './AccountArchitectureCanvas';
import { PriorityRadar } from './PriorityRadar';
import { AccountTranscriptsTab } from './AccountTranscriptsTab';
import { AccountUseCasesTab } from './AccountUseCasesTab';
import { AccountStoryTab } from './AccountStoryTab';
import { AccountInsightsTab } from './AccountInsightsTab';
import { AccountDetailsTab } from './AccountDetailsTab';
import { AccountNBAsTab } from './AccountNBAsTab';
import { AccountStakeholderMapTab } from './AccountStakeholderMapTab';
import { AccountTeamTab } from './AccountTeamTab';
import { OpportunityDetailView } from './OpportunityDetailView';
import { DocumentsPanel } from '@/components/documents/DocumentsPanel';
import { Account, Technology } from '@/types/architecture';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { useRecentItems } from '@/hooks/useRecentItems';
import { LinkSlackChannelDialog } from '@/components/dialogs/LinkSlackChannelDialog';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface AccountDetailViewProps {
  accountId: string;
  activeTab: string;
  onBack: () => void;
  onTabChange: (tab: string) => void;
  initialOpportunityId?: string;
  initialOpportunityTab?: string;
  onOpportunityTabChange?: (tab: string) => void;
  onOpportunitySelect?: (opportunityId: string | null) => void;
}

const accountTypeColors: Record<string, string> = {
  prospect: 'bg-layer-build-muted text-layer-build',
  customer: 'bg-primary/20 text-primary',
  whitespace_only: 'bg-amber-500/20 text-amber-500',
};

const relationshipStatusColors: Record<string, string> = {
  active: 'bg-layer-growth/20 text-layer-growth',
  whitespace_only: 'bg-amber-500/20 text-amber-500',
  inactive: 'bg-muted text-muted-foreground',
};

const priorityColors: Record<string, string> = {
  high: 'bg-destructive/20 text-destructive',
  medium: 'bg-layer-build-muted text-layer-build',
  low: 'bg-muted text-muted-foreground',
};

// Opportunity stages based on Salesforce stages
const opportunityStages = [
  { value: 'stage_0', label: 'Stage 0' },
  { value: 'stage_1', label: 'Stage 1' },
  { value: 'stage_2', label: 'Stage 2' },
  { value: 'stage_3', label: 'Stage 3' },
  { value: 'stage_4', label: 'Stage 4' },
  { value: 'stage_5_sales_won', label: 'Stage 5: Sales/Won' },
  { value: 'stage_6_closed_won', label: 'Stage 6: Closed/Won' },
  { value: 'disqualified', label: 'Disqualified' },
  { value: 'closed_lost', label: 'Closed/Lost' },
  { value: 'closed_shifted', label: 'Closed/Shifted' },
  { value: 'closed_cancelled_shift', label: 'Closed/Cancelled Shift' },
];

// Stages that indicate a "won" deal - makes account a customer
const wonStages = ['stage_5_sales_won', 'stage_6_closed_won'];

// Stage colors for opportunities
const opportunityStageColors: Record<string, string> = {
  stage_0: 'bg-muted text-muted-foreground',
  stage_1: 'bg-layer-host-muted text-layer-host',
  stage_2: 'bg-layer-build-muted text-layer-build',
  stage_3: 'bg-layer-adopt-muted text-layer-adopt',
  stage_4: 'bg-layer-growth-muted text-layer-growth',
  stage_5_sales_won: 'bg-primary/20 text-primary',
  stage_6_closed_won: 'bg-primary/20 text-primary',
  disqualified: 'bg-destructive/20 text-destructive',
  closed_lost: 'bg-destructive/20 text-destructive',
  closed_shifted: 'bg-amber-500/20 text-amber-500',
  closed_cancelled_shift: 'bg-amber-500/20 text-amber-500',
};

// Helper to check if account should be customer based on opportunities
export function deriveAccountType(opportunities: DbOpportunity[]): 'customer' | 'prospect' {
  const hasWonOpportunity = opportunities.some(opp => 
    wonStages.includes(opp.stage || '')
  );
  return hasWonOpportunity ? 'customer' : 'prospect';
}

// Get display label for stage
function getStageLabel(stageValue: string | null): string {
  if (!stageValue) return 'Stage 0';
  const stage = opportunityStages.find(s => s.value === stageValue);
  return stage?.label || stageValue;
}

export function AccountDetailView({
  accountId,
  activeTab,
  onBack,
  onTabChange,
  initialOpportunityId,
  initialOpportunityTab,
  onOpportunityTabChange,
  onOpportunitySelect,
}: AccountDetailViewProps) {
  const { data: accountData, isLoading } = useAccountWithDetails(accountId, true); // Include archived
  const { data: useCases } = useAccountUseCases(accountId);
  const { data: allTranscripts } = useTranscriptReviews('approved');
  const { data: functionalAreas } = useFunctionalAreas();
  const updateAccount = useUpdateAccount();
  const createTechnology = useCreateAccountTechnology();
  const deleteTechnology = useDeleteAccountTechnology();
  const updateTechnology = useUpdateAccountTechnology();
  const [showOpportunityDialog, setShowOpportunityDialog] = useState(false);
  const [selectedOpportunity, setSelectedOpportunity] = useState<DbOpportunity | null>(null);
  const [isOpportunityLoading, setIsOpportunityLoading] = useState(false);
  const [showMAPExport, setShowMAPExport] = useState(false);
  const { addRecentItem } = useRecentItems();

  // Reset opportunity selection when switching accounts
  useEffect(() => {
    setSelectedOpportunity(null);
    setIsOpportunityLoading(false);
  }, [accountId]);

  // Keep URL selection in sync when an opportunity is currently open
  useEffect(() => {
    if (selectedOpportunity?.id) {
      onOpportunitySelect?.(selectedOpportunity.id);
    }
  }, [selectedOpportunity?.id, onOpportunitySelect]);

  // Track this account as recently viewed
  useEffect(() => {
    if (accountData?.name) {
      addRecentItem({
        id: accountId,
        type: 'account',
        name: accountData.name,
        path: `/accounts/${accountId}`,
      });
    }
  }, [accountId, accountData?.name, addRecentItem]);


  // Track whether we've already handled the initial deep-link so refetches don't remount
  const hasHandledInitialOpportunity = useRef(false);

  useEffect(() => {
    if (hasHandledInitialOpportunity.current) return;
    if (initialOpportunityId && accountData?.opportunities) {
      const opp = accountData.opportunities.find(o => o.id === initialOpportunityId);
      if (opp) {
        hasHandledInitialOpportunity.current = true;
        setIsOpportunityLoading(true);
        onTabChange('opportunities');
        setTimeout(() => {
          setSelectedOpportunity(opp);
          onOpportunitySelect?.(opp.id);
          setIsOpportunityLoading(false);
        }, 100);
      }
    }
  }, [initialOpportunityId, accountData?.opportunities, onTabChange, onOpportunitySelect]);

  // Count transcripts for this account (dedupe by file_name to avoid double-counting re-analysis)
  const transcriptCount = useMemo(() => {
    if (!allTranscripts) return 0;

    const unique = new Set<string>();
    allTranscripts
      .filter((t: any) => t.final_account_id === accountId)
      .forEach((t: any) => {
        const key = t.file_name || t.id;
        if (key) unique.add(key);
      });

    return unique.size;
  }, [allTranscripts, accountId]);

  // Fetch NBA count for this account (database NBAs only)
  const { data: dbNbaCount } = useQuery({
    queryKey: ['account-nba-count', accountId],
    queryFn: async () => {
      const { count, error } = await supabase
        .from('account_nbas')
        .select('*', { count: 'exact', head: true })
        .eq('account_id', accountId)
        .neq('status', 'completed');
      if (error) throw error;
      return count || 0;
    },
  });

  // Fetch whitespace NBAs for count
  const { whitespaceNBAs } = useWhitespaceNBAs(accountId);
  
  // Total actions count = database NBAs + whitespace NBAs
  const nbaCount = (dbNbaCount || 0) + (whitespaceNBAs?.length || 0);

  // Calculate architecture coverage percentage - use technologies length and categories for proper dependency tracking
  const technologiesCount = accountData?.technologies?.length ?? 0;
  const technologyCategories = accountData?.technologies?.map(t => t.category).join(',') ?? '';
  
  const coveragePercent = useMemo(() => {
    if (!functionalAreas || functionalAreas.length === 0) return 0;

    const techs = Array.isArray(accountData?.technologies) ? accountData!.technologies : [];
    const coveredAreas = new Set(techs.map(t => t.category));
    const totalAreas = new Set(functionalAreas.map(a => a.name));

    let covered = 0;
    totalAreas.forEach(area => {
      if (coveredAreas.has(area)) covered++;
    });

    return Math.round((covered / totalAreas.size) * 100);
  }, [accountData, functionalAreas, technologiesCount, technologyCategories]);

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-12 w-64" />
        <Skeleton className="h-[600px]" />
      </div>
    );
  }

  if (!accountData) {
    return (
      <div className="p-6">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Accounts
        </Button>
        <p className="mt-4 text-muted-foreground">Account not found</p>
      </div>
    );
  }

  // Convert DB account to the Account type expected by ArchitectureCanvas
  const technologies = Array.isArray(accountData.technologies) ? accountData.technologies : [];
  const opportunities = Array.isArray(accountData.opportunities) ? accountData.opportunities : [];
  const archivedOpportunities = Array.isArray((accountData as any).archivedOpportunities) ? (accountData as any).archivedOpportunities : [];
  const documents = Array.isArray(accountData.documents) ? accountData.documents : [];

  const legacyAccount: Account = {
    id: accountData.id,
    name: accountData.name,
    industry: accountData.industry || undefined,
    stage: accountData.stage as Account['stage'],
    technologies: technologies.map(t => ({
      id: t.id,
      name: t.name,
      layer: t.layer as 'host' | 'build' | 'adopt' | 'growth',
      category: t.category,
      notes: t.notes || undefined,
      priority: t.priority as Technology['priority'],
    })),
    createdAt: new Date(accountData.created_at),
    updatedAt: new Date(accountData.updated_at),
  };

  const handleUpdateAccount = async (updated: Account) => {
    // Update account basic info
    updateAccount.mutate({
      id: updated.id,
      name: updated.name,
      industry: updated.industry || null,
      stage: updated.stage,
    });

    // Find technologies to add (in updated but not in current)
    const currentTechIds = technologies.map(t => t.id);
    const updatedTechIds = updated.technologies.map(t => t.id);

    const techsToAdd = updated.technologies.filter(t => !currentTechIds.includes(t.id));
    const techsToRemove = technologies.filter(t => !updatedTechIds.includes(t.id));
    const techsToUpdate = updated.technologies.filter(t => currentTechIds.includes(t.id));

    // Add new technologies
    for (const tech of techsToAdd) {
      await createTechnology.mutateAsync({
        account_id: accountId,
        name: tech.name,
        layer: tech.layer,
        category: tech.category,
        notes: tech.notes || null,
        priority: tech.priority || null,
      });
    }

    // Update existing technologies (e.g., priority changes)
    for (const tech of techsToUpdate) {
      const current = technologies.find(t => t.id === tech.id);
      if (current && current.priority !== tech.priority) {
        await updateTechnology.mutateAsync({
          id: tech.id,
          accountId,
          priority: tech.priority || null,
        });
      }
    }

    // Remove deleted technologies
    for (const tech of techsToRemove) {
      await deleteTechnology.mutateAsync({ id: tech.id, accountId });
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <Building2 className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="page-heading">{accountData.name}</h1>
              <div className="flex items-center gap-2 mt-1">
                {accountData.industry && (
                  <span className="text-sm text-muted-foreground">{accountData.industry}</span>
                )}
                {accountData.stage && (
                  <Badge className={cn("capitalize", accountTypeColors[accountData.stage] || 'bg-layer-build-muted text-layer-build')}>
                    {accountData.stage}
                  </Badge>
                )}
                {accountData.relationship_status === 'whitespace_only' && (
                  <Badge className={cn(relationshipStatusColors.whitespace_only)}>
                    Whitespace Only
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <LinkSlackChannelDialog accountId={accountId} purpose="account" />
          <Button onClick={() => setShowMAPExport(true)} className="gap-2">
            <FileDown className="w-4 h-4" />
            Export MAP
          </Button>
        </div>
      </div>

      {/* MAP Export Dialog */}
      <ExportMAPDialog
        open={showMAPExport}
        onOpenChange={setShowMAPExport}
        accountId={accountId}
        accountName={accountData.name}
      />

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={onTabChange} className="flex-1 flex flex-col">
        <div className="px-6 border-b border-border overflow-x-auto">
          <TabsList className="h-12 inline-flex min-w-max">
            <TabsTrigger value="details" className="gap-2 whitespace-nowrap">
              <User className="w-4 h-4" />
              Details
            </TabsTrigger>
            <TabsTrigger value="insights" className="gap-2 whitespace-nowrap">
              <BarChart3 className="w-4 h-4" />
              Insights
            </TabsTrigger>
            <TabsTrigger value="use-cases" className="gap-2 whitespace-nowrap">
              <Lightbulb className="w-4 h-4" />
              Use Cases
              <Badge variant="outline" className="ml-1 text-xs px-1.5 py-0">
                {useCases?.length || 0}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="architecture" className="gap-2 whitespace-nowrap">
              <Building2 className="w-4 h-4" />
              Architecture
              <Badge variant="outline" className="ml-1 text-xs px-1.5 py-0">
                {coveragePercent}%
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="radar" className="gap-2 whitespace-nowrap">
              <Target className="w-4 h-4" />
              Priority Radar
            </TabsTrigger>
            <TabsTrigger value="nbas" className="gap-2 whitespace-nowrap">
              <Zap className="w-4 h-4" />
              Actions
              <Badge variant="outline" className="ml-1 text-xs px-1.5 py-0">
                {nbaCount || 0}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="opportunities" className="gap-2 whitespace-nowrap">
              <Target className="w-4 h-4" />
              <span>Opportunities</span>
              <Badge variant="outline" className="ml-1 text-xs px-1.5 py-0">
                {opportunities.length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="story" className="gap-2 whitespace-nowrap">
              <BookOpen className="w-4 h-4" />
              Story
            </TabsTrigger>
            <TabsTrigger value="transcripts" className="gap-2 whitespace-nowrap">
              <Mic className="w-4 h-4" />
              Transcripts
              <Badge variant="outline" className="ml-1 text-xs px-1.5 py-0">
                {transcriptCount}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="stakeholders" className="gap-2 whitespace-nowrap">
              <Users className="w-4 h-4" />
              Stakeholder Map
            </TabsTrigger>
            <TabsTrigger value="team" className="gap-2 whitespace-nowrap">
              <Users className="w-4 h-4" />
              Team
            </TabsTrigger>
            <TabsTrigger value="documents" className="gap-2 whitespace-nowrap">
              <FileText className="w-4 h-4" />
              Documents
              <Badge variant="outline" className="ml-1 text-xs px-1.5 py-0">
                {documents.length}
              </Badge>
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="flex-1 overflow-auto">
          <TabsContent value="details" className="h-full m-0 overflow-auto">
            <AccountDetailsTab account={accountData} opportunities={opportunities} />
          </TabsContent>

          <TabsContent value="insights" className="h-full m-0 overflow-auto">
            <AccountInsightsTab accountId={accountId} />
          </TabsContent>

          <TabsContent value="use-cases" className="h-full m-0">
            <AccountUseCasesTab accountId={accountId} />
          </TabsContent>

          <TabsContent value="architecture" className="h-full m-0">
            <AccountArchitectureCanvas accountId={accountId} technologies={technologies} />
          </TabsContent>

          <TabsContent value="radar" className="h-full m-0">
            <PriorityRadar
              account={legacyAccount}
              onUpdateAccount={handleUpdateAccount}
              onBack={onBack}
              embedded
            />
          </TabsContent>

          <TabsContent value="nbas" className="h-full m-0 overflow-auto">
            <AccountNBAsTab accountId={accountId} accountName={accountData.name} />
          </TabsContent>

          <TabsContent value="opportunities" className="h-full m-0">
            {isOpportunityLoading ? (
              <div className="flex items-center justify-center h-64">
                <div className="flex flex-col items-center gap-3">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  <p className="text-sm text-muted-foreground">Loading opportunity...</p>
                </div>
              </div>
            ) : selectedOpportunity ? (
              <OpportunityDetailView
                opportunity={selectedOpportunity}
                accountName={accountData.name}
                onBack={() => {
                  setSelectedOpportunity(null);
                  onOpportunitySelect?.(null);
                  // Clear oppTab from URL when going back
                  onOpportunityTabChange?.('');
                }}
                initialTab={initialOpportunityTab}
                onTabChange={onOpportunityTabChange}
              />
            ) : (
              <div className="p-6">
                <OpportunitiesTab
                  opportunities={opportunities}
                  archivedOpportunities={archivedOpportunities}
                  accountId={accountId}
                  showDialog={showOpportunityDialog}
                  setShowDialog={setShowOpportunityDialog}
                  onSelectOpportunity={(opp) => {
                    setIsOpportunityLoading(true);
                    onOpportunitySelect?.(opp.id);
                    // Simulate a brief delay for the loading state to be visible
                    // The actual loading happens in OpportunityDetailView
                    setTimeout(() => {
                      setSelectedOpportunity(opp);
                      setIsOpportunityLoading(false);
                    }, 100);
                  }}
                />
              </div>
            )}
          </TabsContent>

          <TabsContent value="story" className="h-full m-0 overflow-auto">
            <AccountStoryTab accountId={accountId} />
          </TabsContent>

          <TabsContent value="transcripts" className="p-6">
            <AccountTranscriptsTab accountId={accountId} accountName={accountData.name} documents={documents} />
          </TabsContent>

          <TabsContent value="stakeholders" className="h-full m-0 overflow-auto">
            <AccountStakeholderMapTab accountId={accountId} />
          </TabsContent>

          <TabsContent value="team" className="h-full m-0 overflow-auto">
            <AccountTeamTab accountId={accountId} />
          </TabsContent>

          <TabsContent value="documents" className="p-6">
            <DocumentsPanel 
              accountId={accountId} 
              accountName={accountData.name}
              context="account" 
            />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}

interface OpportunitiesTabProps {
  opportunities: DbOpportunity[];
  archivedOpportunities: DbOpportunity[];
  accountId: string;
  showDialog: boolean;
  setShowDialog: (show: boolean) => void;
  onSelectOpportunity: (opp: DbOpportunity) => void;
}

function OpportunitiesTab({ opportunities, archivedOpportunities, accountId, showDialog, setShowDialog, onSelectOpportunity }: OpportunitiesTabProps) {
  const createOpportunity = useCreateOpportunity();
  const deleteOpportunity = useDeleteOpportunity();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [value, setValue] = useState('');
  const [priority, setPriority] = useState('medium');
  const [stage, setStage] = useState('stage_0');
  const [opportunityToDelete, setOpportunityToDelete] = useState<DbOpportunity | null>(null);
  const [activeView, setActiveView] = useState<'open' | 'closed'>('open');

  const handleDeleteOpportunity = async () => {
    if (!opportunityToDelete) return;
    await deleteOpportunity.mutateAsync({ id: opportunityToDelete.id, accountId });
    setOpportunityToDelete(null);
  };

  const handleCreate = async () => {
    if (!name.trim()) return;
    
    await createOpportunity.mutateAsync({
      account_id: accountId,
      name: name.trim(),
      description: description || null,
      value: value ? parseFloat(value) : null,
      priority,
      stage,
    });

    setName('');
    setDescription('');
    setValue('');
    setPriority('medium');
    setStage('stage_0');
    setShowDialog(false);
  };

  const displayedOpportunities = activeView === 'open' ? opportunities : archivedOpportunities;

  const renderOpportunityCard = (opp: DbOpportunity, isArchived: boolean) => (
    <div 
      key={opp.id} 
      className={cn("glass rounded-xl p-5 cursor-pointer hover:bg-muted/50 transition-colors group", isArchived && "opacity-60")}
      onClick={() => onSelectOpportunity(opp)}
    >
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-foreground">{opp.name}</h3>
            {isArchived && (
              <Badge variant="outline" className="text-xs">
                {(opp as any).sales_stage?.includes('won') ? 'Won' : 'Lost'}
              </Badge>
            )}
          </div>
          {opp.description && (
            <p className="text-sm text-muted-foreground mt-1">{opp.description}</p>
          )}
        </div>
        <div className="flex items-center gap-2">
          {opp.value && (
            <span className="text-sm font-medium text-foreground">
              ${opp.value.toLocaleString()}
            </span>
          )}
          {!isArchived && opp.stage && (
            <Badge className={cn(opportunityStageColors[opp.stage] || 'bg-muted text-muted-foreground')}>
              {getStageLabel(opp.stage)}
            </Badge>
          )}
          {!isArchived && (
            <Badge className={cn(priorityColors[opp.priority || 'medium'])}>
              {opp.priority}
            </Badge>
          )}
          {!isArchived && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
              onClick={(e) => {
                e.stopPropagation();
                setOpportunityToDelete(opp);
              }}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
          <ChevronRight className="w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Opportunities</h2>
          <p className="text-sm text-muted-foreground">Track expansion and upsell opportunities</p>
        </div>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button variant="glow">
              <Plus className="w-4 h-4" />
              Add Opportunity
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Opportunity</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>Name *</Label>
                <Input
                  placeholder="e.g., Expand to Product team"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  placeholder="Describe the opportunity..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Value ($)</Label>
                  <Input
                    type="number"
                    placeholder="50000"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Stage</Label>
                  <Select value={stage} onValueChange={setStage}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {opportunityStages.map(s => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Priority</Label>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={!name.trim() || createOpportunity.isPending}>
                  {createOpportunity.isPending ? 'Adding...' : 'Add Opportunity'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Open / Closed toggle */}
      <div className="flex items-center gap-1 p-1 bg-muted rounded-lg w-fit">
        <Button
          variant={activeView === 'open' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setActiveView('open')}
          className="text-xs"
        >
          Open ({opportunities.length})
        </Button>
        <Button
          variant={activeView === 'closed' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setActiveView('closed')}
          className="text-xs"
        >
          Closed ({archivedOpportunities.length})
        </Button>
      </div>

      {displayedOpportunities.length === 0 ? (
        <div className="glass rounded-xl p-8 text-center">
          <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">
            {activeView === 'open' ? 'No open opportunities' : 'No closed opportunities'}
          </p>
          {activeView === 'open' && (
            <p className="text-sm text-muted-foreground mt-1">
              Add opportunities to track expansion potential
            </p>
          )}
        </div>
      ) : (
        <div className="grid gap-4">
          {displayedOpportunities.map((opp) => renderOpportunityCard(opp, activeView === 'closed'))}
        </div>
      )}

      <AlertDialog open={!!opportunityToDelete} onOpenChange={(open) => !open && setOpportunityToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Opportunity</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{opportunityToDelete?.name}"? This action cannot be undone and will remove all associated data including transcripts, insights, and stakeholders linked to this opportunity.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteOpportunity}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteOpportunity.isPending ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

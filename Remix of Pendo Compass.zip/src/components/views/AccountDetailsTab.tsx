import { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { User, Building2, Calendar, DollarSign, Edit2, Save, X, Link2, Video, ExternalLink, Trash2, AlertTriangle, Info, FileText, ChevronDown, Loader2, Eraser } from 'lucide-react';
import { toast } from 'sonner';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { useUpdateAccount, useDeleteAccount, DbAccount, DbOpportunity } from '@/hooks/useAccounts';
import { useAuth } from '@/contexts/AuthContext';
import { useAssignableOpportunityUsers } from '@/hooks/useAssignableOpportunityUsers';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { WhitespaceRevenueCalculator } from '@/components/WhitespaceRevenueCalculator';

interface AccountDetailsTabProps {
  account: DbAccount;
  opportunities?: DbOpportunity[];
  onDelete?: () => void;
}

// Account type: prospect or customer
const accountTypeOptions = [
  { value: 'prospect', label: 'Prospect' },
  { value: 'customer', label: 'Customer' },
];

const accountTypeColors: Record<string, string> = {
  prospect: 'bg-layer-build-muted text-layer-build',
  customer: 'bg-primary/20 text-primary',
};

// Stages that indicate a "won" deal - makes account a customer
const wonStages = ['stage_5_sales_won', 'stage_6_closed_won'];

// Helper to derive account type from opportunities
function deriveAccountType(opportunities: DbOpportunity[]): 'customer' | 'prospect' {
  const hasWonOpportunity = opportunities.some(opp => 
    wonStages.includes(opp.stage || '')
  );
  return hasWonOpportunity ? 'customer' : 'prospect';
}

export function AccountDetailsTab({ account, opportunities = [], onDelete }: AccountDetailsTabProps) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const updateAccount = useUpdateAccount();
  const deleteAccount = useDeleteAccount();
  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showPurgeDialog, setShowPurgeDialog] = useState(false);

  // Purge AI-extracted data mutation
  const purgeAIDataMutation = useMutation({
    mutationFn: async () => {
      // Delete AI-extracted technologies
      await gateway.from('account_technologies').delete().eq('account_id', account.id).execute();
      
      // Delete contacts from transcripts AND momentum (AI-extracted, keep manual ones)
      // Note: momentum contacts come from meeting attendee parsing which can have bad data
      await gateway.from('account_contacts')
        .delete()
        .eq('account_id', account.id)
        .in('source', ['transcript', 'momentum'])
        .execute();
      
      // Delete pain points
      await gateway.from('account_pain_points').delete().eq('account_id', account.id).execute();
      
      // Delete use cases
      await gateway.from('account_use_cases').delete().eq('account_id', account.id).execute();
      
      // Delete NBAs
      await gateway.from('account_nbas').delete().eq('account_id', account.id).execute();
      
      // Delete metrics
      await gateway.from('account_metrics').delete().eq('account_id', account.id).execute();
      
      // Delete captured insights
      await gateway.from('account_captured_insights').delete().eq('account_id', account.id).execute();
      
      // Delete product mentions
      await gateway.from('product_mentions').delete().eq('account_id', account.id).execute();
      
      // Delete exec summaries (Account Intelligence, Key Risks, Key Opportunities)
      await gateway.from('account_exec_summaries').delete().eq('account_id', account.id).execute();
      
      // Delete metric history
      await gateway.from('account_metric_history').delete().eq('account_id', account.id).execute();
      
      // Delete strategic themes
      await gateway.from('account_strategic_themes').delete().eq('account_id', account.id).execute();
      
      // Get transcripts and clear their extracted insights + delete detection matches
      const { data: transcripts } = await gateway
        .from('transcript_reviews')
        .select('id')
        .eq('final_account_id', account.id)
        .execute();
      
      if (transcripts && transcripts.length > 0) {
        const transcriptIds = transcripts.map(t => t.id);
        
        // Delete detection rule matches
        await gateway.from('detection_rule_matches')
          .delete()
          .in('transcript_id', transcriptIds)
          .execute();
        
        // Clear extracted insights JSON from transcripts (keeps the transcript, removes analysis)
        // IMPORTANT: Also clear last_enriched_hash so re-analysis won't skip due to "unchanged content"
        await gateway.from('transcript_reviews')
          .update({ 
            extracted_insights: null, 
            extracted_technologies: null,
            last_enriched_hash: null, // Clear hash to force re-analysis
            status: 'pending' // Reset to pending so they can be re-analyzed
          })
          .in('id', transcriptIds)
          .execute();
      }
    },
    onSuccess: () => {
      toast.success('AI-extracted data purged successfully. Transcripts reset to pending for re-analysis.');
      setShowPurgeDialog(false);
      // Invalidate all relevant queries
      queryClient.invalidateQueries({ queryKey: ['account-technologies', account.id] });
      queryClient.invalidateQueries({ queryKey: ['account-contacts', account.id] });
      queryClient.invalidateQueries({ queryKey: ['account-pain-points', account.id] });
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', account.id] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', account.id] });
      queryClient.invalidateQueries({ queryKey: ['account-metrics', account.id] });
      queryClient.invalidateQueries({ queryKey: ['account-insights', account.id] });
      queryClient.invalidateQueries({ queryKey: ['product-mentions', account.id] });
      queryClient.invalidateQueries({ queryKey: ['account-exec-summary', account.id] });
      queryClient.invalidateQueries({ queryKey: ['account-strategic-themes', account.id] });
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', account.id] });
      queryClient.invalidateQueries({ queryKey: ['account-health-metrics', account.id] });
    },
    onError: (err) => {
      toast.error('Failed to purge data: ' + (err instanceof Error ? err.message : 'Unknown error'));
    },
  });

  type AccountType = 'customer' | 'prospect';
  type FormData = {
    name: string;
    industry: string;
    stage: AccountType;
    arr: string;
    salesforce_account_id: string;
  };

  // Derive account type from opportunities
  const derivedType = useMemo(() => deriveAccountType(opportunities), [opportunities]);
  
  // Aggregate MAU count from opportunities
  const aggregatedMauCount = useMemo(() => {
    const oppMaus = opportunities
      .map(opp => (opp as any).mau_count as number | null)
      .filter((m): m is number => m !== null && m > 0);
    return oppMaus.length > 0 ? oppMaus.reduce((sum, m) => sum + m, 0) : null;
  }, [opportunities]);

  // accounts.stage can contain pipeline stages like "discovery"; normalize to the only valid account-type values
  const normalizedType: AccountType =
    account.stage === 'customer' || account.stage === 'prospect' ? account.stage : derivedType;
  const isTypeOverridden = normalizedType !== derivedType && account.stage !== null;

  const [formData, setFormData] = useState<FormData>({
    name: account.name,
    industry: account.industry || '',
    stage: normalizedType,
    arr: account.arr?.toString() || '',
    salesforce_account_id: account.salesforce_account_id || '',
  });

  // Fetch Momentum meetings linked to this account
  const { data: momentumMeetings } = useQuery({
    queryKey: ['momentum-meetings-account', account.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('momentum_meetings')
        .select('id, title, start_time, status, salesforce_opportunity_id')
        .eq('matched_account_id', account.id)
        .order('start_time', { ascending: false })
        .limit(5);
      if (error) throw error;
      return data;
    },
  });
  const { data: assignableUsers } = useAssignableOpportunityUsers(account.id);
  const allActiveUsers = assignableUsers?.seUsers || [];

  // Validate that primary_se_email is actually an email (not corrupted data like dates)
  const isValidEmail = (value: string | null | undefined): boolean => {
    if (!value) return false;
    // Basic email validation - must contain @ and not look like a date
    return value.includes('@') && !(/^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(value));
  };

  const validOwnerEmail = isValidEmail(account.primary_se_email) ? account.primary_se_email : null;
  const isOwner = validOwnerEmail === user?.email;
  const ownerUser = validOwnerEmail ? allActiveUsers.find(u => u.email === validOwnerEmail) : null;

  const formatDate = (value?: string | null) => {
    if (!value) return '—';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return '—';
    return format(d, 'MMM d, yyyy');
  };

  const handleSave = async () => {
    await updateAccount.mutateAsync({
      id: account.id,
      name: formData.name,
      industry: formData.industry || null,
      stage: formData.stage,
      arr: formData.arr ? parseFloat(formData.arr) : null,
      salesforce_account_id: formData.salesforce_account_id || null,
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData({
      name: account.name,
      industry: account.industry || '',
      stage: normalizedType,
      arr: account.arr?.toString() || '',
      salesforce_account_id: account.salesforce_account_id || '',
    });
    setIsEditing(false);
  };

  const handleTakeOwnership = async () => {
    if (!user) return;
    await updateAccount.mutateAsync({
      id: account.id,
      owner_id: user.id,
      primary_se_email: user.email,
    });
  };

  const handleChangeOwner = async (ownerEmail: string) => {
    await updateAccount.mutateAsync({
      id: account.id,
      primary_se_email: ownerEmail,
    });
  };

  const handleDelete = async () => {
    await deleteAccount.mutateAsync(account.id);
    setShowDeleteDialog(false);
    if (onDelete) {
      onDelete();
    } else {
      navigate('/accounts');
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-3xl">
      {/* Ownership Section */}
      <div className="glass rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <User className="w-5 h-5 text-primary" />
            Account Owner
          </h2>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <User className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1">
            <Select
              value={validOwnerEmail || ''}
              onValueChange={(value) => {
                if (value && value !== validOwnerEmail) {
                  handleChangeOwner(value);
                }
              }}
            >
              <SelectTrigger className="w-full max-w-xs">
                <SelectValue placeholder="Select owner">
                  {ownerUser ? (ownerUser.full_name || ownerUser.email) : 'Select owner'}
                </SelectValue>
              </SelectTrigger>
              <SelectContent 
                className="z-[9999] bg-popover"
                position="popper"
                sideOffset={4}
              >
                {allActiveUsers.map((u) => (
                  <SelectItem 
                    key={u.email} 
                    value={u.email}
                    className="cursor-pointer hover:bg-accent"
                  >
                    {u.full_name || u.email}
                    {u.full_name && <span className="text-muted-foreground ml-2 text-xs">({u.email})</span>}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {ownerUser && (
              <p className="text-sm text-muted-foreground mt-1">{ownerUser.email}</p>
            )}
          </div>
          {isOwner && (
            <Badge className="ml-auto bg-primary/20 text-primary">
              You
            </Badge>
          )}
        </div>
      </div>

      {/* Account Details Section */}
      <div className="glass rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Building2 className="w-5 h-5 text-primary" />
            Account Details
          </h2>
          {isEditing ? (
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={handleCancel}>
                <X className="w-4 h-4 mr-1" />
                Cancel
              </Button>
              <Button size="sm" onClick={handleSave} disabled={updateAccount.isPending}>
                <Save className="w-4 h-4 mr-1" />
                {updateAccount.isPending ? 'Saving...' : 'Save'}
              </Button>
            </div>
          ) : (
            <Button variant="ghost" size="sm" onClick={() => setIsEditing(true)}>
              <Edit2 className="w-4 h-4 mr-1" />
              Edit
            </Button>
          )}
        </div>

        <div className="grid gap-6">
          {/* Name */}
          <div className="space-y-2">
            <Label className="text-muted-foreground">Account Name</Label>
            {isEditing ? (
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            ) : (
              <p className="text-foreground font-medium">{account.name}</p>
            )}
          </div>

          {/* Industry */}
          <div className="space-y-2">
            <Label className="text-muted-foreground">Industry</Label>
            {isEditing ? (
              <Input
                value={formData.industry}
                onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                placeholder="e.g., Technology, Healthcare, Finance"
              />
            ) : (
              <p className="text-foreground">{account.industry || 'Not specified'}</p>
            )}
          </div>

          {/* Account Type */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Label className="text-muted-foreground">Account Type</Label>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="w-3.5 h-3.5 text-muted-foreground cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p>Auto-determined from opportunities: <strong>Customer</strong> if any opportunity is Stage 5: Sales/Won or Stage 6: Closed/Won, otherwise <strong>Prospect</strong>. You can manually override this.</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            {isEditing ? (
              <div className="space-y-2">
                <Select
                  value={formData.stage}
                  onValueChange={(value) => setFormData({ ...formData, stage: value as AccountType })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {accountTypeOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formData.stage !== derivedType && (
                  <p className="text-xs text-muted-foreground">
                    Suggested: <span className="capitalize font-medium">{derivedType}</span> (based on opportunities)
                  </p>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Badge className={cn("capitalize", accountTypeColors[account.stage || derivedType])}>
                  {account.stage || derivedType}
                </Badge>
                {isTypeOverridden && (
                  <span className="text-xs text-muted-foreground">(manually set)</span>
                )}
              </div>
            )}
          </div>

          {/* ARR */}
          <div className="space-y-2">
            <Label className="text-muted-foreground">Annual Recurring Revenue (ARR)</Label>
            {isEditing ? (
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="number"
                  value={formData.arr}
                  onChange={(e) => setFormData({ ...formData, arr: e.target.value })}
                  className="pl-9"
                  placeholder="0"
                />
              </div>
            ) : (
              <p className="text-foreground font-medium">
                {account.arr ? `$${account.arr.toLocaleString()}` : 'Not specified'}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Revenue Calculator */}
      <WhitespaceRevenueCalculator
        accountId={account.id}
        accountName={account.name}
        mauCount={aggregatedMauCount ?? (account as any).mau_count ?? null}
        baseMauValue={(account as any).base_mau_value || null}
        employeeCount={(account as any).employee_count || null}
        aggregatedFromOpportunities={aggregatedMauCount !== null}
        onUpdateMauCount={async (mauCount) => {
          await updateAccount.mutateAsync({
            id: account.id,
            mau_count: mauCount,
          } as any);
        }}
        onUpdateBaseMauValue={async (value) => {
          await updateAccount.mutateAsync({
            id: account.id,
            base_mau_value: value,
          } as any);
        }}
      />

      {/* Integrations Section */}
      <div className="glass rounded-xl p-6">
        <h2 className="text-lg font-semibold text-foreground flex items-center gap-2 mb-4">
          <Link2 className="w-5 h-5 text-primary" />
          Integrations
        </h2>
        <div className="space-y-4">
          {/* Salesforce */}
          <div className="space-y-2">
            <Label className="text-muted-foreground">Salesforce Account ID</Label>
            {isEditing ? (
              <Input
                value={formData.salesforce_account_id}
                onChange={(e) => setFormData({ ...formData, salesforce_account_id: e.target.value })}
                placeholder="e.g., 001Xx000003NGl8IAG"
              />
            ) : account.salesforce_account_id ? (
              <a
                href={`https://pendo.lightning.force.com/lightning/r/Account/${account.salesforce_account_id}/view`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 hover:opacity-80 transition-opacity"
              >
                <Badge variant="outline" className="font-mono text-xs">
                  {account.salesforce_account_id}
                </Badge>
                <ExternalLink className="w-3 h-3 text-muted-foreground" />
              </a>
            ) : (
              <p className="text-muted-foreground text-sm">Not linked</p>
            )}
          </div>

          {/* Auto-Import Transcripts Toggle */}
          <div className="flex items-center justify-between py-3 border-b border-border">
            <div className="flex items-center gap-3">
              <FileText className="w-4 h-4 text-muted-foreground" />
              <div>
                <Label className="text-foreground">Auto-Import Transcripts</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically import and analyze matched Momentum meetings
                </p>
              </div>
            </div>
            <Switch
              checked={(account as any).auto_import_transcripts !== false}
              onCheckedChange={async (checked) => {
                await updateAccount.mutateAsync({
                  id: account.id,
                  auto_import_transcripts: checked,
                } as any);
              }}
            />
          </div>

          {/* Momentum Meetings */}
          {momentumMeetings && momentumMeetings.length > 0 && (
            <div className="space-y-2">
              <Label className="text-muted-foreground flex items-center gap-2">
                <Video className="w-4 h-4" />
                Recent Momentum Meetings ({momentumMeetings.length})
              </Label>
              <div className="space-y-2">
                {momentumMeetings.map((meeting) => (
                  <div key={meeting.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/50 text-sm">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{meeting.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(meeting.start_time), 'MMM d, yyyy')}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {meeting.salesforce_opportunity_id && (
                        <Badge variant="outline" className="text-xs font-mono">
                          Opp: {meeting.salesforce_opportunity_id.slice(0, 10)}...
                        </Badge>
                      )}
                      <Badge variant={meeting.status === 'imported' ? 'default' : 'secondary'} className="text-xs capitalize">
                        {meeting.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Metadata Section */}
      <div className="glass rounded-xl p-6">
        <h2 className="text-lg font-semibold text-foreground flex items-center gap-2 mb-4">
          <Calendar className="w-5 h-5 text-primary" />
          Metadata
        </h2>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Created</p>
            <p className="text-foreground">{formatDate((account as any).created_at)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Last Updated</p>
            <p className="text-foreground">{formatDate((account as any).updated_at)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Status</p>
            <Badge variant="outline" className="mt-1 capitalize">
              {account.status || 'Active'}
            </Badge>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="glass rounded-xl p-6 border border-destructive/20">
        <h2 className="text-lg font-semibold text-destructive flex items-center gap-2 mb-4">
          <AlertTriangle className="w-5 h-5" />
          Danger Zone
        </h2>
        <div className="space-y-4">
          {/* Purge AI-extracted data */}
          <div className="flex items-center justify-between py-3 border-b border-border">
            <div>
              <p className="font-medium text-foreground">Purge AI-Extracted Data</p>
              <p className="text-sm text-muted-foreground">
                Remove all AI-extracted technologies, contacts, use cases, pain points, and metrics. Keeps manually added data.
              </p>
            </div>
            <AlertDialog open={showPurgeDialog} onOpenChange={setShowPurgeDialog}>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="border-amber-500 text-amber-600 hover:bg-amber-500/10">
                  <Eraser className="w-4 h-4 mr-2" />
                  Purge Data
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Purge AI-Extracted Data</AlertDialogTitle>
                  <AlertDialogDescription className="space-y-2">
                    <p>
                      This will remove all AI-extracted data for <strong>{account.name}</strong>. This is useful when transcripts were incorrectly assigned and later removed.
                    </p>
                    <p className="text-amber-600 font-medium">
                      The following will be deleted:
                    </p>
                    <ul className="list-disc list-inside text-sm text-muted-foreground">
                      <li>Technologies (all)</li>
                      <li>Contacts from transcripts (keeps manual)</li>
                      <li>Account Intelligence (summary, risks, opportunities)</li>
                      <li>Use Cases & Pain Points</li>
                      <li>NBAs (Next Best Actions)</li>
                      <li>Metrics & Health History</li>
                      <li>Product Mentions & Detection Matches</li>
                      <li>Strategic Themes & Initiatives</li>
                    </ul>
                    <p className="text-sm text-amber-600 mt-2">
                      Transcripts will be reset to "pending" status so they can be re-analyzed.
                    </p>
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => purgeAIDataMutation.mutate()}
                    className="bg-amber-600 text-white hover:bg-amber-700"
                    disabled={purgeAIDataMutation.isPending}
                  >
                    {purgeAIDataMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Purging...
                      </>
                    ) : 'Purge All AI Data'}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>

          {/* Delete Account */}
          <div className="flex items-center justify-between pt-2">
            <div>
              <p className="font-medium text-foreground">Delete Account</p>
              <p className="text-sm text-muted-foreground">
                Permanently delete this account and all related data
              </p>
            </div>
            <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Account
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Account</AlertDialogTitle>
                  <AlertDialogDescription className="space-y-2">
                    <p>
                      Are you sure you want to delete <strong>{account.name}</strong>? This action cannot be undone.
                    </p>
                    <p className="text-destructive font-medium">
                      This will also delete all related data including:
                    </p>
                    <ul className="list-disc list-inside text-sm text-muted-foreground">
                      <li>Opportunities</li>
                      <li>Technologies</li>
                      <li>Documents</li>
                      <li>Contacts</li>
                      <li>Use Cases</li>
                      <li>NBAs (Next Best Actions)</li>
                      <li>Customer Stories</li>
                    </ul>
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDelete}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    disabled={deleteAccount.isPending}
                  >
                    {deleteAccount.isPending ? 'Deleting...' : 'Delete Account'}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </div>
  );
}

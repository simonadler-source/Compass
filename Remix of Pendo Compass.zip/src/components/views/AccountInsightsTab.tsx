import { useMemo, useState } from 'react';
import { AlertTriangle, Lightbulb, Users, Zap, Shield, Database, TrendingUp, TrendingDown, Target, AlertCircle, Check, X, ChevronDown, Swords, Plus, UserCheck, UserX, ArrowRight, Layers, EyeOff, ChevronRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useCompetitiveAnalysis, getMaturityDescription, type FeatureComparison } from '@/hooks/useCompetitiveIntelligence';
import { useCreateAccountTechnology, useDeleteAccountTechnology } from '@/hooks/useAccounts';
import { toast } from 'sonner';
import { ThemedInsightsPanel } from './ThemedInsightsPanel';
import { OpportunityMetricsSection } from './OpportunityMetricsSection';
import { useSuppressedTechnologies, useSuppressTechnology } from '@/hooks/useSuppressedTechnologies';
import { useRejectedTechnologyDetections, useRejectTechnologyDetection, isTechRejectedForTranscript } from '@/hooks/useRejectedTechnologyDetections';
import { AddTechnologyPopover } from '@/components/AddTechnologyPopover';
import { AccountCompetitorManager } from '@/components/AccountCompetitorManager';

interface AccountInsightsTabProps {
  accountId: string;
}

interface ExtractedTech {
  name: string;
  confidence: number;
  context?: string;
  suggestedLayer?: string;
  suggestedFunctionalArea?: string;
  sourceTranscriptId?: string; // Track which transcript detected this
  repositoryTechId?: string | null; // For rejection matching
}

interface FunctionalAreaOption {
  id: string;
  name: string;
}

interface ExtractedPerson {
  name: string;
  role: string | null;
  email: string | null;
  phone: string | null;
  context: string;
}

interface NextBestAction {
  action: string;
  actionType: string;
  priority: string;
  reasoning: string;
}

interface CommercialInsight {
  insight: string;
  type: 'build_vs_buy' | 'budget_timing' | 'competitive_positioning' | 'stakeholder_dynamics';
  swotCategory: 'strength' | 'weakness' | 'opportunity' | 'threat';
  importance: 'high' | 'medium' | 'low';
  context: string;
}

// Pain point can be a string or an object with description/severity
type PainPointItem = string | { description?: string; pain_point?: string; severity?: string };
// Use case can be a string or an object with description/priority
type UseCaseItem = string | { description?: string; use_case?: string; priority?: string };

interface TranscriptInsights {
  painPoints: PainPointItem[];
  useCases: UseCaseItem[];
  competitorMentions: string[];
  people: ExtractedPerson[];
  nbas: NextBestAction[];
  commercialInsights?: CommercialInsight[];
}

interface SwotItem {
  text: string;
  source: string;
  importance: 'high' | 'medium' | 'low';
  insightType?: string; // For commercial insights categorization
}

interface SwotAnalysis {
  strengths: SwotItem[];
  weaknesses: SwotItem[];
  opportunities: SwotItem[];
  threats: SwotItem[];
}

// Confidence-based color coding
const getConfidenceColor = (confidence: number): string => {
  if (confidence >= 0.9) return 'hsl(142, 70%, 45%)'; // Green
  if (confidence >= 0.7) return 'hsl(45, 80%, 45%)';  // Yellow
  return 'hsl(25, 80%, 50%)'; // Orange
};

// Auto-match technology name to functional areas using fuzzy matching
const matchTechToFunctionalAreas = (techName: string, functionalAreas: FunctionalAreaOption[]): { matched: FunctionalAreaOption[]; unmatched: FunctionalAreaOption[] } => {
  const techLower = techName.toLowerCase();
  const matched: FunctionalAreaOption[] = [];
  const unmatched: FunctionalAreaOption[] = [];
  
  // Keywords mapping for common technologies
  const techKeywords: Record<string, string[]> = {
    'salesforce': ['crm'],
    'hubspot': ['crm'],
    'dynamics': ['crm'],
    'snowflake': ['data lake', 'warehouse'],
    'databricks': ['data lake', 'warehouse'],
    'bigquery': ['data lake', 'warehouse'],
    'redshift': ['data lake', 'warehouse'],
    'tableau': ['analytics', 'bi', 'dashboards'],
    'looker': ['analytics', 'bi', 'dashboards'],
    'power bi': ['analytics', 'bi', 'dashboards'],
    'jira': ['issue tracking', 'agile'],
    'azure devops': ['issue tracking', 'agile'],
    'linear': ['issue tracking', 'agile'],
    'confluence': ['knowledge base', 'content'],
    'notion': ['knowledge base', 'content'],
    'productboard': ['roadmap', 'feedback'],
    'aha': ['roadmap', 'feedback'],
    'pendo': ['digital adoption', 'in-app', 'javascript', 'sdk'],
    'walkme': ['digital adoption', 'in-app'],
    'appcues': ['digital adoption', 'in-app'],
    'sap': ['erp', 'financial', 'back office'],
    'netsuite': ['erp', 'financial', 'back office'],
    'workday': ['erp', 'financial', 'back office'],
    'docebo': ['learning', 'lms'],
    'cornerstone': ['learning', 'lms'],
  };
  
  functionalAreas.forEach(area => {
    const areaLower = area.name.toLowerCase();
    let isMatch = false;
    
    // Direct name match
    if (areaLower.includes(techLower) || techLower.includes(areaLower.split(' ')[0])) {
      isMatch = true;
    }
    
    // Keyword-based matching
    for (const [keyword, areaKeywords] of Object.entries(techKeywords)) {
      if (techLower.includes(keyword)) {
        if (areaKeywords.some(ak => areaLower.includes(ak))) {
          isMatch = true;
          break;
        }
      }
    }
    
    if (isMatch) {
      matched.push(area);
    } else {
      unmatched.push(area);
    }
  });
  
  return { matched, unmatched };
};

// Technology chip with functional area click/selection (using Popover for reliable click handling)
interface TechWithAreaMatchProps {
  tech: ExtractedTech;
  functionalAreas: FunctionalAreaOption[];
  onAreaSelect?: (techName: string, areaId: string, areaName: string, layer: string) => void;
  onSuppress?: (techName: string) => void;
  onUnlink?: (techId: string, techName: string) => void;
  isAdding?: boolean;
  isSuppressing?: boolean;
  isUnlinking?: boolean;
  isInArchitecture?: boolean;
  techId?: string; // ID in account_technologies for unlinking
}

function TechWithAreaMatch({ tech, functionalAreas, onAreaSelect, onSuppress, onUnlink, isAdding, isSuppressing, isUnlinking, isInArchitecture, techId }: TechWithAreaMatchProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { matched, unmatched } = useMemo(
    () => matchTechToFunctionalAreas(tech.name, functionalAreas),
    [tech.name, functionalAreas]
  );
  
  const hasAutoMatch = matched.length > 0;
  
  // Fetch layer info for functional areas
  const { data: areasWithLayer } = useQuery({
    queryKey: ['functional-areas-with-layer'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('functional_areas')
        .select('id, name, layer');
      if (error) throw error;
      return data as { id: string; name: string; layer: string }[];
    },
  });
  
  const getLayerForArea = (areaId: string): string => {
    const area = areasWithLayer?.find(a => a.id === areaId);
    return area?.layer || 'adopt';
  };

  const handleSelectArea = (areaId: string, areaName: string) => {
    const layer = getLayerForArea(areaId);
    onAreaSelect?.(tech.name, areaId, areaName, layer);
    setIsOpen(false);
  };

  const handleSuppress = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    onSuppress?.(tech.name);
  };
  
  const handleUnlink = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (techId) {
      onUnlink?.(techId, tech.name);
    }
  };

  // If already in architecture, show a simpler chip with unlink option
  if (isInArchitecture) {
    return (
      <div className="inline-flex items-center gap-0.5">
        <div 
          className={cn(
            "inline-flex items-center gap-2 px-3 py-1.5 rounded-l-full border text-sm",
            "bg-primary/10 border-primary/30",
            isUnlinking && "opacity-50"
          )}
        >
          <Check className="w-3 h-3 text-primary" />
          <span className="font-medium">{tech.name}</span>
          <span 
            className="text-xs px-1.5 py-0.5 rounded-full"
            style={{ 
              backgroundColor: getConfidenceColor(tech.confidence),
              color: 'white'
            }}
          >
            {Math.round(tech.confidence * 100)}%
          </span>
          <Badge variant="outline" className="text-[10px] px-1 py-0 bg-primary/5 text-primary border-primary/20">
            In Architecture
          </Badge>
        </div>
        {/* Unlink button */}
        <button
          type="button"
          onClick={handleUnlink}
          disabled={isUnlinking}
          className={cn(
            "inline-flex items-center justify-center w-6 h-8 rounded-r-full border border-l-0 text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors",
            "border-primary/30 bg-primary/5",
            isUnlinking && "opacity-50 pointer-events-none"
          )}
          title={`Remove ${tech.name} from architecture`}
        >
          <X className="w-3 h-3" />
        </button>
      </div>
    );
  }
  
  return (
    <div className="inline-flex items-center gap-0.5">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <div 
            className={cn(
              "inline-flex items-center gap-2 px-3 py-1.5 rounded-l-full border text-sm cursor-pointer transition-all hover:scale-105",
              hasAutoMatch && "ring-1 ring-primary/30",
              (isAdding || isSuppressing) && "opacity-50 pointer-events-none"
            )}
            style={{
              borderColor: getConfidenceColor(tech.confidence),
              backgroundColor: `${getConfidenceColor(tech.confidence)}15`,
            }}
          >
            <span className="font-medium">{tech.name}</span>
            <span 
              className="text-xs px-1.5 py-0.5 rounded-full"
              style={{ 
                backgroundColor: getConfidenceColor(tech.confidence),
                color: 'white'
              }}
            >
              {Math.round(tech.confidence * 100)}%
            </span>
            {hasAutoMatch && (
              <Check className="w-3 h-3 text-primary" />
            )}
          </div>
        </PopoverTrigger>
        <PopoverContent className="w-80 p-0" align="start" sideOffset={5}>
          <div className="p-3 border-b border-border">
            <div className="font-semibold text-sm">{tech.name}</div>
            <div className="text-xs text-muted-foreground mt-1">
              Confidence: {Math.round(tech.confidence * 100)}%
              {tech.context && <span className="ml-2">• {tech.context}</span>}
            </div>
          </div>
          <div className="p-3">
            <div className="text-xs font-medium text-muted-foreground mb-2">
              Select functional area to add to architecture
            </div>
            <ScrollArea className="h-[200px]">
              <div className="space-y-1">
                {/* Auto-matched areas - clickable to add */}
                {matched.map(area => (
                  <Button
                    key={area.id}
                    variant="ghost"
                    size="sm"
                    className="w-full justify-between py-1.5 px-2 h-auto bg-primary/10 hover:bg-primary/20"
                    onClick={() => handleSelectArea(area.id, area.name)}
                  >
                    <span className="text-sm">{area.name}</span>
                    <div className="flex items-center gap-1">
                      <Check className="w-4 h-4 text-primary" />
                      <Plus className="w-3 h-3 text-primary" />
                    </div>
                  </Button>
                ))}
                {/* Unmatched areas - clickable to add */}
                {unmatched.map(area => (
                  <Button
                    key={area.id}
                    variant="ghost"
                    size="sm"
                    className="w-full justify-between py-1.5 px-2 h-auto hover:bg-muted/50"
                    onClick={() => handleSelectArea(area.id, area.name)}
                  >
                    <span className="text-sm text-muted-foreground">{area.name}</span>
                    <div className="flex items-center gap-1 text-primary">
                      <Plus className="w-3 h-3" />
                      <span className="text-xs">Add</span>
                    </div>
                  </Button>
                ))}
              </div>
            </ScrollArea>
          </div>
          <div className="p-2 border-t border-border bg-muted/30 text-center">
            <span className="text-xs text-muted-foreground">
              Click an area to add this technology
            </span>
          </div>
        </PopoverContent>
      </Popover>
      {/* Suppress button (hide from future extractions) */}
      <button
        type="button"
        onClick={handleSuppress}
        disabled={isSuppressing}
        className={cn(
          "inline-flex items-center justify-center w-6 h-full rounded-r-full border border-l-0 text-muted-foreground hover:text-amber-600 hover:bg-amber-500/10 transition-colors",
          isSuppressing && "opacity-50 pointer-events-none"
        )}
        style={{
          borderColor: getConfidenceColor(tech.confidence),
          backgroundColor: `${getConfidenceColor(tech.confidence)}10`,
        }}
        title={`Suppress ${tech.name} (hide from extracted technologies)`}
      >
        <EyeOff className="w-3 h-3" />
      </button>
    </div>
  );
}

// SWOT category colors - light theme compatible
const swotColors = {
  strengths: { bg: 'hsl(142, 70%, 40%)', light: 'hsl(142, 50%, 94%)', text: 'hsl(142, 70%, 25%)' },
  weaknesses: { bg: 'hsl(0, 70%, 45%)', light: 'hsl(0, 50%, 95%)', text: 'hsl(0, 70%, 30%)' },
  opportunities: { bg: 'hsl(199, 89%, 48%)', light: 'hsl(199, 50%, 94%)', text: 'hsl(199, 89%, 30%)' },
  threats: { bg: 'hsl(25, 80%, 45%)', light: 'hsl(25, 50%, 94%)', text: 'hsl(25, 80%, 30%)' },
};

// SWOT Cluster Chart Component
function SwotClusterChart({ swot }: { swot: SwotAnalysis }) {
  const [hoveredItem, setHoveredItem] = useState<{ category: string; item: SwotItem } | null>(null);
  
  const totalItems = swot.strengths.length + swot.weaknesses.length + swot.opportunities.length + swot.threats.length;
  
  const chartWidth = 600;
  const chartHeight = 400;
  const quadrantWidth = chartWidth / 2;
  const quadrantHeight = chartHeight / 2;

  // Memoize cluster positions to prevent recalculation on hover
  const clusters = useMemo(() => {
    if (totalItems === 0) return null;

    // Seeded random for consistent positions
    const seededRandom = (seed: number) => {
      const x = Math.sin(seed) * 10000;
      return x - Math.floor(x);
    };

    const getClusterPositions = (items: SwotItem[], centerX: number, centerY: number, radius: number, seedOffset: number) => {
      return items.map((item, idx) => {
        const seed = seedOffset + idx * 17;
        const angle = (idx / Math.max(items.length, 1)) * Math.PI * 0.8 - Math.PI * 0.4;
        const distance = radius * (0.3 + seededRandom(seed) * 0.6);
        return {
          item,
          x: centerX + Math.cos(angle) * distance,
          y: centerY + Math.sin(angle) * distance,
          size: item.importance === 'high' ? 40 : item.importance === 'medium' ? 30 : 20,
        };
      });
    };

    return {
      strengths: getClusterPositions(swot.strengths, quadrantWidth * 0.5, quadrantHeight * 0.5, 80, 100),
      weaknesses: getClusterPositions(swot.weaknesses, quadrantWidth * 1.5, quadrantHeight * 0.5, 80, 200),
      opportunities: getClusterPositions(swot.opportunities, quadrantWidth * 0.5, quadrantHeight * 1.5, 80, 300),
      threats: getClusterPositions(swot.threats, quadrantWidth * 1.5, quadrantHeight * 1.5, 80, 400),
    };
  }, [swot, totalItems, quadrantWidth, quadrantHeight]);
  
  if (totalItems === 0 || !clusters) {
    return (
      <div className="flex items-center justify-center h-[400px] text-muted-foreground">
        No SWOT data available
      </div>
    );
  }

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-[400px]">
        {/* Quadrant backgrounds */}
        <rect x="0" y="0" width={quadrantWidth} height={quadrantHeight} fill={swotColors.strengths.light} />
        <rect x={quadrantWidth} y="0" width={quadrantWidth} height={quadrantHeight} fill={swotColors.weaknesses.light} />
        <rect x="0" y={quadrantHeight} width={quadrantWidth} height={quadrantHeight} fill={swotColors.opportunities.light} />
        <rect x={quadrantWidth} y={quadrantHeight} width={quadrantWidth} height={quadrantHeight} fill={swotColors.threats.light} />
        
        {/* Quadrant dividers */}
        <line x1={quadrantWidth} y1="0" x2={quadrantWidth} y2={chartHeight} stroke="hsl(var(--border))" strokeWidth="2" />
        <line x1="0" y1={quadrantHeight} x2={chartWidth} y2={quadrantHeight} stroke="hsl(var(--border))" strokeWidth="2" />
        
        {/* Labels */}
        <text x="20" y="30" fontSize="14" fontWeight="600" fill={swotColors.strengths.text}>Strengths ({swot.strengths.length})</text>
        <text x={quadrantWidth + 20} y="30" fontSize="14" fontWeight="600" fill={swotColors.weaknesses.text}>Weaknesses ({swot.weaknesses.length})</text>
        <text x="20" y={quadrantHeight + 30} fontSize="14" fontWeight="600" fill={swotColors.opportunities.text}>Opportunities ({swot.opportunities.length})</text>
        <text x={quadrantWidth + 20} y={quadrantHeight + 30} fontSize="14" fontWeight="600" fill={swotColors.threats.text}>Threats ({swot.threats.length})</text>
        
        {/* Cluster bubbles */}
        {Object.entries(clusters).map(([category, positions]) => 
          positions.map((pos, idx) => (
            <g key={`${category}-${idx}`}>
              <circle
                cx={pos.x}
                cy={pos.y}
                r={pos.size / 2}
                fill={swotColors[category as keyof typeof swotColors].bg}
                opacity={0.7}
                className="cursor-pointer transition-all duration-200 hover:opacity-100"
                onMouseEnter={() => setHoveredItem({ category, item: pos.item })}
                onMouseLeave={() => setHoveredItem(null)}
              />
              <text
                x={pos.x}
                y={pos.y}
                textAnchor="middle"
                dominantBaseline="central"
                fontSize="10"
                fill="white"
                className="pointer-events-none"
              >
                {idx + 1}
              </text>
            </g>
          ))
        )}
        
        {/* Axis labels */}
        <text x={chartWidth / 2} y="15" textAnchor="middle" fontSize="11" fill="hsl(var(--muted-foreground))">Internal ↔ External</text>
        <text x="10" y={chartHeight / 2} textAnchor="start" fontSize="11" fill="hsl(var(--muted-foreground))" transform={`rotate(-90 10 ${chartHeight / 2})`}>Positive ↔ Negative</text>
      </svg>
      
      {/* Tooltip */}
      {hoveredItem && (
        <div className="absolute top-4 right-4 max-w-[250px] p-3 rounded-lg shadow-lg border border-border bg-background z-10">
          <div 
            className="text-xs font-semibold uppercase mb-1"
            style={{ color: swotColors[hoveredItem.category as keyof typeof swotColors].bg }}
          >
            {hoveredItem.category}
          </div>
          <p className="text-sm">{hoveredItem.item.text}</p>
          <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
            <span>Source: {hoveredItem.item.source}</span>
            <Badge variant="outline" className="text-xs py-0">
              {hoveredItem.item.importance}
            </Badge>
          </div>
        </div>
      )}
    </div>
  );
}

// Extended SWOT item with ID for tracking
interface SwotItemWithId extends SwotItem {
  id: string;
}

type SwotItemStatus = 'pending' | 'accepted' | 'rejected';

interface SwotGridProps {
  swot: SwotAnalysis;
  acceptedItems: Set<string>;
  rejectedItems: Set<string>;
  onAccept: (itemId: string) => void;
  onReject: (itemId: string) => void;
  onUndo: (itemId: string) => void;
}

// Generate a stable ID for a SWOT item
const generateSwotItemId = (category: string, item: SwotItem, index: number): string => {
  return `${category}-${index}-${item.text.substring(0, 30).replace(/\s+/g, '-')}`;
};

// SWOT Grid Component with accept/reject
function SwotGrid({ swot, acceptedItems, rejectedItems, onAccept, onReject, onUndo }: SwotGridProps) {
  const getItemStatus = (itemId: string): SwotItemStatus => {
    if (acceptedItems.has(itemId)) return 'accepted';
    if (rejectedItems.has(itemId)) return 'rejected';
    return 'pending';
  };

  const renderQuadrant = (
    title: string, 
    items: SwotItem[], 
    icon: React.ReactNode, 
    colorKey: keyof typeof swotColors
  ) => {
    // Filter out rejected items but keep accepted and pending
    const visibleItems = items.map((item, i) => ({
      ...item,
      id: generateSwotItemId(colorKey, item, i),
    })).filter(item => !rejectedItems.has(item.id));

    const acceptedCount = visibleItems.filter(item => acceptedItems.has(item.id)).length;
    const pendingCount = visibleItems.filter(item => !acceptedItems.has(item.id)).length;

    return (
      <div 
        className="p-4 rounded-lg"
        style={{ backgroundColor: swotColors[colorKey].light }}
      >
        <h4 
          className="font-semibold flex items-center gap-2 mb-3"
          style={{ color: swotColors[colorKey].text }}
        >
          {icon}
          {title} ({visibleItems.length})
          {acceptedCount > 0 && (
            <Badge variant="outline" className="text-xs py-0 border-green-500 text-green-500 ml-auto">
              {acceptedCount} accepted
            </Badge>
          )}
        </h4>
        {visibleItems.length === 0 ? (
          <p className="text-sm text-muted-foreground italic">No items identified</p>
        ) : (
          <ul className="space-y-2">
            {visibleItems.map((item) => {
              const status = getItemStatus(item.id);
              return (
                <li 
                  key={item.id} 
                  className={cn(
                    "flex items-start gap-2 text-sm p-2 rounded-md transition-all",
                    status === 'accepted' && "bg-green-500/10 border border-green-500/30",
                    status === 'pending' && "hover:bg-background/50"
                  )}
                >
                  {item.insightType === 'stakeholder_dynamics' ? (
                    <Users className="w-3.5 h-3.5 mt-1 flex-shrink-0 text-muted-foreground" />
                  ) : (
                    <span 
                      className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0"
                      style={{ backgroundColor: swotColors[colorKey].bg }}
                    />
                  )}
                  <div className="flex-1 min-w-0">
                    <span className={cn(status === 'accepted' && "font-medium")}>{item.text}</span>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "text-xs py-0",
                          item.importance === 'high' && 'border-destructive text-destructive',
                          item.importance === 'medium' && 'border-yellow-500 text-yellow-500',
                          item.importance === 'low' && 'border-muted-foreground text-muted-foreground'
                        )}
                      >
                        {item.importance}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{item.source}</span>
                      {status === 'accepted' && (
                        <Badge variant="outline" className="text-xs py-0 border-green-500 text-green-500">
                          <Check className="w-3 h-3 mr-1" />
                          Accepted
                        </Badge>
                      )}
                    </div>
                  </div>
                  {/* Accept/Reject buttons */}
                  <div className="flex items-center gap-1 flex-shrink-0">
                    {status === 'pending' ? (
                      <>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 hover:bg-green-500/20 hover:text-green-500"
                          onClick={() => onAccept(item.id)}
                          title="Accept suggestion"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 hover:bg-destructive/20 hover:text-destructive"
                          onClick={() => onReject(item.id)}
                          title="Reject suggestion"
                        >
                          <X className="w-3.5 h-3.5" />
                        </Button>
                      </>
                    ) : (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 text-xs text-muted-foreground hover:text-foreground"
                        onClick={() => onUndo(item.id)}
                      >
                        Undo
                      </Button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-2 gap-4">
      {renderQuadrant('Strengths', swot.strengths, <TrendingUp className="w-4 h-4" />, 'strengths')}
      {renderQuadrant('Weaknesses', swot.weaknesses, <TrendingDown className="w-4 h-4" />, 'weaknesses')}
      {renderQuadrant('Opportunities', swot.opportunities, <Target className="w-4 h-4" />, 'opportunities')}
      {renderQuadrant('Threats', swot.threats, <AlertCircle className="w-4 h-4" />, 'threats')}
    </div>
  );
}

export function AccountInsightsTab({ accountId }: AccountInsightsTabProps) {
  const [insightsView, setInsightsView] = useState<'overview' | 'swot'>('overview');
  
  // SWOT accept/reject state - persisted per account
  const [acceptedSwotItems, setAcceptedSwotItems] = useState<Set<string>>(() => {
    const saved = localStorage.getItem(`swot-accepted-${accountId}`);
    return saved ? new Set(JSON.parse(saved)) : new Set();
  });
  const [rejectedSwotItems, setRejectedSwotItems] = useState<Set<string>>(() => {
    const saved = localStorage.getItem(`swot-rejected-${accountId}`);
    return saved ? new Set(JSON.parse(saved)) : new Set();
  });

  const handleAcceptSwotItem = (itemId: string) => {
    setAcceptedSwotItems(prev => {
      const next = new Set(prev);
      next.add(itemId);
      localStorage.setItem(`swot-accepted-${accountId}`, JSON.stringify([...next]));
      return next;
    });
    setRejectedSwotItems(prev => {
      const next = new Set(prev);
      next.delete(itemId);
      localStorage.setItem(`swot-rejected-${accountId}`, JSON.stringify([...next]));
      return next;
    });
    toast.success('Suggestion accepted');
  };

  const handleRejectSwotItem = (itemId: string) => {
    setRejectedSwotItems(prev => {
      const next = new Set(prev);
      next.add(itemId);
      localStorage.setItem(`swot-rejected-${accountId}`, JSON.stringify([...next]));
      return next;
    });
    setAcceptedSwotItems(prev => {
      const next = new Set(prev);
      next.delete(itemId);
      localStorage.setItem(`swot-accepted-${accountId}`, JSON.stringify([...next]));
      return next;
    });
    toast.success('Suggestion rejected');
  };

  const handleUndoSwotItem = (itemId: string) => {
    setAcceptedSwotItems(prev => {
      const next = new Set(prev);
      next.delete(itemId);
      localStorage.setItem(`swot-accepted-${accountId}`, JSON.stringify([...next]));
      return next;
    });
    setRejectedSwotItems(prev => {
      const next = new Set(prev);
      next.delete(itemId);
      localStorage.setItem(`swot-rejected-${accountId}`, JSON.stringify([...next]));
      return next;
    });
  };

  // Fetch transcript reviews for this account
  const { data: transcriptReviews, isLoading, refetch: refetchTranscripts } = useQuery({
    queryKey: ['account-transcript-insights', accountId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transcript_reviews')
        .select('id, extracted_technologies, extracted_insights, file_name, created_at')
        .eq('final_account_id', accountId)
        .eq('status', 'approved');
      
      if (error) throw error;
      return data;
    },
  });

  // Fetch functional areas for matching
  const { data: functionalAreas } = useQuery({
    queryKey: ['functional-areas-for-matching'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('functional_areas')
        .select('id, name')
        .order('name');
      
      if (error) throw error;
      return data as FunctionalAreaOption[];
    },
  });

  // Fetch stakeholders for SWOT integration - use gateway for decryption
  const { data: stakeholders } = useQuery({
    queryKey: ['stakeholder-swot', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_contacts')
        .select('id, name, role, influence_level, sentiment, champion_score, is_ignored, is_internal')
        .eq('account_id', accountId)
        .eq('is_ignored', false)
        .eq('is_internal', false)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
  });

  // Fetch key people - external stakeholders from account_contacts - use gateway for decryption
  const { data: keyExternalPeople } = useQuery({
    queryKey: ['key-external-people', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_contacts')
        .select('id, name, role, stakeholder_type, champion_score, influence_level')
        .eq('account_id', accountId)
        .eq('is_ignored', false)
        .eq('is_internal', false)
        .order('influence_level', { ascending: false })
        .limit(10)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
  });

  // Fetch key internal people - team members and opportunity owners
  const { data: keyInternalPeople } = useQuery({
    queryKey: ['key-internal-people', accountId],
    queryFn: async () => {
      // Get account team members
      const { data: teamMembers, error: teamError } = await supabase
        .from('account_team_members')
        .select('team_member_email, role')
        .eq('account_id', accountId);
      
      if (teamError) throw teamError;

      // Get opportunity owners (primary SEs and AEs)
      const { data: opportunities, error: oppError } = await supabase
        .from('opportunities')
        .select('primary_se_email, owner_email')
        .eq('account_id', accountId);
      
      if (oppError) throw oppError;

      // Get profiles for team member emails
      const emails = new Set<string>();
      teamMembers?.forEach(m => emails.add(m.team_member_email));
      opportunities?.forEach(o => {
        if (o.primary_se_email) emails.add(o.primary_se_email);
        if (o.owner_email) emails.add(o.owner_email);
      });

      if (emails.size === 0) return [];

      const { data: profiles, error: profileError } = await supabase
        .from('profiles')
        .select('email, full_name')
        .in('email', Array.from(emails));
      
      if (profileError) throw profileError;

      // Build the internal people list with roles
      const profileMap = new Map(profiles?.map(p => [p.email, p.full_name]) || []);
      const teamMemberRoles = new Map(teamMembers?.map(m => [m.team_member_email, m.role]) || []);
      
      const internalPeople: Array<{ email: string; name: string; role: string }> = [];
      const seenEmails = new Set<string>();

      // Add opportunity owners first (most important)
      opportunities?.forEach(o => {
        if (o.primary_se_email && !seenEmails.has(o.primary_se_email)) {
          seenEmails.add(o.primary_se_email);
          internalPeople.push({
            email: o.primary_se_email,
            name: profileMap.get(o.primary_se_email) || o.primary_se_email.split('@')[0],
            role: 'Solutions Engineer'
          });
        }
        if (o.owner_email && !seenEmails.has(o.owner_email)) {
          seenEmails.add(o.owner_email);
          internalPeople.push({
            email: o.owner_email,
            name: profileMap.get(o.owner_email) || o.owner_email.split('@')[0],
            role: 'Account Executive'
          });
        }
      });

      // Add team members with their roles
      teamMembers?.forEach(m => {
        if (!seenEmails.has(m.team_member_email)) {
          seenEmails.add(m.team_member_email);
          internalPeople.push({
            email: m.team_member_email,
            name: profileMap.get(m.team_member_email) || m.team_member_email.split('@')[0],
            role: m.role || 'Team Member'
          });
        }
      });

      return internalPeople.slice(0, 6); // Limit to top 6 internal people
    },
  });

  const createTechnology = useCreateAccountTechnology();
  const deleteTechnology = useDeleteAccountTechnology();
  const queryClient = useQueryClient();
  const [addingTech, setAddingTech] = useState<string | null>(null);
  const [suppressingTech, setSuppressingTech] = useState<string | null>(null);
  const [unlinkingTech, setUnlinkingTech] = useState<string | null>(null);
  const [acceptedOpen, setAcceptedOpen] = useState(true);
  const [suggestedOpen, setSuggestedOpen] = useState(true);
  
  // Fetch suppressed technologies for this account
  const { data: suppressedTechnologies } = useSuppressedTechnologies(accountId);
  const suppressTech = useSuppressTechnology();
  
  // Fetch per-transcript rejections for this account
  const { data: rejectedDetections } = useRejectedTechnologyDetections(accountId);
  const rejectTech = useRejectTechnologyDetection();
  const [rejectingTech, setRejectingTech] = useState<string | null>(null);
  
  // Fetch technologies already in architecture (include repository_tech_id for competitor detection)
  // NOTE: must go through the authenticated gateway (this app uses custom auth tokens,
  // not the native DB auth session), otherwise RLS will return an empty list.
  const { data: accountTechnologies } = useQuery({
    queryKey: ['account-technologies', accountId],
    queryFn: async () => {
      const result = await gateway
        .from('account_technologies')
        .select('id, name, repository_tech_id')
        .eq('account_id', accountId)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return (result.data || []) as Array<{ id: string; name: string; repository_tech_id: string | null }>;
    },
    enabled: !!accountId,
  });
  
  // Fetch competitor technologies from the repository
  const { data: competitorTechs } = useQuery({
    queryKey: ['competitor-technologies'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('technology_repository')
        .select('id, name')
        .eq('is_competitor', true);
      if (error) throw error;
      return (data || []) as Array<{ id: string; name: string }>;
    },
  });
  
  // Check if a technology is already in the architecture
  const isInArchitecture = (techName: string): boolean => {
    return accountTechnologies?.some(t => t.name.toLowerCase() === techName.toLowerCase()) || false;
  };
  
  // Get the account_technologies ID for a tech by name
  const getAccountTechId = (techName: string): string | undefined => {
    return accountTechnologies?.find(t => t.name.toLowerCase() === techName.toLowerCase())?.id;
  };

  // Handler for when user selects a functional area for a technology
  const handleAreaSelect = async (techName: string, areaId: string, areaName: string, layer: string) => {
    setAddingTech(techName);
    try {
      await createTechnology.mutateAsync({
        account_id: accountId,
        name: techName,
        layer: layer,
        category: areaName,
        notes: null,
        status: 'confirmed',
      });
      toast.success(`Added ${techName} to ${areaName}`);
      // Invalidate account technologies query to refresh the architecture canvas
      queryClient.invalidateQueries({ queryKey: ['account-technologies', accountId] });
    } catch (error) {
      console.error('Failed to add technology:', error);
      toast.error(`Failed to add ${techName}`);
    } finally {
      setAddingTech(null);
    }
  };

  // Handler for suppressing a technology (hide from extracted list)
  const handleSuppressTech = async (techName: string) => {
    setSuppressingTech(techName);
    try {
      await suppressTech.mutateAsync({ accountId, technologyName: techName });
    } catch (error) {
      console.error('Failed to suppress technology:', error);
    } finally {
      setSuppressingTech(null);
    }
  };
  
  // Handler for unlinking a technology from architecture
  const handleUnlinkTech = async (techId: string, techName: string) => {
    setUnlinkingTech(techName);
    try {
      await deleteTechnology.mutateAsync({ id: techId, accountId });
      toast.success(`Removed ${techName} from architecture`);
      queryClient.invalidateQueries({ queryKey: ['account-technologies', accountId] });
    } catch (error) {
      console.error('Failed to unlink technology:', error);
      toast.error(`Failed to remove ${techName}`);
    } finally {
      setUnlinkingTech(null);
    }
  };

  // Handler for rejecting a technology suggestion (per-transcript)
  const handleRejectTech = async (techName: string, sourceTranscriptId: string | undefined, repositoryTechId?: string | null) => {
    if (!sourceTranscriptId) {
      toast.error('Cannot reject: no source transcript found');
      return;
    }
    setRejectingTech(techName);
    try {
      await rejectTech.mutateAsync({
        accountId,
        transcriptId: sourceTranscriptId,
        repositoryTechId,
        detectedName: techName,
      });
    } catch (error) {
      console.error('Failed to reject technology:', error);
    } finally {
      setRejectingTech(null);
    }
  };
  
  // Handler for adding a technology manually from the popover
  const handleAddManualTechnology = async (tech: { name: string; repositoryTechId?: string; layer?: string; category?: string }) => {
    setAddingTech(tech.name);
    try {
      await createTechnology.mutateAsync({
        account_id: accountId,
        name: tech.name,
        layer: tech.layer || 'adopt',
        category: tech.category || 'Other',
        notes: null,
        status: 'confirmed',
        repository_tech_id: tech.repositoryTechId || null,
      });
      toast.success(`Added ${tech.name} to architecture`);
      queryClient.invalidateQueries({ queryKey: ['account-technologies', accountId] });
    } catch (error) {
      console.error('Failed to add technology:', error);
      toast.error(`Failed to add ${tech.name}`);
    } finally {
      setAddingTech(null);
    }
  };

  // Extract competitor names from transcripts + architecture for competitive analysis
  const competitorNames = useMemo(() => {
    const names = new Set<string>();
    
    // From transcript mentions
    transcriptReviews?.forEach(review => {
      const insights = (review.extracted_insights as unknown as TranscriptInsights) || {} as TranscriptInsights;
      const mentions = insights.competitorMentions || [];
      mentions.forEach(m => names.add(m));
    });
    
    // From architecture - technologies that are marked as competitors in repository
    if (accountTechnologies && competitorTechs) {
      const competitorNameSet = new Set(competitorTechs.map(c => c.name.toLowerCase()));
      accountTechnologies.forEach(at => {
        if (competitorNameSet.has(at.name.toLowerCase())) {
          names.add(at.name);
        }
      });
    }
    
    return Array.from(names);
  }, [transcriptReviews, accountTechnologies, competitorTechs]);

  // Fetch competitive analysis based on mentioned competitors
  const { data: competitiveData } = useCompetitiveAnalysis(competitorNames);

  // Aggregate insights from all transcripts
  const aggregatedInsights = useMemo(() => {
    if (!transcriptReviews || transcriptReviews.length === 0) {
      return null;
    }

    const technologies: Map<string, ExtractedTech> = new Map();
    const painPoints: Set<string> = new Set();
    const useCases: Set<string> = new Set();
    const competitorMentions: Set<string> = new Set();
    const people: Map<string, ExtractedPerson> = new Map();
    const nbas: NextBestAction[] = [];
    const commercialInsights: CommercialInsight[] = [];

    transcriptReviews.forEach(review => {
      // Aggregate technologies - keep highest confidence but track all source transcripts
      const techs = (review.extracted_technologies as unknown as ExtractedTech[]) || [];
      techs.forEach(tech => {
        if (!tech || !tech.name) return;
        const existing = technologies.get(tech.name);
        if (!existing || tech.confidence > existing.confidence) {
          technologies.set(tech.name, {
            ...tech,
            sourceTranscriptId: review.id, // Track source transcript for rejection matching
          });
        }
      });

      // Aggregate insights
      const insights = (review.extracted_insights as unknown as TranscriptInsights) || {} as TranscriptInsights;
      
      const insightPainPoints = insights.painPoints || [];
      const insightUseCases = insights.useCases || [];
      const insightCompetitors = insights.competitorMentions || [];
      const insightPeople = insights.people || [];
      const insightNbas = insights.nbas || [];
      const insightCommercial = insights.commercialInsights || [];
      
      // Handle both string and object formats for pain points
      insightPainPoints.forEach((pp) => {
        const text = typeof pp === 'string'
          ? pp
          : (pp?.description || (pp as any)?.painPoint || pp?.pain_point || '');
        if (text) painPoints.add(text);
      });
      // Handle both string and object formats for use cases
      insightUseCases.forEach((uc) => {
        const text = typeof uc === 'string'
          ? uc
          : (uc?.description || (uc as any)?.useCase || uc?.use_case || '');
        if (text) useCases.add(text);
      });
      insightCompetitors.forEach(cm => competitorMentions.add(cm));
      
      insightPeople.forEach(person => {
        if (person && person.name && !people.has(person.name)) {
          people.set(person.name, person);
        }
      });

      insightNbas.forEach(nba => {
        // Avoid duplicates based on action text
        if (nba && nba.action && !nbas.some(existing => existing.action === nba.action)) {
          nbas.push(nba);
        }
      });

      // Aggregate commercial insights - avoid duplicates by insight text
      insightCommercial.forEach(ci => {
        if (ci && ci.insight && !commercialInsights.some(existing => existing.insight === ci.insight)) {
          commercialInsights.push(ci);
        }
      });
    });

    // Sort technologies by confidence
    const sortedTechnologies = Array.from(technologies.values())
      .sort((a, b) => b.confidence - a.confidence);

    return {
      technologies: sortedTechnologies,
      painPoints: Array.from(painPoints),
      useCases: Array.from(useCases),
      competitorMentions: Array.from(competitorMentions),
      people: Array.from(people.values()),
      nbas,
      commercialInsights,
      transcriptCount: transcriptReviews.length,
    };
  }, [transcriptReviews]);

  // Generate SWOT analysis from aggregated insights + competitive intelligence
  const swotAnalysis = useMemo((): SwotAnalysis => {
    if (!aggregatedInsights) {
      return { strengths: [], weaknesses: [], opportunities: [], threats: [] };
    }

    const strengths: SwotItem[] = [];
    const weaknesses: SwotItem[] = [];
    const opportunities: SwotItem[] = [];
    const threats: SwotItem[] = [];

    // === COMPETITIVE INTELLIGENCE ENRICHMENT ===
    
    // Pendo's competitive strengths (where we beat mentioned competitors)
    if (competitiveData?.strengths) {
      competitiveData.strengths.slice(0, 5).forEach((comp: FeatureComparison) => {
        strengths.push({
          text: `${comp.featureName}: Pendo scores ${comp.pendoScore}/5 vs ${comp.competitorName}'s ${comp.competitorScore}/5 (+${comp.pendoAdvantage} advantage)`,
          source: `Competitive Analysis - ${comp.categoryName}`,
          importance: comp.pendoAdvantage >= 3 ? 'high' : 'medium',
        });
      });
    }

    // Competitive threats (where competitors beat Pendo)
    if (competitiveData?.threats) {
      competitiveData.threats.slice(0, 5).forEach((comp: FeatureComparison) => {
        threats.push({
          text: `${comp.competitorName} leads in ${comp.featureName} (${comp.competitorScore}/5 vs Pendo's ${comp.pendoScore}/5)`,
          source: `Competitive Analysis - ${comp.categoryName}`,
          importance: comp.pendoAdvantage <= -3 ? 'high' : 'medium',
        });
      });
    }

    // Feature parity opportunities (where Pendo can differentiate)
    if (competitiveData?.opportunities) {
      competitiveData.opportunities.slice(0, 3).forEach((comp: FeatureComparison) => {
        opportunities.push({
          text: `Opportunity to demonstrate ${comp.featureName} - Pendo at ${comp.pendoScore}/5, room to showcase ${getMaturityDescription(comp.pendoScore, comp)} capabilities`,
          source: `Competitive Positioning - ${comp.categoryName}`,
          importance: 'medium',
        });
      });
    }

    // === EXISTING SWOT LOGIC ===

    // Technologies with high confidence - check if competitor or regular tech
    aggregatedInsights.technologies
      .filter(t => t.confidence >= 0.8)
      .forEach(tech => {
        // Check if this technology is a mentioned competitor
        const isCompetitor = aggregatedInsights.competitorMentions.some(
          comp => tech.name.toLowerCase().includes(comp.toLowerCase()) ||
                  comp.toLowerCase().includes(tech.name.toLowerCase())
        ) || competitiveData?.threats?.some(
          (t: FeatureComparison) => tech.name.toLowerCase().includes(t.competitorName.toLowerCase())
        );

        if (isCompetitor) {
          // Customer knowing competitor well is a THREAT
          threats.push({
            text: `Customer has strong understanding of ${tech.name}`,
            source: 'Competitive Intelligence',
            importance: tech.confidence >= 0.95 ? 'high' : 'medium',
          });
        } else {
          // Understanding their non-competitor tech stack is a strength (we know their environment)
          strengths.push({
            text: `Clear understanding of ${tech.name} in their stack`,
            source: 'Technology Analysis',
            importance: 'low',
          });
        }
      });

    // People with roles identified are strengths (relationship building)
    aggregatedInsights.people
      .filter(p => p.role)
      .slice(0, 5)
      .forEach(person => {
        strengths.push({
          text: `Known contact: ${person.name} (${person.role})`,
          source: 'Contact Intelligence',
          importance: person.role?.toLowerCase().includes('vp') || person.role?.toLowerCase().includes('director') ? 'high' : 'medium',
        });
      });

    // Pain points are opportunities (we can solve them)
    aggregatedInsights.painPoints.forEach((pp, i) => {
      opportunities.push({
        text: pp,
        source: 'Pain Point Analysis',
        importance: i < 2 ? 'high' : i < 5 ? 'medium' : 'low',
      });
    });

    // Use cases are opportunities
    aggregatedInsights.useCases.forEach((uc, i) => {
      opportunities.push({
        text: uc,
        source: 'Use Case Discovery',
        importance: i < 2 ? 'high' : 'medium',
      });
    });

    // Competitor mentions are threats (general mention - enriched above with specifics)
    aggregatedInsights.competitorMentions.forEach((comp, i) => {
      // Only add if we don't have competitive data (avoids duplication)
      if (!competitiveData?.threats?.some((t: FeatureComparison) => t.competitorName.toLowerCase().includes(comp.toLowerCase()))) {
        threats.push({
          text: `Competitor ${comp} mentioned in conversations`,
          source: 'Competitive Intelligence',
          importance: i === 0 ? 'high' : 'medium',
        });
      }
    });

    // Technologies with low confidence are weaknesses (unclear understanding)
    aggregatedInsights.technologies
      .filter(t => t.confidence < 0.6)
      .forEach(tech => {
        weaknesses.push({
          text: `Unclear about ${tech.name} - needs validation`,
          source: 'Technology Analysis',
          importance: 'low',
        });
      });

    // High priority NBAs that are technical could indicate gaps (weaknesses)
    aggregatedInsights.nbas
      .filter(nba => nba.priority === 'high' && nba.actionType === 'technical')
      .slice(0, 3)
      .forEach(nba => {
        weaknesses.push({
          text: `Technical gap: ${nba.action.substring(0, 80)}...`,
          source: 'Action Analysis',
          importance: 'high',
        });
      });

    // No key contacts = weakness
    if (aggregatedInsights.people.length === 0) {
      weaknesses.push({
        text: 'No key contacts identified yet',
        source: 'Contact Intelligence',
        importance: 'medium',
      });
    }

    // === COMMERCIAL INSIGHTS - AUTO-CATEGORIZED INTO SWOT ===
    const typeLabels: Record<string, string> = {
      'build_vs_buy': 'Build vs Buy',
      'budget_timing': 'Budget/Timing',
      'competitive_positioning': 'Competitive',
      'stakeholder_dynamics': 'Stakeholder',
    };

    aggregatedInsights.commercialInsights?.forEach(ci => {
      const swotItem: SwotItem = {
        text: ci.insight,
        source: `Commercial - ${typeLabels[ci.type] || ci.type}`,
        importance: ci.importance,
        insightType: ci.type,
      };

      switch (ci.swotCategory) {
        case 'strength':
          strengths.push(swotItem);
          break;
        case 'weakness':
          weaknesses.push(swotItem);
          break;
        case 'opportunity':
          opportunities.push(swotItem);
          break;
        case 'threat':
          threats.push(swotItem);
          break;
      }
    });

    // === STAKEHOLDER MAPPING INTEGRATION ===
    if (stakeholders && stakeholders.length > 0) {
      // Champions (high influence + positive sentiment) are STRENGTHS
      const champions = stakeholders.filter(s => 
        (s.influence_level ?? 50) >= 60 && (s.sentiment ?? 50) >= 60
      );
      champions.forEach(champion => {
        const championScore = champion.champion_score ?? 50;
        strengths.push({
          text: `Champion: ${champion.name}${champion.role ? ` (${champion.role})` : ''} - ${championScore}% champion score`,
          source: 'Stakeholder Map',
          importance: (champion.influence_level ?? 50) >= 80 || championScore >= 80 ? 'high' : 'medium',
          insightType: 'stakeholder_dynamics',
        });
      });

      // Blockers (high influence + negative sentiment) are THREATS
      const blockers = stakeholders.filter(s => 
        (s.influence_level ?? 50) >= 60 && (s.sentiment ?? 50) < 40
      );
      blockers.forEach(blocker => {
        threats.push({
          text: `Blocker: ${blocker.name}${blocker.role ? ` (${blocker.role})` : ''} - High influence with negative sentiment`,
          source: 'Stakeholder Map',
          importance: (blocker.influence_level ?? 50) >= 80 ? 'high' : 'medium',
          insightType: 'stakeholder_dynamics',
        });
      });

      // Supporters (low influence + positive sentiment) are OPPORTUNITIES
      const supporters = stakeholders.filter(s => 
        (s.influence_level ?? 50) < 50 && (s.sentiment ?? 50) >= 60
      );
      if (supporters.length > 0) {
        opportunities.push({
          text: `${supporters.length} supporter${supporters.length > 1 ? 's' : ''} with positive sentiment could be developed into champions`,
          source: 'Stakeholder Map',
          importance: supporters.length >= 3 ? 'high' : 'medium',
          insightType: 'stakeholder_dynamics',
        });
      }

      // Detractors (low influence + negative sentiment) are WEAKNESSES
      const detractors = stakeholders.filter(s => 
        (s.influence_level ?? 50) < 50 && (s.sentiment ?? 50) < 40
      );
      if (detractors.length > 0) {
        weaknesses.push({
          text: `${detractors.length} detractor${detractors.length > 1 ? 's' : ''} with negative sentiment may escalate issues`,
          source: 'Stakeholder Map',
          importance: detractors.length >= 3 ? 'medium' : 'low',
          insightType: 'stakeholder_dynamics',
        });
      }

      // Overall stakeholder coverage insights
      const avgChampionScore = stakeholders.reduce((acc, s) => acc + (s.champion_score ?? 50), 0) / stakeholders.length;
      if (avgChampionScore >= 70) {
        strengths.push({
          text: `Strong overall stakeholder engagement (${Math.round(avgChampionScore)}% avg champion score across ${stakeholders.length} contacts)`,
          source: 'Stakeholder Map',
          importance: 'medium',
          insightType: 'stakeholder_dynamics',
        });
      } else if (avgChampionScore < 40 && stakeholders.length >= 3) {
        weaknesses.push({
          text: `Low stakeholder engagement (${Math.round(avgChampionScore)}% avg champion score) - needs relationship building`,
          source: 'Stakeholder Map',
          importance: 'high',
          insightType: 'stakeholder_dynamics',
        });
      }

      // No champions identified is a weakness
      if (champions.length === 0 && stakeholders.length >= 3) {
        weaknesses.push({
          text: 'No clear champion identified among stakeholders',
          source: 'Stakeholder Map',
          importance: 'high',
          insightType: 'stakeholder_dynamics',
        });
      }
    }

    return { strengths, weaknesses, opportunities, threats };
  }, [aggregatedInsights, competitiveData, stakeholders]);

  // Get competitor techs from architecture to include in competitor mentions
  // IMPORTANT: These useMemo hooks MUST be before any early returns to follow React's rules of hooks
  const architectureCompetitorMentions = useMemo(() => {
    if (!accountTechnologies || !competitorTechs) return [];
    const competitorNameSet = new Set(competitorTechs.map(c => c.name.toLowerCase()));
    return accountTechnologies
      .filter(at => competitorNameSet.has(at.name.toLowerCase()))
      .map(at => at.name);
  }, [accountTechnologies, competitorTechs]);
  
  // Create aggregated insights, merging architecture competitors into competitorMentions
  const displayInsights = useMemo(() => {
    const baseInsights = aggregatedInsights || {
      technologies: [],
      painPoints: [],
      useCases: [],
      competitorMentions: [],
      people: [],
      nbas: [],
      commercialInsights: [],
      transcriptCount: 0,
    };
    
    // Merge architecture competitor mentions
    const allCompetitors = new Set([
      ...baseInsights.competitorMentions,
      ...architectureCompetitorMentions
    ]);
    
    return {
      ...baseInsights,
      competitorMentions: Array.from(allCompetitors),
    };
  }, [aggregatedInsights, architectureCompetitorMentions]);

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-32" />
        <Skeleton className="h-48" />
        <Skeleton className="h-32" />
      </div>
    );
  }

  // Show empty state only if no transcripts AND no architecture technologies
  const hasArchitectureTechnologies = (accountTechnologies?.length ?? 0) > 0;
  
  if (!aggregatedInsights && !hasArchitectureTechnologies) {
    return (
      <div className="p-6">
        <div className="glass rounded-xl p-8 text-center border-2 border-dashed border-border">
          <Database className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No analyzed transcripts for this account</p>
          <p className="text-sm text-muted-foreground mt-1">
            Upload and analyze transcripts to see extracted insights here
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Account Insights</h2>
          <p className="text-sm text-muted-foreground">
            {displayInsights.transcriptCount > 0 
              ? `Aggregated from ${displayInsights.transcriptCount} analyzed transcript${displayInsights.transcriptCount !== 1 ? 's' : ''}`
              : 'Technologies from architecture'}
          </p>
        </div>
        <Tabs value={insightsView} onValueChange={(v) => setInsightsView(v as 'overview' | 'swot')}>
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="swot">SWOT Analysis</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {insightsView === 'swot' ? (
        <div className="space-y-6">
          {/* SWOT Cluster Chart */}
          <div className="glass rounded-xl p-5">
            <h3 className="font-semibold text-foreground mb-4">SWOT Cluster Chart</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Hover over bubbles to see details. Size indicates importance.
            </p>
            <SwotClusterChart swot={swotAnalysis} />
          </div>

          {/* SWOT Grid */}
          <div className="glass rounded-xl p-5">
            <h3 className="font-semibold text-foreground mb-4">SWOT Details</h3>
            <SwotGrid 
              swot={swotAnalysis} 
              acceptedItems={acceptedSwotItems}
              rejectedItems={rejectedSwotItems}
              onAccept={handleAcceptSwotItem}
              onReject={handleRejectSwotItem}
              onUndo={handleUndoSwotItem}
            />
          </div>
        </div>
      ) : (
        <>
          {/* Themed Insights Panel - New enriched view */}
          <ThemedInsightsPanel accountId={accountId} />

          {/* Current vs Future State Section (legacy) */}
          {(displayInsights.painPoints && displayInsights.painPoints.length > 0) ||
           (displayInsights.useCases && displayInsights.useCases.length > 0) ? (
            <div className="glass rounded-xl p-5 space-y-4">
              <h3 className="font-semibold text-foreground flex items-center gap-2">
                <Layers className="w-4 h-4 text-primary" />
                Current vs Future State
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative">
                {/* Current State Card - Challenges & Pains */}
                <div className="bg-destructive/5 rounded-lg p-4 border border-destructive/20">
                  <div className="flex items-center gap-2 mb-3">
                    <AlertCircle className="w-4 h-4 text-destructive" />
                    <h4 className="font-medium text-sm">Current State — Challenges</h4>
                  </div>
                  
                  {displayInsights.painPoints && displayInsights.painPoints.length > 0 ? (
                    <ul className="space-y-2">
                      {displayInsights.painPoints.slice(0, 6).map((pain, idx) => (
                        <li key={idx} className="text-xs flex items-start gap-2">
                          <X className="w-3 h-3 text-destructive mt-0.5 flex-shrink-0" />
                          <span className="text-foreground/80">{pain}</span>
                        </li>
                      ))}
                      {displayInsights.painPoints.length > 6 && (
                        <li className="text-xs text-muted-foreground pl-5">
                          +{displayInsights.painPoints.length - 6} more challenges identified
                        </li>
                      )}
                    </ul>
                  ) : (
                    <p className="text-xs text-muted-foreground italic">No challenges captured yet</p>
                  )}
                </div>

                {/* Arrow between cards - hidden on mobile */}
                <div className="hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
                  <div className="bg-primary/10 rounded-full p-2">
                    <ArrowRight className="w-5 h-5 text-primary" />
                  </div>
                </div>

                {/* Future State Card - Potential Outcomes */}
                <div className="bg-green-500/5 rounded-lg p-4 border border-green-500/20">
                  <div className="flex items-center gap-2 mb-3">
                    <TrendingUp className="w-4 h-4 text-green-500" />
                    <h4 className="font-medium text-sm">Future State — Potential Outcomes</h4>
                  </div>
                  
                  {displayInsights.useCases && displayInsights.useCases.length > 0 ? (
                    <ul className="space-y-2">
                      {displayInsights.useCases.slice(0, 6).map((useCase, idx) => (
                        <li key={idx} className="text-xs flex items-start gap-2">
                          <Check className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
                          <span className="text-foreground/80">{useCase}</span>
                        </li>
                      ))}
                      {displayInsights.useCases.length > 6 && (
                        <li className="text-xs text-muted-foreground pl-5">
                          +{displayInsights.useCases.length - 6} more potential outcomes
                        </li>
                      )}
                    </ul>
                  ) : (
                    <p className="text-xs text-muted-foreground italic">No outcomes captured yet</p>
                  )}
                </div>
              </div>
            </div>
          ) : null}
          {/* Technologies - Split into Accepted vs Suggested */}
          {(() => {
            // Suppressed technologies - these are hidden entirely
            const suppressedNames = new Set(suppressedTechnologies?.map(s => s.technology_name.toLowerCase()) || []);
            
            // Filter detected technologies, excluding suppressed ones
            const detectedTechs = displayInsights.technologies.filter(
              tech => !suppressedNames.has(tech.name.toLowerCase())
            );
            
            // Accepted technologies = those in account_technologies
            const acceptedTechs: ExtractedTech[] = (accountTechnologies || []).map(t => ({
              name: t.name,
              confidence: 1,
              context: 'Added to architecture',
              repositoryTechId: t.repository_tech_id,
            }));
            
            // Suggested technologies = detected but NOT in architecture, and NOT rejected for their source transcript
            const acceptedNamesLower = new Set(acceptedTechs.map(t => t.name.toLowerCase()));
            const suggestedTechs = detectedTechs.filter(tech => {
              // Not already accepted
              if (acceptedNamesLower.has(tech.name.toLowerCase())) return false;
              // Not rejected for this specific transcript
              if (tech.sourceTranscriptId && rejectedDetections) {
                const isRejected = isTechRejectedForTranscript(
                  rejectedDetections,
                  tech.sourceTranscriptId,
                  tech.repositoryTechId || null,
                  tech.name
                );
                if (isRejected) return false;
              }
              return true;
            });
            
            const existingTechNames = [
              ...acceptedTechs.map(t => t.name),
              ...suggestedTechs.map(t => t.name),
            ];
            
            return (
              <div className="glass rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-foreground flex items-center gap-2">
                    <Database className="w-4 h-4 text-primary" />
                    Technologies
                  </h3>
                  <AddTechnologyPopover
                    onSelectTechnology={handleAddManualTechnology}
                    existingTechNames={existingTechNames}
                    disabled={!!addingTech}
                  />
                </div>

                {/* Accepted Technologies Section */}
                <Collapsible open={acceptedOpen} onOpenChange={setAcceptedOpen}>
                  <CollapsibleTrigger className="flex items-center gap-2 w-full text-left group">
                    <ChevronRight className={cn(
                      "w-4 h-4 text-muted-foreground transition-transform",
                      acceptedOpen && "rotate-90"
                    )} />
                    <span className="text-sm font-medium text-foreground">
                      Accepted Technologies
                    </span>
                    <Badge variant="secondary" className="text-xs ml-1">
                      {acceptedTechs.length}
                    </Badge>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="pt-3">
                    {acceptedTechs.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {acceptedTechs.map((tech, i) => (
                          <TechWithAreaMatch
                            key={`accepted-${tech.name}-${i}`}
                            tech={tech}
                            functionalAreas={functionalAreas || []}
                            onAreaSelect={handleAreaSelect}
                            onSuppress={handleSuppressTech}
                            onUnlink={handleUnlinkTech}
                            isAdding={addingTech === tech.name}
                            isSuppressing={suppressingTech === tech.name}
                            isUnlinking={unlinkingTech === tech.name}
                            isInArchitecture={true}
                            techId={getAccountTechId(tech.name)}
                          />
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground italic pl-6">
                        No accepted technologies yet. Accept suggestions below or add manually.
                      </p>
                    )}
                  </CollapsibleContent>
                </Collapsible>

                {/* Suggested Technologies Section */}
                <Collapsible open={suggestedOpen} onOpenChange={setSuggestedOpen}>
                  <CollapsibleTrigger className="flex items-center gap-2 w-full text-left group">
                    <ChevronRight className={cn(
                      "w-4 h-4 text-muted-foreground transition-transform",
                      suggestedOpen && "rotate-90"
                    )} />
                    <span className="text-sm font-medium text-foreground">
                      Suggested Technologies
                    </span>
                    <Badge variant="outline" className="text-xs ml-1 border-amber-500/50 text-amber-600">
                      {suggestedTechs.length}
                    </Badge>
                    <span className="text-xs text-muted-foreground ml-auto">
                      AI-detected from transcripts
                    </span>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="pt-3">
                    {suggestedTechs.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {suggestedTechs.map((tech, i) => (
                          <div key={`suggested-${tech.name}-${i}`} className="inline-flex items-center gap-0.5">
                            <TechWithAreaMatch
                              tech={tech}
                              functionalAreas={functionalAreas || []}
                              onAreaSelect={handleAreaSelect}
                              onSuppress={handleSuppressTech}
                              onUnlink={handleUnlinkTech}
                              isAdding={addingTech === tech.name}
                              isSuppressing={suppressingTech === tech.name}
                              isUnlinking={unlinkingTech === tech.name}
                              isInArchitecture={false}
                              techId={undefined}
                            />
                            {/* Reject button for suggestions */}
                            {tech.sourceTranscriptId && (
                              <button
                                type="button"
                                onClick={() => handleRejectTech(tech.name, tech.sourceTranscriptId, tech.repositoryTechId)}
                                disabled={rejectingTech === tech.name}
                                className={cn(
                                  "inline-flex items-center justify-center w-6 h-8 rounded-r-full border border-l-0 text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors",
                                  "border-amber-500/30 bg-amber-500/5",
                                  rejectingTech === tech.name && "opacity-50 pointer-events-none"
                                )}
                                title={`Reject ${tech.name} (won't appear from this transcript again)`}
                              >
                                <X className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground italic pl-6">
                        No new technology suggestions. All detected technologies have been accepted or rejected.
                      </p>
                    )}
                  </CollapsibleContent>
                </Collapsible>
              </div>
            );
          })()}

          {/* Pain Points and Use Cases are now shown in ThemedInsightsPanel as Strategic Themes */}

          {/* Competitive Positioning - Always shown with add capability */}
          <div className="glass rounded-xl p-5 space-y-4">
            <h3 className="font-semibold text-foreground flex items-center gap-2">
              <Swords className="w-4 h-4 text-orange-500" />
              Competitive Positioning
            </h3>
            
            {/* Competitor Manager - handles both AI-mentioned and manual competitors */}
            <div>
              <p className="text-xs text-muted-foreground mb-2">Competitors mentioned</p>
              <AccountCompetitorManager
                accountId={accountId}
                mentionedCompetitors={displayInsights.competitorMentions}
              />
            </div>

            {/* Pendo Advantages */}
            {competitiveData?.strengths && competitiveData.strengths.length > 0 && (
              <div className="pt-3 border-t border-border">
                <p className="text-xs font-medium text-green-600 mb-2 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  Pendo Advantages
                </p>
                <ul className="space-y-2">
                  {competitiveData.strengths.slice(0, 3).map((comp: FeatureComparison, idx: number) => (
                    <li key={idx} className="text-xs flex items-start gap-2">
                      <Check className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <span className="font-medium">{comp.featureName}</span>
                        <span className="text-muted-foreground"> vs {comp.competitorName}: </span>
                        <span className="text-green-600">+{comp.pendoAdvantage} advantage</span>
                        <span className="text-muted-foreground"> ({comp.pendoScore}/5 vs {comp.competitorScore}/5)</span>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Areas to Address */}
            {competitiveData?.threats && competitiveData.threats.length > 0 && (
              <div className="pt-3 border-t border-border">
                <p className="text-xs font-medium text-amber-600 mb-2 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  Areas to Address
                </p>
                <ul className="space-y-2">
                  {competitiveData.threats.slice(0, 2).map((comp: FeatureComparison, idx: number) => (
                    <li key={idx} className="text-xs flex items-start gap-2">
                      <X className="w-3 h-3 text-amber-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <span className="font-medium">{comp.featureName}</span>
                        <span className="text-muted-foreground">: {comp.competitorName} leads </span>
                        <span className="text-amber-600">({comp.competitorScore}/5 vs {comp.pendoScore}/5)</span>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {displayInsights.competitorMentions.length === 0 && !competitiveData?.strengths?.length && !competitiveData?.threats?.length && (
              <p className="text-xs text-muted-foreground italic">
                No competitors added yet. Use the Add button above to track competitive positioning.
              </p>
            )}
          </div>

          {/* Key People - External Stakeholders + Internal Team */}
          {((keyExternalPeople && keyExternalPeople.length > 0) || (keyInternalPeople && keyInternalPeople.length > 0)) && (
            <div className="glass rounded-xl p-5 space-y-4">
              <h3 className="font-semibold text-foreground flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" />
                Key People
              </h3>
              
              {/* External Stakeholders */}
              {keyExternalPeople && keyExternalPeople.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                    External Stakeholders
                  </div>
                  <div className="grid gap-2 md:grid-cols-2">
                    {keyExternalPeople.map((person) => (
                      <div key={person.id} className="bg-muted/30 rounded-lg p-3 flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <span className="text-sm font-medium text-primary">
                          {(person.name || '?').charAt(0).toUpperCase()}
                        </span>
                        </div>
                        <div className="min-w-0">
                          <div className="font-medium text-sm truncate">{person.name || 'Unknown'}</div>
                          {person.role && (
                            <div className="text-xs text-muted-foreground truncate">{person.role}</div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Internal Team */}
              {keyInternalPeople && keyInternalPeople.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                    Internal Team
                  </div>
                  <div className="grid gap-2 md:grid-cols-2">
                    {keyInternalPeople.map((person, i) => (
                      <div key={person.email || i} className="bg-muted/30 rounded-lg p-3 flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-layer-growth/10 flex items-center justify-center shrink-0">
                        <span className="text-sm font-medium text-layer-growth">
                          {(person.name || '?').charAt(0).toUpperCase()}
                        </span>
                        </div>
                        <div className="min-w-0">
                          <div className="font-medium text-sm truncate">{person.name || 'Unknown'}</div>
                          <div className="text-xs text-muted-foreground truncate">{person.role}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Next Best Actions */}
          {displayInsights.nbas.length > 0 && (
            <div className="glass rounded-xl p-5 space-y-3">
              <h3 className="font-semibold text-foreground flex items-center gap-2">
                <Zap className="w-4 h-4 text-layer-growth" />
                Next Best Actions
              </h3>
              <div className="space-y-3">
                {displayInsights.nbas.map((nba, i) => (
                  <div key={i} className="bg-muted/30 rounded-lg p-3">
                    <div className="flex items-start gap-2">
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "text-xs shrink-0",
                          nba.priority === 'high' && 'border-destructive text-destructive',
                          nba.priority === 'medium' && 'border-yellow-500 text-yellow-500',
                          nba.priority === 'low' && 'border-muted-foreground text-muted-foreground'
                        )}
                      >
                        {nba.priority}
                      </Badge>
                      <Badge variant="secondary" className="text-xs shrink-0">
                        {nba.actionType.replace(/_/g, ' ')}
                      </Badge>
                    </div>
                    <p className="text-sm mt-2">{nba.action}</p>
                    {nba.reasoning && (
                      <p className="text-xs text-muted-foreground mt-2 italic">{nba.reasoning}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Extracted Metrics Section - Account Rollup */}
          <OpportunityMetricsSection 
            accountId={accountId} 
            showAccountRollup={true}
          />
        </>
      )}
    </div>
  );
}

import { useState, useMemo } from 'react';
import { 
  Target, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Mail, 
  Users, 
  ClipboardList,
  AlertCircle,
  Clock,
  Sparkles,
  Lightbulb,
  HelpCircle,
  Layers,
  ChevronDown,
  ChevronRight,
  User,
  Calendar,
  X,
  AlertTriangle,
  Ban,
  DollarSign,
  Package
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { format, differenceInDays, isPast, isToday, isTomorrow, parseISO } from 'date-fns';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useWhitespaceNBAs, WhitespaceNBA } from '@/hooks/useWhitespaceNBAs';
import { useAssignableOpportunityUsers } from '@/hooks/useAssignableOpportunityUsers';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { DueDatePicker } from '@/components/DueDatePicker';
import { useAuth } from '@/contexts/AuthContext';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface AccountNBAsTabProps {
  accountId: string;
  accountName: string;
}

interface AccountNBA {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  action: string;
  action_type: string;
  priority: string | null;
  status: string | null;
  notes: string | null;
  due_date: string | null;
  delivery_method: string | null;
  assigned_to: string | null;
  created_at: string;
  auto_complete_confidence: number | null;
  auto_complete_reason: string | null;
}

interface Opportunity {
  id: string;
  name: string;
}

const priorityColors: Record<string, string> = {
  high: 'border-destructive text-destructive bg-destructive/10',
  medium: 'border-layer-build text-layer-build bg-layer-build/10',
  low: 'border-muted-foreground text-muted-foreground bg-muted/50',
};

const actionTypeLabels: Record<string, string> = {
  discovery: 'Discovery',
  discovery_nba: 'Discovery Question',
  followup: 'Follow-up',
  follow_up: 'Follow-up',
  technical: 'Technical',
  whitespace: 'Whitespace',
  use_case_gap: 'Use Case Gap',
  tech_gap: 'Tech Gap',
  low_coverage: 'Low Coverage',
  competitive_advantage: 'Competitive',
  research: 'Research',
  meeting: 'Meeting',
};

const deliveryMethodConfig = {
  email: { icon: Mail, label: 'Email', color: 'text-blue-500' },
  meeting: { icon: Users, label: 'Meeting', color: 'text-purple-500' },
  internal: { icon: ClipboardList, label: 'Internal', color: 'text-muted-foreground' },
};

// Whitespace NBA Card Component
function WhitespaceNBACard({ 
  nba, 
  isExpanded, 
  onToggle 
}: { 
  nba: WhitespaceNBA; 
  isExpanded: boolean; 
  onToggle: () => void;
}) {
  // Format currency for display
  const formatRevenue = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}k`;
    return `$${amount}`;
  };

  return (
    <div className="rounded-lg border border-layer-build/30 bg-layer-build/5 overflow-hidden">
      <Collapsible open={isExpanded} onOpenChange={onToggle}>
        <CollapsibleTrigger asChild>
          <div className="flex items-start gap-3 p-3 cursor-pointer hover:bg-layer-build/10 transition-colors">
            <div className="mt-1">
              {isExpanded ? (
                <ChevronDown className="w-4 h-4 text-layer-build" />
              ) : (
                <ChevronRight className="w-4 h-4 text-layer-build" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <Layers className="w-4 h-4 text-layer-build" />
                <span className="text-xs text-layer-build font-medium">{nba.functionalArea}</span>
              </div>
              <p className="text-sm text-foreground">{nba.action}</p>
              <p className="text-xs text-muted-foreground mt-1">{nba.reasoning}</p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {/* Revenue badge - prominently displayed */}
              {nba.potentialRevenue && nba.potentialRevenue > 0 && (
                <Badge variant="default" className="text-xs bg-emerald-600 hover:bg-emerald-700 gap-1">
                  <DollarSign className="w-3 h-3" />
                  {formatRevenue(nba.potentialRevenue)}
                </Badge>
              )}
              <Badge variant="outline" className="text-[10px] border-layer-build/50 text-layer-build">
                {actionTypeLabels[nba.type] || nba.type}
              </Badge>
              <Badge 
                variant="outline" 
                className={cn('text-[10px]', priorityColors[nba.priority])}
              >
                {nba.priority}
              </Badge>
              {nba.discoveryQuestions.length > 0 && (
                <Badge variant="secondary" className="text-[10px] gap-1">
                  <HelpCircle className="w-3 h-3" />
                  {nba.discoveryQuestions.length}
                </Badge>
              )}
            </div>
          </div>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <div className="px-3 pb-3 pt-1 border-t border-layer-build/20 bg-layer-build/10 space-y-3">
            {/* Modules section */}
            {nba.modules && nba.modules.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Package className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-xs font-medium text-emerald-600">Relevant Modules</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {nba.modules.map((module, idx) => (
                    <Badge key={idx} variant="outline" className="text-[10px] border-emerald-500/50 text-emerald-600 bg-emerald-500/10">
                      {module}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            
            {/* Discovery questions section */}
            {nba.discoveryQuestions.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <HelpCircle className="w-3.5 h-3.5 text-layer-build" />
                  <span className="text-xs font-medium text-layer-build">Discovery Questions</span>
                </div>
                <ul className="space-y-1.5">
                  {nba.discoveryQuestions.map((question, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-foreground">
                      <span className="text-layer-build font-medium mt-0.5">{idx + 1}.</span>
                      <span>{question}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}

// Helper to get initials from name or email
function getInitials(name: string | null, email: string): string {
  if (name) {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  }
  return email.substring(0, 2).toUpperCase();
}

export function AccountNBAsTab({ accountId, accountName }: AccountNBAsTabProps) {
  const queryClient = useQueryClient();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('pending');
  const [opportunityFilter, setOpportunityFilter] = useState<string>('all');
  const [expandedWhitespace, setExpandedWhitespace] = useState<Record<string, boolean>>({});
  
  // Form state
  const [newAction, setNewAction] = useState('');
  const [newType, setNewType] = useState('followup');
  const [newPriority, setNewPriority] = useState('medium');
  const [newDeliveryMethod, setNewDeliveryMethod] = useState('email');
  const [newNotes, setNewNotes] = useState('');
  const [newOpportunityId, setNewOpportunityId] = useState<string>('account');
  const [newAssignedTo, setNewAssignedTo] = useState('');
  const [newDueDate, setNewDueDate] = useState('');

  // Fetch whitespace NBAs
  const { whitespaceNBAs, isLoading: whitespaceLoading } = useWhitespaceNBAs(accountId);

  // Fetch assignable users
  const { data: assignableUsers } = useAssignableOpportunityUsers(accountId, null);

  // Create a map of email to user info for displaying owners
  const userMap = useMemo(() => {
    const map = new Map<string, { name: string | null; email: string }>();
    assignableUsers?.allUsers.forEach(user => {
      map.set(user.email.toLowerCase(), { name: user.full_name, email: user.email });
    });
    return map;
  }, [assignableUsers]);

  // Fetch opportunities for this account
  const { data: opportunities } = useQuery({
    queryKey: ['account-opportunities', accountId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('opportunities')
        .select('id, name')
        .eq('account_id', accountId)
        .order('name');
      if (error) throw error;
      return data as Opportunity[];
    },
  });

  // Fetch NBAs for this account (all opportunities + account-level) - use gateway for decryption
  const { data: nbas, isLoading } = useQuery({
    queryKey: ['account-nbas', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_nbas')
        .select('id, account_id, opportunity_id, action, action_type, priority, status, notes, due_date, delivery_method, assigned_to, created_at, auto_complete_confidence, auto_complete_reason')
        .eq('account_id', accountId)
        .order('created_at', { ascending: false })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as AccountNBA[];
    },
  });

  // Map opportunity names
  const opportunityMap = useMemo(() => {
    const map = new Map<string, string>();
    opportunities?.forEach(o => map.set(o.id, o.name));
    return map;
  }, [opportunities]);

  // Create NBA mutation
  const createNBA = useMutation({
    mutationFn: async (nba: {
      action: string;
      action_type: string;
      priority: string;
      delivery_method: string;
      notes: string;
      opportunity_id: string | null;
      assigned_to?: string;
      due_date?: string;
    }) => {
      const { data: inserted, error } = await gateway
        .from('account_nbas')
        .insert({
          account_id: accountId,
          opportunity_id: nba.opportunity_id,
          action: nba.action,
          action_type: nba.action_type,
          priority: nba.priority,
          delivery_method: nba.delivery_method,
          notes: nba.notes || null,
          assigned_to: nba.assigned_to || null,
          due_date: nba.due_date || null,
          status: 'pending',
        })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const data = Array.isArray(inserted) ? inserted[0] : inserted;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      if (data.opportunity_id) {
        queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', data.opportunity_id] });
      }
      toast.success('Action added');
      setShowAddDialog(false);
      resetForm();
    },
    onError: (error) => {
      toast.error('Failed to add action: ' + error.message);
    },
  });

  // Update NBA owner mutation
  const updateNBAOwner = useMutation({
    mutationFn: async ({ nbaId, assignedTo }: { nbaId: string; assignedTo: string | null }) => {
      const { error } = await gateway
        .from('account_nbas')
        .update({ assigned_to: assignedTo })
        .eq('id', nbaId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Owner updated');
    },
  });

  // Complete NBA mutation
  const completeNBA = useMutation({
    mutationFn: async (nbaId: string) => {
      const { error } = await supabase
        .from('account_nbas')
        .update({ status: 'completed' })
        .eq('id', nbaId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Action completed');
    },
  });

  // Reopen NBA mutation
  const reopenNBA = useMutation({
    mutationFn: async (nbaId: string) => {
      const { error } = await supabase
        .from('account_nbas')
        .update({ status: 'pending' })
        .eq('id', nbaId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Action reopened');
    },
  });

  // Cancel NBA mutation
  const cancelNBA = useMutation({
    mutationFn: async (nbaId: string) => {
      const { error } = await supabase
        .from('account_nbas')
        .update({ status: 'cancelled', completed_at: new Date().toISOString() })
        .eq('id', nbaId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Action cancelled');
    },
  });

  // Get user for due date change logging
  const { user } = useAuth();
  const userEmail = user?.email;

  // Update due date mutation with logging
  const updateDueDate = useMutation({
    mutationFn: async ({ 
      nbaId, 
      newDueDate, 
      previousDueDate 
    }: { 
      nbaId: string; 
      newDueDate: Date;
      previousDueDate: Date | null;
    }) => {
      let changeType = 'manual';
      let daysChanged = 0;
      
      if (!previousDueDate) {
        changeType = 'initial';
      } else {
        daysChanged = differenceInDays(newDueDate, previousDueDate);
        changeType = daysChanged > 0 ? 'postponed' : 'advanced';
      }

      const { error } = await gateway
        .from('account_nbas')
        .update({ due_date: newDueDate.toISOString() })
        .eq('id', nbaId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));

      // Log the change
      await gateway.from('nba_due_date_changes')
        .insert({
          nba_id: nbaId,
          previous_due_date: previousDueDate?.toISOString() || null,
          new_due_date: newDueDate.toISOString(),
          change_type: changeType,
          days_changed: daysChanged,
          changed_by: user?.id || null,
          changed_by_email: userEmail || null,
        })
        .execute();

      return { changeType, daysChanged };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      if (data.changeType === 'postponed') {
        toast.info(`Due date postponed by ${data.daysChanged} day${data.daysChanged !== 1 ? 's' : ''}`);
      } else if (data.changeType === 'advanced') {
        toast.success(`Due date moved up`);
      } else {
        toast.success('Due date set');
      }
    },
  });

  const resetForm = () => {
    setNewAction('');
    setNewType('followup');
    setNewPriority('medium');
    setNewDeliveryMethod('email');
    setNewNotes('');
    setNewOpportunityId('account');
    setNewAssignedTo('');
    setNewDueDate('');
  };

  const handleCreate = () => {
    if (!newAction.trim()) {
      toast.error('Action description is required');
      return;
    }
    createNBA.mutate({
      action: newAction,
      action_type: newType,
      priority: newPriority,
      delivery_method: newDeliveryMethod,
      notes: newNotes,
      opportunity_id: newOpportunityId === 'account' ? null : newOpportunityId,
      assigned_to: newAssignedTo && newAssignedTo !== '__unassigned__' ? newAssignedTo : undefined,
      due_date: newDueDate || undefined,
    });
  };

  const toggleWhitespaceExpanded = (id: string) => {
    setExpandedWhitespace(prev => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Helper to get due date status
  const getDueDateStatus = (dueDate: string | null) => {
    if (!dueDate) return null;
    const date = parseISO(dueDate);
    if (isPast(date) && !isToday(date)) {
      return { status: 'overdue', label: 'Overdue', color: 'text-destructive bg-destructive/10' };
    }
    if (isToday(date)) {
      return { status: 'today', label: 'Due today', color: 'text-amber-600 bg-amber-500/10' };
    }
    if (isTomorrow(date)) {
      return { status: 'tomorrow', label: 'Due tomorrow', color: 'text-blue-600 bg-blue-500/10' };
    }
    return null;
  };

  // Filter NBAs by status and opportunity
  const filteredNBAs = useMemo(() => {
    if (!nbas) return [];
    let filtered = nbas;
    
    // Filter by opportunity
    if (opportunityFilter !== 'all') {
      if (opportunityFilter === 'account') {
        filtered = filtered.filter(n => !n.opportunity_id);
      } else {
        filtered = filtered.filter(n => n.opportunity_id === opportunityFilter);
      }
    }
    
    // Filter by status - exclude cancelled unless viewing all
    if (filter === 'pending') {
      filtered = filtered.filter(n => n.status !== 'completed' && n.status !== 'cancelled');
    } else if (filter === 'completed') {
      filtered = filtered.filter(n => n.status === 'completed' || n.status === 'cancelled');
    }
    
    return filtered;
  }, [nbas, filter, opportunityFilter]);

  // Group by delivery method
  const groupedByDelivery = useMemo(() => {
    const groups: Record<string, AccountNBA[]> = {
      meeting: [],
      email: [],
      internal: [],
    };
    filteredNBAs.forEach(nba => {
      const method = nba.delivery_method || 'internal';
      if (groups[method]) {
        groups[method].push(nba);
      } else {
        groups['internal'].push(nba);
      }
    });
    return groups;
  }, [filteredNBAs]);

  // Stats
  const stats = useMemo(() => {
    if (!nbas) return { total: 0, pending: 0, completed: 0, cancelled: 0, high: 0, overdue: 0, whitespace: 0, internal: 0, external: 0 };
    const pendingNBAs = nbas.filter(n => n.status !== 'completed' && n.status !== 'cancelled');
    const overdueNBAs = pendingNBAs.filter(n => {
      if (!n.due_date) return false;
      const date = parseISO(n.due_date);
      return isPast(date) && !isToday(date);
    });
    return {
      total: nbas.length,
      pending: pendingNBAs.length,
      completed: nbas.filter(n => n.status === 'completed').length,
      cancelled: nbas.filter(n => n.status === 'cancelled').length,
      high: pendingNBAs.filter(n => n.priority === 'high').length,
      overdue: overdueNBAs.length,
      whitespace: whitespaceNBAs?.length || 0,
      internal: pendingNBAs.filter(n => n.delivery_method === 'internal').length,
      external: pendingNBAs.filter(n => n.delivery_method === 'email' || n.delivery_method === 'meeting').length,
    };
  }, [nbas, whitespaceNBAs]);

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <div className="h-8 w-48 bg-muted animate-pulse rounded" />
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-20 bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Next Best Actions</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Specific actions to progress {accountName}
          </p>
        </div>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add Action
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Next Best Action</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Action</Label>
                <Textarea
                  value={newAction}
                  onChange={(e) => setNewAction(e.target.value)}
                  placeholder="Describe the action to take..."
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Select value={newType} onValueChange={setNewType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="followup">Follow-up</SelectItem>
                      <SelectItem value="discovery">Discovery</SelectItem>
                      <SelectItem value="technical">Technical</SelectItem>
                      <SelectItem value="whitespace">Whitespace</SelectItem>
                      <SelectItem value="competitive_advantage">Competitive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Priority</Label>
                  <Select value={newPriority} onValueChange={setNewPriority}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Delivery Method</Label>
                <Select value={newDeliveryMethod} onValueChange={setNewDeliveryMethod}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="email">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4" />
                        Email
                      </div>
                    </SelectItem>
                    <SelectItem value="meeting">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        Meeting
                      </div>
                    </SelectItem>
                    <SelectItem value="internal">
                      <div className="flex items-center gap-2">
                        <ClipboardList className="w-4 h-4" />
                        Internal
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Opportunity Selection */}
              <div className="space-y-2">
                <Label>Opportunity</Label>
                <Select value={newOpportunityId} onValueChange={setNewOpportunityId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select opportunity..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="account">
                      <span className="text-muted-foreground">Account-wide (no specific opportunity)</span>
                    </SelectItem>
                    {opportunities?.map(opp => (
                      <SelectItem key={opp.id} value={opp.id}>
                        {opp.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Owner</Label>
                  <Select value={newAssignedTo} onValueChange={setNewAssignedTo}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select owner..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__unassigned__">
                        <span className="text-muted-foreground">Unassigned</span>
                      </SelectItem>
                      {assignableUsers?.allUsers.map((user) => (
                        <SelectItem key={user.email} value={user.email}>
                          <div className="flex items-center gap-2">
                            <Avatar className="h-5 w-5">
                              <AvatarFallback className="text-[10px]">
                                {getInitials(user.full_name, user.email)}
                              </AvatarFallback>
                            </Avatar>
                            <span>{user.full_name || user.email}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Due Date (optional)</Label>
                  <Input
                    type="date"
                    value={newDueDate}
                    onChange={(e) => setNewDueDate(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Notes (optional)</Label>
                <Textarea
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="Additional context..."
                  rows={2}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={createNBA.isPending}>
                  Add Action
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats - Compact layout */}
      <div className="flex items-center gap-2 flex-wrap">
        <Badge variant="outline" className="gap-1.5 py-1 px-2">
          <Target className="w-3.5 h-3.5 text-primary" />
          <span className="font-semibold">{stats.pending}</span>
          <span className="text-muted-foreground">pending</span>
        </Badge>
        {stats.overdue > 0 && (
          <Badge variant="destructive" className="gap-1.5 py-1 px-2">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span className="font-semibold">{stats.overdue}</span>
            <span>overdue</span>
          </Badge>
        )}
        <Badge variant="outline" className="gap-1.5 py-1 px-2 border-primary/30">
          <ClipboardList className="w-3.5 h-3.5 text-primary" />
          <span className="font-semibold">{stats.internal}</span>
          <span className="text-muted-foreground">internal</span>
        </Badge>
        <Badge variant="outline" className="gap-1.5 py-1 px-2">
          <Mail className="w-3.5 h-3.5 text-blue-500" />
          <span className="font-semibold">{stats.external}</span>
          <span className="text-muted-foreground">external</span>
        </Badge>
        {stats.high > 0 && (
          <Badge variant="outline" className="gap-1.5 py-1 px-2 border-destructive/30">
            <AlertCircle className="w-3.5 h-3.5 text-destructive" />
            <span className="font-semibold">{stats.high}</span>
            <span className="text-muted-foreground">high priority</span>
          </Badge>
        )}
        {stats.whitespace > 0 && (
          <Badge variant="outline" className="gap-1.5 py-1 px-2 border-layer-build/30">
            <Lightbulb className="w-3.5 h-3.5 text-layer-build" />
            <span className="font-semibold">{stats.whitespace}</span>
            <span className="text-muted-foreground">whitespace</span>
          </Badge>
        )}
        <Badge variant="outline" className="gap-1.5 py-1 px-2">
          <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
          <span className="font-semibold">{stats.completed}</span>
          <span className="text-muted-foreground">done</span>
        </Badge>
        {stats.cancelled > 0 && (
          <Badge variant="outline" className="gap-1.5 py-1 px-2 opacity-60">
            <Ban className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="font-semibold">{stats.cancelled}</span>
            <span className="text-muted-foreground">cancelled</span>
          </Badge>
        )}
      </div>

      {/* Whitespace NBAs Section */}
      {whitespaceNBAs && whitespaceNBAs.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Lightbulb className="w-4 h-4 text-layer-build" />
            <h3 className="text-sm font-medium text-foreground">Whitespace Opportunities</h3>
            <Badge variant="outline" className="text-xs border-layer-build/50 text-layer-build">
              {whitespaceNBAs.length} gaps
            </Badge>
          </div>
          <div className="space-y-2">
            {whitespaceNBAs.map((nba) => (
              <WhitespaceNBACard
                key={nba.id}
                nba={nba}
                isExpanded={expandedWhitespace[nba.id] || false}
                onToggle={() => toggleWhitespaceExpanded(nba.id)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex items-center gap-4">
        <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
          <TabsList>
            <TabsTrigger value="pending">Pending ({stats.pending})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({stats.completed})</TabsTrigger>
            <TabsTrigger value="all">All ({stats.total})</TabsTrigger>
          </TabsList>
        </Tabs>
        
        {/* Opportunity Filter */}
        {opportunities && opportunities.length > 0 && (
          <Select value={opportunityFilter} onValueChange={setOpportunityFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Filter by opportunity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Opportunities</SelectItem>
              <SelectItem value="account">Account-wide only</SelectItem>
              {opportunities.map(opp => (
                <SelectItem key={opp.id} value={opp.id}>
                  {opp.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* NBAs grouped by delivery method */}
      {filteredNBAs.length === 0 && (!whitespaceNBAs || whitespaceNBAs.length === 0) ? (
        <div className="text-center py-12 text-muted-foreground">
          <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium">No actions found</p>
          <p className="text-sm mt-1">
            {filter === 'pending' ? 'All actions have been completed!' : 'Add actions to track what needs to be done.'}
          </p>
        </div>
      ) : filteredNBAs.length > 0 && (
        <div className="space-y-6">
          {Object.entries(groupedByDelivery).map(([method, items]) => {
            if (items.length === 0) return null;
            const config = deliveryMethodConfig[method as keyof typeof deliveryMethodConfig] || deliveryMethodConfig.internal;
            const Icon = config.icon;

            return (
              <div key={method} className="space-y-3">
                <div className="flex items-center gap-2">
                  <Icon className={cn('w-4 h-4', config.color)} />
                  <h3 className="text-sm font-medium text-foreground">{config.label}</h3>
                  <Badge variant="outline" className="text-xs">{items.length}</Badge>
                </div>

                <div className="space-y-2">
                  {items.map((nba) => {
                    const dueDateStatus = getDueDateStatus(nba.due_date);
                    const isCancelled = nba.status === 'cancelled';
                    const isCompleted = nba.status === 'completed';
                    const isInactive = isCancelled || isCompleted;
                    
                    return (
                      <div
                        key={nba.id}
                        className={cn(
                          'flex items-start gap-3 p-4 rounded-lg border transition-all group',
                          isInactive && 'opacity-60',
                          isCancelled && 'bg-muted/30 border-muted',
                          isCompleted && 'bg-muted/30 border-muted',
                          !isInactive && 'bg-card border-border hover:border-primary/30',
                          !isInactive && (nba.delivery_method === 'internal') && 'border-primary/50',
                          !isInactive && dueDateStatus?.status === 'overdue' && 'border-destructive/50 bg-destructive/5'
                        )}
                      >
                        {/* Checkbox or Cancel icon */}
                        {isCancelled ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Ban className="w-5 h-5 text-muted-foreground mt-0.5" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">Cancelled</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          <Checkbox
                            checked={isCompleted}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                completeNBA.mutate(nba.id);
                              } else {
                                reopenNBA.mutate(nba.id);
                              }
                            }}
                            className="mt-0.5"
                          />
                        )}
                        
                        {/* Main content */}
                        <div className="flex-1 min-w-0">
                          {/* Action text */}
                          <p className={cn(
                            'text-sm text-foreground',
                            isInactive && 'line-through text-muted-foreground'
                          )}>
                            {nba.action}
                          </p>
                          
                          {/* Second row: Owner selector and due date */}
                          <div className="flex items-center gap-3 mt-2 flex-wrap">
                            {/* Owner selector */}
                            <Select 
                              value={nba.assigned_to || '__unassigned__'} 
                              onValueChange={(value) => updateNBAOwner.mutate({ 
                                nbaId: nba.id, 
                                assignedTo: value === '__unassigned__' ? null : value 
                              })}
                              disabled={isInactive}
                            >
                              <SelectTrigger className="h-7 w-auto min-w-[140px] border-dashed">
                                {nba.assigned_to ? (() => {
                                  const owner = userMap.get(nba.assigned_to.toLowerCase());
                                  const displayName = owner?.name || nba.assigned_to;
                                  return (
                                    <div className="flex items-center gap-1.5">
                                      <Avatar className="h-5 w-5">
                                        <AvatarFallback className="text-[9px] bg-primary/10 text-primary">
                                          {getInitials(owner?.name || null, nba.assigned_to)}
                                        </AvatarFallback>
                                      </Avatar>
                                      <span className="text-xs">{displayName}</span>
                                    </div>
                                  );
                                })() : (
                                  <span className="text-xs text-muted-foreground">Assign owner...</span>
                                )}
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="__unassigned__">
                                  <span className="text-muted-foreground">Unassigned</span>
                                </SelectItem>
                                {assignableUsers?.allUsers.map((user) => (
                                  <SelectItem key={user.email} value={user.email}>
                                    <div className="flex items-center gap-2">
                                      <Avatar className="h-5 w-5">
                                        <AvatarFallback className="text-[10px]">
                                          {getInitials(user.full_name, user.email)}
                                        </AvatarFallback>
                                      </Avatar>
                                      <span>{user.full_name || user.email}</span>
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            
                            {/* Due date picker */}
                            <DueDatePicker
                              dueDate={nba.due_date}
                              onDateChange={(newDate, prevDate) => updateDueDate.mutate({ 
                                nbaId: nba.id, 
                                newDueDate: newDate, 
                                previousDueDate: prevDate 
                              })}
                              disabled={isInactive}
                            />
                            
                            {/* Due date status badge */}
                            {!isInactive && dueDateStatus && (
                              <Badge variant="outline" className={cn('text-[10px]', dueDateStatus.color)}>
                                {dueDateStatus.status === 'overdue' && <AlertTriangle className="w-3 h-3 mr-1" />}
                                {dueDateStatus.label}
                              </Badge>
                            )}
                          </div>
                          
                          {/* Notes row */}
                          {nba.notes && (
                            <p className="text-xs text-muted-foreground mt-1.5 line-clamp-2">
                              {nba.notes}
                            </p>
                          )}
                          
                          {/* Opportunity name */}
                          {nba.opportunity_id && opportunityMap.get(nba.opportunity_id) && (
                            <p className="text-xs text-muted-foreground mt-1.5">
                              <span className="text-muted-foreground/60">Opportunity:</span>{' '}
                              {opportunityMap.get(nba.opportunity_id)}
                            </p>
                          )}
                        </div>
                        
                        {/* Right side: badges and actions */}
                        <div className="flex flex-col items-end gap-2 shrink-0">
                          {/* Priority badge */}
                          <Badge 
                            variant="outline" 
                            className={cn('text-[10px]', priorityColors[nba.priority || 'medium'])}
                          >
                            {nba.priority || 'medium'}
                          </Badge>
                          
                          {/* Type badge */}
                          <Badge variant="secondary" className="text-[10px]">
                            {actionTypeLabels[nba.action_type] || nba.action_type}
                          </Badge>
                          
                          {/* Cancel button - only visible on hover for pending items */}
                          {!isInactive && (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                                    onClick={() => cancelNBA.mutate(nba.id)}
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-xs">Cancel task</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

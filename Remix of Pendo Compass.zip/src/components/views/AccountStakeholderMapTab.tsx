import { useMemo, useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Users, RefreshCw, Info, TrendingUp, TrendingDown, Minus, UserX, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ScoreSparkline } from '@/components/ui/score-sparkline';
import { useAccountContactSnapshots, getSparklineData } from '@/hooks/useContactSnapshots';
import { ScoreReasoningTooltip } from '@/components/stakeholder/ScoreReasoningTooltip';
import { ScoreHistoryPanel } from '@/components/stakeholder/ScoreHistoryPanel';

// MEDDIC-aligned stakeholder types
type StakeholderType = 'champion' | 'economic_buyer' | 'decision_criteria_owner' | 'coach' | 'blocker' | 'end_user' | 'unknown';

interface Stakeholder {
  id: string;
  name: string;
  role: string | null;
  email: string | null;
  influence_level: number | null;
  sentiment: number | null;
  champion_score: number | null;
  stakeholder_type: StakeholderType | null;
  last_assessed_at: string | null;
  assessment_source: string | null;
  is_ignored: boolean;
  is_internal: boolean;
  advocacy_signals: object | null;
  info_sharing_signals: object | null;
  opportunity_id: string | null;
}

interface Opportunity {
  id: string;
  name: string;
}

interface AccountStakeholderMapTabProps {
  accountId: string;
}

// Stakeholder type definitions with MEDDIC alignment
const STAKEHOLDER_TYPES: Record<StakeholderType, { label: string; description: string; color: string; icon: string }> = {
  champion: { 
    label: 'Champion', 
    description: 'Internal advocate who actively sells for you, shares insights, and helps navigate politics', 
    color: 'hsl(var(--primary))',
    icon: '🏆'
  },
  economic_buyer: { 
    label: 'Economic Buyer', 
    description: 'Sponsor with budget authority and final sign-off power', 
    color: 'hsl(var(--layer-growth))',
    icon: '💰'
  },
  decision_criteria_owner: { 
    label: 'Decision Criteria Owner', 
    description: 'Defines technical/business requirements the solution must meet', 
    color: 'hsl(var(--secondary))',
    icon: '📋'
  },
  coach: { 
    label: 'Coach', 
    description: 'Provides insider guidance and helps you understand internal dynamics', 
    color: 'hsl(var(--accent))',
    icon: '🎯'
  },
  blocker: { 
    label: 'Blocker', 
    description: 'Actively opposes the solution or creates obstacles', 
    color: 'hsl(var(--destructive))',
    icon: '🚫'
  },
  end_user: { 
    label: 'End User', 
    description: 'Will use the solution day-to-day but has limited decision power', 
    color: 'hsl(var(--muted-foreground))',
    icon: '👤'
  },
  unknown: { 
    label: 'Needs Analysis', 
    description: 'Insufficient evidence to classify - requires more transcript analysis', 
    color: 'hsl(var(--border))',
    icon: '❓'
  },
};

// Quadrant labels for bubble chart (based on influence + sentiment)
const QUADRANTS = {
  topRight: { label: 'Potential Champions', description: 'High influence, positive sentiment - validate champion signals', color: 'hsl(var(--primary))' },
  topLeft: { label: 'Blockers', description: 'High influence, negative sentiment - need attention', color: 'hsl(var(--destructive))' },
  bottomRight: { label: 'Supporters', description: 'Low influence, positive sentiment - potential coaches', color: 'hsl(var(--layer-growth))' },
  bottomLeft: { label: 'Detractors', description: 'Low influence, negative sentiment - monitor for escalation', color: 'hsl(var(--muted-foreground))' },
};

// Helper component for score cells with sparklines
interface StakeholderScoreCellProps {
  value: number | null;
  label: string;
  contactId: string;
  contactName: string;
  metric: 'sentiment' | 'influence_level' | 'champion_score';
  snapshots: any[] | undefined;
  colorStart: string;
  colorEnd: string;
  icon?: React.ReactNode;
  onOpenHistory?: (metric: 'sentiment' | 'influence_level' | 'champion_score') => void;
}

function StakeholderScoreCell({ 
  value, label, contactId, contactName, metric, snapshots, colorStart, colorEnd, icon, onOpenHistory 
}: StakeholderScoreCellProps) {
  const sparklineData = useMemo(() => {
    if (!snapshots || snapshots.length === 0) return [];
    return getSparklineData(snapshots, contactId, metric);
  }, [snapshots, contactId, metric]);
  
  return (
    <ScoreReasoningTooltip
      value={value}
      label={label}
      metric={metric}
      snapshots={snapshots || []}
      contactId={contactId}
      onClickDetails={onOpenHistory ? () => onOpenHistory(metric) : undefined}
    >
      <div 
        className="text-center flex flex-col items-center gap-0.5 cursor-pointer hover:bg-muted/30 rounded px-2 py-1 transition-colors"
        onClick={(e) => {
          e.stopPropagation();
          onOpenHistory?.(metric);
        }}
      >
        <div className="flex items-center gap-1 font-medium">
          {icon}
          {value != null ? `${value}%` : '—'}
        </div>
        {sparklineData.length > 1 ? (
          <ScoreSparkline
            data={sparklineData}
            height={16}
            width={48}
            colorStart={colorStart}
            colorEnd={colorEnd}
            showTooltip={false}
            label={label}
          />
        ) : (
          <div className="text-xs text-muted-foreground">{label}</div>
        )}
      </div>
    </ScoreReasoningTooltip>
  );
}

export function AccountStakeholderMapTab({ accountId }: AccountStakeholderMapTabProps) {
  const queryClient = useQueryClient();
  const [selectedStakeholder, setSelectedStakeholder] = useState<Stakeholder | null>(null);
  const [editValues, setEditValues] = useState<{ influence: number; sentiment: number; champion: number }>({ influence: 50, sentiment: 50, champion: 50 });
  const [showIgnored, setShowIgnored] = useState(false);
  const [stakeholderToRemove, setStakeholderToRemove] = useState<Stakeholder | null>(null);
  const [removeReason, setRemoveReason] = useState('');
  const [selectedOpportunityId, setSelectedOpportunityId] = useState<string>('all');
  
  // History panel state
  const [historyPanel, setHistoryPanel] = useState<{
    open: boolean;
    contactId: string;
    contactName: string;
    metric: 'sentiment' | 'influence_level' | 'champion_score';
    currentValue: number | null;
  } | null>(null);

  // Fetch opportunities for this account
  const { data: opportunities } = useQuery({
    queryKey: ['account-opportunities', accountId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('opportunities')
        .select('id, name')
        .eq('account_id', accountId)
        .order('name');
      
      if (error) throw error;
      return data as Opportunity[];
    },
  });

  // Fetch stakeholders (contacts with assessment data) - use gateway for decryption
  const { data: stakeholders, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['stakeholder-map', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_contacts')
        .select('id, name, role, email, influence_level, sentiment, champion_score, stakeholder_type, last_assessed_at, assessment_source, is_ignored, is_internal, advocacy_signals, info_sharing_signals, opportunity_id')
        .eq('account_id', accountId)
        .order('name', { ascending: true })
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return (data || []).map(d => ({
        ...d,
        // Keep null values to show "Needs Analysis" instead of fake 50s
        influence_level: d.influence_level,
        sentiment: d.sentiment,
        champion_score: d.champion_score,
        stakeholder_type: (d.stakeholder_type as StakeholderType) || 'unknown',
        is_ignored: d.is_ignored ?? false,
        is_internal: d.is_internal ?? false,
        advocacy_signals: d.advocacy_signals,
        info_sharing_signals: d.info_sharing_signals,
        opportunity_id: d.opportunity_id,
      })) as Stakeholder[];
    },
    retry: 2,
    retryDelay: 1000,
  });

  // Fetch contact snapshots for sparklines
  const { data: contactSnapshots } = useAccountContactSnapshots(accountId);

  // Auto-fix: Mark @pendo.io contacts as internal if they were misclassified
  useEffect(() => {
    if (!stakeholders) return;
    
    const misclassifiedContacts = stakeholders.filter(s => 
      !s.is_internal && s.email && s.email.toLowerCase().endsWith('@pendo.io')
    );
    
    if (misclassifiedContacts.length > 0) {
      console.log(`[Stakeholders] Auto-fixing ${misclassifiedContacts.length} misclassified internal contacts`);
      
      // Update each misclassified contact to internal
      Promise.all(misclassifiedContacts.map(async (contact) => {
        try {
          await supabase
            .from('account_contacts')
            .update({ is_internal: true })
            .eq('id', contact.id);
        } catch (err) {
          console.error('Failed to fix internal classification:', err);
        }
      })).then(() => {
        // Refetch to update the view
        queryClient.invalidateQueries({ queryKey: ['stakeholder-map', accountId] });
        toast.info(`Fixed ${misclassifiedContacts.length} misclassified internal contact(s)`);
      });
    }
  }, [stakeholders, accountId, queryClient]);

  // Filter stakeholders based on showIgnored toggle and selected opportunity
  const visibleStakeholders = useMemo(() => {
    if (!stakeholders) return [];
    let filtered = stakeholders;
    
    // Filter by opportunity if selected
    if (selectedOpportunityId !== 'all') {
      filtered = filtered.filter(s => s.opportunity_id === selectedOpportunityId);
    }
    
    // Filter by ignored status
    if (!showIgnored) {
      filtered = filtered.filter(s => !s.is_ignored && !s.is_internal);
    }
    
    return filtered;
  }, [stakeholders, showIgnored, selectedOpportunityId]);

  const ignoredCount = useMemo(() => {
    if (!stakeholders) return 0;
    return stakeholders.filter(s => s.is_ignored || s.is_internal).length;
  }, [stakeholders]);

  // Update stakeholder mutation
  const updateStakeholder = useMutation({
    mutationFn: async ({ id, influence, sentiment, champion }: { id: string; influence: number; sentiment: number; champion: number }) => {
      const { error } = await supabase
        .from('account_contacts')
        .update({
          influence_level: influence,
          sentiment: sentiment,
          champion_score: champion,
          last_assessed_at: new Date().toISOString(),
          assessment_source: 'manual',
        })
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['stakeholder-map', accountId] });
      toast.success('Stakeholder updated');
      setSelectedStakeholder(null);
    },
    onError: (error) => {
      toast.error('Failed to update stakeholder');
      console.error(error);
    },
  });

  // Remove (ignore) stakeholder mutation
  const ignoreStakeholder = useMutation({
    mutationFn: async ({ id, reason, isInternal }: { id: string; reason: string; isInternal: boolean }) => {
      const { error } = await supabase
        .from('account_contacts')
        .update({
          is_ignored: !isInternal,
          is_internal: isInternal,
          ignored_reason: reason,
        })
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['stakeholder-map', accountId] });
      toast.success('Stakeholder removed from analysis');
      setStakeholderToRemove(null);
      setRemoveReason('');
    },
    onError: (error) => {
      toast.error('Failed to remove stakeholder');
      console.error(error);
    },
  });

  // Restore stakeholder mutation
  const restoreStakeholder = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('account_contacts')
        .update({
          is_ignored: false,
          is_internal: false,
          ignored_reason: null,
        })
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['stakeholder-map', accountId] });
      toast.success('Stakeholder restored');
    },
    onError: (error) => {
      toast.error('Failed to restore stakeholder');
      console.error(error);
    },
  });

  // Calculate bubble positions and sizes - handle null scores properly
  const bubbleData = useMemo(() => {
    if (!visibleStakeholders) return [];
    
    // Only include stakeholders with assessed scores on the chart
    return visibleStakeholders
      .filter(s => s.influence_level !== null && s.sentiment !== null)
      .map(s => ({
        ...s,
        x: s.sentiment!, // 0-100 (negative to positive)
        y: s.influence_level!, // 0-100 (low to high)
        size: Math.max(24, Math.min(80, 24 + ((s.champion_score ?? 0) / 100) * 56)), // 24-80px based on champion score (more visible range)
        quadrant: s.influence_level! >= 50 
          ? (s.sentiment! >= 50 ? 'topRight' : 'topLeft')
          : (s.sentiment! >= 50 ? 'bottomRight' : 'bottomLeft'),
      }));
  }, [visibleStakeholders]);

  // Stakeholders that need analysis (null scores)
  const unassessedStakeholders = useMemo(() => {
    if (!visibleStakeholders) return [];
    return visibleStakeholders.filter(s => 
      s.influence_level === null || s.sentiment === null || s.stakeholder_type === 'unknown'
    );
  }, [visibleStakeholders]);

  // Stats summary - now based on stakeholder_type, not just position
  const stats = useMemo(() => {
    if (!visibleStakeholders?.length) return null;
    
    const champions = visibleStakeholders.filter(s => s.stakeholder_type === 'champion');
    const economicBuyers = visibleStakeholders.filter(s => s.stakeholder_type === 'economic_buyer');
    const blockers = visibleStakeholders.filter(s => s.stakeholder_type === 'blocker');
    const needsAnalysis = visibleStakeholders.filter(s => 
      s.stakeholder_type === 'unknown' || s.influence_level === null
    );
    
    return {
      total: visibleStakeholders.length,
      champions: champions.length,
      economicBuyers: economicBuyers.length,
      blockers: blockers.length,
      needsAnalysis: needsAnalysis.length,
    };
  }, [visibleStakeholders]);

  const handleStakeholderClick = (stakeholder: Stakeholder) => {
    setSelectedStakeholder(stakeholder);
    setEditValues({
      influence: stakeholder.influence_level ?? 50,
      sentiment: stakeholder.sentiment ?? 50,
      champion: stakeholder.champion_score ?? 0,
    });
  };

  const handleSave = () => {
    if (!selectedStakeholder) return;
    updateStakeholder.mutate({
      id: selectedStakeholder.id,
      influence: editValues.influence,
      sentiment: editValues.sentiment,
      champion: editValues.champion,
    });
  };

  const getSentimentIcon = (sentiment: number | null) => {
    if (sentiment === null) return <Minus className="w-4 h-4 text-border" />;
    if (sentiment >= 60) return <TrendingUp className="w-4 h-4 text-primary" />;
    if (sentiment <= 40) return <TrendingDown className="w-4 h-4 text-destructive" />;
    return <Minus className="w-4 h-4 text-muted-foreground" />;
  };

  const getStakeholderTypeBadge = (type: StakeholderType | null) => {
    const typeInfo = STAKEHOLDER_TYPES[type || 'unknown'];
    return (
      <Badge 
        variant={type === 'unknown' ? 'outline' : 'secondary'}
        className="gap-1"
        style={{ 
          borderColor: type === 'unknown' ? undefined : typeInfo.color,
          color: type === 'unknown' ? undefined : typeInfo.color,
        }}
      >
        <span>{typeInfo.icon}</span>
        {typeInfo.label}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center">
        <RefreshCw className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="p-6">
        <Card className="border-destructive/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="w-12 h-12 text-destructive mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">Failed to Load Stakeholders</h3>
            <p className="text-sm text-muted-foreground text-center max-w-md mb-4">
              {error instanceof Error ? error.message : 'An error occurred while loading stakeholders.'}
            </p>
            <Button variant="outline" onClick={() => refetch()}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!stakeholders?.length) {
    return (
      <div className="p-6">
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">No Stakeholders Found</h3>
            <p className="text-sm text-muted-foreground text-center max-w-md">
              Stakeholders are extracted from transcript analysis. Upload and analyze transcripts to populate this map.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header with stats */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <Users className="w-5 h-5" />
            Stakeholder Map
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            External stakeholders only. Bubble size indicates champion potential.
          </p>
        </div>
        <div className="flex items-center gap-4">
          {/* Opportunity Filter */}
          {opportunities && opportunities.length > 0 && (
            <Select value={selectedOpportunityId} onValueChange={setSelectedOpportunityId}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filter by opportunity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Opportunities</SelectItem>
                {opportunities.map((opp) => (
                  <SelectItem key={opp.id} value={opp.id}>
                    {opp.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          {ignoredCount > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowIgnored(!showIgnored)}
              className="gap-2"
            >
              {showIgnored ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {showIgnored ? 'Hide' : 'Show'} Removed ({ignoredCount})
            </Button>
          )}
          {stats && (
            <div className="flex gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-foreground">{stats.total}</div>
                <div className="text-xs text-muted-foreground">Stakeholders</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">{stats.champions}</div>
                <div className="text-xs text-muted-foreground">Champions</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-layer-growth">{stats.economicBuyers}</div>
                <div className="text-xs text-muted-foreground">Econ. Buyers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-destructive">{stats.blockers}</div>
                <div className="text-xs text-muted-foreground">Blockers</div>
              </div>
              {stats.needsAnalysis > 0 && (
                <div className="text-center">
                  <div className="text-2xl font-bold text-border">{stats.needsAnalysis}</div>
                  <div className="text-xs text-muted-foreground">Needs Analysis</div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bubble Chart */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex gap-4 text-xs">
              {Object.entries(QUADRANTS).map(([key, quad]) => (
                <div key={key} className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: quad.color }} />
                  <span className="text-muted-foreground">{quad.label}</span>
                </div>
              ))}
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-6 w-6">
                    <Info className="w-4 h-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="left" className="max-w-xs">
                  <p>Click on a bubble to edit stakeholder scores. Larger bubbles indicate higher champion potential.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </CardHeader>
        <CardContent>
          {/* Chart Area */}
          <div className="relative w-full h-[500px] bg-muted/20 rounded-lg border border-border overflow-hidden">
            {/* Grid lines */}
            <div className="absolute inset-0">
              {/* Horizontal center line */}
              <div className="absolute left-0 right-0 top-1/2 border-t border-border/50" />
              {/* Vertical center line */}
              <div className="absolute top-0 bottom-0 left-1/2 border-l border-border/50" />
              {/* Grid pattern */}
              {[25, 75].map(pos => (
                <div key={`h-${pos}`} className="absolute left-0 right-0 border-t border-border/20" style={{ top: `${100 - pos}%` }} />
              ))}
              {[25, 75].map(pos => (
                <div key={`v-${pos}`} className="absolute top-0 bottom-0 border-l border-border/20" style={{ left: `${pos}%` }} />
              ))}
            </div>

            {/* Axis labels */}
            <div className="absolute left-2 top-1/2 -translate-y-1/2 -rotate-90 text-xs text-muted-foreground font-medium whitespace-nowrap">
              INFLUENCE →
            </div>
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-xs text-muted-foreground font-medium">
              ← Negative | SENTIMENT | Positive →
            </div>

            {/* Quadrant labels */}
            <div className="absolute top-4 left-4 text-xs font-medium text-destructive/70">Blockers</div>
            <div className="absolute top-4 right-4 text-xs font-medium text-primary/70">Champions</div>
            <div className="absolute bottom-8 left-4 text-xs font-medium text-muted-foreground/70">Detractors</div>
            <div className="absolute bottom-8 right-4 text-xs font-medium text-layer-growth/70">Supporters</div>

            {/* Bubbles */}
            <TooltipProvider>
              {bubbleData.map((bubble) => (
                <Tooltip key={bubble.id}>
                  <TooltipTrigger asChild>
                    <button
                      className={cn(
                        "absolute rounded-full border-2 border-background shadow-lg transition-all hover:scale-110 hover:z-10 focus:outline-none focus:ring-2 focus:ring-ring",
                        "flex items-center justify-center text-[10px] font-medium text-white"
                      )}
                      style={{
                        left: `calc(${bubble.x}% - ${bubble.size / 2}px)`,
                        bottom: `calc(${bubble.y}% - ${bubble.size / 2}px)`,
                        width: `${bubble.size}px`,
                        height: `${bubble.size}px`,
                        backgroundColor: QUADRANTS[bubble.quadrant as keyof typeof QUADRANTS].color,
                      }}
                      onClick={() => handleStakeholderClick(bubble)}
                    >
                      {bubble.name?.split(' ').map(n => n?.[0] || '').join('').slice(0, 2) || '?'}
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="space-y-1">
                      <div className="font-medium">{bubble.name}</div>
                      {bubble.role && <div className="text-xs text-muted-foreground">{bubble.role}</div>}
                      <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-xs pt-1 border-t">
                        <span className="text-muted-foreground">Influence:</span>
                        <span>{bubble.influence_level}%</span>
                        <span className="text-muted-foreground">Sentiment:</span>
                        <span>{bubble.sentiment}%</span>
                        <span className="text-muted-foreground">Champion:</span>
                        <span>{bubble.champion_score}%</span>
                      </div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              ))}
            </TooltipProvider>
          </div>
        </CardContent>
      </Card>

      {/* Stakeholder List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Stakeholder Details</CardTitle>
          <CardDescription>Click to edit assessment scores</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="divide-y divide-border">
            {(showIgnored ? stakeholders : visibleStakeholders)?.map((s) => (
              <div
                key={s.id}
                className={cn(
                  "py-3 flex items-center justify-between -mx-4 px-4 transition-colors",
                  s.is_ignored || s.is_internal ? "opacity-50 bg-muted/30" : "cursor-pointer hover:bg-muted/50"
                )}
                onClick={() => !s.is_ignored && !s.is_internal && handleStakeholderClick(s)}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium text-white"
                    style={{ 
                      backgroundColor: s.is_ignored || s.is_internal || s.influence_level === null || s.sentiment === null
                        ? 'hsl(var(--muted-foreground))'
                        : QUADRANTS[
                          (s.influence_level ?? 0) >= 50 
                            ? ((s.sentiment ?? 0) >= 50 ? 'topRight' : 'topLeft')
                            : ((s.sentiment ?? 0) >= 50 ? 'bottomRight' : 'bottomLeft')
                        ].color 
                    }}
                  >
                    {s.name?.split(' ').map(n => n?.[0] || '').join('').slice(0, 2) || '?'}
                  </div>
                  <div>
                    <div className="font-medium text-foreground flex items-center gap-2">
                      {s.name}
                      {s.is_internal && <Badge variant="secondary" className="text-xs">Internal</Badge>}
                      {s.is_ignored && <Badge variant="outline" className="text-xs">Removed</Badge>}
                    </div>
                    <div className="text-sm text-muted-foreground">{s.role || 'No role specified'}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  {!s.is_ignored && !s.is_internal && (
                    <>
                      <StakeholderScoreCell
                        value={s.influence_level}
                        label="Influence"
                        contactId={s.id}
                        contactName={s.name}
                        metric="influence_level"
                        snapshots={contactSnapshots}
                        colorStart="hsl(var(--muted-foreground))"
                        colorEnd="hsl(217, 91%, 60%)"
                        onOpenHistory={(metric) => setHistoryPanel({
                          open: true,
                          contactId: s.id,
                          contactName: s.name,
                          metric,
                          currentValue: s.influence_level,
                        })}
                      />
                      <StakeholderScoreCell
                        value={s.sentiment}
                        label="Sentiment"
                        contactId={s.id}
                        contactName={s.name}
                        metric="sentiment"
                        snapshots={contactSnapshots}
                        colorStart="hsl(var(--muted-foreground))"
                        colorEnd="hsl(142, 76%, 36%)"
                        icon={getSentimentIcon(s.sentiment)}
                        onOpenHistory={(metric) => setHistoryPanel({
                          open: true,
                          contactId: s.id,
                          contactName: s.name,
                          metric,
                          currentValue: s.sentiment,
                        })}
                      />
                      <StakeholderScoreCell
                        value={s.champion_score}
                        label="Champion"
                        contactId={s.id}
                        contactName={s.name}
                        metric="champion_score"
                        snapshots={contactSnapshots}
                        colorStart="hsl(var(--muted-foreground))"
                        colorEnd="hsl(45, 93%, 47%)"
                        onOpenHistory={(metric) => setHistoryPanel({
                          open: true,
                          contactId: s.id,
                          contactName: s.name,
                          metric,
                          currentValue: s.champion_score,
                        })}
                      />
                      {s.assessment_source && (
                        <Badge variant="outline" className="text-xs">
                          {s.assessment_source}
                        </Badge>
                      )}
                    </>
                  )}
                  {(s.is_ignored || s.is_internal) ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        restoreStakeholder.mutate(s.id);
                      }}
                    >
                      Restore
                    </Button>
                  ) : (
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            onClick={(e) => {
                              e.stopPropagation();
                              setStakeholderToRemove(s);
                            }}
                          >
                            <UserX className="w-4 h-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Remove from analysis</TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Remove Confirmation Dialog */}
      <AlertDialog open={!!stakeholderToRemove} onOpenChange={(open) => !open && setStakeholderToRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Stakeholder from Analysis</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove <strong>{stakeholderToRemove?.name}</strong> from the stakeholder map. 
              You can restore them later if needed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-4 space-y-4">
            <div className="flex gap-2">
              <Button
                variant={removeReason === 'internal' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setRemoveReason('internal')}
              >
                Internal Employee (Pendo)
              </Button>
              <Button
                variant={removeReason === 'other' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setRemoveReason('other')}
              >
                Other Reason
              </Button>
            </div>
            {removeReason === 'other' && (
              <Input
                placeholder="Reason for removal..."
                value={removeReason === 'other' ? '' : removeReason}
                onChange={(e) => setRemoveReason(e.target.value || 'other')}
              />
            )}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setRemoveReason('')}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (stakeholderToRemove && removeReason) {
                  ignoreStakeholder.mutate({
                    id: stakeholderToRemove.id,
                    reason: removeReason === 'internal' ? 'Internal Pendo employee' : removeReason,
                    isInternal: removeReason === 'internal',
                  });
                }
              }}
              disabled={!removeReason || ignoreStakeholder.isPending}
            >
              {ignoreStakeholder.isPending ? 'Removing...' : 'Remove'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Dialog */}
      <Dialog open={!!selectedStakeholder} onOpenChange={(open) => !open && setSelectedStakeholder(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Stakeholder Assessment</DialogTitle>
          </DialogHeader>
          {selectedStakeholder && (
            <div className="space-y-6 py-4">
              <div className="flex items-center justify-between pb-4 border-b">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center text-lg font-medium text-white"
                    style={{ backgroundColor: 'hsl(var(--primary))' }}
                  >
                    {selectedStakeholder.name?.split(' ').map(n => n?.[0] || '').join('').slice(0, 2) || '?'}
                  </div>
                  <div>
                    <div className="font-medium text-lg">{selectedStakeholder.name}</div>
                    <div className="text-sm text-muted-foreground">{selectedStakeholder.role || 'No role'}</div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-destructive hover:text-destructive"
                  onClick={() => {
                    setSelectedStakeholder(null);
                    setStakeholderToRemove(selectedStakeholder);
                  }}
                >
                  <UserX className="w-4 h-4 mr-1" />
                  Remove
                </Button>
              </div>

              <div className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Influence Level</Label>
                    <span className="text-sm font-medium">{editValues.influence}%</span>
                  </div>
                  <Slider
                    value={[editValues.influence]}
                    onValueChange={([v]) => setEditValues(prev => ({ ...prev, influence: v }))}
                    max={100}
                    step={5}
                  />
                  <p className="text-xs text-muted-foreground">How much decision-making power does this person have?</p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Sentiment</Label>
                    <span className="text-sm font-medium">{editValues.sentiment}%</span>
                  </div>
                  <Slider
                    value={[editValues.sentiment]}
                    onValueChange={([v]) => setEditValues(prev => ({ ...prev, sentiment: v }))}
                    max={100}
                    step={5}
                  />
                  <p className="text-xs text-muted-foreground">0% = Very negative, 50% = Neutral, 100% = Very positive</p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Champion Score</Label>
                    <span className="text-sm font-medium">{editValues.champion}%</span>
                  </div>
                  <Slider
                    value={[editValues.champion]}
                    onValueChange={([v]) => setEditValues(prev => ({ ...prev, champion: v }))}
                    max={100}
                    step={5}
                  />
                  <p className="text-xs text-muted-foreground">How likely are they to advocate for us internally?</p>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => setSelectedStakeholder(null)}>
                  Cancel
                </Button>
                <Button onClick={handleSave} disabled={updateStakeholder.isPending}>
                  {updateStakeholder.isPending ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Score History Panel */}
      {historyPanel && (
        <ScoreHistoryPanel
          open={historyPanel.open}
          onOpenChange={(open) => setHistoryPanel(open ? historyPanel : null)}
          contactName={historyPanel.contactName}
          metric={historyPanel.metric}
          snapshots={contactSnapshots || []}
          contactId={historyPanel.contactId}
          currentValue={historyPanel.currentValue}
        />
      )}
    </div>
  );
}

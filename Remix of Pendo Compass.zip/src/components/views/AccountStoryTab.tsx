import { useState } from 'react';
import { BookOpen, Sparkles, Loader2, Save, TrendingUp, AlertCircle, ArrowRight, Building2, Edit2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { 
  useAccountWithDetails, 
  useCustomerStories, 
  useCreateCustomerStory,
  useUpdateCustomerStory,
  useAccountContacts,
  useAccountNbas,
} from '@/hooks/useAccounts';
import { useTranscriptReviews } from '@/hooks/useAccounts';
import { useAccountUseCases } from '@/hooks/useAccountUseCases';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface AccountStoryTabProps {
  accountId: string;
}

interface GeneratedStory {
  title: string;
  situation: string;
  situationMetrics: string;
  behavior: string;
  technologiesUsed: string[];
  useCases: string[];
  impact: string;
  impactMetrics: { metric: string; before: string; after: string }[];
  tags: string[];
}

export function AccountStoryTab({ accountId }: AccountStoryTabProps) {
  const { data: account } = useAccountWithDetails(accountId);
  const { data: existingStories, isLoading: loadingStories } = useCustomerStories(accountId);
  const { data: contacts } = useAccountContacts(accountId);
  const { data: nbas } = useAccountNbas(accountId);
  const { data: useCases } = useAccountUseCases(accountId);
  const { data: transcriptReviews } = useTranscriptReviews();
  
  const createStory = useCreateCustomerStory();
  const updateStory = useUpdateCustomerStory();

  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedStory, setGeneratedStory] = useState<GeneratedStory | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedStory, setEditedStory] = useState<GeneratedStory | null>(null);

  const accountTranscripts = transcriptReviews?.filter(
    t => t.final_account_id === accountId || t.suggested_account_id === accountId
  ) || [];

  const handleGenerateStory = async () => {
    if (!account) return;

    setIsGenerating(true);
    try {
      const accountData = {
        name: account.name,
        industry: account.industry,
        technologies: account.technologies.map(t => ({
          name: t.name,
          layer: t.layer,
          category: t.category,
          notes: t.notes,
        })),
        useCases: useCases?.map(uc => ({
          use_case: uc.use_case,
          functional_area: uc.functional_area,
          description: uc.description,
          status: uc.status,
        })) || [],
        transcripts: accountTranscripts.map(t => ({
          insights: t.extracted_insights,
        })),
        nbas: nbas?.map(n => ({
          action: n.action,
          action_type: n.action_type,
          status: n.status,
        })) || [],
        contacts: contacts?.map((c: any) => ({
          name: c.name,
          role: c.role,
        })) || [],
      };

      const { data, error } = await supabase.functions.invoke('generate-customer-story', {
        body: { accountData }
      });

      if (error) throw error;

      setGeneratedStory(data);
      setEditedStory(data);
      toast.success('Customer story generated successfully!');
    } catch (error) {
      console.error('Error generating story:', error);
      toast.error('Failed to generate customer story');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveStory = async () => {
    if (!editedStory) return;

    try {
      await createStory.mutateAsync({
        account_id: accountId,
        title: editedStory.title,
        situation: editedStory.situation,
        situation_metrics: editedStory.situationMetrics,
        behavior: editedStory.behavior,
        technologies_used: editedStory.technologiesUsed,
        use_cases: editedStory.useCases,
        impact: editedStory.impact,
        impact_metrics: editedStory.impactMetrics,
        tags: editedStory.tags,
        industry: account?.industry,
        status: 'draft',
      });

      setGeneratedStory(null);
      setEditedStory(null);
      setIsEditing(false);
    } catch (error) {
      console.error('Error saving story:', error);
    }
  };

  const latestStory = existingStories?.[0];

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Customer Story</h2>
          <p className="text-sm text-muted-foreground">
            AI-generated story based on account data, transcripts, and use cases
          </p>
        </div>
        <Button
          variant="glow"
          onClick={handleGenerateStory}
          disabled={isGenerating}
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              {latestStory ? 'Regenerate Story' : 'Generate Story'}
            </>
          )}
        </Button>
      </div>

      {/* Data Summary */}
      <div className="grid grid-cols-4 gap-4">
        <div className="glass rounded-lg p-4">
          <p className="text-2xl font-bold">{account?.technologies.length || 0}</p>
          <p className="text-xs text-muted-foreground">Technologies</p>
        </div>
        <div className="glass rounded-lg p-4">
          <p className="text-2xl font-bold">{useCases?.length || 0}</p>
          <p className="text-xs text-muted-foreground">Use Cases</p>
        </div>
        <div className="glass rounded-lg p-4">
          <p className="text-2xl font-bold">{accountTranscripts.length}</p>
          <p className="text-xs text-muted-foreground">Transcripts</p>
        </div>
        <div className="glass rounded-lg p-4">
          <p className="text-2xl font-bold">{contacts?.length || 0}</p>
          <p className="text-xs text-muted-foreground">Contacts</p>
        </div>
      </div>

      {/* Generated Story Preview/Edit */}
      {(generatedStory || editedStory) && (
        <div className="glass rounded-xl p-6 space-y-6">
          <div className="flex items-start justify-between">
            <div>
              {isEditing ? (
                <Input
                  value={editedStory?.title || ''}
                  onChange={(e) => setEditedStory(prev => prev ? { ...prev, title: e.target.value } : null)}
                  className="text-xl font-bold"
                />
              ) : (
                <h3 className="text-xl font-bold">{editedStory?.title}</h3>
              )}
              <div className="flex flex-wrap gap-2 mt-2">
                {editedStory?.tags?.map((tag, i) => (
                  <Badge key={i} variant="secondary">{tag}</Badge>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(!isEditing)}
              >
                <Edit2 className="w-4 h-4 mr-1" />
                {isEditing ? 'Preview' : 'Edit'}
              </Button>
              <Button
                size="sm"
                onClick={handleSaveStory}
                disabled={createStory.isPending}
              >
                <Save className="w-4 h-4 mr-1" />
                Save Story
              </Button>
            </div>
          </div>

          {/* Situation */}
          <div className="space-y-2">
            <h4 className="font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-destructive/20 flex items-center justify-center text-xs text-destructive">
                <AlertCircle className="w-3 h-3" />
              </span>
              Situation
            </h4>
            {isEditing ? (
              <Textarea
                value={editedStory?.situation || ''}
                onChange={(e) => setEditedStory(prev => prev ? { ...prev, situation: e.target.value } : null)}
                rows={4}
              />
            ) : (
              <p className="text-muted-foreground whitespace-pre-wrap">{editedStory?.situation}</p>
            )}
            {editedStory?.situationMetrics && (
              <div className="bg-destructive/10 rounded-lg p-3 text-sm">
                <strong>Key Metrics:</strong> {editedStory.situationMetrics}
              </div>
            )}
          </div>

          {/* Behavior */}
          <div className="space-y-2">
            <h4 className="font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs text-primary">
                <ArrowRight className="w-3 h-3" />
              </span>
              Behavior (Solution)
            </h4>
            {isEditing ? (
              <Textarea
                value={editedStory?.behavior || ''}
                onChange={(e) => setEditedStory(prev => prev ? { ...prev, behavior: e.target.value } : null)}
                rows={4}
              />
            ) : (
              <p className="text-muted-foreground whitespace-pre-wrap">{editedStory?.behavior}</p>
            )}
            <div className="flex flex-wrap gap-2">
              {editedStory?.technologiesUsed?.map((tech, i) => (
                <Badge key={i} variant="outline" className="border-primary/50 text-primary">{tech}</Badge>
              ))}
              {editedStory?.useCases?.map((uc, i) => (
                <Badge key={i} variant="secondary">{uc}</Badge>
              ))}
            </div>
          </div>

          {/* Impact */}
          <div className="space-y-2">
            <h4 className="font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-layer-growth/20 flex items-center justify-center text-xs text-layer-growth">
                <TrendingUp className="w-3 h-3" />
              </span>
              Impact
            </h4>
            {isEditing ? (
              <Textarea
                value={editedStory?.impact || ''}
                onChange={(e) => setEditedStory(prev => prev ? { ...prev, impact: e.target.value } : null)}
                rows={4}
              />
            ) : (
              <p className="text-muted-foreground whitespace-pre-wrap">{editedStory?.impact}</p>
            )}
            
            {editedStory?.impactMetrics && editedStory.impactMetrics.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-3">
                {editedStory.impactMetrics.map((m, i) => (
                  <div key={i} className="bg-layer-growth/10 rounded-lg p-3 text-center">
                    <p className="text-xs text-muted-foreground">{m.metric}</p>
                    <div className="flex items-center justify-center gap-2 mt-1">
                      <span className="text-sm line-through text-muted-foreground">{m.before}</span>
                      <ArrowRight className="w-3 h-3" />
                      <span className="text-sm font-bold text-layer-growth">{m.after}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Existing Story */}
      {latestStory && !generatedStory && (
        <div className="glass rounded-xl p-6 space-y-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <Building2 className="w-4 h-4" />
                {account?.name}
                <Badge variant={latestStory.status === 'published' ? 'default' : 'secondary'}>
                  {latestStory.status}
                </Badge>
              </div>
              <h3 className="text-xl font-bold">{latestStory.title}</h3>
              <div className="flex flex-wrap gap-2 mt-2">
                {(latestStory.tags as string[] | null)?.map((tag, i) => (
                  <Badge key={i} variant="secondary">{tag}</Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Situation */}
          <div className="space-y-2">
            <h4 className="font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-destructive/20 flex items-center justify-center text-xs text-destructive">
                <AlertCircle className="w-3 h-3" />
              </span>
              Situation
            </h4>
            <p className="text-muted-foreground whitespace-pre-wrap">{latestStory.situation}</p>
            {latestStory.situation_metrics && (
              <div className="bg-destructive/10 rounded-lg p-3 text-sm">
                <strong>Key Metrics:</strong> {latestStory.situation_metrics}
              </div>
            )}
          </div>

          {/* Behavior */}
          <div className="space-y-2">
            <h4 className="font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs text-primary">
                <ArrowRight className="w-3 h-3" />
              </span>
              Behavior (Solution)
            </h4>
            <p className="text-muted-foreground whitespace-pre-wrap">{latestStory.behavior}</p>
            <div className="flex flex-wrap gap-2">
              {(latestStory.technologies_used as string[] | null)?.map((tech, i) => (
                <Badge key={i} variant="outline" className="border-primary/50 text-primary">{tech}</Badge>
              ))}
              {(latestStory.use_cases as string[] | null)?.map((uc, i) => (
                <Badge key={i} variant="secondary">{uc}</Badge>
              ))}
            </div>
          </div>

          {/* Impact */}
          <div className="space-y-2">
            <h4 className="font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-layer-growth/20 flex items-center justify-center text-xs text-layer-growth">
                <TrendingUp className="w-3 h-3" />
              </span>
              Impact
            </h4>
            <p className="text-muted-foreground whitespace-pre-wrap">{latestStory.impact}</p>
            
            {latestStory.impact_metrics && Array.isArray(latestStory.impact_metrics) && (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-3">
                {(latestStory.impact_metrics as { metric: string; before: string; after: string }[]).map((m, i) => (
                  <div key={i} className="bg-layer-growth/10 rounded-lg p-3 text-center">
                    <p className="text-xs text-muted-foreground">{m.metric}</p>
                    <div className="flex items-center justify-center gap-2 mt-1">
                      <span className="text-sm line-through text-muted-foreground">{m.before}</span>
                      <ArrowRight className="w-3 h-3" />
                      <span className="text-sm font-bold text-layer-growth">{m.after}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="text-xs text-muted-foreground pt-4 border-t border-border">
            Last updated {new Date(latestStory.updated_at).toLocaleDateString()}
          </div>
        </div>
      )}

      {/* Empty State */}
      {!latestStory && !generatedStory && !loadingStories && (
        <div className="glass rounded-xl p-8 text-center">
          <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No customer story yet</p>
          <p className="text-sm text-muted-foreground mt-1">
            Click "Generate Story" to create an AI-powered story from account data
          </p>
        </div>
      )}
    </div>
  );
}

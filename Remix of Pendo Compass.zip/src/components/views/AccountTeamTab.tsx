import { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Users, Mail, Calendar, Building2, UserCircle, Phone, Plus, Trash2, Check, ChevronsUpDown, UserPlus } from 'lucide-react';
import { format } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { useInviteTeamMember } from '@/hooks/useInviteTeamMember';
import { useAllActiveUsers } from '@/hooks/useAllActiveUsers';
import { useCustomRoles } from '@/hooks/useCustomRoles';
import { cn } from '@/lib/utils';

interface AccountTeamTabProps {
  accountId: string;
}

interface TeamMemberAssignment {
  id: string;
  team_member_email: string | null;
  role: string;
  created_at: string;
  opportunity_id?: string;
  opportunity_name?: string;
}

export function AccountTeamTab({ accountId }: AccountTeamTabProps) {
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberRole, setNewMemberRole] = useState('member');
  const [userSearchOpen, setUserSearchOpen] = useState(false);
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const { inviteAsync } = useInviteTeamMember();
  const { users: allUsers, isLoading: loadingUsers } = useAllActiveUsers();
  const { roles: customRoles } = useCustomRoles();

  // Fetch team members assigned to this account
  // Fetch team members assigned to this account - use gateway for decryption
  const { data: accountTeamMembers, isLoading: loadingAccountTeam } = useQuery({
    queryKey: ['account-team-members', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_team_members')
        .select('id, team_member_email, role, created_at')
        .eq('account_id', accountId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
  });

  // Fetch team members across all opportunities for this account
  // Fetch team members across all opportunities for this account - use gateway for decryption
  const { data: opportunityTeamMembers, isLoading: loadingOppTeam } = useQuery({
    queryKey: ['account-opportunity-team-members', accountId],
    queryFn: async () => {
      // First get all opportunities for this account
      const { data: opportunities } = await supabase
        .from('opportunities')
        .select('id, name')
        .eq('account_id', accountId);

      if (!opportunities?.length) return [];

      const oppIds = opportunities.map(o => o.id);
      
      // Fetch all opportunity team members via gateway for decryption
      const allMembers: any[] = [];
      for (const oppId of oppIds) {
        const { data, error } = await gateway
          .from('opportunity_team_members')
          .select('id, team_member_email, role, created_at, opportunity_id')
          .eq('opportunity_id', oppId)
          .execute();
        if (!error && data) {
          allMembers.push(...data);
        }
      }

      // Enrich with opportunity names
      return allMembers.map(tm => ({
        ...tm,
        opportunity_name: opportunities.find(o => o.id === tm.opportunity_id)?.name || 'Unknown',
      }));
    },
  });

  // Fetch team member names from team_members table
  const { data: teamMemberDetails } = useQuery({
    queryKey: ['team-member-details'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('team_members')
        .select('member_email, member_name');
      if (error) throw error;
      return data || [];
    },
  });

  // Fetch contacts (external stakeholders) for this account - use gateway for decryption
  const { data: contacts, isLoading: loadingContacts } = useQuery({
    queryKey: ['account-contacts-team', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_contacts')
        .select('*')
        .eq('account_id', accountId)
        .eq('is_internal', false)
        .not('is_ignored', 'is', true)
        .order('name', { ascending: true })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
  });

  // Add team member mutation - also creates identified/pending user profile
  const addTeamMember = useMutation({
    mutationFn: async ({ email, name, role }: { email: string; name?: string; role: string }) => {
      const normalizedEmail = email.toLowerCase().trim();
      
      // Check if already exists - email is encrypted so we must fetch all and filter in memory
      const { data: allMembers } = await gateway
        .from('account_team_members')
        .select('id, team_member_email')
        .eq('account_id', accountId)
        .execute();
      
      const existingMember = (allMembers || []).find((m: any) => 
        m.team_member_email && m.team_member_email.toLowerCase().trim() === normalizedEmail
      );
      
      if (existingMember) {
        throw { code: '23505', message: 'Member already assigned' };
      }
      
      // Add to account_team_members using encrypted insert
      const { encryptedInsert } = await import('@/lib/encryptedDb');
      const { error } = await encryptedInsert('account_team_members', { 
        account_id: accountId, 
        team_member_email: normalizedEmail, 
        role 
      });
      if (error) throw error;
      
      // Check if user exists in profiles
      const existingUser = allUsers.find(u => u.email.toLowerCase() === normalizedEmail);
      
      if (!existingUser) {
        // User doesn't exist - try invite (for pendo.io emails) or create identified profile
        if (normalizedEmail.endsWith('@pendo.io')) {
          try {
            await inviteAsync({ email: normalizedEmail, name: name?.trim() || undefined });
          } catch (inviteError: any) {
            // If invite fails, create as identified user directly
            console.log('Invite failed, creating identified profile:', inviteError);
            const { v4: uuidv4 } = await import('uuid');
            const { error: profileError } = await supabase
              .from('profiles')
              .insert([{
                id: uuidv4(),
                email: normalizedEmail,
                full_name: name?.trim() || normalizedEmail.split('@')[0],
                status: 'identified',
              }]);
            if (profileError && !profileError.message?.includes('duplicate')) {
              console.error('Failed to create identified profile:', profileError);
            }
          }
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['account-team-members', accountId] });
      queryClient.invalidateQueries({ queryKey: ['assignable-users'] });
      queryClient.invalidateQueries({ queryKey: ['all-active-users'] });
      toast.success('Team member added');
      setIsAddDialogOpen(false);
      setNewMemberEmail('');
      setNewMemberName('');
      setNewMemberRole('member');
      setUserSearchQuery('');
    },
    onError: (error: any) => {
      if (error.code === '23505') {
        toast.error('Member already assigned');
      } else {
        toast.error('Failed to add team member');
      }
    },
  });

  // Remove team member mutation
  const removeTeamMember = useMutation({
    mutationFn: async (memberId: string) => {
      const { error } = await supabase
        .from('account_team_members')
        .delete()
        .eq('id', memberId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['account-team-members', accountId] });
      toast.success('Team member removed');
    },
    onError: () => {
      toast.error('Failed to remove team member');
    },
  });

  // Validate email format - filter out dates, invalid strings, etc.
  const isValidEmail = (email?: string | null): boolean => {
    if (!email) return false;
    const trimmed = email.trim();
    // Must contain @ and a dot after @, and not look like a date
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const datePattern = /^\d{1,2}\/\d{1,2}\/\d{2,4}$/;
    const timePattern = /^\d{1,2}:\d{2}/;
    return emailPattern.test(trimmed) && !datePattern.test(trimmed) && !timePattern.test(trimmed);
  };

  const emailLocalPart = (email?: string | null) => {
    const safe = (email ?? '').trim();
    if (!safe) return 'Unknown';
    return safe.split('@')[0] || safe;
  };

  const getMemberName = (email?: string | null) => {
    if (!email) return null;
    const member = teamMemberDetails?.find(m => m.member_email.toLowerCase() === email.toLowerCase());
    return member?.member_name || null;
  };

  // Get account member id for removal
  const getAccountMemberId = (email?: string | null) => {
    if (!email) return undefined;
    return accountTeamMembers?.find(m => m.team_member_email?.toLowerCase() === email.toLowerCase())?.id;
  };

  const allTeamMembers = new Map<
    string,
    {
      email: string;
      name: string | null;
      opportunities: string[];
      role: string;
      firstSeen: string;
      accountMemberId?: string;
    }
  >();

  accountTeamMembers?.forEach(tm => {
    const email = tm.team_member_email;
    // Skip invalid entries (dates, malformed strings, etc.)
    if (!email || !isValidEmail(email)) return;

    if (!allTeamMembers.has(email)) {
      allTeamMembers.set(email, {
        email,
        name: getMemberName(email),
        opportunities: [],
        role: tm.role,
        firstSeen: tm.created_at,
        accountMemberId: tm.id,
      });
    }
  });

  opportunityTeamMembers?.forEach(tm => {
    const email = tm.team_member_email;
    // Skip invalid entries (dates, malformed strings, etc.)
    if (!email || !isValidEmail(email)) return;

    const existing = allTeamMembers.get(email);
    if (existing) {
      if (tm.opportunity_name && !existing.opportunities.includes(tm.opportunity_name)) {
        existing.opportunities.push(tm.opportunity_name);
      }
      if (new Date(tm.created_at) < new Date(existing.firstSeen)) {
        existing.firstSeen = tm.created_at;
      }
    } else {
      allTeamMembers.set(email, {
        email,
        name: getMemberName(email),
        opportunities: tm.opportunity_name ? [tm.opportunity_name] : [],
        role: tm.role,
        firstSeen: tm.created_at,
      });
    }
  });

  const isLoading = loadingAccountTeam || loadingOppTeam || loadingContacts;

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="h-32 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  const teamArray = Array.from(allTeamMembers.values());

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Users className="h-5 w-5" />
            Team & Contacts
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Internal team members and external stakeholders engaged with this account
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-1" />
              Add Member
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add Team Member</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Select or Enter User *</Label>
                <Popover open={userSearchOpen} onOpenChange={setUserSearchOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={userSearchOpen}
                      className="w-full justify-between font-normal"
                    >
                      {newMemberEmail ? (
                        <span className="flex items-center gap-2 truncate">
                          <Mail className="h-4 w-4 shrink-0 text-muted-foreground" />
                          {allUsers.find(u => u.email === newMemberEmail)?.full_name || newMemberEmail}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">Search users or enter email...</span>
                      )}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[350px] p-0" align="start">
                    <Command shouldFilter={false}>
                      <CommandInput 
                        placeholder="Search by name or email..." 
                        value={userSearchQuery}
                        onValueChange={setUserSearchQuery}
                      />
                      <CommandList>
                        <CommandEmpty>
                          {userSearchQuery.includes('@') ? (
                            <button
                              className="w-full p-2 text-left hover:bg-accent rounded flex items-center gap-2"
                              onClick={() => {
                                setNewMemberEmail(userSearchQuery.toLowerCase().trim());
                                // Clear name if entering new email
                                setNewMemberName('');
                                setUserSearchOpen(false);
                              }}
                            >
                              <UserPlus className="h-4 w-4 text-primary" />
                              <span>Add "{userSearchQuery}" as new user</span>
                            </button>
                          ) : (
                            <span className="text-muted-foreground text-sm">
                              No users found. Enter a full email to add a new user.
                            </span>
                          )}
                        </CommandEmpty>
                        <CommandGroup heading="Existing Users">
                          {allUsers
                            .filter(user => {
                              if (!userSearchQuery) return true;
                              const query = userSearchQuery.toLowerCase();
                              return (
                                user.email.toLowerCase().includes(query) ||
                                (user.full_name?.toLowerCase().includes(query))
                              );
                            })
                            .slice(0, 20)
                            .map((user) => (
                              <CommandItem
                                key={user.id}
                                value={user.email}
                                onSelect={() => {
                                  setNewMemberEmail(user.email);
                                  setNewMemberName(user.full_name || '');
                                  setUserSearchQuery('');
                                  setUserSearchOpen(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    newMemberEmail === user.email ? "opacity-100" : "opacity-0"
                                  )}
                                />
                                <div className="flex flex-col">
                                  <span className="font-medium">{user.full_name || user.email.split('@')[0]}</span>
                                  <span className="text-xs text-muted-foreground">{user.email}</span>
                                </div>
                              </CommandItem>
                            ))}
                        </CommandGroup>
                        {userSearchQuery.includes('@') && !allUsers.some(u => u.email.toLowerCase() === userSearchQuery.toLowerCase()) && (
                          <CommandGroup heading="Add New">
                            <CommandItem
                              value={`new-${userSearchQuery}`}
                              onSelect={() => {
                                setNewMemberEmail(userSearchQuery.toLowerCase().trim());
                                setNewMemberName('');
                                setUserSearchQuery('');
                                setUserSearchOpen(false);
                              }}
                            >
                              <UserPlus className="mr-2 h-4 w-4 text-primary" />
                              <div className="flex flex-col">
                                <span className="font-medium">Add new user</span>
                                <span className="text-xs text-muted-foreground">{userSearchQuery}</span>
                              </div>
                            </CommandItem>
                          </CommandGroup>
                        )}
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
                <p className="text-xs text-muted-foreground">
                  Select an existing user or enter a @pendo.io email to add a new team member
                </p>
              </div>
              
              {/* Show name field only for new users or if existing user has no name */}
              {newMemberEmail && !allUsers.find(u => u.email === newMemberEmail)?.full_name && (
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Eva Bourke"
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    If this is a new user, they'll be added with "identified" status
                  </p>
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="role">Role</Label>
                <Select value={newMemberRole} onValueChange={setNewMemberRole}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {customRoles.length > 0 ? (
                      customRoles.map(role => (
                        <SelectItem key={role.id} value={role.name}>
                          {role.display_name}
                        </SelectItem>
                      ))
                    ) : (
                      <>
                        <SelectItem value="owner">Owner</SelectItem>
                        <SelectItem value="member">Member</SelectItem>
                        <SelectItem value="se">Solutions Engineer</SelectItem>
                        <SelectItem value="csm">Customer Success</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <Button 
                className="w-full" 
                onClick={() => addTeamMember.mutate({ email: newMemberEmail, name: newMemberName, role: newMemberRole })}
                disabled={!newMemberEmail || addTeamMember.isPending}
              >
                {addTeamMember.isPending ? 'Adding...' : 'Add Member'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="team" className="w-full">
        <TabsList>
          <TabsTrigger value="team" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Internal Team ({teamArray.length})
          </TabsTrigger>
          <TabsTrigger value="contacts" className="flex items-center gap-2">
            <UserCircle className="h-4 w-4" />
            Contacts ({contacts?.length || 0})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="team" className="mt-4">
          {teamArray.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-medium text-lg">No team members assigned</h3>
                <p className="text-muted-foreground">
                  Team members will be automatically assigned when they attend meetings with this account
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {teamArray.map(member => (
                <Card key={member.email}>
                  <CardHeader className="pb-3">
                    <div className="flex items-start gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <Users className="h-5 w-5 text-primary" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <CardTitle className="text-base truncate">
                          {member.name || emailLocalPart(member.email)}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-1 truncate">
                          <Mail className="h-3 w-3 shrink-0" />
                          {member.email}
                        </CardDescription>
                      </div>
                      {member.accountMemberId && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          onClick={() => removeTeamMember.mutate(member.accountMemberId!)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0 space-y-3">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="capitalize">
                        {member.role}
                      </Badge>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        Since {format(new Date(member.firstSeen), 'MMM d, yyyy')}
                      </span>
                    </div>
                    {member.opportunities.length > 0 && (
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-muted-foreground">Active on:</p>
                        <div className="flex flex-wrap gap-1">
                          {member.opportunities.slice(0, 3).map(opp => (
                            <Badge key={opp} variant="secondary" className="text-xs">
                              <Building2 className="h-3 w-3 mr-1" />
                              {opp.length > 25 ? opp.slice(0, 25) + '...' : opp}
                            </Badge>
                          ))}
                          {member.opportunities.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{member.opportunities.length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="contacts" className="mt-4">
          {!contacts?.length ? (
            <Card>
              <CardContent className="p-8 text-center">
                <UserCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-medium text-lg">No contacts found</h3>
                <p className="text-muted-foreground">
                  Contacts are automatically extracted from meeting transcripts
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {contacts.map(contact => (
                <Card key={contact.id}>
                  <CardHeader className="pb-3">
                    <div className="flex items-start gap-3">
                      <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center shrink-0">
                        <UserCircle className="h-5 w-5 text-secondary-foreground" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <CardTitle className="text-base truncate">
                          {contact.name}
                        </CardTitle>
                        {contact.role && (
                          <CardDescription className="truncate">
                            {contact.role}
                          </CardDescription>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0 space-y-2">
                    {contact.email && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Mail className="h-3 w-3 shrink-0" />
                        <span className="truncate">{contact.email}</span>
                      </div>
                    )}
                    {contact.phone && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Phone className="h-3 w-3 shrink-0" />
                        <span>{contact.phone}</span>
                      </div>
                    )}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {contact.champion_score && contact.champion_score >= 7 && (
                        <Badge variant="default" className="text-xs">Champion</Badge>
                      )}
                      {contact.influence_level && contact.influence_level >= 4 && (
                        <Badge variant="secondary" className="text-xs">High Influence</Badge>
                      )}
                      {contact.source && (
                        <Badge variant="outline" className="text-xs capitalize">{contact.source}</Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Summary Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold">{teamArray.length}</div>
              <div className="text-xs text-muted-foreground">Team Members</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{contacts?.length || 0}</div>
              <div className="text-xs text-muted-foreground">Contacts</div>
            </div>
            <div>
              <div className="text-2xl font-bold">
                {new Set(teamArray.flatMap(m => m.opportunities)).size}
              </div>
              <div className="text-xs text-muted-foreground">Active Opportunities</div>
            </div>
            <div>
              <div className="text-2xl font-bold">
                {contacts?.filter(c => c.champion_score && c.champion_score >= 7).length || 0}
              </div>
              <div className="text-xs text-muted-foreground">Champions</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

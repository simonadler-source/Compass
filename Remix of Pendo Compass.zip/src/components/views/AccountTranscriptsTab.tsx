import { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Upload, FileText, Sparkles, Loader2, ChevronDown, ChevronUp, Users, Zap, AlertTriangle, X, Video, Calendar, Plus, Briefcase, ExternalLink, Trash2, RotateCcw, CheckCircle2, Link2, Play, Mail, Building2, Square, CheckSquare, ArrowRightLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  useCreateAccountDocument, 
  useCreateAccountTechnology,
  useAccountContacts,
  useAccountNbas,
  useCreateOpportunity,
} from '@/hooks/useAccounts';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { encryptedInsert, encryptedUpdate, encryptedUpsert } from '@/lib/encryptedDb';
import { toast } from 'sonner';
import { saveExtractedTechnologies } from '@/hooks/useSaveExtractedTechnologies';
import { useCompetitorsList } from '@/hooks/useCompetitorsList';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { Label } from '@/components/ui/label';
import { LinkToOpportunityDialog } from '@/components/dialogs/LinkToOpportunityDialog';
import { MoveToAccountDialog } from '@/components/dialogs/MoveToAccountDialog';
import { MoveToOpportunityDialog } from '@/components/dialogs/MoveToOpportunityDialog';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { analyzeTranscript as analyzeTranscriptStreaming } from '@/features/transcript-analysis';

// Helper to build Momentum meeting URL
function getMomentumUrl(momentumId: string): string {
  return `https://app.momentum.io/meeting/${momentumId}/summary?sourceTab=MY_CALLS`;
}

interface MomentumMeeting {
  id: string;
  momentum_id: string;
  title: string;
  start_time: string;
  status: string;
  salesforce_opportunity_id: string | null;
  transcript_content: string | null;
  opportunity_id: string | null;
}

interface AccountTranscriptsTabProps {
  accountId: string;
  accountName: string;
  documents: { id: string; name: string; type: string; content: string | null; created_at: string }[];
}

interface ReanalyzeProgress {
  step: string;
  detail?: string;
}

interface ExtractedTech {
  name: string;
  confidence: number;
  context?: string;
  suggestedLayer?: string;
  relationshipStatus?: 'mentioned' | 'experience' | 'in_use' | 'evaluating' | 'considering' | 'replaced' | 'neutral';
  needsReview?: boolean;
}

interface ExtractedMetric {
  metricName: string;
  metricValue: string;
  metricNumericValue?: number | null;
  metricCategory: string;
  confidence: number;
  needsReview: boolean;
  context: string;
}

interface ExtractedPerson {
  name: string;
  role: string | null;
  email: string | null;
  phone: string | null;
  context: string;
  influenceLevel?: number;
  sentiment?: number;
  championScore?: number;
}

interface NextBestAction {
  action: string;
  actionType: string;
  priority: string;
  reasoning: string;
}

// Helper to convert analysis result to local types and JSON-compatible format
function toLocalTechs(techs: any[]): ExtractedTech[] {
  return (techs || []).map(t => ({
    name: t.name,
    confidence: t.confidence || 0,
    context: t.context,
    suggestedLayer: t.suggestedLayer,
    relationshipStatus: t.relationshipStatus as ExtractedTech['relationshipStatus'],
    needsReview: t.needsReview,
  }));
}

function toLocalPeople(people: any[]): ExtractedPerson[] {
  return (people || []).map(p => ({
    name: p.name,
    role: p.role || null,
    email: p.email || null,
    phone: null,
    context: '',
    influenceLevel: p.influenceLevel,
    sentiment: p.sentiment,
    championScore: p.championScore,
  }));
}

function toLocalNbas(nbas: any[]): NextBestAction[] {
  return (nbas || []).map(n => ({
    action: n.action,
    actionType: n.actionType || 'follow_up',
    priority: n.priority || 'medium',
    reasoning: n.reasoning || '',
  }));
}

interface AnalysisResult {
  technologies: ExtractedTech[];
  people: ExtractedPerson[];
  nbas: NextBestAction[];
  operationalMetrics?: ExtractedMetric[];
  insights: {
    painPoints: string[];
    useCases: string[];
    competitorMentions: string[];
  };
}

export function AccountTranscriptsTab({ accountId, accountName, documents }: AccountTranscriptsTabProps) {
  const queryClient = useQueryClient();
  const [transcript, setTranscript] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [viewingTranscript, setViewingTranscript] = useState<{ id: string; name: string; content: string | null; created_at: string } | null>(null);
  const [viewingMeetingTranscript, setViewingMeetingTranscript] = useState<MomentumMeeting | null>(null);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});
  const [createOpportunityMeeting, setCreateOpportunityMeeting] = useState<MomentumMeeting | null>(null);
  const [opportunityName, setOpportunityName] = useState('');
  const [reanalyzingDocId, setReanalyzingDocId] = useState<string | null>(null);
  const [reanalyzingMeetingId, setReanalyzingMeetingId] = useState<string | null>(null);
  const [reanalyzeProgress, setReanalyzeProgress] = useState<ReanalyzeProgress | null>(null);
  const [linkingToOpportunityId, setLinkingToOpportunityId] = useState<string | null>(null);
  const [linkDialogOpen, setLinkDialogOpen] = useState(false);
  const [linkDialogTranscriptId, setLinkDialogTranscriptId] = useState<string | null>(null);
  const [linkDialogMomentumMeetingId, setLinkDialogMomentumMeetingId] = useState<string | null>(null);
  const [linkDialogMeetingTitle, setLinkDialogMeetingTitle] = useState<string | undefined>(undefined);
  const [linkDialogMeetingSfOppId, setLinkDialogMeetingSfOppId] = useState<string | undefined>(undefined);
  
  // Move to account state
  const [moveDialogOpen, setMoveDialogOpen] = useState(false);
  const [moveTranscriptIds, setMoveTranscriptIds] = useState<string[]>([]);
  const [moveMeetingTitles, setMoveMeetingTitles] = useState<string[]>([]);
  const [selectedTranscriptIds, setSelectedTranscriptIds] = useState<Set<string>>(new Set());
  const [moveToOppTranscript, setMoveToOppTranscript] = useState<{ id: string; title: string; opportunityId?: string | null } | null>(null);
  const { data: competitors } = useCompetitorsList();
  const createDocument = useCreateAccountDocument();
  const createTechnology = useCreateAccountTechnology();
  const createOpportunity = useCreateOpportunity();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Toggle selection for bulk operations
  const toggleTranscriptSelection = (transcriptId: string) => {
    setSelectedTranscriptIds(prev => {
      const next = new Set(prev);
      if (next.has(transcriptId)) {
        next.delete(transcriptId);
      } else {
        next.add(transcriptId);
      }
      return next;
    });
  };
  
  // Open move dialog for single transcript
  const openMoveDialogForSingle = (transcriptId: string, title: string) => {
    setMoveTranscriptIds([transcriptId]);
    setMoveMeetingTitles([title]);
    setMoveDialogOpen(true);
  };
  
  // Open move dialog for selected transcripts (bulk)
  const openMoveDialogForSelected = () => {
    if (selectedTranscriptIds.size === 0) {
      toast.error('No transcripts selected');
      return;
    }
    setMoveTranscriptIds(Array.from(selectedTranscriptIds));
    setMoveMeetingTitles([]); // Will show count instead
    setMoveDialogOpen(true);
  };
  
  // Clear selection after move
  const handleMoveComplete = () => {
    setSelectedTranscriptIds(new Set());
    queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', accountId] });
    queryClient.invalidateQueries({ queryKey: ['momentum-meetings-account', accountId] });
  };

  // Delete transcript mutation
  const deleteTranscriptMutation = useMutation({
    mutationFn: async (docId: string) => {
      const { error } = await gateway
        .from('account_documents')
        .delete()
        .eq('id', docId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      toast.success('Transcript deleted');
      queryClient.invalidateQueries({ queryKey: ['account', accountId] });
    },
    onError: () => {
      toast.error('Failed to delete transcript');
    },
  });

  // Reset stuck processing meeting mutation
  const resetProcessingMutation = useMutation({
    mutationFn: async (meetingId: string) => {
      const { error } = await gateway
        .from('momentum_meetings')
        .update({ status: 'pending', matched_account_id: null })
        .eq('id', meetingId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      toast.success('Meeting reset to pending - you can retry import');
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings-account', accountId] });
    },
    onError: () => {
      toast.error('Failed to reset meeting');
    },
  });

  // Remove transcript from account and delete associated insights
  const removeTranscriptFromAccountMutation = useMutation({
    mutationFn: async (transcriptId: string) => {
      // Delete associated insights that came from this transcript
      await Promise.all([
        gateway.from('account_nbas').delete().eq('source_transcript_id', transcriptId).execute(),
        gateway.from('account_pain_points').delete().eq('source_transcript_id', transcriptId).execute(),
        gateway.from('account_use_cases').delete().eq('source_transcript_id', transcriptId).execute(),
        gateway.from('account_metrics').delete().eq('source_transcript_id', transcriptId).execute(),
        gateway.from('detection_rule_matches').delete().eq('transcript_id', transcriptId).execute(),
        gateway.from('account_captured_insights').delete().eq('source_transcript_id', transcriptId).execute(),
      ]);

      // Orphan the transcript (remove from this account)
      const { error } = await gateway
        .from('transcript_reviews')
        .update({ final_account_id: null, opportunity_id: null })
        .eq('id', transcriptId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      toast.success('Transcript removed from account and associated analysis deleted');
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-pain-points', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-metrics', accountId] });
    },
    onError: () => {
      toast.error('Failed to remove transcript');
    },
  });

  const reanalyzeTranscript = async (doc: { id: string; name: string; content: string | null }) => {
    if (!doc.content) {
      toast.error('No content to analyze');
      return;
    }

    setReanalyzingDocId(doc.id);
    setReanalyzeProgress({ step: 'Preparing analysis...', detail: 'Gathering existing context' });
    try {
      // Fetch existing insights from all approved transcripts for this account
      const { data: existingReviews } = await gateway
        .from('transcript_reviews')
        .select('extracted_insights, extracted_technologies')
        .eq('final_account_id', accountId)
        .eq('status', 'approved')
        .execute();

      // Fetch existing account technologies
      const { data: existingTechs } = await gateway
        .from('account_technologies')
        .select('name, layer, category, relationship_status, context')
        .eq('account_id', accountId)
        .execute();

      // Aggregate existing insights for enrichment context
      const aggregatedInsights = {
        technologies: existingTechs || [],
        painPoints: [] as string[],
        useCases: [] as string[],
        competitorMentions: [] as string[],
        people: [] as any[],
        nbas: [] as any[],
      };

      existingReviews?.forEach((review) => {
        const insights = review.extracted_insights as any || {};
        aggregatedInsights.painPoints.push(...(insights.painPoints || []));
        aggregatedInsights.useCases.push(...(insights.useCases || []));
        aggregatedInsights.competitorMentions.push(...(insights.competitorMentions || []));
        aggregatedInsights.people.push(...(insights.people || []));
        aggregatedInsights.nbas.push(...(insights.nbas || []));
      });

      // Deduplicate arrays
      aggregatedInsights.painPoints = [...new Set(aggregatedInsights.painPoints)];
      aggregatedInsights.useCases = [...new Set(aggregatedInsights.useCases)];
      aggregatedInsights.competitorMentions = [...new Set(aggregatedInsights.competitorMentions)];

      setReanalyzeProgress({ step: 'Analyzing transcript...', detail: 'AI is extracting insights (Pass 1 of 2)' });

      // Use the shared streaming analysis utility
      const result = await analyzeTranscriptStreaming({
        transcript: doc.content,
        accounts: [{ id: accountId, name: accountName }],
        competitors: competitors?.map(c => ({ id: c.id, name: c.name })) || [],
        existingInsights: aggregatedInsights,
        onProgress: (progress) => {
          setReanalyzeProgress({ 
            step: `Analyzing transcript...`, 
            detail: `Pass ${progress.pass} of ${progress.totalPasses}: ${progress.stage}` 
          });
        },
      });

      if (!result.success || !result.analysis) {
        throw new Error(result.error || 'Analysis failed');
      }

      const data = result.analysis;

      setReanalyzeProgress({ step: 'Saving technologies...', detail: `${data.technologies?.length || 0} found` });

      // Save extracted technologies (creates drafts in repository for unknowns)
      if (data.technologies?.length > 0) {
        const { saved, draftsCreated, updated } = await saveExtractedTechnologies(
          accountId,
          data.technologies as any,
          `Re-analyzed from: ${doc.name}`
        );
        if (draftsCreated > 0) {
          toast.info(`${draftsCreated} new technologies added to library for review`);
        }
        if (updated > 0) {
          toast.info(`${updated} technologies updated with new relationship status`);
        }
      }

      // NOTE: We save operational metrics AFTER we upsert transcript_reviews so we can set source_transcript_id

      setReanalyzeProgress({ step: 'Saving stakeholders...', detail: `${data.people?.length || 0} found` });

      // Helper: Detect if email belongs to internal domain
      const isInternalEmail = (email: string | null | undefined): boolean => {
        if (!email) return false;
        const normalizedEmail = email.toLowerCase().trim();
        // Internal domains - @pendo.io is our company
        return normalizedEmail.endsWith('@pendo.io');
      };

      // Save extracted contacts with AI-assessed stakeholder scores (MEDDIC-aligned)
      if (data.people?.length > 0) {
        let contactsSaved = 0;
        for (const person of data.people) {
          // Determine internal status: trust AI OR detect via email domain
          const isInternal = person.isInternal === true || isInternalEmail(person.email);
          
          const contactData = {
            account_id: accountId,
            name: person.name,
            email: person.email || null,
            role: person.role || null,
            source: 'transcript',
            notes: (person as any).context || null,
            stakeholder_type: person.stakeholderType || 'unknown',
            influence_level: person.influenceLevel ?? null,
            sentiment: person.sentiment ?? null,
            champion_score: person.championScore ?? null,
            advocacy_signals: person.advocacySignals || { detected: false, examples: [] },
            info_sharing_signals: person.infoSharingSignals || { detected: false, examples: [] },
            last_assessed_at: new Date().toISOString(),
            assessment_source: 'ai_transcript',
            is_internal: isInternal,
          };

          if (person.email) {
            // Upsert by email if available (using encrypted upsert)
            await encryptedUpsert('account_contacts', contactData);
            contactsSaved++;
          } else {
            // Check if contact with same name exists, update if so, else insert
            // Note: name column is encrypted (NULL in DB), so we fetch all and filter in memory
            const { data: allContacts } = await gateway
              .from('account_contacts')
              .select('id, name')
              .eq('account_id', accountId)
              .execute();

            const existingContact = (allContacts || []).find((c: any) => 
              c.name && c.name.toLowerCase().trim() === person.name.toLowerCase().trim()
            );

            if (existingContact) {
              await encryptedUpdate('account_contacts', existingContact.id, {
                role: contactData.role,
                notes: contactData.notes,
                stakeholder_type: contactData.stakeholder_type,
                influence_level: contactData.influence_level,
                sentiment: contactData.sentiment,
                champion_score: contactData.champion_score,
                advocacy_signals: contactData.advocacy_signals,
                info_sharing_signals: contactData.info_sharing_signals,
                last_assessed_at: contactData.last_assessed_at,
                assessment_source: contactData.assessment_source,
                is_internal: contactData.is_internal,
              });
            } else {
              await encryptedInsert('account_contacts', contactData);
            }
            contactsSaved++;
          }
        }
        if (contactsSaved > 0) {
          const externalCount = data.people.filter((p: any) => !p.isInternal).length;
          const championsCount = data.people.filter((p: any) => p.stakeholderType === 'champion').length;
          toast.info(`${externalCount} stakeholders analyzed (${championsCount} champions identified)`);
        }
        // Invalidate stakeholder map query
        queryClient.invalidateQueries({ queryKey: ['stakeholder-map', accountId] });
      }

      setReanalyzeProgress({ step: 'Saving actions...', detail: `${data.nbas?.length || 0} NBAs` });

      // Save NBAs with deduplication
      if (data.nbas?.length > 0) {
        const { saveNBAsWithDeduplication } = await import('@/hooks/useInsightEnrichment');
        const nbaStats = await saveNBAsWithDeduplication(
          accountId,
          data.nbas,
          undefined, // no opportunity ID in this context
          undefined  // no transcript ID in this context
        );
        console.log(`NBAs saved: ${nbaStats.created} new, ${nbaStats.skipped} skipped`);
      }

      setReanalyzeProgress({ step: 'Finalizing...', detail: 'Saving to database' });

      // Upsert transcript_reviews so insights tab aggregates correctly
      // Check if one already exists for this document
      const { data: existingReview } = await gateway
        .from('transcript_reviews')
        .select('id, opportunity_id')
        .eq('file_name', doc.name)
        .eq('final_account_id', accountId)
        .single()
        .execute();

      const extractedInsights = {
        painPoints: data.insights?.painPoints ?? [],
        useCases: data.insights?.useCases ?? [],
        competitorMentions: data.insights?.competitorMentions ?? [],
        commercialInsights: data.commercialInsights ?? [],
        operationalMetrics: data.operationalMetrics ?? [],
        people: data.people ?? [],
        nbas: data.nbas ?? [],
      };

      if (existingReview) {
        // Update existing record
        await gateway
          .from('transcript_reviews')
          .update({
            extracted_technologies: JSON.parse(JSON.stringify(data.technologies ?? [])),
            extracted_insights: JSON.parse(JSON.stringify(extractedInsights)),
            updated_at: new Date().toISOString(),
          })
          .eq('id', existingReview.id)
          .execute();
      } else {
        // Create new record (using encrypted insert)
        await encryptedInsert('transcript_reviews', {
          transcript_content: doc.content,
          file_name: doc.name,
          status: 'approved',
          final_account_id: accountId,
          extracted_technologies: JSON.parse(JSON.stringify(data.technologies ?? [])),
          extracted_insights: JSON.parse(JSON.stringify(extractedInsights)),
        });
      }

      // Get the transcript review ID for enrichment
      const { data: reviewForEnrichment } = await gateway
        .from('transcript_reviews')
        .select('id, opportunity_id')
        .eq('file_name', doc.name)
        .eq('final_account_id', accountId)
        .single()
        .execute();

      // Save extracted operational metrics (with transcript + opportunity linkage when available)
      if (reviewForEnrichment?.id && data.operationalMetrics?.length > 0) {
        const transcriptReviewId = reviewForEnrichment.id;
        const opportunityId = reviewForEnrichment.opportunity_id ?? existingReview?.opportunity_id ?? null;

        // Deduplicate by name+value (gateway decrypts metric_value for comparisons)
        const { data: existingMetrics } = await gateway
          .from('account_metrics')
          .select('metric_name, metric_value')
          .eq('account_id', accountId)
          .execute();

        const existingSet = new Set(
          (existingMetrics || []).map((m: any) => `${String(m.metric_name || '').toLowerCase().trim()}::${String(m.metric_value || '').toLowerCase().trim()}`)
        );

        let metricsAdded = 0;
        for (const metric of data.operationalMetrics as any[]) {
          const key = `${String(metric.metricName || '').toLowerCase().trim()}::${String(metric.metricValue || '').toLowerCase().trim()}`;
          if (key === '::' || existingSet.has(key)) continue;

          await encryptedInsert('account_metrics', {
            account_id: accountId,
            opportunity_id: opportunityId,
            source_transcript_id: transcriptReviewId,
            metric_name: metric.metricName,
            metric_value: metric.metricValue,
            metric_numeric_value: metric.metricNumericValue ?? null,
            metric_category: metric.metricCategory || 'general',
            confidence_score: metric.confidence ?? 0.8,
            needs_review: metric.needsReview ?? false,
            context: metric.context || '',
            mentioned_by_name: metric.mentionedByName ?? null,
            mentioned_by_type: metric.mentionedByType ?? null,
            source: 'transcript_analysis',
          });
          metricsAdded++;
          existingSet.add(key);
        }

        if (metricsAdded > 0) {
          toast.info(`${metricsAdded} operational metrics extracted`);
        }
      }

      // Trigger enrichment (detection rules, readiness) - fire and forget
      if (reviewForEnrichment?.id) {
        supabase.functions.invoke('enrich-transcript', {
          body: { transcriptReviewId: reviewForEnrichment.id }
        }).then(() => {
          queryClient.invalidateQueries({ queryKey: ['activity-signals'] });
          queryClient.invalidateQueries({ queryKey: ['detection-rule-matches'] });
          console.log('Enrichment completed for transcript:', reviewForEnrichment.id);
        }).catch(err => console.error('Enrichment failed:', err));
      }

      toast.success('Re-analysis complete! Extracted data saved.');
      queryClient.invalidateQueries({ queryKey: ['account', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-contacts', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-transcript-insights', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-metrics', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-technologies', accountId] });
      queryClient.invalidateQueries({ queryKey: ['stakeholder-map', accountId] });
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews'] });
      
      // Trigger account intelligence synthesis (fire and forget)
      supabase.functions.invoke('synthesize-account-insights', {
        body: { accountId }
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['account-strategic-themes', accountId] });
        queryClient.invalidateQueries({ queryKey: ['account-exec-summary', accountId] });
      }).catch(err => console.error('Account synthesis failed:', err));
    } catch (error) {
      console.error('Re-analysis error:', error);
      toast.error('Failed to re-analyze transcript');
    } finally {
      setReanalyzingDocId(null);
      setReanalyzeProgress(null);
    }
  };

  // Re-analyze momentum meeting transcript
  const reanalyzeMomentumMeeting = async (meeting: MomentumMeeting & { momentum_id: string }) => {
    let transcriptContent = meeting.transcript_content;
    
    // If no plaintext content, try server-side decryption
    if (!transcriptContent) {
      try {
        const { data: decryptResult, error: decryptError } = await supabase.functions.invoke('decrypt-transcript', {
          body: { transcriptId: meeting.id, table: 'momentum_meetings' },
        });
        if (!decryptError && decryptResult?.success && decryptResult?.content) {
          transcriptContent = decryptResult.content;
        }
      } catch { /* fall through */ }
    }

    if (!transcriptContent) {
      toast.error('No transcript content to analyze');
      return;
    }

    setReanalyzingMeetingId(meeting.id);
    setReanalyzeProgress({ step: 'Analyzing transcript...', detail: 'AI is extracting insights (Pass 1 of 2)' });
    try {
      // Use the shared streaming analysis utility
      const result = await analyzeTranscriptStreaming({
        transcript: transcriptContent,
        accounts: [{ id: accountId, name: accountName }],
        competitors: competitors?.map(c => ({ id: c.id, name: c.name })) || [],
        onProgress: (progress) => {
          setReanalyzeProgress({ 
            step: `Analyzing transcript...`, 
            detail: `Pass ${progress.pass} of ${progress.totalPasses}: ${progress.stage}` 
          });
        },
      });

      if (!result.success || !result.analysis) {
        throw new Error(result.error || 'Analysis failed');
      }

      const data = result.analysis;

      setReanalyzeProgress({ step: 'Saving technologies...', detail: `${data.technologies?.length || 0} found` });

      // Save extracted technologies
      if (data.technologies?.length > 0) {
        const { draftsCreated, updated } = await saveExtractedTechnologies(
          accountId,
          data.technologies as any,
          `Re-analyzed from: ${meeting.title}`
        );
        if (draftsCreated > 0) {
          toast.info(`${draftsCreated} new technologies added to library for review`);
        }
        if (updated > 0) {
          toast.info(`${updated} technologies updated`);
        }
      }

      setReanalyzeProgress({ step: 'Saving actions...', detail: `${data.nbas?.length || 0} NBAs` });

      // Save NBAs - link to opportunity if the transcript is linked
      if (data.nbas?.length > 0) {
        const opportunityId = getMeetingOpportunityId(meeting);
        for (const nba of data.nbas) {
          const nbaData = nba as any;
          await gateway.insert('account_nbas', {
            account_id: accountId,
            opportunity_id: opportunityId, // Link NBAs to the opportunity
            action: nba.action,
            action_type: nba.actionType || 'follow_up',
            assigned_to: nbaData.ownerEmail || nbaData.ownerName || nbaData.ownerType || 'sales_engineer',
            priority: nba.priority || 'medium',
            notes: nbaData.ownerName ? `Owner: ${nbaData.ownerName}. ${nba.reasoning || ''}`.trim() : nba.reasoning,
            status: 'pending',
          });
        }
      }

      setReanalyzeProgress({ step: 'Finalizing...', detail: 'Saving to database' });

      // Upsert transcript_reviews
      const fileName = `momentum_${meeting.momentum_id}`;
      const { data: existingReview } = await gateway
        .from('transcript_reviews')
        .select('id')
        .eq('file_name', fileName)
        .eq('final_account_id', accountId)
        .single()
        .execute();

      const extractedInsights = {
        painPoints: data.insights?.painPoints ?? [],
        useCases: data.insights?.useCases ?? [],
        competitorMentions: data.insights?.competitorMentions ?? [],
        commercialInsights: data.commercialInsights ?? [],
        operationalMetrics: data.operationalMetrics ?? [],
        people: data.people ?? [],
        nbas: data.nbas ?? [],
      };

      if (existingReview) {
        await gateway
          .from('transcript_reviews')
          .update({
            extracted_technologies: JSON.parse(JSON.stringify(data.technologies ?? [])),
            extracted_insights: JSON.parse(JSON.stringify(extractedInsights)),
            updated_at: new Date().toISOString(),
          })
          .eq('id', existingReview.id)
          .execute();
      } else {
        await gateway.insert('transcript_reviews', {
          transcript_content: meeting.transcript_content,
          file_name: fileName,
          status: 'approved',
          final_account_id: accountId,
          extracted_technologies: JSON.parse(JSON.stringify(data.technologies ?? [])),
          extracted_insights: JSON.parse(JSON.stringify(extractedInsights)),
        });
      }

      // Get transcript review ID for enrichment
      const { data: reviewForEnrichment } = await gateway
        .from('transcript_reviews')
        .select('id')
        .eq('file_name', fileName)
        .eq('final_account_id', accountId)
        .single()
        .execute();

      // Save extracted operational metrics for Momentum (link to opportunity when meeting is linked)
      if (reviewForEnrichment?.id && data.operationalMetrics?.length > 0) {
        const transcriptReviewId = reviewForEnrichment.id;
        const opportunityId = getMeetingOpportunityId(meeting);

        const { data: existingMetrics } = await gateway
          .from('account_metrics')
          .select('metric_name, metric_value')
          .eq('account_id', accountId)
          .execute();

        const existingSet = new Set(
          (existingMetrics || []).map((m: any) => `${String(m.metric_name || '').toLowerCase().trim()}::${String(m.metric_value || '').toLowerCase().trim()}`)
        );

        let metricsAdded = 0;
        for (const metric of data.operationalMetrics as any[]) {
          const key = `${String(metric.metricName || '').toLowerCase().trim()}::${String(metric.metricValue || '').toLowerCase().trim()}`;
          if (key === '::' || existingSet.has(key)) continue;

          await encryptedInsert('account_metrics', {
            account_id: accountId,
            opportunity_id: opportunityId,
            source_transcript_id: transcriptReviewId,
            metric_name: metric.metricName,
            metric_value: metric.metricValue,
            metric_numeric_value: metric.metricNumericValue ?? null,
            metric_category: metric.metricCategory || 'general',
            confidence_score: metric.confidence ?? 0.8,
            needs_review: metric.needsReview ?? false,
            context: metric.context || '',
            mentioned_by_name: metric.mentionedByName ?? null,
            mentioned_by_type: metric.mentionedByType ?? null,
            source: 'transcript_analysis',
          });
          metricsAdded++;
          existingSet.add(key);
        }

        if (metricsAdded > 0) {
          toast.info(`${metricsAdded} operational metrics extracted`);
        }
      }

      // Trigger enrichment (detection rules, readiness) - fire and forget
      if (reviewForEnrichment?.id) {
        supabase.functions.invoke('enrich-transcript', {
          body: { transcriptReviewId: reviewForEnrichment.id }
        }).then(() => {
          queryClient.invalidateQueries({ queryKey: ['activity-signals'] });
          queryClient.invalidateQueries({ queryKey: ['detection-rule-matches'] });
          console.log('Enrichment completed for transcript:', reviewForEnrichment.id);
        }).catch(err => console.error('Enrichment failed:', err));
      }

      toast.success('Re-analysis complete!');
      queryClient.invalidateQueries({ queryKey: ['account', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', accountId] });
      
      // Trigger account intelligence synthesis (fire and forget)
      supabase.functions.invoke('synthesize-account-insights', {
        body: { accountId }
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['account-strategic-themes', accountId] });
        queryClient.invalidateQueries({ queryKey: ['account-exec-summary', accountId] });
      }).catch(err => console.error('Account synthesis failed:', err));
      
      // Invalidate readiness queries if meeting is linked to an opportunity
      const linkedOpportunityId = getMeetingOpportunityId(meeting);
      if (linkedOpportunityId) {
        queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', linkedOpportunityId] });
        queryClient.invalidateQueries({ queryKey: ['opportunity-deployment-types', linkedOpportunityId] });
      }
    } catch (error) {
      console.error('Re-analysis error:', error);
      toast.error('Failed to re-analyze transcript');
    } finally {
      setReanalyzingMeetingId(null);
      setReanalyzeProgress(null);
    }
  };

  // Re-analyze orphaned transcript (momentum transcript where momentum_meeting is missing)
  const reanalyzeOrphanedTranscript = async (transcript: { id: string; file_name: string; meeting_title: string | null; momentum_meeting_id: string | null; opportunity_id: string | null }) => {
    setReanalyzingMeetingId(transcript.id);
    setReanalyzeProgress({ step: 'Fetching transcript content...', detail: '' });

    try {
      let transcriptContent: string | null = null;

      // Try to get content from linked momentum_meeting first
      if (transcript.momentum_meeting_id) {
        const { data: momentumMeeting } = await gateway
          .from('momentum_meetings')
          .select('transcript_content, title, momentum_id')
          .eq('id', transcript.momentum_meeting_id)
          .maybeSingle()
          .execute();

        transcriptContent = momentumMeeting?.transcript_content || null;
      }

      // If no plaintext content available, try server-side decryption
      if (!transcriptContent) {
        setReanalyzeProgress({ step: 'Decrypting transcript...', detail: 'Retrieving encrypted content' });
        try {
          const { data: decryptResult, error: decryptError } = await supabase.functions.invoke('decrypt-transcript', {
            body: { transcriptId: transcript.id, table: 'transcript_reviews' },
          });

          if (decryptError || !decryptResult?.success || !decryptResult?.content) {
            toast.error('Could not decrypt transcript content');
            return;
          }
          transcriptContent = decryptResult.content;
        } catch (decryptErr) {
          toast.error('Failed to retrieve transcript content');
          return;
        }
      }

      if (!transcriptContent) {
        toast.error('No transcript content available');
        return;
      }

      setReanalyzeProgress({ step: 'Analyzing transcript...', detail: 'AI is extracting insights (Pass 1 of 2)' });

      // Use the shared streaming analysis utility
      const result = await analyzeTranscriptStreaming({
        transcript: transcriptContent,
        accounts: [{ id: accountId, name: accountName }],
        competitors: competitors?.map(c => ({ id: c.id, name: c.name })) || [],
        onProgress: (progress) => {
          setReanalyzeProgress({ 
            step: `Analyzing transcript...`, 
            detail: `Pass ${progress.pass} of ${progress.totalPasses}: ${progress.stage}` 
          });
        },
      });

      if (!result.success || !result.analysis) {
        throw new Error(result.error || 'Analysis failed');
      }

      const data = result.analysis;
      setReanalyzeProgress({ step: 'Saving technologies...', detail: `${data.technologies?.length || 0} found` });

      // Save extracted technologies
      if (data.technologies?.length > 0) {
        const { draftsCreated, updated } = await saveExtractedTechnologies(
          accountId,
          data.technologies as any,
          `Re-analyzed from: ${transcript.meeting_title || transcript.file_name}`
        );
        if (draftsCreated > 0) {
          toast.info(`${draftsCreated} new technologies added as drafts`);
        }
      }

      setReanalyzeProgress({ step: 'Saving insights...', detail: `${data.nbas?.length || 0} NBAs` });

      // Save NBAs
      if (data.nbas?.length > 0) {
        for (const nba of data.nbas) {
          const nbaData = nba as any;
          await gateway.insert('account_nbas', {
            account_id: accountId,
            opportunity_id: transcript.opportunity_id,
            action: nba.action,
            action_type: nba.actionType || 'follow_up',
            assigned_to: nbaData.ownerEmail || nbaData.ownerName || nbaData.ownerType || 'sales_engineer',
            priority: nba.priority || 'medium',
            notes: nbaData.ownerName ? `Owner: ${nbaData.ownerName}. ${nba.reasoning || ''}`.trim() : nba.reasoning,
            status: 'pending',
          });
        }
      }

      setReanalyzeProgress({ step: 'Updating transcript record...', detail: '' });

      const extractedInsights = {
        painPoints: data.insights?.painPoints ?? [],
        useCases: data.insights?.useCases ?? [],
        competitorMentions: data.insights?.competitorMentions ?? [],
        commercialInsights: data.commercialInsights ?? [],
        people: data.people ?? [],
        nbas: data.nbas ?? [],
      };

      // Update the transcript_review
      await gateway
        .from('transcript_reviews')
        .update({
          extracted_technologies: JSON.parse(JSON.stringify(data.technologies ?? [])),
          extracted_insights: JSON.parse(JSON.stringify(extractedInsights)),
          updated_at: new Date().toISOString(),
        })
        .eq('id', transcript.id)
        .execute();

      // Trigger enrichment (detection rules, readiness) - fire and forget
      supabase.functions.invoke('enrich-transcript', {
        body: { transcriptReviewId: transcript.id }
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['activity-signals'] });
        queryClient.invalidateQueries({ queryKey: ['detection-rule-matches'] });
        console.log('Enrichment completed for transcript:', transcript.id);
      }).catch(err => console.error('Enrichment failed:', err));

      // Trigger account synthesis - fire and forget
      supabase.functions.invoke('synthesize-account-insights', {
        body: { accountId }
      }).catch(err => console.error('Account synthesis failed:', err));

      toast.success('Transcript re-analyzed successfully');

      // Refresh data
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-technologies', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-pain-points', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', accountId] });
    } catch (error) {
      console.error('Re-analysis error:', error);
      toast.error('Failed to re-analyze transcript');
    } finally {
      setReanalyzingMeetingId(null);
      setReanalyzeProgress(null);
    }
  };

  // Open the link to opportunity dialog for Momentum meetings
  const openLinkDialog = async (meetingInternalId: string, meetingMomentumId: string, meetingTitle?: string, salesforceOpportunityId?: string) => {
    // Try to find transcript_review by momentum_meeting_id first, then by file_name
    let reviewId: string | null = null;

    const { data: reviewByMeeting } = await gateway
      .from('transcript_reviews')
      .select('id')
      .eq('momentum_meeting_id', meetingInternalId)
      .eq('final_account_id', accountId)
      .limit(1)
      .execute();
    
    if (reviewByMeeting && reviewByMeeting.length > 0) {
      reviewId = reviewByMeeting[0].id;
    } else {
      // Fallback: search by file_name pattern
      const fileName = `momentum_${meetingMomentumId}`;
      const { data: reviewByName } = await gateway
        .from('transcript_reviews')
        .select('id')
        .eq('file_name', fileName)
        .eq('final_account_id', accountId)
        .single()
        .execute();
      if (reviewByName) {
        reviewId = reviewByName.id;
      }
    }

    // Open dialog — works with or without a transcript
    setLinkDialogTranscriptId(reviewId);
    setLinkDialogMomentumMeetingId(meetingInternalId);
    setLinkDialogMeetingTitle(meetingTitle);
    setLinkDialogMeetingSfOppId(salesforceOpportunityId);
    setLinkDialogOpen(true);
  };

  // Open the link to opportunity dialog for regular transcripts (by document name)
  const openLinkDialogForDoc = async (docName: string) => {
    // Find the transcript_review for this document
    const { data: review } = await gateway
      .from('transcript_reviews')
      .select('id')
      .eq('file_name', docName)
      .eq('final_account_id', accountId)
      .single()
      .execute();
    
    if (review) {
      setLinkDialogTranscriptId(review.id);
      setLinkDialogMeetingTitle(docName);
      setLinkDialogOpen(true);
    } else {
      toast.error('No analyzed transcript found for this document');
    }
  };

  // Direct link dialog opener when we already have the transcript ID
  const openLinkDialogForTranscript = (transcriptId: string, title?: string) => {
    setLinkDialogTranscriptId(transcriptId);
    setLinkDialogMeetingTitle(title);
    setLinkDialogOpen(true);
  };

  // Legacy link function for backwards compatibility (auto-links to first opportunity)
  const linkTranscriptToOpportunity = async (meetingMomentumId: string, opportunityId: string) => {
    setLinkingToOpportunityId(opportunityId);
    try {
      // Find the transcript_review for this momentum meeting
      const fileName = `momentum_${meetingMomentumId}`;
      const { data: review, error: findError } = await gateway
        .from('transcript_reviews')
        .select('id')
        .eq('file_name', fileName)
        .eq('final_account_id', accountId)
        .single()
        .execute();
      
      if (findError) throw new Error(getErrorMessage(findError));
      
      if (review) {
        const { error: updateError } = await gateway
          .from('transcript_reviews')
          .update({ opportunity_id: opportunityId })
          .eq('id', review.id)
          .execute();
        if (updateError) throw new Error(getErrorMessage(updateError));
        toast.success('Transcript linked to opportunity');
        queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', accountId] });
        queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', opportunityId] });
      } else {
        toast.error('No analyzed transcript found for this meeting');
      }
    } catch (error) {
      console.error('Link error:', error);
      toast.error('Failed to link transcript');
    } finally {
      setLinkingToOpportunityId(null);
    }
  };
  
  // Fetch related data for the account
  const { data: contacts } = useAccountContacts(accountId);
  const { data: nbas } = useAccountNbas(accountId);

  // Fetch Momentum meetings linked to this account
  const { data: momentumMeetings } = useQuery({
    queryKey: ['momentum-meetings-account', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select('id, title, start_time, status, salesforce_opportunity_id, transcript_content, momentum_id, opportunity_id')
        .eq('matched_account_id', accountId)
        .order('start_time', { ascending: false })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as (MomentumMeeting & { momentum_id: string })[];
    },
  });

  // Fetch existing opportunities for this account to check duplicates
  const { data: existingOpportunities } = useQuery({
    queryKey: ['account-opportunities', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunities')
        .select('id, name, description, salesforce_opportunity_id')
        .eq('account_id', accountId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
  });

  // Set of salesforce opportunity IDs that already have opportunities created
  const existingSfOppIds = new Set(
    existingOpportunities
      ?.map(opp => opp.salesforce_opportunity_id)
      .filter(Boolean) || []
  );

  // Map SF Opp ID -> opportunity for quick lookup
  const sfOppIdToOpportunity = new Map(
    existingOpportunities
      ?.filter(opp => opp.salesforce_opportunity_id)
      .map(opp => [opp.salesforce_opportunity_id, opp]) || []
  );

  // Map opportunity ID -> opportunity for displaying names
  const opportunityById = new Map<string, { id: string; name: string }>(
    existingOpportunities?.map(opp => [opp.id, opp]) || []
  );

  // Fetch transcript_reviews for this account to know analysis status
  const { data: transcriptReviews } = useQuery({
    queryKey: ['transcript-reviews-account', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('transcript_reviews')
        .select('id, file_name, status, extracted_insights, opportunity_id, meeting_title, created_at, momentum_meeting_id')
        .eq('final_account_id', accountId)
        .order('created_at', { ascending: false })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as { id: string; file_name: string; status: string; extracted_insights: any; opportunity_id: string | null; meeting_title: string | null; created_at: string; momentum_meeting_id: string | null }[];
    },
  });

  // Create a set of momentum IDs that have transcript_reviews (stores both UUID and numeric IDs)
  const analyzedMomentumIds = new Set(
    transcriptReviews
      ?.filter(tr => tr.file_name?.startsWith('momentum_'))
      .map(tr => tr.file_name?.replace('momentum_', '')) || []
  );

  // Helper to check if a meeting has been analyzed (checks both UUID id and numeric momentum_id)
  const isMeetingAnalyzed = (meeting: { id: string; momentum_id: string | number }) => {
    return analyzedMomentumIds.has(meeting.id) || analyzedMomentumIds.has(String(meeting.momentum_id));
  };

  // Map momentum IDs to their linked opportunity IDs (handles both formats)
  const momentumOpportunityMap = new Map<string, string | null>(
    transcriptReviews
      ?.filter(tr => tr.file_name?.startsWith('momentum_'))
      .map(tr => [tr.file_name?.replace('momentum_', '') || '', tr.opportunity_id]) || []
  );

  // Also build a map from momentum_meetings.opportunity_id (for meetings without transcript_reviews)
  const meetingDirectOpportunityMap = new Map<string, string | null>(
    momentumMeetings
      ?.filter(m => m.opportunity_id)
      .map(m => [m.id, (m as any).opportunity_id]) || []
  );

  // Map momentum IDs to their transcript_review IDs
  const momentumTranscriptIdMap = new Map<string, string>(
    transcriptReviews
      ?.filter(tr => tr.file_name?.startsWith('momentum_'))
      .map(tr => [tr.file_name?.replace('momentum_', '') || '', tr.id]) || []
  );

  // Helper to get opportunity ID for a meeting (checks transcript_reviews first, then momentum_meetings directly)
  const getMeetingOpportunityId = (meeting: { id: string; momentum_id: string | number }) => {
    return momentumOpportunityMap.get(meeting.id) 
      ?? momentumOpportunityMap.get(String(meeting.momentum_id)) 
      ?? meetingDirectOpportunityMap.get(meeting.id)
      ?? null;
  };

  // Helper to get transcript_review ID for a meeting (needed for move operation)
  const getMeetingTranscriptId = (meeting: { id: string; momentum_id: string | number }): string | null => {
    return momentumTranscriptIdMap.get(meeting.id) ?? momentumTranscriptIdMap.get(String(meeting.momentum_id)) ?? null;
  };

  // Get first opportunity for linking (if any exist)
  const firstOpportunity = existingOpportunities?.[0];

  // Set of momentum meeting IDs we have in the momentum_meetings table
  const existingMomentumMeetingIds = new Set(
    momentumMeetings?.map(mm => mm.id) || []
  );
  const existingMomentumNumericIds = new Set(
    momentumMeetings?.map(mm => String(mm.momentum_id)) || []
  );

  // Non-momentum transcript reviews (manual uploads, pasted transcripts)
  // Also include "orphaned" momentum transcripts where the momentum_meetings record is missing
  const nonMomentumTranscripts = transcriptReviews?.filter(tr => {
    if (!tr.file_name?.startsWith('momentum_')) {
      // Regular non-momentum transcript
      return true;
    }
    // It's a momentum transcript - check if the corresponding momentum_meeting exists
    const momentumId = tr.file_name.replace('momentum_', '');
    const hasMomentumMeeting = existingMomentumMeetingIds.has(momentumId) || existingMomentumNumericIds.has(momentumId);
    // Include it here if the momentum_meeting is missing (orphaned)
    return !hasMomentumMeeting;
  }) || [];

  // Filter out transcripts that are duplicates of momentum meetings
  const transcriptDocs = documents.filter(d => {
    if (d.type !== 'transcript') return false;
    
    // Check if this document name matches any momentum meeting title
    // If so, filter it out to avoid duplication
    const isDuplicate = momentumMeetings?.some(mm => {
      const docNameLower = d.name.toLowerCase();
      const meetingTitleLower = mm.title.toLowerCase();
      // Check for various matching patterns
      return docNameLower.includes(meetingTitleLower) || 
             meetingTitleLower.includes(docNameLower.replace('call:', '').trim());
    });
    
    // Also filter out if there's a transcript_review with this name that we'll show in nonMomentumTranscripts
    const hasTranscriptReview = nonMomentumTranscripts.some(tr => 
      tr.file_name === d.name || tr.meeting_title === d.name
    );
    
    return !isDuplicate && !hasTranscriptReview;
  });

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handleOpenCreateOpportunity = (meeting: MomentumMeeting) => {
    setCreateOpportunityMeeting(meeting);
    // Suggest a name based on meeting title
    const suggestedName = meeting.title.replace(/\s*\|\s*/g, ' - ').replace(/Pendo/gi, '').trim() || `Opportunity from ${format(new Date(meeting.start_time), 'MMM d, yyyy')}`;
    setOpportunityName(suggestedName);
  };

  const handleCreateOpportunity = async () => {
    if (!createOpportunityMeeting || !opportunityName.trim()) return;
    
    try {
      await createOpportunity.mutateAsync({
        account_id: accountId,
        name: opportunityName.trim(),
        description: `Created from Momentum meeting: ${createOpportunityMeeting.title}\n\nSalesforce Opportunity ID: ${createOpportunityMeeting.salesforce_opportunity_id || 'N/A'}\n\nMeeting Date: ${format(new Date(createOpportunityMeeting.start_time), 'MMM d, yyyy')}`,
        stage: 'identified',
        priority: 'medium',
      });
      
      toast.success('Opportunity created successfully');
      setCreateOpportunityMeeting(null);
      setOpportunityName('');
      queryClient.invalidateQueries({ queryKey: ['account', accountId] });
    } catch (error) {
      toast.error('Failed to create opportunity');
    }
  };

  const handleAnalyze = async () => {
    if (!transcript.trim()) return;
    
    setIsProcessing(true);
    setAnalysisResult(null);
    
    try {
      // Use the shared streaming analysis utility
      const result = await analyzeTranscriptStreaming({
        transcript,
        accounts: [{ id: accountId, name: accountName }],
        competitors: competitors?.map(c => ({ id: c.id, name: c.name })) || [],
      });

      if (!result.success || !result.analysis) {
        throw new Error(result.error || 'Analysis failed');
      }

      const data = result.analysis;

      setAnalysisResult({
        technologies: toLocalTechs(data.technologies || []),
        people: toLocalPeople(data.people || []),
        nbas: toLocalNbas(data.nbas || []),
        insights: data.insights || { painPoints: [], useCases: [], competitorMentions: [] }
      });

      toast.success('Transcript analyzed successfully');
    } catch (error) {
      console.error('Analysis error:', error);
      toast.error('Failed to analyze transcript');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSaveTranscript = async () => {
    if (!transcript.trim()) return;
    
    // Save transcript document
    await createDocument.mutateAsync({
      account_id: accountId,
      name: `Transcript - ${new Date().toLocaleDateString()}`,
      type: 'transcript',
      content: transcript,
    });

    // Auto-add extracted technologies to account
    if (analysisResult?.technologies) {
      for (const tech of analysisResult.technologies) {
        if (tech.confidence >= 0.7) {
          await createTechnology.mutateAsync({
            account_id: accountId,
            name: tech.name,
            layer: tech.suggestedLayer || 'adopt',
            category: 'Extracted',
            notes: tech.context || null,
          });
        }
      }
    }
    
    setTranscript('');
    setAnalysisResult(null);
    toast.success('Transcript and technologies saved');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const text = await file.text();
    setTranscript(text);
  };

  // Get contacts and NBAs that came from transcripts (via source field)
  const transcriptContacts = contacts?.filter(c => c.source === 'transcript') || [];
  const transcriptNbas = nbas || [];

  return (
    <div className="space-y-6">
      {/* Upload/Paste Area */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Add Transcript</h3>
            <p className="text-sm text-muted-foreground">
              Paste or upload a call transcript for AI analysis
            </p>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.md,.doc,.docx"
            className="hidden"
            onChange={handleFileUpload}
          />
          <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
            <Upload className="w-4 h-4 mr-2" />
            Upload File
          </Button>
        </div>

        <Textarea
          placeholder="Paste your call transcript here..."
          value={transcript}
          onChange={(e) => setTranscript(e.target.value)}
          className="min-h-[200px] font-mono text-sm"
        />

        <div className="flex items-center gap-3">
          <Button
            variant="glow"
            onClick={handleAnalyze}
            disabled={!transcript.trim() || isProcessing}
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Analyze Transcript
              </>
            )}
          </Button>
          <Button
            variant="outline"
            onClick={handleSaveTranscript}
            disabled={!transcript.trim() || createDocument.isPending}
          >
            Save to Account
          </Button>
        </div>
      </div>

      {/* Analysis Results */}
      {analysisResult && (
        <div className="space-y-4">
          {/* Extracted Technologies */}
          {analysisResult.technologies.length > 0 && (
            <div className="glass rounded-xl p-4 space-y-3">
              <h4 className="font-medium text-foreground">Extracted Technologies</h4>
              <div className="flex flex-wrap gap-2">
                {analysisResult.technologies.map((tech, i) => (
                  <Badge key={i} variant="secondary" className="gap-2">
                    {tech.name}
                    <span className="text-xs opacity-70">
                      {Math.round(tech.confidence * 100)}%
                    </span>
                  </Badge>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                Technologies with ≥70% confidence will be auto-added when saved
              </p>
            </div>
          )}

          {/* People */}
          {analysisResult.people.length > 0 && (
            <div className="glass rounded-xl p-4 space-y-3">
              <h4 className="font-medium text-foreground flex items-center gap-2">
                <Users className="w-4 h-4" />
                People Mentioned
              </h4>
              <div className="flex flex-wrap gap-2">
                {analysisResult.people.map((person, i) => (
                  <Badge key={i} variant="outline" className="gap-1">
                    {person.name}
                    {person.role && <span className="opacity-70">({person.role})</span>}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* NBAs */}
          {analysisResult.nbas.length > 0 && (
            <div className="glass rounded-xl p-4 space-y-3">
              <h4 className="font-medium text-foreground flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Next Best Actions
              </h4>
              <div className="space-y-2">
                {analysisResult.nbas.map((nba, i) => (
                  <div key={i} className="bg-muted/30 rounded-lg p-3">
                    <div className="flex items-start gap-2">
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "text-xs shrink-0",
                          nba.priority === 'high' && 'border-destructive text-destructive',
                          nba.priority === 'medium' && 'border-yellow-500 text-yellow-500',
                          nba.priority === 'low' && 'border-muted-foreground text-muted-foreground'
                        )}
                      >
                        {nba.priority}
                      </Badge>
                      <div>
                        <p className="text-sm font-medium">{nba.action}</p>
                        <p className="text-xs text-muted-foreground mt-1">{nba.reasoning}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Insights */}
          {(analysisResult.insights.painPoints.length > 0 || 
            analysisResult.insights.useCases.length > 0 ||
            analysisResult.insights.competitorMentions.length > 0) && (
            <div className="glass rounded-xl p-4 space-y-3">
              <h4 className="font-medium text-foreground">Insights</h4>
              
              {analysisResult.insights.painPoints.length > 0 && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> Pain Points
                  </p>
                  <ul className="list-disc list-inside text-sm">
                    {analysisResult.insights.painPoints.map((point, i) => (
                      <li key={i}>{point}</li>
                    ))}
                  </ul>
                </div>
              )}

              {analysisResult.insights.useCases.length > 0 && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Use Cases</p>
                  <ul className="list-disc list-inside text-sm">
                    {analysisResult.insights.useCases.map((uc, i) => (
                      <li key={i}>{uc}</li>
                    ))}
                  </ul>
                </div>
              )}

              {analysisResult.insights.competitorMentions.length > 0 && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Competitor Mentions</p>
                  <div className="flex flex-wrap gap-1">
                    {analysisResult.insights.competitorMentions.map((comp, i) => (
                      <Badge key={i} variant="outline" className="text-orange-400 border-orange-400/50">
                        {comp}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Momentum Meetings with Transcripts */}
      {momentumMeetings && momentumMeetings.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Video className="w-5 h-5 text-primary" />
            Call Recordings from Momentum
          </h3>
          <div className="grid gap-3">
            {momentumMeetings.map((meeting) => {
              const isAnalyzed = isMeetingAnalyzed(meeting);
              const linkedOpportunityId = getMeetingOpportunityId(meeting);
              const isLinkedToOpportunity = !!linkedOpportunityId;
              const hasExistingOpportunity = meeting.salesforce_opportunity_id 
                ? existingSfOppIds.has(meeting.salesforce_opportunity_id)
                : false;
              const isReanalyzing = reanalyzingMeetingId === meeting.id;
              
              return (
              <div key={meeting.id} className="glass rounded-xl p-4">
                {/* Progress indicator */}
                {isReanalyzing && reanalyzeProgress && (
                  <div className="mb-3 p-3 bg-primary/5 rounded-lg border border-primary/20">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-primary" />
                      <span className="text-sm font-medium text-primary">{reanalyzeProgress.step}</span>
                    </div>
                    {reanalyzeProgress.detail && (
                      <p className="text-xs text-muted-foreground mt-1 ml-6">{reanalyzeProgress.detail}</p>
                    )}
                  </div>
                )}
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    {isAnalyzed ? (
                      <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5" />
                    ) : (
                      <Video className="w-5 h-5 text-muted-foreground mt-0.5" />
                    )}
                    <div>
                      <p className="font-medium text-foreground">{meeting.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(meeting.start_time), 'MMM d, yyyy h:mm a')}
                        </p>
                        <Badge variant={meeting.status === 'imported' ? 'default' : 'secondary'} className="text-xs capitalize">
                          {meeting.status}
                        </Badge>
                        {isAnalyzed && (
                          <Badge variant="outline" className="text-xs text-green-600 border-green-500/50 bg-green-500/10">
                            <CheckCircle2 className="w-3 h-3 mr-1" />
                            Analyzed
                          </Badge>
                        )}
                      </div>
                      {meeting.salesforce_opportunity_id && (
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="outline" className="text-xs font-mono">
                            <Briefcase className="w-3 h-3 mr-1" />
                            SF Opp: {meeting.salesforce_opportunity_id}
                          </Badge>
                          {hasExistingOpportunity ? (
                            <>
                              <Badge variant="outline" className="text-xs text-green-600 border-green-500/50 bg-green-500/10">
                                <CheckCircle2 className="w-3 h-3 mr-1" />
                                Opportunity Exists
                              </Badge>
                              {!isLinkedToOpportunity && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 text-xs"
                                  onClick={() => openLinkDialog(meeting.id, meeting.momentum_id, meeting.title, meeting.salesforce_opportunity_id || undefined)}
                                >
                                  <Link2 className="w-3 h-3 mr-1" />
                                  Link to Opportunity
                                </Button>
                              )}
                              {isLinkedToOpportunity && (() => {
                                const opp = opportunityById.get(linkedOpportunityId!);
                                return (
                                  <Badge 
                                    variant="outline" 
                                    className="text-xs text-blue-600 border-blue-500/50 bg-blue-500/10 cursor-pointer hover:bg-blue-500/20 transition-colors"
                                    onClick={() => {
                                      const params = new URLSearchParams();
                                      params.set('opportunityId', linkedOpportunityId!);
                                      window.location.href = `/accounts/${accountId}?${params.toString()}`;
                                    }}
                                  >
                                    <Briefcase className="w-3 h-3 mr-1" />
                                    {opp?.name || 'Opportunity'}
                                    <ExternalLink className="w-3 h-3 ml-1" />
                                  </Badge>
                                );
                              })()}
                            </>
                          ) : (
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-6 text-xs"
                              onClick={() => handleOpenCreateOpportunity(meeting)}
                            >
                              <Plus className="w-3 h-3 mr-1" />
                              Create Opportunity
                            </Button>
                          )}
                        </div>
                      )}
                      {!meeting.salesforce_opportunity_id && !isLinkedToOpportunity && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-6 text-xs mt-2"
                          onClick={() => openLinkDialog(meeting.id, meeting.momentum_id, meeting.title, undefined)}
                        >
                          <Link2 className="w-3 h-3 mr-1" />
                          Link to Opportunity
                        </Button>
                      )}
                      {!meeting.salesforce_opportunity_id && isLinkedToOpportunity && (() => {
                        const opp = opportunityById.get(linkedOpportunityId!);
                        return (
                          <div className="flex items-center gap-2 mt-2">
                            <Badge 
                              variant="outline" 
                              className="text-xs text-blue-600 border-blue-500/50 bg-blue-500/10 cursor-pointer hover:bg-blue-500/20 transition-colors"
                              onClick={() => {
                                const params = new URLSearchParams();
                                params.set('opportunityId', linkedOpportunityId!);
                                window.location.href = `/accounts/${accountId}?${params.toString()}`;
                              }}
                            >
                              <Briefcase className="w-3 h-3 mr-1" />
                              {opp?.name || 'Opportunity'}
                              <ExternalLink className="w-3 h-3 ml-1" />
                            </Badge>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {/* Move to Account button (only for analyzed meetings) */}
                    {isAnalyzed && getMeetingTranscriptId(meeting) && (
                      <>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => {
                                const transcriptId = getMeetingTranscriptId(meeting);
                                if (transcriptId) {
                                  const linkedOppId = getMeetingOpportunityId(meeting);
                                  setMoveToOppTranscript({
                                    id: transcriptId,
                                    title: meeting.title,
                                    opportunityId: linkedOppId,
                                  });
                                }
                              }}
                            >
                              <ArrowRightLeft className="w-4 h-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Move to different opportunity</TooltipContent>
                        </Tooltip>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => {
                                const transcriptId = getMeetingTranscriptId(meeting);
                                if (transcriptId) {
                                  openMoveDialogForSingle(transcriptId, meeting.title);
                                }
                              }}
                            >
                              <Building2 className="w-4 h-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Move to different account</TooltipContent>
                        </Tooltip>
                      </>
                    )}
                    {/* View in Momentum button */}
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => window.open(getMomentumUrl(meeting.momentum_id), '_blank')}
                        >
                          <Play className="w-4 h-4 text-primary" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>View in Momentum</TooltipContent>
                    </Tooltip>
                    {meeting.status === 'processing' ? (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => resetProcessingMutation.mutate(meeting.id)}
                        disabled={resetProcessingMutation.isPending}
                      >
                        {resetProcessingMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <RotateCcw className="w-4 h-4 mr-1" />
                            Reset
                          </>
                        )}
                      </Button>
                    ) : (meeting.transcript_content || meeting.status === 'imported') && (
                      <>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setViewingMeetingTranscript(meeting)}
                        >
                          View
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => reanalyzeMomentumMeeting(meeting)}
                          disabled={reanalyzingMeetingId === meeting.id}
                        >
                          {reanalyzingMeetingId === meeting.id ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <>
                              <RotateCcw className="w-4 h-4 mr-1" />
                              Re-analyze
                            </>
                          )}
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Previous Transcripts */}
      {transcriptDocs.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-foreground">Previous Transcripts</h3>
          <div className="grid gap-3">
            {transcriptDocs.map((doc) => {
              // Check if this document has a corresponding transcript_review
              const matchingReview = transcriptReviews?.find(tr => 
                tr.file_name === doc.name || 
                (doc.content && tr.file_name?.includes(doc.name.substring(0, 20)))
              );
              const hasReview = !!matchingReview;
              const isLinkedToOpportunity = !!matchingReview?.opportunity_id;
              
              return (
              <Collapsible key={doc.id}>
                <div className="glass rounded-xl p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {hasReview ? (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      ) : (
                        <FileText className="w-5 h-5 text-muted-foreground" />
                      )}
                      <div>
                        <p className="font-medium text-foreground">{doc.name}</p>
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-xs text-muted-foreground">
                            {new Date(doc.created_at).toLocaleDateString()}
                          </p>
                          {hasReview && (
                            <Badge variant="outline" className="text-xs text-green-600 border-green-500/50 bg-green-500/10">
                              Analyzed
                            </Badge>
                          )}
                          {isLinkedToOpportunity && (
                            <Badge variant="outline" className="text-xs text-blue-600 border-blue-500/50 bg-blue-500/10">
                              <Link2 className="w-3 h-3 mr-1" />
                              Linked to Opportunity
                            </Badge>
                          )}
                          {hasReview && !isLinkedToOpportunity && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 text-xs"
                              onClick={() => openLinkDialogForDoc(doc.name)}
                            >
                              <Link2 className="w-3 h-3 mr-1" />
                              Link to Opportunity
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setViewingTranscript(doc)}
                      >
                        View Full
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => reanalyzeTranscript(doc)}
                        disabled={reanalyzingDocId === doc.id}
                      >
                        {reanalyzingDocId === doc.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <RotateCcw className="w-4 h-4 mr-1" />
                            Re-analyze
                          </>
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (confirm('Delete this transcript?')) {
                            deleteTranscriptMutation.mutate(doc.id);
                          }
                        }}
                        disabled={deleteTranscriptMutation.isPending}
                        className="text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm">
                          Preview
                          <ChevronDown className="w-4 h-4 ml-1" />
                        </Button>
                      </CollapsibleTrigger>
                    </div>
                  </div>
                  <CollapsibleContent className="mt-4">
                    <div className="bg-muted/30 rounded-lg p-3 max-h-40 overflow-hidden">
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap line-clamp-6">
                        {doc.content?.substring(0, 500)}...
                      </p>
                    </div>
                  </CollapsibleContent>
                </div>
              </Collapsible>
              );
            })}
          </div>
        </div>
      )}

      {/* Extracted Data Summary */}
      {(transcriptContacts.length > 0 || transcriptNbas.length > 0) && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-foreground">Extracted from Transcripts</h3>
          
          {/* Contacts from Transcripts */}
          {transcriptContacts.length > 0 && (
            <Collapsible open={expandedSections['contacts']} onOpenChange={() => toggleSection('contacts')}>
              <div className="glass rounded-xl p-4">
                <CollapsibleTrigger asChild>
                  <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-primary" />
                      <span className="font-medium">{transcriptContacts.length} Contacts</span>
                    </div>
                    {expandedSections['contacts'] ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-3 space-y-2">
                  {transcriptContacts.map((contact: any) => (
                    <div key={contact.id} className="flex items-center justify-between bg-muted/30 rounded-lg p-3">
                      <div>
                        <p className="font-medium text-sm">{contact.name}</p>
                        <p className="text-xs text-muted-foreground">{contact.role || 'No role'}</p>
                      </div>
                      <div className="text-right text-xs text-muted-foreground">
                        {contact.email && <p>{contact.email}</p>}
                        {contact.phone && <p>{contact.phone}</p>}
                      </div>
                    </div>
                  ))}
                </CollapsibleContent>
              </div>
            </Collapsible>
          )}

          {/* NBAs from Transcripts */}
          {transcriptNbas.length > 0 && (
            <Collapsible open={expandedSections['nbas']} onOpenChange={() => toggleSection('nbas')}>
              <div className="glass rounded-xl p-4">
                <CollapsibleTrigger asChild>
                  <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-primary" />
                      <span className="font-medium">{transcriptNbas.length} Actions</span>
                    </div>
                    {expandedSections['nbas'] ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-3 space-y-2">
                  {transcriptNbas.map((nba) => (
                    <div key={nba.id} className="bg-muted/30 rounded-lg p-3">
                      <div className="flex items-start gap-2">
                        <Badge 
                          variant="outline" 
                          className={cn(
                            "text-xs shrink-0",
                            nba.priority === 'high' && 'border-destructive text-destructive',
                            nba.priority === 'medium' && 'border-yellow-500 text-yellow-500',
                            nba.priority === 'low' && 'border-muted-foreground text-muted-foreground'
                          )}
                        >
                          {nba.priority}
                        </Badge>
                        <Badge variant="secondary" className="text-xs shrink-0">
                          {nba.action_type}
                        </Badge>
                        <div className="flex-1">
                          <p className="text-sm">{nba.action}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Status: {nba.status}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </CollapsibleContent>
              </div>
            </Collapsible>
          )}
        </div>
      )}

      {/* Analyzed Transcripts (non-Momentum) */}
      {nonMomentumTranscripts.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Analyzed Transcripts
            </h3>
            {/* Bulk action bar */}
            {selectedTranscriptIds.size > 0 && (
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{selectedTranscriptIds.size} selected</Badge>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={openMoveDialogForSelected}
                >
                  <Building2 className="w-4 h-4 mr-1" />
                  Move Selected
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedTranscriptIds(new Set())}
                >
                  Clear
                </Button>
              </div>
            )}
          </div>
          <div className="grid gap-3">
            {nonMomentumTranscripts.map((tr) => {
              const displayTitle = tr.meeting_title || tr.file_name || 'Untitled Transcript';
              const isLinkedToOpportunity = !!tr.opportunity_id;
              const isOrphanedMomentum = tr.file_name?.startsWith('momentum_') && tr.momentum_meeting_id;
              const isReanalyzing = reanalyzingMeetingId === tr.id;
              const isSelected = selectedTranscriptIds.has(tr.id);
              
              return (
                <div key={tr.id} className={cn(
                  "glass rounded-xl p-4",
                  isSelected && "ring-2 ring-primary"
                )}>
                  {/* Progress indicator for reanalysis */}
                  {isReanalyzing && reanalyzeProgress && (
                    <div className="mb-3 p-3 bg-primary/5 rounded-lg border border-primary/20">
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin text-primary" />
                        <span className="text-sm font-medium text-primary">{reanalyzeProgress.step}</span>
                      </div>
                      {reanalyzeProgress.detail && (
                        <p className="text-xs text-muted-foreground mt-1 ml-6">{reanalyzeProgress.detail}</p>
                      )}
                    </div>
                  )}
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      {/* Selection checkbox */}
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={() => toggleTranscriptSelection(tr.id)}
                        className="mt-1"
                      />
                      <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5" />
                      <div>
                        <p className="font-medium text-foreground">{displayTitle}</p>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {format(new Date(tr.created_at), 'MMM d, yyyy h:mm a')}
                          </p>
                          <Badge 
                            variant="outline" 
                            className={cn(
                              "text-xs",
                              tr.status === 'approved' && "text-green-600 border-green-500/50 bg-green-500/10",
                              tr.status === 'pending' && "text-amber-600 border-amber-500/50 bg-amber-500/10",
                              tr.status === 'processing' && "text-blue-600 border-blue-500/50 bg-blue-500/10",
                              tr.status === 'rejected' && "text-red-600 border-red-500/50 bg-red-500/10"
                            )}
                          >
                            {tr.status === 'approved' ? 'Analyzed' : tr.status === 'pending' ? 'Pending' : tr.status === 'processing' ? 'Processing' : tr.status}
                          </Badge>
                          {isLinkedToOpportunity ? (() => {
                            const opp = opportunityById.get(tr.opportunity_id!);
                            return (
                              <>
                                <Badge 
                                  variant="outline" 
                                  className="text-xs text-blue-600 border-blue-500/50 bg-blue-500/10 cursor-pointer hover:bg-blue-500/20 transition-colors"
                                  onClick={() => {
                                    const params = new URLSearchParams();
                                    params.set('opportunityId', tr.opportunity_id!);
                                    window.location.href = `/accounts/${accountId}?${params.toString()}`;
                                  }}
                                >
                                  <Briefcase className="w-3 h-3 mr-1" />
                                  {opp?.name || 'Opportunity'}
                                  <ExternalLink className="w-3 h-3 ml-1" />
                                </Badge>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 text-xs"
                                  onClick={() => openLinkDialogForTranscript(tr.id, displayTitle)}
                                >
                                  Change
                                </Button>
                              </>
                            );
                          })() : (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 text-xs"
                              onClick={() => openLinkDialogForTranscript(tr.id, displayTitle)}
                            >
                              <Link2 className="w-3 h-3 mr-1" />
                              Link to Opportunity
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                    {/* Action buttons */}
                    <div className="flex items-center gap-2">
                      {/* Remove from Account button */}
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:bg-destructive/10"
                            onClick={() => {
                              if (confirm('Remove this transcript from the account? This will also delete all associated insights (NBAs, pain points, use cases, metrics) extracted from it.')) {
                                removeTranscriptFromAccountMutation.mutate(tr.id);
                              }
                            }}
                            disabled={removeTranscriptFromAccountMutation.isPending}
                          >
                            {removeTranscriptFromAccountMutation.isPending ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <Trash2 className="w-4 h-4" />
                            )}
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Remove from account (deletes associated analysis)</TooltipContent>
                      </Tooltip>
                      {/* Move to Account button */}
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => openMoveDialogForSingle(tr.id, displayTitle)}
                          >
                            <Building2 className="w-4 h-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Move to different account</TooltipContent>
                      </Tooltip>
                      {isOrphanedMomentum && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => reanalyzeOrphanedTranscript(tr)}
                          disabled={isReanalyzing}
                        >
                          {isReanalyzing ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <>
                              <RotateCcw className="w-4 h-4 mr-1" />
                              Re-analyze
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {transcriptDocs.length === 0 && (!momentumMeetings || momentumMeetings.length === 0) && nonMomentumTranscripts.length === 0 && !transcript && (
        <div className="glass rounded-xl p-8 text-center border-2 border-dashed border-border">
          <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No transcripts yet</p>
          <p className="text-sm text-muted-foreground mt-1">
            Add call transcripts to automatically extract technologies and insights
          </p>
        </div>
      )}

      {/* Full Transcript Viewer Dialog */}
      <Dialog open={!!viewingTranscript} onOpenChange={() => setViewingTranscript(null)}>
        <DialogContent className="max-w-5xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              {viewingTranscript?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="text-xs text-muted-foreground mb-2">
            {viewingTranscript && new Date(viewingTranscript.created_at).toLocaleString()}
          </div>
          <ScrollArea className="h-[70vh]">
            <div className="bg-muted/30 rounded-lg p-6">
              <pre className="text-sm whitespace-pre-wrap font-mono leading-relaxed">
                {viewingTranscript?.content || 'No content available'}
              </pre>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Momentum Meeting Transcript Viewer Dialog */}
      <Dialog open={!!viewingMeetingTranscript} onOpenChange={() => setViewingMeetingTranscript(null)}>
        <DialogContent className="max-w-5xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Video className="w-5 h-5" />
              {viewingMeetingTranscript?.title}
            </DialogTitle>
          </DialogHeader>
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
            <Calendar className="w-3 h-3" />
            {viewingMeetingTranscript && format(new Date(viewingMeetingTranscript.start_time), 'MMM d, yyyy h:mm a')}
            {viewingMeetingTranscript?.salesforce_opportunity_id && (
              <Badge variant="outline" className="text-xs font-mono ml-2">
                SF Opp: {viewingMeetingTranscript.salesforce_opportunity_id}
              </Badge>
            )}
          </div>
          <ScrollArea className="h-[70vh]">
            <div className="bg-muted/30 rounded-lg p-6">
              <pre className="text-sm whitespace-pre-wrap font-mono leading-relaxed">
                {viewingMeetingTranscript?.transcript_content || 'No transcript available'}
              </pre>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Create Opportunity Dialog */}
      <Dialog open={!!createOpportunityMeeting} onOpenChange={() => setCreateOpportunityMeeting(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Briefcase className="w-5 h-5" />
              Create Opportunity
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground">
              Creating opportunity from meeting: <strong>{createOpportunityMeeting?.title}</strong>
            </div>
            
            {createOpportunityMeeting?.salesforce_opportunity_id && (
              <div className="flex items-center gap-2 p-3 bg-primary/10 rounded-lg border border-primary/20">
                <ExternalLink className="h-4 w-4 text-primary" />
                <span className="text-sm">
                  <strong>Salesforce Opportunity:</strong>{' '}
                  <code className="font-mono text-xs">{createOpportunityMeeting.salesforce_opportunity_id}</code>
                </span>
              </div>
            )}

            <div className="space-y-2">
              <Label>Opportunity Name</Label>
              <Input
                value={opportunityName}
                onChange={(e) => setOpportunityName(e.target.value)}
                placeholder="Enter opportunity name..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpportunityMeeting(null)}>
              Cancel
            </Button>
            <Button 
              onClick={handleCreateOpportunity}
              disabled={!opportunityName.trim() || createOpportunity.isPending}
            >
              {createOpportunity.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Opportunity
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Link to Opportunity Dialog */}
      {(linkDialogTranscriptId || linkDialogMomentumMeetingId) && (
        <LinkToOpportunityDialog
          open={linkDialogOpen}
          onOpenChange={(open) => {
            setLinkDialogOpen(open);
            if (!open) {
              setLinkDialogTranscriptId(null);
              setLinkDialogMomentumMeetingId(null);
              setLinkDialogMeetingTitle(undefined);
              setLinkDialogMeetingSfOppId(undefined);
            }
          }}
          accountId={accountId}
          transcriptReviewId={linkDialogTranscriptId}
          momentumMeetingId={linkDialogMomentumMeetingId}
          meetingTitle={linkDialogMeetingTitle}
          meetingSfOppId={linkDialogMeetingSfOppId}
          onLinked={(opportunityId) => {
            queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', accountId] });
            queryClient.invalidateQueries({ queryKey: ['account-opportunities', accountId] });
          }}
        />
      )}
      
      {/* Move to Account Dialog */}
      <MoveToAccountDialog
        open={moveDialogOpen}
        onOpenChange={(open) => {
          setMoveDialogOpen(open);
          if (!open) {
            setMoveTranscriptIds([]);
            setMoveMeetingTitles([]);
          }
        }}
        transcriptIds={moveTranscriptIds}
        currentAccountId={accountId}
        meetingTitles={moveMeetingTitles}
        onMoved={handleMoveComplete}
      />

      {/* Move to Opportunity Dialog */}
      {moveToOppTranscript && (
        <MoveToOpportunityDialog
          open={!!moveToOppTranscript}
          onOpenChange={(open) => { if (!open) setMoveToOppTranscript(null); }}
          transcriptId={moveToOppTranscript.id}
          transcriptTitle={moveToOppTranscript.title}
          accountId={accountId}
          currentOpportunityId={moveToOppTranscript.opportunityId}
          onMoved={() => {
            queryClient.invalidateQueries({ queryKey: ['transcript-reviews-account', accountId] });
            queryClient.invalidateQueries({ queryKey: ['momentum-meetings-account', accountId] });
          }}
        />
      )}
    </div>
  );
}

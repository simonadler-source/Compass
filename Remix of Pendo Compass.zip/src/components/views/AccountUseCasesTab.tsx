import { UseCasesPanel } from './UseCasesPanel';

interface AccountUseCasesTabProps {
  accountId: string;
}

export function AccountUseCasesTab({ accountId }: AccountUseCasesTabProps) {
  return <UseCasesPanel accountId={accountId} />;
}
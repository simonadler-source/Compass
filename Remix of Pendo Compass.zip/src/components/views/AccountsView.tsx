import { useState, useMemo } from 'react';
import { 
  Plus, 
  Search, 
  Building2, 
  Calendar, 
  ArrowRight, 
  Target, 
  FolderOpen, 
  TrendingUp, 
  Upload,
  Filter,
  ArrowUpDown,
  LayoutGrid,
  List,
  ChevronDown,
  X,
  FileText,
  Briefcase,
  Layers,
  CheckCircle2,
  Users,
  AlertCircle,
  Sparkles,
  DollarSign,
  ClipboardCheck,
  BarChart3,
  UserCheck,
  Percent,
  Star,
  Video,
  Clock,
} from 'lucide-react';
import { OpportunitiesPipelineView } from './OpportunitiesPipelineView';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { useAccounts, DbAccount, useUpdateAccount } from '@/hooks/useAccounts';
import { useAccountStats, AccountStats } from '@/hooks/useAccountStats';
import { useAllActiveUsers } from '@/hooks/useAllActiveUsers';
import { useTeamMembers } from '@/hooks/useTeamMembers';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ImportAccountsDialog } from '@/components/dialogs/ImportAccountsDialog';
import { FinancialSummaryHeader } from '@/components/FinancialSummaryHeader';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AccountsViewProps {
  onSelectAccount: (accountId: string) => void;
  onSelectOpportunity: (accountId: string, opportunityId: string) => void;
  onCreateAccount: () => void;
}

type SortField = 'name' | 'arr' | 'updated_at' | 'stage';
type SortDirection = 'asc' | 'desc';
type ViewMode = 'card' | 'list';
type TabView = 'accounts' | 'opportunities';


const accountTypeColors: Record<string, string> = {
  prospect: 'bg-layer-build-muted text-layer-build',
  customer: 'bg-primary/20 text-primary',
};

const statusColors: Record<string, string> = {
  active: 'bg-layer-growth/20 text-layer-growth',
  pending_review: 'bg-amber-500/20 text-amber-500',
  inactive: 'bg-muted text-muted-foreground',
  whitespace_only: 'bg-purple-500/20 text-purple-500',
};

const accountTypes = ['prospect', 'customer', 'discovery', 'evaluation', 'closed'];
const industries = ['Technology', 'Healthcare', 'Financial Services', 'Manufacturing', 'Retail', 'Other'];

// Format currency in compact form (e.g., $500k, $1.2M)
function formatCompactCurrency(amount: number): string {
  if (amount >= 1000000) {
    return `$${(amount / 1000000).toFixed(1)}M`;
  } else if (amount >= 1000) {
    return `$${(amount / 1000).toFixed(0)}k`;
  }
  return `$${amount.toFixed(0)}`;
}

export function AccountsView({ onSelectAccount, onSelectOpportunity, onCreateAccount }: AccountsViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [showImportDialog, setShowImportDialog] = useState(false);
  
  // Tab and view state
  const [activeTab, setActiveTab] = useState<TabView>('accounts');
  const [viewMode, setViewMode] = useState<ViewMode>('card');
  const [sortField, setSortField] = useState<SortField>('updated_at');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);
  const [selectedIndustry, setSelectedIndustry] = useState<string>('all');
  const [selectedAE, setSelectedAE] = useState<string>('all');
  const [selectedSE, setSelectedSE] = useState<string>('all');
  const [selectedActivity, setSelectedActivity] = useState<string>('all'); // 'all', 'new_accounts', 'new_meetings', 'new_opportunities'

  // Debounce search
  useMemo(() => {
    const timer = setTimeout(() => setDebouncedSearch(searchQuery), 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const { data: accounts, isLoading } = useAccounts(debouncedSearch || undefined);
  const updateAccount = useUpdateAccount();
  
  // Fetch team members for dropdowns
  const { teamMembers } = useTeamMembers();
  const { users: allUsers } = useAllActiveUsers();

  // Build SE filter options: union of (1) users with 'se' role and (2) emails assigned as primary_se on any account
  const { data: seOptions } = useQuery({
    queryKey: ['se-filter-options'],
    queryFn: async () => {
      // 1. Fetch users with the 'se' role
      const { data: seRoles } = await supabase
        .from('user_roles')
        .select('user_id, profiles!inner(email, full_name)')
        .eq('role', 'se' as any);

      // 2. Fetch distinct primary_se_email values from accounts
      const { data: accountSEs } = await supabase
        .from('accounts')
        .select('primary_se_email')
        .not('primary_se_email', 'is', null);

      const seMap = new Map<string, string>(); // email -> display name

      // Add role-based SEs
      (seRoles || []).forEach((row: any) => {
        const profile = Array.isArray(row.profiles) ? row.profiles[0] : row.profiles;
        if (profile?.email) {
          seMap.set(profile.email.toLowerCase(), profile.full_name || profile.email);
        }
      });

      // Add SEs assigned on accounts (fall back to email if no profile name found)
      (accountSEs || []).forEach((row: any) => {
        const email = row.primary_se_email?.toLowerCase();
        if (email && !seMap.has(email)) {
          // Try to find name from allUsers cache
          const profile = allUsers?.find(u => u.email?.toLowerCase() === email);
          seMap.set(email, profile?.full_name || email);
        }
      });

      return Array.from(seMap.entries())
        .map(([email, name]) => ({ email, name }))
        .sort((a, b) => a.name.localeCompare(b.name));
    },
    staleTime: 60_000,
  });
  
  // Get all account IDs for stats fetching
  const accountIds = useMemo(() => accounts?.map(a => a.id) || [], [accounts]);
  const { data: accountStats } = useAccountStats(accountIds);
  
  // Fetch accounts with unanalyzed transcripts
  const { data: accountsWithUnanalyzed } = useQuery({
    queryKey: ['accounts-with-unanalyzed'],
    queryFn: async () => {
      // Get all imported meetings with accounts
      const { data: importedMeetings, error: importedError } = await supabase
        .from('momentum_meetings')
        .select('id, momentum_id, matched_account_id')
        .eq('status', 'imported')
        .not('transcript_content', 'is', null)
        .not('matched_account_id', 'is', null);
      
      if (importedError) throw importedError;
      if (!importedMeetings?.length) return new Set<string>();

      // Get all transcript_reviews file_names - check both UUID and numeric formats for compatibility
      const allFileNames = importedMeetings.flatMap(m => [
        `momentum_${m.id}`,           // UUID format
        `momentum_${m.momentum_id}`   // Numeric format
      ]);
      const { data: existingReviews, error: reviewsError } = await supabase
        .from('transcript_reviews')
        .select('file_name')
        .in('file_name', allFileNames);
      
      if (reviewsError) throw reviewsError;

      const analyzedFileNames = new Set(existingReviews?.map(r => r.file_name) || []);
      
      // Get account IDs that have unanalyzed meetings (check both formats)
      const unanalyzedAccountIds = new Set<string>();
      importedMeetings.forEach(m => {
        const hasUuidReview = analyzedFileNames.has(`momentum_${m.id}`);
        const hasNumericReview = analyzedFileNames.has(`momentum_${m.momentum_id}`);
        if (!hasUuidReview && !hasNumericReview && m.matched_account_id) {
          unanalyzedAccountIds.add(m.matched_account_id);
        }
      });
      
      return unanalyzedAccountIds;
    },
  });

  // Define "new" as within last 7 days
  const sevenDaysAgo = useMemo(() => {
    const date = new Date();
    date.setDate(date.getDate() - 7);
    return date.toISOString();
  }, []);

  // Fetch accounts with new meetings (in last 7 days)
  const { data: accountsWithNewMeetings } = useQuery({
    queryKey: ['accounts-with-new-meetings', sevenDaysAgo],
    queryFn: async () => {
      const { data: meetings, error } = await supabase
        .from('momentum_meetings')
        .select('matched_account_id, start_time')
        .not('matched_account_id', 'is', null)
        .gte('start_time', sevenDaysAgo);
      
      if (error) throw error;
      
      // Return map of accountId -> count of new meetings
      const meetingCounts = new Map<string, number>();
      (meetings || []).forEach((m: { matched_account_id: string | null; start_time: string | null }) => {
        if (m.matched_account_id) {
          meetingCounts.set(m.matched_account_id, (meetingCounts.get(m.matched_account_id) || 0) + 1);
        }
      });
      return meetingCounts;
    },
  });

  // Fetch accounts with new opportunities (created in last 7 days)
  const { data: accountsWithNewOpportunities } = useQuery({
    queryKey: ['accounts-with-new-opportunities', sevenDaysAgo],
    queryFn: async () => {
      const { data: opps, error } = await supabase
        .from('opportunities')
        .select('account_id, created_at')
        .gte('created_at', sevenDaysAgo);
      
      if (error) throw error;
      
      // Return map of accountId -> count of new opportunities
      const oppCounts = new Map<string, number>();
      opps?.forEach(o => {
        if (o.account_id) {
          oppCounts.set(o.account_id, (oppCounts.get(o.account_id) || 0) + 1);
        }
      });
      return oppCounts;
    },
  });

  // Set of new accounts (created in last 7 days)
  const newAccountIds = useMemo(() => {
    if (!accounts) return new Set<string>();
    return new Set(
      accounts
        .filter(a => a.created_at && new Date(a.created_at) >= new Date(sevenDaysAgo))
        .map(a => a.id)
    );
  }, [accounts, sevenDaysAgo]);

  
  // Handler for updating account owner/SE
  const handleUpdateAccountField = (accountId: string, field: 'owner_id' | 'primary_se_email', value: string | null) => {
    updateAccount.mutate({ id: accountId, [field]: value === 'unassigned' ? null : value }, {
      onSuccess: () => {
        toast.success(`Account ${field === 'owner_id' ? 'owner' : 'primary SE'} updated`);
      }
    });
  };

  // Filter and sort accounts
  const filteredAndSortedAccounts = useMemo(() => {
    if (!accounts) return [];
    
    let filtered = [...accounts];
    
    // Filter by type (prospect/customer)
    if (selectedTypes.length > 0) {
      filtered = filtered.filter(a => selectedTypes.includes(a.stage || 'prospect'));
    }
    
    // Filter by status
    if (selectedStatuses.length > 0) {
      filtered = filtered.filter(a => selectedStatuses.includes(a.status || 'active'));
    }
    
    // Filter by industry
    if (selectedIndustry && selectedIndustry !== 'all') {
      filtered = filtered.filter(a => a.industry === selectedIndustry);
    }
    
    // Filter by Account Executive (owner)
    if (selectedAE && selectedAE !== 'all') {
      if (selectedAE === 'unassigned') {
        filtered = filtered.filter(a => !a.owner_id);
      } else {
        filtered = filtered.filter(a => a.owner_id === selectedAE);
      }
    }
    
    // Filter by Sales Engineer
    if (selectedSE && selectedSE !== 'all') {
      if (selectedSE === 'unassigned') {
        filtered = filtered.filter(a => !a.primary_se_email);
      } else {
        filtered = filtered.filter(a => a.primary_se_email === selectedSE);
      }
    }
    
    // Filter by Activity (new accounts, new meetings, new opportunities)
    if (selectedActivity && selectedActivity !== 'all') {
      switch (selectedActivity) {
        case 'new_accounts':
          filtered = filtered.filter(a => newAccountIds.has(a.id));
          break;
        case 'new_meetings':
          filtered = filtered.filter(a => accountsWithNewMeetings?.has(a.id));
          break;
        case 'new_opportunities':
          filtered = filtered.filter(a => accountsWithNewOpportunities?.has(a.id));
          break;
      }
    }
    
    // Sort
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortField) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'arr':
          comparison = (a.arr || 0) - (b.arr || 0);
          break;
        case 'updated_at':
          comparison = new Date(a.updated_at).getTime() - new Date(b.updated_at).getTime();
          break;
        case 'stage':
          // Type sorting: prospect before customer
          const typeOrder = { prospect: 0, customer: 1 };
          comparison = (typeOrder[a.stage as keyof typeof typeOrder] ?? 0) - 
                       (typeOrder[b.stage as keyof typeof typeOrder] ?? 0);
          break;
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });
    
    return filtered;
  }, [accounts, selectedTypes, selectedStatuses, selectedIndustry, selectedAE, selectedSE, sortField, sortDirection]);

  // Count pending review accounts
  const pendingReviewCount = useMemo(() => {
    return accounts?.filter(a => a.status === 'pending_review').length || 0;
  }, [accounts]);

  // Group accounts by stage for card view
  const accountsByType = useMemo(() => {
    return filteredAndSortedAccounts.reduce((acc, account) => {
      const type = account.stage || 'prospect';
      if (!acc[type]) acc[type] = [];
      acc[type].push(account);
      return acc;
    }, {} as Record<string, DbAccount[]>);
  }, [filteredAndSortedAccounts]);

  const toggleTypeFilter = (type: string) => {
    setSelectedTypes(prev => 
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const toggleStatusFilter = (status: string) => {
    setSelectedStatuses(prev => 
      prev.includes(status) ? prev.filter(s => s !== status) : [...prev, status]
    );
  };

  const clearFilters = () => {
    setSelectedTypes([]);
    setSelectedStatuses([]);
    setSelectedIndustry('all');
    setSelectedAE('all');
    setSelectedSE('all');
    setSelectedActivity('all');
  };

  const hasActiveFilters = selectedTypes.length > 0 || selectedStatuses.length > 0 || selectedIndustry !== 'all' || selectedAE !== 'all' || selectedSE !== 'all' || selectedActivity !== 'all';

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const preSalesStageColors: Record<string, string> = {
    'Not Started': 'bg-muted text-muted-foreground',
    'Discovery': 'bg-blue-500/20 text-blue-500',
    'Demo': 'bg-purple-500/20 text-purple-500',
    'Proof - Scoping': 'bg-amber-500/20 text-amber-500',
    'Proof': 'bg-orange-500/20 text-orange-500',
    'Technical Win': 'bg-layer-growth/20 text-layer-growth',
    'Technical Loss': 'bg-destructive/20 text-destructive',
    'Stale / Not Active': 'bg-muted text-muted-foreground',
    'Unqualified': 'bg-muted text-muted-foreground',
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-heading">Account Folders</h1>
          <p className="text-muted-foreground mt-1">
            Manage customer accounts, whitespace opportunities & technical plans
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setShowImportDialog(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Import CSV
          </Button>
          <Button variant="glow" onClick={onCreateAccount}>
            <Plus className="w-4 h-4" />
            New Account
          </Button>
        </div>
      </div>

      {/* Tab Toggle */}
      <div className="flex items-center gap-1 p-1 bg-muted/50 rounded-lg w-fit">
        <Button
          variant={activeTab === 'accounts' ? 'secondary' : 'ghost'}
          size="sm"
          onClick={() => setActiveTab('accounts')}
          className="gap-2"
        >
          <Building2 className="w-4 h-4" />
          Accounts
        </Button>
        <Button
          variant={activeTab === 'opportunities' ? 'secondary' : 'ghost'}
          size="sm"
          onClick={() => setActiveTab('opportunities')}
          className="gap-2"
        >
          <Briefcase className="w-4 h-4" />
          Opportunities
        </Button>
      </div>

      <ImportAccountsDialog open={showImportDialog} onOpenChange={setShowImportDialog} />

      {/* Accounts Tab Content */}
      {activeTab === 'accounts' && (
        <>
      {/* Financial Summary Header */}
      {filteredAndSortedAccounts.length > 0 && (
        <FinancialSummaryHeader 
          accountIds={filteredAndSortedAccounts.map(a => a.id)}
          totalWhitespace={
            accountStats 
              ? filteredAndSortedAccounts.reduce((sum, a) => sum + (accountStats[a.id]?.whitespaceRevenue || 0), 0)
              : 0
          }
        />
      )}

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <FolderOpen className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{accounts?.length || 0}</p>
              <p className="text-xs text-muted-foreground">Total Accounts</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
              <Target className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{pendingReviewCount}</p>
              <p className="text-xs text-muted-foreground">Pending Review</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-layer-build-muted flex items-center justify-center">
              <Target className="w-5 h-5 text-layer-build" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{accountsByType['prospect']?.length || 0}</p>
              <p className="text-xs text-muted-foreground">Prospects</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{accountsByType['customer']?.length || 0}</p>
              <p className="text-xs text-muted-foreground">Customers</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search, Filters, and View Toggle */}
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="flex flex-wrap items-center gap-2 flex-1">
          {/* Search */}
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search accounts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Type Filter */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1">
                <Filter className="w-4 h-4" />
                Type
                {selectedTypes.length > 0 && (
                  <Badge variant="secondary" className="ml-1 h-5 px-1.5">
                    {selectedTypes.length}
                  </Badge>
                )}
                <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48 bg-popover border border-border shadow-lg z-50">
              <DropdownMenuLabel>Filter by Type</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {accountTypes.map(type => (
                <DropdownMenuCheckboxItem
                  key={type}
                  checked={selectedTypes.includes(type)}
                  onCheckedChange={() => toggleTypeFilter(type)}
                  className="capitalize"
                >
                  {type}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Status Filter */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1">
                <Filter className="w-4 h-4" />
                Status
                {selectedStatuses.length > 0 && (
                  <Badge variant="secondary" className="ml-1 h-5 px-1.5">
                    {selectedStatuses.length}
                  </Badge>
                )}
                <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48 bg-popover border border-border shadow-lg z-50">
              <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {['active', 'pending_review', 'inactive'].map(status => (
                <DropdownMenuCheckboxItem
                  key={status}
                  checked={selectedStatuses.includes(status)}
                  onCheckedChange={() => toggleStatusFilter(status)}
                  className="capitalize"
                >
                  {status.replace('_', ' ')}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Industry Filter */}
          <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Industry" />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50">
              <SelectItem value="all">All Industries</SelectItem>
              {industries.map(industry => (
                <SelectItem key={industry} value={industry}>{industry}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Account Executive Filter */}
          <Select value={selectedAE} onValueChange={setSelectedAE}>
            <SelectTrigger className="w-[160px] h-9">
              <SelectValue placeholder="Account Exec" />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50">
              <SelectItem value="all">All AEs</SelectItem>
              <SelectItem value="unassigned">Unassigned</SelectItem>
              {allUsers?.map(user => (
                <SelectItem key={user.id} value={user.id}>
                  {user.full_name || user.email}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Sales Engineer Filter */}
          <Select value={selectedSE} onValueChange={setSelectedSE}>
            <SelectTrigger className="w-[160px] h-9">
              <SelectValue placeholder="Sales Engineer" />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50">
              <SelectItem value="all">All SEs</SelectItem>
              <SelectItem value="unassigned">Unassigned</SelectItem>
              {seOptions?.map(se => (
                <SelectItem key={se.email} value={se.email}>
                  {se.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Activity Filter - New Accounts, Meetings, Opportunities */}
          <Select value={selectedActivity} onValueChange={setSelectedActivity}>
            <SelectTrigger className="w-[180px] h-9">
              <SelectValue placeholder="Activity" />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50">
              <SelectItem value="all">All Activity</SelectItem>
              <SelectItem value="new_accounts">
                <div className="flex items-center gap-2">
                  <Star className="w-3 h-3 text-amber-500" />
                  New Accounts (7d)
                </div>
              </SelectItem>
              <SelectItem value="new_meetings">
                <div className="flex items-center gap-2">
                  <Video className="w-3 h-3 text-blue-500" />
                  New Meetings (7d)
                </div>
              </SelectItem>
              <SelectItem value="new_opportunities">
                <div className="flex items-center gap-2">
                  <Briefcase className="w-3 h-3 text-green-500" />
                  New Opps (7d)
                </div>
              </SelectItem>
            </SelectContent>
          </Select>

          {/* Clear Filters */}
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters} className="gap-1">
              <X className="w-3 h-3" />
              Clear
            </Button>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* Sort */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1">
                <ArrowUpDown className="w-4 h-4" />
                Sort
                <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 bg-popover border border-border shadow-lg z-50">
              <DropdownMenuLabel>Sort by</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => handleSort('name')}>
                Name {sortField === 'name' && (sortDirection === 'asc' ? '↑' : '↓')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleSort('arr')}>
                ARR {sortField === 'arr' && (sortDirection === 'asc' ? '↑' : '↓')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleSort('updated_at')}>
                Last Updated {sortField === 'updated_at' && (sortDirection === 'asc' ? '↑' : '↓')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleSort('stage')}>
                Stage {sortField === 'stage' && (sortDirection === 'asc' ? '↑' : '↓')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* View Toggle */}
          <div className="flex items-center border border-border rounded-lg overflow-hidden">
            <Button
              variant={viewMode === 'card' ? 'secondary' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('card')}
              className="rounded-none border-0"
            >
              <LayoutGrid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'secondary' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('list')}
              className="rounded-none border-0"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2">
          {selectedTypes.map(type => (
            <Badge key={type} variant="secondary" className="gap-1 capitalize">
              {type}
              <X className="w-3 h-3 cursor-pointer" onClick={() => toggleTypeFilter(type)} />
            </Badge>
          ))}
          {selectedStatuses.map(status => (
            <Badge key={status} variant="secondary" className="gap-1 capitalize">
              {status.replace('_', ' ')}
              <X className="w-3 h-3 cursor-pointer" onClick={() => toggleStatusFilter(status)} />
            </Badge>
          ))}
          {selectedIndustry !== 'all' && (
            <Badge variant="secondary" className="gap-1">
              {selectedIndustry}
              <X className="w-3 h-3 cursor-pointer" onClick={() => setSelectedIndustry('all')} />
            </Badge>
          )}
        </div>
      )}

      {/* Loading State */}
      {isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-[180px] rounded-xl" />
          ))}
        </div>
      )}

      {/* Results Count */}
      {!isLoading && accounts && (
        <p className="text-sm text-muted-foreground">
          Showing {filteredAndSortedAccounts.length} of {accounts.length} accounts
        </p>
      )}

      {/* Card View - Grouped by Type */}
      {!isLoading && viewMode === 'card' && filteredAndSortedAccounts.length > 0 && (
        <div className="space-y-6">
          {accountTypes.map((type) => {
            const typeAccounts = accountsByType[type] || [];
            if (typeAccounts.length === 0) return null;
            
            return (
              <div key={type} className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge className={cn("capitalize", accountTypeColors[type])}>
                    {type}
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    {typeAccounts.length} account{typeAccounts.length !== 1 ? 's' : ''}
                  </span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {typeAccounts.map((account, index) => (
                    <AccountCard
                      key={account.id}
                      account={account}
                      stats={accountStats?.[account.id]}
                      index={index}
                      onSelect={() => onSelectAccount(account.id)}
                      hasUnanalyzedTranscripts={accountsWithUnanalyzed?.has(account.id) || false}
                      isNew={newAccountIds.has(account.id)}
                      newMeetingsCount={accountsWithNewMeetings?.get(account.id) || 0}
                      newOpportunitiesCount={accountsWithNewOpportunities?.get(account.id) || 0}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* List View */}
      {!isLoading && viewMode === 'list' && filteredAndSortedAccounts.length > 0 && (
        <div className="glass rounded-xl overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead 
                  className="cursor-pointer hover:text-foreground"
                  onClick={() => handleSort('name')}
                >
                  Account {sortField === 'name' && (sortDirection === 'asc' ? '↑' : '↓')}
                </TableHead>
                <TableHead>Industry</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Primary SE</TableHead>
                <TableHead 
                  className="cursor-pointer hover:text-foreground"
                  onClick={() => handleSort('stage')}
                >
                  Type {sortField === 'stage' && (sortDirection === 'asc' ? '↑' : '↓')}
                </TableHead>
                <TableHead>Status</TableHead>
                <TableHead 
                  className="cursor-pointer hover:text-foreground"
                  onClick={() => handleSort('updated_at')}
                >
                  Updated {sortField === 'updated_at' && (sortDirection === 'asc' ? '↑' : '↓')}
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAndSortedAccounts.map((account) => {
                // Find owner name from users (by id)
                const ownerUser = allUsers?.find(u => u.id === account.owner_id);
                const ownerDisplay = ownerUser?.full_name || ownerUser?.email?.split('@')[0] || null;
                
                // Find SE name from profiles by email (more consistent than team_members)
                const seEmail = (account as any).primary_se_email?.toLowerCase();
                const seUserFromProfiles = allUsers?.find(u => u.email?.toLowerCase() === seEmail);
                const seUser = teamMembers?.find(t => t.member_email?.toLowerCase() === seEmail);
                const seDisplay = seUserFromProfiles?.full_name || seUser?.member_name || seEmail?.split('@')[0] || null;
                
                return (
                <TableRow 
                  key={account.id} 
                  className="cursor-pointer hover:bg-muted/50"
                >
                  <TableCell onClick={() => onSelectAccount(account.id)}>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Building2 className="w-4 h-4 text-primary" />
                      </div>
                      <span className="font-medium">{account.name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground" onClick={() => onSelectAccount(account.id)}>
                    {account.industry || '-'}
                  </TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <Select
                      value={account.owner_id || 'unassigned'}
                      onValueChange={(value) => handleUpdateAccountField(account.id, 'owner_id', value)}
                    >
                      <SelectTrigger className="w-36 h-8 text-xs">
                        <SelectValue placeholder="Select owner">
                          {ownerDisplay || <span className="text-muted-foreground">Unassigned</span>}
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent className="bg-popover border border-border shadow-lg z-50">
                        <SelectItem value="unassigned">
                          <span className="text-muted-foreground">Unassigned</span>
                        </SelectItem>
                        {allUsers?.map(user => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.full_name || user.email?.split('@')[0]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <Select
                      value={(account as any).primary_se_email || 'unassigned'}
                      onValueChange={(value) => handleUpdateAccountField(account.id, 'primary_se_email' as any, value)}
                    >
                      <SelectTrigger className="w-36 h-8 text-xs">
                        <SelectValue placeholder="Select SE">
                          {seDisplay || <span className="text-muted-foreground">Unassigned</span>}
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent className="bg-popover border border-border shadow-lg z-50">
                        <SelectItem value="unassigned">
                          <span className="text-muted-foreground">Unassigned</span>
                        </SelectItem>
                        {teamMembers?.filter(m => m.member_email).map(member => (
                          <SelectItem key={member.member_email} value={member.member_email}>
                            {member.member_name || member.member_email.split('@')[0]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell onClick={() => onSelectAccount(account.id)}>
                    {account.stage && (
                      <Badge className={cn("capitalize", accountTypeColors[account.stage] || accountTypeColors.prospect)}>
                        {account.stage}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell onClick={() => onSelectAccount(account.id)}>
                    {account.status && (
                      <Badge className={cn("capitalize", statusColors[account.status] || statusColors.active)}>
                        {account.status.replace('_', ' ')}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-muted-foreground" onClick={() => onSelectAccount(account.id)}>
                    {new Date(account.updated_at).toLocaleDateString()}
                  </TableCell>
                </TableRow>
              );})}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Empty State */}
      {!isLoading && filteredAndSortedAccounts.length === 0 && accounts && accounts.length > 0 && (
        <div className="glass rounded-xl p-8 flex flex-col items-center justify-center min-h-[200px]">
          <Filter className="w-12 h-12 text-muted-foreground mb-4" />
          <p className="font-semibold text-lg text-foreground">No accounts match your filters</p>
          <p className="text-sm text-muted-foreground mt-1">
            Try adjusting your filters or search query
          </p>
          <Button variant="outline" onClick={clearFilters} className="mt-4">
            Clear all filters
          </Button>
        </div>
      )}

      {/* Empty State - No accounts at all */}
      {!isLoading && (!accounts || accounts.length === 0) && (
        <div
          onClick={onCreateAccount}
          className="glass rounded-xl p-8 cursor-pointer group border-2 border-dashed border-border hover:border-primary/50 transition-colors flex flex-col items-center justify-center min-h-[300px]"
        >
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <Plus className="w-10 h-10 text-primary" />
          </div>
          <p className="font-semibold text-lg text-foreground">Create your first account</p>
          <p className="text-sm text-muted-foreground mt-1 text-center max-w-md">
            Start by creating a customer folder to store technical architecture maps, 
            discovery transcripts, opportunities, and account plans.
          </p>
        </div>
      )}
        </>
      )}

      {/* Opportunities Tab Content */}
      {activeTab === 'opportunities' && (
        <OpportunitiesPipelineView
          onSelectAccount={onSelectAccount}
          onSelectOpportunity={onSelectOpportunity}
        />
      )}
    </div>
  );
}

interface AccountCardProps {
  account: DbAccount;
  stats?: AccountStats;
  index: number;
  onSelect: () => void;
  hasUnanalyzedTranscripts?: boolean;
  isNew?: boolean;
  newMeetingsCount?: number;
  newOpportunitiesCount?: number;
}

function AccountCard({ account, stats, index, onSelect, hasUnanalyzedTranscripts, isNew, newMeetingsCount, newOpportunitiesCount }: AccountCardProps) {
  const coverageColor = (stats?.coveragePercent ?? 0) >= 70 
    ? 'text-layer-growth' 
    : (stats?.coveragePercent ?? 0) >= 40 
      ? 'text-amber-500' 
      : 'text-muted-foreground';

  return (
    <TooltipProvider>
      <div
        onClick={onSelect}
        className={cn(
          "glass glass-hover rounded-xl p-5 cursor-pointer group",
          "animate-slide-up"
        )}
        style={{ animationDelay: `${index * 50}ms` }}
      >
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center relative">
              <Building2 className="w-5 h-5 text-primary" />
              {hasUnanalyzedTranscripts && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 flex items-center justify-center">
                      <AlertCircle className="w-3 h-3 text-white" />
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Has unanalyzed transcripts</p>
                  </TooltipContent>
                </Tooltip>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors truncate">
                  {account.name}
                </h3>
                {/* Activity badges */}
                {isNew && (
                  <Badge className="bg-amber-500/20 text-amber-500 text-xs shrink-0 gap-1">
                    <Star className="w-3 h-3" />
                    New
                  </Badge>
                )}
                {(newMeetingsCount ?? 0) > 0 && (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Badge className="bg-blue-500/20 text-blue-500 text-xs shrink-0 gap-1">
                        <Video className="w-3 h-3" />
                        {newMeetingsCount}
                      </Badge>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{newMeetingsCount} new meeting{newMeetingsCount !== 1 ? 's' : ''} in last 7 days</p>
                    </TooltipContent>
                  </Tooltip>
                )}
                {(newOpportunitiesCount ?? 0) > 0 && (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Badge className="bg-green-500/20 text-green-500 text-xs shrink-0 gap-1">
                        <Briefcase className="w-3 h-3" />
                        {newOpportunitiesCount}
                      </Badge>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{newOpportunitiesCount} new opp{newOpportunitiesCount !== 1 ? 's' : ''} in last 7 days</p>
                    </TooltipContent>
                  </Tooltip>
                )}
                {account.status === 'pending_review' && (
                  <Badge className="bg-amber-500/20 text-amber-500 text-xs shrink-0">
                    Pending
                  </Badge>
                )}
              </div>
              {/* Financial Metrics Row - Always visible */}
              <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                {/* Current ARR (closed won) */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className={cn(
                      "inline-flex items-center gap-1 text-xs font-medium",
                      (stats?.currentArr ?? 0) > 0 
                        ? "text-green-600 dark:text-green-400" 
                        : "text-muted-foreground/50"
                    )}>
                      <DollarSign className="w-3 h-3" />
                      {(stats?.currentArr ?? 0) > 0 
                        ? formatCompactCurrency(stats?.currentArr ?? 0) 
                        : '$0'}
                    </span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Current ARR (Closed Won)</p>
                  </TooltipContent>
                </Tooltip>

                {/* Pipeline Total */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className={cn(
                      "inline-flex items-center gap-1 text-xs font-medium",
                      (stats?.totalOpportunityValue ?? 0) > 0 
                        ? "text-layer-build" 
                        : "text-muted-foreground/50"
                    )}>
                      <TrendingUp className="w-3 h-3" />
                      {(stats?.totalOpportunityValue ?? 0) > 0 
                        ? formatCompactCurrency(stats?.totalOpportunityValue ?? 0) 
                        : '$0'}
                    </span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>
                      Pipeline: {formatCompactCurrency(stats?.totalOpportunityValue ?? 0)} | 
                      Weighted: {formatCompactCurrency(stats?.pipelineWeighted ?? 0)}
                    </p>
                  </TooltipContent>
                </Tooltip>

                {/* Whitespace */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Badge 
                      className={cn(
                        "border-0 gap-1 px-2 py-0.5 font-semibold cursor-help",
                        (stats?.whitespaceRevenue ?? 0) > 0
                          ? "bg-layer-growth/20 text-layer-growth"
                          : "bg-muted/40 text-muted-foreground/50"
                      )}
                    >
                      <Sparkles className="w-3 h-3" />
                      {(stats?.whitespaceRevenue ?? 0) > 0 
                        ? formatCompactCurrency(stats?.whitespaceRevenue ?? 0)
                        : '$0'}
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Whitespace Opportunity</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              {account.industry && (
                <p className="text-xs text-muted-foreground truncate">{account.industry}</p>
              )}
            </div>
        </div>
        <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
      </div>

      {/* Three Readiness Progress Bars */}
      <div className="mb-3 space-y-2">
        {/* Knowledge Coverage - Blue */}
        <div>
          <div className="flex items-center justify-between text-[10px] mb-0.5">
            <span className="text-muted-foreground">Knowledge</span>
            <span className={cn("font-medium", coverageColor)}>
              {stats?.coveragePercent ?? 0}%
            </span>
          </div>
          <Progress value={stats?.coveragePercent ?? 0} className="h-1 [&>div]:bg-blue-500" />
        </div>
        
        {/* Technical Readiness - Orange */}
        <div>
          <div className="flex items-center justify-between text-[10px] mb-0.5">
            <span className="text-muted-foreground">Technical</span>
            <span className={cn(
              "font-medium",
              (stats?.technicalReadinessPercent ?? 0) >= 70 ? 'text-green-600' :
              (stats?.technicalReadinessPercent ?? 0) >= 40 ? 'text-amber-500' : 'text-muted-foreground'
            )}>
              {stats?.technicalReadinessPercent ?? 0}%
            </span>
          </div>
          <Progress value={stats?.technicalReadinessPercent ?? 0} className="h-1 [&>div]:bg-orange-500" />
        </div>
        
        {/* Commercial Readiness - Green */}
        <div>
          <div className="flex items-center justify-between text-[10px] mb-0.5">
            <span className="text-muted-foreground">Commercial</span>
            <span className={cn(
              "font-medium",
              (stats?.commercialReadinessPercent ?? 0) >= 70 ? 'text-green-600' :
              (stats?.commercialReadinessPercent ?? 0) >= 40 ? 'text-amber-500' : 'text-muted-foreground'
            )}>
              {stats?.commercialReadinessPercent ?? 0}%
            </span>
          </div>
          <Progress value={stats?.commercialReadinessPercent ?? 0} className="h-1 [&>div]:bg-green-500" />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-2 mb-3">
        <div className="text-center p-2 rounded-lg bg-muted/30">
          <div className="flex items-center justify-center gap-1 mb-0.5">
            <Briefcase className="w-3 h-3 text-muted-foreground" />
            <span className="text-sm font-semibold text-foreground">
              {(stats?.openOpportunities ?? 0)}
            </span>
          </div>
          <span className="text-[10px] text-muted-foreground">Open Opps</span>
        </div>
        <div className="text-center p-2 rounded-lg bg-muted/30">
          <div className="flex items-center justify-center gap-1 mb-0.5">
            <FileText className="w-3 h-3 text-muted-foreground" />
            <span className="text-sm font-semibold text-foreground">
              {stats?.totalTranscripts ?? 0}
            </span>
          </div>
          <span className="text-[10px] text-muted-foreground">Transcripts</span>
        </div>
        <div className="text-center p-2 rounded-lg bg-muted/30">
          <div className="flex items-center justify-center gap-1 mb-0.5">
            <Target className="w-3 h-3 text-muted-foreground" />
            <span className="text-sm font-semibold text-foreground">
              {stats?.useCasesCount ?? 0}
            </span>
          </div>
          <span className="text-[10px] text-muted-foreground">Use Cases</span>
        </div>
      </div>

      {/* RAG Status Icons */}
      <div className="flex items-center justify-between text-xs border-t border-border/50 pt-2 mb-2">
        <div className="flex items-center gap-2">
          {/* Technical Readiness */}
          <Tooltip>
            <TooltipTrigger asChild>
              <div className={cn(
                "flex items-center gap-1 px-1.5 py-0.5 rounded",
                (stats?.technicalReadinessPercent ?? 0) >= 70 ? 'bg-green-500/20 text-green-600' :
                (stats?.technicalReadinessPercent ?? 0) >= 40 ? 'bg-amber-500/20 text-amber-600' :
                (stats?.technicalReadinessPercent ?? 0) > 0 ? 'bg-red-500/20 text-red-600' :
                'bg-muted text-muted-foreground'
              )}>
                <ClipboardCheck className="w-3 h-3" />
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Technical Readiness: {stats?.technicalReadinessPercent ?? 0}%</p>
            </TooltipContent>
          </Tooltip>

          {/* Metrics */}
          <Tooltip>
            <TooltipTrigger asChild>
              <div className={cn(
                "flex items-center gap-1 px-1.5 py-0.5 rounded",
                stats?.metricsStatus === 'green' ? 'bg-green-500/20 text-green-600' :
                stats?.metricsStatus === 'amber' ? 'bg-amber-500/20 text-amber-600' :
                stats?.metricsStatus === 'red' ? 'bg-red-500/20 text-red-600' :
                'bg-muted text-muted-foreground'
              )}>
                <BarChart3 className="w-3 h-3" />
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Business Metrics: {stats?.metricsCount ?? 0} captured</p>
            </TooltipContent>
          </Tooltip>

          {/* Economic Buyer */}
          <Tooltip>
            <TooltipTrigger asChild>
              <div className={cn(
                "flex items-center gap-1 px-1.5 py-0.5 rounded",
                stats?.economicBuyerStatus === 'green' ? 'bg-green-500/20 text-green-600' :
                stats?.economicBuyerStatus === 'amber' ? 'bg-amber-500/20 text-amber-600' :
                stats?.economicBuyerStatus === 'red' ? 'bg-red-500/20 text-red-600' :
                'bg-muted text-muted-foreground'
              )}>
                <UserCheck className="w-3 h-3" />
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>{stats?.hasEconomicBuyer ? 'Economic buyer identified' : 'No economic buyer identified'}</p>
            </TooltipContent>
          </Tooltip>
        </div>

        <div className="flex items-center gap-3 text-muted-foreground">
          <div className="flex items-center gap-1" title="Technologies">
            <Layers className="w-3 h-3" />
            <span>{stats?.technologiesCount ?? 0}</span>
          </div>
          <div className="flex items-center gap-1" title="Open NBAs">
            <CheckCircle2 className="w-3 h-3" />
            <span>{stats?.openNbasCount ?? 0}</span>
          </div>
          <div className="flex items-center gap-1" title="Contacts">
            <Users className="w-3 h-3" />
            <span>{stats?.contactsCount ?? 0}</span>
          </div>
        </div>
      </div>

      {/* ARR Row - show stats.currentArr if available, fallback to account.arr */}
      {((stats?.currentArr ?? 0) > 0 || account.arr) && (
        <div className="flex items-center justify-between text-xs border-t border-border/50 pt-2">
          <span className="text-muted-foreground">Booked ARR</span>
          <span className="font-semibold text-green-600 dark:text-green-400">
            {formatCompactCurrency(stats?.currentArr ?? account.arr ?? 0)}
          </span>
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between mt-2 pt-2 border-t border-border/50">
        <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
          <Calendar className="w-3 h-3" />
          Updated {new Date(account.updated_at).toLocaleDateString()}
        </div>
        {account.stage && (
          <span className={cn(
            "px-2 py-0.5 rounded-full text-[10px] font-medium capitalize",
            accountTypeColors[account.stage] || accountTypeColors.prospect
          )}>
            {account.stage}
          </span>
        )}
      </div>
    </div>
    </TooltipProvider>
  );
}

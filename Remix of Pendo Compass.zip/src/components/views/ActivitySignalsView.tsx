import { useState, useMemo, useCallback } from 'react';
import { NewThisWeekTab } from '@/components/views/NewThisWeekTab';
import { Link } from 'react-router-dom';
import { useActivitySignalStats, ActivitySignalMatch, NewSignal, DynamicSignalType } from '@/hooks/useActivitySignals';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { CEPTimelineTab } from '@/components/cep/CEPTimelineTab';
import { SalesforceIcon } from '@/components/icons/SalesforceIcon';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Target,
  Sparkles,
  Calendar as CalendarIcon,
  Building2,
  AlertCircle,
  User,
  Users,
  GitBranch,
  Filter,
  ChevronDown,
  X,
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

const SALESFORCE_BASE_URL = 'https://pendo.lightning.force.com/lightning/r/Opportunity';

// Define ordered stages with proper display names
const STAGE_ORDER = [
  'Discovery',
  'Demo',
  'Proof - Scoping',
  'Proof',
  'Technical Win',
  'Technical Loss',
];

const STAGE_COLORS: Record<string, string> = {
  'Discovery': '#6366F1',
  'Demo': '#0EA5E9',
  'Proof - Scoping': '#F59E0B',
  'Proof': '#8B5CF6',
  'Technical Win': '#10B981',
  'Technical Loss': '#EF4444',
};

// Normalize stage names for consistent display
const normalizeStage = (stage: string | null): string => {
  if (!stage) return 'Unknown';
  const lower = stage.toLowerCase().trim();
  if (lower === 'discovery') return 'Discovery';
  if (lower === 'demo') return 'Demo';
  if (lower === 'proof - scoping' || lower === 'proof-scoping' || lower === 'scoping') return 'Proof - Scoping';
  if (lower === 'proof' || lower === 'evaluation') return 'Proof';
  if (lower === 'technical win' || lower === 'technical-win' || lower === 'win') return 'Technical Win';
  if (lower === 'technical loss' || lower === 'technical-loss' || lower === 'loss') return 'Technical Loss';
  return stage.charAt(0).toUpperCase() + stage.slice(1);
};

function StatCard({ 
  title, 
  value, 
  color,
  subtitle,
  isActive,
  onClick,
}: { 
  title: string; 
  value: number; 
  color: string;
  subtitle?: string;
  isActive?: boolean;
  onClick?: () => void;
}) {
  return (
    <Card 
      className={cn(
        onClick && "cursor-pointer transition-all hover:shadow-md hover:border-primary/50",
        isActive && "ring-2 ring-primary ring-offset-2 ring-offset-background"
      )}
      onClick={onClick}
    >
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-3xl font-bold mt-1" style={{ color }}>{value}</p>
            {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
          </div>
          <div className="p-3 rounded-full" style={{ backgroundColor: `${color}20` }}>
            <Target className="h-6 w-6" style={{ color }} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function WeekOverWeekBadge({ change }: { change: number }) {
  if (change > 0) {
    return (
      <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20">
        <TrendingUp className="h-3 w-3 mr-1" />
        +{change}% vs last week
      </Badge>
    );
  } else if (change < 0) {
    return (
      <Badge variant="outline" className="bg-red-500/10 text-red-600 border-red-500/20">
        <TrendingDown className="h-3 w-3 mr-1" />
        {change}% vs last week
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="bg-muted text-muted-foreground">
      <Minus className="h-3 w-3 mr-1" />
      No change
    </Badge>
  );
}

function SpeakerBadge({ type, name }: { type: 'internal' | 'external' | 'unknown' | null; name?: string | null }) {
  if (!type || type === 'unknown') {
    return (
      <Badge variant="outline" className="text-xs text-muted-foreground">
        <User className="h-3 w-3 mr-1" />
        Unknown
      </Badge>
    );
  }
  
  if (type === 'internal') {
    return (
      <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-600 border-blue-500/20">
        <Users className="h-3 w-3 mr-1" />
        {name || 'Pendo Team'}
      </Badge>
    );
  }
  
  return (
    <Badge variant="outline" className="text-xs bg-green-500/10 text-green-600 border-green-500/20">
      <User className="h-3 w-3 mr-1" />
      {name || 'Customer'}
    </Badge>
  );
}

function SalesforceLink({ salesforceId }: { salesforceId: string | null }) {
  if (!salesforceId) return null;
  
  const url = `${SALESFORCE_BASE_URL}/${salesforceId}/view`;
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center p-1 rounded hover:bg-muted transition-colors shrink-0"
            onClick={(e) => e.stopPropagation()}
          >
            <SalesforceIcon className="h-4 w-4" />
          </a>
        </TooltipTrigger>
        <TooltipContent>
          <p>Open in Salesforce</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function SignalTypeFilter({
  signalTypes,
  selectedTypes,
  onSelectionChange,
}: {
  signalTypes: DynamicSignalType[];
  selectedTypes: string[];
  onSelectionChange: (types: string[]) => void;
}) {
  const [open, setOpen] = useState(false);

  const toggleType = (typeId: string) => {
    if (selectedTypes.includes(typeId)) {
      onSelectionChange(selectedTypes.filter(id => id !== typeId));
    } else {
      onSelectionChange([...selectedTypes, typeId]);
    }
  };

  const clearAll = () => {
    onSelectionChange([]);
  };

  return (
    <div className="flex items-center gap-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <Filter className="h-4 w-4" />
            Signal Types
            {selectedTypes.length > 0 && (
              <Badge variant="secondary" className="ml-1">
                {selectedTypes.length}
              </Badge>
            )}
            <ChevronDown className="h-3 w-3" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64 p-3 bg-background border z-50" align="start">
          <div className="space-y-2">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Filter by Signal Type</span>
              {selectedTypes.length > 0 && (
                <Button variant="ghost" size="sm" onClick={clearAll} className="h-6 px-2 text-xs">
                  Clear all
                </Button>
              )}
            </div>
            {signalTypes.map((type) => (
              <label
                key={type.id}
                className="flex items-center gap-2 cursor-pointer hover:bg-muted/50 p-2 rounded-md transition-colors"
              >
                <Checkbox
                  checked={selectedTypes.includes(type.id)}
                  onCheckedChange={() => toggleType(type.id)}
                />
                <div className="flex items-center gap-2 flex-1">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: type.color }}
                  />
                  <span className="text-sm">{type.name}</span>
                </div>
              </label>
            ))}
          </div>
        </PopoverContent>
      </Popover>
      
      {/* Active filter chips */}
      {selectedTypes.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {selectedTypes.map(typeId => {
            const type = signalTypes.find(t => t.id === typeId);
            if (!type) return null;
            return (
              <Badge 
                key={typeId} 
                variant="secondary"
                className="gap-1 pl-2"
                style={{ borderColor: type.color, backgroundColor: `${type.color}15` }}
              >
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: type.color }} />
                {type.name}
                <button
                  onClick={() => onSelectionChange(selectedTypes.filter(id => id !== typeId))}
                  className="ml-1 hover:bg-muted rounded-full p-0.5"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            );
          })}
        </div>
      )}
    </div>
  );
}

function NewSignalsList({ signals, signalTypes }: { signals: NewSignal[]; signalTypes: DynamicSignalType[] }) {
  if (signals.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
        <p>No new signals detected this week</p>
      </div>
    );
  }

  const getSignalColor = (ruleKey: string) => {
    const type = signalTypes.find(t => t.key === ruleKey);
    return type?.color || '#6B7280';
  };

  return (
    <ScrollArea className="h-[300px]">
      <div className="space-y-3">
        {signals.map((signal) => {
          const color = getSignalColor(signal.rule_key);
          return (
            <div 
              key={signal.id} 
              className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
            >
              <div className="p-2 rounded-full" style={{ backgroundColor: `${color}20` }}>
                <Target className="h-4 w-4" style={{ color }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <Link 
                    to={`/accounts/${signal.account_id}?tab=opportunities&opp=${signal.opportunity_id}`}
                    className="font-medium truncate text-primary hover:underline"
                  >
                    {signal.opportunity_name}
                  </Link>
                  <SalesforceLink salesforceId={signal.salesforce_opportunity_id} />
                  <Badge 
                    variant="secondary" 
                    className="text-xs shrink-0"
                    style={{ borderColor: color, color, backgroundColor: `${color}15` }}
                  >
                    {signal.rule_name.replace(' Signals', '')}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  <Link 
                    to={`/accounts/${signal.account_id}`}
                    className="flex items-center gap-1 hover:underline"
                  >
                    <Building2 className="h-3 w-3" />
                    <span className="truncate">{signal.account_name}</span>
                  </Link>
                </div>
                <div className="flex items-center gap-3 mt-2">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <CalendarIcon className="h-3 w-3" />
                    <span>{formatDistanceToNow(new Date(signal.first_detected_at), { addSuffix: true })}</span>
                  </div>
                  <SpeakerBadge type={signal.speaker_type} name={signal.speaker_name} />
                </div>
                {signal.matched_phrases.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {signal.matched_phrases.slice(0, 3).map((phrase, i) => (
                      <Badge key={i} variant="outline" className="text-xs">
                        "{phrase}"
                      </Badge>
                    ))}
                    {signal.matched_phrases.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{signal.matched_phrases.length - 3} more
                      </Badge>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </ScrollArea>
  );
}

export function ActivitySignalsView() {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedSignalTypes, setSelectedSignalTypes] = useState<string[]>([]);
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date } | undefined>(undefined);
  
  const {
    signals,
    signalTypes,
    counts,
    stageBreakdown,
    weeklyTrends,
    monthlyTrends,
    newThisWeek,
    weekOverWeekChange,
    isLoading,
    error,
  } = useActivitySignalStats(
    selectedSignalTypes.length > 0 ? selectedSignalTypes : undefined,
    dateRange
  );

  // Prepare chart data with dynamic keys
  const chartData = useMemo(() => {
    return weeklyTrends.map(w => ({
      weekLabel: w.weekLabel,
      ...w.byType,
    }));
  }, [weeklyTrends]);

  const monthlyChartData = useMemo(() => {
    return monthlyTrends.map(m => ({
      monthLabel: m.monthLabel,
      ...m.byType,
    }));
  }, [monthlyTrends]);

  const pieData = useMemo(() => {
    return signalTypes
      .map(st => ({
        name: st.name,
        value: counts.byType[st.key] || 0,
        color: st.color,
      }))
      .filter(d => d.value > 0);
  }, [signalTypes, counts]);

  const stageChartData = useMemo(() => {
    return stageBreakdown.map(s => ({
      stage: s.stage,
      ...s.byType,
      total: s.total,
    }));
  }, [stageBreakdown]);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full" />
        <div className="text-center">
          <p className="text-sm font-medium text-muted-foreground">Loading Activity Signals...</p>
          <p className="text-xs text-muted-foreground mt-1">Fetching detection rules and matches</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="border-destructive">
        <CardContent className="pt-6">
          <div className="flex items-center gap-2 text-destructive">
            <AlertCircle className="h-5 w-5" />
            <span>Failed to load activity signals</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Activity Signals</h1>
          <p className="text-muted-foreground">
            Track evaluation, demo, and POC discussions across opportunities
          </p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          {/* Date Range Filter */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2">
                <CalendarIcon className="h-4 w-4" />
                {dateRange
                  ? `${format(dateRange.from, 'MMM d')} – ${format(dateRange.to, 'MMM d, yyyy')}`
                  : 'All Time'}
                <ChevronDown className="h-3 w-3" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <div className="p-3 border-b space-y-1">
                <p className="text-sm font-medium">Date Range</p>
                <div className="flex flex-wrap gap-1">
                  {[
                    { label: 'All Time', value: undefined },
                    { label: '30 days', value: 30 },
                    { label: '60 days', value: 60 },
                    { label: '90 days', value: 90 },
                  ].map((preset) => (
                    <Button
                      key={preset.label}
                      variant={
                        (!dateRange && !preset.value) ? 'secondary' : 'ghost'
                      }
                      size="sm"
                      className="h-7 text-xs"
                      onClick={() => {
                        if (!preset.value) {
                          setDateRange(undefined);
                        } else {
                          const to = new Date();
                          const from = new Date();
                          from.setDate(from.getDate() - preset.value);
                          setDateRange({ from, to });
                        }
                      }}
                    >
                      {preset.label}
                    </Button>
                  ))}
                </div>
              </div>
              <Calendar
                mode="range"
                selected={dateRange ? { from: dateRange.from, to: dateRange.to } : undefined}
                onSelect={(range) => {
                  if (range?.from && range?.to) {
                    setDateRange({ from: range.from, to: range.to });
                  } else if (range?.from) {
                    setDateRange({ from: range.from, to: range.from });
                  }
                }}
                numberOfMonths={2}
                disabled={(date) => date > new Date()}
                className="p-3 pointer-events-auto"
              />
              {dateRange && (
                <div className="p-2 border-t flex justify-end">
                  <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setDateRange(undefined)}>
                    Clear
                  </Button>
                </div>
              )}
            </PopoverContent>
          </Popover>

          <SignalTypeFilter
            signalTypes={signalTypes}
            selectedTypes={selectedSignalTypes}
            onSelectionChange={setSelectedSignalTypes}
          />
          <WeekOverWeekBadge change={weekOverWeekChange} />
        </div>
      </div>

      {/* Summary Cards - Dynamic */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Opportunities with Signals"
          value={counts.total}
          color="hsl(var(--primary))"
          subtitle="Unique opportunities"
          isActive={selectedSignalTypes.length === 0}
          onClick={() => setSelectedSignalTypes([])}
        />
        {signalTypes.slice(0, 3).map(st => (
          <StatCard
            key={st.id}
            title={st.name}
            value={counts.byType[st.key] || 0}
            color={st.color}
            subtitle="Detections"
            isActive={selectedSignalTypes.length === 1 && selectedSignalTypes[0] === st.id}
            onClick={() => {
              if (selectedSignalTypes.length === 1 && selectedSignalTypes[0] === st.id) {
                setSelectedSignalTypes([]);
              } else {
                setSelectedSignalTypes([st.id]);
              }
            }}
          />
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="cep-timeline" className="gap-1">
            <GitBranch className="w-4 h-4" />
            CEP Timeline
          </TabsTrigger>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="by-stage">By Stage</TabsTrigger>
          <TabsTrigger value="new">New This Week ({newThisWeek.length})</TabsTrigger>
          <TabsTrigger value="all">All Signals ({signals.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="cep-timeline" className="mt-6">
          <CEPTimelineTab 
            externalSignalTypeFilter={selectedSignalTypes.length > 0 ? selectedSignalTypes : undefined}
            onSignalTypeFilterChange={setSelectedSignalTypes}
          />
        </TabsContent>

        <TabsContent value="overview" className="space-y-6 mt-6">
          {/* Weekly Trend Line Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Weekly Signal Trend</CardTitle>
              <CardDescription>Signal detections over the past 8 weeks</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="weekLabel" className="text-xs" />
                  <YAxis className="text-xs" />
                  <RechartsTooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }} 
                  />
                  <Legend />
                  {signalTypes.map(st => (
                    <Line 
                      key={st.id}
                      type="monotone" 
                      dataKey={st.key}
                      name={st.name}
                      stroke={st.color}
                      strokeWidth={3}
                      dot={{ fill: st.color, strokeWidth: 2, r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Weekly Bar Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Weekly Detection Volume</CardTitle>
                <CardDescription>New signal detections by week</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="weekLabel" className="text-xs" />
                    <YAxis className="text-xs" />
                    <RechartsTooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }} 
                    />
                    <Legend />
                    {signalTypes.map(st => (
                      <Bar 
                        key={st.id}
                        dataKey={st.key}
                        name={st.name}
                        fill={st.color}
                        radius={[4, 4, 0, 0]}
                      />
                    ))}
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Distribution Pie Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Signal Distribution</CardTitle>
                <CardDescription>Breakdown by signal type</CardDescription>
              </CardHeader>
              <CardContent>
                {pieData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={280}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        outerRadius={90}
                        innerRadius={55}
                        dataKey="value"
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                        labelLine={false}
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <RechartsTooltip />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-[280px] text-muted-foreground">
                    No signals detected yet
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* New This Week */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-yellow-500" />
                New This Week
              </CardTitle>
              <CardDescription>
                Signals first detected in the current week
              </CardDescription>
            </CardHeader>
            <CardContent>
              <NewSignalsList signals={newThisWeek} signalTypes={signalTypes} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 gap-6">
            {/* Monthly Trend Line Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Monthly Trend</CardTitle>
                <CardDescription>Signal detections over the past 6 months</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <LineChart data={monthlyChartData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="monthLabel" className="text-xs" />
                    <YAxis className="text-xs" />
                    <RechartsTooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }} 
                    />
                    <Legend />
                    {signalTypes.map(st => (
                      <Line 
                        key={st.id}
                        type="monotone" 
                        dataKey={st.key}
                        name={st.name}
                        stroke={st.color}
                        strokeWidth={2}
                        dot={{ fill: st.color }}
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Weekly Detail Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Weekly Detail</CardTitle>
                <CardDescription>Stacked view of weekly signal counts</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="weekLabel" className="text-xs" />
                    <YAxis className="text-xs" />
                    <RechartsTooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }} 
                    />
                    <Legend />
                    {signalTypes.map((st, idx) => (
                      <Bar 
                        key={st.id}
                        dataKey={st.key}
                        name={st.name}
                        stackId="a"
                        fill={st.color}
                        radius={idx === signalTypes.length - 1 ? [4, 4, 0, 0] : undefined}
                      />
                    ))}
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="by-stage" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Signals by Pre-Sales Stage</CardTitle>
              <CardDescription>
                Which stages have the most activity signal discussions
              </CardDescription>
            </CardHeader>
            <CardContent>
              {stageBreakdown.length > 0 ? (
                <>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={stageChartData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis type="number" className="text-xs" />
                      <YAxis dataKey="stage" type="category" width={120} className="text-xs" />
                      <RechartsTooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                        }} 
                      />
                      <Legend />
                      {signalTypes.map(st => (
                        <Bar 
                          key={st.id}
                          dataKey={st.key}
                          name={st.name}
                          fill={st.color}
                          radius={[0, 4, 4, 0]}
                        />
                      ))}
                    </BarChart>
                  </ResponsiveContainer>

                  <Table className="mt-6">
                    <TableHeader>
                      <TableRow>
                        <TableHead>Stage</TableHead>
                        {signalTypes.map(st => (
                          <TableHead key={st.id} className="text-right">{st.name}</TableHead>
                        ))}
                        <TableHead className="text-right">Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {stageBreakdown.map((row) => {
                        const stageColor = STAGE_COLORS[row.stage] || '#6B7280';
                        return (
                          <TableRow key={row.stage}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <div 
                                  className="w-3 h-3 rounded-full" 
                                  style={{ backgroundColor: stageColor }}
                                />
                                <span className="font-medium">{row.stage}</span>
                              </div>
                            </TableCell>
                            {signalTypes.map(st => {
                              const value = row.byType[st.key] || 0;
                              return (
                                <TableCell key={st.id} className="text-right">
                                  {value > 0 ? (
                                    <Badge variant="outline" style={{ borderColor: st.color, color: st.color }}>
                                      {value}
                                    </Badge>
                                  ) : (
                                    <span className="text-muted-foreground">-</span>
                                  )}
                                </TableCell>
                              );
                            })}
                            <TableCell className="text-right">
                              <span className="font-bold text-lg">{row.total}</span>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No stage breakdown available
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="new" className="mt-6">
          <NewThisWeekTab signals={newThisWeek} signalTypes={signalTypes} />
        </TabsContent>

        <TabsContent value="all" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>All Activity Signals</CardTitle>
              <CardDescription>
                Complete list of detected signals across all opportunities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Signal Type</TableHead>
                      <TableHead>Account</TableHead>
                      <TableHead>Opportunity</TableHead>
                      <TableHead>Stage</TableHead>
                      <TableHead>Speaker</TableHead>
                      <TableHead>First Detected</TableHead>
                      <TableHead>Matched Phrases</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {signals.map((signal) => {
                      const signalType = signalTypes.find(st => st.id === signal.rule_id);
                      const ruleColor = signalType?.color || '#6B7280';
                      const ruleName = signal.rule_name.replace(' Signals', '');
                      
                      return (
                        <TableRow key={signal.id}>
                          <TableCell>
                            <Badge 
                              variant="outline" 
                              style={{ borderColor: ruleColor, color: ruleColor, backgroundColor: `${ruleColor}15` }}
                            >
                              {ruleName}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Link 
                              to={`/accounts/${signal.account_id}`}
                              className="font-medium text-primary hover:underline flex items-center gap-1"
                            >
                              <Building2 className="h-3 w-3" />
                              {signal.account_name}
                            </Link>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Link 
                                to={`/accounts/${signal.account_id}?tab=opportunities&opp=${signal.opportunity_id}`}
                                className="hover:underline"
                              >
                                {signal.opportunity_name}
                              </Link>
                              <SalesforceLink salesforceId={signal.salesforce_opportunity_id} />
                            </div>
                          </TableCell>
                          <TableCell>
                            {(() => {
                              const normalizedStage = normalizeStage(signal.pre_sales_stage);
                              const stageColor = STAGE_COLORS[normalizedStage] || '#6B7280';
                              return (
                                <Badge 
                                  variant="outline" 
                                  className="font-medium"
                                  style={{ borderColor: stageColor, color: stageColor }}
                                >
                                  {normalizedStage}
                                </Badge>
                              );
                            })()}
                          </TableCell>
                          <TableCell>
                            <SpeakerBadge type={signal.speaker_type} name={signal.speaker_name} />
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {format(new Date(signal.first_detected_at), 'MMM d, yyyy')}
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1 max-w-[200px]">
                              {signal.matched_phrases.slice(0, 2).map((phrase, i) => (
                                <Badge key={i} variant="outline" className="text-xs">
                                  {phrase}
                                </Badge>
                              ))}
                              {signal.matched_phrases.length > 2 && (
                                <Badge variant="outline" className="text-xs">
                                  +{signal.matched_phrases.length - 2}
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

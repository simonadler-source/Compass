import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { 
  ChevronDown, 
  Database, 
  FileText, 
  Cpu, 
  ArrowRight, 
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Info
} from 'lucide-react';

interface DataSource {
  name: string;
  type: 'hardcoded' | 'database' | 'context' | 'request';
  location: string;
  itemCount?: number;
  items?: string[];
  passesUsed: string[];
  description?: string;
}

interface PassInfo {
  passKey: string;
  name: string;
  phase: 'sync' | 'async';
  dataSources: string[];
  outputs: string[];
  status?: 'complete' | 'pending' | 'failed' | 'skipped';
  tokensUsed?: { input: number; output: number };
}

interface AnalysisDebugPanelProps {
  transcriptReviewId?: string;
  extractedInsights?: Record<string, any>;
  enrichmentStatus?: string;
  analysisMetadata?: {
    contentType?: string;
    contentDensity?: string;
    truncated?: boolean;
    originalLength?: number;
    processedLength?: number;
    pipelineUsed?: string;
    tokensEstimate?: { input: number; output: number; total: number };
  };
}

// Static data source definitions
const DATA_SOURCES: DataSource[] = [
  {
    name: 'Pain Categories',
    type: 'hardcoded',
    location: 'prompt-library.ts:25-31',
    items: ['vendor_relationship', 'technical_limitations', 'operational_friction', 'resource_constraints', 'strategic_misalignment'],
    passesUsed: ['core_extraction'],
    description: 'Fixed taxonomy for categorizing pain types'
  },
  {
    name: 'Business Impacts',
    type: 'hardcoded',
    location: 'prompt-library.ts:34-39',
    items: ['revenue_enablement', 'cost_reduction', 'risk_mitigation', 'efficiency_gains'],
    passesUsed: ['core_extraction'],
    description: 'Outcomes if pain is solved'
  },
  {
    name: 'Business Themes',
    type: 'hardcoded',
    location: 'prompt-library.ts:42-51',
    items: ['operational_efficiency', 'customer_experience', 'revenue_growth', 'cost_reduction', 'compliance_risk', 'digital_transformation', 'data_insights', 'team_productivity'],
    passesUsed: ['core_extraction'],
    description: 'What use cases aim to accomplish'
  },
  {
    name: 'Stakeholder Types',
    type: 'hardcoded',
    location: 'FALLBACK_SCHEMAS.core_extraction',
    items: ['champion', 'economic_buyer', 'decision_criteria_owner', 'coach', 'blocker', 'end_user', 'unknown'],
    passesUsed: ['core_extraction'],
    description: 'MEDDIC stakeholder classification'
  },
  {
    name: 'Activity Signal Rules',
    type: 'database',
    location: 'detection_rules (tree: Activity Signals)',
    passesUsed: ['enrichment_detection'],
    description: 'User-defined rules for detecting sales activities'
  },
  {
    name: 'Pendo Product Rules',
    type: 'database',
    location: 'detection_rules (tree: Pendo Products)',
    passesUsed: ['product_detection'],
    description: 'Rules for detecting Pendo product mentions'
  },
  {
    name: 'Competitor Rules',
    type: 'database',
    location: 'detection_rules (tree: Competitors)',
    passesUsed: ['product_detection'],
    description: 'Rules for detecting competitor mentions'
  },
  {
    name: 'Readiness Questions',
    type: 'database',
    location: 'readiness_template_questions',
    passesUsed: ['enrichment_readiness'],
    description: 'Technical readiness assessment questions'
  },
  {
    name: 'Technology Repository',
    type: 'database',
    location: 'technology_repository (is_pendo_product / is_competitor)',
    passesUsed: ['enrichment_readiness'],
    description: 'Product names injected into prompts'
  },
  {
    name: 'Analysis Context',
    type: 'context',
    location: 'context-builder.ts',
    passesUsed: ['core_extraction', 'stage_assessment'],
    description: 'Recent meetings, open NBAs, stakeholder trends'
  },
  {
    name: 'Core Extraction Results',
    type: 'context',
    location: 'Pass 1 output',
    passesUsed: ['stage_assessment', 'enrichment_detection', 'enrichment_readiness'],
    description: 'Pain points, use cases, technologies from first pass'
  }
];

const PASSES: PassInfo[] = [
  {
    passKey: 'core_extraction',
    name: 'Core Extraction',
    phase: 'sync',
    dataSources: ['Pain Categories', 'Business Impacts', 'Business Themes', 'Stakeholder Types', 'Analysis Context'],
    outputs: ['technologies', 'people', 'nbas', 'painPoints', 'useCases', 'competitorMentions', 'contentTypeDetection']
  },
  {
    passKey: 'stage_assessment',
    name: 'Stage Assessment',
    phase: 'sync',
    dataSources: ['Core Extraction Results'],
    outputs: ['salesStageAssessment', 'preSalesStageAssessment', 'commercialInsights', 'operationalMetrics', 'discoveryQuestions']
  },
  {
    passKey: 'enrichment_detection',
    name: 'Activity Signal Detection',
    phase: 'async',
    dataSources: ['Activity Signal Rules', 'Core Extraction Results'],
    outputs: ['detectionRuleMatches (activity)', 'detectedDeploymentTypes']
  },
  {
    passKey: 'product_detection',
    name: 'Product Detection',
    phase: 'async',
    dataSources: ['Pendo Product Rules', 'Competitor Rules'],
    outputs: ['detectionRuleMatches (products)', 'product_mentions (via trigger)']
  },
  {
    passKey: 'enrichment_readiness',
    name: 'Readiness Extraction',
    phase: 'async',
    dataSources: ['Readiness Questions', 'Technology Repository', 'Core Extraction Results'],
    outputs: ['readinessAnswers', 'productMentions']
  }
];

export const AnalysisDebugPanel: React.FC<AnalysisDebugPanelProps> = ({
  transcriptReviewId,
  extractedInsights,
  enrichmentStatus,
  analysisMetadata
}) => {
  const [expandedSources, setExpandedSources] = useState<string[]>([]);

  const toggleSource = (name: string) => {
    setExpandedSources(prev => 
      prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name]
    );
  };

  const getSourceTypeIcon = (type: DataSource['type']) => {
    switch (type) {
      case 'hardcoded': return <FileText className="h-4 w-4 text-orange-500" />;
      case 'database': return <Database className="h-4 w-4 text-blue-500" />;
      case 'context': return <Cpu className="h-4 w-4 text-purple-500" />;
      case 'request': return <ArrowRight className="h-4 w-4 text-green-500" />;
    }
  };

  const getPassStatus = (passKey: string): 'complete' | 'pending' | 'failed' | 'skipped' => {
    if (!extractedInsights) return 'pending';
    
    // Check if this pass has produced output
    switch (passKey) {
      case 'core_extraction':
        return extractedInsights.technologies || extractedInsights.people ? 'complete' : 'pending';
      case 'stage_assessment':
        return extractedInsights.salesStageAssessment ? 'complete' : 'pending';
      case 'enrichment_detection':
      case 'product_detection':
        return extractedInsights.detectionRuleMatches?.length > 0 ? 'complete' : 
               enrichmentStatus === 'complete' ? 'skipped' : 'pending';
      case 'enrichment_readiness':
        return extractedInsights.readinessAnswers?.length > 0 ? 'complete' :
               enrichmentStatus === 'complete' ? 'skipped' : 'pending';
      default:
        return 'pending';
    }
  };

  const getStatusIcon = (status: 'complete' | 'pending' | 'failed' | 'skipped') => {
    switch (status) {
      case 'complete': return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'pending': return <Info className="h-4 w-4 text-muted-foreground" />;
      case 'failed': return <XCircle className="h-4 w-4 text-destructive" />;
      case 'skipped': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getOutputCount = (outputKey: string): number => {
    if (!extractedInsights) return 0;
    const value = extractedInsights[outputKey];
    if (Array.isArray(value)) return value.length;
    if (typeof value === 'object' && value !== null) return 1;
    return 0;
  };

  return (
    <Card className="border-dashed">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <Cpu className="h-4 w-4" />
          Analysis Pipeline Debug
          {analysisMetadata?.pipelineUsed && (
            <Badge variant="outline" className="ml-2 text-xs">
              {analysisMetadata.pipelineUsed}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="flow" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="flow">Data Flow</TabsTrigger>
            <TabsTrigger value="sources">Data Sources</TabsTrigger>
            <TabsTrigger value="outputs">Outputs</TabsTrigger>
            <TabsTrigger value="conflicts">Conflicts</TabsTrigger>
          </TabsList>
          
          <TabsContent value="flow" className="mt-4">
            <div className="space-y-3">
              {/* Sync Phase */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
                  <Badge variant="secondary">SYNC</Badge>
                  Real-time analysis
                </div>
                {PASSES.filter(p => p.phase === 'sync').map(pass => (
                  <div 
                    key={pass.passKey}
                    className="flex items-center gap-3 p-2 rounded-md border bg-muted/30"
                  >
                    {getStatusIcon(getPassStatus(pass.passKey))}
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium">{pass.name}</div>
                      <div className="text-xs text-muted-foreground truncate">
                        {pass.dataSources.join(' → ')}
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {pass.outputs.map(o => `${getOutputCount(o)}`).join('/')} items
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Async Phase */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
                  <Badge variant="outline">ASYNC</Badge>
                  Background enrichment
                  {enrichmentStatus && (
                    <Badge 
                      variant={enrichmentStatus === 'complete' ? 'default' : 'secondary'}
                      className="ml-2"
                    >
                      {enrichmentStatus}
                    </Badge>
                  )}
                </div>
                {PASSES.filter(p => p.phase === 'async').map(pass => (
                  <div 
                    key={pass.passKey}
                    className="flex items-center gap-3 p-2 rounded-md border bg-muted/30"
                  >
                    {getStatusIcon(getPassStatus(pass.passKey))}
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium">{pass.name}</div>
                      <div className="text-xs text-muted-foreground truncate">
                        {pass.dataSources.join(' → ')}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Metadata */}
              {analysisMetadata && (
                <div className="pt-2 border-t text-xs text-muted-foreground space-y-1">
                  <div className="flex justify-between">
                    <span>Content Type:</span>
                    <span className="font-mono">{analysisMetadata.contentType || 'unknown'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Density:</span>
                    <span className="font-mono">{analysisMetadata.contentDensity || 'unknown'}</span>
                  </div>
                  {analysisMetadata.truncated && (
                    <div className="flex justify-between text-yellow-600">
                      <span>Truncated:</span>
                      <span>{analysisMetadata.originalLength?.toLocaleString()} → {analysisMetadata.processedLength?.toLocaleString()} chars</span>
                    </div>
                  )}
                  {analysisMetadata.tokensEstimate && (
                    <div className="flex justify-between">
                      <span>Tokens:</span>
                      <span className="font-mono">~{analysisMetadata.tokensEstimate.total?.toLocaleString()}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="sources" className="mt-4">
            <ScrollArea className="h-[300px]">
              <div className="space-y-2">
                {DATA_SOURCES.map(source => (
                  <Collapsible 
                    key={source.name}
                    open={expandedSources.includes(source.name)}
                    onOpenChange={() => toggleSource(source.name)}
                  >
                    <CollapsibleTrigger className="w-full">
                      <div className="flex items-center gap-2 p-2 rounded-md border hover:bg-muted/50 transition-colors">
                        {getSourceTypeIcon(source.type)}
                        <div className="flex-1 text-left">
                          <div className="text-sm font-medium">{source.name}</div>
                          <div className="text-xs text-muted-foreground">{source.location}</div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {source.type}
                        </Badge>
                        <ChevronDown className={`h-4 w-4 transition-transform ${expandedSources.includes(source.name) ? 'rotate-180' : ''}`} />
                      </div>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="ml-6 mt-1 p-2 rounded-md bg-muted/30 text-xs space-y-2">
                        {source.description && (
                          <p className="text-muted-foreground">{source.description}</p>
                        )}
                        <div>
                          <span className="font-medium">Used in: </span>
                          {source.passesUsed.map(p => (
                            <Badge key={p} variant="secondary" className="mr-1 text-xs">{p}</Badge>
                          ))}
                        </div>
                        {source.items && (
                          <div>
                            <span className="font-medium">Values ({source.items.length}): </span>
                            <div className="mt-1 flex flex-wrap gap-1">
                              {source.items.map(item => (
                                <Badge key={item} variant="outline" className="text-xs font-mono">{item}</Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="outputs" className="mt-4">
            <ScrollArea className="h-[300px]">
              <div className="space-y-3">
                {extractedInsights ? (
                  <>
                    {/* Core outputs */}
                    <div className="space-y-1">
                      <div className="text-xs font-medium text-muted-foreground">Core Extraction</div>
                      <div className="grid grid-cols-2 gap-2">
                        {['technologies', 'people', 'nbas', 'painPoints', 'useCases', 'competitorMentions'].map(key => (
                          <div key={key} className="flex justify-between p-2 rounded border text-xs">
                            <span className="font-mono">{key}</span>
                            <Badge variant={getOutputCount(key) > 0 ? 'default' : 'secondary'}>
                              {getOutputCount(key)}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* Enrichment outputs */}
                    <div className="space-y-1">
                      <div className="text-xs font-medium text-muted-foreground">Enrichment</div>
                      <div className="grid grid-cols-2 gap-2">
                        {['detectionRuleMatches', 'detectedDeploymentTypes', 'readinessAnswers', 'productMentions'].map(key => (
                          <div key={key} className="flex justify-between p-2 rounded border text-xs">
                            <span className="font-mono truncate">{key}</span>
                            <Badge variant={getOutputCount(key) > 0 ? 'default' : 'secondary'}>
                              {getOutputCount(key)}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-sm text-muted-foreground text-center py-4">
                    No analysis data available
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="conflicts" className="mt-4">
            <ScrollArea className="h-[300px]">
              <div className="space-y-3">
                {/* Potential conflict warnings */}
                <div className="p-3 rounded-md border border-yellow-500/50 bg-yellow-500/10">
                  <div className="flex items-center gap-2 text-sm font-medium text-yellow-600">
                    <AlertTriangle className="h-4 w-4" />
                    Hardcoded vs. Database Taxonomies
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Pain categories, business themes, and stakeholder types are hardcoded in prompt-library.ts. 
                    New values added to detection rules will not be recognized by Pass 1 schema validation.
                  </p>
                </div>
                
                <div className="p-3 rounded-md border border-blue-500/50 bg-blue-500/10">
                  <div className="flex items-center gap-2 text-sm font-medium text-blue-600">
                    <Info className="h-4 w-4" />
                    Product Detection Sync
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Products in technology_repository auto-create detection rules via trigger. 
                    Detection matches sync to product_mentions via database trigger. 
                    Both Pass 3b and Pass 4 can create product mentions.
                  </p>
                </div>
                
                <div className="p-3 rounded-md border border-purple-500/50 bg-purple-500/10">
                  <div className="flex items-center gap-2 text-sm font-medium text-purple-600">
                    <Database className="h-4 w-4" />
                    Functional Areas vs. Business Themes
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    functional_areas (database) and BUSINESS_THEMES (hardcoded) are independent taxonomies 
                    with no automatic mapping. Use cases are tagged with themes but not functional areas.
                  </p>
                </div>
                
                {/* Signal uniqueness info */}
                <div className="p-3 rounded-md border bg-muted/30">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Signal Uniqueness
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Each signal in detection_rule_matches is unique per transcript_id + rule_id. 
                    Upsert prevents duplicates. first_detected_at preserves original meeting date.
                  </p>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default AnalysisDebugPanel;

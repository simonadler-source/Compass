import React, { useState } from 'react';
import { Plus, Star, Trash2, Copy, Pencil, Check, X, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import {
  ReadinessApp,
} from '@/hooks/useOpportunityReadiness';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';

interface AppScopedCategorySectionProps {
  apps: ReadinessApp[];
  onCreateApp: (name: string, isPrimary: boolean) => Promise<ReadinessApp>;
  onDeleteApp: (appId: string) => Promise<void>;
  onUpdateApp: (appId: string, name: string) => Promise<void>;
  onCopyAppAnswers: (sourceAppId: string, targetAppId: string) => Promise<void>;
  /** Render the full question list for a given appId */
  renderQuestionsForApp: (appId: string) => React.ReactNode;
}

export function AppScopedCategorySection({
  apps,
  onCreateApp,
  onDeleteApp,
  onUpdateApp,
  onCopyAppAnswers,
  renderQuestionsForApp,
}: AppScopedCategorySectionProps) {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newAppName, setNewAppName] = useState('');
  const [editingAppId, setEditingAppId] = useState<string | null>(null);
  const [editingAppName, setEditingAppName] = useState('');
  const [copySourceId, setCopySourceId] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const handleAddApp = async () => {
    if (!newAppName.trim()) return;
    setIsCreating(true);
    try {
      const isPrimary = apps.length === 0;
      await onCreateApp(newAppName.trim(), isPrimary);
      setNewAppName('');
      setShowAddDialog(false);
      toast({ title: 'App added', description: `"${newAppName.trim()}" has been added` });
    } catch (error) {
      toast({ title: 'Failed to add app', variant: 'destructive' });
    } finally {
      setIsCreating(false);
    }
  };

  const handleCopyAnswers = async (targetAppId: string) => {
    if (!copySourceId) return;
    try {
      await onCopyAppAnswers(copySourceId, targetAppId);
      setCopySourceId(null);
      toast({ title: 'Answers copied' });
    } catch (error) {
      toast({ title: 'Failed to copy answers', variant: 'destructive' });
    }
  };

  const handleSaveAppName = async (appId: string) => {
    if (!editingAppName.trim()) return;
    try {
      await onUpdateApp(appId, editingAppName.trim());
      setEditingAppId(null);
      toast({ title: 'App renamed' });
    } catch (error) {
      toast({ title: 'Failed to rename app', variant: 'destructive' });
    }
  };

  if (apps.length === 0) {
    return (
      <div className="p-6 text-center space-y-3">
        <p className="text-sm text-muted-foreground">
          No applications configured yet. Add your first application to track app-specific readiness.
        </p>
        <Button onClick={() => setShowAddDialog(true)} variant="outline" className="gap-2">
          <Plus className="w-4 h-4" />
          Add Application
        </Button>
        <AddAppDialog
          open={showAddDialog}
          onOpenChange={setShowAddDialog}
          appName={newAppName}
          onAppNameChange={setNewAppName}
          onSubmit={handleAddApp}
          isCreating={isCreating}
        />
      </div>
    );
  }

  const defaultTab = apps[0]?.id || '';

  return (
    <div className="space-y-2">
      <Tabs defaultValue={defaultTab}>
        <div className="flex items-center gap-2">
          <TabsList className="h-8">
            {apps.map(app => (
              <TabsTrigger key={app.id} value={app.id} className="text-xs gap-1.5 h-7 px-3">
                {app.is_primary && (
                  <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                )}
                {app.app_name}
              </TabsTrigger>
            ))}
          </TabsList>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 w-7 p-0"
                  onClick={() => setShowAddDialog(true)}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Add another application</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        {apps.map(app => (
          <TabsContent key={app.id} value={app.id} className="mt-3">
            {/* App actions bar */}
            <div className="flex items-center justify-between mb-3 pb-2 border-b">
              <div className="flex items-center gap-2">
                {editingAppId === app.id ? (
                  <div className="flex items-center gap-1">
                    <Input
                      value={editingAppName}
                      onChange={(e) => setEditingAppName(e.target.value)}
                      className="h-7 text-xs w-40"
                      autoFocus
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleSaveAppName(app.id);
                        if (e.key === 'Escape') setEditingAppId(null);
                      }}
                    />
                    <button onClick={() => handleSaveAppName(app.id)} className="p-1 text-green-600 hover:bg-green-50 rounded">
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => setEditingAppId(null)} className="p-1 text-muted-foreground hover:bg-muted rounded">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <span className="text-sm font-semibold text-foreground">{app.app_name}</span>
                )}
                {app.is_primary && (
                  <Badge variant="outline" className="text-[10px] h-5 gap-1 border-amber-500/50 text-amber-600">
                    <Star className="w-2.5 h-2.5 fill-amber-500" />
                    Primary
                  </Badge>
                )}
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-44">
                  <DropdownMenuItem onClick={() => {
                    setEditingAppId(app.id);
                    setEditingAppName(app.app_name);
                  }}>
                    <Pencil className="w-3.5 h-3.5 mr-2" />
                    Rename
                  </DropdownMenuItem>
                  {apps.length > 1 && (
                    <DropdownMenuItem onClick={() => setCopySourceId(app.id)}>
                      <Copy className="w-3.5 h-3.5 mr-2" />
                      Copy answers to…
                    </DropdownMenuItem>
                  )}
                  {!app.is_primary && (
                    <DropdownMenuItem
                      onClick={() => onDeleteApp(app.id)}
                      className="text-destructive focus:text-destructive"
                    >
                      <Trash2 className="w-3.5 h-3.5 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Copy target selector */}
            {copySourceId && copySourceId !== app.id && (
              <div className="flex items-center gap-2 p-2 mb-3 bg-primary/5 rounded-lg border border-primary/20">
                <Copy className="w-4 h-4 text-primary" />
                <span className="text-xs text-muted-foreground">
                  Copy from <strong>{apps.find(a => a.id === copySourceId)?.app_name}</strong> to <strong>{app.app_name}</strong>?
                </span>
                <Button size="sm" variant="default" className="h-6 text-xs ml-auto gap-1" onClick={() => handleCopyAnswers(app.id)}>
                  <Check className="w-3 h-3" />
                  Confirm
                </Button>
                <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={() => setCopySourceId(null)}>
                  Cancel
                </Button>
              </div>
            )}

            {/* Full question rendering with all features */}
            <div className="space-y-2">
              {renderQuestionsForApp(app.id)}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Cancel copy mode - shown when on the source tab */}
      {copySourceId && (
        <div className="flex items-center gap-2 p-2 bg-primary/5 rounded-lg border border-primary/20">
          <Copy className="w-4 h-4 text-primary" />
          <span className="text-xs text-muted-foreground">
            Select a target app tab to paste answers from <strong>{apps.find(a => a.id === copySourceId)?.app_name}</strong>
          </span>
          <Button size="sm" variant="ghost" className="h-6 text-xs ml-auto" onClick={() => setCopySourceId(null)}>
            Cancel
          </Button>
        </div>
      )}

      <AddAppDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        appName={newAppName}
        onAppNameChange={setNewAppName}
        onSubmit={handleAddApp}
        isCreating={isCreating}
      />
    </div>
  );
}

function AddAppDialog({
  open,
  onOpenChange,
  appName,
  onAppNameChange,
  onSubmit,
  isCreating,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  appName: string;
  onAppNameChange: (name: string) => void;
  onSubmit: () => void;
  isCreating: boolean;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add Application</DialogTitle>
          <DialogDescription>
            Add a new application to track its readiness separately.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <Input
            value={appName}
            onChange={(e) => onAppNameChange(e.target.value)}
            placeholder="e.g. Customer Portal, Admin Dashboard"
            autoFocus
            onKeyDown={(e) => {
              if (e.key === 'Enter') onSubmit();
            }}
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={onSubmit} disabled={!appName.trim() || isCreating}>
            {isCreating ? 'Adding...' : 'Add App'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

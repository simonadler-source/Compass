import { useState } from 'react';
import { useDrop } from 'react-dnd';
import { cn } from '@/lib/utils';
import { Technology, LayerType, LAYER_CONFIG, Account, COMMON_TECHNOLOGIES } from '@/types/architecture';
import { TechnologyChip } from '@/components/TechnologyChip';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Search, X, ChevronLeft, FileDown, Eye, EyeOff } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { ExportPlanDialog } from '@/components/dialogs/ExportPlanDialog';
import { useReferenceTechnologies, ReferenceTechnology } from '@/hooks/useReferenceArchitecture';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface ArchitectureCanvasProps {
  account: Account;
  onUpdateAccount: (account: Account) => void;
  onBack: () => void;
  embedded?: boolean;
}

const layers: LayerType[] = ['host', 'build', 'adopt', 'growth', 'ops'];

const layerStyles: Record<LayerType, { bg: string; border: string; text: string }> = {
  host: { 
    bg: 'bg-layer-host-muted/30', 
    border: 'border-layer-host/30',
    text: 'text-layer-host'
  },
  build: { 
    bg: 'bg-layer-build-muted/30', 
    border: 'border-layer-build/30',
    text: 'text-layer-build'
  },
  adopt: { 
    bg: 'bg-layer-adopt-muted/30', 
    border: 'border-layer-adopt/30',
    text: 'text-layer-adopt'
  },
  growth: { 
    bg: 'bg-layer-growth-muted/30', 
    border: 'border-layer-growth/30',
    text: 'text-layer-growth'
  },
  ops: { 
    bg: 'bg-layer-ops-muted/30', 
    border: 'border-layer-ops/30',
    text: 'text-layer-ops'
  },
};

interface GhostTechnology {
  id: string;
  name: string;
  category: string;
  integration_type: string | null;
  description: string | null;
}

function LayerRow({ 
  layer, 
  technologies, 
  ghostTechnologies,
  showGhosts,
  onDrop,
  onSelectTech,
  onRemoveTech,
  onAddFromGhost
}: { 
  layer: LayerType;
  technologies: Technology[];
  ghostTechnologies: GhostTechnology[];
  showGhosts: boolean;
  onDrop: (tech: Partial<Technology>) => void;
  onSelectTech: (tech: Technology) => void;
  onRemoveTech: (techId: string) => void;
  onAddFromGhost: (ghost: GhostTechnology) => void;
}) {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: 'technology',
    drop: (item: Technology) => onDrop(item),
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  }), [onDrop]);

  const config = LAYER_CONFIG[layer];
  const styles = layerStyles[layer];
  
  // Filter out ghosts that are already in the account
  const techNames = technologies.map(t => t.name.toLowerCase());
  const missingGhosts = ghostTechnologies.filter(g => !techNames.includes(g.name.toLowerCase()));

  return (
    <div
      ref={drop}
      className={cn(
        "rounded-xl border-2 p-4 transition-all duration-200 min-h-[100px]",
        styles.bg,
        styles.border,
        isOver && "ring-2 ring-primary ring-offset-2 ring-offset-background scale-[1.01]"
      )}
    >
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className={cn("font-semibold", styles.text)}>
            {config.label}
          </h3>
          <p className="text-xs text-muted-foreground">{config.description}</p>
        </div>
        <div className="flex items-center gap-2">
          {showGhosts && missingGhosts.length > 0 && (
            <Badge variant="outline" className="text-xs text-muted-foreground">
              {missingGhosts.length} missing
            </Badge>
          )}
          <span className="text-xs text-muted-foreground px-2 py-1 rounded-full bg-background/50">
            {technologies.length} systems
          </span>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {technologies.map(tech => (
          <div key={tech.id} className="relative group">
            <TechnologyChip 
              technology={tech}
              onSelect={onSelectTech}
              showDetails
              isDraggable={false}
            />
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRemoveTech(tech.id);
              }}
              className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
        
        {/* Ghost technologies from reference architecture */}
        {showGhosts && missingGhosts.map(ghost => (
          <Tooltip key={ghost.id}>
            <TooltipTrigger asChild>
              <button
                onClick={() => onAddFromGhost(ghost)}
                className={cn(
                  "px-3 py-1.5 rounded-lg border-2 border-dashed transition-all",
                  "text-muted-foreground/50 hover:text-muted-foreground",
                  "hover:border-primary/50 hover:bg-primary/5",
                  ghost.integration_type === 'core' && "border-layer-growth/30",
                  ghost.integration_type === 'recommended' && "border-layer-build/30",
                  ghost.integration_type === 'optional' && "border-border"
                )}
              >
                <span className="text-sm opacity-60">{ghost.name}</span>
                <Plus className="w-3 h-3 ml-1 inline opacity-0 group-hover:opacity-100" />
              </button>
            </TooltipTrigger>
            <TooltipContent>
              <p className="font-medium">{ghost.name}</p>
              <p className="text-xs text-muted-foreground">{ghost.category}</p>
              {ghost.description && (
                <p className="text-xs mt-1 max-w-[200px]">{ghost.description}</p>
              )}
              <p className="text-xs mt-1 text-primary">Click to add to account</p>
            </TooltipContent>
          </Tooltip>
        ))}
        
        {technologies.length === 0 && missingGhosts.length === 0 && (
          <p className="text-sm text-muted-foreground italic">
            Drag technologies here
          </p>
        )}
      </div>
    </div>
  );
}

export function ArchitectureCanvas({ account, onUpdateAccount, onBack, embedded }: ArchitectureCanvasProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTech, setSelectedTech] = useState<Technology | null>(null);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [showGhosts, setShowGhosts] = useState(true);
  
  // Fetch reference technologies
  const { data: referenceTechs } = useReferenceTechnologies();

  const filteredPalette = COMMON_TECHNOLOGIES.filter(tech =>
    tech.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tech.category?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Group reference techs by layer
  const refTechsByLayer = referenceTechs?.reduce((acc, tech) => {
    if (!acc[tech.layer]) acc[tech.layer] = [];
    acc[tech.layer].push({
      id: tech.id,
      name: tech.name,
      category: tech.category,
      integration_type: tech.integration_type,
      description: tech.description,
    });
    return acc;
  }, {} as Record<string, GhostTechnology[]>) || {};

  const handleDropToLayer = (layer: LayerType) => (droppedTech: Partial<Technology>) => {
    // Check if already exists
    const exists = account.technologies.find(t => t.name === droppedTech.name);
    if (exists) {
      // Update layer
      const updated = account.technologies.map(t =>
        t.id === exists.id ? { ...t, layer } : t
      );
      onUpdateAccount({ ...account, technologies: updated, updatedAt: new Date() });
    } else {
      // Add new
      const newTech: Technology = {
        id: uuidv4(),
        name: droppedTech.name!,
        layer,
        category: droppedTech.category || 'Unknown',
        status: 'active',
      };
      onUpdateAccount({
        ...account,
        technologies: [...account.technologies, newTech],
        updatedAt: new Date()
      });
    }
  };

  const handleRemoveTech = (techId: string) => {
    onUpdateAccount({
      ...account,
      technologies: account.technologies.filter(t => t.id !== techId),
      updatedAt: new Date()
    });
  };

  const handleAddFromGhost = (layer: LayerType) => (ghost: GhostTechnology) => {
    const newTech: Technology = {
      id: uuidv4(),
      name: ghost.name,
      layer,
      category: ghost.category,
      status: 'active',
    };
    onUpdateAccount({
      ...account,
      technologies: [...account.technologies, newTech],
      updatedAt: new Date()
    });
  };

  // Calculate whitespace stats
  const totalRefTechs = referenceTechs?.length || 0;
  const accountTechNames = account.technologies.map(t => t.name.toLowerCase());
  const matchedCount = referenceTechs?.filter(r => accountTechNames.includes(r.name.toLowerCase())).length || 0;
  const coveragePercent = totalRefTechs > 0 ? Math.round((matchedCount / totalRefTechs) * 100) : 0;

  return (
    <div className="flex h-full animate-fade-in">
      {/* Left: Architecture Layers */}
      <div className="flex-1 p-6 overflow-auto">
        {!embedded && (
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="page-heading">{account.name}</h1>
                <p className="text-muted-foreground">Technical Architecture Map</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={showGhosts ? "default" : "outline"}
                size="sm"
                onClick={() => setShowGhosts(!showGhosts)}
              >
                {showGhosts ? <Eye className="w-4 h-4 mr-2" /> : <EyeOff className="w-4 h-4 mr-2" />}
                {showGhosts ? 'Hide' : 'Show'} Whitespace
              </Button>
              <Button variant="outline" onClick={() => setShowExportDialog(true)}>
                <FileDown className="w-4 h-4 mr-2" />
                Export Plan
              </Button>
            </div>
          </div>
        )}

        {embedded && (
          <div className="flex items-center justify-between mb-4 px-2">
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="text-xs">
                {coveragePercent}% coverage
              </Badge>
              <span className="text-xs text-muted-foreground">
                {matchedCount} of {totalRefTechs} reference integrations
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={showGhosts ? "default" : "outline"}
                size="sm"
                onClick={() => setShowGhosts(!showGhosts)}
              >
                {showGhosts ? <Eye className="w-4 h-4 mr-1" /> : <EyeOff className="w-4 h-4 mr-1" />}
                {showGhosts ? 'Hide' : 'Show'} Whitespace
              </Button>
              <Button variant="outline" size="sm" onClick={() => setShowExportDialog(true)}>
                <FileDown className="w-4 h-4 mr-1" />
                Export
              </Button>
            </div>
          </div>
        )}

        <div className="space-y-4">
          {layers.map(layer => (
            <LayerRow
              key={layer}
              layer={layer}
              technologies={account.technologies.filter(t => t.layer === layer)}
              ghostTechnologies={refTechsByLayer[layer] || []}
              showGhosts={showGhosts}
              onDrop={handleDropToLayer(layer)}
              onSelectTech={setSelectedTech}
              onRemoveTech={handleRemoveTech}
              onAddFromGhost={handleAddFromGhost(layer)}
            />
          ))}
        </div>
      </div>

      {/* Right: Technology Palette */}
      <div className="w-80 border-l border-border bg-card/50 p-4 overflow-auto">
        <h2 className="font-semibold mb-4">Technology Palette</h2>
        
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search technologies..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="space-y-4">
          {layers.map(layer => {
            const techs = filteredPalette.filter(t => t.layer === layer);
            if (techs.length === 0) return null;
            
            return (
              <div key={layer}>
                <h3 className={cn(
                  "text-xs font-medium uppercase tracking-wider mb-2",
                  layerStyles[layer].text
                )}>
                  {LAYER_CONFIG[layer].label}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {techs.map((tech, i) => (
                    <TechnologyChip
                      key={`${tech.name}-${i}`}
                      technology={{
                        id: `palette-${tech.name}`,
                        name: tech.name!,
                        layer: tech.layer!,
                        category: tech.category!,
                      }}
                      size="sm"
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 pt-4 border-t border-border">
          <Button variant="outline" className="w-full">
            <Plus className="w-4 h-4" />
            Add Custom Technology
          </Button>
        </div>
      </div>

      {/* Technology Detail Panel */}
      {selectedTech && (
        <div className="w-80 border-l border-border bg-card p-4 animate-slide-in-right">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">{selectedTech.name}</h2>
            <Button variant="ghost" size="icon" onClick={() => setSelectedTech(null)}>
              <X className="w-4 h-4" />
            </Button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-xs text-muted-foreground">Category</label>
              <p className="font-medium">{selectedTech.category}</p>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Layer</label>
              <p className={cn("font-medium", layerStyles[selectedTech.layer].text)}>
                {LAYER_CONFIG[selectedTech.layer].label}
              </p>
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Owner</label>
              <Input 
                placeholder="e.g., IT Admin, Security Analyst"
                value={selectedTech.owner || ''}
                onChange={(e) => {
                  const updated = account.technologies.map(t =>
                    t.id === selectedTech.id ? { ...t, owner: e.target.value } : t
                  );
                  onUpdateAccount({ ...account, technologies: updated });
                  setSelectedTech({ ...selectedTech, owner: e.target.value });
                }}
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Version</label>
              <Input 
                placeholder="e.g., 2.5.1"
                value={selectedTech.version || ''}
                onChange={(e) => {
                  const updated = account.technologies.map(t =>
                    t.id === selectedTech.id ? { ...t, version: e.target.value } : t
                  );
                  onUpdateAccount({ ...account, technologies: updated });
                  setSelectedTech({ ...selectedTech, version: e.target.value });
                }}
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Security Model</label>
              <Input 
                placeholder="e.g., OAuth 2.0, SAML"
                value={selectedTech.securityModel || ''}
                onChange={(e) => {
                  const updated = account.technologies.map(t =>
                    t.id === selectedTech.id ? { ...t, securityModel: e.target.value } : t
                  );
                  onUpdateAccount({ ...account, technologies: updated });
                  setSelectedTech({ ...selectedTech, securityModel: e.target.value });
                }}
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Known Issues</label>
              <Input 
                placeholder="e.g., No tracking, poor engagement"
                value={selectedTech.issues || ''}
                onChange={(e) => {
                  const updated = account.technologies.map(t =>
                    t.id === selectedTech.id ? { ...t, issues: e.target.value } : t
                  );
                  onUpdateAccount({ ...account, technologies: updated });
                  setSelectedTech({ ...selectedTech, issues: e.target.value });
                }}
              />
            </div>
          </div>
        </div>
      )}

      <ExportPlanDialog
        open={showExportDialog}
        onOpenChange={setShowExportDialog}
        account={account}
      />
    </div>
  );
}

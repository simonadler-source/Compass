import { useState } from 'react';
import { Search, BookOpen, Building2, Edit2, Trash2, ChevronRight, Filter, TrendingUp, AlertCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useCustomerStories, useDeleteCustomerStory, useUpdateCustomerStory } from '@/hooks/useAccounts';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export function CustomerStoriesView() {
  const { data: stories, isLoading } = useCustomerStories();
  const deleteStory = useDeleteCustomerStory();
  const updateStory = useUpdateCustomerStory();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStory, setSelectedStory] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [industryFilter, setIndustryFilter] = useState<string>('all');

  // Get unique industries for filter
  const industries = [...new Set((stories as any[] | undefined)?.map(s => s.industry).filter(Boolean) || [])] as string[];

  // Filter stories
  const filteredStories = stories?.filter(story => {
    const matchesSearch = searchQuery === '' || 
      story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (story.accounts as any)?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (story.tags as string[] | null)?.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesStatus = statusFilter === 'all' || story.status === statusFilter;
    const matchesIndustry = industryFilter === 'all' || story.industry === industryFilter;

    return matchesSearch && matchesStatus && matchesIndustry;
  }) || [];

  const selectedStoryData = stories?.find(s => s.id === selectedStory);

  const handlePublish = async (id: string) => {
    await updateStory.mutateAsync({ id, status: 'published' });
  };

  const handleDelete = async (id: string) => {
    await deleteStory.mutateAsync(id);
    if (selectedStory === id) setSelectedStory(null);
  };

  return (
    <div className="flex h-full animate-fade-in">
      {/* Stories List */}
      <div className="w-96 border-r border-border p-6 overflow-auto flex flex-col">
        <div className="mb-6">
          <h1 className="page-heading">Customer Stories</h1>
          <p className="text-sm text-muted-foreground">Success stories from all accounts</p>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search stories..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-4">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="published">Published</SelectItem>
            </SelectContent>
          </Select>
          <Select value={industryFilter} onValueChange={setIndustryFilter}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Industry" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Industries</SelectItem>
              {industries.map(ind => (
                <SelectItem key={ind} value={ind!}>{ind}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Stories List */}
        <div className="space-y-3 flex-1 overflow-auto">
          {isLoading && (
            <>
              <Skeleton className="h-24 rounded-xl" />
              <Skeleton className="h-24 rounded-xl" />
              <Skeleton className="h-24 rounded-xl" />
            </>
          )}

          {!isLoading && filteredStories.map((story) => (
            <div
              key={story.id}
              onClick={() => setSelectedStory(story.id)}
              className={cn(
                "glass rounded-xl p-4 cursor-pointer transition-all hover:bg-muted/50",
                selectedStory === story.id && "ring-2 ring-primary"
              )}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                    <Building2 className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium text-sm">{(story.accounts as any)?.name || 'Unknown'}</h3>
                    <p className="text-xs text-muted-foreground">{story.industry}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Badge variant={story.status === 'published' ? 'default' : 'secondary'} className="text-xs">
                    {story.status}
                  </Badge>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </div>
              <p className="text-sm line-clamp-2">{story.title}</p>
              <div className="flex flex-wrap gap-1 mt-2">
                {(story.tags as string[] | null)?.slice(0, 2).map((tag, i) => (
                  <Badge key={i} variant="outline" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          ))}

          {!isLoading && filteredStories.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No customer stories found</p>
              <p className="text-sm mt-1">Generate stories from account pages</p>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="pt-4 border-t border-border mt-4">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>{stories?.length || 0} total stories</span>
            <span>{stories?.filter(s => s.status === 'published').length || 0} published</span>
          </div>
        </div>
      </div>

      {/* Story Detail */}
      <div className="flex-1 p-6 overflow-auto">
        {selectedStoryData ? (
          <div className="max-w-3xl space-y-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                  <Building2 className="w-4 h-4" />
                  {(selectedStoryData.accounts as any)?.name} • {selectedStoryData.industry}
                </div>
                <h1 className="page-heading">{selectedStoryData.title}</h1>
                <div className="flex flex-wrap gap-2 mt-3">
                  <Badge variant={selectedStoryData.status === 'published' ? 'default' : 'secondary'}>
                    {selectedStoryData.status}
                  </Badge>
                  {(selectedStoryData.tags as string[] | null)?.map((tag, i) => (
                    <Badge key={i} variant="outline">{tag}</Badge>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {selectedStoryData.status === 'draft' && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handlePublish(selectedStoryData.id)}
                  >
                    Publish
                  </Button>
                )}
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => handleDelete(selectedStoryData.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Technologies & Use Cases */}
            <div className="flex flex-wrap gap-2">
              {(selectedStoryData.technologies_used as string[] | null)?.map((tech, i) => (
                <Badge key={i} variant="outline" className="border-primary/50 text-primary">
                  {tech}
                </Badge>
              ))}
              {(selectedStoryData.use_cases as string[] | null)?.map((uc, i) => (
                <Badge key={i} variant="secondary">
                  {uc}
                </Badge>
              ))}
            </div>

            {/* Situation */}
            <div className="glass rounded-xl p-6">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-destructive/20 flex items-center justify-center">
                  <AlertCircle className="w-3 h-3 text-destructive" />
                </span>
                Situation
              </h3>
              <p className="text-muted-foreground whitespace-pre-wrap">{selectedStoryData.situation}</p>
              {selectedStoryData.situation_metrics && (
                <div className="bg-destructive/10 rounded-lg p-3 text-sm mt-3">
                  <strong>Key Metrics:</strong> {selectedStoryData.situation_metrics}
                </div>
              )}
            </div>

            {/* Behavior */}
            <div className="glass rounded-xl p-6">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                  <ArrowRight className="w-3 h-3 text-primary" />
                </span>
                Behavior (Solution)
              </h3>
              <p className="text-muted-foreground whitespace-pre-wrap">{selectedStoryData.behavior}</p>
            </div>

            {/* Impact */}
            <div className="glass rounded-xl p-6">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-layer-growth/20 flex items-center justify-center">
                  <TrendingUp className="w-3 h-3 text-layer-growth" />
                </span>
                Impact
              </h3>
              <p className="text-muted-foreground whitespace-pre-wrap">{selectedStoryData.impact}</p>
              
              {selectedStoryData.impact_metrics && Array.isArray(selectedStoryData.impact_metrics) && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-4">
                  {(selectedStoryData.impact_metrics as { metric: string; before: string; after: string }[]).map((m, i) => (
                    <div key={i} className="bg-layer-growth/10 rounded-lg p-3 text-center">
                      <p className="text-xs text-muted-foreground">{m.metric}</p>
                      <div className="flex items-center justify-center gap-2 mt-1">
                        <span className="text-sm line-through text-muted-foreground">{m.before}</span>
                        <ArrowRight className="w-3 h-3" />
                        <span className="text-sm font-bold text-layer-growth">{m.after}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="text-xs text-muted-foreground">
              Created {new Date(selectedStoryData.created_at).toLocaleDateString()} • 
              Updated {new Date(selectedStoryData.updated_at).toLocaleDateString()}
            </div>
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <BookOpen className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg">Select a story to view details</p>
              <p className="text-sm mt-1">Stories are generated from account pages</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

import { useState, useMemo, useEffect } from 'react';
import { Plus, ChevronRight, ChevronDown, Trash2, Edit, GitBranch, MessageCircleQuestion, Zap, Settings2, ToggleLeft, ToggleRight, CheckCircle2, XCircle, HelpCircle, Link2, Database, FileText, Sliders, Target, Code2, Copy, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { toast } from 'sonner';
import {
  useDetectionRuleTrees,
  useDetectionRules,
  useDetectionRuleDetails,
  useCreateRuleTree,
  useUpdateRuleTree,
  useDeleteRuleTree,
  useCreateRule,
  useUpdateRule,
  useDeleteRule,
  useUpsertRuleQuestion,
  useDeleteRuleQuestion,
  useUpsertRuleNBA,
  useDeleteRuleNBA,
  useReadinessQuestionsForMapping,
  useUpsertReadinessMapping,
  useDeleteReadinessMapping,
  useUpsertCaptureField,
  useDeleteCaptureField,
  useValidationTaskTemplates,
  DetectionRule,
  DetectionRuleTree,
} from '@/hooks/useDetectionRules';
import { useDeploymentTypes } from '@/hooks/useOpportunityReadiness';
import { RuleActionsPanel } from '@/components/RuleActionsPanel';
import { useTreeTriageConfig, useUpsertTreeTriageConfig } from '@/hooks/useTreeTriageConfig';

// Example phrases that would trigger or not trigger a rule
const DONT_KNOW_PHRASES = [
  "I don't know",
  "I'm not sure",
  "we haven't decided",
  "still evaluating",
  "need to check",
  "let me get back to you",
  "TBD",
  "not sure yet",
  "unclear",
];

export function DetectionRulesView() {
  const [selectedTreeId, setSelectedTreeId] = useState<string | null>(null);
  const [selectedRuleId, setSelectedRuleId] = useState<string | null>(null);
  const [expandedRules, setExpandedRules] = useState<Set<string>>(new Set());
  
  // Dialog states
  const [treeDialogOpen, setTreeDialogOpen] = useState(false);
  const [editingTree, setEditingTree] = useState<DetectionRuleTree | null>(null);
  const [ruleDialogOpen, setRuleDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<DetectionRule | null>(null);
  const [parentRuleId, setParentRuleId] = useState<string | null>(null);
  const [deleteTreeId, setDeleteTreeId] = useState<string | null>(null);
  const [deleteRuleId, setDeleteRuleId] = useState<string | null>(null);
  const [readinessMappingDialogOpen, setReadinessMappingDialogOpen] = useState(false);
  
  // Form states
  const [treeName, setTreeName] = useState('');
  const [treeDescription, setTreeDescription] = useState('');
  const [treeDeploymentType, setTreeDeploymentType] = useState<string>('');
  const [ruleName, setRuleName] = useState('');
  const [ruleDescription, setRuleDescription] = useState('');
  const [ruleTriggerPhrases, setRuleTriggerPhrases] = useState('');
  const [ruleContextQualifiers, setRuleContextQualifiers] = useState('');
  const [ruleExclusionPhrases, setRuleExclusionPhrases] = useState('');
  const [ruleConfirmationPatterns, setRuleConfirmationPatterns] = useState('');
  const [ruleDetectionIntent, setRuleDetectionIntent] = useState<'discussed' | 'implemented' | 'planned' | 'blocked'>('discussed');
  const [ruleConfidence, setRuleConfidence] = useState('0.7');
  const [ruleSpeakerContext, setRuleSpeakerContext] = useState<'any' | 'internal_only' | 'external_only'>('any');
  // Legacy signal field states are now managed via Actions tab
  
  // New question/NBA states
  const [newQuestionText, setNewQuestionText] = useState('');
  const [newNBAText, setNewNBAText] = useState('');
  const [newNBAPriority, setNewNBAPriority] = useState('medium');
  
  // Readiness mapping states
  const [selectedReadinessQuestion, setSelectedReadinessQuestion] = useState<string>('');
  const [autoAnswerValue, setAutoAnswerValue] = useState('');
  
  // Capture field states
  const [newCaptureFieldName, setNewCaptureFieldName] = useState('');
  const [newCaptureFieldType, setNewCaptureFieldType] = useState('text');
  const [newCaptureFieldDescription, setNewCaptureFieldDescription] = useState('');
  const [newCaptureFieldPrompt, setNewCaptureFieldPrompt] = useState('');
  
  // Trigger preview test
  const [triggerTestInput, setTriggerTestInput] = useState('');
  
  // Triage config states
  const [triageEnabled, setTriageEnabled] = useState(false);
  const [triageKeywords, setTriageKeywords] = useState('');
  const [triagePrompt, setTriagePrompt] = useState('');
  const [triageContextField, setTriageContextField] = useState('');
  
  const { data: trees = [], isLoading: treesLoading } = useDetectionRuleTrees();
  const { data: rules = [], isLoading: rulesLoading } = useDetectionRules(selectedTreeId);
  const { data: ruleDetails, isLoading: detailsLoading } = useDetectionRuleDetails(selectedRuleId);
  const { data: deploymentTypes = [] } = useDeploymentTypes();
  const { data: readinessCategories = [] } = useReadinessQuestionsForMapping();
  const { data: validationTaskTemplates = [] } = useValidationTaskTemplates();
  const { data: triageConfig, isLoading: triageLoading } = useTreeTriageConfig(editingTree?.id || null);
  const upsertTriageConfig = useUpsertTreeTriageConfig();
  
  const createTree = useCreateRuleTree();
  const updateTree = useUpdateRuleTree();
  const deleteTree = useDeleteRuleTree();
  const createRule = useCreateRule();
  const updateRule = useUpdateRule();
  const deleteRule = useDeleteRule();
  const upsertQuestion = useUpsertRuleQuestion();
  const deleteQuestion = useDeleteRuleQuestion();
  const upsertNBA = useUpsertRuleNBA();
  const deleteNBA = useDeleteRuleNBA();
  const upsertReadinessMapping = useUpsertReadinessMapping();
  const deleteReadinessMapping = useDeleteReadinessMapping();
  const upsertCaptureField = useUpsertCaptureField();
  const deleteCaptureField = useDeleteCaptureField();
  
  const selectedTree = trees.find(t => t.id === selectedTreeId);
  
  // Populate triage config when editing a tree
  useEffect(() => {
    if (triageConfig && editingTree) {
      setTriageEnabled(triageConfig.triage_enabled);
      setTriageKeywords((triageConfig.triage_keywords || []).join(', '));
      setTriagePrompt(triageConfig.triage_prompt || '');
      setTriageContextField(triageConfig.triage_context_field || '');
    }
  }, [triageConfig, editingTree]);
  
  // Find parent rule for context (if selected rule is a child)
  const findParentRule = (parentId: string | null): DetectionRule | null => {
    if (!parentId || !rules.length) return null;
    const findInTree = (ruleList: DetectionRule[]): DetectionRule | null => {
      for (const r of ruleList) {
        if (r.id === parentId) return r;
        if (r.children?.length) {
          const found = findInTree(r.children);
          if (found) return found;
        }
      }
      return null;
    };
    return findInTree(rules);
  };
  
  // Generate AI prompt preview based on rule configuration
  // Generate the concise injection snippet for the analysis pipeline
  const generatedPrompt = useMemo(() => {
    if (!ruleDetails?.rule) return null;
    const rule = ruleDetails.rule;
    const parentRule = findParentRule(rule.parent_rule_id);
    
    // Build concise rule definition for pipeline injection
    const parts: string[] = [];
    
    // Rule identifier with parent context if applicable
    if (parentRule) {
      parts.push(`- "${rule.name}" (child of "${parentRule.name}")`);
    } else {
      parts.push(`- "${rule.name}"`);
    }
    
    // Trigger phrases inline
    parts.push(`  triggers: [${rule.trigger_phrases.map(p => `"${p}"`).join(', ')}]`);
    
    // Context qualifiers if any
    if (rule.context_qualifiers?.length) {
      parts.push(`  context: [${rule.context_qualifiers.map(p => `"${p}"`).join(', ')}]`);
    }
    
    // Exclusions if any
    if (rule.exclusion_phrases?.length) {
      parts.push(`  exclude: [${rule.exclusion_phrases.map(p => `"${p}"`).join(', ')}]`);
    }
    
    // Confirmation patterns for implemented intent
    if (rule.confirmation_patterns?.length && rule.detection_intent === 'implemented') {
      parts.push(`  confirm: [${rule.confirmation_patterns.map(p => `"${p}"`).join(', ')}]`);
    }
    
    // Speaker and intent on same line
    const speakerLabel = rule.speaker_context === 'external_only' ? 'customer' : 
                         rule.speaker_context === 'internal_only' ? 'internal' : 'any';
    parts.push(`  intent: ${rule.detection_intent}, speaker: ${speakerLabel}, threshold: ${(rule.confidence_threshold * 100).toFixed(0)}%`);
    
    return parts.join('\n');
  }, [ruleDetails, rules]);

  const toggleExpand = (ruleId: string) => {
    setExpandedRules(prev => {
      const next = new Set(prev);
      if (next.has(ruleId)) {
        next.delete(ruleId);
      } else {
        next.add(ruleId);
      }
      return next;
    });
  };
  
  const openTreeDialog = (tree?: DetectionRuleTree) => {
    if (tree) {
      setEditingTree(tree);
      setTreeName(tree.name);
      setTreeDescription(tree.description || '');
      setTreeDeploymentType(tree.deployment_type_id || 'none');
      // Triage will be populated by useEffect when triageConfig loads
    } else {
      setEditingTree(null);
      setTreeName('');
      setTreeDescription('');
      setTreeDeploymentType('none');
      setTriageEnabled(false);
      setTriageKeywords('');
      setTriagePrompt('');
      setTriageContextField('');
    }
    setTreeDialogOpen(true);
  };
  
  const openRuleDialog = (parentId: string | null, rule?: DetectionRule) => {
    setParentRuleId(parentId);
    if (rule) {
      setEditingRule(rule);
      setRuleName(rule.name);
      setRuleDescription(rule.description || '');
      setRuleTriggerPhrases(rule.trigger_phrases.join(', '));
      setRuleContextQualifiers((rule.context_qualifiers || []).join(', '));
      setRuleExclusionPhrases((rule.exclusion_phrases || []).join(', '));
      setRuleConfirmationPatterns((rule.confirmation_patterns || []).join(', '));
      setRuleDetectionIntent(rule.detection_intent || 'discussed');
      setRuleConfidence(String(rule.confidence_threshold));
      setRuleSpeakerContext(rule.speaker_context || 'any');
      // Signal field is now managed via Actions tab
    } else {
      setEditingRule(null);
      setRuleName('');
      setRuleDescription('');
      setRuleTriggerPhrases('');
      setRuleContextQualifiers('');
      setRuleExclusionPhrases('');
      setRuleConfirmationPatterns('');
      setRuleDetectionIntent('discussed');
      setRuleConfidence('0.7');
      setRuleSpeakerContext('any');
      // Signal field is now managed via Actions tab
    }
    setRuleDialogOpen(true);
  };
  
  const handleSaveTree = async () => {
    if (!treeName.trim()) {
      toast.error('Name is required');
      return;
    }
    
    try {
      let treeId: string;
      if (editingTree) {
        await updateTree.mutateAsync({
          id: editingTree.id,
          name: treeName.trim(),
          description: treeDescription.trim() || null,
          deployment_type_id: treeDeploymentType === 'none' ? null : treeDeploymentType || null,
        });
        treeId = editingTree.id;
        toast.success('Rule tree updated');
      } else {
        const result = await createTree.mutateAsync({
          name: treeName.trim(),
          description: treeDescription.trim() || undefined,
          deployment_type_id: treeDeploymentType === 'none' ? undefined : treeDeploymentType || undefined,
        });
        treeId = result.id;
        setSelectedTreeId(result.id);
        toast.success('Rule tree created');
      }
      
      // Save triage config
      const parsedKeywords = triageKeywords.split(',').map(k => k.trim()).filter(Boolean);
      await upsertTriageConfig.mutateAsync({
        tree_id: treeId,
        name: treeName.trim(),
        description: treeDescription.trim() || null,
        triage_enabled: triageEnabled,
        triage_keywords: parsedKeywords,
        triage_prompt: triagePrompt.trim() || null,
        triage_context_field: triageContextField.trim() || null,
      });
      
      setTreeDialogOpen(false);
    } catch (error) {
      toast.error('Failed to save rule tree');
    }
  };
  
  const handleSaveRule = async () => {
    if (!ruleName.trim() || !selectedTreeId) {
      toast.error('Name is required');
      return;
    }
    
    const phrases = ruleTriggerPhrases.split(',').map(p => p.trim()).filter(Boolean);
    const contextQualifiers = ruleContextQualifiers.split(',').map(p => p.trim()).filter(Boolean);
    const exclusionPhrases = ruleExclusionPhrases.split(',').map(p => p.trim()).filter(Boolean);
    const confirmationPatterns = ruleConfirmationPatterns.split(',').map(p => p.trim()).filter(Boolean);
    
    try {
      if (editingRule) {
        await updateRule.mutateAsync({
          id: editingRule.id,
          treeId: selectedTreeId,
          name: ruleName.trim(),
          description: ruleDescription.trim() || undefined,
          trigger_phrases: phrases,
          context_qualifiers: contextQualifiers,
          exclusion_phrases: exclusionPhrases,
          confirmation_patterns: confirmationPatterns,
          detection_intent: ruleDetectionIntent,
          confidence_threshold: parseFloat(ruleConfidence),
          speaker_context: ruleSpeakerContext,
          // Signal field capture is now managed via detection_rule_actions
        });
        toast.success('Rule updated');
      } else {
        const result = await createRule.mutateAsync({
          tree_id: selectedTreeId,
          parent_rule_id: parentRuleId,
          name: ruleName.trim(),
          description: ruleDescription.trim() || undefined,
          trigger_phrases: phrases,
          context_qualifiers: contextQualifiers,
          exclusion_phrases: exclusionPhrases,
          confirmation_patterns: confirmationPatterns,
          detection_intent: ruleDetectionIntent,
          confidence_threshold: parseFloat(ruleConfidence),
          speaker_context: ruleSpeakerContext,
          // Signal field capture is now managed via detection_rule_actions
        });
        setSelectedRuleId(result.id);
        if (parentRuleId) {
          setExpandedRules(prev => new Set([...prev, parentRuleId]));
        }
        toast.success('Rule created');
      }
      setRuleDialogOpen(false);
    } catch (error) {
      toast.error('Failed to save rule');
    }
  };
  
  const handleDeleteTree = async () => {
    if (!deleteTreeId) return;
    try {
      await deleteTree.mutateAsync(deleteTreeId);
      if (selectedTreeId === deleteTreeId) {
        setSelectedTreeId(null);
        setSelectedRuleId(null);
      }
      toast.success('Rule tree deleted');
    } catch (error) {
      toast.error('Failed to delete rule tree');
    }
    setDeleteTreeId(null);
  };
  
  const handleDeleteRule = async () => {
    if (!deleteRuleId || !selectedTreeId) return;
    try {
      await deleteRule.mutateAsync({ id: deleteRuleId, treeId: selectedTreeId });
      if (selectedRuleId === deleteRuleId) {
        setSelectedRuleId(null);
      }
      toast.success('Rule deleted');
    } catch (error) {
      toast.error('Failed to delete rule');
    }
    setDeleteRuleId(null);
  };
  
  const handleAddQuestion = async () => {
    if (!newQuestionText.trim() || !selectedRuleId) return;
    try {
      await upsertQuestion.mutateAsync({
        rule_id: selectedRuleId,
        question_text: newQuestionText.trim(),
      });
      setNewQuestionText('');
      toast.success('Question added');
    } catch (error) {
      toast.error('Failed to add question');
    }
  };
  
  const handleAddNBA = async () => {
    if (!newNBAText.trim() || !selectedRuleId) return;
    try {
      await upsertNBA.mutateAsync({
        rule_id: selectedRuleId,
        action_text: newNBAText.trim(),
        priority: newNBAPriority,
      });
      setNewNBAText('');
      toast.success('NBA template added');
    } catch (error) {
      toast.error('Failed to add NBA');
    }
  };
  
  const handleToggleTreeActive = async (tree: DetectionRuleTree) => {
    try {
      await updateTree.mutateAsync({
        id: tree.id,
        is_active: !tree.is_active,
      });
      toast.success(tree.is_active ? 'Rule tree deactivated' : 'Rule tree activated');
    } catch (error) {
      toast.error('Failed to update rule tree');
    }
  };

  const handleAddReadinessMapping = async () => {
    if (!selectedReadinessQuestion || !selectedRuleId) return;
    try {
      await upsertReadinessMapping.mutateAsync({
        rule_id: selectedRuleId,
        readiness_question_id: selectedReadinessQuestion,
        auto_answer: autoAnswerValue || null,
      });
      setSelectedReadinessQuestion('');
      setAutoAnswerValue('');
      setReadinessMappingDialogOpen(false);
      toast.success('Readiness mapping added');
    } catch (error) {
      toast.error('Failed to add readiness mapping');
    }
  };

  const handleAddCaptureField = async () => {
    if (!newCaptureFieldName.trim() || !selectedRuleId) return;
    try {
      await upsertCaptureField.mutateAsync({
        rule_id: selectedRuleId,
        field_name: newCaptureFieldName.trim(),
        field_type: newCaptureFieldType,
        description: newCaptureFieldDescription.trim() || null,
        extraction_prompt: newCaptureFieldPrompt.trim() || null,
      });
      setNewCaptureFieldName('');
      setNewCaptureFieldType('text');
      setNewCaptureFieldDescription('');
      setNewCaptureFieldPrompt('');
      toast.success('Capture field added');
    } catch (error) {
      toast.error('Failed to add capture field');
    }
  };

  // Test if input would trigger the current rule
  const triggerTestResult = useMemo(() => {
    if (!triggerTestInput.trim() || !ruleDetails?.rule.trigger_phrases.length) {
      return null;
    }
    const inputLower = triggerTestInput.toLowerCase();
    const matchedPhrases = ruleDetails.rule.trigger_phrases.filter(phrase =>
      inputLower.includes(phrase.toLowerCase())
    );
    const isDontKnow = DONT_KNOW_PHRASES.some(phrase =>
      inputLower.includes(phrase.toLowerCase())
    );
    return {
      triggered: matchedPhrases.length > 0,
      matchedPhrases,
      isDontKnow,
    };
  }, [triggerTestInput, ruleDetails?.rule.trigger_phrases]);

  const renderRule = (rule: DetectionRule, depth = 0) => {
    const hasChildren = rule.children && rule.children.length > 0;
    const isExpanded = expandedRules.has(rule.id);
    const isSelected = selectedRuleId === rule.id;
    
    return (
      <div key={rule.id}>
        <div
          className={`flex items-center gap-2 px-2 py-1.5 rounded-md cursor-pointer hover:bg-muted/50 group ${isSelected ? 'bg-primary/10 border border-primary/20' : ''}`}
          style={{ paddingLeft: `${depth * 16 + 8}px` }}
          onClick={() => setSelectedRuleId(rule.id)}
        >
          {hasChildren ? (
            <button onClick={(e) => { e.stopPropagation(); toggleExpand(rule.id); }} className="p-0.5">
              {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
          ) : (
            <div className="w-5" />
          )}
          <GitBranch className="w-4 h-4 text-muted-foreground" />
          <span className="flex-1 text-sm truncate">{rule.name}</span>
          {rule.validation_task_template && (
            <span title={`Linked: ${rule.validation_task_template.activity}`}>
              <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
            </span>
          )}
          {!rule.is_active && <Badge variant="outline" className="text-xs">Inactive</Badge>}
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 opacity-0 group-hover:opacity-100"
            onClick={(e) => { e.stopPropagation(); openRuleDialog(rule.id); }}
          >
            <Plus className="w-3 h-3" />
          </Button>
        </div>
        {hasChildren && isExpanded && (
          <div>
            {rule.children!.map(child => renderRule(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };
  
  return (
    <div className="flex h-[calc(100vh-4rem)] gap-4 p-6">
      {/* Trees Panel */}
      <Card className="w-72 flex flex-col">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Rule Trees</CardTitle>
            <Button size="sm" variant="outline" onClick={() => openTreeDialog()}>
              <Plus className="w-4 h-4 mr-1" />
              New
            </Button>
          </div>
        </CardHeader>
        <CardContent className="flex-1 overflow-auto p-2">
          {treesLoading ? (
            <div className="text-sm text-muted-foreground p-2">Loading...</div>
          ) : trees.length === 0 ? (
            <div className="text-sm text-muted-foreground p-2">No rule trees yet</div>
          ) : (
            <div className="space-y-1">
              {trees.map(tree => (
                <div
                  key={tree.id}
                  className={`flex items-center gap-2 px-3 py-2 rounded-md cursor-pointer hover:bg-muted/50 group ${selectedTreeId === tree.id ? 'bg-primary/10 border border-primary/20' : ''}`}
                  onClick={() => { setSelectedTreeId(tree.id); setSelectedRuleId(null); }}
                >
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{tree.name}</div>
                    {tree.deployment_type && (
                      <div className="text-xs text-muted-foreground">{tree.deployment_type.name}</div>
                    )}
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleToggleTreeActive(tree); }}
                    className="opacity-0 group-hover:opacity-100"
                  >
                    {tree.is_active ? (
                      <ToggleRight className="w-5 h-5 text-green-500" />
                    ) : (
                      <ToggleLeft className="w-5 h-5 text-muted-foreground" />
                    )}
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); openTreeDialog(tree); }}
                    className="opacity-0 group-hover:opacity-100"
                  >
                    <Edit className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); setDeleteTreeId(tree.id); }}
                    className="opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Rules Tree Panel */}
      <Card className="w-80 flex flex-col">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">
              {selectedTree ? selectedTree.name : 'Select a Tree'}
            </CardTitle>
            {selectedTreeId && (
              <Button size="sm" variant="outline" onClick={() => openRuleDialog(null)}>
                <Plus className="w-4 h-4 mr-1" />
                Root Rule
              </Button>
            )}
          </div>
          {selectedTree?.description && (
            <CardDescription className="text-xs">{selectedTree.description}</CardDescription>
          )}
        </CardHeader>
        <CardContent className="flex-1 overflow-auto p-2">
          {!selectedTreeId ? (
            <div className="text-sm text-muted-foreground p-2">Select a rule tree to see its rules</div>
          ) : rulesLoading ? (
            <div className="text-sm text-muted-foreground p-2">Loading...</div>
          ) : rules.length === 0 ? (
            <div className="text-sm text-muted-foreground p-2">No rules yet. Add a root rule to start.</div>
          ) : (
            <div className="space-y-0.5">
              {rules.map(rule => renderRule(rule))}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Rule Details Panel */}
      <Card className="flex-1 flex flex-col">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">
            {ruleDetails?.rule ? ruleDetails.rule.name : 'Rule Details'}
          </CardTitle>
          {ruleDetails?.rule?.description && (
            <CardDescription className="text-xs">{ruleDetails.rule.description}</CardDescription>
          )}
        </CardHeader>
        <CardContent className="flex-1 overflow-auto">
          {!selectedRuleId ? (
            <div className="text-sm text-muted-foreground">Select a rule to see its details</div>
          ) : detailsLoading ? (
            <div className="text-sm text-muted-foreground">Loading...</div>
          ) : ruleDetails ? (
            <Tabs defaultValue="config" className="h-full">
              <TabsList className="mb-4">
                <TabsTrigger value="config">Detection</TabsTrigger>
                <TabsTrigger value="actions">Actions</TabsTrigger>
                <TabsTrigger value="preview">Test & Preview</TabsTrigger>
              </TabsList>
              
              <TabsContent value="config" className="space-y-6">
                {/* Trigger Phrases */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Settings2 className="w-4 h-4 text-muted-foreground" />
                    <h4 className="font-medium text-sm">Trigger Phrases</h4>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {ruleDetails.rule.trigger_phrases.length === 0 ? (
                      <span className="text-sm text-muted-foreground">No trigger phrases</span>
                    ) : (
                      ruleDetails.rule.trigger_phrases.map((phrase, i) => (
                        <Badge key={i} variant="secondary" className="text-xs">{phrase}</Badge>
                      ))
                    )}
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">
                    Confidence threshold: {(ruleDetails.rule.confidence_threshold * 100).toFixed(0)}%
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-2"
                    onClick={() => openRuleDialog(ruleDetails.rule.parent_rule_id, ruleDetails.rule)}
                  >
                    <Edit className="w-3 h-3 mr-1" />
                    Edit Rule
                  </Button>
                </div>
                
                <Separator />
                
                {/* Note: Signal capture and validation tasks are now managed via the Actions tab */}
                <div className="p-3 bg-muted/30 rounded-md border border-dashed">
                  <p className="text-xs text-muted-foreground">
                    <strong>Tip:</strong> Use the <span className="font-medium">Actions</span> tab to configure what happens when this rule matches — 
                    including creating validation tasks, extracting data, and generating NBAs.
                  </p>
                </div>
                
                {/* Discovery Questions */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <MessageCircleQuestion className="w-4 h-4 text-muted-foreground" />
                    <h4 className="font-medium text-sm">Discovery Questions</h4>
                  </div>
                  <div className="space-y-2">
                    {ruleDetails.questions.map(q => (
                      <div key={q.id} className="flex items-start gap-2 p-2 bg-muted/30 rounded text-sm">
                        <span className="flex-1">{q.question_text}</span>
                        {q.is_required && <Badge variant="outline" className="text-xs">Required</Badge>}
                        <button onClick={() => deleteQuestion.mutate({ id: q.id, ruleId: selectedRuleId! })}>
                          <Trash2 className="w-3.5 h-3.5 text-muted-foreground hover:text-destructive" />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-2">
                    <Input
                      placeholder="Add a question..."
                      value={newQuestionText}
                      onChange={(e) => setNewQuestionText(e.target.value)}
                      className="text-sm"
                      onKeyDown={(e) => e.key === 'Enter' && handleAddQuestion()}
                    />
                    <Button size="sm" onClick={handleAddQuestion} disabled={!newQuestionText.trim()}>
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <Separator />
                
                {/* NBA Templates */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="w-4 h-4 text-muted-foreground" />
                    <h4 className="font-medium text-sm">NBA Templates</h4>
                  </div>
                  <div className="space-y-2">
                    {ruleDetails.nbaTemplates.map(nba => (
                      <div key={nba.id} className="flex items-start gap-2 p-2 bg-muted/30 rounded text-sm">
                        <span className="flex-1">{nba.action_text}</span>
                        <Badge variant="outline" className="text-xs capitalize">{nba.priority}</Badge>
                        <button onClick={() => deleteNBA.mutate({ id: nba.id, ruleId: selectedRuleId! })}>
                          <Trash2 className="w-3.5 h-3.5 text-muted-foreground hover:text-destructive" />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-2">
                    <Input
                      placeholder="Add an NBA..."
                      value={newNBAText}
                      onChange={(e) => setNewNBAText(e.target.value)}
                      className="text-sm flex-1"
                      onKeyDown={(e) => e.key === 'Enter' && handleAddNBA()}
                    />
                    <Select value={newNBAPriority} onValueChange={setNewNBAPriority}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button size="sm" onClick={handleAddNBA} disabled={!newNBAText.trim()}>
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                {/* Add Child Rule */}
                <Separator />
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => openRuleDialog(selectedRuleId)}>
                    <Plus className="w-4 h-4 mr-1" />
                    Add Child Rule
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => setDeleteRuleId(selectedRuleId)}
                  >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Delete Rule
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="actions" className="space-y-4">
                <RuleActionsPanel
                  ruleId={selectedRuleId!}
                  actions={ruleDetails.actions || []}
                  readinessCategories={readinessCategories}
                  validationTaskTemplates={validationTaskTemplates as any[]}
                />
              </TabsContent>
              
              <TabsContent value="preview" className="space-y-4">
                {/* Trigger Test */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Settings2 className="w-4 h-4 text-muted-foreground" />
                    <h4 className="font-medium text-sm">Test Trigger Phrases</h4>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">
                    Enter sample text to see if it would trigger this rule.
                  </p>
                  <Textarea
                    placeholder="e.g., 'We're building an iOS app with Swift and need mobile analytics'"
                    value={triggerTestInput}
                    onChange={(e) => setTriggerTestInput(e.target.value)}
                    className="text-sm"
                    rows={3}
                  />
                  {triggerTestResult && (
                    <div className="mt-3 p-3 rounded-md border">
                      <div className="flex items-center gap-2 mb-2">
                        {triggerTestResult.triggered ? (
                          <>
                            <CheckCircle2 className="w-5 h-5 text-green-500" />
                            <span className="font-medium text-green-600">Rule would trigger</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-5 h-5 text-muted-foreground" />
                            <span className="font-medium text-muted-foreground">Rule would NOT trigger</span>
                          </>
                        )}
                      </div>
                      {triggerTestResult.triggered && triggerTestResult.matchedPhrases.length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-2">
                          <span className="text-xs text-muted-foreground">Matched:</span>
                          {triggerTestResult.matchedPhrases.map((p, i) => (
                            <Badge key={i} variant="default" className="text-xs">{p}</Badge>
                          ))}
                        </div>
                      )}
                      {triggerTestResult.isDontKnow && (
                        <div className="flex items-center gap-2 mt-2 p-2 bg-amber-500/10 rounded border border-amber-500/30">
                          <HelpCircle className="w-4 h-4 text-amber-500" />
                          <span className="text-xs text-amber-600">
                            "Don't know" response detected - consider creating a follow-up NBA
                          </span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
                
                <Separator />
                
                {/* Example Triggers */}
                <div>
                  <h4 className="font-medium text-sm mb-2">Example Responses</h4>
                  <div className="grid gap-2">
                    <div className="p-2 bg-green-500/10 border border-green-500/30 rounded text-sm">
                      <div className="flex items-center gap-2 mb-1">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                        <span className="font-medium text-green-600">Would Trigger</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {ruleDetails.rule.trigger_phrases.length > 0 
                          ? `"We're using ${ruleDetails.rule.trigger_phrases[0]} in our environment"`
                          : 'Add trigger phrases to see examples'}
                      </p>
                    </div>
                    <div className="p-2 bg-muted/50 border rounded text-sm">
                      <div className="flex items-center gap-2 mb-1">
                        <XCircle className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium text-muted-foreground">Would NOT Trigger</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        "We're still evaluating our options for this area"
                      </p>
                    </div>
                    <div className="p-2 bg-amber-500/10 border border-amber-500/30 rounded text-sm">
                      <div className="flex items-center gap-2 mb-1">
                        <HelpCircle className="w-4 h-4 text-amber-500" />
                        <span className="font-medium text-amber-600">"Don't Know" Response</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        "I'm not sure about that, let me get back to you" → Creates follow-up NBA
                      </p>
                    </div>
                  </div>
                </div>
                
                {/* Generated AI Prompt */}
                <Separator />
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Code2 className="w-4 h-4 text-muted-foreground" />
                      <h4 className="font-medium text-sm">Generated AI Prompt</h4>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <HelpCircle className="w-3.5 h-3.5 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent side="right" className="max-w-xs text-xs">
                          <p className="font-medium mb-1">AI Matching Behavior</p>
                          <ul className="space-y-1 text-muted-foreground">
                            <li>• <strong>Synonyms & plurals</strong> are handled automatically by the AI</li>
                            <li>• <strong>No wildcards (*)</strong> — add explicit variations instead</li>
                            <li>• <strong>For compound matches</strong> (e.g., "iFrame" + "application"), use Context Qualifiers</li>
                          </ul>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs"
                      onClick={() => {
                        if (generatedPrompt) {
                          navigator.clipboard.writeText(generatedPrompt);
                          toast.success('Prompt copied to clipboard');
                        }
                      }}
                    >
                      <Copy className="w-3 h-3 mr-1" />
                      Copy
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">
                    This snippet is injected into the analysis pipeline for this rule.
                    {ruleDetails.rule.parent_rule_id && (
                      <span className="ml-1 text-primary">
                        Includes parent rule context.
                      </span>
                    )}
                  </p>
                  <div className="bg-muted/50 border rounded-lg p-3 max-h-96 overflow-auto">
                    <pre className="text-xs font-mono whitespace-pre-wrap text-foreground/80">
                      {generatedPrompt || 'No prompt generated'}
                    </pre>
                  </div>
                </div>
                
                {/* Don't Know Detection Info */}
                <Separator />
                <div>
                  <h4 className="font-medium text-sm mb-2">Automatic "Don't Know" Detection</h4>
                  <p className="text-xs text-muted-foreground mb-2">
                    These phrases are automatically detected and flagged for follow-up:
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {DONT_KNOW_PHRASES.map((phrase, i) => (
                      <Badge key={i} variant="outline" className="text-xs">{phrase}</Badge>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          ) : null}
        </CardContent>
      </Card>
      
      {/* Tree Dialog */}
      <Dialog open={treeDialogOpen} onOpenChange={setTreeDialogOpen}>
        <DialogContent className="max-w-lg max-h-[85vh] flex flex-col overflow-hidden">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle>{editingTree ? 'Edit Rule Tree' : 'Create Rule Tree'}</DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto space-y-4 py-4 pr-2 min-h-0">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input value={treeName} onChange={(e) => setTreeName(e.target.value)} placeholder="e.g., Mobile Detection" />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea value={treeDescription} onChange={(e) => setTreeDescription(e.target.value)} placeholder="What does this rule tree detect?" />
            </div>
            <div className="space-y-2">
              <Label>Deployment Type (optional)</Label>
              <Select value={treeDeploymentType} onValueChange={setTreeDeploymentType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select deployment type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {deploymentTypes.map(dt => (
                    <SelectItem key={dt.id} value={dt.id}>{dt.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <Separator />
            
            {/* Triage / Gating Configuration */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-muted-foreground" />
                  <Label className="text-sm font-medium">Analysis Triage</Label>
                </div>
                <Switch checked={triageEnabled} onCheckedChange={setTriageEnabled} />
              </div>
              <p className="text-xs text-muted-foreground">
                When enabled, the analysis pipeline will check if this tree is relevant before running its rules — saving AI cost and time.
              </p>
              
              {triageEnabled && (
                <div className="space-y-3 pl-1 border-l-2 border-primary/20 ml-2">
                  <div className="space-y-2 pl-3">
                    <Label className="text-xs">Gate Keywords (comma-separated)</Label>
                    <Textarea
                      value={triageKeywords}
                      onChange={(e) => setTriageKeywords(e.target.value)}
                      placeholder="listen, gong, zendesk, feedback, survey"
                      className="h-16 text-sm"
                    />
                    <p className="text-xs text-muted-foreground">
                      Fast keyword scan — if none of these appear in the transcript, the tree is skipped entirely.
                    </p>
                  </div>
                  <div className="space-y-2 pl-3">
                    <Label className="text-xs">AI Triage Prompt</Label>
                    <Textarea
                      value={triagePrompt}
                      onChange={(e) => setTriagePrompt(e.target.value)}
                      placeholder="Is this transcript about a Pendo Listen evaluation? Answer YES or NO with one sentence of reasoning."
                      className="h-20 text-sm"
                    />
                    <p className="text-xs text-muted-foreground">
                      If keywords match, this prompt is sent to a cheap AI call for confirmation. The AI answers YES/NO.
                    </p>
                  </div>
                  <div className="space-y-2 pl-3">
                    <Label className="text-xs">Context Field (optional)</Label>
                    <Input
                      value={triageContextField}
                      onChange={(e) => setTriageContextField(e.target.value)}
                      placeholder="e.g., included_module_ids or relationship_status"
                      className="text-sm"
                    />
                    <p className="text-xs text-muted-foreground">
                      Opportunity field to check for additional context (future use).
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTreeDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveTree} disabled={createTree.isPending || updateTree.isPending}>
              {editingTree ? 'Save' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Rule Dialog */}
      <Dialog open={ruleDialogOpen} onOpenChange={setRuleDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle>{editingRule ? 'Edit Rule' : 'Create Rule'}</DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto pr-4 min-h-0">
            <Accordion type="multiple" defaultValue={['basic', 'detection']} className="space-y-2">
              {/* Basic Information */}
              <AccordionItem value="basic" className="border rounded-lg px-4">
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-primary" />
                    <span className="font-medium">Basic Information</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="space-y-4 pt-2 pb-4">
                  <div className="space-y-2">
                    <Label>Name</Label>
                    <Input value={ruleName} onChange={(e) => setRuleName(e.target.value)} placeholder="e.g., Demo Request Signal" />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea value={ruleDescription} onChange={(e) => setRuleDescription(e.target.value)} placeholder="What does this rule detect?" className="h-20" />
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Detection Configuration */}
              <AccordionItem value="detection" className="border rounded-lg px-4">
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-primary" />
                    <span className="font-medium">Detection Configuration</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="space-y-4 pt-2 pb-4">
                  <div className="space-y-2">
                    <Label>Trigger Phrases (comma-separated)</Label>
                    <Textarea
                      value={ruleTriggerPhrases}
                      onChange={(e) => setRuleTriggerPhrases(e.target.value)}
                      placeholder="schedule a demo, see a demo, demo request"
                      className="h-16"
                    />
                    <p className="text-xs text-muted-foreground">Phrases that trigger this rule when found in transcripts</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Context Qualifiers (comma-separated)</Label>
                    <Textarea
                      value={ruleContextQualifiers}
                      onChange={(e) => setRuleContextQualifiers(e.target.value)}
                      placeholder="interested, want to see, ready for"
                      className="h-16"
                    />
                    <p className="text-xs text-muted-foreground">Phrases that must appear NEAR trigger phrases to confirm intent</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Exclusion Phrases (comma-separated)</Label>
                    <Textarea
                      value={ruleExclusionPhrases}
                      onChange={(e) => setRuleExclusionPhrases(e.target.value)}
                      placeholder="already saw, previous demo"
                      className="h-16"
                    />
                    <p className="text-xs text-muted-foreground">Phrases that indicate a DIFFERENT intent - exclude the match if found</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Confirmation Patterns (comma-separated)</Label>
                    <Textarea
                      value={ruleConfirmationPatterns}
                      onChange={(e) => setRuleConfirmationPatterns(e.target.value)}
                      placeholder="yes, we have, it's working, we set up"
                      className="h-16"
                    />
                    <p className="text-xs text-muted-foreground">
                      For "implemented" intent: phrases the CUSTOMER must say to confirm completion
                    </p>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Behavior Settings */}
              <AccordionItem value="behavior" className="border rounded-lg px-4">
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-primary" />
                    <span className="font-medium">Behavior Settings</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="space-y-4 pt-2 pb-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Detection Intent</Label>
                      <Select value={ruleDetectionIntent} onValueChange={(v) => setRuleDetectionIntent(v as 'discussed' | 'implemented' | 'planned' | 'blocked')}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="discussed">Discussed (any mention)</SelectItem>
                          <SelectItem value="implemented">Implemented (confirmed complete)</SelectItem>
                          <SelectItem value="planned">Planned (future intent)</SelectItem>
                          <SelectItem value="blocked">Blocked (obstacle identified)</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">What type of signal to detect</p>
                    </div>
                    <div className="space-y-2">
                      <Label>Speaker Context</Label>
                      <Select value={ruleSpeakerContext} onValueChange={(v) => setRuleSpeakerContext(v as 'any' | 'internal_only' | 'external_only')}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="any">Anyone</SelectItem>
                          <SelectItem value="external_only">External Only (Customer)</SelectItem>
                          <SelectItem value="internal_only">Internal Only (Pendo)</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">Who must speak</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Confidence Threshold ({(parseFloat(ruleConfidence || '0.7') * 100).toFixed(0)}%)</Label>
                    <Input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={ruleConfidence}
                      onChange={(e) => setRuleConfidence(e.target.value)}
                    />
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Note: Signal Capture is now configured via the Actions tab with update_field action type */}
            </Accordion>
          </div>
          <DialogFooter className="mt-4 pt-4 border-t">
            <Button variant="outline" onClick={() => setRuleDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveRule} disabled={createRule.isPending || updateRule.isPending}>
              {editingRule ? 'Save' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete Tree Confirmation */}
      <AlertDialog open={!!deleteTreeId} onOpenChange={() => setDeleteTreeId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Rule Tree?</AlertDialogTitle>
            <AlertDialogDescription>
              This will delete the rule tree and all its rules. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteTree} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Delete Rule Confirmation */}
      <AlertDialog open={!!deleteRuleId} onOpenChange={() => setDeleteRuleId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Rule?</AlertDialogTitle>
            <AlertDialogDescription>
              This will delete the rule and all its child rules. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteRule} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Readiness Mapping Dialog */}
      <Dialog open={readinessMappingDialogOpen} onOpenChange={setReadinessMappingDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Link Readiness Question</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Select Question</Label>
              <Select value={selectedReadinessQuestion} onValueChange={setSelectedReadinessQuestion}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a readiness question" />
                </SelectTrigger>
                <SelectContent>
                  {readinessCategories.map((cat: any) => (
                    <div key={cat.id}>
                      <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-muted/50">
                        {cat.name} {cat.deployment_type?.name && `(${cat.deployment_type.name})`}
                      </div>
                      {cat.questions?.map((q: any) => (
                        <SelectItem key={q.id} value={q.id} className="pl-4">
                          {q.question}
                        </SelectItem>
                      ))}
                    </div>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Auto-Answer Value (optional)</Label>
              <Input
                value={autoAnswerValue}
                onChange={(e) => setAutoAnswerValue(e.target.value)}
                placeholder="Value to auto-fill when rule matches"
              />
              <p className="text-xs text-muted-foreground">
                If provided, this value will be automatically applied when the rule matches.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setReadinessMappingDialogOpen(false)}>Cancel</Button>
            <Button 
              onClick={handleAddReadinessMapping} 
              disabled={!selectedReadinessQuestion || upsertReadinessMapping.isPending}
            >
              Link Question
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useEvaluationRadar, EvaluationOpportunity, EvalCriterion, EvalTechnicalRisk, EvalPhase, MilestoneSummary } from '@/hooks/useEvaluationRadar';
import { useOrgTree, OrgNode, collectSubtreeEmails } from '@/hooks/useOrgTree';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { supabase } from '@/integrations/supabase/client';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import {
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Clock,
  DollarSign,
  EyeOff,
  Gauge,
  Plus,
  FileCheck,
  Target,
  Trash2,
  Building2,
  Users,
  FlaskConical,
  RefreshCw,
  GripVertical,
  Layers,
  ShieldAlert,
  ArrowRight,
  Info,
  Search,
  ChevronRight,
  ChevronDown,
  User,
  X,
} from 'lucide-react';
import { format } from 'date-fns';

// ─── Config ────────────────────────────────────────────────────
const phaseConfig: Record<EvalPhase, { label: string; icon: React.ReactNode; color: string; headerBg: string; borderColor: string }> = {
  planning: { label: 'Planning', icon: <Layers className="h-4 w-4" />, color: 'text-blue-700', headerBg: 'bg-blue-500/10', borderColor: 'border-blue-500/30' },
  deploying: { label: 'Deploying', icon: <ArrowRight className="h-4 w-4" />, color: 'text-violet-700', headerBg: 'bg-violet-500/10', borderColor: 'border-violet-500/30' },
  running: { label: 'Running', icon: <FlaskConical className="h-4 w-4" />, color: 'text-emerald-700', headerBg: 'bg-emerald-500/10', borderColor: 'border-emerald-500/30' },
  completed: { label: 'Completed', icon: <CheckCircle2 className="h-4 w-4" />, color: 'text-muted-foreground', headerBg: 'bg-muted/50', borderColor: 'border-muted-foreground/20' },
};

const statusConfig: Record<string, { label: string; color: string }> = {
  not_started: { label: 'Not Started', color: 'bg-muted text-muted-foreground' },
  in_progress: { label: 'In Progress', color: 'bg-blue-500/15 text-blue-700' },
  met: { label: 'Met', color: 'bg-emerald-500/15 text-emerald-700' },
  at_risk: { label: 'At Risk', color: 'bg-amber-500/15 text-amber-700' },
  not_met: { label: 'Not Met', color: 'bg-destructive/10 text-destructive' },
};

const riskSeverityConfig: Record<string, { label: string; color: string }> = {
  low: { label: 'Low', color: 'bg-blue-500/15 text-blue-700' },
  medium: { label: 'Medium', color: 'bg-amber-500/15 text-amber-700' },
  high: { label: 'High', color: 'bg-orange-500/15 text-orange-700' },
  critical: { label: 'Critical', color: 'bg-destructive/10 text-destructive' },
};

const OPEN_STAGES = ['stage_0', 'stage_1', 'stage_2', 'stage_3', 'stage_4', 'stage_5', 'pending_compliance'];

// ─── Org Tree Picker ───────────────────────────────────────────
function OrgTreeNode({ node, selectedId, onSelect, depth = 0 }: {
  node: OrgNode;
  selectedId: string | null;
  onSelect: (node: OrgNode) => void;
  depth?: number;
}) {
  const [expanded, setExpanded] = useState(depth < 1);
  const hasChildren = node.children.length > 0;
  const isSelected = node.id === selectedId;

  return (
    <div>
      <button
        className={cn(
          "flex items-center gap-1.5 w-full text-left px-2 py-1.5 rounded text-sm hover:bg-accent transition-colors",
          isSelected && "bg-primary/10 text-primary font-medium",
        )}
        style={{ paddingLeft: `${depth * 16 + 8}px` }}
        onClick={() => onSelect(node)}
      >
        {hasChildren ? (
          <button
            className="shrink-0 p-0.5 hover:bg-muted rounded"
            onClick={e => { e.stopPropagation(); setExpanded(!expanded); }}
          >
            {expanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
          </button>
        ) : (
          <span className="w-4" />
        )}
        <User className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        <span className="truncate">{node.full_name || node.email}</span>
        {hasChildren && (
          <Badge variant="secondary" className="text-[10px] h-4 px-1 ml-auto shrink-0">
            {node.children.length}
          </Badge>
        )}
      </button>
      {expanded && hasChildren && (
        <div>
          {node.children.map(child => (
            <OrgTreeNode key={child.id} node={child} selectedId={selectedId} onSelect={onSelect} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

function OrgTreeFilter({ selectedNode, onSelectNode, roots, currentUserId }: {
  selectedNode: OrgNode | null;
  onSelectNode: (node: OrgNode | null) => void;
  roots: OrgNode[];
  currentUserId: string | null;
}) {
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
          <Users className="h-3.5 w-3.5" />
          {selectedNode ? (selectedNode.full_name || selectedNode.email.split('@')[0]) : 'My Team'}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-2" align="end">
        <div className="max-h-[300px] overflow-y-auto">
          {roots.map(root => (
            <OrgTreeNode
              key={root.id}
              node={root}
              selectedId={selectedNode?.id || null}
              onSelect={node => { onSelectNode(node); setOpen(false); }}
            />
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}

// ─── Add to Planning Picker ────────────────────────────────────
function AddToPlanningPicker({ existingOppIds, teamEmails, onAdded }: {
  existingOppIds: Set<string>;
  teamEmails: string[];
  onAdded: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');

  const { data: searchResults, isLoading } = useQuery({
    queryKey: ['eval-planning-search', search, teamEmails],
    queryFn: async () => {
      if (!search.trim() || search.trim().length < 2) return [];
      const { data, error } = await gateway
        .from('opportunities')
        .select('id, name, sales_stage, accounts!inner(name)')
        .eq('is_archived', false)
        .in('sales_stage', OPEN_STAGES)
        .ilike('name', `%${search.trim()}%`)
        .limit(20);
      if (error) throw error;
      // Filter out already on board
      return (data || []).filter((o: any) => !existingOppIds.has(o.id));
    },
    enabled: open && search.trim().length >= 2,
    staleTime: 10_000,
  });

  const handleSelect = async (oppId: string) => {
    const { error } = await supabase
      .from('opportunities')
      .update({ eval_phase_override: 'planning', eval_radar_dismissed: false } as any)
      .eq('id', oppId);
    if (error) {
      toast.error('Failed to add to Planning');
      return;
    }
    toast.success('Added to Planning');
    setOpen(false);
    setSearch('');
    onAdded();
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
          <Plus className="h-3.5 w-3.5" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[320px] p-0" align="start">
        <Command shouldFilter={false}>
          <CommandInput
            placeholder="Search open opportunities..."
            value={search}
            onValueChange={setSearch}
          />
          <CommandList>
            <CommandEmpty>
              {search.trim().length < 2 ? 'Type to search...' : isLoading ? 'Searching...' : 'No matching opportunities'}
            </CommandEmpty>
            {(searchResults || []).length > 0 && (
              <CommandGroup heading="Open Opportunities">
                {(searchResults || []).map((opp: any) => (
                  <CommandItem
                    key={opp.id}
                    value={opp.id}
                    onSelect={() => handleSelect(opp.id)}
                    className="flex flex-col items-start gap-0.5"
                  >
                    <span className="text-sm font-medium truncate w-full">{opp.name}</span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Building2 className="h-3 w-3" />{opp.accounts?.name || 'Unknown'}
                      <Badge variant="outline" className="text-[10px] h-4 ml-1">{opp.sales_stage?.replace('_', ' ')}</Badge>
                    </span>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

// ─── Criteria Manager ──────────────────────────────────────────
function CriteriaManager({ opportunityId, criteria, onRefresh }: {
  opportunityId: string;
  criteria: EvalCriterion[];
  onRefresh: () => void;
}) {
  const [adding, setAdding] = useState(false);
  const [newCriterion, setNewCriterion] = useState('');
  const [newMetric, setNewMetric] = useState('');
  const [newTarget, setNewTarget] = useState('');

  const handleAdd = async () => {
    if (!newCriterion.trim()) return;
    const { error } = await supabase
      .from('evaluation_success_criteria')
      .insert({ opportunity_id: opportunityId, criterion: newCriterion.trim(), metric_name: newMetric.trim() || null, target_value: newTarget.trim() || null });
    if (error) { toast.error('Failed to add criterion'); return; }
    toast.success('Success criterion added');
    setNewCriterion(''); setNewMetric(''); setNewTarget(''); setAdding(false);
    onRefresh();
  };

  const handleStatusChange = async (id: string, status: string) => {
    const { error } = await supabase.from('evaluation_success_criteria').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) { toast.error('Failed to update'); return; }
    onRefresh();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('evaluation_success_criteria').delete().eq('id', id);
    if (error) { toast.error('Failed to delete'); return; }
    toast.success('Criterion removed');
    onRefresh();
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h4 className="text-xs font-semibold uppercase text-muted-foreground">Success Criteria</h4>
        <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setAdding(!adding)}>
          <Plus className="h-3 w-3 mr-1" /> Add
        </Button>
      </div>
      {adding && (
        <div className="space-y-1.5 p-2 rounded border bg-muted/30">
          <Input placeholder="What needs to be true?" value={newCriterion} onChange={e => setNewCriterion(e.target.value)} className="h-7 text-xs" />
          <div className="flex gap-1.5">
            <Input placeholder="Metric" value={newMetric} onChange={e => setNewMetric(e.target.value)} className="h-7 text-xs flex-1" />
            <Input placeholder="Target" value={newTarget} onChange={e => setNewTarget(e.target.value)} className="h-7 text-xs flex-1" />
          </div>
          <div className="flex justify-end gap-1">
            <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setAdding(false)}>Cancel</Button>
            <Button size="sm" className="h-6 text-xs" onClick={handleAdd} disabled={!newCriterion.trim()}>Add</Button>
          </div>
        </div>
      )}
      {criteria.length === 0 && !adding && (
        <div className="text-center py-2 text-xs text-muted-foreground border border-dashed rounded">
          <EyeOff className="h-3.5 w-3.5 mx-auto mb-0.5 opacity-50" />
          No criteria — flying blind
        </div>
      )}
      {criteria.map(c => (
        <div key={c.id} className="flex items-center gap-2 p-1.5 rounded border bg-card text-xs">
          <span className="flex-1 truncate">{c.criterion}</span>
          <Select value={c.status} onValueChange={v => handleStatusChange(c.id, v)}>
            <SelectTrigger className={cn("h-6 text-xs w-[90px]", statusConfig[c.status]?.color)}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(statusConfig).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => handleDelete(c.id)}>
            <Trash2 className="h-3 w-3 text-muted-foreground" />
          </Button>
        </div>
      ))}
    </div>
  );
}

// ─── Risk Manager ──────────────────────────────────────────────
function RiskManager({ opportunityId, risks, onRefresh }: {
  opportunityId: string;
  risks: EvalTechnicalRisk[];
  onRefresh: () => void;
}) {
  const [adding, setAdding] = useState(false);
  const [desc, setDesc] = useState('');
  const [severity, setSeverity] = useState('medium');

  const handleAdd = async () => {
    if (!desc.trim()) return;
    const { error } = await supabase
      .from('evaluation_technical_risks')
      .insert({ opportunity_id: opportunityId, risk_description: desc.trim(), severity });
    if (error) { toast.error('Failed to add risk'); return; }
    toast.success('Technical risk added');
    setDesc(''); setSeverity('medium'); setAdding(false);
    onRefresh();
  };

  const handleStatusChange = async (id: string, status: string) => {
    const { error } = await supabase.from('evaluation_technical_risks').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error('Failed to update');
    else onRefresh();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('evaluation_technical_risks').delete().eq('id', id);
    if (error) toast.error('Failed to delete');
    else { toast.success('Risk removed'); onRefresh(); }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h4 className="text-xs font-semibold uppercase text-muted-foreground">Technical Risks</h4>
        <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setAdding(!adding)}>
          <Plus className="h-3 w-3 mr-1" /> Add
        </Button>
      </div>
      {adding && (
        <div className="space-y-1.5 p-2 rounded border bg-muted/30">
          <Textarea placeholder="Describe the risk..." value={desc} onChange={e => setDesc(e.target.value)} className="text-xs min-h-[50px]" />
          <Select value={severity} onValueChange={setSeverity}>
            <SelectTrigger className="h-7 text-xs w-[120px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(riskSeverityConfig).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex justify-end gap-1">
            <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setAdding(false)}>Cancel</Button>
            <Button size="sm" className="h-6 text-xs" onClick={handleAdd} disabled={!desc.trim()}>Add</Button>
          </div>
        </div>
      )}
      {risks.map(r => (
        <div key={r.id} className="flex items-center gap-2 p-1.5 rounded border bg-card text-xs">
          <ShieldAlert className="h-3.5 w-3.5 shrink-0 text-amber-600" />
          <span className="flex-1 truncate">{r.risk_description}</span>
          <Badge variant="outline" className={cn("text-[10px] h-5", riskSeverityConfig[r.severity]?.color)}>
            {riskSeverityConfig[r.severity]?.label}
          </Badge>
          <Select value={r.status} onValueChange={v => handleStatusChange(r.id, v)}>
            <SelectTrigger className="h-6 text-xs w-[90px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="mitigated">Mitigated</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="accepted">Accepted</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => handleDelete(r.id)}>
            <Trash2 className="h-3 w-3 text-muted-foreground" />
          </Button>
        </div>
      ))}
    </div>
  );
}

// ─── Eval Card (Kanban) ────────────────────────────────────────
function EvalKanbanCard({ ev, criteria, risks, onRefresh, onRefreshRisks, onClick, onPhaseOverride, onDismiss }: {
  ev: EvaluationOpportunity;
  criteria: EvalCriterion[];
  risks: EvalTechnicalRisk[];
  onRefresh: () => void;
  onRefreshRisks: () => void;
  onClick: () => void;
  onPhaseOverride: (oppId: string, phase: EvalPhase | null) => void;
  onDismiss: (oppId: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const criteriaProgress = ev.criteriaCount > 0 ? (ev.criteriaMetCount / ev.criteriaCount) * 100 : 0;
  const hasRisks = ev.riskCount > 0 && ev.phase !== 'completed';
  const hasIssues = ev.issueCount > 0 && ev.phase !== 'completed';
  const hasAlerts = ev.risks.length > 0 && ev.phase !== 'completed';

  return (
    <Card className={cn(
      "border transition-shadow hover:shadow-md",
      hasIssues ? 'border-l-4 border-l-destructive' : hasRisks ? 'border-l-4 border-l-amber-500' : hasAlerts ? 'border-l-4 border-l-amber-500' : '',
    )}>
      <CardContent className="p-3 space-y-2">
        {/* Header */}
        <div className="flex items-start justify-between gap-1">
          <div className="flex-1 min-w-0 cursor-pointer" onClick={onClick}>
            <p className="font-medium text-sm truncate leading-tight">{ev.name}</p>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
              <Building2 className="h-3 w-3 shrink-0" />{ev.accountName}
            </p>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <FileCheck className={cn("h-4 w-4 shrink-0", ev.primaryEvalQuote ? "text-emerald-600" : "text-muted-foreground/40")} />
                </TooltipTrigger>
                <TooltipContent>
                  {ev.primaryEvalQuote
                    ? <p className="text-xs">Eval quote: <strong>{ev.primaryEvalQuote}</strong></p>
                    : <p className="text-xs text-muted-foreground">No eval quote set</p>
                  }
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            {ev.phaseConflict && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-4 w-4 text-amber-500 shrink-0" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Manual override active. CRM suggests: <strong>{phaseConfig[ev.computedPhase].label}</strong></p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
        </div>

        {/* Badges row */}
        <div className="flex flex-wrap gap-1">
          {ev.addedViaMilestones && !ev.primaryEvalQuote && (
            <Badge variant="outline" className="text-[10px] h-5 border-amber-500/50 text-amber-700 bg-amber-500/10">
              <AlertTriangle className="h-2.5 w-2.5 mr-0.5" />No Quote
            </Badge>
          )}
          {ev.milestoneSummary && (
            <Badge variant="secondary" className="text-[10px] h-5">
              <Calendar className="h-2.5 w-2.5 mr-0.5" />{ev.milestoneSummary.completed}/{ev.milestoneSummary.total} milestones
            </Badge>
          )}
          {ev.salesStage && (
            <Badge variant="outline" className="text-[10px] h-5">CRM: {ev.salesStage}</Badge>
          )}
          {ev.preSalesStage && (
            <Badge variant="outline" className="text-[10px] h-5">SE: {ev.preSalesStage}</Badge>
          )}
          {ev.evalType && (
            <Badge variant="secondary" className="text-[10px] h-5">
              <FlaskConical className="h-2.5 w-2.5 mr-0.5" />{ev.evalType}
            </Badge>
          )}
        </div>

        {/* Key metrics */}
        <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
          {ev.readinessScore !== null && (
            <span className={cn("flex items-center gap-0.5 font-medium",
              ev.readinessScore >= 70 ? 'text-emerald-600' : ev.readinessScore >= 40 ? 'text-amber-600' : 'text-destructive'
            )}>
              <Gauge className="h-3 w-3" />{ev.readinessScore}%
            </span>
          )}
          {ev.useCaseCount > 0 && (
            <span className="flex items-center gap-0.5">
              <Target className="h-3 w-3" />{ev.useCaseCount} use cases
            </span>
          )}
          {ev.value && (
            <span className="flex items-center gap-0.5">
              <DollarSign className="h-3 w-3" />${(ev.value / 1000).toFixed(0)}k
            </span>
          )}
          {ev.primarySeEmail && (
            <span className="flex items-center gap-0.5 truncate max-w-[120px]">
              <Users className="h-3 w-3" />{ev.primarySeEmail.split('@')[0]}
            </span>
          )}
        </div>

        {/* Timeline */}
        {(ev.evalStartDate || ev.evalEndDate) && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Calendar className="h-3 w-3 shrink-0" />
            {ev.evalStartDate && <span>{format(new Date(ev.evalStartDate), 'MMM d')}</span>}
            {ev.evalStartDate && ev.evalEndDate && <span>→</span>}
            {ev.evalEndDate && <span>{format(new Date(ev.evalEndDate), 'MMM d')}</span>}
            {ev.daysRemaining !== null && ev.phase === 'running' && (
              <Badge variant={ev.daysRemaining <= 7 ? 'destructive' : 'secondary'} className="text-[10px] h-5">
                <Clock className="h-2.5 w-2.5 mr-0.5" />{ev.daysRemaining}d left
              </Badge>
            )}
            {ev.daysElapsed !== null && ev.phase === 'running' && (
              <span className="text-muted-foreground">{ev.daysElapsed}d elapsed</span>
            )}
          </div>
        )}

        {/* Success criteria progress */}
        <div className="space-y-0.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">
              {ev.criteriaCount === 0 ? 'No criteria' : `${ev.criteriaMetCount}/${ev.criteriaCount} met`}
            </span>
            <div className="flex items-center gap-2">
              {ev.riskCount > 0 && (
                <span className="text-amber-600 flex items-center gap-0.5">
                  <ShieldAlert className="h-3 w-3" />{ev.riskCount} risk{ev.riskCount > 1 ? 's' : ''}
                </span>
              )}
              {ev.issueCount > 0 && (
                <span className="text-destructive flex items-center gap-0.5">
                  <AlertTriangle className="h-3 w-3" />{ev.issueCount} issue{ev.issueCount > 1 ? 's' : ''}
                </span>
              )}
            </div>
          </div>
          {ev.criteriaCount > 0 && <Progress value={criteriaProgress} className="h-1.5" />}
        </div>

        {/* Risk/issue alerts (collapsed) */}
        {hasAlerts && !expanded && (
          <div className="space-y-1">
            {ev.risks.slice(0, 2).map((risk, i) => {
              const isIssueAlert = risk.includes('issue');
              return (
                <div key={i} className={cn(
                  "text-xs rounded px-2 py-1 flex items-center gap-1",
                  isIssueAlert ? "text-destructive bg-destructive/10" : "text-amber-700 bg-amber-500/10"
                )}>
                  <AlertTriangle className="h-3 w-3 shrink-0" />
                  <span className="truncate">{risk}</span>
                </div>
              );
            })}
            {ev.risks.length > 2 && <span className="text-xs text-muted-foreground pl-2">+{ev.risks.length - 2} more</span>}
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-1">
            <Select
              value={ev.evalPhaseOverride || 'auto'}
              onValueChange={v => onPhaseOverride(ev.id, v === 'auto' ? null : v as EvalPhase)}
            >
              <SelectTrigger className="h-6 text-[10px] w-[100px]">
                <GripVertical className="h-3 w-3 mr-0.5" />
                <SelectValue placeholder="Move" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">Auto ({phaseConfig[ev.computedPhase].label})</SelectItem>
                <SelectItem value="planning">Planning</SelectItem>
                <SelectItem value="deploying">Deploying</SelectItem>
                <SelectItem value="running">Running</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-muted-foreground hover:text-destructive"
                    onClick={() => onDismiss(ev.id)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent><p className="text-xs">Dismiss from Eval Radar</p></TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setExpanded(!expanded)}>
            {expanded ? 'Collapse' : 'Details'}
          </Button>
        </div>

        {/* Expanded section */}
        {expanded && (
          <div className="space-y-3 pt-2 border-t">
            {ev.risks.length > 0 && (
              <div className="space-y-1">
                {ev.risks.map((risk, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-amber-700 bg-amber-500/10 rounded px-2 py-1">
                    <AlertTriangle className="h-3 w-3 shrink-0" />
                    <span>{risk}</span>
                  </div>
                ))}
              </div>
            )}

            <CriteriaManager
              opportunityId={ev.id}
              criteria={criteria.filter(c => c.opportunity_id === ev.id)}
              onRefresh={onRefresh}
            />

            <RiskManager
              opportunityId={ev.id}
              risks={risks.filter(r => r.opportunity_id === ev.id)}
              onRefresh={onRefreshRisks}
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Kanban Column ─────────────────────────────────────────────
function KanbanColumn({ phase, evaluations, criteria, risks, onRefresh, onRefreshRisks, onNavigate, onPhaseOverride, onDismiss, collapsed, onToggleCollapse, existingOppIds, teamEmails, onOppAdded }: {
  phase: EvalPhase;
  evaluations: EvaluationOpportunity[];
  criteria: EvalCriterion[];
  risks: EvalTechnicalRisk[];
  onRefresh: () => void;
  onRefreshRisks: () => void;
  onNavigate: (id: string) => void;
  onPhaseOverride: (oppId: string, phase: EvalPhase | null) => void;
  onDismiss: (oppId: string) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  existingOppIds: Set<string>;
  teamEmails: string[];
  onOppAdded: () => void;
}) {
  const config = phaseConfig[phase];
  const atRiskCount = evaluations.filter(e => e.riskCount > 0).length;
  const atIssueCount = evaluations.filter(e => e.issueCount > 0).length;

  if (collapsed) {
    return (
      <div
        className={cn("flex flex-col items-center rounded-lg border cursor-pointer px-2 py-4 min-w-[48px]", config.headerBg, config.borderColor)}
        onClick={onToggleCollapse}
      >
        <span className={cn("text-xs font-semibold writing-mode-vertical", config.color)} style={{ writingMode: 'vertical-rl' }}>
          {config.label} ({evaluations.length})
        </span>
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col rounded-lg border min-w-[280px] flex-1", config.borderColor)}>
      {/* Column header */}
      <div className={cn("flex items-center justify-between px-3 py-2 rounded-t-lg", config.headerBg)} onClick={phase === 'completed' ? onToggleCollapse : undefined}>
        <div className="flex items-center gap-2">
          <span className={config.color}>{config.icon}</span>
          <span className={cn("text-sm font-semibold", config.color)}>{config.label}</span>
          <Badge variant="secondary" className="text-xs h-5 px-1.5">{evaluations.length}</Badge>
        </div>
        <div className="flex items-center gap-1">
          {atIssueCount > 0 && (
            <Badge variant="outline" className="text-[10px] h-5 border-destructive/50 text-destructive">
              <AlertTriangle className="h-2.5 w-2.5 mr-0.5" />{atIssueCount}
            </Badge>
          )}
          {atRiskCount > 0 && (
            <Badge variant="outline" className="text-[10px] h-5 border-amber-500/50 text-amber-600">
              <ShieldAlert className="h-2.5 w-2.5 mr-0.5" />{atRiskCount}
            </Badge>
          )}
          {phase === 'planning' && (
            <AddToPlanningPicker
              existingOppIds={existingOppIds}
              teamEmails={teamEmails}
              onAdded={onOppAdded}
            />
          )}
        </div>
      </div>

      {/* Cards */}
      <ScrollArea className="flex-1 max-h-[calc(100vh-320px)]">
        <div className="p-2 space-y-2">
          {evaluations.length === 0 && (
            <div className="text-center py-6 text-xs text-muted-foreground">
              No evaluations
            </div>
          )}
          {evaluations.map(ev => (
            <EvalKanbanCard
              key={ev.id}
              ev={ev}
              criteria={criteria}
              risks={risks}
              onRefresh={onRefresh}
              onRefreshRisks={onRefreshRisks}
              onClick={() => onNavigate(ev.id)}
              onPhaseOverride={onPhaseOverride}
              onDismiss={onDismiss}
            />
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}

// ─── Main Component ────────────────────────────────────────────
export default function EvaluationRadarTab({ teamEmails: parentTeamEmails }: { teamEmails: string[] }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { effectiveUserId } = useAuth();
  const { roots, nodeMap, isManager, isLoading: orgLoading } = useOrgTree();

  // Find current user's node for default selection
  const currentUserNode = useMemo(() => {
    if (!effectiveUserId || !nodeMap.size) return null;
    return nodeMap.get(effectiveUserId) || null;
  }, [effectiveUserId, nodeMap]);

  // Default: select the current user's node (shows self + reports)
  const [selectedNode, setSelectedNode] = useState<OrgNode | null>(null);

  // Compute filtered team emails from org tree selection
  const filteredEmails = useMemo(() => {
    const node = selectedNode || currentUserNode;
    if (!node) return parentTeamEmails;
    return collectSubtreeEmails(node);
  }, [selectedNode, currentUserNode, parentTeamEmails]);

  const { byPhase, evaluations, criteria, technicalRisks, stats, isLoading, refetchCriteria, refetchRisks } = useEvaluationRadar(filteredEmails);
  const [completedCollapsed, setCompletedCollapsed] = useState(true);

  const existingOppIds = useMemo(() => new Set(evaluations.map(e => e.id)), [evaluations]);

  const handlePhaseOverride = async (oppId: string, phase: EvalPhase | null) => {
    const { error } = await supabase
      .from('opportunities')
      .update({ eval_phase_override: phase })
      .eq('id', oppId);
    if (error) {
      toast.error('Failed to update phase');
      return;
    }
    toast.success(phase ? `Moved to ${phaseConfig[phase].label}` : 'Reset to auto-computed phase');
    queryClient.invalidateQueries({ queryKey: ['evaluation-radar-opps-team'] });
    queryClient.invalidateQueries({ queryKey: ['evaluation-radar-opps-overrides'] });
  };

  const handleDismiss = async (oppId: string) => {
    const { error } = await supabase
      .from('opportunities')
      .update({ eval_radar_dismissed: true, eval_phase_override: null } as any)
      .eq('id', oppId);
    if (error) {
      toast.error('Failed to dismiss');
      return;
    }
    toast.success('Removed from Eval Radar');
    queryClient.invalidateQueries({ queryKey: ['evaluation-radar-opps-team'] });
    queryClient.invalidateQueries({ queryKey: ['evaluation-radar-opps-overrides'] });
  };

  const handleOppAdded = () => {
    queryClient.invalidateQueries({ queryKey: ['evaluation-radar-opps-team'] });
    queryClient.invalidateQueries({ queryKey: ['evaluation-radar-opps-overrides'] });
  };

  if (isLoading || orgLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const activeNode = selectedNode || currentUserNode;

  return (
    <div className="space-y-4">
      {/* Filter bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Viewing:</span>
          {activeNode && (
            <Badge variant="secondary" className="text-xs">
              {activeNode.full_name || activeNode.email.split('@')[0]}
              {activeNode.children.length > 0 && ` + ${collectSubtreeEmails(activeNode).length - 1} reports`}
            </Badge>
          )}
        </div>
        {roots.length > 0 && (
          <OrgTreeFilter
            selectedNode={selectedNode || currentUserNode}
            onSelectNode={setSelectedNode}
            roots={roots}
            currentUserId={effectiveUserId}
          />
        )}
      </div>

      {/* Stats summary */}
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
        {(['planning', 'deploying', 'running', 'completed'] as EvalPhase[]).map(p => (
          <Card key={p} className={cn("border", phaseConfig[p].borderColor)}>
            <CardContent className="p-2 flex items-center gap-2">
              <span className={phaseConfig[p].color}>{phaseConfig[p].icon}</span>
              <div>
                <p className="text-lg font-bold leading-tight">{byPhase[p].length}</p>
                <p className="text-[10px] text-muted-foreground">{phaseConfig[p].label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
        <Card className="border-amber-500/30">
          <CardContent className="p-2 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <div>
              <p className="text-lg font-bold leading-tight text-amber-600">{stats.atRisk}</p>
              <p className="text-[10px] text-muted-foreground">At Risk</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-destructive/30">
          <CardContent className="p-2 flex items-center gap-2">
            <EyeOff className="h-4 w-4 text-destructive" />
            <div>
              <p className="text-lg font-bold leading-tight text-destructive">{stats.flyingBlind}</p>
              <p className="text-[10px] text-muted-foreground">Flying Blind</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Kanban board */}
      <div className="flex gap-3 overflow-x-auto pb-4">
        {(['planning', 'deploying', 'running', 'completed'] as EvalPhase[]).map(phase => (
          <KanbanColumn
            key={phase}
            phase={phase}
            evaluations={byPhase[phase]}
            criteria={criteria}
            risks={technicalRisks}
            onRefresh={refetchCriteria}
            onRefreshRisks={refetchRisks}
            onNavigate={id => navigate(`/opportunities/${id}`)}
            onPhaseOverride={handlePhaseOverride}
            onDismiss={handleDismiss}
            collapsed={phase === 'completed' && completedCollapsed}
            onToggleCollapse={() => phase === 'completed' && setCompletedCollapsed(!completedCollapsed)}
            existingOppIds={existingOppIds}
            teamEmails={filteredEmails}
            onOppAdded={handleOppAdded}
          />
        ))}
      </div>
    </div>
  );
}

import { useState, useRef, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useExecWeeklySummary, type EvalOppSummary, type RiskIssueSummary, type TopMeetingOpp } from '@/hooks/useExecWeeklySummary';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { BestCallHighlight } from '@/hooks/useExecWeeklySummary';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import {
  Send,
  Download,
  RefreshCw,
  Sparkles,
  Calendar as CalendarIcon,
  ChevronDown,
  TrendingUp,
  TrendingDown,
  Minus,
  AlertTriangle,
  ArrowRight,
  MapPin,
  Plus,
  Trash2,
  Info,
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import html2canvas from 'html2canvas';
import jspdf from 'jspdf';
import { startOfWeek, endOfWeek, subWeeks, format } from 'date-fns';
import AddManualMeetingDialog from '@/components/dialogs/AddManualMeetingDialog';
import { useDeleteManualMeeting } from '@/hooks/useManualMeetings';

type DatePreset = 'this_week' | 'last_week' | 'custom';

function formatCurrency(value: number): string {
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `$${(value / 1_000).toFixed(0)}k`;
  return `$${value}`;
}

function EvalOppList({ opps, phase }: { opps: EvalOppSummary[]; phase: string }) {
  if (opps.length === 0) return null;
  return (
    <ul className="mt-1 ml-4 space-y-0.5">
      {opps.map((opp) => (
        <li key={opp.id} className="text-sm text-foreground/80 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-foreground/30 shrink-0" />
          <span className="font-medium">{opp.name}</span>
          <span className="text-muted-foreground">({opp.accountName})</span>
          {opp.value && <span className="text-muted-foreground">— {formatCurrency(opp.value)}</span>}
        </li>
      ))}
    </ul>
  );
}

export default function ExecWeeklySummaryTab({ teamEmails }: { teamEmails?: string[] }) {
  const navigate = useNavigate();
  const [preset, setPreset] = useState<DatePreset>('this_week');
  const [customFrom, setCustomFrom] = useState<Date | undefined>();
  const [customTo, setCustomTo] = useState<Date | undefined>();
  const [calendarOpen, setCalendarOpen] = useState(false);

  const dateRange = useMemo(() => {
    const now = new Date();
    if (preset === 'last_week') {
      const lastStart = startOfWeek(subWeeks(now, 1), { weekStartsOn: 1 });
      const lastEnd = endOfWeek(subWeeks(now, 1), { weekStartsOn: 1 });
      return { from: lastStart, to: lastEnd };
    }
    if (preset === 'custom' && customFrom && customTo) {
      return { from: customFrom, to: customTo };
    }
    return undefined;
  }, [preset, customFrom, customTo]);

  const { summaryData, isLoading, sendEmail } = useExecWeeklySummary(dateRange, teamEmails);
  const { user } = useAuth();
  const [recipientEmail, setRecipientEmail] = useState('');
  const [addMeetingOpen, setAddMeetingOpen] = useState(false);
  const deleteMeeting = useDeleteManualMeeting();
  const summaryRef = useRef<HTMLDivElement>(null);

  const handleSend = () => {
    const email = recipientEmail || user?.email;
    if (email) sendEmail.mutate(email);
  };

  const handleDownloadPDF = async () => {
    if (!summaryRef.current) return;
    try {
      const canvas = await html2canvas(summaryRef.current, { scale: 2, backgroundColor: '#ffffff' });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jspdf({ orientation: 'portrait', unit: 'px', format: [canvas.width / 2, canvas.height / 2] });
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width / 2, canvas.height / 2);
      pdf.save(`exec-summary-${summaryData?.weekLabel?.replace(/\s/g, '-') || 'report'}.pdf`);
    } catch (e) {
      console.error('PDF generation failed:', e);
    }
  };

  const presetLabel = preset === 'this_week' ? 'This Week' :
    preset === 'last_week' ? 'Last Week' :
    (customFrom && customTo) ? `${format(customFrom, 'MMM d')} – ${format(customTo, 'MMM d')}` : 'Custom Range';

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
        <span className="ml-2 text-muted-foreground">Building your executive summary…</span>
      </div>
    );
  }

  if (!summaryData) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <Sparkles className="h-12 w-12 mx-auto mb-4 opacity-50" />
        <p>No data available for this period yet.</p>
      </div>
    );
  }

  const d = summaryData;
  const totalEvals = d.evalPhaseCounts.planning + d.evalPhaseCounts.deploying + d.evalPhaseCounts.running + d.evalPhaseCounts.completed;
  const meetingsKpi = d.kpis.find(k => k.label === 'Meetings Attended');
  const actionsKpi = d.kpis.find(k => k.label === 'Actions Completed');
  const evalActivityKpi = d.kpis.find(k => k.label === 'Eval Activity');
  const coachingKpi = d.kpis.find(k => k.label === 'Avg Coaching Score');

  const risks = d.risksAndIssues.filter(r => r.entryType === 'risk');
  const issues = d.risksAndIssues.filter(r => r.entryType === 'issue');
  const highSevItems = d.risksAndIssues.filter(r => r.severity === 'high' || r.severity === 'critical');

  // Group risks/issues by opportunity
  const risksByOpp = (() => {
    const map = new Map<string, { opportunityId: string; opportunityName: string; accountId: string; accountName: string; riskCount: number; issueCount: number; highSevCount: number }>();
    d.risksAndIssues.forEach(r => {
      const existing = map.get(r.opportunityId);
      const isHighSev = r.severity === 'high' || r.severity === 'critical';
      if (existing) {
        if (r.entryType === 'issue') existing.issueCount++;
        else existing.riskCount++;
        if (isHighSev) existing.highSevCount++;
      } else {
        map.set(r.opportunityId, {
          opportunityId: r.opportunityId,
          opportunityName: r.opportunityName,
          accountId: r.accountId,
          accountName: r.accountName,
          riskCount: r.entryType === 'risk' ? 1 : 0,
          issueCount: r.entryType === 'issue' ? 1 : 0,
          highSevCount: isHighSev ? 1 : 0,
        });
      }
    });
    return Array.from(map.values()).sort((a, b) => b.highSevCount - a.highSevCount || (b.riskCount + b.issueCount) - (a.riskCount + a.issueCount));
  })();

  const kpiDescriptions: Record<string, string> = {
    'Meetings Attended': 'Total meetings involving your team members during the period. Includes auto-detected meetings from transcripts (matched by team email) plus any manually logged meetings. Each manual entry counts as at least 1.',
    'Actions Completed': 'Number of Next Best Actions (NBAs) marked as completed by team members during the period.',
    'Eval Activity': 'Sum of evaluation events: stage transitions, milestone completions, validation task updates, and NBA completions across all team opportunities.',
    'Avg Coaching Score': 'Average SE coaching score (0–5 scale) from AI-analyzed transcripts. Scores ≤ 1.0 are excluded as error-floor values. Only transcripts within the period are included.',
  };

  const trendIcon = (kpi: { trend: string } | undefined) => {
    if (!kpi) return null;
    if (kpi.trend === 'up') return <TrendingUp className="h-3.5 w-3.5 inline text-emerald-600" />;
    if (kpi.trend === 'down') return <TrendingDown className="h-3.5 w-3.5 inline text-destructive" />;
    return <Minus className="h-3.5 w-3.5 inline text-muted-foreground" />;
  };

  return (
    <div className="space-y-6">
      {/* Actions bar */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Executive Summary</h2>

          <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1">
                <CalendarIcon className="h-3 w-3" />
                {presetLabel}
                <ChevronDown className="h-3 w-3 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <div className="p-3 space-y-2 border-b">
                <p className="text-xs font-medium text-muted-foreground">Quick Select</p>
                <div className="flex gap-2">
                  <Button size="sm" variant={preset === 'this_week' ? 'default' : 'outline'} className="h-7 text-xs"
                    onClick={() => { setPreset('this_week'); setCalendarOpen(false); }}>This Week</Button>
                  <Button size="sm" variant={preset === 'last_week' ? 'default' : 'outline'} className="h-7 text-xs"
                    onClick={() => { setPreset('last_week'); setCalendarOpen(false); }}>Last Week</Button>
                </div>
              </div>
              <div className="p-3 space-y-2">
                <p className="text-xs font-medium text-muted-foreground">Custom Range</p>
                <Calendar
                  mode="range"
                  selected={customFrom && customTo ? { from: customFrom, to: customTo } : undefined}
                  onSelect={(range) => {
                    if (range?.from) setCustomFrom(range.from);
                    if (range?.to) { setCustomTo(range.to); setPreset('custom'); setCalendarOpen(false); }
                    else setCustomTo(undefined);
                  }}
                  numberOfMonths={1}
                  disabled={(date) => date > new Date()}
                  className={cn("p-3 pointer-events-auto")}
                />
              </div>
            </PopoverContent>
          </Popover>
          <Button size="sm" variant="outline" onClick={() => setAddMeetingOpen(true)} className="gap-1">
            <Plus className="h-3.5 w-3.5" />
            Log Meeting
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <Input
            placeholder={user?.email || 'Recipient email'}
            value={recipientEmail}
            onChange={(e) => setRecipientEmail(e.target.value)}
            className="w-64 h-9 text-sm"
          />
          <Button size="sm" onClick={handleSend} disabled={sendEmail.isPending}>
            <Send className="h-4 w-4 mr-1" />
            {sendEmail.isPending ? 'Sending…' : 'Email'}
          </Button>
          <Button size="sm" variant="outline" onClick={handleDownloadPDF}>
            <Download className="h-4 w-4 mr-1" />
            PDF
          </Button>
        </div>
      </div>

      {/* ─── Readable Document ───────────────────────── */}
      <div ref={summaryRef} className="max-w-3xl mx-auto bg-card border rounded-xl shadow-sm overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent px-8 py-6 border-b">
          <p className="text-xs font-semibold uppercase tracking-widest text-primary/70 mb-1">SE Team Executive Summary</p>
          <h1 className="text-2xl font-bold text-foreground">{d.weekLabel}</h1>
          <p className="text-sm text-muted-foreground mt-1">{d.teamSize} team members</p>
        </div>

        <div className="px-8 py-6 space-y-6">
          {/* ─── Executive Overview ──────────────────── */}
          <section>
            <h2 className="text-base font-bold text-foreground mb-3 flex items-center gap-2">
              <span className="w-1 h-5 bg-primary rounded-full" />
              Executive Overview
            </h2>
            <p className="text-sm leading-relaxed text-foreground/85">
              During the selected period, the team participated in{' '}
              <strong className="text-foreground">{meetingsKpi?.value ?? 0} meetings</strong>{' '}
              {trendIcon(meetingsKpi)}
              {d.meetingWoWDelta !== null && (
                <span className={cn(
                  'text-xs font-semibold ml-1',
                  d.meetingWoWDelta > 0 ? 'text-emerald-600' : d.meetingWoWDelta < 0 ? 'text-destructive' : 'text-muted-foreground'
                )}>
                  ({d.meetingWoWDelta > 0 ? '+' : ''}{d.meetingWoWDelta}% WoW)
                </span>
              )}{' '}
              across{' '}
              <strong className="text-foreground">{d.meetingLinkedOppCount} active opportunities</strong>{' '}
              worth{' '}
              <strong className="text-foreground">{formatCurrency(d.meetingLinkedPipelineValue)}</strong>{' '}
              in total pipeline.
            </p>

            {/* Top 5 opportunities by revenue */}
            {d.topMeetingLinkedOpps && d.topMeetingLinkedOpps.length > 0 && (
              <div className="mt-2 ml-1">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Top Opportunities by ARR</p>
                <ul className="space-y-0.5">
                  {d.topMeetingLinkedOpps.map((opp, i) => (
                    <li key={opp.id} className="text-sm text-foreground/80 flex items-center gap-2">
                      <span className="text-xs font-bold text-muted-foreground w-4 text-right">{i + 1}.</span>
                      <button
                        className="font-medium text-primary hover:underline cursor-pointer text-left"
                        onClick={() => navigate(`/accounts?opportunityId=${opp.id}`)}
                      >
                        {opp.name}
                      </button>
                      {opp.accountName && <span className="text-muted-foreground">({opp.accountName})</span>}
                      <span className="text-muted-foreground">— {formatCurrency(opp.value)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {(d.preEvalOppCount > 0 || d.evalStageOppCount > 0) && (
              <p className="text-sm leading-relaxed text-foreground/85 mt-2">
                Of the deals engaged this period,{' '}
                {d.preEvalOppCount > 0 && (
                  <>
                    <strong className="text-foreground">{d.preEvalOppCount} opportunities</strong>{' '}
                    worth <strong className="text-foreground">{formatCurrency(d.preEvalPipelineValue)}</strong>{' '}
                    are in pre-eval stages (Discovery/Demo) being built toward evaluation
                    {d.evalStageOppCount > 0 ? ', while ' : '. '}
                  </>
                )}
                {d.evalStageOppCount > 0 && (
                  <>
                    <strong className="text-foreground">{d.evalStageOppCount} opportunities</strong>{' '}
                    worth <strong className="text-foreground">{formatCurrency(d.evalStagePipelineValue)}</strong>{' '}
                    are actively in evaluation (Proof - Scoping or above).
                  </>
                )}
              </p>
            )}

            <p className="text-sm leading-relaxed text-foreground/85 mt-2">
              The team completed{' '}
              <strong className="text-foreground">{evalActivityKpi?.value ?? 0} evaluation activities</strong>{' '}
              and{' '}
              <strong className="text-foreground">{actionsKpi?.value ?? 0} actions</strong>.{' '}
              {coachingKpi && coachingKpi.value > 0 && (
                <>
                  The average coaching score was{' '}
                  <strong className="text-foreground">{coachingKpi.value}/5</strong>{' '}
                  {trendIcon(coachingKpi)}.
                </>
              )}
            </p>

          </section>

          <Separator />

          {/* ─── Key Metrics ────────────────────────── */}
          <section>
            <h2 className="text-base font-bold text-foreground mb-3 flex items-center gap-2">
              <span className="w-1 h-5 bg-primary rounded-full" />
              Key Metrics
            </h2>
            <div className="grid grid-cols-2 gap-3">
              {d.kpis.map((kpi, i) => {
                const delta = kpi.previousValue > 0
                  ? Math.round(((kpi.value - kpi.previousValue) / kpi.previousValue) * 100)
                  : kpi.value > 0 ? 100 : 0;
                return (
                  <div key={i} className="rounded-lg border bg-muted/30 p-3">
                    <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                      {kpi.label}
                      {kpiDescriptions[kpi.label] && (
                        <TooltipProvider delayDuration={200}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Info className="h-3 w-3 text-muted-foreground/60 cursor-help" />
                            </TooltipTrigger>
                            <TooltipContent side="top" className="max-w-xs text-xs font-normal normal-case tracking-normal">
                              {kpiDescriptions[kpi.label]}
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                    </p>
                    <div className="flex items-baseline gap-2 mt-1">
                      <span className="text-2xl font-bold">{kpi.value}{kpi.unit || ''}</span>
                      {kpi.previousValue > 0 && (
                        <span className={cn('text-xs font-semibold',
                          kpi.trendIsPositive && kpi.trend === 'up' ? 'text-emerald-600' :
                          !kpi.trendIsPositive && kpi.trend === 'up' ? 'text-destructive' :
                          kpi.trendIsPositive && kpi.trend === 'down' ? 'text-destructive' :
                          'text-emerald-600'
                        )}>
                          {delta > 0 ? '+' : ''}{delta}% vs prev
                        </span>
                      )}
                    </div>
                    {kpi.fourWeekAvg > 0 && (
                      <p className="text-[11px] text-muted-foreground mt-0.5">4-wk avg: {kpi.fourWeekAvg}{kpi.unit || ''}</p>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          <Separator />

          {/* ─── Evaluation Pipeline ────────────────── */}
          <section>
            <h2 className="text-base font-bold text-foreground mb-3 flex items-center gap-2">
              <span className="w-1 h-5 bg-primary rounded-full" />
              Evaluation Pipeline
              <Badge variant="secondary" className="text-xs ml-1">{totalEvals} active</Badge>
              <span className="text-sm font-normal text-muted-foreground ml-auto">
                {formatCurrency(d.totalRevenueInMotion)} in motion
              </span>
            </h2>

            {/* Stacked bar */}
            {totalEvals > 0 && (
              <div className="flex h-6 rounded-md overflow-hidden mb-4">
                {d.evalPhaseCounts.planning > 0 && (
                  <div className="bg-blue-500 flex items-center justify-center text-[11px] font-bold text-white"
                    style={{ width: `${(d.evalPhaseCounts.planning / totalEvals) * 100}%` }}>{d.evalPhaseCounts.planning}</div>
                )}
                {d.evalPhaseCounts.deploying > 0 && (
                  <div className="bg-violet-500 flex items-center justify-center text-[11px] font-bold text-white"
                    style={{ width: `${(d.evalPhaseCounts.deploying / totalEvals) * 100}%` }}>{d.evalPhaseCounts.deploying}</div>
                )}
                {d.evalPhaseCounts.running > 0 && (
                  <div className="bg-emerald-500 flex items-center justify-center text-[11px] font-bold text-white"
                    style={{ width: `${(d.evalPhaseCounts.running / totalEvals) * 100}%` }}>{d.evalPhaseCounts.running}</div>
                )}
                {d.evalPhaseCounts.completed > 0 && (
                  <div className="bg-muted-foreground/50 flex items-center justify-center text-[11px] font-bold text-white"
                    style={{ width: `${(d.evalPhaseCounts.completed / totalEvals) * 100}%` }}>{d.evalPhaseCounts.completed}</div>
                )}
              </div>
            )}

            <div className="space-y-3">
              {[
                { key: 'planning', label: 'Planning', color: 'bg-blue-500', count: d.evalPhaseCounts.planning },
                { key: 'deploying', label: 'Deploying', color: 'bg-violet-500', count: d.evalPhaseCounts.deploying },
                { key: 'running', label: 'Running', color: 'bg-emerald-500', count: d.evalPhaseCounts.running },
                { key: 'completed', label: 'Completed', color: 'bg-muted-foreground/50', count: d.evalPhaseCounts.completed },
              ].map(phase => (
                <div key={phase.key}>
                  <div className="flex items-center gap-2 mb-0.5">
                    <div className={cn('w-2.5 h-2.5 rounded-full', phase.color)} />
                    <span className="text-sm font-semibold">{phase.label}</span>
                    <Badge variant="outline" className="text-[10px] h-4">{phase.count}</Badge>
                    {(d.evalOppsByPhase[phase.key] || []).length > 0 && (
                      <span className="text-xs text-muted-foreground ml-auto">
                        {formatCurrency((d.evalOppsByPhase[phase.key] || []).reduce((sum, o) => sum + (o.value || 0), 0))}
                      </span>
                    )}
                  </div>
                  <EvalOppList opps={d.evalOppsByPhase[phase.key] || []} phase={phase.key} />
                </div>
              ))}
            </div>
          </section>

          {/* ─── Risks & Issues ─────────────────────── */}
          {d.risksAndIssues.length > 0 && (
            <>
              <Separator />
              <section>
                <h2 className="text-base font-bold text-foreground mb-3 flex items-center gap-2">
                  <span className="w-1 h-5 bg-destructive rounded-full" />
                  Open Risks & Issues
                  <Badge variant="outline" className="text-xs border-amber-500/50 text-amber-600">{risks.length} risk{risks.length !== 1 ? 's' : ''}</Badge>
                  <Badge variant="outline" className="text-xs border-destructive/50 text-destructive">{issues.length} issue{issues.length !== 1 ? 's' : ''}</Badge>
                </h2>

                <p className="text-sm text-foreground/85 mb-3">
                  There are currently open risks and issues across{' '}
                  <strong>{risksByOpp.length} opportunit{risksByOpp.length === 1 ? 'y' : 'ies'}</strong>
                  {highSevItems.length > 0 && (
                    <>, of which <strong className="text-destructive">{highSevItems.length} are high severity or critical</strong></>
                  )}.
                </p>

                <div className="space-y-2">
                  {risksByOpp.map((opp) => {
                    const isHighRisk = opp.highSevCount > 0;
                    return (
                      <div key={opp.opportunityId} className={cn(
                        "rounded-lg border px-3 py-2 text-sm flex items-center gap-2",
                        isHighRisk ? "bg-destructive/5 border-destructive/20" : "bg-muted/20",
                      )}>
                        {isHighRisk && <AlertTriangle className="h-4 w-4 text-destructive shrink-0" />}
                        <button
                          onClick={() => navigate(`/accounts/${opp.accountId}?opportunityId=${opp.opportunityId}&tab=risks-issues`)}
                          className="font-medium text-primary hover:underline text-left"
                        >
                          {opp.opportunityName}
                        </button>
                        <span className="text-muted-foreground text-xs">({opp.accountName})</span>
                        <div className="ml-auto flex items-center gap-1.5 shrink-0">
                          {opp.riskCount > 0 && (
                            <Badge variant="outline" className="text-[10px] h-4 border-amber-500/30 text-amber-600">
                              {opp.riskCount} risk{opp.riskCount !== 1 ? 's' : ''}
                            </Badge>
                          )}
                          {opp.issueCount > 0 && (
                            <Badge variant="outline" className="text-[10px] h-4 border-destructive/30 text-destructive">
                              {opp.issueCount} issue{opp.issueCount !== 1 ? 's' : ''}
                            </Badge>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            </>
          )}

          {/* ─── Stage Movements ────────────────────── */}
          {d.stageMovementSummary.totalMovements > 0 && (
            <>
              <Separator />
              <section>
                <h2 className="text-base font-bold text-foreground mb-3 flex items-center gap-2">
                  <span className="w-1 h-5 bg-primary rounded-full" />
                  Stage Movements
                  <Badge variant="secondary" className="text-xs">{d.stageMovementSummary.totalMovements} total</Badge>
                </h2>

                {/* Forward progress – single line */}
                {d.stageMovementSummary.forwardCount > 0 && (
                  <p className="text-sm text-foreground/80 mb-4">
                    <span className="font-semibold">{d.stageMovementSummary.forwardCount}</span> deal{d.stageMovementSummary.forwardCount !== 1 ? 's' : ''} moved forward in stage.
                  </p>
                )}

                {/* Closed Won */}
                {d.stageMovementSummary.closedWon.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-emerald-600 dark:text-emerald-400 mb-2 flex items-center gap-1.5">
                      <TrendingUp className="h-3.5 w-3.5" />
                      Closed Won ({d.stageMovementSummary.closedWon.length})
                    </p>
                    <ul className="ml-4 space-y-1">
                      {d.stageMovementSummary.closedWon.map((deal, i) => (
                        <li key={i} className="text-sm flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                          <span className="font-medium">{deal.opportunityName}</span>
                          <span className="text-muted-foreground">({deal.accountName})</span>
                          {deal.value && <span className="text-muted-foreground">— {formatCurrency(deal.value)}</span>}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Closed Lost */}
                {d.stageMovementSummary.closedLost.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-destructive mb-2 flex items-center gap-1.5">
                      <TrendingDown className="h-3.5 w-3.5" />
                      Closed Lost ({d.stageMovementSummary.closedLost.length})
                    </p>
                    <ul className="ml-4 space-y-1">
                      {d.stageMovementSummary.closedLost.map((deal, i) => (
                        <li key={i} className="text-sm flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-destructive shrink-0" />
                          <span className="font-medium">{deal.opportunityName}</span>
                          <span className="text-muted-foreground">({deal.accountName})</span>
                          {deal.value && <span className="text-muted-foreground">— {formatCurrency(deal.value)}</span>}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Regressions */}
                {d.stageMovementSummary.regressions.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-amber-600 dark:text-amber-400 mb-2 flex items-center gap-1.5">
                      <AlertTriangle className="h-3.5 w-3.5" />
                      Moved Back ({d.stageMovementSummary.regressions.length})
                    </p>
                    <ul className="ml-4 space-y-1">
                      {d.stageMovementSummary.regressions.map((deal, i) => (
                        <li key={i} className="text-sm flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                          <span className="font-medium">{deal.opportunityName}</span>
                          <span className="text-muted-foreground">({deal.accountName})</span>
                          <Badge variant="outline" className="text-[10px] h-5">{deal.oldStage}</Badge>
                          <ArrowRight className="h-3 w-3 text-muted-foreground" />
                          <Badge className="text-[10px] h-5 bg-amber-500/10 text-amber-600 border-amber-500/20">{deal.newStage}</Badge>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </section>
            </>
          )}

          {/* ─── AI Situation Reports ─────────────────── */}
          {d.situationReports && d.situationReports.length > 0 && (
            <>
              <Separator />
              <section>
                <h2 className="text-base font-bold text-foreground mb-3 flex items-center gap-2">
                  <span className="w-1 h-5 bg-primary rounded-full" />
                  <Sparkles className="h-4 w-4 text-primary" />
                  Deal Situation Reports
                  <Badge variant="secondary" className="text-xs">{d.situationReports.length}</Badge>
                </h2>
                <div className="space-y-2">
                  {d.situationReports.map((report) => (
                    <div key={report.opportunityId} className="rounded-lg border bg-card p-3 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <button
                          className="text-sm font-semibold text-primary hover:underline cursor-pointer text-left"
                          onClick={() => navigate(`/accounts?opportunityId=${report.opportunityId}`)}
                        >
                          {report.opportunityName}
                        </button>
                        <span className="text-xs text-muted-foreground">{report.accountName}</span>
                      </div>
                      <p className="text-sm text-foreground/80 leading-relaxed">{report.oneLiner}</p>
                      {report.nextCriticalAction && (
                        <div className="flex items-start gap-1.5 text-xs text-amber-600 font-medium">
                          <span>⚡</span>
                          <span>{report.nextCriticalAction}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            </>
          )}

          {/* ─── Coaching Highlights ─────────────────── */}
          {d.topCoachingImprovers.length > 0 && (
            <>
              <Separator />
              <section>
                <h2 className="text-base font-bold text-foreground mb-3 flex items-center gap-2">
                  <span className="w-1 h-5 bg-amber-500 rounded-full" />
                  Top Coaching Improvers
                </h2>
                <div className="space-y-1.5">
                  {d.topCoachingImprovers.map((imp, i) => (
                    <div key={i} className="flex items-center gap-3 text-sm px-3 py-1.5 rounded-lg bg-muted/20">
                      <span className={cn(
                        "w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold",
                        i === 0 ? "bg-amber-500/20 text-amber-600" : "bg-muted text-muted-foreground"
                      )}>{i + 1}</span>
                      <span className="flex-1 font-medium">{imp.name}</span>
                      <Badge variant="outline" className="text-emerald-600 border-emerald-200 text-xs">
                        <TrendingUp className="h-3 w-3 mr-0.5" /> +{imp.delta} pts
                      </Badge>
                    </div>
                  ))}
                </div>
              </section>
            </>
          )}

          {/* ─── Best Call of the Period ────────────── */}
          {d.bestCall && (
            <>
              <Separator />
              <section>
                <h2 className="text-base font-bold text-foreground mb-3 flex items-center gap-2">
                  <span className="w-1 h-5 bg-emerald-500 rounded-full" />
                  🏆 Best Call of the Period
                  <Badge variant="secondary" className="text-xs">{d.bestCall.overallScore}/5</Badge>
                </h2>

                <div className="rounded-lg border bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/30 p-4 space-y-3">
                  {/* Call metadata */}
                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <span className="font-semibold text-foreground">{d.bestCall.seEmail}</span>
                      {d.bestCall.opportunityName && (
                        <span className="text-muted-foreground"> — {d.bestCall.opportunityName}</span>
                      )}
                      {d.bestCall.accountName && (
                        <span className="text-muted-foreground"> ({d.bestCall.accountName})</span>
                      )}
                    </div>
                    {d.bestCall.meetingDate && (
                      <span className="text-xs text-muted-foreground">
                        {format(new Date(d.bestCall.meetingDate), 'MMM d, yyyy')}
                      </span>
                    )}
                  </div>

                  {/* Greatness moment */}
                  {d.bestCall.greatnessMoment && (
                    <div className="bg-card rounded-md p-3 border">
                      <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider mb-1">Standout Moment</p>
                      <p className="text-sm text-foreground/85 leading-relaxed italic">"{d.bestCall.greatnessMoment}"</p>
                    </div>
                  )}

                  {/* Top dimensions */}
                  {d.bestCall.topDimensions.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Top Scoring Dimensions</p>
                      <div className="grid grid-cols-2 gap-2">
                        {d.bestCall.topDimensions.map((dim, i) => (
                          <div key={i} className="rounded-md bg-card border px-3 py-2 space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-medium text-foreground">{dim.name}</span>
                              <Badge variant="outline" className="text-[10px] h-4 text-emerald-600 border-emerald-300">{dim.score}/5</Badge>
                            </div>
                            <p className="text-[11px] text-muted-foreground leading-snug">
                              {dim.evidence || 'Strong execution across this dimension in the selected call.'}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Replicable techniques — structured playbook */}
                  {d.bestCall.replicablePlaybook && d.bestCall.replicablePlaybook.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                        ✨ Replicable Approaches for the Team
                      </p>
                      <ul className="space-y-2">
                        {d.bestCall.replicablePlaybook.map((play, i) => (
                          <li key={i} className="rounded-md bg-card border px-3 py-2">
                            <p className="text-sm font-medium text-foreground">{play.approach}</p>
                            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{play.howToReplicate}</p>
                            {play.whyItMatters && (
                              <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-1 italic leading-relaxed">Why: {play.whyItMatters}</p>
                            )}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </section>
            </>
          )}

          {/* ─── Notable Activities (highlighted manual meetings) ── */}
          {d.notableActivities && d.notableActivities.length > 0 && (
            <>
              <Separator />
              <section>
                <h2 className="text-base font-bold text-foreground mb-3 flex items-center gap-2">
                  <span className="w-1 h-5 bg-primary rounded-full" />
                  <MapPin className="h-4 w-4 text-primary" />
                  Notable Activities
                  <Badge variant="secondary" className="text-xs">{d.notableActivities.length}</Badge>
                </h2>
                <div className="space-y-2">
                  {d.notableActivities.map(activity => (
                    <div key={activity.id} className="rounded-lg border bg-primary/5 border-primary/20 px-4 py-3 group relative">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-[10px] border-primary/30 text-primary">
                            {activity.meetingTypeLabel}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {format(new Date(activity.meetingDate), 'MMM d, yyyy')}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          {activity.value && (
                            <span className="text-xs font-medium text-muted-foreground">
                              {formatCurrency(activity.value)}
                            </span>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive hover:bg-destructive/10"
                            onClick={() => {
                              if (window.confirm('Remove this manual meeting?')) {
                                deleteMeeting.mutate(activity.id);
                              }
                            }}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                      {(activity.opportunityName || activity.accountName) && (
                        <p className="text-sm font-medium text-foreground">
                          {activity.opportunityName}
                          {activity.accountName && (
                            <span className="text-muted-foreground font-normal"> ({activity.accountName})</span>
                          )}
                        </p>
                      )}
                      {activity.notes && (
                        <p className="text-sm text-foreground/80 mt-1">{activity.notes}</p>
                      )}
                      {activity.attendeeEmails.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {activity.attendeeEmails.map(email => (
                            <span key={email} className="text-[10px] text-muted-foreground bg-muted/50 rounded px-1.5 py-0.5">
                              {email}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-8 py-3 border-t bg-muted/20 text-center">
          <p className="text-[11px] text-muted-foreground">
            Generated {format(new Date(), "EEEE, MMMM d, yyyy 'at' h:mm a")} • SE Team Performance Report
          </p>
        </div>
      </div>

      <AddManualMeetingDialog open={addMeetingOpen} onOpenChange={setAddMeetingOpen} />
    </div>
  );
}

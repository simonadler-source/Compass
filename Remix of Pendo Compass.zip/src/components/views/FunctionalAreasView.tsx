import { useState, useMemo } from 'react';
import { 
  Layers, 
  Plus, 
  ChevronRight, 
  MessageSquareText, 
  Target, 
  Edit2, 
  Trash2,
  HelpCircle,
  Lightbulb,
  GripVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from '@/components/ui/resizable';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter 
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { 
  FunctionalArea,
  useCreateFunctionalArea,
  useDeleteFunctionalArea,
  useFunctionalAreas,
  useUpdateFunctionalArea,
} from '@/hooks/useTechnologyRepository';
import { FunctionalAreaDialog } from '@/components/dialogs/FunctionalAreaDialog';
import { 
  useDiscoveryQuestions, 
  useCreateDiscoveryQuestion, 
  useUpdateDiscoveryQuestion,
  useDeleteDiscoveryQuestion,
  useUseCaseTemplates,
  useCreateUseCaseTemplate,
  useUpdateUseCaseTemplate,
  useDeleteUseCaseTemplate,
  DiscoveryQuestion,
  UseCaseTemplate
} from '@/hooks/useFunctionalAreaDetails';
import { Skeleton } from '@/components/ui/skeleton';

const QUESTION_CATEGORIES = [
  { value: 'general', label: 'General' },
  { value: 'pain_points', label: 'Pain Points' },
  { value: 'current_state', label: 'Current State' },
  { value: 'desired_state', label: 'Desired State' },
  { value: 'metrics', label: 'Success Metrics' },
  { value: 'stakeholders', label: 'Stakeholders' },
];

const LAYER_LABELS: Record<string, string> = {
  host: 'Host',
  build: 'Build',
  adopt: 'Adopt',
  growth: 'Growth',
};

export function FunctionalAreasView() {
  const [selectedAreaId, setSelectedAreaId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('questions');
  const [questionDialogOpen, setQuestionDialogOpen] = useState(false);
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<DiscoveryQuestion | null>(null);
  const [editingTemplate, setEditingTemplate] = useState<UseCaseTemplate | null>(null);

  const [areaDialogOpen, setAreaDialogOpen] = useState(false);
  const [editingArea, setEditingArea] = useState<FunctionalArea | null>(null);
  const [deleteAreaConfirmOpen, setDeleteAreaConfirmOpen] = useState(false);
  const [areaToDelete, setAreaToDelete] = useState<FunctionalArea | null>(null);
  const { data: functionalAreas, isLoading: areasLoading } = useFunctionalAreas();
  const { data: questions = [], isLoading: questionsLoading } = useDiscoveryQuestions(selectedAreaId || undefined);
  const { data: templates = [], isLoading: templatesLoading } = useUseCaseTemplates(selectedAreaId || undefined);

  const createArea = useCreateFunctionalArea();
  const updateArea = useUpdateFunctionalArea();
  const deleteArea = useDeleteFunctionalArea();
  const createQuestion = useCreateDiscoveryQuestion();
  const updateQuestion = useUpdateDiscoveryQuestion();
  const deleteQuestion = useDeleteDiscoveryQuestion();
  const createTemplate = useCreateUseCaseTemplate();
  const updateTemplate = useUpdateUseCaseTemplate();
  const deleteTemplate = useDeleteUseCaseTemplate();

  const selectedArea = useMemo(() => 
    functionalAreas?.find(a => a.id === selectedAreaId),
    [functionalAreas, selectedAreaId]
  );

  // Group areas by layer
  const areasByLayer = useMemo(() => {
    if (!functionalAreas) return {};
    return functionalAreas.reduce((acc, area) => {
      const layer = area.layer || 'adopt';
      if (!acc[layer]) acc[layer] = [];
      acc[layer].push(area);
      return acc;
    }, {} as Record<string, typeof functionalAreas>);
  }, [functionalAreas]);

  const handleAddArea = () => {
    setEditingArea(null);
    setAreaDialogOpen(true);
  };

  const handleEditArea = (area: FunctionalArea) => {
    setEditingArea(area);
    setAreaDialogOpen(true);
  };

  const handleRequestDeleteArea = (area: FunctionalArea) => {
    setAreaToDelete(area);
    setDeleteAreaConfirmOpen(true);
  };

  const handleConfirmDeleteArea = () => {
    if (!areaToDelete) return;
    deleteArea.mutate(areaToDelete.id, {
      onSuccess: () => {
        if (selectedAreaId === areaToDelete.id) setSelectedAreaId(null);
        setDeleteAreaConfirmOpen(false);
        setAreaToDelete(null);
      },
      onError: () => {
        // mutation hook already toasts
        setDeleteAreaConfirmOpen(false);
      },
    });
  };

  const handleAddQuestion = () => {
    setEditingQuestion(null);
    setQuestionDialogOpen(true);
  };

  const handleEditQuestion = (question: DiscoveryQuestion) => {
    setEditingQuestion(question);
    setQuestionDialogOpen(true);
  };

  const handleAddTemplate = () => {
    setEditingTemplate(null);
    setTemplateDialogOpen(true);
  };

  const handleEditTemplate = (template: UseCaseTemplate) => {
    setEditingTemplate(template);
    setTemplateDialogOpen(true);
  };

  return (
    <ResizablePanelGroup direction="horizontal" className="h-full animate-fade-in">
      {/* Left: Functional Areas List */}
      <ResizablePanel defaultSize={30} minSize={22} maxSize={45} className="bg-card/50">
        <div className="p-4 border-b border-border">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Layers className="w-5 h-5 text-primary" />
                Functional Areas
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                Manage use cases and discovery questions
              </p>
            </div>
            <Button size="sm" onClick={handleAddArea} className="shrink-0">
              <Plus className="w-4 h-4 mr-1" />
              Add
            </Button>
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-3 space-y-4">
            {areasLoading ? (
              Array(4).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-20 w-full" />
              ))
            ) : (
              ['host', 'build', 'adopt', 'growth'].map(layer => {
                const areas = areasByLayer[layer] || [];
                if (areas.length === 0) return null;
                
                return (
                  <div key={layer}>
                    <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2 px-2">
                      {LAYER_LABELS[layer]} Layer
                    </div>
                    <div className="space-y-1">
                      {areas.map(area => (
                        <button
                          key={area.id}
                          onClick={() => setSelectedAreaId(area.id)}
                          className={cn(
                            "group w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all",
                            selectedAreaId === area.id
                              ? "bg-primary/10 border border-primary/30"
                              : "hover:bg-muted/50"
                          )}
                        >
                          <div 
                            className="w-3 h-3 rounded-full flex-shrink-0"
                            style={{ backgroundColor: area.color }}
                          />
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm truncate">{area.name}</div>
                            {area.description && (
                              <div className="text-xs text-muted-foreground truncate">
                                {area.description}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                handleEditArea(area);
                              }}
                              aria-label={`Edit ${area.name}`}
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                handleRequestDeleteArea(area);
                              }}
                              aria-label={`Delete ${area.name}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>

                          <ChevronRight className={cn(
                            "w-4 h-4 text-muted-foreground transition-transform",
                            selectedAreaId === area.id && "rotate-90"
                          )} />
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </ScrollArea>
      </ResizablePanel>

      <ResizableHandle withHandle />

      {/* Right: Area Details */}
      <ResizablePanel defaultSize={75} minSize={50}>
        <div className="h-full flex flex-col overflow-hidden">
        {selectedArea ? (
          <>
            {/* Header */}
            <div className="p-6 border-b border-border">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${selectedArea.color}30` }}
                  >
                    <Layers className="w-5 h-5" style={{ color: selectedArea.color }} />
                  </div>
                  <div>
                    <h1 className="page-heading">{selectedArea.name}</h1>
                    <p className="text-muted-foreground">
                      {selectedArea.description || `${LAYER_LABELS[selectedArea.layer]} layer functional area`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleEditArea(selectedArea)}>
                    <Edit2 className="w-4 h-4 mr-1" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive"
                    onClick={() => handleRequestDeleteArea(selectedArea)}
                  >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
              <div className="px-6 pt-4">
                <TabsList>
                  <TabsTrigger value="questions" className="gap-2">
                    <HelpCircle className="w-4 h-4" />
                    Discovery Questions
                    <Badge variant="secondary" className="ml-1">{questions.length}</Badge>
                  </TabsTrigger>
                  <TabsTrigger value="usecases" className="gap-2">
                    <Target className="w-4 h-4" />
                    Use Case Templates
                    <Badge variant="secondary" className="ml-1">{templates.length}</Badge>
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="questions" className="flex-1 overflow-auto p-6 pt-4">
                <div className="flex justify-between items-center mb-4">
                  <p className="text-sm text-muted-foreground">
                    Questions to ask during discovery calls for this functional area
                  </p>
                  <Button size="sm" onClick={handleAddQuestion}>
                    <Plus className="w-4 h-4 mr-1" />
                    Add Question
                  </Button>
                </div>

                {questionsLoading ? (
                  <div className="space-y-3">
                    {Array(3).fill(0).map((_, i) => (
                      <Skeleton key={i} className="h-20 w-full" />
                    ))}
                  </div>
                ) : questions.length === 0 ? (
                  <Card className="border-dashed">
                    <CardContent className="flex flex-col items-center justify-center py-12">
                      <HelpCircle className="w-12 h-12 text-muted-foreground/50 mb-4" />
                      <p className="text-muted-foreground text-center">
                        No discovery questions defined yet
                      </p>
                      <Button variant="outline" className="mt-4" onClick={handleAddQuestion}>
                        <Plus className="w-4 h-4 mr-1" />
                        Add First Question
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-3">
                    {questions.map((question, index) => (
                      <Card key={question.id} className="group">
                        <CardContent className="flex items-start gap-3 p-4">
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <GripVertical className="w-4 h-4 opacity-0 group-hover:opacity-100" />
                            <span className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-xs font-medium text-primary">
                              {index + 1}
                            </span>
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">{question.question}</p>
                            <Badge variant="outline" className="mt-2 text-xs">
                              {QUESTION_CATEGORIES.find(c => c.value === question.category)?.label || question.category}
                            </Badge>
                          </div>
                          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8"
                              onClick={() => handleEditQuestion(question)}
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8 text-destructive"
                              onClick={() => deleteQuestion.mutate(question.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="usecases" className="flex-1 overflow-auto p-6 pt-4">
                <div className="flex justify-between items-center mb-4">
                  <p className="text-sm text-muted-foreground">
                    Reusable use case templates that can be applied to accounts
                  </p>
                  <Button size="sm" onClick={handleAddTemplate}>
                    <Plus className="w-4 h-4 mr-1" />
                    Add Template
                  </Button>
                </div>

                {templatesLoading ? (
                  <div className="space-y-3">
                    {Array(3).fill(0).map((_, i) => (
                      <Skeleton key={i} className="h-24 w-full" />
                    ))}
                  </div>
                ) : templates.length === 0 ? (
                  <Card className="border-dashed">
                    <CardContent className="flex flex-col items-center justify-center py-12">
                      <Lightbulb className="w-12 h-12 text-muted-foreground/50 mb-4" />
                      <p className="text-muted-foreground text-center">
                        No use case templates defined yet
                      </p>
                      <Button variant="outline" className="mt-4" onClick={handleAddTemplate}>
                        <Plus className="w-4 h-4 mr-1" />
                        Add First Template
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2">
                    {templates.map((template) => (
                      <Card key={template.id} className="group">
                        <CardHeader className="pb-2">
                          <div className="flex items-start justify-between">
                            <CardTitle className="text-base">{template.name}</CardTitle>
                            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-7 w-7"
                                onClick={() => handleEditTemplate(template)}
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-7 w-7 text-destructive"
                                onClick={() => deleteTemplate.mutate(template.id)}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </Button>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          {template.description && (
                            <p className="text-sm text-muted-foreground mb-2">
                              {template.description}
                            </p>
                          )}
                          {template.example_outcomes && (
                            <div className="text-xs bg-muted/50 rounded p-2 mt-2">
                              <span className="font-medium">Expected Outcomes:</span> {template.example_outcomes}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <Layers className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-muted-foreground">Select a Functional Area</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Choose an area from the left to manage its discovery questions and use cases
              </p>
            </div>
          </div>
        )}
        </div>
      </ResizablePanel>

      {/* Functional Area Dialog */}
      <FunctionalAreaDialog
        open={areaDialogOpen}
        onOpenChange={setAreaDialogOpen}
        existingArea={editingArea}
        defaultSortOrder={functionalAreas?.length || 0}
        onCreate={(area) =>
          createArea.mutate(area, {
            onSuccess: (created) => {
              setSelectedAreaId(created.id);
            },
          })
        }
        onUpdate={(area) => updateArea.mutate(area)}
      />

      {/* Delete Functional Area Confirm */}
      <AlertDialog open={deleteAreaConfirmOpen} onOpenChange={setDeleteAreaConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete functional area?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the functional area. Any discovery questions and use case templates linked to it may also become orphaned.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setAreaToDelete(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDeleteArea}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Question Dialog */}
      <QuestionDialog
        open={questionDialogOpen}
        onOpenChange={setQuestionDialogOpen}
        functionalAreaId={selectedAreaId || ''}
        existingQuestion={editingQuestion}
        onCreate={(q) => createQuestion.mutate(q)}
        onUpdate={(q) => updateQuestion.mutate(q)}
      />

      {/* Template Dialog */}
      <TemplateDialog
        open={templateDialogOpen}
        onOpenChange={setTemplateDialogOpen}
        functionalAreaId={selectedAreaId || ''}
        existingTemplate={editingTemplate}
        onCreate={(t) => createTemplate.mutate(t)}
        onUpdate={(t) => updateTemplate.mutate(t)}
      />
    </ResizablePanelGroup>
  );
}

// Question Dialog Component
function QuestionDialog({
  open,
  onOpenChange,
  functionalAreaId,
  existingQuestion,
  onCreate,
  onUpdate,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  functionalAreaId: string;
  existingQuestion: DiscoveryQuestion | null;
  onCreate: (q: Omit<DiscoveryQuestion, 'id' | 'created_at' | 'updated_at'>) => void;
  onUpdate: (q: Partial<DiscoveryQuestion> & { id: string }) => void;
}) {
  const [question, setQuestion] = useState('');
  const [category, setCategory] = useState('general');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    if (existingQuestion) {
      onUpdate({
        id: existingQuestion.id,
        question,
        category,
      });
    } else {
      onCreate({
        functional_area_id: functionalAreaId,
        question,
        category,
        sort_order: 0,
        is_active: true,
      });
    }

    onOpenChange(false);
    setQuestion('');
    setCategory('general');
  };

  // Reset form when dialog opens
  useState(() => {
    if (open && existingQuestion) {
      setQuestion(existingQuestion.question);
      setCategory(existingQuestion.category);
    } else if (open) {
      setQuestion('');
      setCategory('general');
    }
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{existingQuestion ? 'Edit Question' : 'Add Discovery Question'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Question</Label>
            <Textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="What question should be asked during discovery?"
              rows={3}
              required
            />
          </div>
          <div className="space-y-2">
            <Label>Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {QUESTION_CATEGORIES.map(cat => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!question.trim()}>
              {existingQuestion ? 'Update' : 'Add Question'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Template Dialog Component
function TemplateDialog({
  open,
  onOpenChange,
  functionalAreaId,
  existingTemplate,
  onCreate,
  onUpdate,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  functionalAreaId: string;
  existingTemplate: UseCaseTemplate | null;
  onCreate: (t: Omit<UseCaseTemplate, 'id' | 'created_at' | 'updated_at'>) => void;
  onUpdate: (t: Partial<UseCaseTemplate> & { id: string }) => void;
}) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [outcomes, setOutcomes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (existingTemplate) {
      onUpdate({
        id: existingTemplate.id,
        name,
        description: description || null,
        example_outcomes: outcomes || null,
      });
    } else {
      onCreate({
        functional_area_id: functionalAreaId,
        name,
        description: description || null,
        example_outcomes: outcomes || null,
        sort_order: 0,
        is_active: true,
      });
    }

    onOpenChange(false);
    setName('');
    setDescription('');
    setOutcomes('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{existingTemplate ? 'Edit Template' : 'Add Use Case Template'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Use Case Name</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Track feature adoption rates"
              required
            />
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe this use case..."
              rows={2}
            />
          </div>
          <div className="space-y-2">
            <Label>Expected Outcomes</Label>
            <Textarea
              value={outcomes}
              onChange={(e) => setOutcomes(e.target.value)}
              placeholder="What outcomes should customers expect?"
              rows={2}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!name.trim()}>
              {existingTemplate ? 'Update' : 'Add Template'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

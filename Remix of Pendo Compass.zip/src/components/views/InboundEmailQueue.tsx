import { useState } from 'react';
import { Mail, Building2, Target, Check, X, ExternalLink, Clock, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useAccounts } from '@/hooks/useAccounts';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface InboundEmail {
  id: string;
  from_email: string;
  from_name: string | null;
  to_emails: string[];
  cc_emails: string[];
  subject: string | null;
  text_body: string | null;
  match_status: string;
  matched_account_id: string | null;
  matched_opportunity_id: string | null;
  match_confidence: number;
  match_method: string | null;
  match_details: Record<string, unknown> | null;
  email_sent_at: string | null;
  received_at: string;
  review_notes: string | null;
}

export function InboundEmailQueue({ onNavigateToAccount }: { onNavigateToAccount?: (id: string) => void }) {
  const queryClient = useQueryClient();
  const { data: accounts } = useAccounts();
  const [selectedAccountMap, setSelectedAccountMap] = useState<Record<string, string>>({});
  const [reviewNotes, setReviewNotes] = useState<Record<string, string>>({});

  const { data: emails, isLoading } = useQuery({
    queryKey: ['inbound-emails-queue'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('inbound_emails')
        .select('*')
        .in('match_status', ['review', 'matched', 'pending'])
        .order('received_at', { ascending: false })
        .limit(50);
      if (error) throw error;
      return (data || []) as InboundEmail[];
    },
  });

  const processEmail = useMutation({
    mutationFn: async ({ emailId, accountId, action }: { emailId: string; accountId?: string; action: 'approve' | 'reject' }) => {
      if (action === 'reject') {
        await supabase.from('inbound_emails').update({
          match_status: 'rejected',
          review_notes: reviewNotes[emailId] || null,
        }).eq('id', emailId);
        return;
      }

      const finalAccountId = accountId;
      if (!finalAccountId) throw new Error('No account selected');

      // Find best opportunity for account
      const { data: opps } = await supabase
        .from('opportunities')
        .select('id, name')
        .eq('account_id', finalAccountId)
        .eq('is_archived', false)
        .order('updated_at', { ascending: false })
        .limit(1);

      const oppId = opps?.[0]?.id || null;

      // Get the email text
      const email = emails?.find(e => e.id === emailId);
      if (!email?.text_body) throw new Error('Email has no text content');

      // Create transcript review
      const { data: review, error: reviewError } = await supabase
        .from('transcript_reviews')
        .insert({
          transcript_content: email.text_body,
          file_name: `Email: ${email.subject || 'No Subject'}`,
          suggested_account_id: finalAccountId,
          suggested_account_confidence: 1.0,
          opportunity_id: oppId,
          status: 'approved',
          content_type: 'email',
          extracted_insights: {
            source: 'inbound_email',
            inbound_email_id: emailId,
            from: email.from_email,
            subject: email.subject,
            email_sent_at: email.email_sent_at,
          },
        })
        .select('id')
        .single();

      if (reviewError) throw reviewError;

      // Update email record
      await supabase.from('inbound_emails').update({
        match_status: 'processed',
        matched_account_id: finalAccountId,
        matched_opportunity_id: oppId,
        match_confidence: 1.0,
        match_method: 'manual',
        transcript_review_id: review.id,
        processed_at: new Date().toISOString(),
        review_notes: reviewNotes[emailId] || null,
      }).eq('id', emailId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inbound-emails-queue'] });
      toast.success('Email processed successfully');
    },
    onError: (err) => {
      toast.error(`Failed to process: ${err instanceof Error ? err.message : 'Unknown error'}`);
    },
  });

  const reviewEmails = emails?.filter(e => e.match_status === 'review' || e.match_status === 'pending') || [];
  const matchedEmails = emails?.filter(e => e.match_status === 'matched') || [];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!emails || emails.length === 0) {
    return (
      <div className="glass rounded-xl p-8 text-center">
        <Mail className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-muted-foreground">No inbound emails awaiting review</p>
        <p className="text-sm text-muted-foreground mt-1">
          Forwarded emails will appear here for matching and processing
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Needs Review */}
      {reviewEmails.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            Needs Review ({reviewEmails.length})
          </h3>
          {reviewEmails.map(email => (
            <EmailCard
              key={email.id}
              email={email}
              accounts={accounts || []}
              selectedAccount={selectedAccountMap[email.id]}
              onAccountChange={(val) => setSelectedAccountMap(prev => ({ ...prev, [email.id]: val }))}
              reviewNote={reviewNotes[email.id] || ''}
              onReviewNoteChange={(val) => setReviewNotes(prev => ({ ...prev, [email.id]: val }))}
              onApprove={() => processEmail.mutate({
                emailId: email.id,
                accountId: selectedAccountMap[email.id] || email.matched_account_id || undefined,
                action: 'approve',
              })}
              onReject={() => processEmail.mutate({ emailId: email.id, action: 'reject' })}
              isProcessing={processEmail.isPending}
              onNavigateToAccount={onNavigateToAccount}
            />
          ))}
        </div>
      )}

      {/* Auto-Matched (pending confirmation) */}
      {matchedEmails.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <Check className="w-4 h-4" />
            Auto-Matched ({matchedEmails.length})
          </h3>
          {matchedEmails.map(email => (
            <EmailCard
              key={email.id}
              email={email}
              accounts={accounts || []}
              selectedAccount={selectedAccountMap[email.id] || email.matched_account_id || ''}
              onAccountChange={(val) => setSelectedAccountMap(prev => ({ ...prev, [email.id]: val }))}
              reviewNote={reviewNotes[email.id] || ''}
              onReviewNoteChange={(val) => setReviewNotes(prev => ({ ...prev, [email.id]: val }))}
              onApprove={() => processEmail.mutate({
                emailId: email.id,
                accountId: selectedAccountMap[email.id] || email.matched_account_id || undefined,
                action: 'approve',
              })}
              onReject={() => processEmail.mutate({ emailId: email.id, action: 'reject' })}
              isProcessing={processEmail.isPending}
              onNavigateToAccount={onNavigateToAccount}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function EmailCard({
  email,
  accounts,
  selectedAccount,
  onAccountChange,
  reviewNote,
  onReviewNoteChange,
  onApprove,
  onReject,
  isProcessing,
  onNavigateToAccount,
}: {
  email: InboundEmail;
  accounts: Array<{ id: string; name: string }>;
  selectedAccount: string | undefined;
  onAccountChange: (val: string) => void;
  reviewNote: string;
  onReviewNoteChange: (val: string) => void;
  onApprove: () => void;
  onReject: () => void;
  isProcessing: boolean;
  onNavigateToAccount?: (id: string) => void;
}) {
  const matchedAccount = accounts.find(a => a.id === (selectedAccount || email.matched_account_id));
  const confidencePct = Math.round((email.match_confidence || 0) * 100);

  return (
    <Card className="glass">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="space-y-1 flex-1 min-w-0">
            <CardTitle className="text-sm font-medium truncate">
              {email.subject || 'No Subject'}
            </CardTitle>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Mail className="w-3 h-3" />
                {email.from_name || email.from_email}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {email.email_sent_at
                  ? format(new Date(email.email_sent_at), 'MMM d, yyyy h:mm a')
                  : format(new Date(email.received_at), 'MMM d, yyyy h:mm a')}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 ml-3">
            {email.match_method && (
              <Badge variant="outline" className="text-xs">
                {email.match_method === 'ai_fallback' ? 'AI' : email.match_method.replace('_', ' ')}
              </Badge>
            )}
            {confidencePct > 0 && (
              <Badge variant={confidencePct >= 70 ? 'default' : confidencePct >= 40 ? 'secondary' : 'outline'} className="text-xs">
                {confidencePct}%
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Recipients */}
        <div className="text-xs text-muted-foreground">
          <span className="font-medium">To:</span> {email.to_emails?.join(', ') || '—'}
          {email.cc_emails?.length > 0 && (
            <span className="ml-3"><span className="font-medium">CC:</span> {email.cc_emails.join(', ')}</span>
          )}
        </div>

        {/* Preview */}
        {email.text_body && (
          <p className="text-xs text-muted-foreground line-clamp-3 bg-muted/30 rounded p-2">
            {email.text_body.slice(0, 300)}
          </p>
        )}

        {/* Account selector */}
        <div className="flex items-center gap-2">
          <Building2 className="w-4 h-4 text-muted-foreground shrink-0" />
          <Select value={selectedAccount || email.matched_account_id || ''} onValueChange={onAccountChange}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue placeholder="Select account..." />
            </SelectTrigger>
            <SelectContent>
              {accounts.map(a => (
                <SelectItem key={a.id} value={a.id} className="text-xs">{a.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {matchedAccount && onNavigateToAccount && (
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onNavigateToAccount(matchedAccount.id)}>
              <ExternalLink className="w-3 h-3" />
            </Button>
          )}
        </div>

        {/* Notes */}
        <Textarea
          placeholder="Review notes (optional)..."
          value={reviewNote}
          onChange={(e) => onReviewNoteChange(e.target.value)}
          className="text-xs min-h-[40px] h-10"
        />

        {/* Actions */}
        <div className="flex gap-2 justify-end">
          <Button variant="outline" size="sm" onClick={onReject} disabled={isProcessing}>
            <X className="w-3 h-3 mr-1" />
            Reject
          </Button>
          <Button size="sm" onClick={onApprove} disabled={isProcessing || !(selectedAccount || email.matched_account_id)}>
            {isProcessing ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Check className="w-3 h-3 mr-1" />}
            Approve & Analyze
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

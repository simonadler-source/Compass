import { useState } from 'react';
import { SlackChannelPicker } from '@/components/SlackChannelPicker';
import { Link2, Check, Settings, ExternalLink, Calendar, Database, Cloud, Zap, RefreshCw, Clock, Mic, MessageSquare, Plus, X, Hash, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

const POLLING_OPTIONS = [
  { value: '15', label: 'Every 15 minutes' },
  { value: '30', label: 'Every 30 minutes' },
  { value: '60', label: 'Every hour' },
  { value: '240', label: 'Every 4 hours' },
  { value: '360', label: 'Every 6 hours' },
  { value: '720', label: 'Every 12 hours' },
  { value: '1440', label: 'Every 24 hours' },
];

const CHANNEL_PURPOSE_OPTIONS = [
  { value: 'competitive', label: 'Competitive Intel', description: 'Extract competitor signals, pricing, win/loss stories' },
  { value: 'account', label: 'Account Updates', description: 'Link to an account for pain points, use cases, stakeholder signals' },
  { value: 'opportunity', label: 'Opportunity Updates', description: 'Link to an opportunity for deal-specific signals' },
  { value: 'general', label: 'General Intel', description: 'Broad signal extraction without specific linking' },
];

interface SlackChannel {
  id: string;
  name: string;
  purpose: 'competitive' | 'account' | 'opportunity' | 'general';
  linked_account_id?: string;
  linked_opportunity_id?: string;
  last_sync_at?: string;
  last_sync_status?: 'success' | 'error' | 'syncing';
  last_sync_signals?: number;
}

interface Integration {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  connected: boolean;
  status?: 'active' | 'syncing' | 'error';
  lastSync?: Date;
}

export function IntegrationsView() {
  const queryClient = useQueryClient();
  
  // Fetch all data integrations
  const { data: dataIntegrations } = useQuery({
    queryKey: ['data-integrations'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('data_integrations')
        .select('*')
        .order('created_at', { ascending: true });
      if (error) throw error;
      return data || [];
    },
  });

  const gongIntegration = dataIntegrations?.find((i: any) => i.provider === 'gong');
  const slackIntegration = dataIntegrations?.find((i: any) => i.provider === 'slack');
  const momentumIntegrationData = dataIntegrations?.find((i: any) => i.provider === 'momentum');

  // Fetch Momentum sync state (legacy — still used for meeting counts)
  const { data: momentumSyncState } = useQuery({
    queryKey: ['momentum-sync-state'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('momentum_sync_state')
        .select('*')
        .order('last_sync_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  // Derived momentum enabled state from database
  const momentumEnabled = momentumSyncState?.is_enabled ?? true;

  // Toggle Momentum enabled mutation
  const toggleMomentumMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      if (!momentumSyncState?.id) {
        // Create initial record if none exists
        const { error } = await supabase
          .from('momentum_sync_state')
          .insert({ is_enabled: enabled });
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('momentum_sync_state')
          .update({ is_enabled: enabled })
          .eq('id', momentumSyncState.id);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['momentum-sync-state'] });
    },
    onError: (error) => {
      toast.error('Failed to update Momentum status: ' + error.message);
    },
  });

  // Sync Momentum mutation
  const syncMomentum = useMutation({
    mutationFn: async ({ fullSync = false }: { fullSync?: boolean } = {}) => {
      const endpoint = fullSync ? 'sync-momentum?fullSync=true' : 'sync-momentum';
      const { data, error } = await supabase.functions.invoke(endpoint);
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['momentum-sync-state'] });
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
      toast.success(`Synced ${data?.newMeetings || data?.meetings_synced || 0} meetings from Momentum`);
    },
    onError: (error) => {
      toast.error('Failed to sync Momentum: ' + error.message);
    },
  });

  // Sync Gong mutation
  const syncGong = useMutation({
    mutationFn: async ({ fullSync = false }: { fullSync?: boolean } = {}) => {
      const endpoint = fullSync ? 'sync-gong?fullSync=true' : 'sync-gong';
      const { data, error } = await supabase.functions.invoke(endpoint);
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
      toast.success(`Synced ${data?.newMeetings || 0} calls from Gong`);
    },
    onError: (error) => {
      toast.error('Failed to sync Gong: ' + error.message);
    },
  });

  // Sync Slack mutation
  const syncSlack = useMutation({
    mutationFn: async () => {
      const channels: SlackChannel[] = (slackIntegration?.config as any)?.channels || [];
      if (channels.length === 0) throw new Error('No Slack channels configured');
      let totalSignals = 0;
      const updatedChannels = [...channels];
      for (let i = 0; i < updatedChannels.length; i++) {
        const ch = updatedChannels[i];
        updatedChannels[i] = { ...ch, last_sync_status: 'syncing' as const };
        // Update status in DB so UI reflects syncing
        if (slackIntegration?.id) {
          await supabase.from('data_integrations').update({ config: { ...(slackIntegration.config as any || {}), channels: updatedChannels } }).eq('id', slackIntegration.id);
          queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
        }
        try {
          const { data, error } = await supabase.functions.invoke('ingest-competitive-slack', {
            body: { channelId: ch.id, channelPurpose: ch.purpose || 'competitive', linkedAccountId: ch.linked_account_id, linkedOpportunityId: ch.linked_opportunity_id, lookbackHours: 24 },
          });
          if (error) throw error;
          const signals = data?.signals_inserted || 0;
          totalSignals += signals;
          updatedChannels[i] = { ...ch, last_sync_status: 'success' as const, last_sync_at: new Date().toISOString(), last_sync_signals: signals };
        } catch (err: any) {
          updatedChannels[i] = { ...ch, last_sync_status: 'error' as const, last_sync_at: new Date().toISOString() };
          console.error(`Slack sync error for #${ch.name}:`, err);
        }
      }
      // Final update with all statuses
      if (slackIntegration?.id) {
        await supabase.from('data_integrations').update({
          config: { ...(slackIntegration.config as any || {}), channels: updatedChannels },
          last_sync_at: new Date().toISOString(),
          last_sync_status: updatedChannels.every(c => c.last_sync_status === 'success') ? 'success' : 'partial',
        }).eq('id', slackIntegration.id);
      }
      return { totalSignals, channelCount: channels.length };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
      toast.success(`Pulled ${data.totalSignals} signals from ${data.channelCount} channel(s)`);
    },
    onError: (error) => {
      queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
      toast.error('Failed to sync Slack: ' + error.message);
    },
  });

  // Slack channel management
  const [newChannelId, setNewChannelId] = useState('');
  const [newChannelName, setNewChannelName] = useState('');
  const [showChannelPicker, setShowChannelPicker] = useState(false);
  const [newChannelPurpose, setNewChannelPurpose] = useState<SlackChannel['purpose']>('competitive');

  const addSlackChannel = async () => {
    if (!newChannelId.trim() || !newChannelName.trim()) {
      toast.error('Both channel ID and name are required');
      return;
    }
    const existing = slackIntegration;
    const currentChannels: SlackChannel[] = (existing?.config as any)?.channels || [];
    if (currentChannels.some(c => c.id === newChannelId.trim())) {
      toast.error('Channel already added');
      return;
    }
    const newChannel: SlackChannel = {
      id: newChannelId.trim(),
      name: newChannelName.trim(),
      purpose: newChannelPurpose,
    };
    const updatedChannels = [...currentChannels, newChannel];
    try {
      if (existing?.id) {
        const { error } = await supabase.from('data_integrations').update({ config: { ...(existing.config as any || {}), channels: updatedChannels } }).eq('id', existing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('data_integrations').insert([{ provider: 'slack', display_name: 'Slack', is_enabled: true, polling_interval_minutes: 240, config: { channels: updatedChannels } as any }]);
        if (error) throw error;
      }
      queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
      setNewChannelId('');
      setNewChannelName('');
      setNewChannelPurpose('competitive');
      toast.success(`Added #${newChannel.name} (${CHANNEL_PURPOSE_OPTIONS.find(p => p.value === newChannelPurpose)?.label})`);
    } catch (err: any) {
      toast.error('Failed to add channel: ' + (err.message || 'Unknown error'));
    }
  };

  const removeSlackChannel = async (channelId: string) => {
    if (!slackIntegration?.id) return;
    const currentChannels: SlackChannel[] = (slackIntegration.config as any)?.channels || [];
    const updatedChannels = currentChannels.filter(c => c.id !== channelId);
    const { error } = await supabase.from('data_integrations').update({ config: { ...(slackIntegration.config as any || {}), channels: updatedChannels } }).eq('id', slackIntegration.id);
    if (error) {
      toast.error('Failed to remove channel: ' + error.message);
      return;
    }
    queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
    toast.success('Channel removed');
  };

  // Toggle integration enabled state
  const toggleIntegrationMutation = useMutation({
    mutationFn: async ({ provider, enabled }: { provider: string; enabled: boolean }) => {
      const existing = dataIntegrations?.find((i: any) => i.provider === provider);
      if (existing) {
        const { error } = await supabase
          .from('data_integrations')
          .update({ is_enabled: enabled })
          .eq('id', existing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('data_integrations')
          .insert({ provider, display_name: provider.charAt(0).toUpperCase() + provider.slice(1), is_enabled: enabled });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
    },
    onError: (error) => {
      toast.error('Failed to update integration: ' + error.message);
    },
  });

  const [integrations, setIntegrations] = useState<Integration[]>([
    {
      id: 'salesforce',
      name: 'Salesforce',
      description: 'Sync account data and update opportunity fields automatically',
      icon: Cloud,
      connected: false,
    },
    {
      id: 'google-calendar',
      name: 'Google Calendar',
      description: 'Track external meetings and discover new accounts',
      icon: Calendar,
      connected: false,
    },
    {
      id: 'outlook',
      name: 'Microsoft Outlook',
      description: 'Sync calendar and email data for meeting analysis',
      icon: Calendar,
      connected: false,
    },
  ]);
  
  // Polling periods for each integration
  const [pollingPeriods, setPollingPeriods] = useState<Record<string, string>>({
    momentum: '1440',
    salesforce: '60',
    'google-calendar': '30',
    outlook: '30',
  });

  const updatePollingPeriod = (integrationId: string, value: string) => {
    setPollingPeriods(prev => ({ ...prev, [integrationId]: value }));
    toast.success(`Polling period updated to ${POLLING_OPTIONS.find(o => o.value === value)?.label}`);
  };

  // Create Momentum integration object
  const momentumIntegration: Integration = {
    id: 'momentum',
    name: 'Momentum',
    description: 'Import meeting transcripts and insights from Momentum AI',
    icon: Zap,
    connected: !!momentumSyncState && momentumEnabled,
    lastSync: momentumSyncState?.last_sync_at ? new Date(momentumSyncState.last_sync_at) : undefined,
    status: syncMomentum.isPending ? 'syncing' : momentumEnabled ? 'active' : undefined,
  };

  const [showConfig, setShowConfig] = useState<string | null>(null);

  const toggleConnection = (id: string) => {
    setIntegrations(prev => prev.map(i => 
      i.id === id ? { ...i, connected: !i.connected, lastSync: i.connected ? undefined : new Date() } : i
    ));
  };

  const toggleMomentum = () => {
    const newEnabled = !momentumEnabled;
    toggleMomentumMutation.mutate(newEnabled);
    toast.success(newEnabled ? 'Momentum integration enabled' : 'Momentum integration disabled');
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="page-heading">Integrations</h1>
        <p className="text-muted-foreground mt-1">
          Connect your tools to automate data flow
        </p>
      </div>

      {/* Integration Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Momentum Integration - Featured */}
        <div
          className={cn(
            "glass rounded-xl p-5 animate-slide-up lg:col-span-2",
            momentumIntegration.connected && "ring-1 ring-primary/50"
          )}
        >
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-4">
              <div className={cn(
                "w-12 h-12 rounded-xl flex items-center justify-center",
                momentumIntegration.connected ? "bg-primary/20" : "bg-muted"
              )}>
                <Zap className={cn(
                  "w-6 h-6",
                  momentumIntegration.connected ? "text-primary" : "text-muted-foreground"
                )} />
              </div>
              <div>
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  {momentumIntegration.name}
                  {momentumIntegration.connected && (
                    <span className="inline-flex items-center gap-1 text-xs text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                      <Check className="w-3 h-3" />
                      Connected
                    </span>
                  )}
                  {momentumIntegration.status === 'syncing' && (
                    <span className="inline-flex items-center gap-1 text-xs text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full">
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      Syncing
                    </span>
                  )}
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  {momentumIntegration.description}
                </p>
                {momentumIntegration.connected && momentumIntegration.lastSync && (
                  <p className="text-xs text-muted-foreground mt-2">
                    Last synced: {new Date(momentumIntegration.lastSync).toLocaleString()}
                    {momentumSyncState?.meetings_synced !== undefined && (
                      <span className="ml-2">• {momentumSyncState.meetings_synced} meetings</span>
                    )}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowConfig(showConfig === 'momentum' ? null : 'momentum')}
              >
                <Settings className="w-4 h-4" />
                Configure
              </Button>
              {momentumEnabled && (
                <>
                  <Button
                    variant="glow"
                    size="sm"
                    onClick={() => syncMomentum.mutate({})}
                    disabled={syncMomentum.isPending}
                  >
                    <RefreshCw className={cn("w-4 h-4", syncMomentum.isPending && "animate-spin")} />
                    {syncMomentum.isPending ? 'Syncing...' : 'Sync Now'}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => syncMomentum.mutate({ fullSync: true })}
                    disabled={syncMomentum.isPending}
                    title="Sync all meetings from the last 30 days"
                  >
                    Full Sync
                  </Button>
                </>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                {momentumEnabled ? 'Active' : 'Disabled'}
              </span>
              <Switch
                checked={momentumEnabled}
                onCheckedChange={toggleMomentum}
              />
            </div>
          </div>

          {/* Momentum Config Panel */}
          {showConfig === 'momentum' && (
            <div className="mt-4 pt-4 border-t border-border space-y-4 animate-scale-in">
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  Polling Period
                </Label>
                <Select 
                  value={pollingPeriods.momentum} 
                  onValueChange={(value) => updatePollingPeriod('momentum', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {POLLING_OPTIONS.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Auto-sync meetings</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Auto-detect NBA completions</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Extract technologies from transcripts</span>
                <Switch defaultChecked />
              </div>
              <p className="text-xs text-muted-foreground">
                Momentum meetings are synced and matched to accounts automatically. 
                Visit the <a href="/momentum" className="text-primary hover:underline">Momentum page</a> to review and import meetings.
              </p>
            </div>
          )}
        </div>

        {/* Gong Integration - Featured */}
        <div
          className={cn(
            "glass rounded-xl p-5 animate-slide-up lg:col-span-2",
            gongIntegration?.is_enabled && "ring-1 ring-primary/50"
          )}
        >
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-4">
              <div className={cn(
                "w-12 h-12 rounded-xl flex items-center justify-center",
                gongIntegration?.is_enabled ? "bg-primary/20" : "bg-muted"
              )}>
                <Mic className={cn(
                  "w-6 h-6",
                  gongIntegration?.is_enabled ? "text-primary" : "text-muted-foreground"
                )} />
              </div>
              <div>
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  Gong
                  {gongIntegration?.is_enabled && (
                    <span className="inline-flex items-center gap-1 text-xs text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                      <Check className="w-3 h-3" />
                      Connected
                    </span>
                  )}
                  {syncGong.isPending && (
                    <span className="inline-flex items-center gap-1 text-xs text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full">
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      Syncing
                    </span>
                  )}
                  {gongIntegration?.last_sync_status === 'error' && (
                    <span className="inline-flex items-center gap-1 text-xs text-destructive bg-destructive/10 px-2 py-0.5 rounded-full">
                      Error
                    </span>
                  )}
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Import call recordings, transcripts, and conversation intelligence from Gong
                </p>
                {gongIntegration?.last_sync_at && (
                  <p className="text-xs text-muted-foreground mt-2">
                    Last synced: {new Date(gongIntegration.last_sync_at).toLocaleString()}
                    {gongIntegration.last_sync_meetings_count !== undefined && (
                      <span className="ml-2">• {gongIntegration.last_sync_meetings_count} calls</span>
                    )}
                  </p>
                )}
                {gongIntegration?.last_sync_status === 'error' && gongIntegration?.last_sync_error && (
                  <p className="text-xs text-destructive mt-1">
                    {gongIntegration.last_sync_error}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowConfig(showConfig === 'gong' ? null : 'gong')}
              >
                <Settings className="w-4 h-4" />
                Configure
              </Button>
              {gongIntegration?.is_enabled && (
                <>
                  <Button
                    variant="glow"
                    size="sm"
                    onClick={() => syncGong.mutate({})}
                    disabled={syncGong.isPending}
                  >
                    <RefreshCw className={cn("w-4 h-4", syncGong.isPending && "animate-spin")} />
                    {syncGong.isPending ? 'Syncing...' : 'Sync Now'}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => syncGong.mutate({ fullSync: true })}
                    disabled={syncGong.isPending}
                    title="Sync all calls from the last 30 days"
                  >
                    Full Sync
                  </Button>
                </>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                {gongIntegration?.is_enabled ? 'Active' : 'Disabled'}
              </span>
              <Switch
                checked={gongIntegration?.is_enabled ?? false}
                onCheckedChange={(checked) => {
                  toggleIntegrationMutation.mutate({ provider: 'gong', enabled: checked });
                  toast.success(checked ? 'Gong integration enabled' : 'Gong integration disabled');
                }}
              />
            </div>
          </div>

          {/* Gong Config Panel */}
          {showConfig === 'gong' && (
            <div className="mt-4 pt-4 border-t border-border space-y-4 animate-scale-in">
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  Polling Period
                </Label>
                <Select 
                  value={String(gongIntegration?.polling_interval_minutes || 60)} 
                  onValueChange={async (value) => {
                    if (gongIntegration?.id) {
                      await supabase.from('data_integrations').update({ polling_interval_minutes: parseInt(value) }).eq('id', gongIntegration.id);
                      queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
                    }
                    toast.success(`Polling period updated to ${POLLING_OPTIONS.find(o => o.value === value)?.label}`);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {POLLING_OPTIONS.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Auto-sync calls</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Import talk metrics (talk ratio, monologues)</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Extract CRM associations</span>
                <Switch defaultChecked />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">API Credentials</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Access Key</Label>
                    <Input
                      type="password"
                      placeholder="Enter Gong Access Key"
                      defaultValue={(gongIntegration?.config as any)?.access_key ? '••••••••' : ''}
                      onBlur={async (e) => {
                        const val = e.target.value;
                        if (!val || val === '••••••••') return;
                        if (gongIntegration?.id) {
                          await supabase.from('data_integrations').update({ 
                            config: { ...(gongIntegration.config as any || {}), access_key: val } 
                          }).eq('id', gongIntegration.id);
                          queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
                          toast.success('Gong Access Key saved');
                        }
                      }}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Access Key Secret</Label>
                    <Input
                      type="password"
                      placeholder="Enter Gong Access Key Secret"
                      defaultValue={(gongIntegration?.config as any)?.access_key_secret ? '••••••••' : ''}
                      onBlur={async (e) => {
                        const val = e.target.value;
                        if (!val || val === '••••••••') return;
                        if (gongIntegration?.id) {
                          await supabase.from('data_integrations').update({ 
                            config: { ...(gongIntegration.config as any || {}), access_key_secret: val } 
                          }).eq('id', gongIntegration.id);
                          queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
                          toast.success('Gong Access Key Secret saved');
                        }
                      }}
                    />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Find your API credentials in Gong → Settings → API. Keys are stored encrypted.
                </p>
              </div>
              <p className="text-xs text-muted-foreground">
                Gong calls are synced and matched to accounts using CRM associations and attendee domains.
              </p>
            </div>
          )}
        </div>

        {/* Slack Integration */}
        <div
          className={cn(
            "glass rounded-xl p-5 animate-slide-up lg:col-span-2",
            slackIntegration?.is_enabled && "ring-1 ring-primary/50"
          )}
        >
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-4">
              <div className={cn(
                "w-12 h-12 rounded-xl flex items-center justify-center",
                slackIntegration?.is_enabled ? "bg-primary/20" : "bg-muted"
              )}>
                <MessageSquare className={cn(
                  "w-6 h-6",
                  slackIntegration?.is_enabled ? "text-primary" : "text-muted-foreground"
                )} />
              </div>
              <div>
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  Slack
                  {slackIntegration?.is_enabled && (
                    <span className="inline-flex items-center gap-1 text-xs text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                      <Check className="w-3 h-3" />
                      Connected
                    </span>
                  )}
                  {syncSlack.isPending && (
                    <span className="inline-flex items-center gap-1 text-xs text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full">
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      Syncing
                    </span>
                  )}
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Pull competitive intelligence from Slack channels. Messages are AI-analyzed for competitor signals.
                </p>
                {slackIntegration?.last_sync_at && (
                  <p className="text-xs text-muted-foreground mt-2">
                    Last synced: {new Date(slackIntegration.last_sync_at).toLocaleString()}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowConfig(showConfig === 'slack' ? null : 'slack')}
              >
                <Settings className="w-4 h-4" />
                Configure
              </Button>
              {slackIntegration?.is_enabled && (
                <Button
                  variant="glow"
                  size="sm"
                  onClick={() => syncSlack.mutate()}
                  disabled={syncSlack.isPending || !((slackIntegration?.config as any)?.channels?.length > 0)}
                >
                  <RefreshCw className={cn("w-4 h-4", syncSlack.isPending && "animate-spin")} />
                  {syncSlack.isPending ? 'Pulling...' : 'Pull Now'}
                </Button>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                {slackIntegration?.is_enabled ? 'Active' : 'Disabled'}
              </span>
              <Switch
                checked={slackIntegration?.is_enabled ?? false}
                onCheckedChange={(checked) => {
                  toggleIntegrationMutation.mutate({ provider: 'slack', enabled: checked });
                  toast.success(checked ? 'Slack integration enabled' : 'Slack integration disabled');
                }}
              />
            </div>
          </div>

          {/* Slack Config Panel */}
          {showConfig === 'slack' && (
            <div className="mt-4 pt-4 border-t border-border space-y-4 animate-scale-in">
              {/* Polling Period */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  Polling Period
                </Label>
                <Select 
                  value={String(slackIntegration?.polling_interval_minutes || 240)} 
                  onValueChange={async (value) => {
                    if (slackIntegration?.id) {
                      await supabase.from('data_integrations').update({ polling_interval_minutes: parseInt(value) }).eq('id', slackIntegration.id);
                      queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
                    }
                    toast.success(`Polling period updated to ${POLLING_OPTIONS.find(o => o.value === value)?.label}`);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {POLLING_OPTIONS.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Configured Channels */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Monitored Channels</Label>
                {((slackIntegration?.config as any)?.channels || []).length === 0 ? (
                  <p className="text-xs text-muted-foreground">No channels configured yet. Add a channel below.</p>
                ) : (
                  <div className="space-y-2">
                    {((slackIntegration?.config as any)?.channels || []).map((ch: SlackChannel) => (
                      <div key={ch.id} className="flex items-center gap-3 bg-muted/50 rounded-lg px-3 py-2.5 text-sm">
                        <Hash className="w-4 h-4 text-muted-foreground shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{ch.name}</span>
                            <span className="text-xs text-muted-foreground font-mono">({ch.id})</span>
                          </div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs px-1.5 py-0.5 rounded bg-primary/10 text-primary">
                              {CHANNEL_PURPOSE_OPTIONS.find(p => p.value === (ch.purpose || 'competitive'))?.label || ch.purpose}
                            </span>
                            {ch.last_sync_at && (
                              <span className="text-xs text-muted-foreground">
                                Last sync: {new Date(ch.last_sync_at).toLocaleString()}
                              </span>
                            )}
                            {ch.last_sync_status === 'success' && (
                              <CheckCircle2 className="w-3.5 h-3.5 text-primary" />
                            )}
                            {ch.last_sync_status === 'error' && (
                              <AlertCircle className="w-3.5 h-3.5 text-destructive" />
                            )}
                            {ch.last_sync_status === 'syncing' && (
                              <Loader2 className="w-3.5 h-3.5 text-muted-foreground animate-spin" />
                            )}
                            {ch.last_sync_signals != null && ch.last_sync_signals > 0 && (
                              <span className="text-xs text-muted-foreground">{ch.last_sync_signals} signals</span>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={() => removeSlackChannel(ch.id)}
                          className="text-muted-foreground hover:text-destructive transition-colors shrink-0"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Add Channel */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">Add Channel</Label>
                {showChannelPicker ? (
                  <div className="space-y-2">
                    <SlackChannelPicker
                      onSelect={async (ch) => {
                        const newChannel: SlackChannel = {
                          id: ch.id,
                          name: ch.name,
                          purpose: newChannelPurpose,
                        };
                        const existing = slackIntegration;
                        const currentChannels: SlackChannel[] = (existing?.config as any)?.channels || [];
                        if (currentChannels.some(c => c.id === ch.id)) {
                          toast.error('Channel already added');
                          return;
                        }
                        const updatedChannels = [...currentChannels, newChannel];
                        try {
                          if (existing?.id) {
                            const { error } = await supabase.from('data_integrations').update({
                              config: { ...(existing.config as any || {}), channels: updatedChannels },
                              is_enabled: true,
                              polling_interval_minutes: existing.polling_interval_minutes ?? 240,
                            }).eq('id', existing.id);
                            if (error) throw error;
                          } else {
                            const { error } = await supabase.from('data_integrations').insert([{ provider: 'slack', display_name: 'Slack', is_enabled: true, polling_interval_minutes: 240, config: { channels: updatedChannels } as any }]);
                            if (error) throw error;
                          }
                          queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
                          setShowChannelPicker(false);
                          setNewChannelPurpose('competitive');
                          toast.success(`Added #${ch.name} (${CHANNEL_PURPOSE_OPTIONS.find(p => p.value === newChannelPurpose)?.label})`);
                        } catch (err: any) {
                          toast.error('Failed to add channel: ' + (err.message || 'Unknown error'));
                        }
                      }}
                      excludeIds={((slackIntegration?.config as any)?.channels || []).map((c: SlackChannel) => c.id)}
                    />
                    <div className="flex items-center gap-2">
                      <Select value={newChannelPurpose} onValueChange={(v) => setNewChannelPurpose(v as SlackChannel['purpose'])}>
                        <SelectTrigger className="w-[200px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {CHANNEL_PURPOSE_OPTIONS.map(opt => (
                            <SelectItem key={opt.value} value={opt.value}>
                              <div>
                                <div className="font-medium">{opt.label}</div>
                                <div className="text-xs text-muted-foreground">{opt.description}</div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button variant="ghost" size="sm" onClick={() => setShowChannelPicker(false)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Button variant="outline" size="sm" onClick={() => setShowChannelPicker(true)} className="gap-2">
                    <Plus className="w-4 h-4" />
                    Add Channel
                  </Button>
                )}
              </div>

              {/* Processing info */}
              <div className="space-y-2 rounded-lg bg-muted/50 p-3">
                <Label className="text-sm font-medium">How channels are processed</Label>
                <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
                  <li><strong>Competitive Intel:</strong> Extracts competitor signals (pricing, weaknesses, win/loss stories) → competitive audit pipeline</li>
                  <li><strong>Account Updates:</strong> Extracts pain points, use cases, stakeholder signals → linked account</li>
                  <li><strong>Opportunity Updates:</strong> Extracts deal-specific signals, risk flags → linked opportunity</li>
                  <li>Thread replies are automatically collected and concatenated</li>
                  <li>Channels are polled on the configured schedule (default: every 4 hours)</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Other Integrations */}
        {integrations.map((integration, index) => {
          const Icon = integration.icon;
          
          return (
            <div
              key={integration.id}
              className={cn(
                "glass rounded-xl p-5 animate-slide-up",
                integration.connected && "ring-1 ring-primary/50"
              )}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center",
                    integration.connected ? "bg-primary/20" : "bg-muted"
                  )}>
                    <Icon className={cn(
                      "w-6 h-6",
                      integration.connected ? "text-primary" : "text-muted-foreground"
                    )} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground flex items-center gap-2">
                      {integration.name}
                      {integration.connected && (
                        <span className="inline-flex items-center gap-1 text-xs text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                          <Check className="w-3 h-3" />
                          Connected
                        </span>
                      )}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {integration.description}
                    </p>
                    {integration.connected && integration.lastSync && (
                      <p className="text-xs text-muted-foreground mt-2">
                        Last synced: {new Date(integration.lastSync).toLocaleString()}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowConfig(showConfig === integration.id ? null : integration.id)}
                >
                  <Settings className="w-4 h-4" />
                  Configure
                </Button>
                <Switch
                  checked={integration.connected}
                  onCheckedChange={() => toggleConnection(integration.id)}
                />
              </div>

              {/* Config Panel */}
              {showConfig === integration.id && (
                <div className="mt-4 pt-4 border-t border-border space-y-4 animate-scale-in">
                  {/* Polling Period - Common to all */}
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2 text-sm">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      Polling Period
                    </Label>
                    <Select 
                      value={pollingPeriods[integration.id] || '60'} 
                      onValueChange={(value) => updatePollingPeriod(integration.id, value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {POLLING_OPTIONS.map(option => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {integration.id === 'salesforce' && (
                    <>
                      <div>
                        <label className="text-xs text-muted-foreground block mb-1">
                          Salesforce Instance URL
                        </label>
                        <Input placeholder="https://yourcompany.salesforce.com" />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Auto-sync accounts</span>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Update opportunity fields</span>
                        <Switch defaultChecked />
                      </div>
                      <Button className="w-full" variant="glow">
                        <ExternalLink className="w-4 h-4" />
                        Authorize with Salesforce
                      </Button>
                    </>
                  )}

                  {(integration.id === 'google-calendar' || integration.id === 'outlook') && (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Detect external meetings</span>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Auto-create accounts from meetings</span>
                        <Switch />
                      </div>
                      <Button className="w-full" variant="glow">
                        <ExternalLink className="w-4 h-4" />
                        Connect {integration.name}
                      </Button>
                    </>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Coming Soon */}
      <div className="mt-8">
        <h2 className="text-lg font-semibold mb-4 text-muted-foreground">Coming Soon</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {['HubSpot', 'Zoom', 'Google Drive'].map((name) => (
            <div 
              key={name}
              className="glass rounded-xl p-4 opacity-50"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                  <Link2 className="w-5 h-5 text-muted-foreground" />
                </div>
                <div>
                  <h3 className="font-medium text-foreground">{name}</h3>
                  <p className="text-xs text-muted-foreground">Coming soon</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

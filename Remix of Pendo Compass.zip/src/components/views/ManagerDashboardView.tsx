import { useState, useMemo, lazy, Suspense } from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useNavigate, Link } from 'react-router-dom';
import { useManagerDashboard, OpportunityAlert } from '@/hooks/useManagerDashboard';
import { useTeamMemberMetrics, TIME_RANGES, RangeKey, getDateRangeForKey } from '@/hooks/useTeamMemberMetrics';
import { useTeamHierarchy } from '@/hooks/useTeamHierarchy';
import { useOrgTree, collectSubtreeEmails } from '@/hooks/useOrgTree';
import OrgTreePicker from '@/components/OrgTreePicker';
import { useUserRole } from '@/hooks/useUserRole';
import { useMultipleTabAccess } from '@/hooks/useTabAccess';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import TeamMemberWeeklyHeatmap from './TeamMemberWeeklyHeatmap';
import SECoachingTab from './SECoachingTab';
import { 
  AlertTriangle, 
  AlertCircle, 
  Info, 
  Users, 
  DollarSign, 
  Calendar,
  Clock,
  UserMinus,
  Target,
  TrendingDown,
  FileQuestion,
  Presentation,
  Building2,
  ChevronRight,
  ChevronDown,
  RefreshCw,
  Settings,
  BarChart3,
  ShieldAlert,
  Video,
  FileText,
  CheckCircle2,
  Briefcase,
  UserCog,
  Zap,
  PlayCircle,
  FileCheck,
  Gauge,
  Lightbulb,
  Award,
  FlaskConical,
  Sparkles
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { OneOnOnePrepSheet } from '@/components/OneOnOnePrepSheet';
import EvaluationRadarTab from './EvaluationRadarTab';
import TeamManualMeetingsSection from '@/components/TeamManualMeetingsSection';
const ExecWeeklySummaryTab = lazy(() => import('./ExecWeeklySummaryTab'));

const getAlertTypeIcon = (alertType: string): React.ReactNode => {
  const icons: Record<string, React.ReactNode> = {
    no_recent_meetings: <Clock className="h-4 w-4" />,
    stalled_stage: <TrendingDown className="h-4 w-4" />,
    missing_stakeholders: <UserMinus className="h-4 w-4" />,
    readiness_below_threshold: <FileQuestion className="h-4 w-4" />,
    unanswered_questions_count: <FileQuestion className="h-4 w-4" />,
    stale_readiness: <Clock className="h-4 w-4" />,
    advanced: <Target className="h-4 w-4" />,
    custom: <Target className="h-4 w-4" />,
    // AI Coaching types - violet to differentiate from warning alerts
    ai_coaching: <Lightbulb className="h-4 w-4 text-violet-500" />,
    stale_champion: <Clock className="h-4 w-4 text-violet-500" />,
    no_executive_sponsor: <UserMinus className="h-4 w-4 text-violet-500" />,
    engagement_decline: <TrendingDown className="h-4 w-4 text-violet-500" />,
    deal_velocity_slow: <Clock className="h-4 w-4 text-violet-500" />,
    competitor_mentioned: <ShieldAlert className="h-4 w-4 text-violet-500" />,
    // Legacy types for backwards compatibility
    low_readiness: <FileQuestion className="h-4 w-4" />,
    no_metrics: <Target className="h-4 w-4" />,
    no_economic_buyer: <DollarSign className="h-4 w-4" />,
    no_reverse_demo: <Presentation className="h-4 w-4" />,
    low_discovery: <Info className="h-4 w-4" />,
    technical_red_flags: <ShieldAlert className="h-4 w-4" />,
  };
  return icons[alertType] || <AlertCircle className="h-4 w-4" />;
};

// Helper to detect inferred stage from signals
function getDetectedStage(signals: Record<string, { detected_at: string }> | null): { stage: string | null; signal: string | null } {
  if (!signals) return { stage: null, signal: null };
  
  // Check signals in priority order
  if (signals.technical_win || signals.legal) {
    return { stage: 'Stage 4', signal: signals.technical_win ? 'Technical Win' : 'Legal' };
  }
  if (signals.evaluation_poc) {
    return { stage: 'Stage 3', signal: 'Evaluation/POC' };
  }
  if (signals.demo_request) {
    return { stage: 'Stage 1', signal: 'Demo Request' };
  }
  return { stage: null, signal: null };
}

// Helper to get readiness score color
function getReadinessColor(score: number | null): string {
  if (score === null) return 'text-muted-foreground';
  if (score >= 70) return 'text-green-600';
  if (score >= 40) return 'text-amber-600';
  return 'text-red-600';
}

function getReadinessBgColor(score: number | null): string {
  if (score === null) return 'bg-muted';
  if (score >= 70) return 'bg-green-500/20';
  if (score >= 40) return 'bg-amber-500/20';
  return 'bg-red-500/20';
}

// Enhanced opportunity card row showing stages, signals, and readiness
function OpportunityInfoRow({ 
  opp 
}: { 
  opp: {
    sales_stage?: string | null;
    pre_sales_stage?: string | null;
    readiness_score?: number | null;
    detection_signal_fields?: Record<string, { detected_at: string }> | null;
  }
}) {
  const detected = getDetectedStage(opp.detection_signal_fields || null);
  const hasSignals = opp.detection_signal_fields && Object.keys(opp.detection_signal_fields).length > 0;
  
  return (
    <div className="flex flex-wrap items-center gap-2 mt-2 text-xs">
      {/* Sales Stage */}
      {opp.sales_stage && (
        <Badge variant="outline" className="text-xs font-normal">
          <BarChart3 className="h-3 w-3 mr-1 text-blue-500" />
          CRM: {opp.sales_stage}
        </Badge>
      )}
      
      {/* Detected Stage (if different) */}
      {detected.stage && detected.stage !== opp.sales_stage && (
        <Badge variant="outline" className="text-xs font-normal border-amber-500/50 text-amber-700">
          <Zap className="h-3 w-3 mr-1" />
          Detected: {detected.stage}
        </Badge>
      )}
      
      {/* Pre-Sales Stage */}
      {opp.pre_sales_stage && (
        <Badge variant="outline" className="text-xs font-normal">
          <PlayCircle className="h-3 w-3 mr-1 text-purple-500" />
          {opp.pre_sales_stage}
        </Badge>
      )}
      
      {/* Activity Signals */}
      {hasSignals && (
        <>
          {opp.detection_signal_fields?.demo_request && (
            <Badge variant="secondary" className="text-xs bg-blue-500/10 text-blue-700">
              <Presentation className="h-3 w-3 mr-1" />
              Demo
            </Badge>
          )}
          {opp.detection_signal_fields?.evaluation_poc && (
            <Badge variant="secondary" className="text-xs bg-green-500/10 text-green-700">
              <FileCheck className="h-3 w-3 mr-1" />
              POC
            </Badge>
          )}
          {opp.detection_signal_fields?.technical_win && (
            <Badge variant="secondary" className="text-xs bg-emerald-500/10 text-emerald-700">
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Tech Win
            </Badge>
          )}
        </>
      )}
      
      {/* Readiness Score */}
      {opp.readiness_score !== null && opp.readiness_score !== undefined && (
        <Badge 
          variant="outline" 
          className={cn("text-xs font-medium", getReadinessBgColor(opp.readiness_score), getReadinessColor(opp.readiness_score))}
        >
          <Gauge className="h-3 w-3 mr-1" />
          {opp.readiness_score}% Ready
        </Badge>
      )}
    </div>
  );
}

function AlertCard({ alert, onClick }: { alert: OpportunityAlert; onClick: () => void }) {
  const isCoachingAlert = alert.ruleName === 'AI Coaching';
  
  const levelColors = {
    critical: 'border-l-destructive bg-destructive/5',
    warning: 'border-l-yellow-500 bg-yellow-500/5',
    info: 'border-l-blue-500 bg-blue-500/5',
  };

  const levelIcons = {
    critical: <AlertTriangle className="h-4 w-4 text-destructive" />,
    warning: <AlertCircle className="h-4 w-4 text-yellow-500" />,
    info: <Info className="h-4 w-4 text-blue-500" />,
  };

  // AI Coaching alerts get distinct purple/violet styling to differentiate from warning alerts
  const cardColor = isCoachingAlert 
    ? 'border-l-violet-500 bg-gradient-to-r from-violet-500/10 to-purple-500/5' 
    : levelColors[alert.alertLevel];
  
  const cardIcon = isCoachingAlert 
    ? <Lightbulb className="h-4 w-4 text-violet-500" />
    : levelIcons[alert.alertLevel];

  return (
    <Card 
      className={cn(
        "border-l-4 cursor-pointer hover:shadow-md transition-shadow",
        cardColor
      )}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <div className="mt-0.5">
              {cardIcon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-medium text-foreground truncate">
                  {alert.opportunityName}
                </span>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-xs",
                    isCoachingAlert && "border-violet-500/50 bg-violet-500/10 text-violet-700"
                  )}
                >
                  {getAlertTypeIcon(alert.alertType)}
                  <span className="ml-1">{alert.ruleName}</span>
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {alert.alertMessage}
              </p>
              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Building2 className="h-3 w-3" />
                  {alert.accountName}
                </span>
                {alert.ownerName && (
                  <span className="flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    {alert.ownerName}
                  </span>
                )}
                {alert.closeDate && (
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    Close: {format(new Date(alert.closeDate), 'MMM d')}
                  </span>
                )}
                {alert.value && (
                  <span className="flex items-center gap-1">
                    <DollarSign className="h-3 w-3" />
                    ${(alert.value / 1000).toFixed(0)}k
                  </span>
                )}
              </div>
            </div>
          </div>
          <ChevronRight className="h-5 w-5 text-muted-foreground shrink-0" />
        </div>
      </CardContent>
    </Card>
  );
}

function TeamMemberSection({ 
  email, 
  name, 
  alerts, 
  onAlertClick,
  onOpportunityClick
}: { 
  email: string; 
  name: string | null;
  alerts: OpportunityAlert[];
  onAlertClick: (alert: OpportunityAlert) => void;
  onOpportunityClick: (opportunityId: string) => void;
}) {
  const criticalCount = alerts.filter(a => a.alertLevel === 'critical').length;
  const warningCount = alerts.filter(a => a.alertLevel === 'warning').length;

  // Group alerts by opportunity
  const byOpportunity = alerts.reduce((acc, alert) => {
    if (!acc[alert.opportunityId]) {
      acc[alert.opportunityId] = {
        opportunityId: alert.opportunityId,
        opportunityName: alert.opportunityName,
        accountId: alert.accountId,
        accountName: alert.accountName,
        value: alert.value,
        closeDate: alert.closeDate,
        alerts: [],
      };
    }
    acc[alert.opportunityId].alerts.push(alert);
    return acc;
  }, {} as Record<string, { opportunityId: string; opportunityName: string; accountId: string; accountName: string; value: number | null; closeDate: string | null; alerts: OpportunityAlert[] }>);

  const opportunities = Object.values(byOpportunity).sort((a, b) => {
    const aCritical = a.alerts.filter(al => al.alertLevel === 'critical').length;
    const bCritical = b.alerts.filter(al => al.alertLevel === 'critical').length;
    return bCritical - aCritical;
  });

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
            <Users className="h-4 w-4 text-primary" />
          </div>
          <div>
            <p className="font-medium">{name || email}</p>
            {name && <p className="text-xs text-muted-foreground">{email}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {criticalCount > 0 && (
            <Badge variant="destructive" className="text-xs">
              {criticalCount} critical
            </Badge>
          )}
          {warningCount > 0 && (
            <Badge variant="secondary" className="text-xs bg-yellow-500/20 text-yellow-700">
              {warningCount} warning
            </Badge>
          )}
        </div>
      </div>
      <div className="space-y-3 pl-10">
        {opportunities.map(opp => {
          const oppCritical = opp.alerts.filter(a => a.alertLevel === 'critical').length;
          const oppWarning = opp.alerts.filter(a => a.alertLevel === 'warning').length;
          
          return (
            <Card 
              key={opp.opportunityId} 
              className={cn(
                "border-l-4 overflow-hidden",
                oppCritical > 0 ? "border-l-destructive" : oppWarning > 0 ? "border-l-yellow-500" : "border-l-blue-500"
              )}
            >
              <div 
                className="p-3 cursor-pointer hover:bg-muted/50 transition-colors flex items-center justify-between"
                onClick={() => onOpportunityClick(opp.opportunityId)}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm">{opp.opportunityName}</span>
                    {oppCritical > 0 && (
                      <Badge variant="destructive" className="text-xs">{oppCritical} critical</Badge>
                    )}
                    {oppWarning > 0 && (
                      <Badge variant="secondary" className="text-xs bg-yellow-500/20 text-yellow-700">
                        {oppWarning} warning
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Building2 className="h-3 w-3" />
                      {opp.accountName}
                    </span>
                    {opp.closeDate && (
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {format(new Date(opp.closeDate), 'MMM d')}
                      </span>
                    )}
                    {opp.value && (
                      <span className="flex items-center gap-1">
                        <DollarSign className="h-3 w-3" />
                        ${(opp.value / 1000).toFixed(0)}k
                      </span>
                    )}
                  </div>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
              </div>
              <div className="px-3 pb-3 space-y-1.5">
                {opp.alerts.map(alert => (
                  <div 
                    key={alert.id}
                    className={cn(
                      "p-2 rounded text-xs cursor-pointer hover:opacity-80 transition-opacity",
                      alert.alertLevel === 'critical' && "bg-destructive/10",
                      alert.alertLevel === 'warning' && "bg-yellow-500/10",
                      alert.alertLevel === 'info' && "bg-blue-500/10"
                    )}
                    onClick={(e) => {
                      e.stopPropagation();
                      onAlertClick(alert);
                    }}
                  >
                    <div className="flex items-center gap-2">
                      {getAlertTypeIcon(alert.alertType)}
                      <span className="text-muted-foreground">{alert.ruleName}</span>
                    </div>
                    <p className="text-muted-foreground mt-0.5 pl-6">{alert.alertMessage}</p>
                  </div>
                ))}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

export default function ManagerDashboardView() {
  const navigate = useNavigate();
  const { alerts, alertsByOwner, opportunities, stats, hierarchyTeamMembers, teamEmailsWithSelf, isLoading } = useManagerDashboard();
  const { directReports } = useTeamHierarchy();
  const { roots, nodeMap, currentUserId } = useOrgTree();
  const { isAdmin, isManager, isSE, profile } = useUserRole();
  const [selectedRange, setSelectedRange] = useState<RangeKey>('this_week');
  const { metrics, teamTotals, isLoading: metricsLoading } = useTeamMemberMetrics(selectedRange);
  const rangeLabel = getDateRangeForKey(selectedRange).label;
  const [syncing, setSyncing] = useState(false);
  const [expandedMembers, setExpandedMembers] = useState<Set<string>>(new Set());
  const [expandedMemberOpps, setExpandedMemberOpps] = useState<Set<string>>(new Set());
  const [prepSheetMember, setPrepSheetMember] = useState<{ email: string; name: string | null } | null>(null);
  const [selectedHierarchyNodeId, setSelectedHierarchyNodeId] = useState<string | null>(null);

  // Hierarchy filter: default to current user, compute filtered emails
  const effectiveHierarchyId = selectedHierarchyNodeId || currentUserId || null;
  const selectedHierarchyNode = effectiveHierarchyId ? nodeMap.get(effectiveHierarchyId) : null;
  const filteredTeamEmails = useMemo(() => {
    if (selectedHierarchyNode) return collectSubtreeEmails(selectedHierarchyNode);
    return teamEmailsWithSelf || [];
  }, [selectedHierarchyNode, teamEmailsWithSelf]);

  // Derive a lowercase set for quick filtering
  const filteredEmailSet = useMemo(() => new Set(filteredTeamEmails.map(e => e.toLowerCase().trim())), [filteredTeamEmails]);

  // Filter metrics and team members by hierarchy selection
  const filteredMetrics = useMemo(() => {
    if (!filteredEmailSet.size) return metrics;
    return metrics.filter(m => filteredEmailSet.has(m.email.toLowerCase().trim()));
  }, [metrics, filteredEmailSet]);

  const filteredHierarchyTeamMembers = useMemo(() => {
    if (!filteredEmailSet.size) return hierarchyTeamMembers || [];
    return (hierarchyTeamMembers || []).filter(m => filteredEmailSet.has(m.email.toLowerCase().trim()));
  }, [hierarchyTeamMembers, filteredEmailSet]);

  // Filter opportunities and alerts by hierarchy selection
  const filteredOpportunities = useMemo(() => {
    if (!filteredEmailSet.size) return opportunities;
    return opportunities.filter(opp =>
      (opp.owner_email && filteredEmailSet.has(opp.owner_email.toLowerCase().trim())) ||
      (opp.primary_se_email && filteredEmailSet.has(opp.primary_se_email.toLowerCase().trim()))
    );
  }, [opportunities, filteredEmailSet]);

  const filteredAlerts = useMemo(() => {
    const filteredOppIds = new Set(filteredOpportunities.map(o => o.id));
    return alerts.filter(a => filteredOppIds.has(a.opportunityId));
  }, [alerts, filteredOpportunities]);

  // All team members can see the full team coaching view
  const seOnlyEmailFilter = undefined;
  
  // Check tab-level access permissions
  const { canAccessTab } = useMultipleTabAccess('/manager-dashboard', ['accounts', 'opportunities', 'team', 'alerts', 'manage']);

  const toggleMemberExpanded = (email: string) => {
    setExpandedMembers(prev => {
      const next = new Set(prev);
      if (next.has(email)) {
        next.delete(email);
      } else {
        next.add(email);
      }
      return next;
    });
  };

  const toggleMemberOppsExpanded = (memberId: string) => {
    setExpandedMemberOpps(prev => {
      const next = new Set(prev);
      if (next.has(memberId)) {
        next.delete(memberId);
      } else {
        next.add(memberId);
      }
      return next;
    });
  };
  
  // Only show Manage Team tab if user has direct reports (is a manager)
  const hasDirectReports = (directReports?.length || 0) > 0;

  const handleAlertClick = (alert: OpportunityAlert) => {
    // Navigate directly to the opportunity, not the account
    navigate(`/opportunities/${alert.opportunityId}`);
  };

  const handleSync = async () => {
    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('sync-momentum');
      if (error) throw error;
      toast.success(`Synced ${data.newMeetings || 0} new meetings`);
    } catch (error) {
      toast.error('Failed to sync meetings');
    } finally {
      setSyncing(false);
    }
  };

  const handleBackfill = async () => {
    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('backfill-team-members');
      if (error) throw error;
      toast.success(`Assigned team members: ${data.accountAssignments || 0} accounts, ${data.opportunityAssignments || 0} opportunities`);
    } catch (error) {
      toast.error('Failed to backfill team assignments');
    } finally {
      setSyncing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-heading">Team Dashboard</h1>
          <p className="text-muted-foreground">Monitor your team's opportunities and remove blockers</p>
        </div>
        <div className="flex items-center gap-2">
          {roots.length > 0 && (
            <OrgTreePicker
              roots={roots}
              selectedId={effectiveHierarchyId}
              onSelect={(node) => setSelectedHierarchyNodeId(node.id)}
            />
          )}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button onClick={handleBackfill} disabled={syncing} variant="outline" size="sm">
                  <Users className={cn("h-4 w-4 mr-2", syncing && "animate-spin")} />
                  Backfill Team Assignments
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="max-w-[280px]">
                <p>Scans imported meetings for internal attendees and automatically assigns them to the matching account and opportunity teams.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button onClick={handleSync} disabled={syncing} variant="outline">
                  <RefreshCw className={cn("h-4 w-4 mr-2", syncing && "animate-spin")} />
                  Sync Meetings
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="max-w-[280px]">
                <p>Pulls the latest meetings from Momentum and imports any new ones that haven't been synced yet.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-2xl font-bold">{stats.teamMemberCount}</p>
                  <p className="text-xs text-muted-foreground">Team Members</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Target className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-2xl font-bold">{stats.activeOpportunities}</p>
                  <p className="text-xs text-muted-foreground">Active Opportunities</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-2xl font-bold">${(stats.totalPipelineValue / 1000000).toFixed(1)}M</p>
                  <p className="text-xs text-muted-foreground">Pipeline Value</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-destructive/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-destructive" />
                <div>
                  <p className="text-2xl font-bold text-destructive">{stats.criticalAlerts}</p>
                  <p className="text-xs text-muted-foreground">Critical Alerts</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-yellow-500/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-yellow-500" />
                <div>
                  <p className="text-2xl font-bold text-yellow-600">{stats.warningAlerts}</p>
                  <p className="text-xs text-muted-foreground">Warnings</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs defaultValue="accounts" className="space-y-4">
        <TabsList>
          {canAccessTab('accounts') && <TabsTrigger value="accounts">By Account</TabsTrigger>}
          {canAccessTab('opportunities') && <TabsTrigger value="opportunities">By Opportunity</TabsTrigger>}
          {canAccessTab('team') && <TabsTrigger value="team">By Team Member</TabsTrigger>}
          {canAccessTab('alerts') && <TabsTrigger value="alerts">All Alerts</TabsTrigger>}
          <TabsTrigger value="evaluations">
            <FlaskConical className="h-4 w-4 mr-1" />
            Eval Radar
          </TabsTrigger>
          <TabsTrigger value="coaching">
            <Award className="h-4 w-4 mr-1" />
            Coaching
          </TabsTrigger>
          {hasDirectReports && canAccessTab('manage') && <TabsTrigger value="manage">Manage Team</TabsTrigger>}
          <TabsTrigger value="exec-summary">
            <Sparkles className="h-4 w-4 mr-1" />
            Exec Summary
          </TabsTrigger>
        </TabsList>

        <TabsContent value="accounts" className="space-y-4">
          <ScrollArea className="h-[calc(100vh-350px)]">
            {(() => {
              // Group ALL opportunities by account (not just those with alerts)
              const byAccount = filteredOpportunities.reduce((acc, opp) => {
                const accountId = opp.account_id;
                const accountName = opp.accounts?.name || 'Unknown Account';
                if (!acc[accountId]) {
                  acc[accountId] = {
                    accountId,
                    accountName,
                    opportunities: [],
                    alerts: [] as OpportunityAlert[],
                    totalValue: 0,
                  };
                }
                acc[accountId].opportunities.push(opp);
                acc[accountId].totalValue += opp.value || 0;
                // Add any alerts for this opportunity
                const oppAlerts = filteredAlerts.filter(a => a.opportunityId === opp.id);
                acc[accountId].alerts.push(...oppAlerts);
                return acc;
              }, {} as Record<string, { accountId: string; accountName: string; opportunities: typeof opportunities; alerts: OpportunityAlert[]; totalValue: number }>);
              
              const accounts = Object.values(byAccount).sort((a, b) => {
                // Sort by critical alerts first, then by value
                const aCritical = a.alerts.filter(al => al.alertLevel === 'critical').length;
                const bCritical = b.alerts.filter(al => al.alertLevel === 'critical').length;
                if (aCritical !== bCritical) return bCritical - aCritical;
                return b.totalValue - a.totalValue;
              });

              if (accounts.length === 0) {
                return (
                  <Card>
                    <CardContent className="p-8 text-center">
                      <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <h3 className="font-medium text-lg">No accounts</h3>
                      <p className="text-muted-foreground">
                        No accounts found for your team
                      </p>
                    </CardContent>
                  </Card>
                );
              }

              return (
                <div className="space-y-4">
                  {accounts.map(account => {
                    const criticalCount = account.alerts.filter(a => a.alertLevel === 'critical').length;
                    const warningCount = account.alerts.filter(a => a.alertLevel === 'warning').length;
                    // Get AE/SE from first opportunity
                    const firstOpp = account.opportunities[0];
                    return (
                      <Card key={account.accountId} className="overflow-hidden">
                        <CardHeader 
                          className="cursor-pointer hover:bg-muted/50 transition-colors"
                          onClick={() => navigate(`/accounts/${account.accountId}`)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                                <Building2 className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <CardTitle className="text-lg">{account.accountName}</CardTitle>
                                <CardDescription>
                                  {account.opportunities.length} opportunities · ${(account.totalValue / 1000).toFixed(0)}k pipeline
                                </CardDescription>
                                {firstOpp && (
                                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                                    {firstOpp.owner_email && (
                                      <span className="flex items-center gap-1">
                                        <Briefcase className="h-3 w-3 text-blue-500" />
                                        AE: {firstOpp.owner_email}
                                      </span>
                                    )}
                                    {firstOpp.primary_se_email && (
                                      <span className="flex items-center gap-1">
                                        <UserCog className="h-3 w-3 text-green-500" />
                                        SE: {firstOpp.primary_se_email}
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {criticalCount > 0 && (
                                <Badge variant="destructive">{criticalCount} critical</Badge>
                              )}
                              {warningCount > 0 && (
                                <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-700">
                                  {warningCount} warning
                                </Badge>
                              )}
                              <ChevronRight className="h-5 w-5 text-muted-foreground" />
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0 pb-4">
                          {/* Show opportunities first */}
                          <div className="space-y-2 pl-13">
                            {account.opportunities.slice(0, 5).map(opp => {
                              const oppAlerts = account.alerts.filter(a => a.opportunityId === opp.id);
                              const oppCritical = oppAlerts.filter(a => a.alertLevel === 'critical').length;
                              const oppWarning = oppAlerts.filter(a => a.alertLevel === 'warning').length;
                              return (
                                <div 
                                  key={opp.id}
                                  className={cn(
                                    "p-3 rounded-lg border-l-4 cursor-pointer hover:bg-muted/50",
                                    oppCritical > 0 ? "border-l-destructive bg-destructive/5" :
                                    oppWarning > 0 ? "border-l-yellow-500 bg-yellow-500/5" :
                                    "border-l-muted-foreground/30"
                                  )}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    navigate(`/opportunities/${opp.id}`);
                                  }}
                                >
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                      <Target className="h-4 w-4 text-muted-foreground" />
                                      <span className="font-medium text-sm">{opp.name}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      {oppCritical > 0 && (
                                        <Badge variant="destructive" className="text-xs">{oppCritical}</Badge>
                                      )}
                                      {oppWarning > 0 && (
                                        <Badge variant="secondary" className="text-xs bg-yellow-500/20 text-yellow-700">{oppWarning}</Badge>
                                      )}
                                      {opp.value && (
                                        <span className="text-xs text-muted-foreground">${(opp.value / 1000).toFixed(0)}k</span>
                                      )}
                                    </div>
                                  </div>
                                  {/* Enhanced stage/signal/readiness info */}
                                  <OpportunityInfoRow opp={opp} />
                                  {oppAlerts.length > 0 && (
                                    <div className="flex flex-wrap gap-1 mt-2">
                                      {oppAlerts.slice(0, 3).map(alert => (
                                        <Badge key={alert.id} variant="outline" className="text-xs">
                                          {alert.ruleName}
                                        </Badge>
                                      ))}
                                      {oppAlerts.length > 3 && (
                                        <Badge variant="outline" className="text-xs">+{oppAlerts.length - 3}</Badge>
                                      )}
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                            {account.opportunities.length > 5 && (
                              <p className="text-sm text-muted-foreground pl-2">
                                +{account.opportunities.length - 5} more opportunities
                              </p>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              );
            })()}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="opportunities" className="space-y-4">
          <ScrollArea className="h-[calc(100vh-350px)]">
            {(() => {
              // Use ALL opportunities, with alerts as supplementary
              const oppsWithAlerts = filteredOpportunities.map(opp => ({
                ...opp,
                oppAlerts: filteredAlerts.filter(a => a.opportunityId === opp.id),
              }));
              
              const sortedOpps = oppsWithAlerts.sort((a, b) => {
                const aCritical = a.oppAlerts.filter(al => al.alertLevel === 'critical').length;
                const bCritical = b.oppAlerts.filter(al => al.alertLevel === 'critical').length;
                if (aCritical !== bCritical) return bCritical - aCritical;
                return (b.value || 0) - (a.value || 0);
              });

              if (sortedOpps.length === 0) {
                return (
                  <Card>
                    <CardContent className="p-8 text-center">
                      <Target className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <h3 className="font-medium text-lg">No opportunities</h3>
                      <p className="text-muted-foreground">
                        No opportunities found for your team
                      </p>
                    </CardContent>
                  </Card>
                );
              }

              return (
                <div className="space-y-3">
                  {sortedOpps.map(opp => {
                    const criticalCount = opp.oppAlerts.filter(a => a.alertLevel === 'critical').length;
                    const warningCount = opp.oppAlerts.filter(a => a.alertLevel === 'warning').length;
                    return (
                      <Card 
                        key={opp.id} 
                        className="cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => navigate(`/opportunities/${opp.id}`)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-medium">{opp.accounts?.name || 'Unknown'} / {opp.name}</span>
                                {criticalCount > 0 && (
                                  <Badge variant="destructive" className="text-xs">{criticalCount} critical</Badge>
                                )}
                                {warningCount > 0 && (
                                  <Badge variant="secondary" className="text-xs bg-yellow-500/20 text-yellow-700">
                                    {warningCount} warning
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                {opp.owner_email && (
                                  <span className="flex items-center gap-1">
                                    <Briefcase className="h-3 w-3 text-blue-500" />
                                    AE: {opp.owner_email}
                                  </span>
                                )}
                                {opp.primary_se_email && (
                                  <span className="flex items-center gap-1">
                                    <UserCog className="h-3 w-3 text-green-500" />
                                    SE: {opp.primary_se_email}
                                  </span>
                                )}
                                {opp.close_date && (
                                  <span className="flex items-center gap-1">
                                    <Calendar className="h-3 w-3" />
                                    {format(new Date(opp.close_date), 'MMM d')}
                                  </span>
                                )}
                                {opp.value && (
                                  <span className="flex items-center gap-1">
                                    <DollarSign className="h-3 w-3" />
                                    ${(opp.value / 1000).toFixed(0)}k
                                  </span>
                                )}
                              </div>
                              {/* Enhanced stage/signal/readiness info */}
                              <OpportunityInfoRow opp={opp} />
                              {opp.oppAlerts.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-3">
                                  {opp.oppAlerts.map(alert => (
                                    <Badge 
                                      key={alert.id} 
                                      variant={alert.alertType === 'technical_red_flags' ? 'destructive' : 'outline'} 
                                      className={cn(
                                      "text-xs",
                                      alert.alertLevel === 'critical' && "bg-red-600 text-white"
                                    )}
                                  >
                                    {getAlertTypeIcon(alert.alertType)}
                                    <span className="ml-1">{alert.ruleName}</span>
                                  </Badge>
                                  ))}
                                </div>
                              )}
                            </div>
                            <ChevronRight className="h-5 w-5 text-muted-foreground shrink-0" />
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              );
            })()}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <ScrollArea className="h-[calc(100vh-350px)]">
            {(() => {
              // Show ALL team members, not just those with alerts
              const teamMembersToShow = filteredHierarchyTeamMembers;
              
              if (teamMembersToShow.length === 0) {
                return (
                  <Card>
                    <CardContent className="p-8 text-center">
                      <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <h3 className="font-medium text-lg">No team data</h3>
                      <p className="text-muted-foreground">
                        Add team members in User Management to see their opportunities
                      </p>
                    </CardContent>
                  </Card>
                );
              }

              // For each team member, find their opportunities
              const teamEmailSet = new Set(filteredTeamEmails.map(e => e.toLowerCase().trim()));
              
              return (
                <div className="space-y-6">
                  {teamMembersToShow.map(member => {
                    const memberEmail = member.email.toLowerCase().trim();
                    
                    // Find opportunities where this team member is owner OR SE OR in team_member_emails
                    const memberOpps = opportunities?.filter(opp => {
                      const isOwner = opp.owner_email?.toLowerCase().trim() === memberEmail;
                      const isSe = opp.primary_se_email?.toLowerCase().trim() === memberEmail;
                      const isInTeam = opp.team_member_emails?.some(
                        e => e.toLowerCase().trim() === memberEmail
                      );
                      return isOwner || isSe || isInTeam;
                    }) || [];

                    // Get alerts for this team member
                    const memberAlerts = alertsByOwner[memberEmail] || 
                      alertsByOwner[member.email] || [];
                    
                    const criticalCount = memberAlerts.filter(a => a.alertLevel === 'critical').length;
                    const warningCount = memberAlerts.filter(a => a.alertLevel === 'warning').length;
                    const activeOpps = memberOpps.filter(o => 
                      o.stage !== 'closed_won' && o.stage !== 'closed_lost'
                    );
                    const pipelineValue = activeOpps.reduce((sum, o) => sum + (o.value || 0), 0);

                    return (
                      <Card key={member.user_id} className="overflow-hidden">
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                                <Users className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <CardTitle className="text-base">{member.full_name || member.email}</CardTitle>
                                {member.full_name && (
                                  <p className="text-xs text-muted-foreground">{member.email}</p>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {criticalCount > 0 && (
                                <Badge variant="destructive" className="text-xs">
                                  {criticalCount} critical
                                </Badge>
                              )}
                              {warningCount > 0 && (
                                <Badge variant="secondary" className="text-xs bg-yellow-500/20 text-yellow-700">
                                  {warningCount} warning
                                </Badge>
                              )}
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-2">
                          {/* Summary stats for this member */}
                          <div className="flex gap-4 mb-4 text-sm">
                            <div className="flex items-center gap-1.5">
                              <Target className="h-4 w-4 text-muted-foreground" />
                              <span className="font-medium">{activeOpps.length}</span>
                              <span className="text-muted-foreground">opportunities</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <DollarSign className="h-4 w-4 text-muted-foreground" />
                              <span className="font-medium">${(pipelineValue / 1000).toFixed(0)}k</span>
                              <span className="text-muted-foreground">pipeline</span>
                            </div>
                          </div>
                          
                          {memberOpps.length === 0 ? (
                            <p className="text-sm text-muted-foreground">No opportunities assigned</p>
                          ) : (
                            <div className="space-y-2">
                              {(() => {
                                const isExpanded = expandedMemberOpps.has(member.user_id);
                                const oppsToShow = isExpanded ? activeOpps : activeOpps.slice(0, 5);
                                
                                return (
                                  <>
                                    {oppsToShow.map(opp => {
                                      const oppAlerts = memberAlerts.filter(a => a.opportunityId === opp.id);
                                      const hasCritical = oppAlerts.some(a => a.alertLevel === 'critical');
                                      const hasWarning = oppAlerts.some(a => a.alertLevel === 'warning');
                                      
                                      return (
                                        <div 
                                          key={opp.id}
                                          className={cn(
                                            "p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors",
                                            hasCritical && "border-l-4 border-l-destructive",
                                            !hasCritical && hasWarning && "border-l-4 border-l-yellow-500"
                                          )}
                                          onClick={() => navigate(`/opportunities/${opp.id}`)}
                                        >
                                          <div className="flex items-center justify-between">
                                            <div className="flex-1 min-w-0">
                                              <p className="font-medium text-sm truncate">{opp.name}</p>
                                              <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                                                <span className="flex items-center gap-1">
                                                  <Building2 className="h-3 w-3" />
                                                  {opp.accounts?.name}
                                                </span>
                                                {opp.close_date && (
                                                  <span className="flex items-center gap-1">
                                                    <Calendar className="h-3 w-3" />
                                                    {format(new Date(opp.close_date), 'MMM d')}
                                                  </span>
                                                )}
                                                {opp.value && (
                                                  <span className="flex items-center gap-1">
                                                    <DollarSign className="h-3 w-3" />
                                                    ${(opp.value / 1000).toFixed(0)}k
                                                  </span>
                                                )}
                                              </div>
                                              {/* Enhanced stage/signal/readiness info */}
                                              <OpportunityInfoRow opp={opp} />
                                              {oppAlerts.length > 0 && (
                                                <div className="mt-2 flex flex-wrap gap-1">
                                                  {oppAlerts.slice(0, 3).map(alert => (
                                                    <Badge 
                                                      key={alert.id}
                                                      variant={alert.alertLevel === 'critical' ? 'destructive' : 'secondary'}
                                                      className={cn(
                                                        "text-xs",
                                                        alert.alertLevel === 'warning' && "bg-yellow-500/20 text-yellow-700"
                                                      )}
                                                    >
                                                      {alert.ruleName}
                                                    </Badge>
                                                  ))}
                                                  {oppAlerts.length > 3 && (
                                                    <Badge variant="outline" className="text-xs">
                                                      +{oppAlerts.length - 3} more
                                                    </Badge>
                                                  )}
                                                </div>
                                              )}
                                            </div>
                                            <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                                          </div>
                                        </div>
                                      );
                                    })}
                                    {activeOpps.length > 5 && (
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="w-full text-xs text-muted-foreground hover:text-foreground"
                                        onClick={() => toggleMemberOppsExpanded(member.user_id)}
                                      >
                                        {isExpanded ? (
                                          <>
                                            <ChevronDown className="h-3 w-3 mr-1" />
                                            Show less
                                          </>
                                        ) : (
                                          <>
                                            <ChevronRight className="h-3 w-3 mr-1" />
                                            + {activeOpps.length - 5} more opportunities
                                          </>
                                        )}
                                      </Button>
                                    )}
                                  </>
                                );
                              })()}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              );
            })()}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <ScrollArea className="h-[calc(100vh-350px)]">
            {filteredAlerts.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Target className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="font-medium text-lg">No alerts</h3>
                  <p className="text-muted-foreground">
                    All team opportunities are on track!
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {filteredAlerts.map(alert => (
                  <AlertCard 
                    key={alert.id} 
                    alert={alert} 
                    onClick={() => handleAlertClick(alert)} 
                  />
                ))}
              </div>
            )}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="manage" className="space-y-4">
          {/* Time Range Selector */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-muted-foreground" />
              <span className="font-medium">Team Performance Metrics</span>
            </div>
            <div className="flex items-center gap-4">
              <Select value={selectedRange} onValueChange={(v) => setSelectedRange(v as RangeKey)}>
                <SelectTrigger className="w-36">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TIME_RANGES.map(range => {
                    const key = range.isWeek ? (range.weekOffset === 0 ? 'this_week' : 'last_week') : range.days.toString();
                    return (
                      <SelectItem key={key} value={key}>
                        {range.label}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
              {isAdmin && (
                <Button variant="outline" size="sm" asChild>
                  <Link to="/settings?tab=users">
                    <Settings className="w-4 h-4 mr-2" />
                    Manage Hierarchy
                  </Link>
                </Button>
              )}
            </div>
          </div>

          {/* Team Totals Summary */}
          {teamTotals && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-2xl font-bold">{teamTotals.totalAccounts}</p>
                      <p className="text-xs text-muted-foreground">Accounts</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-2xl font-bold">{teamTotals.totalOpportunities}</p>
                      <p className="text-xs text-muted-foreground">Opportunities</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Video className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-2xl font-bold">{teamTotals.totalMeetings}</p>
                      <p className="text-xs text-muted-foreground">Meetings ({rangeLabel})</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-2xl font-bold">{teamTotals.avgHoursPerWeek}h</p>
                      <p className="text-xs text-muted-foreground">Avg hrs/week</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Team Member Metrics Table */}
          <Card>
            <CardHeader>
              <CardTitle>Team Member Performance</CardTitle>
              <CardDescription>
                Detailed metrics for each team member over the selected time period
              </CardDescription>
            </CardHeader>
            <CardContent>
              {metricsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : filteredMetrics.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No team members assigned to you yet.</p>
                  {isAdmin ? (
                    <p className="text-sm mt-2">
                      Go to{' '}
                      <Link to="/settings?tab=users" className="text-primary hover:underline">
                        User Management
                      </Link>{' '}
                      to set up team hierarchy.
                    </p>
                  ) : (
                    <p className="text-sm mt-2">Ask an admin to assign team members to you.</p>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="sticky left-0 bg-background">Team Member</TableHead>
                        <TableHead className="text-center">
                          <div className="flex flex-col items-center">
                            <Building2 className="h-4 w-4 mb-1" />
                            <span>Accounts</span>
                          </div>
                        </TableHead>
                        <TableHead className="text-center">
                          <div className="flex flex-col items-center">
                            <DollarSign className="h-4 w-4 mb-1" />
                            <span>Pipeline</span>
                          </div>
                        </TableHead>
                        <TableHead className="text-center">
                          <div className="flex flex-col items-center">
                            <Video className="h-4 w-4 mb-1" />
                            <span>Meetings</span>
                          </div>
                        </TableHead>
                        <TableHead className="text-center">
                          <div className="flex flex-col items-center">
                            <Clock className="h-4 w-4 mb-1" />
                            <span>Hrs/Week</span>
                          </div>
                        </TableHead>
                        <TableHead className="text-center">
                          <div className="flex flex-col items-center">
                            <FileText className="h-4 w-4 mb-1" />
                            <span>Transcripts</span>
                          </div>
                        </TableHead>
                        <TableHead className="text-center">
                          <div className="flex flex-col items-center">
                            <CheckCircle2 className="h-4 w-4 mb-1" />
                            <span>NBAs</span>
                          </div>
                        </TableHead>
                        <TableHead className="text-center">
                          <div className="flex flex-col items-center">
                            <FileQuestion className="h-4 w-4 mb-1" />
                            <span>Readiness</span>
                          </div>
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredMetrics.map((member) => {
                        const meetingCount = member.meetingCount30d;
                        const isExpanded = expandedMembers.has(member.email);
                        return (
                          <>
                            <TableRow 
                              key={member.email} 
                              className="cursor-pointer hover:bg-muted/50"
                              onClick={() => toggleMemberExpanded(member.email)}
                            >
                              <TableCell className="sticky left-0 bg-background">
                                <div className="flex items-center gap-3">
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="h-6 w-6 shrink-0"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      toggleMemberExpanded(member.email);
                                    }}
                                  >
                                    {isExpanded ? (
                                      <ChevronDown className="h-4 w-4" />
                                    ) : (
                                      <ChevronRight className="h-4 w-4" />
                                    )}
                                  </Button>
                                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                                    <Users className="h-4 w-4 text-primary" />
                                  </div>
                                  <div>
                                    <p className="font-medium">{member.name || member.email}</p>
                                    {member.name && (
                                      <p className="text-xs text-muted-foreground">{member.email}</p>
                                    )}
                                  </div>
                                  {member.depth > 1 && (
                                    <Badge variant="outline" className="text-xs ml-2">
                                      L{member.depth}
                                    </Badge>
                                  )}
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="ml-auto text-xs h-7"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setPrepSheetMember({ email: member.email, name: member.name });
                                    }}
                                  >
                                    <FileText className="h-3 w-3 mr-1" />
                                    Prep 1:1
                                  </Button>
                                </div>
                              </TableCell>
                              <TableCell className="text-center">
                                <span className="font-medium">{member.accountCount}</span>
                                <span className="text-muted-foreground text-xs ml-1">
                                  / {member.opportunityCount} opps
                                </span>
                              </TableCell>
                              <TableCell className="text-center font-medium">
                                ${(member.pipelineValue / 1000).toFixed(0)}k
                              </TableCell>
                              <TableCell className="text-center">
                                <span className="font-medium">{meetingCount}</span>
                                {member.avgMeetingDuration > 0 && (
                                  <span className="text-muted-foreground text-xs ml-1">
                                    ({member.avgMeetingDuration}m avg)
                                  </span>
                                )}
                              </TableCell>
                              <TableCell className="text-center">
                                <span className={cn(
                                  "font-medium",
                                  member.hoursPerWeek < 2 && "text-yellow-600",
                                  member.hoursPerWeek >= 5 && "text-green-600"
                                )}>
                                  {member.hoursPerWeek}h
                                </span>
                              </TableCell>
                              <TableCell className="text-center font-medium">
                                {member.transcriptsProcessed}
                              </TableCell>
                              <TableCell className="text-center">
                                <span className="font-medium">{member.nbasCompleted}</span>
                                <span className="text-muted-foreground text-xs">
                                  /{member.nbasCreated}
                                </span>
                              </TableCell>
                              <TableCell className="text-center">
                                <div className="flex items-center gap-2">
                                  <Progress 
                                    value={member.readinessAverage} 
                                    className="h-2 w-16"
                                  />
                                  <span className={cn(
                                    "text-xs font-medium",
                                    member.readinessAverage < 30 && "text-destructive",
                                    member.readinessAverage >= 70 && "text-green-600"
                                  )}>
                                    {member.readinessAverage}%
                                  </span>
                                </div>
                              </TableCell>
                            </TableRow>
                            {isExpanded && (
                              <TableRow key={`${member.email}-expanded`}>
                                <TableCell colSpan={8} className="p-0 bg-muted/20">
                                  <div className="p-4">
                                    <TeamMemberWeeklyHeatmap 
                                      memberEmail={member.email}
                                      memberName={member.name}
                                      selectedRange={selectedRange}
                                    />
                                  </div>
                                </TableCell>
                              </TableRow>
                            )}
                          </>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Manage Off-site / Manual Meetings (editing, import, deletion) */}
          <TeamManualMeetingsSection teamEmails={filteredTeamEmails} />
        </TabsContent>

        <TabsContent value="evaluations" className="space-y-4">
          <EvaluationRadarTab teamEmails={filteredTeamEmails} />
        </TabsContent>

        <TabsContent value="coaching" className="space-y-4">
          <SECoachingTab seEmailFilter={seOnlyEmailFilter} />
        </TabsContent>

        <TabsContent value="exec-summary" className="space-y-4">
          <Suspense fallback={<div className="flex items-center justify-center py-16"><RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" /></div>}>
            <ExecWeeklySummaryTab teamEmails={filteredTeamEmails} />
          </Suspense>
        </TabsContent>
      </Tabs>

      {/* 1:1 Prep Sheet */}
      <OneOnOnePrepSheet
        open={!!prepSheetMember}
        onOpenChange={(open) => { if (!open) setPrepSheetMember(null); }}
        memberEmail={prepSheetMember?.email || null}
        memberName={prepSheetMember?.name || null}
      />
    </div>
  );
}

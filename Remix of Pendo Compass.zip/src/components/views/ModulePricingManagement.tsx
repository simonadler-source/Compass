import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { DollarSign, Plus, Pencil, Trash2, Package, Percent, Layers, Users, Server, Settings, Save } from 'lucide-react';

type ModuleType = 'platform' | 'mau' | 'module';

interface ModulePricing {
  id: string;
  functional_area_id: string | null;
  module_name: string;
  description: string | null;
  module_type: ModuleType;
  fixed_cost: number;
  per_mau_cost: number;
  mau_percentage: number;
  discount_percentage: number;
  discount_reason: string | null;
  is_base_module: boolean;
  is_active: boolean;
  sort_order: number;
  functional_area?: { id: string; name: string; layer: string } | null;
}

interface FunctionalArea {
  id: string;
  name: string;
  layer: string;
}

interface PricingSetting {
  id: string;
  setting_key: string;
  setting_value: number;
  description: string | null;
  updated_at: string;
}

const MODULE_TYPE_LABELS: Record<ModuleType, { label: string; icon: typeof Server; description: string }> = {
  platform: { label: 'Platform', icon: Server, description: 'Fixed platform cost' },
  mau: { label: 'MAU', icon: Users, description: 'Cost per monthly active user' },
  module: { label: 'Module', icon: Package, description: 'Percentage of MAU value' },
};

export function ModulePricingManagement() {
  const queryClient = useQueryClient();
  const [editingModule, setEditingModule] = useState<ModulePricing | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [listPricePerMau, setListPricePerMau] = useState<string>('');
  const [platformBaseCost, setPlatformBaseCost] = useState<string>('');
  const [formData, setFormData] = useState<Partial<ModulePricing>>({
    module_name: '',
    description: '',
    module_type: 'module',
    fixed_cost: 0,
    per_mau_cost: 0,
    mau_percentage: 0,
    discount_percentage: 0,
    discount_reason: '',
    is_base_module: false,
    is_active: true,
    sort_order: 0,
  });

  // Fetch global pricing settings
  const { data: pricingSettings, isLoading: settingsLoading } = useQuery({
    queryKey: ['pricing-settings'],
    queryFn: async () => {
      const response = await gateway
        .from('pricing_settings')
        .select('*')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      
      const settings = response.data as PricingSetting[];
      // Set local state from fetched values
      const listPrice = settings.find(s => s.setting_key === 'list_price_per_mau');
      const platformCost = settings.find(s => s.setting_key === 'platform_base_cost');
      
      if (listPrice) setListPricePerMau(listPrice.setting_value.toString());
      if (platformCost) setPlatformBaseCost(platformCost.setting_value.toString());
      
      return settings;
    },
  });

  // Update pricing settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async ({ key, value }: { key: string; value: number }) => {
      const response = await gateway
        .from('pricing_settings')
        .update({ setting_value: value, updated_at: new Date().toISOString() })
        .eq('setting_key', key)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pricing-settings'] });
      toast.success('Pricing settings updated');
    },
    onError: (error: any) => {
      toast.error('Failed to update settings: ' + error.message);
    },
  });

  const handleSaveGlobalSettings = () => {
    const listPriceNum = parseFloat(listPricePerMau) || 0;
    const platformCostNum = parseFloat(platformBaseCost) || 0;
    
    updateSettingsMutation.mutate({ key: 'list_price_per_mau', value: listPriceNum });
    updateSettingsMutation.mutate({ key: 'platform_base_cost', value: platformCostNum });
  };

  // Fetch module pricing
  const { data: modules, isLoading } = useQuery({
    queryKey: ['module-pricing'],
    queryFn: async () => {
      const response = await gateway
        .from('module_pricing')
        .select('*, functional_area:functional_areas(*)')
        .order('sort_order', { ascending: true })
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as ModulePricing[];
    },
  });

  // Fetch functional areas for dropdown
  const { data: functionalAreas } = useQuery({
    queryKey: ['functional-areas-list'],
    queryFn: async () => {
      const response = await gateway
        .from('functional_areas')
        .select('id, name, layer')
        .order('sort_order', { ascending: true })
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as FunctionalArea[];
    },
  });

  // Create/Update mutation
  const saveMutation = useMutation({
    mutationFn: async (data: Partial<ModulePricing>) => {
      // Remove the functional_area join data before saving
      const { functional_area, ...saveData } = data as ModulePricing;
      
      if (editingModule) {
        const response = await gateway
          .from('module_pricing')
          .update({
            ...saveData,
            updated_at: new Date().toISOString(),
          })
          .eq('id', editingModule.id)
          .execute();
        if (response.error) throw new Error(getErrorMessage(response.error));
      } else {
        const response = await gateway
          .from('module_pricing')
          .insert(saveData)
          .execute();
        if (response.error) throw new Error(getErrorMessage(response.error));
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['module-pricing'] });
      toast.success(editingModule ? 'Module pricing updated' : 'Module pricing created');
      closeDialog();
    },
    onError: (error: any) => {
      toast.error('Failed to save: ' + error.message);
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await gateway
        .from('module_pricing')
        .delete()
        .eq('id', id)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['module-pricing'] });
      toast.success('Module pricing deleted');
    },
    onError: (error: any) => {
      toast.error('Failed to delete: ' + error.message);
    },
  });

  const openCreateDialog = () => {
    setEditingModule(null);
    setFormData({
      module_name: '',
      description: '',
      functional_area_id: null,
      module_type: 'module',
      fixed_cost: 0,
      per_mau_cost: 0,
      mau_percentage: 0,
      discount_percentage: 0,
      discount_reason: '',
      is_base_module: false,
      is_active: true,
      sort_order: 0,
    });
    setIsDialogOpen(true);
  };

  const openEditDialog = (module: ModulePricing) => {
    setEditingModule(module);
    setFormData({
      module_name: module.module_name,
      description: module.description || '',
      functional_area_id: module.functional_area_id,
      module_type: module.module_type,
      fixed_cost: module.fixed_cost || 0,
      per_mau_cost: module.per_mau_cost || 0,
      mau_percentage: module.mau_percentage || 0,
      discount_percentage: module.discount_percentage || 0,
      discount_reason: module.discount_reason || '',
      is_base_module: module.is_base_module,
      is_active: module.is_active,
      sort_order: module.sort_order,
    });
    setIsDialogOpen(true);
  };

  const closeDialog = () => {
    setIsDialogOpen(false);
    setEditingModule(null);
  };

  const handleSave = () => {
    if (!formData.module_name) {
      toast.error('Module name is required');
      return;
    }
    saveMutation.mutate(formData);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }).format(value);
  };

  const getPricingDisplay = (module: ModulePricing) => {
    switch (module.module_type) {
      case 'platform':
        const parts = [formatCurrency(module.fixed_cost)];
        if (module.per_mau_cost > 0) {
          parts.push(`+ ${formatCurrency(module.per_mau_cost)}/user/mo`);
        }
        return parts.join(' ');
      case 'mau':
        return `${formatCurrency(module.per_mau_cost)}/user/mo`;
      case 'module':
        return `${module.mau_percentage}% of MAU`;
      default:
        return '—';
    }
  };

  const getDiscountDisplay = (module: ModulePricing) => {
    if (!module.discount_percentage || module.discount_percentage === 0) {
      return null;
    }
    return (
      <Badge variant="secondary" className="text-xs">
        -{module.discount_percentage}%
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      {/* Global Pricing Settings Card */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            Global Pricing Settings
          </CardTitle>
          <CardDescription>
            Set baseline pricing values used to calculate whitespace revenue across all accounts.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {settingsLoading ? (
            <div className="text-center py-4 text-muted-foreground">Loading settings...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* List Price per MAU */}
              <div className="space-y-2">
                <Label htmlFor="list_price_per_mau" className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  List Price per MAU
                </Label>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">$</span>
                  <Input
                    id="list_price_per_mau"
                    type="text"
                    inputMode="decimal"
                    value={listPricePerMau}
                    onChange={(e) => setListPricePerMau(e.target.value)}
                    placeholder="0.50"
                    className="max-w-[150px]"
                  />
                  <span className="text-muted-foreground text-sm">/user/month</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Base cost per Monthly Active User. Modules priced as "% of MAU" use this value.
                </p>
              </div>

              {/* Platform Base Cost */}
              <div className="space-y-2">
                <Label htmlFor="platform_base_cost" className="flex items-center gap-2">
                  <Server className="w-4 h-4 text-muted-foreground" />
                  Platform Base Cost
                </Label>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">$</span>
                  <Input
                    id="platform_base_cost"
                    type="text"
                    inputMode="decimal"
                    value={platformBaseCost}
                    onChange={(e) => setPlatformBaseCost(e.target.value)}
                    placeholder="50000"
                    className="max-w-[150px]"
                  />
                  <span className="text-muted-foreground text-sm">/year</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Core platform subscription cost. Used as baseline for revenue calculations.
                </p>
              </div>
            </div>
          )}
          
          <div className="flex justify-end mt-6">
            <Button 
              onClick={handleSaveGlobalSettings} 
              disabled={updateSettingsMutation.isPending}
              variant="glow"
              size="sm"
            >
              <Save className="w-4 h-4 mr-2" />
              {updateSettingsMutation.isPending ? 'Saving...' : 'Save Settings'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="glass border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                Module Pricing
              </CardTitle>
              <CardDescription>
                Configure pricing: Platform (fixed), MAU (per-user), and Modules (% of MAU value). Each can have a discount.
              </CardDescription>
            </div>
            <Button onClick={openCreateDialog} variant="glow" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Module
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading...</div>
          ) : !modules?.length ? (
            <div className="text-center py-8 text-muted-foreground">
              No pricing configured. Add platform cost, MAU pricing, or module pricing to get started.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Functional Area</TableHead>
                  <TableHead className="text-right">Pricing</TableHead>
                  <TableHead className="text-right">Discount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {modules.map((module) => {
                  const typeInfo = MODULE_TYPE_LABELS[module.module_type];
                  const TypeIcon = typeInfo?.icon || Package;
                  return (
                    <TableRow key={module.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <TypeIcon className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <p className="font-medium">{module.module_name}</p>
                            {module.description && (
                              <p className="text-xs text-muted-foreground truncate max-w-[200px]">
                                {module.description}
                              </p>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {typeInfo?.label || module.module_type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {module.functional_area ? (
                          <div className="flex items-center gap-2">
                            <Layers className="w-3 h-3 text-muted-foreground" />
                            <span className="text-sm">{module.functional_area.name}</span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-sm">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right font-mono">
                        {getPricingDisplay(module)}
                      </TableCell>
                      <TableCell className="text-right">
                        {getDiscountDisplay(module) || (
                          <span className="text-muted-foreground text-sm">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={module.is_active ? 'default' : 'secondary'}>
                          {module.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(module)}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              if (confirm('Delete this pricing configuration?')) {
                                deleteMutation.mutate(module.id);
                              }
                            }}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>
              {editingModule ? 'Edit Pricing' : 'Add Pricing'}
            </DialogTitle>
            <DialogDescription>
              Configure pricing for platform, MAU, or module costs.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-6 py-4">
            {/* Basic Info */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="module_name">Name *</Label>
                <Input
                  id="module_name"
                  value={formData.module_name || ''}
                  onChange={(e) => setFormData({ ...formData, module_name: e.target.value })}
                  placeholder="e.g., Platform Fee, Listen"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="module_type">Pricing Type</Label>
                <Select
                  value={formData.module_type || 'module'}
                  onValueChange={(value: ModuleType) => setFormData({ 
                    ...formData, 
                    module_type: value 
                  })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(MODULE_TYPE_LABELS).map(([key, info]) => (
                      <SelectItem key={key} value={key}>
                        <div className="flex items-center gap-2">
                          <info.icon className="w-4 h-4" />
                          <span>{info.label}</span>
                          <span className="text-muted-foreground text-xs">- {info.description}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Brief description"
              />
            </div>

            {/* Functional Area (only for module type) */}
            {formData.module_type === 'module' && (
              <div className="space-y-2">
                <Label htmlFor="functional_area">Functional Area</Label>
                <Select
                  value={formData.functional_area_id || 'none'}
                  onValueChange={(value) => setFormData({ 
                    ...formData, 
                    functional_area_id: value === 'none' ? null : value 
                  })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select area" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No linked area</SelectItem>
                    {functionalAreas?.map((area) => (
                      <SelectItem key={area.id} value={area.id}>
                        {area.name} ({area.layer})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Pricing based on type */}
            <div className="space-y-4">
              <Label>Pricing</Label>
              
              {formData.module_type === 'platform' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">Fixed Platform Cost</Label>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">$</span>
                      <Input
                        type="text"
                        inputMode="decimal"
                        value={formData.fixed_cost || ''}
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          fixed_cost: parseFloat(e.target.value) || 0 
                        })}
                        placeholder="0"
                        className="max-w-[200px]"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">MAU Cost (per user)</Label>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">$</span>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        value={formData.per_mau_cost || ''}
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          per_mau_cost: parseFloat(e.target.value) || 0 
                        })}
                        placeholder="0.00"
                        className="max-w-[200px]"
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">Optional per-user cost included with platform</p>
                  </div>
                </div>
              )}

              {formData.module_type === 'mau' && (
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Cost per MAU</Label>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">$</span>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.per_mau_cost || ''}
                      onChange={(e) => setFormData({ 
                        ...formData, 
                        per_mau_cost: parseFloat(e.target.value) || 0 
                      })}
                      placeholder="0.00"
                      className="max-w-[200px]"
                    />
                    <span className="text-muted-foreground text-sm">/user/month</span>
                  </div>
                </div>
              )}

              {formData.module_type === 'module' && (
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Percentage of MAU Value</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="text"
                      inputMode="decimal"
                      value={formData.mau_percentage || ''}
                      onChange={(e) => setFormData({ 
                        ...formData, 
                        mau_percentage: parseFloat(e.target.value) || 0 
                      })}
                      placeholder="0"
                      className="max-w-[120px]"
                    />
                    <span className="text-muted-foreground">% of MAU value</span>
                  </div>
                </div>
              )}
            </div>

            {/* Discount */}
            <div className="space-y-4 border-t pt-4">
              <Label className="flex items-center gap-2">
                <Percent className="w-4 h-4" />
                Discount
              </Label>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Discount Percentage</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="text"
                      inputMode="decimal"
                      value={formData.discount_percentage || ''}
                      onChange={(e) => setFormData({ 
                        ...formData, 
                        discount_percentage: parseFloat(e.target.value) || 0 
                      })}
                      placeholder="0"
                      className="max-w-[100px]"
                    />
                    <span className="text-muted-foreground">%</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Discount Reason</Label>
                  <Input
                    value={formData.discount_reason || ''}
                    onChange={(e) => setFormData({ ...formData, discount_reason: e.target.value })}
                    placeholder="e.g., Annual commitment"
                  />
                </div>
              </div>
            </div>

            {/* Settings */}
            <div className="flex items-center justify-between border-t pt-4">
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Switch
                    id="is_base_module"
                    checked={formData.is_base_module || false}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_base_module: checked })}
                  />
                  <Label htmlFor="is_base_module" className="text-sm">Base Module</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    id="is_active"
                    checked={formData.is_active ?? true}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                  <Label htmlFor="is_active" className="text-sm">Active</Label>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor="sort_order" className="text-sm">Order:</Label>
                <Input
                  id="sort_order"
                  type="number"
                  value={formData.sort_order || 0}
                  onChange={(e) => setFormData({ ...formData, sort_order: parseInt(e.target.value) || 0 })}
                  className="w-16"
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={closeDialog}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending}>
              {saveMutation.isPending ? 'Saving...' : (editingModule ? 'Update' : 'Create')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
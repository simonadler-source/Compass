import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { gateway, getErrorMessage } from "@/lib/apiGateway";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation, useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  RefreshCw,
  Download,
  X,
  Calendar,
  Users,
  Clock,
  FileText,
  Building2,
  RotateCcw,
  Loader2,
  Search,
  Filter,
  CalendarDays,
  TrendingUp,
  Plus,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Sparkles,
  AlertCircle,
  CheckCircle,
} from "lucide-react";
import { toast } from "sonner";
import { format, isAfter, isBefore, startOfDay, endOfDay, isValid } from "date-fns";

/** Safely format a date string, returning fallback on invalid values */
function safeFormat(dateStr: string | null | undefined, fmt: string, fallback = '—'): string {
  if (!dateStr) return fallback;
  const d = new Date(dateStr);
  return isValid(d) ? format(d, fmt) : fallback;
}

import type { MomentumMeeting } from "@/features/momentum/types";
import { useImportModal } from "@/features/momentum/import/ImportModalContext";
import {
  directImportMomentumMeetingById,
  isDirectImportExceptionMeeting,
  revertMeetingToPending,
  importMomentumMeetingSteps,
} from "@/features/momentum/import/importMomentumMeeting";
import { useMeetingSearchIndex } from "@/hooks/useMeetingSearchIndex";
import ProcessingQueueTab from "@/components/views/ProcessingQueueTab";

type MomentumMeetingListItem = Omit<MomentumMeeting, "transcript_content"> & {
  transcript_content?: string | null;
};

const MEETINGS_LIST_SELECT =
  "id,momentum_id,title,start_time,end_time,host_email,host_name,attendees,salesforce_account_id,salesforce_opportunity_id,status,matched_account_id,imported_at,ignored_at,created_at";

// Extracted MeetingCard component to prevent closure issues
interface MeetingCardProps {
  meeting: MomentumMeetingListItem;
  showRestore?: boolean;
  onImport: (meetingId: string) => void;
  onIgnore: (meetingId: string) => void;
  onRestore: (meetingId: string) => void;
  onResetProcessing: (meetingId: string) => void;
  isIgnoring: boolean;
  isRestoring: boolean;
  isResettingProcessing: boolean;
  isImportingDirect: boolean;
  isOpening: boolean;
}

function MeetingCard({
  meeting,
  showRestore = false,
  onImport,
  onIgnore,
  onRestore,
  onResetProcessing,
  isIgnoring,
  isRestoring,
  isResettingProcessing,
  isImportingDirect,
  isOpening,
}: MeetingCardProps) {
  const allAttendees = meeting.attendees || [];
  const internalAttendees = allAttendees.filter((a: any) => a.isInternal);
  const isProcessing = meeting.status === 'processing';
  
  return (
    <Card className="mb-4 border-border/50">
      <CardContent className="pt-4 select-text">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-semibold text-lg">{meeting.title}</h3>
            <div className="flex flex-wrap gap-4 mt-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {safeFormat(meeting.start_time, 'MMM d, yyyy')}
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {safeFormat(meeting.start_time, 'h:mm a')}
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4" />
                {allAttendees.length} attendee{allAttendees.length !== 1 ? 's' : ''} ({internalAttendees.length} Pendo)
              </div>
            </div>
            {meeting.salesforce_account_id && (
              <Badge variant="outline" className="mt-2">
                <Building2 className="h-3 w-3 mr-1" />
                SF Account: {meeting.salesforce_account_id}
              </Badge>
            )}
            {allAttendees.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {allAttendees.slice(0, 4).map((a: any, i: number) => (
                  <Badge 
                    key={i} 
                    variant="secondary" 
                    className={cn(
                      "text-xs",
                      a.isInternal && "text-[hsl(var(--pendo-pink))] border-[hsl(var(--pendo-pink))/30] bg-[hsl(var(--pendo-pink))/10]"
                    )}
                  >
                    {a.name || a.email}
                  </Badge>
                ))}
                {allAttendees.length > 4 && (
                  <HoverCard>
                    <HoverCardTrigger asChild>
                      <Badge variant="secondary" className="text-xs cursor-pointer hover:bg-secondary/80">
                        +{allAttendees.length - 4} more
                      </Badge>
                    </HoverCardTrigger>
                    <HoverCardContent className="w-72 p-3" align="start">
                      <div className="space-y-2">
                        <p className="text-sm font-medium text-muted-foreground">All Attendees</p>
                        <div className="flex flex-wrap gap-1">
                          {allAttendees.slice(4).map((a: any, i: number) => (
                            <Badge 
                              key={i} 
                              variant="outline" 
                              className={cn(
                                "text-xs",
                                a.isInternal && "text-[hsl(var(--pendo-pink))] border-[hsl(var(--pendo-pink))/30]"
                              )}
                            >
                              {a.name || a.email}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </HoverCardContent>
                  </HoverCard>
                )}
              </div>
            )}
          </div>
          <div className="flex gap-2">
            {showRestore ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onRestore(meeting.id)}
                disabled={isRestoring}
              >
                <RotateCcw className="h-4 w-4 mr-1" />
                Restore
              </Button>
            ) : isProcessing ? (
              <Button
                variant="outline"
                size="sm"
                className="min-w-[90px]"
                onClick={() => onResetProcessing(meeting.id)}
                disabled={isResettingProcessing}
              >
                {isResettingProcessing ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-1" />
                ) : (
                  <RotateCcw className="h-4 w-4 mr-1" />
                )}
                Reset
              </Button>
            ) : (
              <>
                <Button
                  type="button"
                  variant="default"
                  size="sm"
                  className="min-w-[90px] transition-none"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    onImport(meeting.id);
                  }}
                  disabled={isImportingDirect || isOpening}
                >
                  {isImportingDirect ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>Importing…</span>
                    </>
                  ) : isOpening ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>Opening…</span>
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      <span>Import</span>
                    </>
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="transition-none"
                  onClick={() => onIgnore(meeting.id)}
                  disabled={isIgnoring}
                >
                  <X className="h-4 w-4" />
                </Button>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function MomentumMeetingsView() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { openImport, isOpen: isImportModalOpen } = useImportModal();

  const backfillPanelRef = useRef<HTMLDivElement | null>(null);
  const [backfillOpen, setBackfillOpen] = useState(false);
  const [historicalSyncOpen, setHistoricalSyncOpen] = useState(false);
  const [historicalFromDate, setHistoricalFromDate] = useState<Date | undefined>(undefined);
  const [historicalToDate, setHistoricalToDate] = useState<Date | undefined>(undefined);
  const [historicalTeamOnly, setHistoricalTeamOnly] = useState(true);
  const [historicalSfAccountId, setHistoricalSfAccountId] = useState('');
  const [singleMeetingId, setSingleMeetingId] = useState('');
  const [selectedUnanalyzedIds, setSelectedUnanalyzedIds] = useState<Set<string>>(new Set());
  
  // Track meetings currently being analyzed with their status
  const [processingMeetings, setProcessingMeetings] = useState<Map<string, { status: 'processing' | 'error'; error?: string }>>(new Map());
  const [analyzedMeetingIds, setAnalyzedMeetingIds] = useState<Set<string>>(new Set());

  // Pagination state - persisted per tab
  type PageSize = 25 | 50 | 100;
  const PAGE_SIZE_STORAGE_KEY = 'momentum-meetings-page-size';
  const [pageSize, setPageSize] = useState<PageSize>(() => {
    const saved = localStorage.getItem(PAGE_SIZE_STORAGE_KEY);
    return saved ? (parseInt(saved) as PageSize) : 50;
  });
  
  // Track loaded data per tab with offset
  const [pendingOffset, setPendingOffset] = useState(0);
  const [pendingData, setPendingData] = useState<MomentumMeetingListItem[]>([]);
  const [pendingHasMore, setPendingHasMore] = useState(true);
  const [pendingLoadingMore, setPendingLoadingMore] = useState(false);
  
  const [ignoredOffset, setIgnoredOffset] = useState(0);
  const [ignoredData, setIgnoredData] = useState<MomentumMeetingListItem[]>([]);
  const [ignoredHasMore, setIgnoredHasMore] = useState(true);
  const [ignoredLoadingMore, setIgnoredLoadingMore] = useState(false);
  
  const [orphanedOffset, setOrphanedOffset] = useState(0);
  const [orphanedData, setOrphanedData] = useState<MomentumMeetingListItem[]>([]);
  const [orphanedHasMore, setOrphanedHasMore] = useState(true);
  const [orphanedLoadingMore, setOrphanedLoadingMore] = useState(false);

  // Helper to reset all pagination state and invalidate queries - call after import/reset/restore
  const refreshAllMeetings = useCallback(() => {
    // Clear local state
    setPendingOffset(0);
    setPendingData([]);
    setPendingHasMore(true);
    
    setIgnoredOffset(0);
    setIgnoredData([]);
    setIgnoredHasMore(true);
    
    setOrphanedOffset(0);
    setOrphanedData([]);
    setOrphanedHasMore(true);
    
    // Invalidate all momentum-meetings queries
    queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
    queryClient.invalidateQueries({ queryKey: ['meeting-search-index'] });
  }, [queryClient]);

  // Step 1 (process-of-elimination): open a guaranteed basic modal first.
  const [basicImportMeetingId, setBasicImportMeetingId] = useState<string | null>(null);
  const [basicOpenMeetingIdInput, setBasicOpenMeetingIdInput] = useState("");

  // Step 2: account selection state
  const [selectedAccountId, setSelectedAccountId] = useState<string>("");
  const [createNewAccount, setCreateNewAccount] = useState(false);
  const [newAccountName, setNewAccountName] = useState("");

  // Step 3: import execution state
  const [importStep, setImportStep] = useState<1 | 2 | 3>(1);
  const [isImporting, setIsImporting] = useState(false);
  const [importStage, setImportStage] = useState("");
  const [importProgress, setImportProgress] = useState(0);

  const [openingMeetingId, setOpeningMeetingId] = useState<string | null>(null);
  const [directImportingMeetingId, setDirectImportingMeetingId] = useState<string | null>(null);

  // Collapsible state for metrics
  const [existingAccountsOpen, setExistingAccountsOpen] = useState(false);
  const [accountSearchOpen, setAccountSearchOpen] = useState(false);
  
  // Save page size to localStorage
  useEffect(() => {
    localStorage.setItem(PAGE_SIZE_STORAGE_KEY, String(pageSize));
  }, [pageSize]);

  // Filter states - persisted to localStorage
  const FILTERS_STORAGE_KEY = 'momentum-meetings-filters';

  const loadSavedFilters = () => {
    try {
      const saved = localStorage.getItem(FILTERS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          searchQuery: parsed.searchQuery || "",
          attendeeFilter: parsed.attendeeFilter || "",
          dateFrom: parsed.dateFrom ? new Date(parsed.dateFrom) : undefined,
          dateTo: parsed.dateTo ? new Date(parsed.dateTo) : undefined,
          showFilters: parsed.showFilters || false,
          myMeetingsOnly: parsed.myMeetingsOnly ?? true,
        };
      }
    } catch (e) {
      console.error('Failed to load saved filters:', e);
    }
    return null;
  };

  const savedFilters = loadSavedFilters();

  const [searchQuery, setSearchQuery] = useState(savedFilters?.searchQuery || "");
  const [attendeeFilter, setAttendeeFilter] = useState(savedFilters?.attendeeFilter || "");
  const [dateFrom, setDateFrom] = useState<Date | undefined>(savedFilters?.dateFrom);
  const [dateTo, setDateTo] = useState<Date | undefined>(savedFilters?.dateTo);
  const [showFilters, setShowFilters] = useState(savedFilters?.showFilters || false);
  const [myMeetingsOnly, setMyMeetingsOnly] = useState(savedFilters?.myMeetingsOnly ?? true);

  // Persist filters to localStorage when they change
  useEffect(() => {
    const filters = {
      searchQuery,
      attendeeFilter,
      dateFrom: dateFrom?.toISOString(),
      dateTo: dateTo?.toISOString(),
      showFilters,
      myMeetingsOnly,
    };
    localStorage.setItem(FILTERS_STORAGE_KEY, JSON.stringify(filters));

    // Let other components (e.g. Sidebar badge) react immediately in the same tab.
    window.dispatchEvent(new Event('momentum-meetings-filters-changed'));
  }, [searchQuery, attendeeFilter, dateFrom, dateTo, showFilters, myMeetingsOnly]);


  // Reset pagination when filters change - refetch from beginning
  useEffect(() => {
    // Reset all pagination state
    setPendingOffset(0);
    setPendingData([]);
    setPendingHasMore(true);
    
    setIgnoredOffset(0);
    setIgnoredData([]);
    setIgnoredHasMore(true);
    
    setOrphanedOffset(0);
    setOrphanedData([]);
    setOrphanedHasMore(true);
    
    // Invalidate queries to refetch with fresh pagination
    queryClient.invalidateQueries({ queryKey: ['momentum-meetings', 'pending'] });
    queryClient.invalidateQueries({ queryKey: ['momentum-meetings', 'ignored'] });
    queryClient.invalidateQueries({ queryKey: ['momentum-meetings', 'orphaned'] });
    queryClient.invalidateQueries({ queryKey: ['meeting-search-index'] });
  }, [searchQuery, attendeeFilter, dateFrom, dateTo, myMeetingsOnly, queryClient]);

  // Server-side search index for fast filtering
  const pendingSearchFilters = useMemo(() => ({
    searchQuery,
    attendeeFilter,
    dateFrom,
    dateTo,
    myMeetingsOnly,
    userEmail: user?.email,
    statuses: ['pending', 'processing'],
  }), [searchQuery, attendeeFilter, dateFrom, dateTo, myMeetingsOnly, user?.email]);

  const ignoredSearchFilters = useMemo(() => ({
    searchQuery,
    attendeeFilter,
    dateFrom,
    dateTo,
    myMeetingsOnly,
    userEmail: user?.email,
    statuses: ['ignored'],
  }), [searchQuery, attendeeFilter, dateFrom, dateTo, myMeetingsOnly, user?.email]);

  const orphanedSearchFilters = useMemo(() => ({
    searchQuery,
    attendeeFilter,
    dateFrom,
    dateTo,
    myMeetingsOnly,
    userEmail: user?.email,
    statuses: ['imported'],
  }), [searchQuery, attendeeFilter, dateFrom, dateTo, myMeetingsOnly, user?.email]);

  // Use search index for fast filtering
  const { data: pendingSearchResults, isLoading: loadingPendingSearch } = useMeetingSearchIndex(pendingSearchFilters, true);
  const { data: ignoredSearchResults, isLoading: loadingIgnoredSearch } = useMeetingSearchIndex(ignoredSearchFilters, true);
  const { data: orphanedSearchResults, isLoading: loadingOrphanedSearch } = useMeetingSearchIndex(orphanedSearchFilters, true);

  // Note: pendingSearchIds/ignoredSearchIds/orphanedSearchIds are no longer used since we render search results directly
  // Keeping getMeetingIdsFromSearch for potential future use

  // Fetch pending + processing meetings (via gateway for decryption) - with pagination
  const { data: pendingMeetingsInitial, isLoading: loadingPending, refetch: refetchPending } = useQuery({
    queryKey: ['momentum-meetings', 'pending', pageSize],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select(MEETINGS_LIST_SELECT)
        .or('status.eq.pending,status.eq.processing')
        .order('start_time', { ascending: false })
        .limit(pageSize)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const result = data as MomentumMeetingListItem[];
      setPendingData(result);
      setPendingOffset(result.length);
      setPendingHasMore(result.length >= pageSize);
      return result;
    },
    refetchOnMount: 'always', // Always refetch when component mounts
    staleTime: 0, // Consider data stale immediately so invalidation triggers refetch
  });

  const loadMorePending = useCallback(async () => {
    if (!pendingHasMore || pendingLoadingMore) return;
    setPendingLoadingMore(true);
    try {
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select(MEETINGS_LIST_SELECT)
        .or('status.eq.pending,status.eq.processing')
        .order('start_time', { ascending: false })
        .offset(pendingOffset)
        .limit(pageSize)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const newData = data as MomentumMeetingListItem[];
      setPendingData(prev => [...prev, ...newData]);
      setPendingOffset(prev => prev + newData.length);
      setPendingHasMore(newData.length >= pageSize);
    } finally {
      setPendingLoadingMore(false);
    }
  }, [pendingHasMore, pendingLoadingMore, pendingOffset, pageSize]);

  // Fetch ignored meetings (via gateway for decryption) - with pagination
  const { data: ignoredMeetingsInitial, isLoading: loadingIgnored, refetch: refetchIgnored } = useQuery({
    queryKey: ['momentum-meetings', 'ignored', pageSize],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select(MEETINGS_LIST_SELECT)
        .eq('status', 'ignored')
        .order('ignored_at', { ascending: false })
        .limit(pageSize)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const result = data as MomentumMeetingListItem[];
      setIgnoredData(result);
      setIgnoredOffset(result.length);
      setIgnoredHasMore(result.length >= pageSize);
      return result;
    },
    refetchOnMount: 'always',
    staleTime: 0,
  });

  const loadMoreIgnored = useCallback(async () => {
    if (!ignoredHasMore || ignoredLoadingMore) return;
    setIgnoredLoadingMore(true);
    try {
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select(MEETINGS_LIST_SELECT)
        .eq('status', 'ignored')
        .order('ignored_at', { ascending: false })
        .offset(ignoredOffset)
        .limit(pageSize)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const newData = data as MomentumMeetingListItem[];
      setIgnoredData(prev => [...prev, ...newData]);
      setIgnoredOffset(prev => prev + newData.length);
      setIgnoredHasMore(newData.length >= pageSize);
    } finally {
      setIgnoredLoadingMore(false);
    }
  }, [ignoredHasMore, ignoredLoadingMore, ignoredOffset, pageSize]);

  // Fetch orphaned meetings (imported but account was deleted) - via gateway for decryption
  const { data: orphanedMeetingsInitial, isLoading: loadingOrphaned, refetch: refetchOrphaned } = useQuery({
    queryKey: ['momentum-meetings', 'orphaned', pageSize],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select(MEETINGS_LIST_SELECT)
        .eq('status', 'imported')
        .is('matched_account_id', null)
        .order('imported_at', { ascending: false })
        .limit(pageSize)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const result = data as MomentumMeetingListItem[];
      setOrphanedData(result);
      setOrphanedOffset(result.length);
      setOrphanedHasMore(result.length >= pageSize);
      return result;
    },
    refetchOnMount: 'always',
    staleTime: 0,
  });

  const loadMoreOrphaned = useCallback(async () => {
    if (!orphanedHasMore || orphanedLoadingMore) return;
    setOrphanedLoadingMore(true);
    try {
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select(MEETINGS_LIST_SELECT)
        .eq('status', 'imported')
        .is('matched_account_id', null)
        .order('imported_at', { ascending: false })
        .offset(orphanedOffset)
        .limit(pageSize)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const newData = data as MomentumMeetingListItem[];
      setOrphanedData(prev => [...prev, ...newData]);
      setOrphanedOffset(prev => prev + newData.length);
      setOrphanedHasMore(newData.length >= pageSize);
    } finally {
      setOrphanedLoadingMore(false);
    }
  }, [orphanedHasMore, orphanedLoadingMore, orphanedOffset, pageSize]);

  // Use accumulated data instead of query data
  const pendingMeetings = pendingData;
  const ignoredMeetings = ignoredData;
  const orphanedMeetings = orphanedData;

  // Fetch unanalyzed meetings count (imported but no transcript_reviews OR transcript exists but no insights)
  const { data: unanalyzedMeetings, isLoading: loadingUnanalyzed, refetch: refetchUnanalyzed } = useQuery({
    queryKey: ['momentum-meetings', 'unanalyzed'],
    queryFn: async () => {
      // Get imported meetings with transcripts (via gateway for decryption) - limit for performance
      const { data: importedMeetings, error: importedError } = await gateway
        .from('momentum_meetings')
        .select('id, momentum_id, title, start_time, matched_account_id, transcript_content')
        .eq('status', 'imported')
        .not('transcript_content', 'is', null)
        .order('start_time', { ascending: false })
        .limit(500)
        .execute();
      
      if (importedError) throw new Error(getErrorMessage(importedError));
      if (!importedMeetings?.length) return [];

      // Get all transcript_reviews - check both UUID and numeric formats for compatibility
      const allFileNames = importedMeetings.flatMap(m => [
        `momentum_${m.id}`,           // UUID format
        `momentum_${m.momentum_id}`   // Numeric format
      ]);
      const { data: existingReviews, error: reviewsError } = await gateway
        .from('transcript_reviews')
        .select('file_name, extracted_insights')
        .in('file_name', allFileNames)
        .execute();
      
      if (reviewsError) throw new Error(getErrorMessage(reviewsError));

      // Track which have proper reviews with insights
      const reviewsMap = new Map<string, boolean>();
      existingReviews?.forEach(r => {
        // Mark as analyzed only if extracted_insights is NOT null
        const hasInsights = r.extracted_insights !== null;
        reviewsMap.set(r.file_name, hasInsights);
      });
      
      // Return meetings that either:
      // 1. Don't have transcript_reviews at all
      // 2. Have transcript_reviews but with null extracted_insights (analysis failed)
      return importedMeetings.filter(m => {
        const uuidKey = `momentum_${m.id}`;
        const numericKey = `momentum_${m.momentum_id}`;
        
        const hasUuidReview = reviewsMap.has(uuidKey);
        const hasNumericReview = reviewsMap.has(numericKey);
        
        // If no review exists, it's unanalyzed
        if (!hasUuidReview && !hasNumericReview) {
          return m.matched_account_id; // Only include if has account
        }
        
        // If review exists, check if it has insights
        const uuidHasInsights = reviewsMap.get(uuidKey) || false;
        const numericHasInsights = reviewsMap.get(numericKey) || false;
        
        // If review exists but no insights, it's unanalyzed (analysis failed)
        if ((hasUuidReview && !uuidHasInsights) || (hasNumericReview && !numericHasInsights)) {
          return m.matched_account_id; // Only include if has account
        }
        
        return false; // Has proper analysis
      });
    },
  });

  // Backfill mutation
  const backfillMutation = useMutation({
    mutationFn: async (meetingIds: string[]) => {
      // Immediately mark selected meetings as processing in local state
      setProcessingMeetings(prev => {
        const next = new Map(prev);
        meetingIds.forEach(id => next.set(id, { status: 'processing' }));
        return next;
      });
      
      const { data, error } = await supabase.functions.invoke(
        'backfill-transcript-insights',
        {
          body: { meetingIds, limit: meetingIds.length },
        }
      );
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      if (data.queued) {
        toast.success(`Started AI analysis for ${data.queued} transcripts`, {
          description: 'Watch the progress below. Meetings will be removed when complete.',
        });
        // Clear selection after starting
        setSelectedUnanalyzedIds(new Set());
      } else if (data.processed) {
        toast.success(`Processed ${data.processed} transcripts`);
        refetchUnanalyzed();
      } else {
        toast.info('No transcripts need analysis');
        // Clear processing state if nothing to process
        setProcessingMeetings(new Map());
      }
    },
    onError: (error) => {
      toast.error('Failed to start backfill', { description: String(error) });
      // Clear processing state on error
      setProcessingMeetings(new Map());
    },
  });
  
  // Realtime subscription to track meeting status changes during analysis
  useEffect(() => {
    if (processingMeetings.size === 0) return;
    
    const channel = supabase
      .channel('momentum-meetings-processing')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'momentum_meetings',
        },
        (payload) => {
          const meetingId = payload.new.id as string;
          const newStatus = payload.new.status as string;
          
          // Only care about meetings we're tracking
          if (!processingMeetings.has(meetingId)) return;
          
          if (newStatus === 'imported') {
            // Meeting completed processing - check if transcript_review was created
            // by refetching after a brief delay
            setAnalyzedMeetingIds(prev => new Set(prev).add(meetingId));
            setProcessingMeetings(prev => {
              const next = new Map(prev);
              next.delete(meetingId);
              return next;
            });
            
            // Refetch to update the list
            setTimeout(() => refetchUnanalyzed(), 500);
          }
        }
      )
      .subscribe();
    
    return () => {
      supabase.removeChannel(channel);
    };
  }, [processingMeetings.size > 0, refetchUnanalyzed]);
  
  // Auto-clear analyzed meetings from UI after a moment (immediate removal)
  useEffect(() => {
    if (analyzedMeetingIds.size === 0) return;
    
    // Clear immediately since user wants immediate removal
    const timeout = setTimeout(() => {
      setAnalyzedMeetingIds(new Set());
    }, 100);
    
    return () => clearTimeout(timeout);
  }, [analyzedMeetingIds]);

  useEffect(() => {
    if (isImportModalOpen) setOpeningMeetingId(null);
  }, [isImportModalOpen]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('backfill') !== '1') return;

    setBackfillOpen(true);
    window.setTimeout(() => {
      backfillPanelRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 0);

    params.delete('backfill');
    navigate(
      {
        pathname: location.pathname,
        search: params.toString() ? `?${params.toString()}` : "",
      },
      { replace: true }
    );
  }, [location.pathname, location.search, navigate]);

  // If the dialog doesn't open (e.g. portal/z-index issue), don't leave the button stuck in "Opening…"
  useEffect(() => {
    if (!openingMeetingId) return;

    const t = window.setTimeout(() => {
      if (!isImportModalOpen) {
        setOpeningMeetingId(null);
        toast.error('Import dialog did not open. Please try again.');
      }
    }, 1500);

    return () => window.clearTimeout(t);
  }, [openingMeetingId, isImportModalOpen]);


  // Fetch last sync state
  const { data: syncState } = useQuery({
    queryKey: ['momentum-sync-state'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('momentum_sync_state')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data?.[0] || null;
      return data;
    },
  });

  // Fetch metrics for dashboard
  const { data: metrics } = useQuery({
    queryKey: ['momentum-metrics'],
    queryFn: async () => {
      // Use exact counts via gateway to bypass RLS and avoid 1000-row limit
      const [totalImportedRes, toExistingRes, newThisWeekRes] = await Promise.all([
        gateway.from('momentum_meetings').select('id').eq('status', 'imported').countOnly().execute(),
        gateway.from('momentum_meetings').select('id').eq('status', 'imported').not('matched_account_id', 'is', null).countOnly().execute(),
        gateway.from('momentum_meetings').select('id').in('status', ['pending', 'processing']).gte('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()).countOnly().execute(),
      ]);
      const totalImportedCount = (totalImportedRes.data as any)?.count ?? 0;
      const toExistingCount = (toExistingRes.data as any)?.count ?? 0;
      const newThisWeekCount = (newThisWeekRes.data as any)?.count ?? 0;

      // Fetch recent 20 imported meetings to existing accounts (for the expandable list)
      const { data: recentToExisting } = await gateway
        .from('momentum_meetings')
        .select('id, title, matched_account_id, imported_at, start_time')
        .eq('status', 'imported')
        .not('matched_account_id', 'is', null)
        .order('imported_at', { ascending: false })
        .limit(20)
        .execute();

      // Fetch account names for the list
      const matchedAccountIds = [...new Set((recentToExisting || []).map((m: any) => m.matched_account_id as string))];
      let accountsMap: Record<string, string> = {};
      if (matchedAccountIds.length > 0) {
        const { data: accountsData } = await gateway
          .from('accounts')
          .select('id, name')
          .in('id', matchedAccountIds)
          .execute();
        accountsMap = (accountsData || []).reduce((acc: Record<string, string>, a: any) => {
          acc[a.id] = a.name;
          return acc;
        }, {});
      }

      // Get accounts where team members were added from meetings
      const { data: accountsWithTeam } = await gateway
        .from('account_team_members')
        .select('account_id, team_member_email, added_from_meeting_id')
        .not('added_from_meeting_id', 'is', null)
        .execute();

      const { data: teamMembers } = await gateway
        .from('team_members')
        .select('member_email')
        .execute();
      
      const teamEmails = new Set(teamMembers?.map(t => t.member_email.toLowerCase()) || []);
      if (user?.email) teamEmails.add(user.email.toLowerCase());

      const accountsFromTeamMeetings = new Set(
        accountsWithTeam?.filter(atm => 
          teamEmails.has(atm.team_member_email.toLowerCase())
        ).map(atm => atm.account_id) || []
      );

      return {
        newMeetingsThisWeek: newThisWeekCount || 0,
        totalImported: totalImportedCount || 0,
        meetingsToExistingAccounts: toExistingCount || 0,
        meetingsToExistingList: (recentToExisting || []).map((m: any) => ({
          id: m.id,
          title: m.title,
          accountId: m.matched_account_id,
          accountName: accountsMap[m.matched_account_id] || 'Unknown',
          importedAt: m.imported_at,
          startTime: m.start_time,
        })),
        accountsFromTeam: accountsFromTeamMeetings.size,
      };
    },
    enabled: !!user,
  });

  // Step 1 modal data: fetch a single meeting with transcript (via gateway for decryption)
  const { data: basicMeeting, isLoading: basicMeetingLoading } = useQuery({
    queryKey: ['momentum-meeting-basic', basicImportMeetingId],
    queryFn: async () => {
      if (!basicImportMeetingId) return null;
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select('id,title,start_time,end_time,host_email,host_name,status,salesforce_account_id,salesforce_opportunity_id,attendees,matched_account_id,transcript_content')
        .eq('id', basicImportMeetingId)
        .single()
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as any;
    },
    enabled: !!basicImportMeetingId,
  });

  // Step 2: fetch accounts for selection
  const { data: accounts } = useQuery({
    queryKey: ['accounts-list-for-import'],
    queryFn: async () => {
      // Fetch all accounts - need to paginate past the 1000-row default limit
      const allAccounts: { id: string; name: string; salesforce_account_id: string | null }[] = [];
      let offset = 0;
      const batchSize = 1000;
      let hasMore = true;
      while (hasMore) {
        const { data, error } = await gateway
          .from('accounts')
          .select('id, name, salesforce_account_id')
          .order('name', { ascending: true })
          .range(offset, offset + batchSize - 1)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        if (data && data.length > 0) {
          allAccounts.push(...(data as typeof allAccounts));
          offset += batchSize;
          hasMore = data.length === batchSize;
        } else {
          hasMore = false;
        }
      }
      return allAccounts;
    },
  });

  // Reset modal state when it opens
  useEffect(() => {
    if (basicImportMeetingId) {
      setSelectedAccountId("");
      setCreateNewAccount(false);
      setNewAccountName("");
      setImportStep(1);
      setIsImporting(false);
      setImportStage("");
      setImportProgress(0);
    }
  }, [basicImportMeetingId]);

  // Auto-advance from Step 1 → Step 3 when the meeting has a definitively matched account
  // (matched_account_id set, OR SFID maps to an existing account in the loaded accounts list)
  useEffect(() => {
    if (!basicMeeting || !accounts || importStep !== 1) return;

    // If matched_account_id is already set, go straight to Step 3
    if (basicMeeting.matched_account_id) {
      setSelectedAccountId(basicMeeting.matched_account_id);
      setCreateNewAccount(false);
      setImportStep(3);
      return;
    }

    // If SFID matches an account in our local list, pre-select and go to Step 3
    if (basicMeeting.salesforce_account_id) {
      const sfMatch = accounts.find(a => a.salesforce_account_id === basicMeeting.salesforce_account_id);
      if (sfMatch) {
        setSelectedAccountId(sfMatch.id);
        setCreateNewAccount(false);
        setImportStep(3);
      }
    }
  }, [basicMeeting, accounts, importStep]);

  // Extract unique attendees for filter dropdown, grouped by company
  const groupedAttendees = useMemo(() => {
    const allMeetings = [...(pendingMeetings || []), ...(ignoredMeetings || [])];
    const attendeeMap = new Map<string, { name: string; email: string; company: string }>();
    
    allMeetings.forEach(meeting => {
      (meeting.attendees || []).forEach((a: any) => {
        if (a.name || a.email) {
          const email = a.email || '';
          const domain = email.split('@')[1]?.toLowerCase() || 'unknown';
          const company = a.isInternal ? 'Pendo' : domain.split('.')[0] || 'Unknown';
          const key = a.name || a.email;
          
          if (!attendeeMap.has(key)) {
            attendeeMap.set(key, {
              name: a.name || a.email,
              email: email,
              company: company.charAt(0).toUpperCase() + company.slice(1),
            });
          }
        }
      });
    });

    // Group by company
    const grouped: Record<string, { name: string; email: string }[]> = {};
    attendeeMap.forEach((attendee) => {
      if (!grouped[attendee.company]) {
        grouped[attendee.company] = [];
      }
      grouped[attendee.company].push({ name: attendee.name, email: attendee.email });
    });

    // Sort attendees within each group by name
    Object.keys(grouped).forEach(company => {
      grouped[company].sort((a, b) => a.name.localeCompare(b.name));
    });

    // Sort companies: Pendo first, then alphabetically
    const sortedCompanies = Object.keys(grouped).sort((a, b) => {
      if (a === 'Pendo') return -1;
      if (b === 'Pendo') return 1;
      return a.localeCompare(b);
    });

    return { grouped, sortedCompanies };
  }, [pendingMeetings, ignoredMeetings]);

  // Filter function
  const filterMeetings = (meetings: MomentumMeetingListItem[] | undefined) => {
    if (!meetings) return [];
    
    return meetings.filter(meeting => {
      // Filter out internal-only meetings (no external attendees)
      const externalAttendees = (meeting.attendees || []).filter((a: any) => !a.isInternal);
      if (externalAttendees.length === 0) return false;

      // My meetings filter - check if user is host or attendee
      if (myMeetingsOnly && user?.email) {
        const userEmail = user.email.toLowerCase();
        const isHost = meeting.host_email?.toLowerCase() === userEmail;
        const isAttendee = (meeting.attendees || []).some((a: any) => 
          a.email?.toLowerCase() === userEmail
        );
        if (!isHost && !isAttendee) return false;
      }

      // Search filter (title, host)
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = meeting.title.toLowerCase().includes(query);
        const matchesHost =
          meeting.host_name?.toLowerCase().includes(query) ||
          meeting.host_email?.toLowerCase().includes(query);
        if (!matchesTitle && !matchesHost) return false;
      }

      // Attendee filter - search ALL attendees (internal and external)
      if (attendeeFilter) {
        const allAttendeeNames = (meeting.attendees || [])
          .map((a: any) => (a.name || a.email).toLowerCase());
        if (!allAttendeeNames.some(name => name.includes(attendeeFilter.toLowerCase()))) return false;
      }

      // Date from filter
      if (dateFrom) {
        const meetingDate = new Date(meeting.start_time);
        if (isBefore(meetingDate, startOfDay(dateFrom))) return false;
      }

      // Date to filter
      if (dateTo) {
        const meetingDate = new Date(meeting.start_time);
        if (isAfter(meetingDate, endOfDay(dateTo))) return false;
      }

      return true;
    });
  };

  // Use search index results if available, otherwise fall back to client-side filtering
  const hasSearchFilters = searchQuery || attendeeFilter || dateFrom || dateTo || myMeetingsOnly;
  
  // Convert search results to MeetingCard-compatible format for direct rendering
  const convertSearchResultToMeeting = useCallback((result: import("@/hooks/useMeetingSearchIndex").MeetingSearchResult): MomentumMeetingListItem => {
    // Reconstruct attendees array - internal count tells us how many are internal (first N)
    const attendees = result.attendee_names.map((name, i) => ({
      name,
      email: result.attendee_emails[i] || '',
      // The search result has internal_attendee_count which tells us how many internal attendees there are
      // But we don't know which ones are internal without the original data
      // For display purposes, we'll mark based on email domain as a fallback
      isInternal: (result.attendee_emails[i] || '').toLowerCase().includes('@pendo.io'),
    }));
    
    return {
      id: result.meeting_id,
      momentum_id: '', // Not needed for display
      title: result.title || 'Untitled Meeting',
      start_time: result.start_time,
      end_time: result.end_time,
      host_email: result.host_email,
      host_name: result.host_name,
      attendees,
      salesforce_account_id: result.salesforce_account_id,
      salesforce_opportunity_id: result.salesforce_opportunity_id,
      status: result.status || 'pending',
      matched_account_id: result.matched_account_id,
      imported_at: null,
      ignored_at: null,
      created_at: result.start_time,
      opportunity_id: null,
    };
  }, []);
  
  const filteredPendingMeetings = useMemo(() => {
    // When search filters are active, use search results directly for complete coverage
    if (hasSearchFilters && pendingSearchResults) {
      return pendingSearchResults.map(convertSearchResultToMeeting);
    }
    // No filters: use locally-paginated data with client-side filtering
    if (!pendingMeetings) return [];
    return filterMeetings(pendingMeetings);
  }, [pendingMeetings, pendingSearchResults, hasSearchFilters, convertSearchResultToMeeting, searchQuery, attendeeFilter, dateFrom, dateTo, myMeetingsOnly, user?.email]);
  
  const filteredIgnoredMeetings = useMemo(() => {
    if (hasSearchFilters && ignoredSearchResults) {
      return ignoredSearchResults.map(convertSearchResultToMeeting);
    }
    if (!ignoredMeetings) return [];
    return filterMeetings(ignoredMeetings);
  }, [ignoredMeetings, ignoredSearchResults, hasSearchFilters, convertSearchResultToMeeting, searchQuery, attendeeFilter, dateFrom, dateTo, myMeetingsOnly, user?.email]);

  const filteredOrphanedMeetings = useMemo(() => {
    // For orphaned, we filter imported meetings with no matched_account_id
    if (hasSearchFilters && orphanedSearchResults) {
      return orphanedSearchResults
        .filter(r => !r.matched_account_id)
        .map(convertSearchResultToMeeting);
    }
    if (!orphanedMeetings) return [];
    return filterMeetings(orphanedMeetings);
  }, [orphanedMeetings, orphanedSearchResults, hasSearchFilters, convertSearchResultToMeeting, searchQuery, attendeeFilter, dateFrom, dateTo, myMeetingsOnly, user?.email]);

  const hasActiveFilters = searchQuery || attendeeFilter || dateFrom || dateTo || !myMeetingsOnly;

  const clearFilters = () => {
    setSearchQuery("");
    setAttendeeFilter("");
    setDateFrom(undefined);
    setDateTo(undefined);
    setMyMeetingsOnly(true); // Reset to default ON
  };

  // Manual sync mutation
  const syncMutation = useMutation({
    mutationFn: async (params?: { from?: string; to?: string; teamOnly?: boolean; salesforceAccountId?: string; meetingId?: string }) => {
      // Build URL with query params if provided
      let url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/sync-momentum`;
      const queryParams = new URLSearchParams();
      if (params?.from) queryParams.set('from', params.from);
      if (params?.to) queryParams.set('to', params.to);
      if (typeof params?.teamOnly === 'boolean') queryParams.set('teamOnly', String(params.teamOnly));
      if (params?.salesforceAccountId) queryParams.set('salesforceAccountId', params.salesforceAccountId);
      if (params?.meetingId) queryParams.set('meetingId', params.meetingId);
      if (queryParams.toString()) url += `?${queryParams.toString()}`;
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 120000); // 2 minute timeout
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        signal: controller.signal,
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || `HTTP ${response.status}`);
      }
      
      const data = await response.json();
      if (data?.error) {
        throw new Error(data.error);
      }
      return data;
    },
    onSuccess: (data) => {
      toast.success(`Sync completed: ${data.newMeetings} new meetings, ${data.autoMatched} auto-matched`);
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['momentum-sync-state'] });
      setHistoricalSyncOpen(false);
    },
    onError: (error: Error) => {
      const message = error.message || 'Unknown error';
      // Handle timeout/abort - the backend likely completed successfully
      if (error.name === 'AbortError' || message.includes('Failed to fetch') || message.includes('aborted')) {
        toast.info('Sync is still running in the background. Meetings will appear shortly — refresh in a moment.', {
          duration: 8000,
        });
        // Still invalidate queries so new data shows up on next poll
        queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
        queryClient.invalidateQueries({ queryKey: ['momentum-sync-state'] });
        setHistoricalSyncOpen(false);
      } else if (message.includes('MOMENTUM_API_KEY') || message.includes('not configured')) {
        toast.error('Momentum API key is not configured. Please add the MOMENTUM_API_KEY secret in your backend settings.', {
          duration: 8000,
        });
      } else if (message.includes('401') || message.includes('403') || message.includes('Unauthorized')) {
        toast.error('Momentum API key is invalid or expired. Please update the MOMENTUM_API_KEY secret.', {
          duration: 8000,
        });
      } else if (message.includes('WORKER_LIMIT') || message.includes('Memory limit')) {
        toast.error('Too many meetings in date range. Try a smaller range (1-2 weeks max).', {
          duration: 8000,
        });
      } else {
        toast.error(`Sync failed: ${message}`);
      }
    },
  });

  // Process pending imports mutation (runs AI analysis in parallel)
  const processPendingMutation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke('sync-momentum', {
        body: {},
        headers: {},
      });
      // Workaround: invoke with query param via direct fetch
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/sync-momentum?action=process-pending`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
        }
      );
      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || 'Failed to process pending imports');
      }
      return response.json();
    },
    onSuccess: (data) => {
      if (data.processed > 0) {
        toast.success(`Processing ${data.processed} pending imports in parallel`);
      } else {
        toast.info('No pending imports to process');
      }
      refreshAllMeetings();
    },
    onError: (error: Error) => {
      toast.error(`Process failed: ${error.message}`);
    },
  });

  // Ignore meeting mutation
  const ignoreMutation = useMutation({
    mutationFn: async (meetingId: string) => {
      const { error } = await gateway
        .from('momentum_meetings')
        .update({
          status: 'ignored',
          ignored_at: new Date().toISOString(),
        })
        .eq('id', meetingId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      toast.success("Meeting archived");
      refreshAllMeetings();
    },
  });

  // Restore meeting mutation
  const restoreMutation = useMutation({
    mutationFn: async (meetingId: string) => {
      const { error } = await gateway
        .from('momentum_meetings')
        .update({
          status: 'pending',
          ignored_at: null,
        })
        .eq('id', meetingId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      toast.success("Meeting restored");
      refreshAllMeetings();
    },
  });

  // Reset stuck processing meetings back to pending ("locks")
  const resetProcessingMutation = useMutation({
    mutationFn: async (meetingId: string) => {
      await revertMeetingToPending(meetingId);
    },
    onSuccess: () => {
      toast.success('Meeting reset to pending');
      refreshAllMeetings();
    },
    onError: (error: any) => {
      toast.error(`Reset failed: ${error?.message || 'Unknown error'}`);
    },
  });

  // Direct-import mutation (exception flow for problematic meetings)
  const directImportMutation = useMutation({
    mutationFn: async (meetingId: string) => {
      await directImportMomentumMeetingById(meetingId);
    },
    onSuccess: () => {
      toast.success('Meeting imported');
      refreshAllMeetings();
    },
    onError: (error: any) => {
      const msg = error?.message || 'Unknown error';
      toast.error(`Direct import failed: ${msg}`);
    },
    onSettled: () => {
      setDirectImportingMeetingId(null);
    },
  });

  // Import is handled by useImportModal

  // Handler for opening the import modal
  const handleImportClick = (meetingId: string) => {
    toast.message('Opening import…', { duration: 1200 });
    console.debug('[MomentumMeetingsView] import_click', { meetingId });
    setBasicImportMeetingId(meetingId);
  };


  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-heading">Momentum Meetings</h1>
          <p className="text-muted-foreground">Import call recordings and run AI discovery</p>
        </div>
        <div className="flex items-center gap-4">
          {syncState && (
            <span className="text-sm text-muted-foreground">
              Last sync: {safeFormat(syncState.last_sync_at, 'MMM d, h:mm a')}
            </span>
          )}
          <Button 
            variant="outline"
            onClick={() => processPendingMutation.mutate()} 
            disabled={processPendingMutation.isPending}
          >
            {processPendingMutation.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Download className="h-4 w-4 mr-2" />
            )}
            Process Pending
          </Button>
          <Button onClick={() => syncMutation.mutate({})} disabled={syncMutation.isPending}>
            {syncMutation.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4 mr-2" />
            )}
            Sync Now
          </Button>
          <Popover open={historicalSyncOpen} onOpenChange={setHistoricalSyncOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" disabled={syncMutation.isPending}>
                <CalendarDays className="h-4 w-4 mr-2" />
                Backfill
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-1">Historical Sync</h4>
                  <p className="text-sm text-muted-foreground">
                    Sync meetings from a specific date range. Use 1-2 week chunks to avoid memory limits.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs text-muted-foreground">From</label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full justify-start text-left font-normal">
                          <Calendar className="h-3.5 w-3.5 mr-1.5" />
                          {historicalFromDate ? format(historicalFromDate, 'MMM d') : 'Start'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <CalendarComponent
                          mode="single"
                          selected={historicalFromDate}
                          onSelect={setHistoricalFromDate}
                          disabled={(date) => date > new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground">To</label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full justify-start text-left font-normal">
                          <Calendar className="h-3.5 w-3.5 mr-1.5" />
                          {historicalToDate ? format(historicalToDate, 'MMM d') : 'End'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <CalendarComponent
                          mode="single"
                          selected={historicalToDate}
                          onSelect={setHistoricalToDate}
                          disabled={(date) => date > new Date() || (historicalFromDate && date < historicalFromDate)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={historicalTeamOnly}
                    onCheckedChange={(v) => setHistoricalTeamOnly(v === true)}
                    id="historical-team-only"
                  />
                  <label htmlFor="historical-team-only" className="text-sm">
                    Team meetings only
                  </label>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Salesforce Account ID (optional)</label>
                  <Input
                    placeholder="e.g. 0015000000AbCdE"
                    value={historicalSfAccountId}
                    onChange={(e) => setHistoricalSfAccountId(e.target.value.trim())}
                    className="mt-1"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Filter to only sync meetings for a specific account
                  </p>
                </div>
                
                <Button 
                  className="w-full" 
                  disabled={!historicalFromDate || !historicalToDate || syncMutation.isPending}
                  onClick={() => {
                    if (historicalFromDate && historicalToDate) {
                      syncMutation.mutate({
                        from: format(historicalFromDate, 'yyyy-MM-dd'),
                        to: format(historicalToDate, 'yyyy-MM-dd'),
                        teamOnly: historicalTeamOnly,
                        salesforceAccountId: historicalSfAccountId || undefined,
                      });
                    }
                  }}
                >
                  {syncMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Syncing...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Sync Date Range
                    </>
                  )}
                </Button>

                <div className="border-t pt-3 mt-1">
                  <h4 className="font-medium mb-1 text-sm">Import by Meeting ID</h4>
                  <p className="text-xs text-muted-foreground mb-2">
                    Paste a Momentum meeting ID to fetch a specific meeting.
                  </p>
                  <div className="flex gap-2">
                    <Input
                      placeholder="e.g. 2748223"
                      value={singleMeetingId}
                      onChange={(e) => setSingleMeetingId(e.target.value.trim())}
                      className="flex-1"
                    />
                    <Button
                      size="sm"
                      disabled={!singleMeetingId || syncMutation.isPending}
                      onClick={() => {
                        syncMutation.mutate({ meetingId: singleMeetingId });
                        setSingleMeetingId('');
                      }}
                    >
                      {syncMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Download className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>

      {/* Metrics Dashboard */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-border/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Plus className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{metrics?.newMeetingsThisWeek ?? '-'}</p>
                <p className="text-sm text-muted-foreground">New This Week</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-border/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <TrendingUp className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{metrics?.totalImported ?? '-'}</p>
                <p className="text-sm text-muted-foreground">Total Imported</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Collapsible open={existingAccountsOpen} onOpenChange={setExistingAccountsOpen}>
          <Card className="border-border/50">
            <CollapsibleTrigger asChild>
              <CardContent className="pt-4 cursor-pointer hover:bg-muted/30 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-blue-500/10">
                    <Building2 className="h-5 w-5 text-blue-500" />
                  </div>
                  <div className="flex-1">
                    <p className="text-2xl font-bold">{metrics?.meetingsToExistingAccounts ?? '-'}</p>
                    <p className="text-sm text-muted-foreground">To Existing Accounts</p>
                  </div>
                  {existingAccountsOpen ? (
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
              </CardContent>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="px-6 pb-4 pt-0 border-t border-border/50">
                <div className="mt-3 space-y-2 max-h-64 overflow-y-auto">
                  {metrics?.meetingsToExistingList?.length ? (
                    metrics.meetingsToExistingList.map((meeting: any) => (
                      <div 
                        key={meeting.id} 
                        className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors group"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{meeting.title}</p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span>{meeting.accountName}</span>
                            <span>•</span>
                            <span>{safeFormat(meeting.startTime, 'MMM d, yyyy')}</span>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => navigate(`/accounts/${meeting.accountId}`)}
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      No meetings imported yet
                    </p>
                  )}
                </div>
              </div>
            </CollapsibleContent>
          </Card>
        </Collapsible>
        
        <Card className="border-border/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Users className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{metrics?.accountsFromTeam ?? '-'}</p>
                <p className="text-sm text-muted-foreground">Accounts From Team</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Unanalyzed Transcripts Alert */}
      {(unanalyzedMeetings?.length || 0) > 0 && (
        <Collapsible>
          <Card className="border-amber-500/50 bg-amber-500/5">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between gap-4">
                <CollapsibleTrigger className="flex items-center gap-3 cursor-pointer hover:opacity-80 transition-opacity flex-1">
                  <div className="p-2 rounded-lg bg-amber-500/20">
                    <AlertCircle className="h-5 w-5 text-amber-600" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-amber-700">
                      {unanalyzedMeetings?.length} transcript{unanalyzedMeetings?.length !== 1 ? 's' : ''} not analyzed
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Click to see details • AI analysis was not completed (likely due to credit limits)
                    </p>
                  </div>
                  <ChevronDown className="h-4 w-4 text-amber-600 ml-2" />
                </CollapsibleTrigger>
                <Button
                  onClick={(e) => {
                    e.stopPropagation();
                    backfillMutation.mutate(unanalyzedMeetings?.map(m => m.id) || []);
                  }}
                  disabled={backfillMutation.isPending}
                  className="shrink-0"
                >
                  {backfillMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Starting...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Run AI Analysis
                    </>
                  )}
                </Button>
              </div>
              <CollapsibleContent>
                {unanalyzedMeetings && unanalyzedMeetings.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-amber-500/20 space-y-2">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id="select-all-unanalyzed"
                          checked={selectedUnanalyzedIds.size === unanalyzedMeetings.length}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedUnanalyzedIds(new Set(unanalyzedMeetings.map(m => m.id)));
                            } else {
                              setSelectedUnanalyzedIds(new Set());
                            }
                          }}
                        />
                        <label 
                          htmlFor="select-all-unanalyzed" 
                          className="text-xs font-medium text-muted-foreground cursor-pointer"
                        >
                          {selectedUnanalyzedIds.size === unanalyzedMeetings.length 
                            ? 'Deselect all' 
                            : 'Select all'} ({unanalyzedMeetings.length} meetings)
                        </label>
                      </div>
                      {selectedUnanalyzedIds.size > 0 && (
                        <Button
                          size="sm"
                          onClick={() => backfillMutation.mutate(Array.from(selectedUnanalyzedIds))}
                          disabled={backfillMutation.isPending}
                        >
                          {backfillMutation.isPending ? (
                            <>
                              <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                              Starting...
                            </>
                          ) : (
                            <>
                              <Sparkles className="h-3 w-3 mr-1" />
                              Analyze {selectedUnanalyzedIds.size} selected
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {unanalyzedMeetings
                        .filter(meeting => !analyzedMeetingIds.has(meeting.id))
                        .map(meeting => {
                          const processingState = processingMeetings.get(meeting.id);
                          const isProcessing = processingState?.status === 'processing';
                          const hasError = processingState?.status === 'error';
                          
                          return (
                            <div 
                              key={meeting.id} 
                              className={cn(
                                "flex flex-col gap-2 p-3 rounded-lg border transition-all",
                                isProcessing && "bg-primary/5 border-primary/30",
                                hasError && "bg-destructive/5 border-destructive/30",
                                !isProcessing && !hasError && "bg-background/50 border-border/50"
                              )}
                            >
                              <div className="flex items-center gap-3">
                                {isProcessing ? (
                                  <div className="flex items-center justify-center w-5 h-5">
                                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                                  </div>
                                ) : hasError ? (
                                  <div className="flex items-center justify-center w-5 h-5">
                                    <AlertCircle className="h-4 w-4 text-destructive" />
                                  </div>
                                ) : (
                                  <Checkbox
                                    id={`meeting-${meeting.id}`}
                                    checked={selectedUnanalyzedIds.has(meeting.id)}
                                    onCheckedChange={(checked) => {
                                      const newSet = new Set(selectedUnanalyzedIds);
                                      if (checked) {
                                        newSet.add(meeting.id);
                                      } else {
                                        newSet.delete(meeting.id);
                                      }
                                      setSelectedUnanalyzedIds(newSet);
                                    }}
                                  />
                                )}
                                <label 
                                  htmlFor={`meeting-${meeting.id}`}
                                  className="flex-1 min-w-0 cursor-pointer"
                                >
                                  <p className="font-medium text-sm truncate">{meeting.title}</p>
                                  <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                                    <Calendar className="h-3 w-3" />
                                    <span>{safeFormat(meeting.start_time, 'MMM d, yyyy h:mm a')}</span>
                                    {isProcessing && (
                                      <Badge variant="outline" className="text-[10px] ml-2 border-primary/50 text-primary">
                                        Analyzing...
                                      </Badge>
                                    )}
                                    {hasError && (
                                      <Badge variant="outline" className="text-[10px] ml-2 border-destructive/50 text-destructive">
                                        Failed
                                      </Badge>
                                    )}
                                    {!isProcessing && !hasError && meeting.matched_account_id && (
                                      <Badge variant="secondary" className="text-[10px] ml-2">
                                        Has Account
                                      </Badge>
                                    )}
                                    {!isProcessing && !hasError && !meeting.matched_account_id && (
                                      <Badge variant="outline" className="text-[10px] ml-2 border-amber-500/50 text-amber-600">
                                        No Account
                                      </Badge>
                                    )}
                                  </div>
                                </label>
                                {hasError && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => {
                                      // Clear error and allow retry
                                      setProcessingMeetings(prev => {
                                        const next = new Map(prev);
                                        next.delete(meeting.id);
                                        return next;
                                      });
                                    }}
                                  >
                                    <RotateCcw className="h-3 w-3" />
                                  </Button>
                                )}
                              </div>
                              {/* Progress bar for processing items */}
                              {isProcessing && (
                                <div className="w-full h-1.5 bg-primary/20 rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-primary rounded-full animate-pulse"
                                    style={{ width: '60%' }}
                                  />
                                </div>
                              )}
                              {/* Error message */}
                              {hasError && processingState.error && (
                                <p className="text-xs text-destructive truncate">
                                  {processingState.error}
                                </p>
                              )}
                            </div>
                          );
                        })}
                    </div>
                  </div>
                )}
              </CollapsibleContent>
            </CardContent>
          </Card>
        </Collapsible>
      )}

      <Card className="border-border/50">
        <CardContent className="pt-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="flex-1">
              <p className="text-sm font-medium">Open import modal by meeting ID</p>
              <p className="text-xs text-muted-foreground">Use this to isolate UI vs. data issues.</p>
            </div>
            <div className="flex flex-1 gap-2">
              <Input
                value={basicOpenMeetingIdInput}
                onChange={(e) => setBasicOpenMeetingIdInput(e.target.value)}
                placeholder="e.g. 0bbb97f0-6168-4ef2-8096-04734e493a33"
              />
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  const id = basicOpenMeetingIdInput.trim();
                  if (!id) return;
                  toast.message('Opening…', { duration: 900 });
                  setBasicImportMeetingId(id);
                }}
              >
                Open
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          {/* My Meetings Toggle */}
          <Button
            variant={myMeetingsOnly ? "default" : "outline"}
            onClick={() => setMyMeetingsOnly(!myMeetingsOnly)}
            className="flex items-center gap-2"
            size="sm"
          >
            <Users className="h-4 w-4" />
            My Meetings
          </Button>
          
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search meetings or hosts…"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Button
            variant={showFilters ? "secondary" : "outline"}
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2"
          >
            <Filter className="h-4 w-4" />
            Filters
            {(searchQuery || attendeeFilter || dateFrom || dateTo) && (
              <Badge variant="default" className="ml-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
                {[searchQuery, attendeeFilter, dateFrom, dateTo].filter(Boolean).length}
              </Badge>
            )}
          </Button>
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters}>
              Clear all
            </Button>
          )}
        </div>

        {showFilters && (
          <Card className="border-border/50">
            <CardContent className="pt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Attendee Filter */}
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Attendee
                  </label>
                  <Select 
                    value={attendeeFilter || "__all__"} 
                    onValueChange={(val) => setAttendeeFilter(val === "__all__" ? "" : val)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All attendees" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__all__">All attendees</SelectItem>
                      {groupedAttendees.sortedCompanies.map((company) => (
                        <SelectGroup key={company}>
                          <SelectLabel className="py-1 pl-2 pr-2 text-xs font-semibold text-muted-foreground">
                            {company}
                          </SelectLabel>
                          {groupedAttendees.grouped[company].map((attendee) => (
                            <SelectItem key={attendee.name} value={attendee.name} className="pl-4">
                              {attendee.name}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Date From */}
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <CalendarDays className="h-4 w-4" />
                    From Date
                  </label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal">
                        <Calendar className="mr-2 h-4 w-4" />
                        {dateFrom ? format(dateFrom, 'MMM d, yyyy') : 'Select start date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={dateFrom}
                        onSelect={setDateFrom}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                {/* Date To */}
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <CalendarDays className="h-4 w-4" />
                    To Date
                  </label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal">
                        <Calendar className="mr-2 h-4 w-4" />
                        {dateTo ? format(dateTo, 'MMM d, yyyy') : 'Select end date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={dateTo}
                        onSelect={setDateTo}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <Tabs defaultValue="pending">
        <TabsList>
          <TabsTrigger value="pending" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Pending
            {/* Show search index count if available (provides accurate total), otherwise filtered local data */}
            {(pendingSearchResults?.length ?? filteredPendingMeetings.length) > 0 && (
              <Badge variant="secondary">
                {pendingSearchResults?.length ?? filteredPendingMeetings.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="orphaned" className="flex items-center gap-2">
            <Building2 className="h-4 w-4" />
            Orphaned
            {(orphanedSearchResults?.filter(r => !r.matched_account_id).length ?? filteredOrphanedMeetings.length) > 0 && (
              <Badge variant="destructive">
                {orphanedSearchResults?.filter(r => !r.matched_account_id).length ?? filteredOrphanedMeetings.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="ignored" className="flex items-center gap-2">
            <X className="h-4 w-4" />
            Ignored
            {(ignoredSearchResults?.length ?? filteredIgnoredMeetings.length) > 0 && (
              <Badge variant="outline">
                {ignoredSearchResults?.length ?? filteredIgnoredMeetings.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="queue" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Processing Queue
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-4">
          {(loadingPending || loadingPendingSearch) ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filteredPendingMeetings.length > 0 ? (
            <>
              {filteredPendingMeetings.map((meeting) => (
                <MeetingCard
                  key={meeting.id}
                  meeting={meeting}
                  onImport={handleImportClick}
                  onIgnore={(id) => ignoreMutation.mutate(id)}
                  onRestore={(id) => restoreMutation.mutate(id)}
                  onResetProcessing={(id) => resetProcessingMutation.mutate(id)}
                  isIgnoring={ignoreMutation.isPending}
                  isRestoring={restoreMutation.isPending}
                  isResettingProcessing={resetProcessingMutation.isPending}
                  isImportingDirect={directImportingMeetingId === meeting.id && directImportMutation.isPending}
                  isOpening={openingMeetingId === meeting.id}
                />
              ))}
              {pendingHasMore && (
                <div className="flex justify-center py-4">
                  <Button
                    variant="outline"
                    onClick={loadMorePending}
                    disabled={pendingLoadingMore}
                  >
                    {pendingLoadingMore ? (
                      <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Loading...</>
                    ) : (
                      <>Load More ({pendingData.length} loaded)</>
                    )}
                  </Button>
                </div>
              )}
            </>
          ) : (
            <Card className="border-border/50">
              <CardContent className="py-8 text-center text-muted-foreground">
                <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                {hasActiveFilters ? (
                  <>
                    <p>No meetings match your filters</p>
                    <Button variant="link" onClick={clearFilters} className="mt-2">
                      Clear filters
                    </Button>
                  </>
                ) : (
                  <>
                    <p>No pending meetings to import</p>
                    <p className="text-sm mt-1">Meetings that match existing accounts are imported automatically</p>
                  </>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="orphaned" className="mt-4">
          {(loadingOrphaned || loadingOrphanedSearch) ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filteredOrphanedMeetings.length > 0 ? (
            <>
              <Card className="mb-4 border-amber-500/30 bg-amber-500/5">
                <CardContent className="py-3">
                  <p className="text-sm text-amber-600">
                    <strong>Orphaned meetings</strong> were imported to accounts that have since been deleted. 
                    You can re-import them to a different account.
                  </p>
                </CardContent>
              </Card>
              {filteredOrphanedMeetings.map((meeting) => (
                <MeetingCard
                  key={meeting.id}
                  meeting={meeting}
                  onImport={handleImportClick}
                  onIgnore={(id) => ignoreMutation.mutate(id)}
                  onRestore={(id) => restoreMutation.mutate(id)}
                  onResetProcessing={(id) => resetProcessingMutation.mutate(id)}
                  isIgnoring={ignoreMutation.isPending}
                  isRestoring={restoreMutation.isPending}
                  isResettingProcessing={resetProcessingMutation.isPending}
                  isImportingDirect={directImportingMeetingId === meeting.id && directImportMutation.isPending}
                  isOpening={openingMeetingId === meeting.id}
                />
              ))}
            </>
          ) : (
            <Card className="border-border/50">
              <CardContent className="py-8 text-center text-muted-foreground">
                <Building2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                {hasActiveFilters ? (
                  <>
                    <p>No orphaned meetings match your filters</p>
                    <Button variant="link" onClick={clearFilters} className="mt-2">
                      Clear filters
                    </Button>
                  </>
                ) : (
                  <p>No orphaned meetings</p>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="ignored" className="mt-4">
          {(loadingIgnored || loadingIgnoredSearch) ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filteredIgnoredMeetings.length > 0 ? (
            filteredIgnoredMeetings.map((meeting) => (
              <MeetingCard
                key={meeting.id}
                meeting={meeting}
                showRestore
                onImport={handleImportClick}
                onIgnore={(id) => ignoreMutation.mutate(id)}
                onRestore={(id) => restoreMutation.mutate(id)}
                onResetProcessing={(id) => resetProcessingMutation.mutate(id)}
                isIgnoring={ignoreMutation.isPending}
                isRestoring={restoreMutation.isPending}
                isResettingProcessing={resetProcessingMutation.isPending}
                isImportingDirect={directImportingMeetingId === meeting.id && directImportMutation.isPending}
                isOpening={openingMeetingId === meeting.id}
              />
            ))
          ) : (
            <Card className="border-border/50">
              <CardContent className="py-8 text-center text-muted-foreground">
                <X className="h-12 w-12 mx-auto mb-4 opacity-50" />
                {hasActiveFilters ? (
                  <>
                    <p>No archived meetings match your filters</p>
                    <Button variant="link" onClick={clearFilters} className="mt-2">
                      Clear filters
                    </Button>
                  </>
                ) : (
                  <p>No archived meetings</p>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="queue" className="mt-4">
          <ProcessingQueueTab />
        </TabsContent>
      </Tabs>

      {/* Incremental import modal - Step 1: meeting info, Step 2: account selection, Step 3: import */}
      <Dialog open={!!basicImportMeetingId} onOpenChange={(open) => (!open ? setBasicImportMeetingId(null) : undefined)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              Import Meeting {importStep === 1 ? '— Step 1: Review' : importStep === 2 ? '— Step 2: Select Account' : '— Step 3: Import'}
            </DialogTitle>
          </DialogHeader>

          {basicMeetingLoading ? (
            <div className="text-sm text-muted-foreground">Loading meeting…</div>
          ) : !basicMeeting ? (
            <div className="text-sm text-destructive">Meeting not found (or access denied).</div>
          ) : (
            <div className="space-y-4">
              {/* Step 1: Meeting info */}
              {importStep === 1 && (
                <>
                  <div className="rounded-lg border bg-card p-3">
                    <div className="grid gap-2 text-sm">
                      <div className="flex justify-between gap-3">
                        <span className="text-muted-foreground">Title</span>
                        <span className="font-medium text-right">{basicMeeting.title}</span>
                      </div>
                      <div className="flex justify-between gap-3">
                        <span className="text-muted-foreground">When</span>
                        <span className="font-medium">{safeFormat(basicMeeting.start_time, 'MMM d, yyyy • h:mm a')}</span>
                      </div>
                      <div className="flex justify-between gap-3">
                        <span className="text-muted-foreground">Host</span>
                        <span className="font-medium text-right">{basicMeeting.host_name || basicMeeting.host_email || '—'}</span>
                      </div>
                      <div className="flex justify-between gap-3">
                        <span className="text-muted-foreground">Attendees</span>
                        <span className="font-medium">{(basicMeeting.attendees || []).length}</span>
                      </div>
                      <div className="flex justify-between gap-3">
                        <span className="text-muted-foreground">Transcript</span>
                        <span className={cn("font-medium", !basicMeeting.transcript_content && "text-destructive")}>
                          {basicMeeting.transcript_content ? `${basicMeeting.transcript_content.length.toLocaleString()} chars` : 'MISSING'}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setBasicImportMeetingId(null)}>
                      Cancel
                    </Button>
                    <Button
                      type="button"
                      disabled={!basicMeeting.transcript_content}
                      onClick={() => setImportStep(2)}
                    >
                      Next: Select Account
                    </Button>
                  </div>
                </>
              )}

              {/* Step 2: Account selection */}
              {importStep === 2 && (
                <>
                  <div className="space-y-3">
                    <div>
                      <label className="text-sm font-medium">Select Account</label>
                      <Popover open={accountSearchOpen} onOpenChange={setAccountSearchOpen}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={accountSearchOpen}
                            className="mt-1 w-full justify-between font-normal"
                          >
                            {createNewAccount
                              ? `+ Create: ${newAccountName || 'new account'}`
                              : selectedAccountId
                                ? accounts?.find(a => a.id === selectedAccountId)?.name ?? 'Select account…'
                                : 'Search accounts…'}
                            <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                          <Command>
                            <CommandInput placeholder="Search accounts…" />
                            <CommandList>
                              <CommandEmpty>No accounts found.</CommandEmpty>
                              <CommandGroup>
                                <CommandItem
                                  value="__new__"
                                  onSelect={() => {
                                    setCreateNewAccount(true);
                                    setSelectedAccountId('');
                                    setAccountSearchOpen(false);
                                    // Auto-suggest account name from external attendees or meeting title
                                    if (!newAccountName) {
                                      const externalAttendees = (basicMeeting?.attendees || []).filter((a: any) => !a.isInternal);
                                      if (externalAttendees.length > 0) {
                                        const firstExternal = externalAttendees[0];
                                        const email = firstExternal.email || '';
                                        const domain = email.split('@')[1]?.toLowerCase() || '';
                                        const domainName = domain.split('.')[0];
                                        if (domainName && !['gmail', 'yahoo', 'hotmail', 'outlook', 'icloud', 'aol', 'mail', 'protonmail'].includes(domainName)) {
                                          setNewAccountName(domainName.charAt(0).toUpperCase() + domainName.slice(1));
                                        } else {
                                          const title = basicMeeting?.title || '';
                                          const cleanedTitle = title.replace(/^(meeting with|call with|sync with|intro:|intro to|introduction to)\s*/i, '').trim();
                                          if (cleanedTitle) {
                                            setNewAccountName(cleanedTitle.split(/[-–—|:]/)[0].trim());
                                          }
                                        }
                                      } else {
                                        const title = basicMeeting?.title || '';
                                        const cleanedTitle = title.replace(/^(meeting with|call with|sync with|intro:|intro to|introduction to)\s*/i, '').trim();
                                        if (cleanedTitle) {
                                          setNewAccountName(cleanedTitle.split(/[-–—|:]/)[0].trim());
                                        }
                                      }
                                    }
                                  }}
                                  className="text-primary font-medium"
                                >
                                  + Create new account
                                </CommandItem>
                                {accounts?.map((account) => (
                                  <CommandItem
                                    key={account.id}
                                    value={account.name}
                                    onSelect={() => {
                                      setCreateNewAccount(false);
                                      setSelectedAccountId(account.id);
                                      setAccountSearchOpen(false);
                                    }}
                                  >
                                    {account.name}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                    </div>

                    {createNewAccount && (
                      <div>
                        <label className="text-sm font-medium">New Account Name</label>
                        <Input
                          className="mt-1"
                          placeholder="Enter account name…"
                          value={newAccountName}
                          onChange={(e) => setNewAccountName(e.target.value)}
                          autoFocus
                        />
                      </div>
                    )}
                  </div>

                  <div className="flex justify-between gap-2">
                    <Button type="button" variant="ghost" onClick={() => setImportStep(1)}>
                      Back
                    </Button>
                    <Button
                      type="button"
                      disabled={!selectedAccountId && !(createNewAccount && newAccountName.trim())}
                      onClick={() => setImportStep(3)}
                    >
                      Next: Review & Import
                    </Button>
                  </div>
                </>
              )}

              {/* Step 3: Confirm & Import */}
              {importStep === 3 && (
                <>
                  <div className="rounded-lg border bg-card p-4 space-y-2">
                    <p className="text-sm font-medium">Ready to import</p>
                    <div className="grid gap-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Meeting</span>
                        <span className="font-medium truncate max-w-[240px]">{basicMeeting.title}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Account</span>
                        <span className="font-medium">
                          {createNewAccount
                            ? `Create: ${newAccountName}`
                            : accounts?.find((a) => a.id === selectedAccountId)?.name ?? '—'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Transcript</span>
                        <span className="font-medium">{basicMeeting.transcript_content?.length.toLocaleString()} chars</span>
                      </div>
                    </div>
                  </div>

                  {isImporting && (
                    <div className="rounded-lg border bg-muted/30 p-3">
                      <div className="flex items-center justify-between gap-3">
                        <p className="text-sm font-medium">{importStage || 'Working…'}</p>
                        <span className="text-xs text-muted-foreground">{Math.round(importProgress)}%</span>
                      </div>
                      <div className="mt-2 h-2 rounded-full bg-muted overflow-hidden">
                        <div className="h-full bg-primary transition-all" style={{ width: `${importProgress}%` }} />
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between gap-2">
                    <Button type="button" variant="ghost" onClick={() => setImportStep(2)} disabled={isImporting}>
                      Back
                    </Button>
                    <Button
                      type="button"
                      disabled={isImporting || (!createNewAccount && !selectedAccountId)}
                      onClick={async () => {
                        // Validate account selection before starting
                        if (!createNewAccount && !selectedAccountId) {
                          toast.error('Please select an account or create a new one');
                          return;
                        }
                        if (createNewAccount && !newAccountName.trim()) {
                          toast.error('Please enter an account name');
                          return;
                        }

                        setIsImporting(true);
                        setImportStage('Starting import…');
                        setImportProgress(5);

                        try {
                          let accountId = selectedAccountId;

                          // Create account if needed
                          if (createNewAccount) {
                            setImportStage('Creating account…');
                            setImportProgress(10);

                            // First check if this SFID already exists (avoids duplicate key error)
                            let existingAccount: { id: string; name: string } | null = null;
                            if (basicMeeting.salesforce_account_id) {
                              const { data: sfMatch } = await gateway
                                .from('accounts')
                                .select('id, name')
                                .eq('salesforce_account_id', basicMeeting.salesforce_account_id)
                                .maybeSingle();
                              existingAccount = sfMatch || null;
                            }

                            if (existingAccount?.id) {
                              // Already exists — use it directly
                              accountId = existingAccount.id;
                            } else {
                              const { data: inserted, error: createErr } = await gateway
                                .from('accounts')
                                .insert({
                                  name: newAccountName.trim(),
                                  salesforce_account_id: basicMeeting.salesforce_account_id,
                                })
                                .select('id, name')
                                .execute();

                              if (createErr) {
                                // Duplicate key — fetch by name as last resort
                                const isDupe = createErr.message?.includes('duplicate key') || createErr.code === '23505';
                                if (isDupe) {
                                  const { data: byName } = await gateway
                                    .from('accounts')
                                    .select('id, name')
                                    .eq('name', newAccountName.trim())
                                    .maybeSingle();
                                  if (!byName?.id) throw new Error(getErrorMessage(createErr));
                                  accountId = byName.id;
                                } else {
                                  throw new Error(getErrorMessage(createErr));
                                }
                              } else {
                                const newAccount = Array.isArray(inserted) ? inserted[0] : inserted;
                                if (!newAccount?.id) throw new Error('Account creation failed (no id returned)');
                                accountId = newAccount.id;
                              }
                            }
                          }

                          // Import the meeting using the shared import function
                          setImportStage('Running import steps…');
                          setImportProgress(20);

                          const meetingCore = {
                            id: basicMeeting.id,
                            momentum_id: basicMeeting.momentum_id || basicMeeting.id,
                            title: basicMeeting.title,
                            start_time: basicMeeting.start_time,
                            end_time: basicMeeting.end_time,
                            host_email: basicMeeting.host_email,
                            host_name: basicMeeting.host_name,
                            attendees: basicMeeting.attendees,
                            status: basicMeeting.status,
                            salesforce_account_id: basicMeeting.salesforce_account_id,
                            salesforce_opportunity_id: basicMeeting.salesforce_opportunity_id,
                            matched_account_id: basicMeeting.matched_account_id,
                          };

                          await importMomentumMeetingSteps({
                            meeting: meetingCore as any,
                            transcript: basicMeeting.transcript_content,
                            accountId,
                            onStage: setImportStage,
                            onProgress: setImportProgress,
                          });

                          setImportStage('Done!');
                          setImportProgress(100);
                          
                          // Close dialog FIRST before invalidating queries to avoid
                          // race condition where basicMeeting query refetches during close
                          setBasicImportMeetingId(null);
                          
                          // Then show toast and invalidate queries
                          toast.success('Meeting imported successfully');
                          queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
                        } catch (err: any) {
                          const msg = err?.message || 'Unknown error';
                          toast.error(`Import failed: ${msg}`);
                          setImportStage(`Failed: ${msg}`);
                        } finally {
                          setIsImporting(false);
                        }
                      }}
                    >
                      {isImporting ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                          Importing…
                        </>
                      ) : (
                        <>
                          <Download className="h-4 w-4 mr-1" />
                          Import & Analyze
                        </>
                      )}
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

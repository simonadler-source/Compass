import { useState, useMemo } from 'react';
import { 
  Target, 
  ArrowRight, 
  Building2, 
  Calendar, 
  TrendingUp,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Zap,
  Filter,
  ChevronDown,
  ChevronUp,
  Lightbulb,
  PlusCircle,
  FileText,
  MessageSquare,
  Sparkles,
  Swords,
  Shield,
  HelpCircle,
  LayoutList,
  Layers
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useAccounts, DbAccount } from '@/hooks/useAccounts';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { differenceInDays, parseISO, format } from 'date-fns';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { DiscoveryQuestionsPanel, isWhitespaceNBA } from '@/components/DiscoveryQuestionsPanel';
import { useGroupedNBAs } from '@/hooks/useGroupedNBAs';
import { useTeamMembers } from '@/hooks/useTeamMembers';
import { GroupedNBACard } from '@/components/GroupedNBACard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useUpdateOpportunityNBAOwner } from '@/hooks/useOpportunityNBAs';
import { SEPulseSection } from '@/components/SEPulseSection';
import { AssignableUser } from '@/hooks/useAssignableOpportunityUsers';

interface NBADashboardProps {
  onSelectAccount: (accountId: string) => void;
}

// Unified NBA type for all sources
interface NextBestAction {
  id: string;
  accountId: string;
  accountName: string;
  action: string;
  type: 'discovery_nba' | 'whitespace' | 'opportunity' | 'followup' | 'discovery' | 'technical' | 'competitive_advantage' | 'coaching';
  priority: 'high' | 'medium' | 'low';
  dueDate?: string;
  value?: number;
  stage: string;
  closeDate?: string | null;
  priorityScore: number;
  isOwned: boolean;
  // New fields for reasoning
  notes?: string;
  source?: 'transcript' | 'whitespace' | 'stage' | 'competitive';
  functionalArea?: string;
  functionalAreaId?: string;
  businessOutcome?: string;
  useCaseTemplateId?: string;
  // Competitive context
  competitorName?: string;
  pendoScore?: number;
  competitorScore?: number;
  featureCategory?: string;
  // Priority reasoning breakdown
  priorityReasoning?: {
    factors: Array<{ label: string; contribution: number; description: string }>;
    useCasePriority?: 'high' | 'medium' | 'low';
    useCaseStatus?: string;
    linkedUseCaseId?: string;
    linkedUseCaseName?: string;
  };
}

const priorityColors: Record<string, string> = {
  high: 'bg-destructive/20 text-destructive border-destructive/30',
  medium: 'bg-layer-build-muted text-layer-build border-layer-build/30',
  low: 'bg-muted text-muted-foreground border-border',
};

const typeIcons: Record<string, typeof Target> = {
  discovery_nba: MessageSquare,
  whitespace: Sparkles,
  opportunity: TrendingUp,
  followup: Clock,
  discovery: Target,
  technical: Zap,
  competitive_advantage: Swords,
  coaching: Lightbulb,
};

const typeLabels: Record<string, string> = {
  discovery_nba: 'From Discovery',
  whitespace: 'Whitespace Opportunity',
  opportunity: 'Active Opportunity',
  followup: 'Follow Up',
  discovery: 'Discovery Action',
  technical: 'Technical Action',
  competitive_advantage: 'Competitive Advantage',
  coaching: 'AI Coaching',
};

// Stage weights (earlier = more urgent)
const stageWeights: Record<string, number> = {
  closing: 100,
  proposal: 75,
  evaluation: 50,
  discovery: 25,
  customer: 10,
};

interface PriorityCalculation {
  score: number;
  factors: Array<{ label: string; contribution: number; description: string }>;
}

function calculatePriorityScore(params: {
  closeDate: string | null;
  stage: string | null;
  value: number | null;
  basePriority: string | null;
}): PriorityCalculation {
  const { closeDate, stage, value, basePriority } = params;
  let score = 0;
  const factors: Array<{ label: string; contribution: number; description: string }> = [];

  if (closeDate) {
    const daysUntilClose = differenceInDays(parseISO(closeDate), new Date());
    let closeDateScore = 10;
    let description = 'Far out';
    
    if (daysUntilClose <= 7) { closeDateScore = 100; description = 'Closes within 1 week'; }
    else if (daysUntilClose <= 14) { closeDateScore = 80; description = 'Closes within 2 weeks'; }
    else if (daysUntilClose <= 30) { closeDateScore = 60; description = 'Closes within 1 month'; }
    else if (daysUntilClose <= 60) { closeDateScore = 40; description = 'Closes within 2 months'; }
    else if (daysUntilClose <= 90) { closeDateScore = 20; description = 'Closes within quarter'; }
    
    score += closeDateScore;
    factors.push({ label: 'Close Date', contribution: closeDateScore, description });
  }

  const stageScore = stageWeights[stage || 'discovery'] || 25;
  score += stageScore;
  factors.push({ 
    label: 'Stage', 
    contribution: stageScore, 
    description: `${(stage || 'discovery').charAt(0).toUpperCase() + (stage || 'discovery').slice(1)} stage` 
  });

  if (value && value > 0) {
    const valueScore = Math.min(100, Math.log10(value) * 20);
    score += valueScore;
    factors.push({ 
      label: 'Deal Value', 
      contribution: Math.round(valueScore), 
      description: `$${value.toLocaleString()} opportunity` 
    });
  }

  if (basePriority === 'high') {
    score += 50;
    factors.push({ label: 'Base Priority', contribution: 50, description: 'Marked as high priority' });
  } else if (basePriority === 'medium') {
    score += 25;
    factors.push({ label: 'Base Priority', contribution: 25, description: 'Marked as medium priority' });
  }

  return { score, factors };
}

function determinePriority(score: number): 'high' | 'medium' | 'low' {
  if (score >= 200) return 'high';
  if (score >= 100) return 'medium';
  return 'low';
}

export function NBADashboard({ onSelectAccount }: NBADashboardProps) {
  const { user, effectiveUserId, effectiveUserEmail } = useAuth();
  const { isManager, profile } = useUserRole();
  const queryClient = useQueryClient();
  const [viewScope, setViewScope] = useState<'mine' | 'team'>('mine');
  const [expandedNBA, setExpandedNBA] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grouped' | 'detailed'>('grouped');
  const { data: accounts, isLoading: accountsLoading } = useAccounts();
  
  // Derive showOnlyMine from viewScope - 'mine' shows only my NBAs, 'team' shows team NBAs
  const showOnlyMine = viewScope === 'mine';
  
  // Get team members for team filtering (uses effective user for impersonation)
  const { teamEmailsWithSelf } = useTeamMembers();
  
  // Grouped NBAs hook - pass team emails when in team view
  const { 
    groupedByPriority: groupedNBAsByPriority, 
    directlyAssignedByPriority,
    otherOnMyAccountsByPriority,
    directlyAssigned,
    otherOnMyAccounts,
    isLoading: groupedLoading,
    completeSubTask,
    completeGroup,
    updateDueDate
  } = useGroupedNBAs(showOnlyMine, showOnlyMine ? undefined : teamEmailsWithSelf);
  
  // Owner update mutation for reassigning NBAs
  const updateOwner = useUpdateOpportunityNBAOwner();
  
  // Fetch assignable users for all accounts (for reassignment dropdown)
  const { data: assignableUsersMap } = useQuery({
    queryKey: ['all-assignable-users'],
    queryFn: async () => {
      // Get unique account IDs from grouped NBAs
      const accountIds = new Set<string>();
      [...(directlyAssigned || []), ...(otherOnMyAccounts || [])].forEach(g => accountIds.add(g.accountId));
      Object.values(groupedNBAsByPriority || {}).flat().forEach((g: any) => accountIds.add(g.accountId));
      
      if (accountIds.size === 0) return new Map<string, AssignableUser[]>();
      
      const result = new Map<string, AssignableUser[]>();

      // Fetch profiles once for name lookups
      const profilesResponse = await gateway.from('profiles')
        .select('email, full_name')
        .execute();
      const profileNameByEmail = new Map(
        (profilesResponse.data || []).map((p: any) => [p.email?.toLowerCase(), p.full_name])
      );
      
      for (const accountId of accountIds) {
        // Fetch internal team members
        const accTeamResponse = await gateway.from('account_team_members')
          .select('team_member_email, role')
          .eq('account_id', accountId)
          .execute();
        
        const internalUsers: AssignableUser[] = (accTeamResponse.data || []).map((m: any) => ({
          email: m.team_member_email?.toLowerCase().trim() || '',
          full_name: profileNameByEmail.get(m.team_member_email?.toLowerCase()) || null,
          role: m.role || null,
          source: 'account_team_member' as const,
          isExternal: false,
        })).filter((u: AssignableUser) => u.email);

        // Fetch external contacts/stakeholders
        const contactsResponse = await gateway.from('account_contacts')
          .select('id, name, email, role, is_internal')
          .eq('account_id', accountId)
          .not('is_ignored', 'is', true)
          .execute();
        
        const contacts = contactsResponse.data || [];
        const internalEmails = new Set(internalUsers.map(u => u.email));
        
        const externalUsers: AssignableUser[] = contacts
          .filter((c: any) => !c.is_internal && c.email)
          .map((c: any) => ({
            email: (c.email || '').toLowerCase().trim(),
            full_name: c.name || null,
            role: c.role || null,
            source: 'stakeholder' as const,
            isExternal: true,
          }))
          .filter((u: AssignableUser) => u.email && !internalEmails.has(u.email));

        result.set(accountId, [...internalUsers, ...externalUsers]);
      }
      
      return result;
    },
    enabled: !groupedLoading,
  });
  
  // Handler for owner change
  const handleOwnerChange = (nbaId: string, accountId: string, opportunityId: string | null, newOwner: string | null) => {
    updateOwner.mutate({ 
      id: nbaId, 
      accountId, 
      opportunityId: opportunityId || '', 
      assignedTo: newOwner 
    });
  };
  
  // Get assignable users for a specific account
  const getAssignableUsers = (accountId: string): AssignableUser[] => {
    return assignableUsersMap?.get(accountId) || [];
  };
  
  // Fetch account NBAs (from transcript analysis)
  const { data: accountNbas } = useQuery({
    queryKey: ['all-account-nbas'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('account_nbas')
        .select('*, accounts(name, stage, owner_id, arr, primary_se_email)')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  // Get user email for ownership checks - use effective user for impersonation
  const userEmail = effectiveUserEmail;
  const userId = effectiveUserId;

  // Fetch use case templates
  const { data: useCaseTemplates } = useQuery({
    queryKey: ['use-case-templates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('use_case_templates')
        .select('*, functional_areas(name)')
        .eq('is_active', true);
      if (error) throw error;
      return data;
    },
  });

  // Fetch account use cases (what's already identified per account)
  const { data: accountUseCases } = useQuery({
    queryKey: ['all-account-use-cases'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('account_use_cases')
        .select('*');
      if (error) throw error;
      return data;
    },
  });

  // Fetch opportunities for context
  const { data: opportunities } = useQuery({
    queryKey: ['all-opportunities'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('opportunities')
        .select('*, accounts(name, stage, owner_id, primary_se_email)')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  // Fetch transcript insights to detect competitors per account
  const { data: transcriptsByAccount } = useQuery({
    queryKey: ['transcripts-by-account-competitors'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transcript_reviews')
        .select('final_account_id, extracted_insights')
        .eq('status', 'approved')
        .not('final_account_id', 'is', null);
      if (error) throw error;
      
      // Group by account and extract competitor mentions
      const accountCompetitors = new Map<string, Set<string>>();
      data.forEach((t: any) => {
        if (!t.final_account_id) return;
        const insights = t.extracted_insights || {};
        const competitors = insights.competitorMentions || [];
        const existing = accountCompetitors.get(t.final_account_id) || new Set<string>();
        competitors.forEach((c: string) => existing.add(c));
        accountCompetitors.set(t.final_account_id, existing);
      });
      
      return accountCompetitors;
    },
  });

  // Fetch Pendo's competitive advantages
  const { data: pendoAdvantages } = useQuery({
    queryKey: ['pendo-competitive-advantages'],
    queryFn: async () => {
      // Get Pendo's ID
      const { data: pendoData } = await supabase
        .from('competitors')
        .select('id')
        .eq('name', 'Pendo')
        .maybeSingle();
      if (!pendoData) return [];
      
      // Get Pendo scores with features
      const { data: pendoScores } = await supabase
        .from('competitor_scores')
        .select(`
          score,
          feature_id,
          competitive_features(
            name,
            competitive_categories(name)
          )
        `)
        .eq('competitor_id', pendoData.id);
      if (!pendoScores) return [];
      
      // Get all other competitor scores
      const { data: allCompScores } = await supabase
        .from('competitor_scores')
        .select(`
          score,
          feature_id,
          competitor_id,
          competitors(name, is_primary_competitor)
        `)
        .neq('competitor_id', pendoData.id);
      if (!allCompScores) return [];
      
      // Build advantage map: feature -> { competitorName, pendoScore, compScore, advantage }
      const advantages: Array<{
        featureName: string;
        categoryName: string;
        competitorName: string;
        pendoScore: number;
        competitorScore: number;
        advantage: number;
      }> = [];
      
      const pendoScoreMap = new Map(pendoScores.map((s: any) => [s.feature_id, {
        score: s.score,
        featureName: s.competitive_features?.name,
        categoryName: s.competitive_features?.competitive_categories?.name
      }]));
      
      allCompScores.forEach((cs: any) => {
        const pendoInfo = pendoScoreMap.get(cs.feature_id);
        if (!pendoInfo) return;
        const advantage = pendoInfo.score - cs.score;
        if (advantage >= 2) { // Only significant advantages
          advantages.push({
            featureName: pendoInfo.featureName,
            categoryName: pendoInfo.categoryName,
            competitorName: cs.competitors?.name,
            pendoScore: pendoInfo.score,
            competitorScore: cs.score,
            advantage,
          });
        }
      });
      
      return advantages;
    },
  });

  // Mutation to create opportunity from whitespace
  const createOpportunity = useMutation({
    mutationFn: async (params: { accountId: string; name: string; description: string }) => {
      const { data: inserted, error } = await gateway
        .from('opportunities')
        .insert({
          account_id: params.accountId,
          name: params.name,
          description: params.description,
          stage: 'identified',
          priority: 'medium',
          owner_id: user?.id,
        })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const data = Array.isArray(inserted) ? inserted[0] : inserted;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-opportunities'] });
      toast.success('Opportunity created successfully');
    },
    onError: (error) => {
      toast.error('Failed to create opportunity');
      console.error(error);
    },
  });

  // Mutation to add use case to account
  const addUseCase = useMutation({
    mutationFn: async (params: { accountId: string; useCase: string; functionalArea: string; description: string }) => {
      const { data: inserted, error } = await gateway
        .from('account_use_cases')
        .insert({
          account_id: params.accountId,
          use_case: params.useCase,
          functional_area: params.functionalArea,
          description: params.description,
          status: 'identified',
          priority: 'medium',
        })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const data = Array.isArray(inserted) ? inserted[0] : inserted;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-account-use-cases'] });
      toast.success('Use case added to account');
    },
    onError: (error) => {
      toast.error('Failed to add use case');
      console.error(error);
    },
  });

  // Mutation to mark NBA as complete
  const completeNBA = useMutation({
    mutationFn: async (nbaId: string) => {
      const { error } = await supabase
        .from('account_nbas')
        .update({ status: 'completed' })
        .eq('id', nbaId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-account-nbas'] });
      toast.success('Action marked as complete');
    },
  });

  // Generate NBAs from all sources
  const nbas = useMemo(() => {
    const actions: NextBestAction[] = [];
    
    // Helper to find linked use case for an NBA
    const findLinkedUseCase = (accountId: string, action: string, functionalArea?: string) => {
      if (!accountUseCases) return undefined;
      const accountUCs = accountUseCases.filter(uc => uc.account_id === accountId);
      
      // Try to match by functional area first
      if (functionalArea) {
        const byArea = accountUCs.find(uc => 
          uc.functional_area.toLowerCase() === functionalArea.toLowerCase()
        );
        if (byArea) return byArea;
      }
      
      // Try to match by action keywords
      const actionWords = action.toLowerCase().split(/\s+/);
      const byKeywords = accountUCs.find(uc => 
        actionWords.some(w => uc.use_case.toLowerCase().includes(w) || uc.functional_area.toLowerCase().includes(w))
      );
      return byKeywords;
    };
    
    // 1. Discovery NBAs from account_nbas table (highest priority - based on real insights)
    accountNbas?.forEach((nba: any) => {
      // Check ownership with opportunity-level precision
      const accountOwnerId = nba.accounts?.owner_id;
      const primarySeEmail = nba.accounts?.primary_se_email;
      const isAccountOwner = userId === accountOwnerId;
      const isPrimarySE = userEmail && primarySeEmail && userEmail.toLowerCase() === primarySeEmail.toLowerCase();
      const isAssigned = nba.assigned_to && userEmail && nba.assigned_to.toLowerCase() === userEmail.toLowerCase();
      // For opportunity-linked NBAs, account SE alone shouldn't grant visibility
      const hasOpportunity = !!nba.opportunity_id;
      const isOwned = hasOpportunity
        ? (isAccountOwner || isAssigned) // Opportunity-level: need direct involvement
        : (isAccountOwner || isPrimarySE || isAssigned);
      
      const priorityMap: Record<string, number> = { high: 75, medium: 50, low: 25 };
      const baseScore = priorityMap[nba.priority || 'medium'] || 50;
      const stageBoost = stageWeights[nba.accounts?.stage || 'discovery'] || 25;
      
      // Check for linked use case priority
      const linkedUseCase = findLinkedUseCase(nba.account_id, nba.action, nba.functional_area);
      const useCasePriorityBoost = linkedUseCase?.priority === 'high' ? 30 : linkedUseCase?.priority === 'medium' ? 15 : 0;
      
      const priorityScore = baseScore + stageBoost + 50 + useCasePriorityBoost; // Boost discovery NBAs

      const factors: Array<{ label: string; contribution: number; description: string }> = [
        { label: 'Discovery Source', contribution: 50, description: 'Extracted from real conversation' },
        { label: 'Base Priority', contribution: baseScore, description: `Marked as ${nba.priority || 'medium'} priority` },
        { label: 'Stage', contribution: stageBoost, description: `${(nba.accounts?.stage || 'discovery').charAt(0).toUpperCase() + (nba.accounts?.stage || 'discovery').slice(1)} stage` },
      ];
      
      if (useCasePriorityBoost > 0) {
        factors.push({ 
          label: 'Use Case Priority', 
          contribution: useCasePriorityBoost, 
          description: `Linked to ${linkedUseCase?.priority} priority use case` 
        });
      }

      actions.push({
        id: nba.id,
        accountId: nba.account_id,
        accountName: nba.accounts?.name || 'Unknown',
        action: nba.action,
        type: 'discovery_nba',
        priority: nba.priority || 'medium',
        dueDate: nba.due_date,
        stage: nba.accounts?.stage || 'discovery',
        priorityScore,
        isOwned,
        notes: nba.notes,
        source: 'transcript',
        functionalArea: linkedUseCase?.functional_area,
        priorityReasoning: {
          factors,
          useCasePriority: linkedUseCase?.priority as 'high' | 'medium' | 'low' | undefined,
          useCaseStatus: linkedUseCase?.status,
          linkedUseCaseId: linkedUseCase?.id,
          linkedUseCaseName: linkedUseCase?.use_case,
        },
      });
    });

    // 2. Whitespace opportunities - compare templates vs what account has
    if (useCaseTemplates && accounts) {
      accounts.forEach((account) => {
        // Check ownership: account owner or primary SE (use effective user for impersonation)
        const isAccountOwner = userId === account.owner_id;
        const isPrimarySE = userEmail && account.primary_se_email && userEmail.toLowerCase() === account.primary_se_email.toLowerCase();
        const isOwned = isAccountOwner || isPrimarySE;
        const accountUseCasesForAccount = accountUseCases?.filter(uc => uc.account_id === account.id) || [];
        const accountUseCaseNames = accountUseCasesForAccount.map(uc => uc.use_case.toLowerCase());

        // Find use case templates not yet linked to this account
        const whitespaceTemplates = useCaseTemplates.filter((template: any) => 
          !accountUseCaseNames.includes(template.name.toLowerCase())
        );

        // Only suggest top 2 whitespace per account to avoid overwhelming
        whitespaceTemplates.slice(0, 2).forEach((template: any) => {
          const arrScore = account.arr ? Math.log10(account.arr) * 10 : 0;
          const priorityScore = 100 + arrScore;
          
          const factors: Array<{ label: string; contribution: number; description: string }> = [
            { label: 'Whitespace Opportunity', contribution: 100, description: 'Unexplored use case for this account' },
          ];
          
          if (arrScore > 0) {
            factors.push({ 
              label: 'Account Value', 
              contribution: Math.round(arrScore), 
              description: `$${account.arr?.toLocaleString()} ARR account` 
            });
          }
          
          actions.push({
            id: `whitespace-${account.id}-${template.id}`,
            accountId: account.id,
            accountName: account.name,
            action: `Explore: ${template.name}`,
            type: 'whitespace',
            priority: 'medium',
            stage: account.stage || 'discovery',
            priorityScore,
            isOwned,
            notes: template.description,
            source: 'whitespace',
            functionalArea: (template.functional_areas as any)?.name || 'Unknown',
            functionalAreaId: template.functional_area_id,
            businessOutcome: template.example_outcomes,
            useCaseTemplateId: template.id,
            priorityReasoning: { factors },
          });
        });
      });
    }

    // 3. Active opportunities that need attention
    opportunities?.forEach((opp: any) => {
      // Check ownership: opportunity owner, account owner, or primary SE
      const accountOwnerId = opp.accounts?.owner_id;
      const oppOwnerId = opp.owner_id;
      const primarySeEmail = opp.accounts?.primary_se_email;
      const oppPrimarySeEmail = opp.primary_se_email;
      const isOppOwner = userId === oppOwnerId;
      const isAccountOwner = userId === accountOwnerId;
      const isPrimarySE = userEmail && (
        (primarySeEmail && userEmail.toLowerCase() === primarySeEmail.toLowerCase()) ||
        (oppPrimarySeEmail && userEmail.toLowerCase() === oppPrimarySeEmail.toLowerCase())
      );
      const isOwned = isOppOwner || isAccountOwner || isPrimarySE;

      const { score: priorityScore, factors } = calculatePriorityScore({
        closeDate: opp.close_date,
        stage: opp.accounts?.stage,
        value: opp.value,
        basePriority: opp.priority,
      });

      actions.push({
        id: opp.id,
        accountId: opp.account_id,
        accountName: opp.accounts?.name || 'Unknown',
        action: `Progress: ${opp.name}`,
        type: 'opportunity',
        priority: determinePriority(priorityScore),
        value: opp.value,
        stage: opp.accounts?.stage || 'discovery',
        closeDate: opp.close_date,
        priorityScore,
        isOwned,
        notes: opp.description,
        source: 'stage',
        priorityReasoning: { factors },
      });
    });

    // 4. Competitive Advantages - where Pendo beats mentioned competitors
    if (pendoAdvantages && transcriptsByAccount && accounts) {
      accounts.forEach((account) => {
        // Check ownership: account owner or primary SE (use effective user for impersonation)
        const isAccountOwner = userId === account.owner_id;
        const isPrimarySE = userEmail && account.primary_se_email && userEmail.toLowerCase() === account.primary_se_email.toLowerCase();
        const isOwned = isAccountOwner || isPrimarySE;
        const accountCompetitors = transcriptsByAccount.get(account.id);
        
        if (!accountCompetitors || accountCompetitors.size === 0) return;
        
        // Find advantages against mentioned competitors
        const relevantAdvantages = pendoAdvantages.filter(adv => 
          Array.from(accountCompetitors).some(comp => 
            adv.competitorName.toLowerCase().includes(comp.toLowerCase()) ||
            comp.toLowerCase().includes(adv.competitorName.toLowerCase())
          )
        );
        
        // Add top 2 advantages per account
        relevantAdvantages.slice(0, 2).forEach((adv) => {
          const advantageScore = adv.advantage * 20;
          const arrScore = account.arr ? Math.log10(account.arr) * 5 : 0;
          const priorityScore = 150 + advantageScore + arrScore;
          
          const factors: Array<{ label: string; contribution: number; description: string }> = [
            { label: 'Competitive Intel', contribution: 150, description: 'Based on competitive analysis data' },
            { label: 'Advantage Gap', contribution: advantageScore, description: `+${adv.advantage} point lead in ${adv.featureName}` },
          ];
          
          if (arrScore > 0) {
            factors.push({ 
              label: 'Account Value', 
              contribution: Math.round(arrScore), 
              description: `$${account.arr?.toLocaleString()} ARR` 
            });
          }
          
          actions.push({
            id: `competitive-${account.id}-${adv.featureName}-${adv.competitorName}`,
            accountId: account.id,
            accountName: account.name,
            action: `Highlight: ${adv.featureName} advantage`,
            type: 'competitive_advantage',
            priority: adv.advantage >= 3 ? 'high' : 'medium',
            stage: account.stage || 'discovery',
            priorityScore,
            isOwned,
            notes: `Pendo scores ${adv.pendoScore}/5 vs ${adv.competitorName}'s ${adv.competitorScore}/5 in ${adv.featureName}. Use this ${adv.categoryName} capability to differentiate.`,
            source: 'competitive',
            competitorName: adv.competitorName,
            pendoScore: adv.pendoScore,
            competitorScore: adv.competitorScore,
            featureCategory: adv.categoryName,
            priorityReasoning: { factors },
          });
        });
      });
    }

    // Sort by priority score (highest first)
    let result = actions.sort((a, b) => b.priorityScore - a.priorityScore);
    
    // Filter by ownership if toggle is on
    if (showOnlyMine) {
      result = result.filter(a => a.isOwned);
    }
    
    return result;
  }, [accounts, accountNbas, useCaseTemplates, accountUseCases, opportunities, transcriptsByAccount, pendoAdvantages, userId, userEmail, showOnlyMine]);

  // Group NBAs by priority
  const nbasByPriority = useMemo(() => {
    return {
      high: nbas.filter(n => n.priority === 'high'),
      medium: nbas.filter(n => n.priority === 'medium'),
      low: nbas.filter(n => n.priority === 'low'),
    };
  }, [nbas]);

  // Calculate pipeline value
  const pipelineValue = opportunities?.reduce((sum: number, o: any) => sum + (o.value || 0), 0) || 0;

  const handleCreateOpportunity = (nba: NextBestAction) => {
    createOpportunity.mutate({
      accountId: nba.accountId,
      name: nba.action.replace('Explore: ', ''),
      description: nba.notes || '',
    });
  };

  const handleAddUseCase = (nba: NextBestAction) => {
    if (nba.useCaseTemplateId) {
      addUseCase.mutate({
        accountId: nba.accountId,
        useCase: nba.action.replace('Explore: ', ''),
        functionalArea: nba.functionalArea || 'General',
        description: nba.notes || '',
      });
    }
  };

  if (accountsLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-12 w-64" />
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="page-heading">Next Best Actions</h1>
          <p className="text-muted-foreground mt-1">
            Insights from discovery, whitespace analysis, and active opportunities
          </p>
        </div>
        <div className="flex items-center gap-4 flex-wrap">
          {/* View Mode Toggle */}
          <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'grouped' | 'detailed')}>
            <TabsList className="h-9">
              <TabsTrigger value="grouped" className="gap-1.5 text-xs">
                <Layers className="w-3.5 h-3.5" />
                Grouped
              </TabsTrigger>
              <TabsTrigger value="detailed" className="gap-1.5 text-xs">
                <LayoutList className="w-3.5 h-3.5" />
                Detailed
              </TabsTrigger>
            </TabsList>
          </Tabs>
          
          {isManager ? (
            <div className="flex items-center gap-2 bg-card/50 rounded-lg px-3 py-1.5 border border-border">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <Tabs value={viewScope} onValueChange={(v) => setViewScope(v as 'mine' | 'team')}>
                <TabsList className="h-7">
                  <TabsTrigger value="mine" className="text-xs px-3 h-6">My NBAs</TabsTrigger>
                  <TabsTrigger value="team" className="text-xs px-3 h-6">Team NBAs</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          ) : (
            <div className="flex items-center gap-3 bg-card/50 rounded-lg px-4 py-2 border border-border">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <Label htmlFor="show-mine" className="text-sm text-muted-foreground cursor-pointer">
                My accounts only
              </Label>
              <Switch
                id="show-mine"
                checked={showOnlyMine}
                onCheckedChange={(checked) => setViewScope(checked ? 'mine' : 'team')}
              />
            </div>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-destructive" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{nbasByPriority.high.length}</p>
              <p className="text-xs text-muted-foreground">High Priority</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-layer-build-muted flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-layer-build" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {nbas.filter(n => n.type === 'discovery_nba').length}
              </p>
              <p className="text-xs text-muted-foreground">From Discovery</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {nbas.filter(n => n.type === 'whitespace').length}
              </p>
              <p className="text-xs text-muted-foreground">Whitespace</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
              <Swords className="w-5 h-5 text-orange-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {nbas.filter(n => n.type === 'competitive_advantage').length}
              </p>
              <p className="text-xs text-muted-foreground">Competitive</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-layer-growth-muted flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-layer-growth" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                ${(pipelineValue / 1000).toFixed(0)}k
              </p>
              <p className="text-xs text-muted-foreground">Pipeline Value</p>
            </div>
          </div>
        </div>
      </div>

      {/* SE Opportunity Pulse */}
      <SEPulseSection onSelectAccount={onSelectAccount} />

      {/* NBA List - Grouped View */}
      {viewMode === 'grouped' && (
        <div className="space-y-8">
          {/* When in "My NBAs" view, show directly assigned first, then other on my accounts */}
          {showOnlyMine ? (
            <>
              {/* Directly Assigned to Me Section */}
              {directlyAssigned.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 pb-2 border-b border-border">
                    <Target className="w-5 h-5 text-primary" />
                    <h2 className="text-lg font-semibold">Assigned to Me ({directlyAssigned.length})</h2>
                  </div>
                  
                  {directlyAssignedByPriority.high.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="text-sm font-medium text-destructive flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" />
                        High Priority ({directlyAssignedByPriority.high.length})
                      </h3>
                      <div className="grid gap-3">
                        {directlyAssignedByPriority.high.map((group) => (
                          <GroupedNBACard
                            key={group.id}
                            group={group}
                            onCompleteSubTask={(id) => completeSubTask.mutate(id)}
                            onCompleteAll={(ids) => completeGroup.mutate(ids)}
                            onViewAccount={onSelectAccount}
                            onDueDateChange={(nbaId, newDate, prevDate) => updateDueDate.mutate({ nbaId, newDueDate: newDate, previousDueDate: prevDate })}
                            onOwnerChange={handleOwnerChange}
                            assignableUsers={getAssignableUsers(group.accountId)}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {directlyAssignedByPriority.medium.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="text-sm font-medium text-layer-build flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        Medium Priority ({directlyAssignedByPriority.medium.length})
                      </h3>
                      <div className="grid gap-3">
                        {directlyAssignedByPriority.medium.map((group) => (
                          <GroupedNBACard
                            key={group.id}
                            group={group}
                            onCompleteSubTask={(id) => completeSubTask.mutate(id)}
                            onCompleteAll={(ids) => completeGroup.mutate(ids)}
                            onViewAccount={onSelectAccount}
                            onDueDateChange={(nbaId, newDate, prevDate) => updateDueDate.mutate({ nbaId, newDueDate: newDate, previousDueDate: prevDate })}
                            onOwnerChange={handleOwnerChange}
                            assignableUsers={getAssignableUsers(group.accountId)}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {directlyAssignedByPriority.low.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        Low Priority ({directlyAssignedByPriority.low.length})
                      </h3>
                      <div className="grid gap-3">
                        {directlyAssignedByPriority.low.map((group) => (
                          <GroupedNBACard
                            key={group.id}
                            group={group}
                            onCompleteSubTask={(id) => completeSubTask.mutate(id)}
                            onCompleteAll={(ids) => completeGroup.mutate(ids)}
                            onViewAccount={onSelectAccount}
                            onDueDateChange={(nbaId, newDate, prevDate) => updateDueDate.mutate({ nbaId, newDueDate: newDate, previousDueDate: prevDate })}
                            onOwnerChange={handleOwnerChange}
                            assignableUsers={getAssignableUsers(group.accountId)}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Other Actions on My Accounts Section */}
              {otherOnMyAccounts.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 pb-2 border-b border-border">
                    <Building2 className="w-5 h-5 text-muted-foreground" />
                    <h2 className="text-lg font-semibold text-muted-foreground">Other Actions on My Accounts ({otherOnMyAccounts.length})</h2>
                  </div>
                  
                  {otherOnMyAccountsByPriority.high.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="text-sm font-medium text-destructive flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" />
                        High Priority ({otherOnMyAccountsByPriority.high.length})
                      </h3>
                      <div className="grid gap-3">
                        {otherOnMyAccountsByPriority.high.map((group) => (
                          <GroupedNBACard
                            key={group.id}
                            group={group}
                            onCompleteSubTask={(id) => completeSubTask.mutate(id)}
                            onCompleteAll={(ids) => completeGroup.mutate(ids)}
                            onViewAccount={onSelectAccount}
                            onDueDateChange={(nbaId, newDate, prevDate) => updateDueDate.mutate({ nbaId, newDueDate: newDate, previousDueDate: prevDate })}
                            onOwnerChange={handleOwnerChange}
                            assignableUsers={getAssignableUsers(group.accountId)}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {otherOnMyAccountsByPriority.medium.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="text-sm font-medium text-layer-build flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        Medium Priority ({otherOnMyAccountsByPriority.medium.length})
                      </h3>
                      <div className="grid gap-3">
                        {otherOnMyAccountsByPriority.medium.map((group) => (
                          <GroupedNBACard
                            key={group.id}
                            group={group}
                            onCompleteSubTask={(id) => completeSubTask.mutate(id)}
                            onCompleteAll={(ids) => completeGroup.mutate(ids)}
                            onViewAccount={onSelectAccount}
                            onDueDateChange={(nbaId, newDate, prevDate) => updateDueDate.mutate({ nbaId, newDueDate: newDate, previousDueDate: prevDate })}
                            onOwnerChange={handleOwnerChange}
                            assignableUsers={getAssignableUsers(group.accountId)}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {otherOnMyAccountsByPriority.low.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        Low Priority ({otherOnMyAccountsByPriority.low.length})
                      </h3>
                      <div className="grid gap-3">
                        {otherOnMyAccountsByPriority.low.map((group) => (
                          <GroupedNBACard
                            key={group.id}
                            group={group}
                            onCompleteSubTask={(id) => completeSubTask.mutate(id)}
                            onCompleteAll={(ids) => completeGroup.mutate(ids)}
                            onViewAccount={onSelectAccount}
                            onDueDateChange={(nbaId, newDate, prevDate) => updateDueDate.mutate({ nbaId, newDueDate: newDate, previousDueDate: prevDate })}
                            onOwnerChange={handleOwnerChange}
                            assignableUsers={getAssignableUsers(group.accountId)}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Empty state for My NBAs view */}
              {directlyAssigned.length === 0 && otherOnMyAccounts.length === 0 && (
                <div className="glass rounded-xl p-8 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-8 h-8 text-primary" />
                  </div>
                  <div>
                    <p className="text-lg font-medium text-foreground">You're all caught up!</p>
                    <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
                      No pending actions on your accounts. New actions will appear here when transcripts are analyzed or opportunities are updated.
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2 justify-center pt-2">
                    <Badge variant="outline" className="text-xs">
                      <MessageSquare className="w-3 h-3 mr-1" />
                      Import transcripts to discover NBAs
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      <Target className="w-3 h-3 mr-1" />
                      Check Team view for other actions
                    </Badge>
                  </div>
                </div>
              )}
            </>
          ) : (
            /* Team NBAs view - show all grouped by priority */
            <>
              {groupedNBAsByPriority.high.length > 0 && (
                <div className="space-y-3">
                  <h2 className="text-lg font-semibold text-destructive flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5" />
                    High Priority ({groupedNBAsByPriority.high.length})
                  </h2>
                  <div className="grid gap-3">
                    {groupedNBAsByPriority.high.map((group) => (
                      <GroupedNBACard
                        key={group.id}
                        group={group}
                        onCompleteSubTask={(id) => completeSubTask.mutate(id)}
                        onCompleteAll={(ids) => completeGroup.mutate(ids)}
                        onViewAccount={onSelectAccount}
                        onDueDateChange={(nbaId, newDate, prevDate) => updateDueDate.mutate({ nbaId, newDueDate: newDate, previousDueDate: prevDate })}
                        onOwnerChange={handleOwnerChange}
                        assignableUsers={getAssignableUsers(group.accountId)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {groupedNBAsByPriority.medium.length > 0 && (
                <div className="space-y-3">
                  <h2 className="text-lg font-semibold text-layer-build flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Medium Priority ({groupedNBAsByPriority.medium.length})
                  </h2>
                  <div className="grid gap-3">
                    {groupedNBAsByPriority.medium.map((group) => (
                      <GroupedNBACard
                        key={group.id}
                        group={group}
                        onCompleteSubTask={(id) => completeSubTask.mutate(id)}
                        onCompleteAll={(ids) => completeGroup.mutate(ids)}
                        onViewAccount={onSelectAccount}
                        onDueDateChange={(nbaId, newDate, prevDate) => updateDueDate.mutate({ nbaId, newDueDate: newDate, previousDueDate: prevDate })}
                        onOwnerChange={handleOwnerChange}
                        assignableUsers={getAssignableUsers(group.accountId)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {groupedNBAsByPriority.low.length > 0 && (
                <div className="space-y-3">
                  <h2 className="text-lg font-semibold text-muted-foreground flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5" />
                    Low Priority ({groupedNBAsByPriority.low.length})
                  </h2>
                  <div className="grid gap-3">
                    {groupedNBAsByPriority.low.map((group) => (
                      <GroupedNBACard
                        key={group.id}
                        group={group}
                        onCompleteSubTask={(id) => completeSubTask.mutate(id)}
                        onCompleteAll={(ids) => completeGroup.mutate(ids)}
                        onViewAccount={onSelectAccount}
                        onDueDateChange={(nbaId, newDate, prevDate) => updateDueDate.mutate({ nbaId, newDueDate: newDate, previousDueDate: prevDate })}
                        onOwnerChange={handleOwnerChange}
                        assignableUsers={getAssignableUsers(group.accountId)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {groupedNBAsByPriority.high.length === 0 && 
               groupedNBAsByPriority.medium.length === 0 && 
               groupedNBAsByPriority.low.length === 0 && (
                <div className="glass rounded-xl p-8 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto">
                    <Layers className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-lg font-medium text-foreground">No team actions yet</p>
                    <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
                      Actions will be generated automatically when transcripts are analyzed. You can also manually create actions from opportunity views.
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2 justify-center pt-2">
                    <Badge variant="outline" className="text-xs">
                      <Sparkles className="w-3 h-3 mr-1" />
                      AI-generated from conversations
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      <PlusCircle className="w-3 h-3 mr-1" />
                      Manual creation supported
                    </Badge>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* NBA List - Detailed View (Original) */}
      {viewMode === 'detailed' && (
        <div className="space-y-6">
        {/* High Priority */}
        {nbasByPriority.high.length > 0 && (
          <div className="space-y-3">
            <h2 className="text-lg font-semibold text-destructive flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              High Priority Actions
            </h2>
            <div className="grid gap-3">
              {nbasByPriority.high.map((nba) => (
                <NBACard 
                  key={nba.id} 
                  nba={nba} 
                  isExpanded={expandedNBA === nba.id}
                  onToggleExpand={() => setExpandedNBA(expandedNBA === nba.id ? null : nba.id)}
                  onViewAccount={() => onSelectAccount(nba.accountId)}
                  onCreateOpportunity={() => handleCreateOpportunity(nba)}
                  onAddUseCase={() => handleAddUseCase(nba)}
                  onComplete={() => completeNBA.mutate(nba.id)}
                />
              ))}
            </div>
          </div>
        )}

        {/* Medium Priority */}
        {nbasByPriority.medium.length > 0 && (
          <div className="space-y-3">
            <h2 className="text-lg font-semibold text-layer-build flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Medium Priority Actions
            </h2>
            <div className="grid gap-3">
              {nbasByPriority.medium.map((nba) => (
                <NBACard 
                  key={nba.id} 
                  nba={nba} 
                  isExpanded={expandedNBA === nba.id}
                  onToggleExpand={() => setExpandedNBA(expandedNBA === nba.id ? null : nba.id)}
                  onViewAccount={() => onSelectAccount(nba.accountId)}
                  onCreateOpportunity={() => handleCreateOpportunity(nba)}
                  onAddUseCase={() => handleAddUseCase(nba)}
                  onComplete={() => completeNBA.mutate(nba.id)}
                />
              ))}
            </div>
          </div>
        )}

        {/* Low Priority */}
        {nbasByPriority.low.length > 0 && (
          <div className="space-y-3">
            <h2 className="text-lg font-semibold text-muted-foreground flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5" />
              Low Priority Actions
            </h2>
            <div className="grid gap-3">
              {nbasByPriority.low.map((nba) => (
                <NBACard 
                  key={nba.id} 
                  nba={nba} 
                  isExpanded={expandedNBA === nba.id}
                  onToggleExpand={() => setExpandedNBA(expandedNBA === nba.id ? null : nba.id)}
                  onViewAccount={() => onSelectAccount(nba.accountId)}
                  onCreateOpportunity={() => handleCreateOpportunity(nba)}
                  onAddUseCase={() => handleAddUseCase(nba)}
                  onComplete={() => completeNBA.mutate(nba.id)}
                />
              ))}
            </div>
          </div>
        )}

        {nbas.length === 0 && (
          <div className="glass rounded-xl p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
              <Target className="w-8 h-8 text-primary" />
            </div>
            <div>
              <p className="text-lg font-medium text-foreground">No actions available</p>
              <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
                Upload transcripts to get discovery-based insights, or add accounts to see whitespace opportunities.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 justify-center pt-2">
              <Badge variant="outline" className="text-xs">
                <MessageSquare className="w-3 h-3 mr-1" />
                From Transcripts
              </Badge>
              <Badge variant="outline" className="text-xs">
                <Sparkles className="w-3 h-3 mr-1" />
                Whitespace Analysis
              </Badge>
              <Badge variant="outline" className="text-xs">
                <Swords className="w-3 h-3 mr-1" />
                Competitive Insights
              </Badge>
            </div>
          </div>
        )}
        </div>
      )}
    </div>
  );
}

interface NBACardProps {
  nba: NextBestAction;
  isExpanded: boolean;
  onToggleExpand: () => void;
  onViewAccount: () => void;
  onCreateOpportunity: () => void;
  onAddUseCase: () => void;
  onComplete: () => void;
}

function NBACard({ nba, isExpanded, onToggleExpand, onViewAccount, onCreateOpportunity, onAddUseCase, onComplete }: NBACardProps) {
  const Icon = typeIcons[nba.type];
  
  return (
    <Collapsible open={isExpanded} onOpenChange={onToggleExpand}>
      <div
        className={cn(
          "glass rounded-xl border transition-all",
          priorityColors[nba.priority],
          isExpanded && "ring-2 ring-primary/20"
        )}
      >
        <CollapsibleTrigger className="w-full p-4 cursor-pointer">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-background/50 flex items-center justify-center shrink-0">
                <Icon className="w-5 h-5" />
              </div>
              <div className="text-left">
                <p className="font-medium text-foreground">
                  {nba.action}
                </p>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <Building2 className="w-3 h-3 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">{nba.accountName}</span>
                  <Badge variant="outline" className="text-xs">
                    {typeLabels[nba.type]}
                  </Badge>
                  <Badge variant="outline" className="text-xs capitalize">
                    {nba.stage}
                  </Badge>
                  {nba.closeDate && (
                    <Badge variant="outline" className="text-xs flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {format(parseISO(nba.closeDate), 'MMM d')}
                    </Badge>
                  )}
                  {nba.businessOutcome && (
                    <Badge 
                      variant="secondary" 
                      className={cn(
                        "text-xs",
                        nba.businessOutcome === 'Increase Revenue' && "bg-layer-growth-muted text-layer-growth",
                        nba.businessOutcome === 'Cut Costs' && "bg-layer-build-muted text-layer-build",
                        nba.businessOutcome === 'Reduce Risk' && "bg-destructive/10 text-destructive"
                      )}
                    >
                      {nba.businessOutcome}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {nba.value && (
                <span className="text-sm font-medium text-foreground">
                  ${nba.value.toLocaleString()}
                </span>
              )}
              {isExpanded ? (
                <ChevronUp className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              )}
            </div>
          </div>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <div className="px-4 pb-4 pt-2 border-t border-border/50 space-y-4">
            {/* Priority Reasoning Breakdown */}
            {nba.priorityReasoning && nba.priorityReasoning.factors.length > 0 && (
              <div className="bg-gradient-to-r from-primary/5 to-transparent rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <HelpCircle className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium text-foreground">
                    Why {nba.priority} priority?
                  </span>
                  <Badge variant="outline" className="text-xs ml-auto">
                    Score: {nba.priorityScore}
                  </Badge>
                </div>
                <div className="space-y-2">
                  {nba.priorityReasoning.factors.map((factor, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <div className="flex-1">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-muted-foreground">{factor.label}</span>
                          <span className="font-medium text-foreground">+{factor.contribution}</span>
                        </div>
                        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-primary/60 rounded-full transition-all"
                            style={{ width: `${Math.min(100, (factor.contribution / 100) * 100)}%` }}
                          />
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">{factor.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-2 border-t border-border/30 text-xs text-muted-foreground">
                  {nba.priority === 'high' && 'Score ≥200 → High priority'}
                  {nba.priority === 'medium' && 'Score 100-199 → Medium priority'}
                  {nba.priority === 'low' && 'Score <100 → Low priority'}
                </div>
              </div>
            )}

            {/* Linked Use Case */}
            {nba.priorityReasoning?.linkedUseCaseName && (
              <div className="bg-layer-build-muted/30 rounded-lg p-3">
                <div className="flex items-start gap-2">
                  <Target className="w-4 h-4 text-layer-build mt-0.5 shrink-0" />
                  <div className="flex-1">
                    <p className="text-xs font-medium text-muted-foreground mb-1">Linked Use Case</p>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium text-foreground">
                        {nba.priorityReasoning.linkedUseCaseName}
                      </span>
                      {nba.priorityReasoning.useCasePriority && (
                        <Badge 
                          variant="outline" 
                          className={cn(
                            "text-xs",
                            nba.priorityReasoning.useCasePriority === 'high' && 'border-destructive text-destructive',
                            nba.priorityReasoning.useCasePriority === 'medium' && 'border-layer-build text-layer-build',
                            nba.priorityReasoning.useCasePriority === 'low' && 'border-muted-foreground text-muted-foreground'
                          )}
                        >
                          {nba.priorityReasoning.useCasePriority} priority
                        </Badge>
                      )}
                      {nba.priorityReasoning.useCaseStatus && (
                        <Badge variant="secondary" className="text-xs capitalize">
                          {nba.priorityReasoning.useCaseStatus}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Competitive Advantage Visualization */}
            {nba.type === 'competitive_advantage' && nba.pendoScore !== undefined && nba.competitorScore !== undefined && (
              <div className="bg-gradient-to-r from-orange-500/10 to-transparent rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Swords className="w-4 h-4 text-orange-500" />
                  <span className="text-sm font-medium text-foreground">
                    Competitive Advantage vs {nba.competitorName}
                  </span>
                  {nba.featureCategory && (
                    <Badge variant="outline" className="text-xs ml-auto">
                      {nba.featureCategory}
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-4">
                  <TooltipProvider>
                    <div className="flex-1">
                      <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                        <span>Pendo</span>
                        <span className="font-medium text-foreground">{nba.pendoScore}/5</span>
                      </div>
                      <div className="h-3 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary rounded-full transition-all"
                          style={{ width: `${(nba.pendoScore / 5) * 100}%` }}
                        />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                        <span>{nba.competitorName}</span>
                        <span className="font-medium text-foreground">{nba.competitorScore}/5</span>
                      </div>
                      <div className="h-3 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-orange-500/60 rounded-full transition-all"
                          style={{ width: `${(nba.competitorScore / 5) * 100}%` }}
                        />
                      </div>
                    </div>
                  </TooltipProvider>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  +{nba.pendoScore - nba.competitorScore} point advantage in this capability
                </p>
              </div>
            )}

            {/* Reasoning / Notes */}
            {nba.notes && (
              <div className="bg-background/30 rounded-lg p-3">
                <div className="flex items-start gap-2">
                  <Lightbulb className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-1">
                      {nba.type === 'discovery_nba' ? 'Why this matters' : 
                       nba.type === 'competitive_advantage' ? 'How to leverage' : 'Business Value'}
                    </p>
                    <p className="text-sm text-foreground">{nba.notes}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Functional Area for whitespace */}
            {nba.functionalArea && (
              <div className="flex items-center gap-2 text-sm">
                <FileText className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">Functional Area:</span>
                <span className="font-medium text-foreground">{nba.functionalArea}</span>
              </div>
            )}

            {/* Discovery Questions for whitespace NBAs */}
            {(nba.type === 'whitespace' || isWhitespaceNBA(nba.action, nba.type)) && nba.functionalArea && (
              <DiscoveryQuestionsPanel 
                functionalArea={nba.functionalArea}
                nbaAction={nba.action}
                compact
              />
            )}

            {/* Action buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              <Button size="sm" variant="default" onClick={onViewAccount}>
                <Building2 className="w-4 h-4 mr-1" />
                View Account
              </Button>
              
              {nba.type === 'whitespace' && (
                <>
                  <Button size="sm" variant="outline" onClick={onCreateOpportunity}>
                    <PlusCircle className="w-4 h-4 mr-1" />
                    Create Opportunity
                  </Button>
                  <Button size="sm" variant="outline" onClick={onAddUseCase}>
                    <Target className="w-4 h-4 mr-1" />
                    Add Use Case
                  </Button>
                </>
              )}

              {nba.type === 'competitive_advantage' && (
                <Button size="sm" variant="outline" onClick={onCreateOpportunity}>
                  <Shield className="w-4 h-4 mr-1" />
                  Create Competitive Opportunity
                </Button>
              )}
              
              {nba.type === 'discovery_nba' && (
                <Button size="sm" variant="outline" onClick={onComplete}>
                  <CheckCircle2 className="w-4 h-4 mr-1" />
                  Mark Complete
                </Button>
              )}
            </div>
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}

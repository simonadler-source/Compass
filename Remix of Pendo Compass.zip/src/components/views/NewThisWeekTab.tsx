import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { NewSignal, DynamicSignalType } from '@/hooks/useActivitySignals';
import { useTeamLeaders, useTeamMemberEmails } from '@/hooks/useTeamFilterEmails';
import { useAllActiveUsers } from '@/hooks/useAllActiveUsers';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { SalesforceIcon } from '@/components/icons/SalesforceIcon';
import {
  Sparkles,
  Calendar,
  Building2,
  User,
  Users,
  Target,
  Layers,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const SALESFORCE_BASE_URL = 'https://pendo.lightning.force.com/lightning/r/Opportunity';

type GroupBy = 'signal' | 'ae' | 'se';

function SpeakerBadge({ type, name }: { type: 'internal' | 'external' | 'unknown' | null; name?: string | null }) {
  if (!type || type === 'unknown') {
    return (
      <Badge variant="outline" className="text-xs text-muted-foreground">
        <User className="h-3 w-3 mr-1" />
        Unknown
      </Badge>
    );
  }
  if (type === 'internal') {
    return (
      <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-600 border-blue-500/20">
        <Users className="h-3 w-3 mr-1" />
        {name || 'Pendo Team'}
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="text-xs bg-green-500/10 text-green-600 border-green-500/20">
      <User className="h-3 w-3 mr-1" />
      {name || 'Customer'}
    </Badge>
  );
}

function SalesforceLink({ salesforceId }: { salesforceId: string | null }) {
  if (!salesforceId) return null;
  const url = `${SALESFORCE_BASE_URL}/${salesforceId}/view`;
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center p-1 rounded hover:bg-muted transition-colors shrink-0"
            onClick={(e) => e.stopPropagation()}
          >
            <SalesforceIcon className="h-4 w-4" />
          </a>
        </TooltipTrigger>
        <TooltipContent><p>Open in Salesforce</p></TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function SignalCard({ signal, signalTypes }: { signal: NewSignal; signalTypes: DynamicSignalType[] }) {
  const getSignalColor = (ruleKey: string) => {
    const type = signalTypes.find(t => t.key === ruleKey);
    return type?.color || '#6B7280';
  };
  const color = getSignalColor(signal.rule_key);

  return (
    <div className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors">
      <div className="p-2 rounded-full" style={{ backgroundColor: `${color}20` }}>
        <Target className="h-4 w-4" style={{ color }} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <Link
            to={`/accounts/${signal.account_id}?tab=opportunities&opp=${signal.opportunity_id}`}
            className="font-medium truncate text-primary hover:underline"
          >
            {signal.opportunity_name}
          </Link>
          <SalesforceLink salesforceId={signal.salesforce_opportunity_id} />
          <Badge
            variant="secondary"
            className="text-xs shrink-0"
            style={{ borderColor: color, color, backgroundColor: `${color}15` }}
          >
            {signal.rule_name.replace(' Signals', '')}
          </Badge>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
          <Link
            to={`/accounts/${signal.account_id}`}
            className="flex items-center gap-1 hover:underline"
          >
            <Building2 className="h-3 w-3" />
            <span className="truncate">{signal.account_name}</span>
          </Link>
        </div>
        <div className="flex items-center gap-3 mt-2">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Calendar className="h-3 w-3" />
            <span>{formatDistanceToNow(new Date(signal.first_detected_at), { addSuffix: true })}</span>
          </div>
          <SpeakerBadge type={signal.speaker_type} name={signal.speaker_name} />
        </div>
        {signal.matched_phrases.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {signal.matched_phrases.slice(0, 3).map((phrase, i) => (
              <Badge key={i} variant="outline" className="text-xs">
                "{phrase}"
              </Badge>
            ))}
            {signal.matched_phrases.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{signal.matched_phrases.length - 3} more
              </Badge>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export function NewThisWeekTab({
  signals,
  signalTypes,
}: {
  signals: NewSignal[];
  signalTypes: DynamicSignalType[];
}) {
  const [groupBy, setGroupBy] = useState<GroupBy>('signal');
  const [managerId, setManagerId] = useState<string>('all');

  const { data: teamLeaders, isLoading: leadersLoading } = useTeamLeaders();
  const { data: teamEmails } = useTeamMemberEmails(managerId !== 'all' ? managerId : undefined);
  const { users: allUsers } = useAllActiveUsers();

  // Build email→name lookup
  const emailToName = useMemo(() => {
    const map = new Map<string, string>();
    allUsers.forEach(u => {
      if (u.email) map.set(u.email.toLowerCase(), u.full_name || u.email);
    });
    return map;
  }, [allUsers]);

  // Filter by manager hierarchy
  const filteredSignals = useMemo(() => {
    if (managerId === 'all' || !teamEmails || teamEmails.length === 0) return signals;
    return signals.filter(s => {
      const oe = s.owner_email?.toLowerCase();
      const se = s.primary_se_email?.toLowerCase();
      return teamEmails.some(e => e === oe || e === se);
    });
  }, [signals, managerId, teamEmails]);

  // Group signals
  const groups = useMemo(() => {
    const map = new Map<string, { label: string; color?: string; signals: NewSignal[] }>();

    filteredSignals.forEach(s => {
      let key: string;
      let label: string;
      let color: string | undefined;

      switch (groupBy) {
        case 'signal': {
          key = s.rule_key;
          const st = signalTypes.find(t => t.key === s.rule_key);
          label = st?.name || s.rule_name.replace(' Signals', '');
          color = st?.color;
          break;
        }
        case 'ae': {
          const email = s.owner_email?.toLowerCase() || 'unassigned';
          key = email;
          label = email === 'unassigned' ? 'Unassigned AE' : (emailToName.get(email) || email);
          break;
        }
        case 'se': {
          const email = s.primary_se_email?.toLowerCase() || 'unassigned';
          key = email;
          label = email === 'unassigned' ? 'Unassigned SE' : (emailToName.get(email) || email);
          break;
        }
      }

      if (!map.has(key)) {
        map.set(key, { label, color, signals: [] });
      }
      map.get(key)!.signals.push(s);
    });

    // Sort groups by signal count descending
    return Array.from(map.entries())
      .sort((a, b) => b[1].signals.length - a[1].signals.length);
  }, [filteredSignals, groupBy, signalTypes, emailToName]);

  if (signals.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center py-8 text-muted-foreground">
            <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No new signals detected this week</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <Layers className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium text-muted-foreground">Group by</span>
          <Select value={groupBy} onValueChange={(v) => setGroupBy(v as GroupBy)}>
            <SelectTrigger className="w-[180px] h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="signal">Signal Type</SelectItem>
              <SelectItem value="ae">Account Executive</SelectItem>
              <SelectItem value="se">Sales Engineer</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium text-muted-foreground">Manager</span>
          <Select value={managerId} onValueChange={setManagerId}>
            <SelectTrigger className="w-[200px] h-9">
              <SelectValue placeholder="All teams" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Teams</SelectItem>
              {(teamLeaders || []).map(leader => (
                <SelectItem key={leader.id} value={leader.id}>
                  {leader.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Badge variant="secondary" className="ml-auto">
          {filteredSignals.length} signal{filteredSignals.length !== 1 ? 's' : ''}
        </Badge>
      </div>

      {/* Grouped signals */}
      <ScrollArea className="h-[600px]">
        <div className="space-y-6">
          {groups.map(([key, group]) => (
            <Card key={key}>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  {group.color && (
                    <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: group.color }} />
                  )}
                  {group.label}
                  <Badge variant="outline" className="ml-2 font-normal">
                    {group.signals.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  {group.signals.map(signal => (
                    <SignalCard key={signal.id} signal={signal} signalTypes={signalTypes} />
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}

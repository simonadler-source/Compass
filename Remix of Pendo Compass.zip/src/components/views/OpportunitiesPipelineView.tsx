import { useState, useMemo, useCallback } from 'react';
import {
  Search, Briefcase, Building2, ArrowRight, X, Filter, ChevronDown, ChevronRight,
  TrendingUp, TrendingDown, Minus, Zap, Shield, Activity, Gauge, Clock,
  ThermometerSun, Target, Users, BarChart3, AlertTriangle, User,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAllActiveUsers } from '@/hooks/useAllActiveUsers';
import { useTeamMembers } from '@/hooks/useTeamMembers';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Tooltip, TooltipContent, TooltipTrigger, TooltipProvider,
} from '@/components/ui/tooltip';
import {
  Collapsible, CollapsibleContent, CollapsibleTrigger,
} from '@/components/ui/collapsible';

/* ────────── constants ────────── */

const SALES_STAGES_ORDER = [
  'stage_0', 'stage_1', 'stage_2', 'stage_3', 'stage_4', 'stage_5',
];

const SALES_STAGE_LABELS: Record<string, string> = {
  stage_0: 'Stage 0 – Lead',
  stage_1: 'Stage 1 – Qualify',
  stage_2: 'Stage 2 – Develop',
  stage_3: 'Stage 3 – Prove',
  stage_4: 'Stage 4 – Negotiate',
  stage_5: 'Stage 5 – Close',
  stage_6: 'Stage 6 – Won',
  Disqualified: 'Disqualified',
};

const SALES_STAGE_COLORS: Record<string, string> = {
  stage_0: 'bg-sky-500',
  stage_1: 'bg-blue-500',
  stage_2: 'bg-indigo-500',
  stage_3: 'bg-violet-500',
  stage_4: 'bg-purple-500',
  stage_5: 'bg-fuchsia-500',
  stage_6: 'bg-green-500',
  Disqualified: 'bg-muted-foreground',
};

const PRE_SALES_STAGES = [
  'Not Started', 'Discovery', 'Demo', 'Proof - Scoping', 'Proof',
  'Technical Win', 'Technical Loss', 'Stale / Not Active', 'Unqualified',
];

const PRE_SALES_STAGE_COLORS: Record<string, string> = {
  'Not Started': 'bg-muted text-muted-foreground',
  'Discovery': 'bg-blue-500/20 text-blue-500',
  'Demo': 'bg-purple-500/20 text-purple-500',
  'Proof - Scoping': 'bg-amber-500/20 text-amber-500',
  'Proof': 'bg-orange-500/20 text-orange-500',
  'Technical Win': 'bg-green-500/20 text-green-600',
  'Technical Loss': 'bg-destructive/20 text-destructive',
  'Stale / Not Active': 'bg-muted text-muted-foreground',
  'Unqualified': 'bg-muted text-muted-foreground',
};

type GroupBy = 'none' | 'sales_stage' | 'pre_sales_stage' | 'account' | 'owner' | 'se' | 'ae_manager';

interface EnrichedOpportunity {
  id: string;
  name: string;
  account_id: string;
  sales_stage: string | null;
  pre_sales_stage: string | null;
  value: number | null;
  close_date: string | null;
  updated_at: string;
  is_archived: boolean | null;
  engagement_score: number | null;
  momentum_score: number | null;
  readiness_score: number | null;
  competitive_threat_level: string | null;
  competitive_threat_score: number | null;
  stage_changed_at: string | null;
  last_meeting_at: string | null;
  owner_id: string | null;
  primary_se_email: string | null;
  owner_email: string | null;
  account_name: string;
  account_owner_id: string | null;
  account_se_email: string | null;
}

interface Props {
  onSelectAccount: (accountId: string) => void;
  onSelectOpportunity: (accountId: string, opportunityId: string) => void;
}

const isValidEmail = (s: string | null | undefined): boolean =>
  !!s && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);

function formatCompactCurrency(amount: number): string {
  if (amount >= 1_000_000) return `$${(amount / 1_000_000).toFixed(1)}M`;
  if (amount >= 1_000) return `$${(amount / 1_000).toFixed(0)}k`;
  return `$${amount.toFixed(0)}`;
}

function daysInStage(stageChangedAt: string | null): number | null {
  if (!stageChangedAt) return null;
  return Math.floor((Date.now() - new Date(stageChangedAt).getTime()) / 86_400_000);
}

/* ────────── component ────────── */

export function OpportunitiesPipelineView({ onSelectAccount, onSelectOpportunity }: Props) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSalesStages, setSelectedSalesStages] = useState<string[]>(SALES_STAGES_ORDER);
  const [selectedPreSalesStage, setSelectedPreSalesStage] = useState<string>('all');
  const [selectedAE, setSelectedAE] = useState<string>('all');
  const [selectedSE, setSelectedSE] = useState<string>('all');
  const [showArchived, setShowArchived] = useState(false);
  const [groupBy, setGroupBy] = useState<GroupBy>('none');
  const [funnelStageFilter, setFunnelStageFilter] = useState<string | null>(null);
  const [showMyOpps, setShowMyOpps] = useState(false);

  const { effectiveUserEmail, effectiveUserId } = useAuth();

  const { users: allUsers } = useAllActiveUsers();
  const { teamMembers } = useTeamMembers();

  // Fetch team hierarchy to map AE email → Manager name/id
  const { data: aeManagerMap } = useQuery({
    queryKey: ['ae-manager-map'],
    queryFn: async () => {
      // Get hierarchy with profile emails for reports and manager names
      const { data, error } = await supabase
        .from('team_hierarchy')
        .select('manager_id, report_id');
      if (error) throw error;

      // Get report emails + manager profiles in parallel
      const reportIds = [...new Set((data || []).map((r: any) => r.report_id))];
      const managerIds = [...new Set((data || []).map((r: any) => r.manager_id))];
      const allIds = [...new Set([...reportIds, ...managerIds])];

      // Fetch profiles for all IDs
      const profileMap = new Map<string, { email: string; full_name: string | null }>();
      for (let i = 0; i < allIds.length; i += 500) {
        const batch = allIds.slice(i, i + 500);
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, email, full_name')
          .in('id', batch);
        (profiles || []).forEach((p: any) => profileMap.set(p.id, { email: p.email, full_name: p.full_name }));
      }

      // Build email → { managerId, managerName } map
      const map = new Map<string, { managerId: string; managerName: string }>();
      (data || []).forEach((row: any) => {
        const reportProfile = profileMap.get(row.report_id);
        const managerProfile = profileMap.get(row.manager_id);
        if (reportProfile?.email) {
          map.set(reportProfile.email.toLowerCase(), {
            managerId: row.manager_id,
            managerName: managerProfile?.full_name || managerProfile?.email || row.manager_id,
          });
        }
      });
      return map;
    },
    staleTime: 120_000,
  });

  // Fetch opportunity IDs where the current user is a team member
  const { data: myTeamOppIds } = useQuery({
    queryKey: ['my-opportunity-team-ids', effectiveUserEmail],
    enabled: !!effectiveUserEmail,
    queryFn: async () => {
      const { data } = await supabase
        .from('opportunity_team_members')
        .select('opportunity_id')
        .eq('team_member_email', effectiveUserEmail!.toLowerCase());
      return new Set((data || []).map((r: any) => r.opportunity_id));
    },
    staleTime: 60_000,
  });

  // SE filter options
  const { data: seOptions } = useQuery({
    queryKey: ['se-filter-options-pipeline'],
    queryFn: async () => {
      const { data: seRoles } = await supabase
        .from('user_roles')
        .select('user_id, profiles!inner(email, full_name)')
        .eq('role', 'se' as any);
      const { data: oppSEs } = await supabase
        .from('opportunities')
        .select('primary_se_email')
        .not('primary_se_email', 'is', null);
      const seMap = new Map<string, string>();
      (seRoles || []).forEach((r: any) => {
        const p = Array.isArray(r.profiles) ? r.profiles[0] : r.profiles;
        if (p?.email) seMap.set(p.email.toLowerCase(), p.full_name || p.email);
      });
      (oppSEs || []).forEach((r: any) => {
        const e = r.primary_se_email?.toLowerCase();
        if (e && isValidEmail(e) && !seMap.has(e)) seMap.set(e, e);
      });
      return Array.from(seMap.entries()).map(([email, name]) => ({ email, name })).sort((a, b) => a.name.localeCompare(b.name));
    },
    staleTime: 60_000,
  });

  // Fetch ALL opportunities with account names – paginated to avoid 1000-row limit
  const { data: allOpportunities, isLoading } = useQuery({
    queryKey: ['pipeline-opportunities-full'],
    queryFn: async () => {
      // Fetch opps in pages
      const pageSize = 1000;
      let allOpps: any[] = [];
      let page = 0;
      let hasMore = true;
      while (hasMore) {
        const { data, error } = await supabase
          .from('opportunities')
          .select('id, name, account_id, sales_stage, pre_sales_stage, value, close_date, updated_at, is_archived, engagement_score, momentum_score, readiness_score, competitive_threat_level, competitive_threat_score, stage_changed_at, last_meeting_at, owner_id, primary_se_email, owner_email')
          .range(page * pageSize, (page + 1) * pageSize - 1)
          .order('updated_at', { ascending: false });
        if (error) throw error;
        allOpps = allOpps.concat(data || []);
        hasMore = (data?.length || 0) === pageSize;
        page++;
      }

      // Fetch all account names – also paginated
      const uniqueAccountIds = [...new Set(allOpps.map((o: any) => o.account_id))];
      const accountMap = new Map<string, { name: string; owner_id: string | null; primary_se_email: string | null }>();
      for (let i = 0; i < uniqueAccountIds.length; i += 500) {
        const batch = uniqueAccountIds.slice(i, i + 500);
        const { data: accounts } = await supabase
          .from('accounts')
          .select('id, name, owner_id, primary_se_email')
          .in('id', batch);
        (accounts || []).forEach((a: any) => accountMap.set(a.id, { name: a.name, owner_id: a.owner_id, primary_se_email: a.primary_se_email }));
      }

      return allOpps.map((o: any): EnrichedOpportunity => {
        const acct = accountMap.get(o.account_id);
        return {
          ...o,
          account_name: acct?.name || 'Unknown',
          account_owner_id: acct?.owner_id || null,
          account_se_email: acct?.primary_se_email || null,
        };
      });
    },
    staleTime: 30_000,
  });

  // Apply all filters
  const filteredOpps = useMemo(() => {
    if (!allOpportunities) return [];
    let result = [...allOpportunities];

    // Archived filter
    if (!showArchived) {
      result = result.filter(o => !o.is_archived);
    }

    // Sales stage filter (multi-select)
    if (selectedSalesStages.length > 0 && selectedSalesStages.length < SALES_STAGES_ORDER.length + 2) {
      result = result.filter(o => o.sales_stage && selectedSalesStages.includes(o.sales_stage));
    }

    // Pre-sales stage filter
    if (selectedPreSalesStage !== 'all') {
      result = result.filter(o => o.pre_sales_stage === selectedPreSalesStage);
    }

    // Funnel click filter (overrides stage filter visually)
    if (funnelStageFilter) {
      result = result.filter(o => o.sales_stage === funnelStageFilter);
    }

    // AE filter
    if (selectedAE !== 'all') {
      if (selectedAE === 'unassigned') {
        result = result.filter(o => !o.owner_id && !o.account_owner_id);
      } else {
        result = result.filter(o => o.owner_id === selectedAE || o.account_owner_id === selectedAE);
      }
    }

    // SE filter
    if (selectedSE !== 'all') {
      if (selectedSE === 'unassigned') {
        result = result.filter(o => !o.primary_se_email && !o.account_se_email);
      } else {
        result = result.filter(o =>
          o.primary_se_email === selectedSE || o.account_se_email === selectedSE
        );
      }
    }

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(o =>
        o.name.toLowerCase().includes(q) || o.account_name.toLowerCase().includes(q)
      );
    }

    // My Opportunities filter
    if (showMyOpps && effectiveUserEmail) {
      const email = effectiveUserEmail.toLowerCase();
      result = result.filter(o =>
        o.owner_id === effectiveUserId ||
        o.account_owner_id === effectiveUserId ||
        o.primary_se_email?.toLowerCase() === email ||
        o.account_se_email?.toLowerCase() === email ||
        o.owner_email?.toLowerCase() === email ||
        myTeamOppIds?.has(o.id)
      );
    }

    return result;
  }, [allOpportunities, showArchived, selectedSalesStages, selectedPreSalesStage, funnelStageFilter, selectedAE, selectedSE, searchQuery, showMyOpps, effectiveUserEmail, effectiveUserId, myTeamOppIds]);

  // Funnel data (based on pre-funnel-click filter state)
  const funnelData = useMemo(() => {
    if (!allOpportunities) return [];
    // Apply all filters EXCEPT funnel click
    let base = allOpportunities.filter(o => !o.is_archived);
    if (selectedSalesStages.length > 0 && selectedSalesStages.length < SALES_STAGES_ORDER.length + 2) {
      base = base.filter(o => o.sales_stage && selectedSalesStages.includes(o.sales_stage));
    }
    if (selectedPreSalesStage !== 'all') base = base.filter(o => o.pre_sales_stage === selectedPreSalesStage);
    if (selectedAE !== 'all') {
      if (selectedAE === 'unassigned') base = base.filter(o => !o.owner_id && !o.account_owner_id);
      else base = base.filter(o => o.owner_id === selectedAE || o.account_owner_id === selectedAE);
    }
    if (selectedSE !== 'all') {
      if (selectedSE === 'unassigned') base = base.filter(o => !o.primary_se_email && !o.account_se_email);
      else base = base.filter(o => o.primary_se_email === selectedSE || o.account_se_email === selectedSE);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      base = base.filter(o => o.name.toLowerCase().includes(q) || o.account_name.toLowerCase().includes(q));
    }
    if (showMyOpps && effectiveUserEmail) {
      const email = effectiveUserEmail.toLowerCase();
      base = base.filter(o =>
        o.owner_id === effectiveUserId ||
        o.account_owner_id === effectiveUserId ||
        o.primary_se_email?.toLowerCase() === email ||
        o.account_se_email?.toLowerCase() === email ||
        o.owner_email?.toLowerCase() === email ||
        myTeamOppIds?.has(o.id)
      );
    }

    return SALES_STAGES_ORDER.map(stage => {
      const stageOpps = base.filter(o => o.sales_stage === stage);
      const totalValue = stageOpps.reduce((s, o) => s + (o.value || 0), 0);
      const avgDays = stageOpps.length > 0
        ? stageOpps.reduce((s, o) => s + (daysInStage(o.stage_changed_at) ?? 0), 0) / stageOpps.length
        : 0;
      const avgEngagement = stageOpps.length > 0
        ? stageOpps.reduce((s, o) => s + (o.engagement_score ?? 0), 0) / stageOpps.length
        : 0;
      // Simple win rate proxy – not available without historical data, show 0
      return {
        stage,
        label: SALES_STAGE_LABELS[stage] || stage,
        count: stageOpps.length,
        totalValue,
        avgDays: Math.round(avgDays),
        avgEngagement: Math.round(avgEngagement),
      };
    });
  }, [allOpportunities, selectedSalesStages, selectedPreSalesStage, selectedAE, selectedSE, searchQuery, showMyOpps, effectiveUserEmail, effectiveUserId, myTeamOppIds]);

  const maxCount = Math.max(...funnelData.map(d => d.count), 1);

  // Group logic
  const groupedOpps = useMemo(() => {
    if (groupBy === 'none') return [{ key: 'all', label: 'All Opportunities', opps: filteredOpps }];

    const groups = new Map<string, { label: string; opps: EnrichedOpportunity[] }>();
    filteredOpps.forEach(o => {
      let key: string;
      let label: string;
      switch (groupBy) {
        case 'sales_stage':
          key = o.sales_stage || 'none';
          label = SALES_STAGE_LABELS[key] || key;
          break;
        case 'pre_sales_stage':
          key = o.pre_sales_stage || 'none';
          label = key === 'none' ? 'No Pre-Sales Stage' : key;
          break;
        case 'account':
          key = o.account_id;
          label = o.account_name;
          break;
        case 'owner':
          key = o.owner_id || o.account_owner_id || 'unassigned';
          label = key === 'unassigned' ? 'Unassigned' : (allUsers?.find(u => u.id === key)?.full_name || key);
          break;
        case 'se':
          key = o.primary_se_email || o.account_se_email || 'unassigned';
          label = key === 'unassigned' ? 'Unassigned' : (seOptions?.find(s => s.email === key)?.name || key);
          break;
        case 'ae_manager': {
          const seEmail = (o.primary_se_email || o.account_se_email || '').toLowerCase();
          const managerInfo = seEmail ? aeManagerMap?.get(seEmail) : undefined;
          key = managerInfo?.managerId || 'no_manager';
          label = managerInfo?.managerName || 'No Manager';
          break;
        }
        default:
          key = 'all';
          label = 'All';
      }
      if (!groups.has(key)) groups.set(key, { label, opps: [] });
      groups.get(key)!.opps.push(o);
    });

    return Array.from(groups.entries())
      .map(([key, val]) => ({ key, ...val }))
      .sort((a, b) => b.opps.length - a.opps.length);
  }, [filteredOpps, groupBy, allUsers, seOptions, aeManagerMap]);

  const hasActiveFilters = selectedSalesStages.length !== SALES_STAGES_ORDER.length ||
    selectedPreSalesStage !== 'all' || selectedAE !== 'all' || selectedSE !== 'all' ||
    funnelStageFilter !== null || showArchived || showMyOpps;

  const clearAllFilters = useCallback(() => {
    setSelectedSalesStages(SALES_STAGES_ORDER);
    setSelectedPreSalesStage('all');
    setSelectedAE('all');
    setSelectedSE('all');
    setFunnelStageFilter(null);
    setShowArchived(false);
    setShowMyOpps(false);
    setSearchQuery('');
  }, []);

  const handleFunnelClick = (stage: string) => {
    setFunnelStageFilter(prev => prev === stage ? null : stage);
  };

  const toggleSalesStage = (stage: string) => {
    setSelectedSalesStages(prev =>
      prev.includes(stage) ? prev.filter(s => s !== stage) : [...prev, stage]
    );
  };

  return (
    <TooltipProvider>
      <div className="space-y-5">
        {/* ── Funnel Chart ── */}
        <div className="glass rounded-xl p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-primary" />
            Pipeline Funnel
          </h3>
          <div className="space-y-1.5">
            {funnelData.map((d, i) => {
              const widthPct = Math.max((d.count / maxCount) * 100, 8);
              const isSelected = funnelStageFilter === d.stage;
              return (
                <button
                  key={d.stage}
                  onClick={() => handleFunnelClick(d.stage)}
                  className={cn(
                    "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-left transition-all hover:ring-1 hover:ring-primary/30",
                    isSelected ? 'ring-2 ring-primary bg-primary/5' : 'hover:bg-muted/40'
                  )}
                >
                  {/* Funnel bar */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-medium text-foreground truncate">{d.label}</span>
                      <span className="text-xs text-muted-foreground ml-2 shrink-0">{d.count} opps</span>
                    </div>
                    <div className="relative h-6 w-full">
                      <div
                        className={cn(
                          "h-full rounded-md transition-all flex items-center px-2",
                          SALES_STAGE_COLORS[d.stage] || 'bg-muted',
                          isSelected ? 'opacity-100' : 'opacity-80'
                        )}
                        style={{
                          width: `${widthPct}%`,
                          clipPath: `polygon(0 0, 100% ${4 + i * 2}%, 100% ${96 - i * 2}%, 0 100%)`,
                        }}
                      >
                        <span className="text-[10px] font-bold text-white truncate">
                          {formatCompactCurrency(d.totalValue)}
                        </span>
                      </div>
                    </div>
                  </div>
                  {/* Stats */}
                  <div className="hidden md:flex items-center gap-4 shrink-0 text-[10px] text-muted-foreground">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {d.avgDays}d
                        </span>
                      </TooltipTrigger>
                      <TooltipContent><p>Avg days in stage</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <span className="flex items-center gap-1">
                          <Activity className="w-3 h-3" />
                          {d.avgEngagement}%
                        </span>
                      </TooltipTrigger>
                      <TooltipContent><p>Avg engagement score</p></TooltipContent>
                    </Tooltip>
                  </div>
                </button>
              );
            })}
          </div>
          {funnelStageFilter && (
            <div className="mt-3 flex items-center gap-2">
              <Badge variant="secondary" className="gap-1">
                Filtered: {SALES_STAGE_LABELS[funnelStageFilter] || funnelStageFilter}
                <X className="w-3 h-3 cursor-pointer" onClick={() => setFunnelStageFilter(null)} />
              </Badge>
            </div>
          )}
          {/* Totals row */}
          <div className="mt-3 pt-3 border-t border-border flex items-center gap-6 text-xs text-muted-foreground">
            <span className="font-medium text-foreground">
              Total: {funnelData.reduce((s, d) => s + d.count, 0)} opportunities
            </span>
            <span>
              Pipeline: {formatCompactCurrency(funnelData.reduce((s, d) => s + d.totalValue, 0))}
            </span>
          </div>
        </div>

        {/* ── Filters ── */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-full md:w-56">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search opportunities..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-9"
            />
          </div>

          {/* My Opportunities */}
          <Button
            variant={showMyOpps ? 'default' : 'outline'}
            size="sm"
            className="h-9 text-xs gap-1.5"
            onClick={() => setShowMyOpps(!showMyOpps)}
          >
            <User className="w-3.5 h-3.5" />
            My Opps
          </Button>

          {/* Sales Stage multi-select */}
          <Select value="custom" onValueChange={() => {}}>
            <SelectTrigger className="w-[160px] h-9">
              <div className="flex items-center gap-1.5">
                <Filter className="w-3 h-3" />
                <span className="text-xs">Sales Stage</span>
                {selectedSalesStages.length < SALES_STAGES_ORDER.length && (
                  <Badge variant="secondary" className="h-4 px-1 text-[10px]">{selectedSalesStages.length}</Badge>
                )}
              </div>
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50">
              {SALES_STAGES_ORDER.map(stage => (
                <div
                  key={stage}
                  className="flex items-center gap-2 px-2 py-1.5 cursor-pointer hover:bg-muted/50 rounded"
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleSalesStage(stage); }}
                >
                  <div className={cn(
                    "w-3.5 h-3.5 rounded border flex items-center justify-center",
                    selectedSalesStages.includes(stage) ? 'bg-primary border-primary' : 'border-border'
                  )}>
                    {selectedSalesStages.includes(stage) && (
                      <svg className="w-2.5 h-2.5 text-primary-foreground" viewBox="0 0 12 12" fill="none">
                        <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    )}
                  </div>
                  <span className="text-xs">{SALES_STAGE_LABELS[stage] || stage}</span>
                </div>
              ))}
              <div className="border-t border-border mt-1 pt-1 px-2">
                <button
                  className="text-xs text-primary hover:underline"
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); setSelectedSalesStages(SALES_STAGES_ORDER); }}
                >
                  Select All
                </button>
              </div>
            </SelectContent>
          </Select>

          {/* Pre-Sales Stage */}
          <Select value={selectedPreSalesStage} onValueChange={setSelectedPreSalesStage}>
            <SelectTrigger className="w-[160px] h-9">
              <SelectValue placeholder="Pre-Sales Stage" />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50">
              <SelectItem value="all">All Pre-Sales</SelectItem>
              {PRE_SALES_STAGES.map(s => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* AE Filter */}
          <Select value={selectedAE} onValueChange={setSelectedAE}>
            <SelectTrigger className="w-[140px] h-9">
              <SelectValue placeholder="AE" />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50">
              <SelectItem value="all">All AEs</SelectItem>
              <SelectItem value="unassigned">Unassigned</SelectItem>
              {allUsers?.map(u => (
                <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* SE Filter */}
          <Select value={selectedSE} onValueChange={setSelectedSE}>
            <SelectTrigger className="w-[140px] h-9">
              <SelectValue placeholder="SE" />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50">
              <SelectItem value="all">All SEs</SelectItem>
              <SelectItem value="unassigned">Unassigned</SelectItem>
              {seOptions?.map(se => (
                <SelectItem key={se.email} value={se.email}>{se.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Show Archived */}
          <Button
            variant={showArchived ? 'secondary' : 'outline'}
            size="sm"
            className="h-9 text-xs"
            onClick={() => setShowArchived(!showArchived)}
          >
            {showArchived ? 'Showing All' : 'Active Only'}
          </Button>

          {/* Group By */}
          <Select value={groupBy} onValueChange={(v) => setGroupBy(v as GroupBy)}>
            <SelectTrigger className="w-[140px] h-9">
              <SelectValue placeholder="Group by" />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50">
              <SelectItem value="none">No Grouping</SelectItem>
              <SelectItem value="sales_stage">Sales Stage</SelectItem>
              <SelectItem value="pre_sales_stage">Pre-Sales Stage</SelectItem>
              <SelectItem value="account">Account</SelectItem>
              <SelectItem value="owner">Account Owner</SelectItem>
              <SelectItem value="se">Sales Engineer</SelectItem>
              <SelectItem value="ae_manager">SE Manager</SelectItem>
            </SelectContent>
          </Select>

          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={clearAllFilters} className="gap-1 h-9">
              <X className="w-3 h-3" /> Clear
            </Button>
          )}
        </div>

        {/* Results count */}
        <p className="text-xs text-muted-foreground">
          Showing {filteredOpps.length} opportunities
          {allOpportunities && filteredOpps.length < allOpportunities.length && (
            <span> (filtered from {allOpportunities.length})</span>
          )}
        </p>

        {/* Loading */}
        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-48 rounded-xl" />)}
          </div>
        )}

        {/* ── Grouped Opportunity Tables ── */}
        {!isLoading && groupedOpps.map(group => (
          <OpportunityGroup
            key={group.key}
            label={group.label}
            opps={group.opps}
            showGroupHeader={groupBy !== 'none'}
            onSelectAccount={onSelectAccount}
            onSelectOpportunity={onSelectOpportunity}
            allUsers={allUsers}
          />
        ))}

        {/* Empty state */}
        {!isLoading && filteredOpps.length === 0 && (
          <div className="glass rounded-xl p-8 flex flex-col items-center justify-center min-h-[200px]">
            <Briefcase className="w-12 h-12 text-muted-foreground mb-4" />
            <p className="font-semibold text-lg text-foreground">No opportunities match your filters</p>
            <Button variant="outline" onClick={clearAllFilters} className="mt-4">Clear all filters</Button>
          </div>
        )}
      </div>
    </TooltipProvider>
  );
}

/* ────────── Group ────────── */

function OpportunityGroup({
  label, opps, showGroupHeader, onSelectAccount, onSelectOpportunity, allUsers,
}: {
  label: string;
  opps: EnrichedOpportunity[];
  showGroupHeader: boolean;
  onSelectAccount: (id: string) => void;
  onSelectOpportunity: (accountId: string, oppId: string) => void;
  allUsers?: { id: string; full_name: string | null; email: string | null }[];
}) {
  const [isOpen, setIsOpen] = useState(true);
  const totalValue = opps.reduce((s, o) => s + (o.value || 0), 0);

  const content = (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead className="w-[280px]">Opportunity</TableHead>
          <TableHead>Account</TableHead>
          <TableHead>Sales Stage</TableHead>
          <TableHead>Pre-Sales</TableHead>
          <TableHead className="text-right">Value</TableHead>
          <TableHead>Close Date</TableHead>
          <TableHead>Health</TableHead>
          <TableHead>Updated</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {opps.map(opp => (
          <TableRow
            key={opp.id}
            className="cursor-pointer hover:bg-muted/50"
            onClick={() => onSelectOpportunity(opp.account_id, opp.id)}
          >
            <TableCell>
              <div className="flex items-center gap-2">
                <Briefcase className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                <span className="font-medium text-sm truncate max-w-[240px]">{opp.name}</span>
              </div>
            </TableCell>
            <TableCell>
              <button
                className="flex items-center gap-1.5 text-xs text-primary hover:underline"
                onClick={(e) => { e.stopPropagation(); onSelectAccount(opp.account_id); }}
              >
                <Building2 className="w-3 h-3" />
                <span className="truncate max-w-[120px]">{opp.account_name}</span>
              </button>
            </TableCell>
            <TableCell>
              {opp.sales_stage ? (
                <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                  {opp.sales_stage}
                </Badge>
              ) : <span className="text-muted-foreground text-xs">-</span>}
            </TableCell>
            <TableCell>
              {opp.pre_sales_stage ? (
                <Badge className={cn("text-[10px] px-1.5 py-0", PRE_SALES_STAGE_COLORS[opp.pre_sales_stage] || 'bg-muted text-muted-foreground')}>
                  {opp.pre_sales_stage}
                </Badge>
              ) : <span className="text-muted-foreground text-xs">-</span>}
            </TableCell>
            <TableCell className="text-right">
              {opp.value ? (
                <span className="font-medium text-sm">{formatCompactCurrency(opp.value)}</span>
              ) : <span className="text-muted-foreground text-xs">-</span>}
            </TableCell>
            <TableCell className="text-xs text-muted-foreground">
              {opp.close_date ? new Date(opp.close_date).toLocaleDateString() : '-'}
            </TableCell>
            <TableCell>
              <HealthIndicators opp={opp} />
            </TableCell>
            <TableCell className="text-xs text-muted-foreground">
              {new Date(opp.updated_at).toLocaleDateString()}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );

  if (!showGroupHeader) {
    return <div className="glass rounded-xl overflow-hidden">{content}</div>;
  }

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <div className="glass rounded-xl overflow-hidden">
        <CollapsibleTrigger asChild>
          <div className="flex items-center justify-between p-3 bg-muted/30 border-b border-border cursor-pointer hover:bg-muted/50 transition-colors">
            <div className="flex items-center gap-2">
              <ChevronRight className={cn("w-4 h-4 text-muted-foreground transition-transform", isOpen && "rotate-90")} />
              <span className="font-semibold text-sm text-foreground">{label}</span>
              <Badge variant="secondary" className="text-[10px]">{opps.length}</Badge>
            </div>
            <span className="text-xs text-muted-foreground">
              {formatCompactCurrency(totalValue)}
            </span>
          </div>
        </CollapsibleTrigger>
        <CollapsibleContent>
          {content}
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}

/* ────────── Health Indicators ────────── */

function HealthIndicators({ opp }: { opp: EnrichedOpportunity }) {
  const days = daysInStage(opp.stage_changed_at);
  const engagement = opp.engagement_score ?? null;
  const momentum = opp.momentum_score ?? null;
  const readiness = opp.readiness_score ?? null;
  const threat = opp.competitive_threat_level;

  const engColor = engagement !== null
    ? engagement >= 70 ? 'text-green-500' : engagement >= 40 ? 'text-amber-500' : 'text-red-500'
    : 'text-muted-foreground/40';

  const momentumColor = momentum !== null
    ? momentum >= 70 ? 'text-green-500' : momentum >= 40 ? 'text-amber-500' : 'text-red-500'
    : 'text-muted-foreground/40';

  const readinessColor = readiness !== null
    ? readiness >= 70 ? 'text-green-500' : readiness >= 40 ? 'text-amber-500' : 'text-red-500'
    : 'text-muted-foreground/40';

  const velocityColor = days !== null
    ? days <= 14 ? 'text-green-500' : days <= 45 ? 'text-amber-500' : 'text-red-500'
    : 'text-muted-foreground/40';

  const threatColor = threat === 'high' ? 'text-red-500'
    : threat === 'medium' ? 'text-amber-500'
    : threat === 'low' ? 'text-green-500'
    : 'text-muted-foreground/40';

  return (
    <div className="flex items-center gap-1">
      <Tooltip>
        <TooltipTrigger asChild>
          <span className={cn("inline-flex", engColor)}>
            <Activity className="w-3.5 h-3.5" />
          </span>
        </TooltipTrigger>
        <TooltipContent><p>Engagement: {engagement ?? 'N/A'}%</p></TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <span className={cn("inline-flex", momentumColor)}>
            <Zap className="w-3.5 h-3.5" />
          </span>
        </TooltipTrigger>
        <TooltipContent><p>Momentum: {momentum ?? 'N/A'}%</p></TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <span className={cn("inline-flex", readinessColor)}>
            <Target className="w-3.5 h-3.5" />
          </span>
        </TooltipTrigger>
        <TooltipContent><p>Technical Readiness: {readiness ?? 'N/A'}%</p></TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <span className={cn("inline-flex", velocityColor)}>
            <Clock className="w-3.5 h-3.5" />
          </span>
        </TooltipTrigger>
        <TooltipContent><p>Days in stage: {days ?? 'N/A'}</p></TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <span className={cn("inline-flex", threatColor)}>
            <Shield className="w-3.5 h-3.5" />
          </span>
        </TooltipTrigger>
        <TooltipContent><p>Competitive threat: {threat || 'None'}</p></TooltipContent>
      </Tooltip>
    </div>
  );
}

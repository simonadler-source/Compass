import { useState } from 'react';
import {
  Bell,
  Plus,
  Pencil,
  Trash2,
  AlertTriangle,
  Clock,
  Users,
  BarChart3,
  Calendar,
  Shield,
  MessageSquare,
  Target,
  Zap,
  Radio,
  TrendingUp,
  AlertCircle,
  Lightbulb,
  Workflow,
  Copy,
  Building2,
  User,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import {
  useOpportunityAlertRules,
  useMyAlertRules,
  useCreateAlertRule,
  useUpdateAlertRule,
  useDeleteAlertRule,
  useToggleAlertRule,
  useAvailableSignals,
  useCopyRuleToUser,
  OpportunityAlertRule,
  RuleType,
  AssignedToType,
  NbaPriority,
  NbaDeliveryMethod,
  ThresholdConfig,
  RULE_TYPE_LABELS,
  RULE_TYPE_DESCRIPTIONS,
} from '@/hooks/useOpportunityAlertRules';
import {
  ConditionBuilder,
  RuleConditions,
  TeamScopePicker,
  TeamScopeConfig,
  createDefaultRuleConditions,
} from '@/components/alert-rules';

const RULE_TYPE_ICONS: Record<RuleType, React.ElementType> = {
  readiness_below_threshold: BarChart3,
  unanswered_questions_count: MessageSquare,
  stale_readiness: Clock,
  stalled_stage: Target,
  missing_stakeholders: Users,
  no_recent_meetings: Calendar,
  milestone_overdue: AlertTriangle,
  security_incomplete: Shield,
  missing_signal: Radio,
  no_metrics: TrendingUp,
  no_pain_points: AlertCircle,
  no_use_cases: Lightbulb,
  custom: Zap,
  advanced: Workflow,
};

const PRIORITY_COLORS: Record<NbaPriority, string> = {
  low: 'bg-muted text-muted-foreground',
  medium: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
  high: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  critical: 'bg-destructive/10 text-destructive border-destructive/20',
};

const ASSIGNED_TO_LABELS: Record<AssignedToType, string> = {
  primary_se: 'Primary SE',
  opportunity_owner: 'Opportunity Owner',
  account_owner: 'Account Owner',
  rule_creator: 'Rule Creator (Me)',
  team_manager: 'Team Manager',
};

const DELIVERY_METHOD_LABELS: Record<NbaDeliveryMethod, string> = {
  email: 'Email',
  meeting: 'Meeting',
  internal: 'Internal Task',
};

export function OpportunityAlertRulesView() {
  const { user } = useAuth();
  const { isAdmin } = useUserRole();
  const { data: rules, isLoading } = useOpportunityAlertRules();
  const { data: myRules } = useMyAlertRules(user?.id);
  const { data: availableSignals } = useAvailableSignals();
  const createRule = useCreateAlertRule();
  const updateRule = useUpdateAlertRule();
  const deleteRule = useDeleteAlertRule();
  const toggleRule = useToggleAlertRule();
  const copyRule = useCopyRuleToUser();

  const [activeTab, setActiveTab] = useState<'system' | 'my-rules'>('system');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<OpportunityAlertRule | null>(null);
  const [deletingRule, setDeletingRule] = useState<OpportunityAlertRule | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [ruleType, setRuleType] = useState<RuleType>('readiness_below_threshold');
  const [thresholdConfig, setThresholdConfig] = useState<ThresholdConfig>({});
  const [advancedConditions, setAdvancedConditions] = useState<RuleConditions>(createDefaultRuleConditions());
  const [teamScope, setTeamScope] = useState<TeamScopeConfig>({ includeMyTeam: true, additionalUserIds: [] });
  const [nbaActionText, setNbaActionText] = useState('');
  const [nbaPriority, setNbaPriority] = useState<NbaPriority>('medium');
  const [nbaDeliveryMethod, setNbaDeliveryMethod] = useState<NbaDeliveryMethod>('internal');
  const [assignedToType, setAssignedToType] = useState<AssignedToType>('primary_se');
  const [cooldownDays, setCooldownDays] = useState(7);
  const [isSystemRule, setIsSystemRule] = useState(true);

  const resetForm = () => {
    setName('');
    setDescription('');
    setRuleType('readiness_below_threshold');
    setThresholdConfig({});
    setAdvancedConditions(createDefaultRuleConditions());
    setTeamScope({ includeMyTeam: true, additionalUserIds: [] });
    setNbaActionText('');
    setNbaPriority('medium');
    setNbaDeliveryMethod('internal');
    setAssignedToType('primary_se');
    setCooldownDays(7);
    setIsSystemRule(activeTab === 'system');
    setEditingRule(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  // Helper to migrate legacy rule to advanced conditions format
  const migrateRuleToConditions = (rule: OpportunityAlertRule): RuleConditions => {
    // If already has conditions, use them
    if (rule.threshold_config?.conditions) {
      return rule.threshold_config.conditions as RuleConditions;
    }

    // Migrate legacy rule types to condition format
    const config = rule.threshold_config || {};
    const defaultConditions = createDefaultRuleConditions();
    const condition = defaultConditions.groups[0].conditions[0];

    switch (rule.rule_type) {
      case 'readiness_below_threshold':
        condition.field = 'readiness_score';
        condition.operator = 'less_than';
        condition.value = config.minScore || 30;
        break;
      case 'stalled_stage':
        condition.field = 'days_in_stage';
        condition.operator = 'greater_than';
        condition.value = config.maxDays || 30;
        break;
      case 'stale_readiness':
        condition.field = 'days_since_readiness_update';
        condition.operator = 'greater_than';
        condition.value = config.maxDays || 14;
        break;
      case 'no_recent_meetings':
        condition.field = 'days_since_meeting';
        condition.operator = 'greater_than';
        condition.value = config.maxDays || 21;
        break;
      case 'missing_stakeholders':
        if (config.requiredRoles && config.requiredRoles.length > 0) {
          condition.field = 'missing_stakeholder_role';
          condition.operator = 'is_empty';
          condition.fieldContext = config.requiredRoles[0];
        }
        break;
      case 'missing_signal':
        condition.field = 'signal_missing';
        condition.operator = 'is_empty';
        condition.fieldContext = config.signalFieldName || '';
        break;
      case 'no_metrics':
        condition.field = 'metric_count';
        condition.operator = 'less_than';
        condition.value = config.minCount || 1;
        break;
      case 'no_pain_points':
        condition.field = 'pain_point_count';
        condition.operator = 'less_than';
        condition.value = config.minCount || 1;
        break;
      case 'no_use_cases':
        condition.field = 'use_case_count';
        condition.operator = 'less_than';
        condition.value = config.minCount || 1;
        break;
      default:
        // Keep default readiness score condition
        break;
    }

    return defaultConditions;
  };

  const openEditDialog = (rule: OpportunityAlertRule) => {
    setEditingRule(rule);
    setName(rule.name);
    setDescription(rule.description || '');
    setRuleType('advanced'); // Always use advanced for condition builder
    setThresholdConfig(rule.threshold_config || {});
    // Migrate or load conditions
    const migratedConditions = migrateRuleToConditions(rule);
    setAdvancedConditions(migratedConditions);
    // Load team scope from conditions if present
    setTeamScope(migratedConditions.teamScope || { includeMyTeam: true, additionalUserIds: [] });
    setNbaActionText(rule.nba_action_text);
    setNbaPriority(rule.nba_priority);
    setNbaDeliveryMethod(rule.nba_delivery_method);
    setAssignedToType(rule.assigned_to_type);
    setCooldownDays(rule.cooldown_days);
    setIsSystemRule(rule.is_system_rule);
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      toast.error('Rule name is required');
      return;
    }

    // Validate at least one condition exists
    const hasConditions = advancedConditions.groups.some(g => g.conditions.length > 0);
    if (!hasConditions) {
      toast.error('At least one condition is required');
      return;
    }

    try {
      // Always store conditions in threshold_config, including teamScope
      const conditionsWithScope = { ...advancedConditions, teamScope };
      const finalThresholdConfig = { conditions: conditionsWithScope };

      if (editingRule) {
        await updateRule.mutateAsync({
          id: editingRule.id,
          name,
          description: description || null,
          rule_type: 'advanced',
          threshold_config: finalThresholdConfig,
          nba_action_text: nbaActionText,
          nba_priority: nbaPriority,
          nba_delivery_method: nbaDeliveryMethod,
          assigned_to_type: assignedToType,
          cooldown_days: cooldownDays,
        });
        toast.success('Rule updated');
      } else {
        const newIsSystemRule = isSystemRule && isAdmin;
        await createRule.mutateAsync({
          name,
          description: description || null,
          rule_type: 'advanced',
          threshold_config: finalThresholdConfig,
          nba_action_text: nbaActionText,
          nba_priority: nbaPriority,
          nba_delivery_method: nbaDeliveryMethod,
          assigned_to_type: assignedToType,
          cooldown_days: cooldownDays,
          is_active: true,
          sort_order: (rules?.length || 0) + 1,
          owner_id: newIsSystemRule ? null : (user?.id || null),
          is_system_rule: newIsSystemRule,
          copied_from_rule_id: null,
        });
        toast.success('Rule created');
      }
      setDialogOpen(false);
      resetForm();
    } catch (error) {
      toast.error('Failed to save rule');
    }
  };

  const handleDelete = async () => {
    if (!deletingRule) return;
    try {
      await deleteRule.mutateAsync(deletingRule.id);
      toast.success('Rule deleted');
      setDeleteDialogOpen(false);
      setDeletingRule(null);
    } catch (error) {
      toast.error('Failed to delete rule');
    }
  };

  const handleToggle = async (rule: OpportunityAlertRule) => {
    try {
      await toggleRule.mutateAsync({ id: rule.id, is_active: !rule.is_active });
      toast.success(rule.is_active ? 'Rule disabled' : 'Rule enabled');
    } catch (error) {
      toast.error('Failed to update rule');
    }
  };

  const handleCopyRule = async (rule: OpportunityAlertRule) => {
    if (!user?.id) {
      toast.error('You must be logged in to copy rules');
      return;
    }
    try {
      await copyRule.mutateAsync({ rule, userId: user.id });
      toast.success('Rule copied to My Rules');
      setActiveTab('my-rules');
    } catch (error) {
      toast.error('Failed to copy rule');
    }
  };

  // Filter rules based on active tab
  const systemRules = rules?.filter(r => r.is_system_rule) || [];
  const userRules = myRules || [];

  const canEditRule = (rule: OpportunityAlertRule) => {
    if (rule.is_system_rule) return isAdmin;
    return rule.owner_id === user?.id;
  };

  const canDeleteRule = (rule: OpportunityAlertRule) => {
    if (rule.is_system_rule) return isAdmin;
    return rule.owner_id === user?.id;
  };

  const getThresholdSummary = (rule: OpportunityAlertRule) => {
    const config = rule.threshold_config;
    switch (rule.rule_type) {
      case 'readiness_below_threshold':
        return `Score < ${config.minScore || 30}%`;
      case 'unanswered_questions_count':
        return `${config.category ? config.category + ': ' : ''}> ${config.maxUnanswered || 3} unanswered`;
      case 'stale_readiness':
      case 'stalled_stage':
      case 'no_recent_meetings':
        return `> ${config.maxDays || 14} days`;
      case 'missing_stakeholders':
        return (config.requiredRoles || []).join(', ') || 'No roles specified';
      case 'missing_signal':
        return config.signalDisplayName || config.signalFieldName || 'No signal selected';
      case 'no_metrics':
        return `< ${config.minCount ?? 1} metrics`;
      case 'no_pain_points':
        return `< ${config.minCount ?? 1} pain points`;
      case 'no_use_cases':
        return `< ${config.minCount ?? 1} use cases`;
      case 'milestone_overdue':
        return 'Any overdue milestone';
      case 'security_incomplete':
        return 'Security questions incomplete';
      case 'advanced': {
        const conditions = config.conditions as RuleConditions | undefined;
        if (!conditions) return 'No conditions configured';
        const groupCount = conditions.groups?.length || 0;
        const conditionCount = conditions.groups?.reduce((sum, g) => sum + g.conditions.length, 0) || 0;
        return `${conditionCount} conditions in ${groupCount} group${groupCount !== 1 ? 's' : ''}`;
      }
      default:
        return JSON.stringify(config);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Bell className="w-6 h-6 text-primary" />
            Opportunity Alert Rules
          </h1>
          <p className="text-muted-foreground mt-1">
            Configure automated alerts and NBAs based on opportunity health signals
          </p>
        </div>
        {isAdmin && activeTab === 'system' ? (
          <Button onClick={() => { setIsSystemRule(true); openCreateDialog(); }}>
            <Plus className="w-4 h-4 mr-2" />
            Add System Rule
          </Button>
        ) : activeTab === 'my-rules' ? (
          <Button onClick={() => { setIsSystemRule(false); openCreateDialog(); }}>
            <Plus className="w-4 h-4 mr-2" />
            Add My Rule
          </Button>
        ) : null}
      </div>

      {/* Tabs for System vs My Rules */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'system' | 'my-rules')}>
        <TabsList>
          <TabsTrigger value="system" className="flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            System Rules ({systemRules.length})
          </TabsTrigger>
          <TabsTrigger value="my-rules" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            My Rules ({userRules.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="system" className="mt-4 space-y-4">
          {systemRules.length === 0 && (
            <Card className="p-8 text-center">
              <Building2 className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="font-semibold">No System Rules</h3>
              <p className="text-sm text-muted-foreground mt-1">
                {isAdmin ? 'Create system-wide alert rules that apply to all users' : 'No system rules have been configured yet'}
              </p>
              {isAdmin && (
                <Button className="mt-4" onClick={() => { setIsSystemRule(true); openCreateDialog(); }}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create System Rule
                </Button>
              )}
            </Card>
          )}

          {systemRules.map((rule) => {
            const Icon = RULE_TYPE_ICONS[rule.rule_type] || Workflow;
            return (
              <Card key={rule.id} className={!rule.is_active ? 'opacity-60' : ''}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="p-2 rounded-lg bg-primary/10">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-lg flex items-center gap-2">
                          {rule.name}
                          <Badge variant="outline" className="text-xs">
                            <Building2 className="w-3 h-3 mr-1" />
                            System
                          </Badge>
                          {!rule.is_active && (
                            <Badge variant="secondary" className="text-xs">Disabled</Badge>
                          )}
                        </CardTitle>
                        <CardDescription className="mt-1">
                          {rule.description || RULE_TYPE_DESCRIPTIONS[rule.rule_type]}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {/* Copy to My Rules button - available to all users */}
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => handleCopyRule(rule)}
                        title="Copy to My Rules"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      {canEditRule(rule) && (
                        <>
                          <Switch
                            checked={rule.is_active}
                            onCheckedChange={() => handleToggle(rule)}
                          />
                          <Button variant="ghost" size="icon" onClick={() => openEditDialog(rule)}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setDeletingRule(rule);
                              setDeleteDialogOpen(true);
                            }}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Type:</span>
                      <Badge variant="outline">{RULE_TYPE_LABELS[rule.rule_type]}</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Threshold:</span>
                      <span className="font-medium">{getThresholdSummary(rule)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Priority:</span>
                      <Badge className={PRIORITY_COLORS[rule.nba_priority]}>
                        {rule.nba_priority}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Assign to:</span>
                      <span className="font-medium">{ASSIGNED_TO_LABELS[rule.assigned_to_type]}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Cooldown:</span>
                      <span className="font-medium">{rule.cooldown_days} days</span>
                    </div>
                  </div>
                  <div className="mt-3 p-3 bg-muted/50 rounded-lg">
                    <span className="text-xs text-muted-foreground">NBA Action:</span>
                    <p className="text-sm mt-1">{rule.nba_action_text}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>

        <TabsContent value="my-rules" className="mt-4 space-y-4">
          {userRules.length === 0 && (
            <Card className="p-8 text-center">
              <User className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="font-semibold">No Personal Rules</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Create your own alert rules or copy from system rules to customize alerts for your direct reports
              </p>
              <div className="flex items-center justify-center gap-2 mt-4">
                <Button onClick={() => { setIsSystemRule(false); openCreateDialog(); }}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create My Rule
                </Button>
                {systemRules.length > 0 && (
                  <Button variant="outline" onClick={() => setActiveTab('system')}>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy from System
                  </Button>
                )}
              </div>
            </Card>
          )}

          {userRules.map((rule) => {
            const Icon = RULE_TYPE_ICONS[rule.rule_type] || Workflow;
            return (
              <Card key={rule.id} className={!rule.is_active ? 'opacity-60' : ''}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="p-2 rounded-lg bg-secondary/50">
                        <Icon className="w-5 h-5 text-secondary-foreground" />
                      </div>
                      <div>
                        <CardTitle className="text-lg flex items-center gap-2">
                          {rule.name}
                          {rule.copied_from_rule_id && (
                            <Badge variant="secondary" className="text-xs">
                              <Copy className="w-3 h-3 mr-1" />
                              Copied
                            </Badge>
                          )}
                          {!rule.is_active && (
                            <Badge variant="secondary" className="text-xs">Disabled</Badge>
                          )}
                        </CardTitle>
                        <CardDescription className="mt-1">
                          {rule.description || RULE_TYPE_DESCRIPTIONS[rule.rule_type]}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={rule.is_active}
                        onCheckedChange={() => handleToggle(rule)}
                      />
                      <Button variant="ghost" size="icon" onClick={() => openEditDialog(rule)}>
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setDeletingRule(rule);
                          setDeleteDialogOpen(true);
                        }}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Type:</span>
                      <Badge variant="outline">{RULE_TYPE_LABELS[rule.rule_type]}</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Threshold:</span>
                      <span className="font-medium">{getThresholdSummary(rule)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Priority:</span>
                      <Badge className={PRIORITY_COLORS[rule.nba_priority]}>
                        {rule.nba_priority}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Assign to:</span>
                      <span className="font-medium">{ASSIGNED_TO_LABELS[rule.assigned_to_type]}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Cooldown:</span>
                      <span className="font-medium">{rule.cooldown_days} days</span>
                    </div>
                  </div>
                  <div className="mt-3 p-3 bg-muted/50 rounded-lg">
                    <span className="text-xs text-muted-foreground">NBA Action:</span>
                    <p className="text-sm mt-1">{rule.nba_action_text}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>
      </Tabs>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingRule ? 'Edit Alert Rule' : 'Create Alert Rule'}
            </DialogTitle>
            <DialogDescription>
              Configure when and how to alert team members about opportunity health issues
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Basic Info */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Rule Name</Label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Low Readiness Score Alert"
                />
              </div>
              <div className="space-y-2">
                <Label>Description (optional)</Label>
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe what this rule monitors..."
                />
              </div>
            </div>

            {/* Condition Builder - Always visible */}
            <div className="space-y-2">
              <Label>Trigger Conditions</Label>
              <div className="p-4 border rounded-lg bg-muted/30">
                <ConditionBuilder
                  conditions={advancedConditions}
                  availableSignals={availableSignals}
                  onChange={setAdvancedConditions}
                />
              </div>
            </div>

            {/* Team Scope Picker - available for all rules */}
            <div className="space-y-2">
              <Label className="text-base font-medium">Team Scope</Label>
              <p className="text-sm text-muted-foreground mb-3">
                {isSystemRule 
                  ? "Define which teams' opportunities this system rule should monitor (leave empty for all opportunities)"
                  : "Define which teams' opportunities this rule should monitor"}
              </p>
              <div className="p-4 border rounded-lg bg-muted/30">
                <TeamScopePicker
                  value={teamScope}
                  onChange={setTeamScope}
                />
              </div>
            </div>

            {/* NBA Configuration */}
            <div className="space-y-4">
              <h4 className="font-medium">NBA (Next Best Action) Settings</h4>
              
              <div className="space-y-2">
                <Label>Action Text</Label>
                <Textarea
                  value={nbaActionText}
                  onChange={(e) => setNbaActionText(e.target.value)}
                  placeholder="Conduct technical discovery session..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Priority</Label>
                  <Select value={nbaPriority} onValueChange={(v) => setNbaPriority(v as NbaPriority)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Delivery Method</Label>
                  <Select value={nbaDeliveryMethod} onValueChange={(v) => setNbaDeliveryMethod(v as NbaDeliveryMethod)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="internal">Internal Task</SelectItem>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="meeting">Meeting</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Assign To</Label>
                  <Select value={assignedToType} onValueChange={(v) => setAssignedToType(v as AssignedToType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rule_creator">
                        <div className="flex flex-col items-start">
                          <span>Rule Creator (Me)</span>
                          <span className="text-xs text-muted-foreground">Always assigns to whoever created this rule</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="team_manager">
                        <div className="flex flex-col items-start">
                          <span>Team Manager</span>
                          <span className="text-xs text-muted-foreground">Assigns to the manager of the opportunity's owner</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="primary_se">Primary SE</SelectItem>
                      <SelectItem value="opportunity_owner">Opportunity Owner</SelectItem>
                      <SelectItem value="account_owner">Account Owner</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Choose "Rule Creator" to receive alerts yourself, or "Team Manager" to notify the manager in the hierarchy
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Cooldown (days)</Label>
                  <Input
                    type="number"
                    min={1}
                    value={cooldownDays}
                    onChange={(e) => setCooldownDays(parseInt(e.target.value) || 7)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Minimum days before re-triggering for same opportunity
                  </p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={createRule.isPending || updateRule.isPending}>
              {editingRule ? 'Update Rule' : 'Create Rule'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Alert Rule</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deletingRule?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

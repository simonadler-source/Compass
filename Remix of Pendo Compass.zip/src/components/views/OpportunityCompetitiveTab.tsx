import { useMemo, useState, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { 
  Swords, Shield, AlertTriangle, TrendingUp, TrendingDown, 
  Target, Users, Lightbulb, CheckCircle, XCircle, Clock,
  ChevronRight, ExternalLink, Zap, MessageSquare, BarChart3,
  RefreshCw, Loader2
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { 
  useOpportunityCompetitiveInsights, 
  useCompetitivePlaySuggestions,
  useOpportunityThreatAssessment,
  useUpdatePlaySuggestionStatus,
  type CompetitiveInsight,
  type CompetitivePlaySuggestion
} from '@/hooks/useOpportunityCompetitiveInsights';
import { useCompetitiveAnalysis } from '@/hooks/useCompetitiveIntelligence';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';
import { ScorecardComparison } from '@/components/competitive/ScorecardComparison';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

// Hook to fetch ALL competitor names for the opportunity from multiple sources
function useOpportunityCompetitorNames(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-all-competitor-names', opportunityId],
    queryFn: async (): Promise<string[]> => {
      // Source 1: product_mentions table (auto-detected + manual)
      const mentionsPromise = gateway
        .from('product_mentions')
        .select('id, product_name')
        .eq('opportunity_id', opportunityId)
        .eq('mention_type', 'competitive')
        .execute();

      // Source 2: AI-extracted competitorMentions from transcript insights
      const transcriptsPromise = supabase
        .from('transcript_reviews')
        .select('extracted_insights')
        .eq('opportunity_id', opportunityId)
        .not('extracted_insights', 'is', null);

      const [mentionsRes, transcriptsRes] = await Promise.all([mentionsPromise, transcriptsPromise]);

      const names = new Set<string>();

      // Add from product_mentions
      if (!mentionsRes.error && mentionsRes.data) {
        (mentionsRes.data as any[]).forEach((d) => {
          if (d.product_name) names.add(d.product_name);
        });
      }

      // Add from transcript extracted_insights.competitorMentions
      if (!transcriptsRes.error && transcriptsRes.data) {
        transcriptsRes.data.forEach((tr: any) => {
          const insights = tr.extracted_insights;
          if (insights?.competitorMentions) {
            (insights.competitorMentions as string[]).forEach((c) => {
              if (c) names.add(c);
            });
          }
        });
      }

      return Array.from(names);
    },
    enabled: !!opportunityId,
  });
}

// Hook to fetch use cases for the account
function useAccountUseCasesForPlays(accountId: string) {
  return useQuery({
    queryKey: ['account-use-cases-for-plays', accountId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('account_use_cases')
        .select('id, use_case, functional_area, business_theme')
        .eq('account_id', accountId)
        .limit(50);
      if (error) throw error;
      return (data || []).map((uc: any) => ({
        id: uc.id,
        useCase: uc.use_case || 'Unnamed',
        functionalArea: uc.functional_area || 'General',
        businessTheme: uc.business_theme || 'general',
      }));
    },
    enabled: !!accountId,
  });
}

interface OpportunityCompetitiveTabProps {
  opportunityId: string;
  accountId: string;
}

const THREAT_COLORS = {
  high: { bg: 'bg-red-500', text: 'text-red-700', light: 'bg-red-50 border-red-200' },
  medium: { bg: 'bg-amber-500', text: 'text-amber-700', light: 'bg-amber-50 border-amber-200' },
  low: { bg: 'bg-green-500', text: 'text-green-700', light: 'bg-green-50 border-green-200' },
  none: { bg: 'bg-gray-300', text: 'text-gray-600', light: 'bg-gray-50 border-gray-200' },
};

const PLAY_TYPE_CONFIG = {
  landmine: { icon: Target, color: 'text-red-600', label: 'Landmine' },
  differentiation: { icon: Zap, color: 'text-blue-600', label: 'Differentiation' },
  objection_handler: { icon: Shield, color: 'text-amber-600', label: 'Objection Handler' },
  feature_highlight: { icon: TrendingUp, color: 'text-green-600', label: 'Feature Highlight' },
  case_study: { icon: Users, color: 'text-purple-600', label: 'Case Study' },
};

const SENTIMENT_COLORS = {
  positive: 'text-green-600 bg-green-50',
  neutral: 'text-gray-600 bg-gray-50',
  negative: 'text-red-600 bg-red-50',
  mixed: 'text-amber-600 bg-amber-50',
};

// Threat Meter Component
function ThreatMeter({ 
  threatLevel, 
  threatScore, 
  competitorNames,
}: { 
  threatLevel: string; 
  threatScore: number; 
  competitorNames: string[];
}) {
  const colors = THREAT_COLORS[threatLevel as keyof typeof THREAT_COLORS] || THREAT_COLORS.none;
  
  return (
    <Card className={cn("border-l-4", colors.light)}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Swords className={cn("w-5 h-5", colors.text)} />
            <span className="font-semibold">Competitive Threat Level</span>
          </div>
          <Badge className={cn("capitalize", colors.bg, "text-white")}>
            {threatLevel}
          </Badge>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Threat Score</span>
            <span className={cn("font-medium", colors.text)}>{threatScore}/100</span>
          </div>
          <Progress value={threatScore} className="h-2" />
        </div>
        
        {competitorNames.length > 0 && (
          <div className="mt-3 pt-3 border-t">
            <span className="text-sm text-muted-foreground">Competitors ({competitorNames.length})</span>
            <div className="flex flex-wrap gap-1.5 mt-1.5">
              {competitorNames.map(name => (
                <Badge key={name} variant="outline" className="font-medium text-xs">
                  {name}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Strategy badge config
const STRATEGY_CONFIG = {
  attack: { icon: TrendingUp, color: 'text-green-600 bg-green-50 border-green-200', label: 'Attack' },
  defend: { icon: Shield, color: 'text-amber-600 bg-amber-50 border-amber-200', label: 'Defend' },
};

// Competitive Play Card
function PlayCard({ 
  play, 
  onStatusChange,
  useCases,
}: { 
  play: CompetitivePlaySuggestion; 
  onStatusChange: (status: CompetitivePlaySuggestion['status']) => void;
  useCases?: { id: string; useCase: string; functionalArea: string }[];
}) {
  const config = PLAY_TYPE_CONFIG[play.playType];
  const Icon = config.icon;
  const strategyConfig = STRATEGY_CONFIG[play.playStrategy] || STRATEGY_CONFIG.attack;
  const StrategyIcon = strategyConfig.icon;
  
  // Find linked use cases
  const linkedUCs = useCases?.filter(uc => play.linkedUseCaseIds?.includes(uc.id)) || [];
  
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className={cn("text-xs gap-1", strategyConfig.color)}>
              <StrategyIcon className="w-3 h-3" />
              {strategyConfig.label}
            </Badge>
            <div className="flex items-center gap-1">
              <Icon className={cn("w-3.5 h-3.5", config.color)} />
              <Badge variant="outline" className="text-xs">
                {config.label}
              </Badge>
            </div>
          </div>
          {play.status === 'suggested' && (
            <div className="flex gap-1">
              <Button 
                size="sm" 
                variant="ghost" 
                className="h-7 w-7 p-0 text-green-600 hover:bg-green-50"
                onClick={() => onStatusChange('accepted')}
              >
                <CheckCircle className="w-4 h-4" />
              </Button>
              <Button 
                size="sm" 
                variant="ghost" 
                className="h-7 w-7 p-0 text-gray-400 hover:bg-gray-50"
                onClick={() => onStatusChange('dismissed')}
              >
                <XCircle className="w-4 h-4" />
              </Button>
            </div>
          )}
          {play.status !== 'suggested' && (
            <Badge 
              variant="outline" 
              className={cn(
                "text-xs",
                play.status === 'accepted' && "text-green-600 border-green-200",
                play.status === 'executed' && "text-blue-600 border-blue-200",
                play.status === 'dismissed' && "text-gray-400 border-gray-200"
              )}
            >
              {play.status}
            </Badge>
          )}
        </div>
        
        <h4 className="font-medium text-sm mb-1">{play.playTitle}</h4>
        {play.playDescription && (
          <p className="text-xs text-muted-foreground mb-2">{play.playDescription}</p>
        )}
        
        {linkedUCs.length > 0 && (
          <div className="flex items-center gap-1 mb-2 flex-wrap">
            <span className="text-xs text-muted-foreground">Use cases:</span>
            {linkedUCs.map(uc => (
              <Badge key={uc.id} variant="secondary" className="text-xs">
                {uc.functionalArea}
              </Badge>
            ))}
          </div>
        )}
        
        {(play.talkingPoints ?? []).length > 0 && (
          <div className="mt-2 pt-2 border-t">
            <p className="text-xs font-medium text-muted-foreground mb-1">Talking Points:</p>
            <ul className="space-y-1">
              {(play.talkingPoints ?? []).slice(0, 3).map((point, idx) => (
                <li key={idx} className="text-xs flex items-start gap-1">
                  <ChevronRight className="w-3 h-3 mt-0.5 text-muted-foreground" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Objection Card
function ObjectionCard({ insight }: { insight: CompetitiveInsight }) {
  const severityColors = {
    high: 'border-l-red-500 bg-red-50/50',
    medium: 'border-l-amber-500 bg-amber-50/50',
    low: 'border-l-gray-400 bg-gray-50/50',
  };
  
  return (
    <div className={cn(
      "border rounded-lg p-3 border-l-4",
      severityColors[insight.objectionSeverity || 'low']
    )}>
      <div className="flex items-start justify-between mb-1">
        <Badge variant="outline" className="text-xs capitalize">
          {insight.objectionType?.replace('_', ' ')}
        </Badge>
        <Badge 
          variant="outline" 
          className={cn(
            "text-xs",
            insight.objectionSeverity === 'high' && "text-red-600 border-red-200",
            insight.objectionSeverity === 'medium' && "text-amber-600 border-amber-200",
          )}
        >
          {insight.objectionSeverity} severity
        </Badge>
      </div>
      
      <p className="text-sm mt-2">{insight.objectionText}</p>
      
      <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
        {insight.competitorName && (
          <span className="flex items-center gap-1">
            <Swords className="w-3 h-3" />
            {insight.competitorName}
          </span>
        )}
        <span className="flex items-center gap-1">
          <Users className="w-3 h-3" />
          {insight.speakerType === 'external' ? 'Customer' : 'Internal'}
        </span>
      </div>
    </div>
  );
}

// Competitor Mention Card
function CompetitorMentionCard({ insight }: { insight: CompetitiveInsight }) {
  return (
    <div className="border rounded-lg p-3 hover:bg-muted/30 transition-colors">
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="font-medium text-sm">{insight.competitorName}</span>
          <Badge variant="outline" className="text-xs capitalize">
            {insight.mentionType?.replace('_', ' ')}
          </Badge>
        </div>
        <Badge className={cn("text-xs", SENTIMENT_COLORS[insight.sentiment])}>
          {insight.sentiment}
        </Badge>
      </div>
      
      {insight.mentionContext && (
        <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
          "{insight.mentionContext}"
        </p>
      )}
      
      {insight.featureDiscussed && (
        <div className="flex items-center gap-2 text-xs">
          <span className="text-muted-foreground">Feature:</span>
          <span className="font-medium">{insight.featureDiscussed}</span>
          {insight.pendoPosition && (
            <Badge 
              variant="outline" 
              className={cn(
                "text-xs",
                insight.pendoPosition === 'stronger' && "text-green-600",
                insight.pendoPosition === 'weaker' && "text-red-600",
              )}
            >
              Pendo {insight.pendoPosition}
            </Badge>
          )}
        </div>
      )}
      
      <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
        <Clock className="w-3 h-3" />
        {format(new Date(insight.detectedAt), 'MMM d, yyyy')}
      </div>
    </div>
  );
}

export function OpportunityCompetitiveTab({ opportunityId, accountId }: OpportunityCompetitiveTabProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [regenProgress, setRegenProgress] = useState('');
  const queryClient = useQueryClient();
  
  const { data: insights, isLoading: loadingInsights } = useOpportunityCompetitiveInsights(opportunityId);
  const { data: plays, isLoading: loadingPlays } = useCompetitivePlaySuggestions(opportunityId);
  const { data: allCompetitorNames } = useOpportunityCompetitorNames(opportunityId);
  const { data: threatAssessment, isLoading: loadingThreat } = useOpportunityThreatAssessment(opportunityId, allCompetitorNames);
  const { data: useCases } = useAccountUseCasesForPlays(accountId);
  const updatePlayStatus = useUpdatePlaySuggestionStatus();

  // Regenerate competitive intelligence from transcripts with competitor mentions
  const handleRegenerate = useCallback(async () => {
    setIsRegenerating(true);
    setRegenProgress('Finding transcripts with competitor mentions...');
    
    try {
      // Find transcripts with competitor mentions in extracted_insights
      const { data: transcripts, error: fetchErr } = await supabase
        .from('transcript_reviews')
        .select('id, meeting_title, extracted_insights')
        .eq('opportunity_id', opportunityId)
        .eq('status', 'approved')
        .not('extracted_insights', 'is', null);
      
      if (fetchErr) throw fetchErr;
      
      // Filter to those with competitorMentions
      const withCompetitors = (transcripts || []).filter((tr: any) => {
        const mentions = tr.extracted_insights?.competitorMentions;
        return Array.isArray(mentions) && mentions.length > 0;
      });
      
      if (withCompetitors.length === 0) {
        setRegenProgress('No transcripts with competitor mentions found.');
        setTimeout(() => { setIsRegenerating(false); setRegenProgress(''); }, 2000);
        return;
      }
      
      setRegenProgress(`Processing ${withCompetitors.length} transcript(s)...`);
      
      // Reset last_enriched_hash to force re-enrichment
      const transcriptIds = withCompetitors.map((t: any) => t.id);
      await supabase
        .from('transcript_reviews')
        .update({ last_enriched_hash: null })
        .in('id', transcriptIds);
      
      // Trigger enrichment for each transcript sequentially to avoid overload
      let completed = 0;
      let totalInsights = 0;
      let totalPlays = 0;
      
      for (const tr of withCompetitors) {
        completed++;
        setRegenProgress(`Analyzing ${completed}/${withCompetitors.length}: ${(tr as any).meeting_title || 'Untitled'}...`);
        
        try {
          const { data: result, error: enrichErr } = await supabase.functions.invoke('enrich-transcript', {
            body: { transcriptReviewId: tr.id },
          });
          
          if (enrichErr) {
            console.error(`[Regen] Failed for ${tr.id}:`, enrichErr);
          } else {
            totalInsights += result?.competitiveInsights || 0;
            totalPlays += result?.competitivePlays || 0;
          }
        } catch (err) {
          console.error(`[Regen] Error for ${tr.id}:`, err);
        }
      }
      
      setRegenProgress(`Done! Generated ${totalInsights} insights and ${totalPlays} plays from ${withCompetitors.length} transcript(s).`);
      
      // Invalidate queries to refresh the UI
      queryClient.invalidateQueries({ queryKey: ['opportunity-competitive-insights'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-play-suggestions'] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-threat-assessment'] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-all-competitor-names'] });
      
      setTimeout(() => { setIsRegenerating(false); setRegenProgress(''); }, 3000);
    } catch (err) {
      console.error('[Regen] Error:', err);
      setRegenProgress('Failed to regenerate. Please try again.');
      setTimeout(() => { setIsRegenerating(false); setRegenProgress(''); }, 3000);
    }
  }, [opportunityId, queryClient]);
  
  // Get unique competitor names from insights + all sources
  const competitorNames = useMemo(() => {
    const fromInsights = (insights || []).map(i => i.competitorName);
    const fromAllSources = allCompetitorNames || [];
    return [...new Set([...fromInsights, ...fromAllSources])];
  }, [insights, allCompetitorNames]);
  
  const { data: battlecardData } = useCompetitiveAnalysis(competitorNames);
  
  // Group insights
  const { objections, competitorMentions, winLossSignals } = useMemo(() => {
    if (!insights) return { objections: [], competitorMentions: [], winLossSignals: [] };
    
    return {
      objections: insights.filter(i => i.isObjection),
      competitorMentions: insights.filter(i => !i.isObjection && !i.winSignal && !i.lossSignal),
      winLossSignals: insights.filter(i => i.winSignal || i.lossSignal),
    };
  }, [insights]);
  
  // Group plays by strategy
  const { activePlays, attackPlays, defendPlays } = useMemo(() => {
    const active = (plays || []).filter(p => p.status !== 'dismissed');
    return {
      activePlays: active,
      attackPlays: active.filter(p => p.playStrategy === 'attack'),
      defendPlays: active.filter(p => p.playStrategy === 'defend'),
    };
  }, [plays]);
  
  if (loadingInsights || loadingThreat) {
    return (
      <div className="space-y-4 p-4">
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }
  
  const hasData = (insights?.length || 0) > 0 || competitorNames.length > 0;
  
  return (
    <div className="space-y-6 p-4">
      {/* Threat Assessment */}
      {threatAssessment && (
        <ThreatMeter 
          threatLevel={threatAssessment.threatLevel}
          threatScore={threatAssessment.threatScore}
          competitorNames={competitorNames}
        />
      )}
      
      {/* Quick Stats */}
      {hasData && threatAssessment && (
        <div className="grid grid-cols-4 gap-3">
          <Card className="p-3 text-center">
            <div className="text-2xl font-bold">{threatAssessment.competitorCount}</div>
            <div className="text-xs text-muted-foreground">Competitors</div>
          </Card>
          <Card className="p-3 text-center">
            <div className="text-2xl font-bold text-amber-600">{threatAssessment.objectionCount}</div>
            <div className="text-xs text-muted-foreground">Objections</div>
          </Card>
          <Card className="p-3 text-center">
            <div className="text-2xl font-bold text-green-600">{threatAssessment.winSignals}</div>
            <div className="text-xs text-muted-foreground">Win Signals</div>
          </Card>
          <Card className="p-3 text-center">
            <div className="text-2xl font-bold text-red-600">{threatAssessment.lossSignals}</div>
            <div className="text-xs text-muted-foreground">Loss Signals</div>
          </Card>
        </div>
      )}
      
      {/* Regeneration progress banner */}
      {isRegenerating && regenProgress && (
        <Card className="p-3 border-primary/30 bg-primary/5">
          <div className="flex items-center gap-2 text-sm">
            <Loader2 className="w-4 h-4 animate-spin text-primary" />
            <span className="text-foreground">{regenProgress}</span>
          </div>
        </Card>
      )}

      {!hasData ? (
        <Card className="p-8 text-center">
          <Swords className="w-12 h-12 mx-auto text-muted-foreground/50 mb-3" />
          <h3 className="font-medium text-lg mb-1">No Competitive Intelligence Yet</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Competitive insights will be extracted automatically when transcripts are analyzed.
          </p>
          <Button 
            onClick={handleRegenerate} 
            disabled={isRegenerating}
            variant="outline"
            className="gap-2"
          >
            {isRegenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            Generate Competitive Intelligence
          </Button>
        </Card>
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="flex items-center gap-2">
            <TabsList className="grid flex-1 grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="scorecard">
                <BarChart3 className="w-3 h-3 mr-1" />
                Scorecard
              </TabsTrigger>
              <TabsTrigger value="objections">
                Objections ({objections.length})
              </TabsTrigger>
              <TabsTrigger value="mentions">
                Mentions ({competitorMentions.length})
              </TabsTrigger>
            </TabsList>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRegenerate}
              disabled={isRegenerating}
              className="gap-1.5 shrink-0"
            >
              {isRegenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
              Regenerate
            </Button>
          </div>
          
          <TabsContent value="overview" className="mt-4 space-y-6">
            {/* Group plays and scorecard intel by competitor */}
            {competitorNames.map(competitor => {
              const compLower = competitor.toLowerCase();
              const compPlaysAttack = attackPlays.filter(p => 
                p.competitorName?.toLowerCase() === compLower ||
                p.playTitle?.toLowerCase().includes(compLower)
              );
              const compPlaysDefend = defendPlays.filter(p => 
                p.competitorName?.toLowerCase() === compLower ||
                p.playTitle?.toLowerCase().includes(compLower)
              );
              
              // Get scorecard strengths/threats for this competitor
              const compStrengths = battlecardData?.strengths.filter(
                s => s.competitorName.toLowerCase() === competitor.toLowerCase()
              ) || [];
              const compThreats = battlecardData?.threats.filter(
                t => t.competitorName.toLowerCase() === competitor.toLowerCase()
              ) || [];
              
              const hasPlays = compPlaysAttack.length > 0 || compPlaysDefend.length > 0;
              const hasScorecard = compStrengths.length > 0 || compThreats.length > 0;
              
              if (!hasPlays && !hasScorecard) return null;
              
              return (
                <Card key={competitor} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Swords className="w-4 h-4" />
                      vs {competitor}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Attack Plays */}
                    {compPlaysAttack.length > 0 && (
                      <div>
                        <h4 className="text-sm font-semibold mb-2 flex items-center gap-1.5 text-green-700">
                          <TrendingUp className="w-3.5 h-3.5" />
                          Attack — Leverage Pendo Strengths ({compPlaysAttack.length})
                        </h4>
                        <div className="grid gap-2 md:grid-cols-2">
                          {compPlaysAttack.map(play => (
                            <PlayCard 
                              key={play.id} 
                              play={play}
                              useCases={useCases}
                              onStatusChange={(status) => updatePlayStatus.mutate({ playId: play.id, status })}
                            />
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Scorecard Advantages */}
                    {compStrengths.length > 0 && (
                      <div className="border-t pt-3">
                        <p className="text-xs font-medium text-green-600 mb-2 flex items-center gap-1">
                          <TrendingUp className="w-3 h-3" />
                          Scorecard Advantages ({compStrengths.length})
                        </p>
                        <div className="grid gap-1.5 md:grid-cols-2">
                          {compStrengths.slice(0, 6).map((s, idx) => (
                            <div key={idx} className="flex items-center gap-2 text-xs p-1.5 rounded bg-green-50/50">
                              <CheckCircle className="w-3 h-3 text-green-500 shrink-0" />
                              <span className="font-medium truncate">{s.featureName}</span>
                              <Badge variant="outline" className="text-xs text-green-600 shrink-0 ml-auto">
                                Pendo {s.pendoScore} vs {s.competitorScore}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Defend Plays */}
                    {compPlaysDefend.length > 0 && (
                      <div className="border-t pt-3">
                        <h4 className="text-sm font-semibold mb-2 flex items-center gap-1.5 text-amber-700">
                          <Shield className="w-3.5 h-3.5" />
                          Defend — Build a Moat ({compPlaysDefend.length})
                        </h4>
                        <div className="grid gap-2 md:grid-cols-2">
                          {compPlaysDefend.map(play => (
                            <PlayCard 
                              key={play.id} 
                              play={play}
                              useCases={useCases}
                              onStatusChange={(status) => updatePlayStatus.mutate({ playId: play.id, status })}
                            />
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Scorecard Gaps */}
                    {compThreats.length > 0 && (
                      <div className="border-t pt-3">
                        <p className="text-xs font-medium text-amber-600 mb-2 flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          Areas to Address ({compThreats.length})
                        </p>
                        <div className="grid gap-1.5 md:grid-cols-2">
                          {compThreats.slice(0, 6).map((t, idx) => (
                            <div key={idx} className="flex items-center gap-2 text-xs p-1.5 rounded bg-amber-50/50">
                              <XCircle className="w-3 h-3 text-amber-500 shrink-0" />
                              <span className="font-medium truncate">{t.featureName}</span>
                              <Badge variant="outline" className="text-xs text-amber-600 shrink-0 ml-auto">
                                Pendo {t.pendoScore} vs {t.competitorScore}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
            
            {/* Unmatched plays (competitor_name from plays that don't match competitorNames) */}
            {(() => {
              const compLowers = new Set(competitorNames.map(n => n.toLowerCase()));
              
              // Build set of play IDs already shown in per-competitor sections
              const shownPlayIds = new Set<string>();
              activePlays.forEach(p => {
                const pCompName = p.competitorName?.toLowerCase();
                const titleMatch = competitorNames.some(c => p.playTitle?.toLowerCase().includes(c.toLowerCase()));
                if ((pCompName && compLowers.has(pCompName)) || titleMatch) {
                  shownPlayIds.add(p.id);
                }
              });
              
              const generalPlays = activePlays.filter(p => !shownPlayIds.has(p.id));
              
              if (generalPlays.length === 0) return null;
              
              return (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Lightbulb className="w-4 h-4" />
                      General Competitive Plays
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-2 md:grid-cols-2">
                      {generalPlays.map(play => (
                        <PlayCard 
                          key={play.id} 
                          play={play}
                          useCases={useCases}
                          onStatusChange={(status) => updatePlayStatus.mutate({ playId: play.id, status })}
                        />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })()}
            
            {/* High Severity Objections */}
            {objections.filter(o => o.objectionSeverity === 'high').length > 0 && (
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                  Critical Objections
                </h3>
                <div className="space-y-2">
                  {objections.filter(o => o.objectionSeverity === 'high').map(obj => (
                    <ObjectionCard key={obj.id} insight={obj} />
                  ))}
                </div>
              </div>
            )}

            {/* Landmine Questions */}
            {(() => {
              const landmines = activePlays.filter(p => p.playType === 'landmine');
              if (landmines.length === 0) return null;
              return (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Target className="w-4 h-4 text-red-600" />
                      Landmine Questions ({landmines.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground mb-3">
                      Proactive questions to ask that expose competitor weaknesses
                    </p>
                    <div className="space-y-2">
                      {landmines.map((lm, idx) => (
                        <div key={lm.id} className="flex items-start gap-3 p-3 rounded-lg border bg-red-50/30 border-red-200/50">
                          <span className="text-sm font-bold text-red-600 mt-0.5 shrink-0">{idx + 1}.</span>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{lm.playTitle}</p>
                            {lm.playDescription && (
                              <p className="text-xs text-muted-foreground mt-1">{lm.playDescription}</p>
                            )}
                            {lm.competitorName && (
                              <Badge variant="outline" className="text-xs mt-1.5">
                                vs {lm.competitorName}
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })()}

            {/* Gaps & Mitigations */}
            {(() => {
              const gaps = defendPlays.filter(p => p.playType === 'differentiation' || p.playType === 'feature_highlight');
              if (gaps.length === 0) return null;
              return (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Shield className="w-4 h-4 text-amber-600" />
                      Gaps & Mitigations ({gaps.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {gaps.map(gap => (
                        <div key={gap.id} className="border rounded-lg p-3 border-l-4 border-l-amber-400 bg-amber-50/30">
                          <p className="text-sm font-medium">{gap.playTitle}</p>
                          {gap.playDescription && (
                            <p className="text-xs text-muted-foreground mt-1">{gap.playDescription}</p>
                          )}
                          {(gap.talkingPoints ?? []).length > 0 && (
                            <div className="mt-2 pt-2 border-t">
                              <p className="text-xs font-medium text-amber-700 mb-1">Mitigations:</p>
                              <ul className="space-y-1">
                                {(gap.talkingPoints ?? []).map((point, idx) => (
                                  <li key={idx} className="text-xs flex items-start gap-1">
                                    <ChevronRight className="w-3 h-3 mt-0.5 text-amber-500" />
                                    <span>{point}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })()}
            
            {activePlays.length === 0 && !battlecardData?.strengths.length && !battlecardData?.threats.length && (
              <Card className="p-6 text-center">
                <Target className="w-8 h-8 mx-auto text-muted-foreground/50 mb-2" />
                <p className="text-sm text-muted-foreground">No competitive plays or scorecard intelligence available yet. Try regenerating.</p>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="scorecard" className="mt-4">
            <ScorecardComparison 
              competitorNames={competitorNames}
              opportunityId={opportunityId}
            />
          </TabsContent>
          
          <TabsContent value="objections" className="mt-4">
            {objections.length === 0 ? (
              <Card className="p-6 text-center">
                <Shield className="w-8 h-8 mx-auto text-muted-foreground/50 mb-2" />
                <p className="text-sm text-muted-foreground">No objections detected</p>
              </Card>
            ) : (
              <div className="space-y-3">
                {objections.map(obj => (
                  <ObjectionCard key={obj.id} insight={obj} />
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="mentions" className="mt-4">
            {competitorMentions.length === 0 ? (
              <Card className="p-6 text-center">
                <MessageSquare className="w-8 h-8 mx-auto text-muted-foreground/50 mb-2" />
                <p className="text-sm text-muted-foreground">No competitor mentions detected</p>
              </Card>
            ) : (
              <div className="space-y-3">
                {competitorMentions.map(mention => (
                  <CompetitorMentionCard key={mention.id} insight={mention} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}

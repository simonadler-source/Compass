import React, { useState, useMemo, useEffect, useRef } from 'react';
import { ArrowLeft, Target, CheckCircle2, Clock, AlertCircle, Settings2, ClipboardList, Calendar, ChevronRight, Sparkles, FileText, Users, AlertTriangle, Edit2, Save, X, Link2, User, Lightbulb, BarChart3, Zap, Info, Activity, History, Trash2, Plus, ExternalLink, Swords, CalendarRange, FlaskConical, Loader2, RotateCcw } from 'lucide-react';
import { SalesforceIcon } from '@/components/icons/SalesforceIcon';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { 
  useDeploymentTypes,
  useOpportunityDeploymentTypes,
  useToggleOpportunityDeploymentType,
  useMilestoneTemplates,
  useOpportunityMilestones,
  useInitializeMilestones,
  useOpportunityReadinessAnswers,
  useReadinessTemplates,
  calculateReadinessScore,
  ReadinessQuestion,
  DetectedDeploymentType,
  useOpportunityValidationTasks,
  useValidationTaskTemplates,
  shouldShowSubQuestion,
  isFlagDisabled,
  getFlagType,
} from '@/hooks/useOpportunityReadiness';
import { useUpdateOpportunity, useDeleteOpportunity } from '@/hooks/useAccounts';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useAssignableOpportunityUsers } from '@/hooks/useAssignableOpportunityUsers';
import { useOpportunityActivities } from '@/hooks/useOpportunityActivities';
import { useOpportunitySignals } from '@/hooks/useOpportunitySignals';
import { OpportunityTranscriptsTab } from './OpportunityTranscriptsTab';
import { OpportunityTeamTab } from './OpportunityTeamTab';
import { OpportunityTechnicalTab } from './OpportunityTechnicalTab';
import { OpportunityUseCasesTab } from './OpportunityUseCasesTab';
import { OpportunityNBAsTab } from './OpportunityNBAsTab';
import { OpportunityInsightsTab } from './OpportunityInsightsTab';
import { OpportunityCompetitiveTab } from './OpportunityCompetitiveTab';
import { OpportunityStakeholdersTab } from './OpportunityStakeholdersTab';
import { PriorityRadar } from './PriorityRadar';
import { OpportunityHistoryTab } from './OpportunityHistoryTab';
import { ActivityTimeline } from '@/components/ActivityTimeline';
import { ActivityKPICards } from '@/components/ActivityKPICards';
import { AddActivityDialog } from '@/components/dialogs/AddActivityDialog';
import { IncludedModulesSelector } from '@/components/IncludedModulesSelector';
import { DocumentsPanel } from '@/components/documents/DocumentsPanel';
import { Skeleton } from '@/components/ui/skeleton';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useOpportunitySEUpdate, useUpsertSEUpdate } from '@/hooks/useOpportunitySEUpdates';
import { supabase } from '@/integrations/supabase/client';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';
import { Account } from '@/types/architecture';
import { useRecentItems } from '@/hooks/useRecentItems';
import { getOpportunityUrl } from '@/lib/appUrl';
import { ShareOpportunityDigestDialog } from '@/components/dialogs/ShareOpportunityDigestDialog';
import { LinkSlackChannelDialog } from '@/components/dialogs/LinkSlackChannelDialog';
import { ImportFromOpportunityDialog } from '@/components/dialogs/ImportFromOpportunityDialog';
import { useAuth } from '@/contexts/AuthContext';

interface OpportunityDetailViewProps {
  opportunity: {
    id: string;
    name: string;
    description: string | null;
    value: number | null;
    stage: string | null;
    priority: string | null;
    close_date: string | null;
    account_id: string;
  };
  accountName: string;
  onBack: () => void;
  initialTab?: string;
  onTabChange?: (tab: string) => void;
}

const stageColors: Record<string, string> = {
  stage_0: 'bg-muted text-muted-foreground',
  stage_1: 'bg-layer-host-muted text-layer-host',
  stage_2: 'bg-layer-build-muted text-layer-build',
  stage_3: 'bg-layer-adopt-muted text-layer-adopt',
  stage_4: 'bg-layer-growth-muted text-layer-growth',
  stage_5_sales_won: 'bg-primary/20 text-primary',
  stage_6_closed_won: 'bg-primary/20 text-primary',
};

const deploymentTypeIcons: Record<string, string> = {
  snippet: '🔧',
  extension: '🧩',
  mobile: '📱',
  adopt: '🎯',
};

const deploymentTypeLabels: Record<string, string> = {
  snippet: 'Web SDK / Snippet',
  extension: 'Browser Extension (P4E)',
  mobile: 'Mobile SDK (iOS/Android)',
  adopt: 'Pendo Adopt',
};

const stageOptions = [
  { value: 'stage_0', label: 'Stage 0: Qualification' },
  { value: 'stage_1', label: 'Stage 1: Discovery' },
  { value: 'stage_2', label: 'Stage 2: Solution' },
  { value: 'stage_3', label: 'Stage 3: Proof' },
  { value: 'stage_4', label: 'Stage 4: Negotiate' },
  { value: 'stage_5_sales_won', label: 'Stage 5: Sales Won' },
  { value: 'stage_6_closed_won', label: 'Stage 6: Closed Won' },
  { value: 'stage_7_closed_lost', label: 'Stage 7: Closed Lost' },
];

const preSalesStageOptions = [
  { value: 'Discovery', label: 'Discovery' },
  { value: 'Demo', label: 'Demo' },
  { value: 'Proof - Scoping', label: 'Proof - Scoping' },
  { value: 'Proof', label: 'Proof' },
  { value: 'Technical Win', label: 'Technical Win' },
  { value: 'Technical Loss', label: 'Technical Loss' },
  { value: 'Unqualified', label: 'Unqualified' },
];

const priorityOptions = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
  { value: 'critical', label: 'Critical' },
];

function EvalRadarToggle({ opportunityId, evalPhaseOverride, milestones, preSalesStage }: {
  opportunityId: string;
  evalPhaseOverride: string | null | undefined;
  milestones: any[] | undefined;
  preSalesStage: string | null | undefined;
}) {
  const queryClient = useQueryClient();
  const isOnRadar = !!evalPhaseOverride;

  const inferPhase = () => {
    if (milestones && milestones.length > 0) {
      const completedCount = milestones.filter((m: any) => m.status === 'completed' || m.completed_date).length;
      const scheduledCount = milestones.filter((m: any) => m.scheduled_date).length;
      if (completedCount > 0) return 'running';
      if (scheduledCount > 0) return 'planning';
    }
    const ps = preSalesStage?.toLowerCase();
    if (ps && ['proof - scoping', 'proof', 'technical win'].includes(ps)) return 'running';
    if (ps === 'demo') return 'planning';
    return 'planning';
  };

  const handleToggle = async () => {
    if (isOnRadar) {
      const { error } = await supabase.from('opportunities').update({ eval_phase_override: null, eval_radar_dismissed: true } as any).eq('id', opportunityId);
      if (error) { toast.error('Failed to remove from Eval Radar'); return; }
      toast.success('Removed from Eval Radar');
    } else {
      const phase = inferPhase();
      const { error } = await supabase.from('opportunities').update({ eval_phase_override: phase, eval_radar_dismissed: false } as any).eq('id', opportunityId);
      if (error) { toast.error('Failed to add to Eval Radar'); return; }
      toast.success(`Added to Eval Radar (${phase.charAt(0).toUpperCase() + phase.slice(1)})`);
    }
    queryClient.invalidateQueries({ queryKey: ['opportunity-full', opportunityId] });
    queryClient.invalidateQueries({ queryKey: ['evaluation-radar-opps-overrides'] });
    queryClient.invalidateQueries({ queryKey: ['evaluation-radar-opps-team'] });
  };

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant={isOnRadar ? 'secondary' : 'ghost'}
          size="icon"
          className={isOnRadar ? 'text-emerald-600' : 'text-muted-foreground'}
          onClick={handleToggle}
        >
          <FlaskConical className="w-4 h-4" />
        </Button>
      </TooltipTrigger>
      <TooltipContent>
        <p className="text-xs">{isOnRadar ? 'Remove from Eval Radar' : 'Add to Eval Radar'}</p>
      </TooltipContent>
    </Tooltip>
  );
}

export function OpportunityDetailView({ opportunity, accountName, onBack, initialTab, onTabChange }: OpportunityDetailViewProps) {
  const { toast: toastHook } = useToast();
  const { data: assignable } = useAssignableOpportunityUsers(opportunity.account_id, opportunity.id);
  const allAssignableUsers = assignable?.allUsers || [];
  const seUsers = assignable?.seUsers || [];
  const aeUsers = assignable?.aeUsers || [];
  const [activeTab, setActiveTab] = useState(initialTab || 'overview');
  const [isEditingDetails, setIsEditingDetails] = useState(false);
  const { addRecentItem } = useRecentItems();

  // Handle tab changes - update local state and notify parent
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    onTabChange?.(tab);
  };
  
  // Track this opportunity as recently viewed (include current tab in path)
  // Guard: only record when accountName actually belongs to this opportunity's account
  // to avoid stale data from a previously viewed account during navigation
  const accountNameMatchesRef = useRef(false);
  useEffect(() => {
    // On first render or account change, mark as matched once accountName is truthy
    // We verify by checking the name isn't from a stale render
    accountNameMatchesRef.current = !!accountName;
  }, [accountName, opportunity.account_id]);

  useEffect(() => {
    if (!accountName || !accountNameMatchesRef.current) return;
    addRecentItem({
      id: opportunity.id,
      type: 'opportunity',
      name: `${accountName} - ${opportunity.name}`,
      path: `/accounts/${opportunity.account_id}?opportunityId=${opportunity.id}${activeTab !== 'overview' ? `&oppTab=${activeTab}` : ''}`,
    });
  }, [opportunity.id, opportunity.name, opportunity.account_id, accountName, activeTab, addRecentItem]);
  
  // Form state for opportunity details
  const [formData, setFormData] = useState({
    name: opportunity.name,
    description: opportunity.description || '',
    value: opportunity.value?.toString() || '',
    stage: opportunity.stage || 'stage_0',
    pre_sales_stage: '',
    priority: opportunity.priority || 'medium',
    close_date: opportunity.close_date || '',
    owner_email: '',
    primary_se_email: '',
    salesforce_opportunity_id: '',
    included_module_ids: [] as string[],
    mau_count: '',
    primary_eval_quote: '',
    eval_start_date: '',
    eval_end_date: '',
    eval_type: '',
  });
  
  const updateOpportunity = useUpdateOpportunity();
  const deleteOpportunity = useDeleteOpportunity();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  const handleDeleteOpportunity = async () => {
    try {
      await deleteOpportunity.mutateAsync({ id: opportunity.id, accountId: opportunity.account_id });
      setShowDeleteConfirm(false);
      onBack();
    } catch (error) {
      // Error is handled by the mutation's onError
    }
  };

  // Fetch full opportunity data including owner_email and salesforce fields
  const { data: fullOpportunity } = useQuery({
    queryKey: ['opportunity-full', opportunity.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('opportunities')
        .select('*')
        .eq('id', opportunity.id)
        .single();
      if (error) throw error;
      return data;
    },
  });
  
  // Fetch pre-sales stage assessment from the latest transcript
  const { data: preSalesAssessment } = useQuery({
    queryKey: ['opportunity-presales-assessment', opportunity.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transcript_reviews')
        .select('extracted_insights, last_analyzed_at, meeting_title')
        .eq('opportunity_id', opportunity.id)
        .not('extracted_insights', 'is', null)
        .order('last_analyzed_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (error) throw error;
      if (!data?.extracted_insights) return null;
      
      const insights = data.extracted_insights as any;
      if (!insights.preSalesStageAssessment) return null;
      
      return {
        ...insights.preSalesStageAssessment,
        meetingTitle: data.meeting_title,
        analyzedAt: data.last_analyzed_at,
      };
    },
    enabled: !!fullOpportunity?.pre_sales_stage,
  });
  
  // Fetch last detection stages for this opportunity
  const { data: lastDetectionInfo } = useQuery({
    queryKey: ['opportunity-last-detection', opportunity.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('detection_rule_matches')
        .select('crm_stage_at_detection, pre_sales_stage_at_detection, created_at')
        .eq('opportunity_id', opportunity.id)
        .not('crm_stage_at_detection', 'is', null)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
  });
  
  // Calculate inferred/detected stage from detection_signal_fields
  const detectedStageInfo = useMemo(() => {
    const signalFields = fullOpportunity?.detection_signal_fields as Record<string, any> | null;
    if (!signalFields) return null;
    
    // Priority order: technical_win > legal/security > evaluation > demo
    const hasLegal = !!signalFields.legal;
    const hasSecurity = !!signalFields.security;
    const hasEvaluation = !!signalFields.evaluation_poc;
    const hasTechnicalWin = !!signalFields.technical_win;
    const hasDemo = !!signalFields.demo_request;
    const hasPricing = !!signalFields.pricing;
    
    let inferredStage: number | null = null;
    let inferredPreSalesStage: string | null = null;
    let latestSignal: { name: string; date: string } | null = null;
    
    // Find latest signal for display
    let latestDate: Date | null = null;
    Object.entries(signalFields).forEach(([key, value]) => {
      if (value?.detected_at) {
        const signalDate = new Date(value.detected_at);
        if (!latestDate || signalDate > latestDate) {
          latestDate = signalDate;
          latestSignal = { 
            name: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()), 
            date: signalDate.toLocaleDateString() 
          };
        }
      }
    });
    
    // Infer CRM stage based on signals (same logic as useCEPOpportunities)
    if (hasTechnicalWin) inferredStage = 4; // Technical Win suggests Stage 4+
    else if (hasLegal || hasSecurity || hasPricing) inferredStage = 4;
    else if (hasEvaluation) inferredStage = 3;
    else if (hasDemo) inferredStage = 1;
    
    // Infer Pre-Sales stage
    if (hasTechnicalWin) inferredPreSalesStage = 'Technical Win';
    else if (hasEvaluation) inferredPreSalesStage = 'Proof';
    else if (hasDemo) inferredPreSalesStage = 'Demo';
    
    return { inferredStage, inferredPreSalesStage, latestSignal };
  }, [fullOpportunity?.detection_signal_fields]);



  // Update form data when full opportunity loads
  useEffect(() => {
    if (fullOpportunity) {
      setFormData({
        name: fullOpportunity.name,
        description: fullOpportunity.description || '',
        value: fullOpportunity.value?.toString() || '',
        stage: fullOpportunity.sales_stage || fullOpportunity.stage || 'stage_0',
        pre_sales_stage: fullOpportunity.pre_sales_stage || '',
        priority: fullOpportunity.priority || 'medium',
        close_date: fullOpportunity.close_date || '',
        owner_email: fullOpportunity.owner_email || '',
        primary_se_email: fullOpportunity.primary_se_email || '',
        salesforce_opportunity_id: fullOpportunity.salesforce_opportunity_id || '',
        included_module_ids: (fullOpportunity as any).included_module_ids || [],
        mau_count: (fullOpportunity as any).mau_count?.toString() || '',
        primary_eval_quote: (fullOpportunity as any).primary_eval_quote || '',
        eval_start_date: (fullOpportunity as any).eval_start_date || '',
        eval_end_date: (fullOpportunity as any).eval_end_date || '',
        eval_type: (fullOpportunity as any).eval_type || '',
      });
    }
  }, [fullOpportunity]);
  
  const handleSaveDetails = async () => {
    try {
      await updateOpportunity.mutateAsync({
        id: opportunity.id,
        name: formData.name,
        description: formData.description || null,
        value: formData.value ? parseFloat(formData.value) : null,
        sales_stage: formData.stage,
        pre_sales_stage: formData.pre_sales_stage || null,
        priority: formData.priority,
        close_date: formData.close_date || null,
        owner_email: formData.owner_email || null,
        primary_se_email: formData.primary_se_email || null,
        salesforce_opportunity_id: formData.salesforce_opportunity_id || null,
        included_module_ids: formData.included_module_ids,
        mau_count: formData.mau_count ? parseInt(formData.mau_count, 10) : null,
        primary_eval_quote: formData.primary_eval_quote || null,
        eval_start_date: formData.eval_start_date || null,
        eval_end_date: formData.eval_end_date || null,
        eval_type: formData.eval_type || null,
      } as any);
      setIsEditingDetails(false);
      toast.success('Opportunity updated successfully');
    } catch (error) {
      toast.error('Failed to update opportunity');
    }
  };
  
  const handleCancelEdit = () => {
    setFormData({
      name: fullOpportunity?.name || opportunity.name,
      description: fullOpportunity?.description || opportunity.description || '',
      value: (fullOpportunity?.value || opportunity.value)?.toString() || '',
      stage: fullOpportunity?.stage || opportunity.stage || 'stage_0',
      pre_sales_stage: fullOpportunity?.pre_sales_stage || '',
      priority: fullOpportunity?.priority || opportunity.priority || 'medium',
      close_date: fullOpportunity?.close_date || opportunity.close_date || '',
      owner_email: fullOpportunity?.owner_email || '',
      primary_se_email: fullOpportunity?.primary_se_email || '',
      salesforce_opportunity_id: fullOpportunity?.salesforce_opportunity_id || '',
      included_module_ids: fullOpportunity?.included_module_ids || [],
      mau_count: (fullOpportunity as any)?.mau_count?.toString() || '',
      primary_eval_quote: (fullOpportunity as any)?.primary_eval_quote || '',
      eval_start_date: (fullOpportunity as any)?.eval_start_date || '',
      eval_end_date: (fullOpportunity as any)?.eval_end_date || '',
      eval_type: (fullOpportunity as any)?.eval_type || '',
    });
    setIsEditingDetails(false);
  };
  
  const { data: allDeploymentTypes, isLoading: loadingTypes } = useDeploymentTypes();
  const { data: opportunityDeployments, isLoading: loadingOpportunityTypes } = useOpportunityDeploymentTypes(opportunity.id);
  const toggleDeploymentType = useToggleOpportunityDeploymentType();
  
  const { data: milestoneTemplates } = useMilestoneTemplates();
  const { data: milestones } = useOpportunityMilestones(opportunity.id);
  const initializeMilestones = useInitializeMilestones();
  
  // Get enabled deployment type IDs
  const enabledDeploymentTypeIds = useMemo(() => {
    return opportunityDeployments?.map(d => d.deployment_type_id) || [];
  }, [opportunityDeployments]);
  
  // Fetch readiness data
  const { data: readinessTemplates } = useReadinessTemplates(enabledDeploymentTypeIds);
  const { data: readinessAnswers } = useOpportunityReadinessAnswers(opportunity.id);
  
  // Fetch transcript count for badge
  const { data: transcriptCount } = useQuery({
    queryKey: ['opportunity-transcripts-count', opportunity.id],
    queryFn: async () => {
      const { count, error } = await supabase
        .from('transcript_reviews')
        .select('*', { count: 'exact', head: true })
        .eq('opportunity_id', opportunity.id);
      if (error) throw error;
      return count || 0;
    },
  });
  
  // Fetch NBA stats for badge
  const { data: opportunityNBAs } = useQuery({
    queryKey: ['opportunity-nbas-stats', opportunity.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('account_nbas')
        .select('id, status, priority')
        .eq('opportunity_id', opportunity.id);
      if (error) throw error;
      return data || [];
    },
  });
  
  const nbaStats = useMemo(() => {
    if (!opportunityNBAs) return { total: 0, pending: 0, high: 0 };
    return {
      total: opportunityNBAs.length,
      pending: opportunityNBAs.filter(n => n.status !== 'completed').length,
      high: opportunityNBAs.filter(n => n.priority === 'high' && n.status !== 'completed').length,
    };
  }, [opportunityNBAs]);
  
  // Calculate readiness score - must match TechnicalReadinessTab logic
  // Excludes sub-questions hidden by trigger conditions and "not relevant" questions
  const readinessScore = useMemo(() => {
    if (!readinessTemplates || !readinessAnswers) {
      return { answered: 0, total: 0, activeTotal: 0, percentage: 0, gaps: 0, greenCount: 0, amberCount: 0, redCount: 0, disabledCount: 0 };
    }

    const answerMap = new Map<string, any>();
    readinessAnswers.forEach((a: any) => answerMap.set(a.question_id, a));

    let totalVisible = 0, answered = 0;
    let greenCount = 0, amberCount = 0, redCount = 0, disabledCount = 0;

    const processQuestion = (q: ReadinessQuestion, parentAnswer?: any) => {
      // Skip sub-questions whose trigger condition is not met
      if (q.trigger_condition && parentAnswer !== undefined) {
        const parentAnswerText = parentAnswer?.answer || null;
        if (!shouldShowSubQuestion(parentAnswerText, q.trigger_condition)) {
          return;
        }
      }

      const answer = answerMap.get(q.id);
      const hasAnswer = answer?.answer || answer?.answer_json;
      totalVisible++;

      if (isFlagDisabled(answer)) {
        disabledCount++;
      } else {
        if (hasAnswer) answered++;
        const flagType = getFlagType(answer);
        if (flagType === 'green') greenCount++;
        else if (flagType === 'amber') amberCount++;
        else redCount++;
      }

      if (q.children) {
        q.children.forEach((child: ReadinessQuestion) => processQuestion(child, answer));
      }
    };

    readinessTemplates.forEach((cat: any) => {
      (cat.questions || []).forEach((q: ReadinessQuestion) => processQuestion(q));
    });

    const activeTotal = totalVisible - disabledCount;
    const weightedDenominator = (redCount * 2) + (amberCount * 1.5) + (greenCount * 1);
    let percentage = 0;
    if (weightedDenominator > 0) {
      percentage = Math.round((greenCount * 100 + amberCount * 50) / weightedDenominator);
    }

    return {
      answered,
      total: totalVisible,
      activeTotal,
      percentage: Math.max(0, Math.min(100, percentage)),
      gaps: activeTotal - answered,
      greenCount, amberCount, redCount, disabledCount,
    };
  }, [readinessTemplates, readinessAnswers]);
  
  // Fetch validation tasks
  const { data: validationTasks } = useOpportunityValidationTasks(opportunity.id);
  const { data: validationTemplates } = useValidationTaskTemplates(enabledDeploymentTypeIds);
  
  // Calculate validation task progress
  const validationProgress = useMemo(() => {
    if (!validationTasks || validationTasks.length === 0) {
      // Check if there are templates that could be initialized
      const templateCount = validationTemplates?.length || 0;
      return { 
        completed: 0, 
        total: templateCount, 
        percentage: 0, 
        notStarted: templateCount, 
        inProgress: 0,
        blocked: 0,
        needsInitialization: templateCount > 0
      };
    }
    const completed = validationTasks.filter(t => t.status === 'completed').length;
    const notStarted = validationTasks.filter(t => t.status === 'not_started').length;
    const inProgress = validationTasks.filter(t => t.status === 'in_progress').length;
    const blocked = validationTasks.filter(t => t.status === 'blocked').length;
    return {
      completed,
      total: validationTasks.length,
      percentage: Math.round((completed / validationTasks.length) * 100),
      notStarted,
      inProgress,
      blocked,
      needsInitialization: false
    };
  }, [validationTasks, validationTemplates]);
  
  // Calculate milestone progress
  const milestoneProgress = useMemo(() => {
    if (!milestones || milestones.length === 0) return { completed: 0, total: 0, percentage: 0 };
    const completed = milestones.filter(m => m.status === 'completed').length;
    return {
      completed,
      total: milestones.length,
      percentage: Math.round((completed / milestones.length) * 100),
    };
  }, [milestones]);
  
  const handleToggleDeploymentType = async (deploymentTypeId: string, currentlyEnabled: boolean) => {
    await toggleDeploymentType.mutateAsync({
      opportunityId: opportunity.id,
      deploymentTypeId,
      enabled: !currentlyEnabled,
    });
  };
  
  const handleInitializeMilestones = async () => {
    if (milestoneTemplates && milestoneTemplates.length > 0) {
      await initializeMilestones.mutateAsync({
        opportunityId: opportunity.id,
        templates: milestoneTemplates,
      });
    }
  };
  
  const queryClient = useQueryClient();
  
  const handleDeploymentTypesDetected = (detectedTypes: DetectedDeploymentType[]) => {
    // The edge function already persists detected deployment types to opportunity_deployment_types.
    // We just need to invalidate the query so the UI refreshes, and show a toast.
    queryClient.invalidateQueries({ queryKey: ['opportunity-deployment-types', opportunity.id] });
    queryClient.invalidateQueries({ queryKey: ['readiness-templates'] });
    queryClient.invalidateQueries({ queryKey: ['opportunity-readiness', opportunity.id] });
    
    const typeLabels = detectedTypes.map(dt => deploymentTypeLabels[dt.type] || dt.type);
    
    toastHook({
      title: (
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4" />
          <span>Deployment Types Auto-Detected</span>
        </div>
      ) as any,
      description: (
        <div className="space-y-2 mt-2">
          {detectedTypes.map((dt, i) => (
            <div key={i} className="text-sm">
              <span className="font-medium">{deploymentTypeLabels[dt.type] || dt.type}</span>
              <span className="text-muted-foreground ml-2">({dt.confidence}% confidence)</span>
              <p className="text-xs text-muted-foreground mt-0.5">{dt.reasoning}</p>
            </div>
          ))}
        </div>
      ) as any,
      duration: 8000,
    });
  };
  
  if (loadingTypes || loadingOpportunityTypes) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-12 w-64" />
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <span>{accountName}</span>
              <ChevronRight className="w-4 h-4" />
              <span>Opportunity</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Target className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold text-foreground">{opportunity.name}</h1>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => {
                          const url = getOpportunityUrl(opportunity.id);
                          navigator.clipboard.writeText(url);
                          toast.success('Link copied to clipboard');
                        }}
                      >
                        <Link2 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Copy direct link</TooltipContent>
                  </Tooltip>
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  {opportunity.value && (
                    <span className="text-sm text-muted-foreground">
                      ${opportunity.value.toLocaleString()}
                    </span>
                  )}
                  {opportunity.stage && (
                    <Badge className={cn(stageColors[opportunity.stage] || 'bg-muted')}>
                      {opportunity.stage.replace(/_/g, ' ')}
                    </Badge>
                  )}
                  {fullOpportunity?.pre_sales_stage && (
                    <Badge variant="outline" className="bg-layer-adopt-muted text-layer-adopt border-layer-adopt/30">
                      SE: {fullOpportunity.pre_sales_stage}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Link Slack Channel */}
          <LinkSlackChannelDialog opportunityId={opportunity.id} accountId={opportunity.account_id} purpose="opportunity" />
          
          {/* Add to / Remove from Eval Radar */}
          <EvalRadarToggle
            opportunityId={opportunity.id}
            evalPhaseOverride={(fullOpportunity as any)?.eval_phase_override}
            milestones={milestones}
            preSalesStage={fullOpportunity?.pre_sales_stage}
          />
          
          
          {/* Import from Other Opportunity Button */}
          <ImportFromOpportunityDialog 
            accountId={opportunity.account_id} 
            opportunityId={opportunity.id} 
            opportunityName={opportunity.name} 
          />
          
          {/* Share Digest Button */}
          <ShareOpportunityDigestDialog opportunityId={opportunity.id} opportunityName={opportunity.name} />
          
          {/* Delete Button */}
          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
            onClick={() => setShowDeleteConfirm(true)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
          
          {/* Quick Stats */}
          <div className="flex gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{readinessScore.percentage}%</div>
              <div className="text-xs text-muted-foreground">Readiness</div>
            </div>
            <div className="text-center">
              <div className={cn(
                "text-2xl font-bold",
                validationProgress.notStarted > 0 ? "text-amber-500" : "text-foreground"
              )}>
                {validationProgress.percentage}%
              </div>
              <div className="text-xs text-muted-foreground">Validation</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{milestoneProgress.percentage}%</div>
              <div className="text-xs text-muted-foreground">Timeline</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-destructive">{readinessScore.gaps}</div>
              <div className="text-xs text-muted-foreground">Gaps</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={handleTabChange} className="flex-1 flex flex-col">
        <div className="px-6 border-b border-border overflow-x-auto">
          <TabsList className="h-12 inline-flex w-max">
            <TabsTrigger value="overview" className="gap-2">
              <Settings2 className="w-4 h-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="use-cases" className="gap-2">
              <Lightbulb className="w-4 h-4" />
              Use Cases
            </TabsTrigger>
            <TabsTrigger value="technical" className="gap-2">
              <ClipboardList className="w-4 h-4" />
              Technical
            </TabsTrigger>
            <TabsTrigger value="radar" className="gap-2">
              <Target className="w-4 h-4" />
              Priority Radar
            </TabsTrigger>
            <TabsTrigger value="insights" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              Insights
            </TabsTrigger>
            <TabsTrigger value="competitive" className="gap-2">
              <Swords className="w-4 h-4" />
              Competitive
            </TabsTrigger>
            <TabsTrigger value="nbas" className="gap-2">
              <Zap className="w-4 h-4" />
              Actions
              {nbaStats.pending > 0 && (
                <Badge variant="outline" className={cn(
                  "ml-1 text-xs px-1.5 py-0",
                  nbaStats.high > 0 && "border-destructive text-destructive"
                )}>
                  {nbaStats.pending}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="transcripts" className="gap-2">
              <FileText className="w-4 h-4" />
              Transcripts
              {transcriptCount && transcriptCount > 0 && (
                <Badge variant="outline" className="ml-1 text-xs px-1.5 py-0">
                  {transcriptCount}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="stakeholders" className="gap-2">
              <User className="w-4 h-4" />
              Stakeholders
            </TabsTrigger>
            <TabsTrigger value="team" className="gap-2">
              <Users className="w-4 h-4" />
              Team
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <History className="w-4 h-4" />
              History
            </TabsTrigger>
            <TabsTrigger value="documents" className="gap-2">
              <FileText className="w-4 h-4" />
              Documents
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="flex-1 overflow-auto">
          <TabsContent value="overview" className="p-6 m-0">
            <div className="grid gap-6 md:grid-cols-2">
              {/* Opportunity Details Card - Editable (moved to top) */}
              <Card className="md:col-span-2">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Target className="w-5 h-5 text-primary" />
                      Opportunity Details
                    </CardTitle>
                    {isEditingDetails ? (
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm" onClick={handleCancelEdit}>
                          <X className="w-4 h-4 mr-1" />
                          Cancel
                        </Button>
                        <Button size="sm" onClick={handleSaveDetails} disabled={updateOpportunity.isPending}>
                          <Save className="w-4 h-4 mr-1" />
                          {updateOpportunity.isPending ? 'Saving...' : 'Save'}
                        </Button>
                      </div>
                    ) : (
                      <Button variant="ghost" size="sm" onClick={() => setIsEditingDetails(true)}>
                        <Edit2 className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 md:grid-cols-3">
                    {/* Opportunity Name */}
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Opportunity Name</Label>
                      {isEditingDetails ? (
                        <Input
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        />
                      ) : (
                        <div className="flex items-center gap-2">
                          <p className="text-foreground font-medium">{fullOpportunity?.name || opportunity.name}</p>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => {
                                  const url = getOpportunityUrl(opportunity.id);
                                  navigator.clipboard.writeText(url);
                                  toast.success('Link copied to clipboard');
                                }}
                              >
                                <Link2 className="h-3.5 w-3.5 text-muted-foreground" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Copy direct link</TooltipContent>
                          </Tooltip>
                        </div>
                      )}
                    </div>

                    {/* Stage */}
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Sales Stage (CRM)</Label>
                      {isEditingDetails ? (
                        <Select
                          value={formData.stage}
                          onValueChange={(value) => setFormData({ ...formData, stage: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {stageOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge className={cn(stageColors[fullOpportunity?.sales_stage || fullOpportunity?.stage || opportunity.stage || ''] || 'bg-muted')}>
                          {stageOptions.find(s => s.value === (fullOpportunity?.sales_stage || fullOpportunity?.stage || opportunity.stage))?.label || (fullOpportunity?.sales_stage || opportunity.stage)?.replace(/_/g, ' ')}
                        </Badge>
                      )}
                      {/* Detected stage comparison */}
                      {detectedStageInfo?.inferredStage != null && !isEditingDetails && (
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800">
                            <Sparkles className="w-3 h-3 mr-1" />
                            Detected: Stage {detectedStageInfo.inferredStage}
                          </Badge>
                          {(() => {
                            const currentStageNum = parseInt((fullOpportunity?.sales_stage || 'stage_0').replace('stage_', '')) || 0;
                            const diff = currentStageNum - detectedStageInfo.inferredStage;
                            if (diff < 0) return (
                              <span className="text-xs text-amber-600 dark:text-amber-400">
                                ↑ CRM behind by {Math.abs(diff)} stage{Math.abs(diff) > 1 ? 's' : ''}
                              </span>
                            );
                            if (diff > 0) return (
                              <span className="text-xs text-green-600 dark:text-green-400">
                                ✓ CRM ahead
                              </span>
                            );
                            return <span className="text-xs text-green-600">✓ Aligned</span>;
                          })()}
                        </div>
                      )}
                      {detectedStageInfo?.latestSignal && !isEditingDetails && (
                        <p className="text-xs text-muted-foreground">
                          Last signal: {detectedStageInfo.latestSignal.name} on {detectedStageInfo.latestSignal.date}
                        </p>
                      )}
                    </div>

                    {/* Pre-Sales Stage */}
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Pre-Sales Stage</Label>
                      {isEditingDetails ? (
                        <Select
                          value={formData.pre_sales_stage}
                          onValueChange={(value) => setFormData({ ...formData, pre_sales_stage: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select stage" />
                          </SelectTrigger>
                          <SelectContent>
                            {preSalesStageOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : preSalesAssessment ? (
                        <HoverCard>
                          <HoverCardTrigger asChild>
                            <Badge 
                              variant="outline" 
                              className="bg-layer-adopt-muted text-layer-adopt border-layer-adopt/30 cursor-help flex items-center gap-1"
                            >
                              {fullOpportunity?.pre_sales_stage || 'Not set'}
                              <Info className="w-3 h-3 opacity-60" />
                            </Badge>
                          </HoverCardTrigger>
                          <HoverCardContent className="w-80" align="start">
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <span className="text-sm font-medium">AI Assessment</span>
                                <Badge variant="secondary" className="text-xs">
                                  {Math.round((preSalesAssessment.confidence || 0) * 100)}% confidence
                                </Badge>
                              </div>
                              {preSalesAssessment.evidence && preSalesAssessment.evidence.length > 0 && (
                                <div className="space-y-2">
                                  <p className="text-xs font-medium text-muted-foreground">Evidence from transcript:</p>
                                  <div className="space-y-1.5 max-h-40 overflow-y-auto">
                                    {preSalesAssessment.evidence.slice(0, 3).map((quote: string, idx: number) => (
                                      <p key={idx} className="text-xs text-muted-foreground italic border-l-2 border-primary/30 pl-2">
                                        "{quote}"
                                      </p>
                                    ))}
                                  </div>
                                </div>
                              )}
                              {preSalesAssessment.meetingTitle && (
                                <p className="text-xs text-muted-foreground pt-1 border-t">
                                  From: {preSalesAssessment.meetingTitle}
                                </p>
                              )}
                            </div>
                          </HoverCardContent>
                        </HoverCard>
                      ) : (
                        <Badge variant="outline" className="bg-layer-adopt-muted text-layer-adopt border-layer-adopt/30">
                          {fullOpportunity?.pre_sales_stage || 'Not set'}
                        </Badge>
                      )}
                      {/* Detected pre-sales stage comparison */}
                      {detectedStageInfo?.inferredPreSalesStage && !isEditingDetails && (
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800">
                            <Sparkles className="w-3 h-3 mr-1" />
                            Detected: {detectedStageInfo.inferredPreSalesStage}
                          </Badge>
                          {fullOpportunity?.pre_sales_stage === detectedStageInfo.inferredPreSalesStage ? (
                            <span className="text-xs text-green-600 dark:text-green-400">✓ Aligned</span>
                          ) : (
                            <span className="text-xs text-amber-600 dark:text-amber-400">
                              ↕ Mismatch
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Value */}
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Deal Value</Label>
                      {isEditingDetails ? (
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                          <Input
                            type="number"
                            value={formData.value}
                            onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                            className="pl-7"
                            placeholder="0"
                          />
                        </div>
                      ) : (
                        <p className="text-foreground font-medium">
                          {(fullOpportunity?.value || opportunity.value) 
                            ? `$${(fullOpportunity?.value || opportunity.value)?.toLocaleString()}`
                            : 'Not specified'
                          }
                        </p>
                      )}
                    </div>

                    {/* MAU Count */}
                    <div className="space-y-2">
                      <Label className="text-muted-foreground flex items-center gap-2">
                        <Users className="w-3.5 h-3.5" />
                        MAU Count
                      </Label>
                      {isEditingDetails ? (
                        <Input
                          type="number"
                          value={formData.mau_count}
                          onChange={(e) => setFormData({ ...formData, mau_count: e.target.value })}
                          placeholder="e.g., 50000"
                        />
                      ) : (
                        <p className="text-foreground font-medium">
                          {(fullOpportunity as any)?.mau_count 
                            ? (fullOpportunity as any).mau_count.toLocaleString()
                            : 'Not set'
                          }
                        </p>
                      )}
                    </div>

                    {/* Priority */}
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Priority</Label>
                      {isEditingDetails ? (
                        <Select
                          value={formData.priority}
                          onValueChange={(value) => setFormData({ ...formData, priority: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {priorityOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge variant="outline" className="capitalize">
                          {fullOpportunity?.priority || opportunity.priority || 'medium'}
                        </Badge>
                      )}
                    </div>

                    {/* Close Date */}
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Close Date</Label>
                      {isEditingDetails ? (
                        <Input
                          type="date"
                          value={formData.close_date}
                          onChange={(e) => setFormData({ ...formData, close_date: e.target.value })}
                        />
                      ) : (
                        <p className="text-foreground">
                          {(fullOpportunity?.close_date || opportunity.close_date)
                            ? new Date(fullOpportunity?.close_date || opportunity.close_date || '').toLocaleDateString()
                            : 'Not set'
                          }
                        </p>
                      )}
                    </div>

                    {/* Opportunity Owner (AE) */}
                    <div className="space-y-2">
                      <Label className="text-muted-foreground flex items-center gap-2">
                        <User className="w-3.5 h-3.5" />
                        Opportunity Owner (AE)
                      </Label>
                      {isEditingDetails ? (
                        <Select
                          value={formData.owner_email}
                          onValueChange={(value) => setFormData({ ...formData, owner_email: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select AE">
                              {(() => {
                                const ownerUser = allAssignableUsers.find(u => u.email === formData.owner_email);
                                return ownerUser ? (ownerUser.full_name || ownerUser.email) : 'Select AE';
                              })()}
                            </SelectValue>
                          </SelectTrigger>
                          <SelectContent>
                            {aeUsers.map((u) => (
                              <SelectItem key={u.email} value={u.email}>
                                {u.full_name || u.email}
                                {u.full_name && <span className="text-muted-foreground ml-2 text-xs">({u.email})</span>}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <p className="text-foreground">
                          {(() => {
                            const ownerUser = allAssignableUsers.find(u => u.email === fullOpportunity?.owner_email);
                            return ownerUser ? (ownerUser.full_name || ownerUser.email) : (fullOpportunity?.owner_email || 'Not assigned');
                          })()}
                        </p>
                      )}
                    </div>

                    {/* Sales Engineer - SE role users only */}
                    <div className="space-y-2">
                      <Label className="text-muted-foreground flex items-center gap-2">
                        <User className="w-3.5 h-3.5" />
                        Sales Engineer
                      </Label>
                      {isEditingDetails ? (
                        <Select
                          value={formData.primary_se_email}
                          onValueChange={(value) => setFormData({ ...formData, primary_se_email: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select SE">
                              {(() => {
                                const seUser = allAssignableUsers.find(u => u.email === formData.primary_se_email);
                                return seUser ? (seUser.full_name || seUser.email) : 'Select SE';
                              })()}
                            </SelectValue>
                          </SelectTrigger>
                          <SelectContent>
                            {seUsers.map((u) => (
                              <SelectItem key={u.email} value={u.email}>
                                {u.full_name || u.email}
                                {u.full_name && <span className="text-muted-foreground ml-2 text-xs">({u.email})</span>}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <p className="text-foreground">
                          {(() => {
                            const seUser = allAssignableUsers.find(u => u.email === fullOpportunity?.primary_se_email);
                            return seUser ? (seUser.full_name || seUser.email) : (fullOpportunity?.primary_se_email || 'Not assigned');
                          })()}
                        </p>
                      )}
                    </div>

                    {/* Salesforce Opportunity ID */}
                    <div className="space-y-2">
                      <Label className="text-muted-foreground flex items-center gap-2">
                        <SalesforceIcon className="w-3.5 h-3.5" />
                        Salesforce Opp ID
                      </Label>
                      {isEditingDetails ? (
                        <Input
                          value={formData.salesforce_opportunity_id}
                          onChange={(e) => setFormData({ ...formData, salesforce_opportunity_id: e.target.value })}
                          placeholder="e.g., 006Pe00000auUBdIAM"
                        />
                      ) : (
                        <div className="flex items-center gap-2">
                          <p className="text-foreground text-sm font-mono">
                            {fullOpportunity?.salesforce_opportunity_id || 'Not set'}
                          </p>
                          {fullOpportunity?.salesforce_opportunity_id && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <a
                                  href={`https://pendo.lightning.force.com/lightning/r/Opportunity/${fullOpportunity.salesforce_opportunity_id.trim()}/view`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center justify-center h-6 w-6 rounded-md hover:bg-accent transition-colors"
                                >
                                  <ExternalLink className="h-3.5 w-3.5 text-muted-foreground hover:text-primary" />
                                </a>
                              </TooltipTrigger>
                              <TooltipContent>Open in Salesforce</TooltipContent>
                            </Tooltip>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Description - full width */}
                    <div className="space-y-2 md:col-span-3">
                      <Label className="text-muted-foreground">Description</Label>
                      {isEditingDetails ? (
                        <Textarea
                          value={formData.description}
                          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                          placeholder="Opportunity description..."
                          rows={2}
                        />
                      ) : (
                        <p className="text-foreground text-sm">
                          {fullOpportunity?.description || opportunity.description || 'No description'}
                        </p>
                      )}
                    </div>

                    {/* Evaluation Section - full width */}
                    <div className="space-y-4 md:col-span-3 border-t border-border pt-4">
                      <h4 className="text-sm font-semibold text-foreground flex items-center gap-2">
                        <CalendarRange className="w-4 h-4 text-orange-500" />
                        Evaluation / Trial Period
                        {(fullOpportunity as any)?.primary_eval_quote && !(fullOpportunity as any)?.eval_start_date && (
                          <Badge variant="outline" className="text-xs bg-amber-500/10 text-amber-600 border-amber-500/30">Eval Pending</Badge>
                        )}
                        {(fullOpportunity as any)?.eval_start_date && !(fullOpportunity as any)?.eval_end_date && (
                          <Badge variant="outline" className="text-xs bg-orange-500/10 text-orange-600 border-orange-500/30">Eval Active</Badge>
                        )}
                        {(fullOpportunity as any)?.eval_end_date && (
                          <Badge variant="outline" className="text-xs bg-green-500/10 text-green-600 border-green-500/30">Eval Complete</Badge>
                        )}
                      </h4>
                      <div className="grid gap-4 md:grid-cols-4">
                        {/* Primary Eval Quote */}
                        <div className="space-y-2 md:col-span-4">
                          <Label className="text-muted-foreground text-xs">Primary Eval Quote</Label>
                          {isEditingDetails ? (
                            <Input
                              value={formData.primary_eval_quote}
                              onChange={(e) => setFormData({ ...formData, primary_eval_quote: e.target.value })}
                              placeholder="e.g., Q1 FY25 Eval Approved"
                            />
                          ) : (
                            <p className="text-foreground text-sm">
                              {(fullOpportunity as any)?.primary_eval_quote || <span className="text-muted-foreground italic">Not set</span>}
                            </p>
                          )}
                        </div>
                        {/* Eval Type */}
                        <div className="space-y-2">
                          <Label className="text-muted-foreground text-xs">Eval Type</Label>
                          {isEditingDetails ? (
                            <Input
                              value={formData.eval_type}
                              onChange={(e) => setFormData({ ...formData, eval_type: e.target.value })}
                              placeholder="e.g., POC, POV, Trial"
                            />
                          ) : (
                            <p className="text-foreground text-sm">
                              {(fullOpportunity as any)?.eval_type || <span className="text-muted-foreground italic">Not set</span>}
                            </p>
                          )}
                        </div>
                        {/* Eval Start Date */}
                        <div className="space-y-2">
                          <Label className="text-muted-foreground text-xs">Eval Start Date</Label>
                          {isEditingDetails ? (
                            <Input
                              type="date"
                              value={formData.eval_start_date}
                              onChange={(e) => setFormData({ ...formData, eval_start_date: e.target.value })}
                            />
                          ) : (
                            <p className="text-foreground text-sm">
                              {(fullOpportunity as any)?.eval_start_date
                                ? new Date((fullOpportunity as any).eval_start_date).toLocaleDateString()
                                : <span className="text-muted-foreground italic">Not started</span>}
                            </p>
                          )}
                        </div>
                        {/* Eval End Date */}
                        <div className="space-y-2">
                          <Label className="text-muted-foreground text-xs">Eval End Date</Label>
                          {isEditingDetails ? (
                            <Input
                              type="date"
                              value={formData.eval_end_date}
                              onChange={(e) => setFormData({ ...formData, eval_end_date: e.target.value })}
                            />
                          ) : (
                            <p className="text-foreground text-sm">
                              {(fullOpportunity as any)?.eval_end_date
                                ? new Date((fullOpportunity as any).eval_end_date).toLocaleDateString()
                                : <span className="text-muted-foreground italic">Not completed</span>}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Included Modules Selector - full width */}
                    <div className="space-y-2 md:col-span-3">
                      <IncludedModulesSelector
                        selectedModuleIds={formData.included_module_ids}
                        onSelectionChange={(ids) => setFormData({ ...formData, included_module_ids: ids })}
                        disabled={!isEditingDetails}
                        opportunityId={opportunity.id}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* AI Situation Report */}
              <AISituationReportCard opportunityId={opportunity.id} />

              {/* SE Weekly Update Card */}
              <SEUpdateCard opportunityId={opportunity.id} />

              {/* Activity Timeline Card */}
              <OpportunityActivityTimelineCard opportunityId={opportunity.id} accountId={opportunity.account_id} />

              {/* Deployment Types Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Deployment Types</CardTitle>
                  <CardDescription>
                    Select which deployment methods apply to this opportunity
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {allDeploymentTypes?.map(dt => {
                    const isEnabled = enabledDeploymentTypeIds.includes(dt.id);
                    return (
                      <div
                        key={dt.id}
                        className={cn(
                          "flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer",
                          isEnabled ? "border-primary bg-primary/5" : "border-border hover:border-muted-foreground"
                        )}
                        onClick={() => handleToggleDeploymentType(dt.id, isEnabled)}
                      >
                        <Checkbox checked={isEnabled} />
                        <span className="text-xl">{deploymentTypeIcons[dt.name] || '📦'}</span>
                        <div className="flex-1">
                          <div className="font-medium">{deploymentTypeLabels[dt.name] || dt.name}</div>
                          {dt.description && (
                            <div className="text-sm text-muted-foreground">{dt.description}</div>
                          )}
                        </div>
                        {isEnabled && <CheckCircle2 className="w-5 h-5 text-primary" />}
                      </div>
                    );
                  })}
                </CardContent>
              </Card>

              {/* Readiness Summary Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Readiness Summary</CardTitle>
                  <CardDescription>
                    Technical documentation completion status
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Questions Answered</span>
                      <span className="font-medium">{readinessScore.answered} / {readinessScore.total}</span>
                    </div>
                    <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary transition-all"
                        style={{ width: `${readinessScore.percentage}%` }}
                      />
                    </div>
                    
                    {readinessScore.gaps > 0 && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive">
                        <AlertCircle className="w-4 h-4" />
                        <span className="text-sm font-medium">
                          {readinessScore.gaps} questions need answers
                        </span>
                      </div>
                    )}
                    
                    {readinessScore.percentage === 100 && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/10 text-primary">
                        <CheckCircle2 className="w-4 h-4" />
                        <span className="text-sm font-medium">
                          All technical questions answered!
                        </span>
                      </div>
                    )}
                    
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => setActiveTab('technical')}
                    >
                      View Technical Readiness
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Timeline Summary Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Timeline Progress</CardTitle>
                  <CardDescription>
                    Mutual action plan milestones
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {milestones && milestones.length > 0 ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Milestones Completed</span>
                        <span className="font-medium">{milestoneProgress.completed} / {milestoneProgress.total}</span>
                      </div>
                      <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary transition-all"
                          style={{ width: `${milestoneProgress.percentage}%` }}
                        />
                      </div>
                      
                      {/* Next milestones */}
                      <div className="space-y-2">
                        <div className="text-sm font-medium">Upcoming</div>
                        {milestones
                          .filter(m => m.status !== 'completed' && m.status !== 'skipped')
                          .slice(0, 3)
                          .map(m => (
                            <div key={m.id} className="flex items-center gap-2 text-sm">
                              <Clock className="w-4 h-4 text-muted-foreground" />
                              <span className="flex-1 truncate">{m.name}</span>
                              {m.scheduled_date && (
                                <span className="text-muted-foreground">
                                  {new Date(m.scheduled_date).toLocaleDateString()}
                                </span>
                              )}
                            </div>
                          ))}
                      </div>
                      
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => setActiveTab('technical')}
                      >
                        View Full Timeline
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <Clock className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground mb-4">
                        No milestones set up yet
                      </p>
                      <Button onClick={handleInitializeMilestones} disabled={initializeMilestones.isPending}>
                        {initializeMilestones.isPending ? 'Setting up...' : 'Initialize Timeline'}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Validation Tasks Summary Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Validation Tasks</CardTitle>
                  <CardDescription>
                    Pre-deployment validation checklist
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Tasks Completed</span>
                      <span className="font-medium">{validationProgress.completed} / {validationProgress.total}</span>
                    </div>
                    <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary transition-all"
                        style={{ width: `${validationProgress.percentage}%` }}
                      />
                    </div>
                    
                    {validationProgress.notStarted > 0 && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-500/10 text-amber-600">
                        <AlertTriangle className="w-4 h-4" />
                        <span className="text-sm font-medium">
                          {validationProgress.notStarted} tasks not started
                        </span>
                      </div>
                    )}
                    
                    {validationProgress.blocked > 0 && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive">
                        <AlertCircle className="w-4 h-4" />
                        <span className="text-sm font-medium">
                          {validationProgress.blocked} tasks blocked
                        </span>
                      </div>
                    )}
                    
                    {validationProgress.percentage === 100 && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/10 text-primary">
                        <CheckCircle2 className="w-4 h-4" />
                        <span className="text-sm font-medium">
                          All validation tasks complete!
                        </span>
                      </div>
                    )}
                    
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => setActiveTab('technical')}
                    >
                      View Validation Tasks
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="radar" className="h-full m-0 overflow-auto p-6">
            <div className="text-center text-muted-foreground py-12">
              <Target className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>Priority Radar is available from the Account view.</p>
            </div>
          </TabsContent>

          <TabsContent value="insights" className="h-full m-0 overflow-auto">
            <OpportunityInsightsTab
              opportunityId={opportunity.id}
              accountId={opportunity.account_id}
            />
          </TabsContent>

          <TabsContent value="competitive" className="h-full m-0 overflow-auto">
            <OpportunityCompetitiveTab
              opportunityId={opportunity.id}
              accountId={opportunity.account_id}
            />
          </TabsContent>

          <TabsContent value="nbas" className="h-full m-0 overflow-auto">
            <OpportunityNBAsTab
              opportunityId={opportunity.id}
              accountId={opportunity.account_id}
              opportunityName={opportunity.name}
            />
          </TabsContent>

          <TabsContent value="use-cases" className="h-full m-0 overflow-auto">
            <OpportunityUseCasesTab 
              opportunityId={opportunity.id}
              accountId={opportunity.account_id}
            />
          </TabsContent>

          <TabsContent value="technical" className="h-full m-0" forceMount style={{ display: activeTab === 'technical' ? undefined : 'none' }}>
            <OpportunityTechnicalTab
              opportunityId={opportunity.id}
              accountId={opportunity.account_id}
              accountName={accountName}
              opportunityName={opportunity.name}
              deploymentTypeIds={enabledDeploymentTypeIds}
              onDeploymentTypesDetected={handleDeploymentTypesDetected}
              onInitializeMilestones={handleInitializeMilestones}
              isInitializingMilestones={initializeMilestones.isPending}
            />
          </TabsContent>

          <TabsContent value="transcripts" className="h-full m-0">
            <OpportunityTranscriptsTab 
              opportunityId={opportunity.id}
              accountId={opportunity.account_id}
              deploymentTypeIds={enabledDeploymentTypeIds}
              onDeploymentTypesDetected={handleDeploymentTypesDetected}
              primarySeEmail={fullOpportunity?.primary_se_email || null}
            />
          </TabsContent>

          <TabsContent value="stakeholders" className="h-full m-0 overflow-auto">
            <OpportunityStakeholdersTab 
              opportunityId={opportunity.id}
              accountId={opportunity.account_id}
            />
          </TabsContent>

          <TabsContent value="team" className="h-full m-0 overflow-auto">
            <OpportunityTeamTab opportunityId={opportunity.id} />
          </TabsContent>

          <TabsContent value="history" className="h-full m-0 overflow-auto">
            <OpportunityHistoryTab opportunityId={opportunity.id} />
          </TabsContent>

          <TabsContent value="documents" className="p-6">
            <DocumentsPanel 
              accountId={opportunity.account_id}
              opportunityId={opportunity.id}
              opportunityName={opportunity.name}
              context="opportunity"
            />
          </TabsContent>
        </div>
      </Tabs>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Opportunity</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{opportunity.name}"? This action cannot be undone and will remove all associated data including transcripts, insights, and stakeholders linked to this opportunity.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteOpportunity}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteOpportunity.isPending ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// AI Situation Report Card Component
function AISituationReportCard({ opportunityId }: { opportunityId: string }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const queryClient = useQueryClient();

  const { data: summary, isLoading } = useQuery({
    queryKey: ['opportunity-summary', opportunityId],
    queryFn: async () => {
      const result = await gateway
        .from('opportunity_summaries')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .maybeSingle()
        .execute();

      if (result.error) {
        throw new Error(result.error.message || 'Failed to load opportunity summary');
      }

      return result.data;
    },
  });

  const [isRegenerating, setIsRegenerating] = useState(false);
  const handleRegenerate = async () => {
    setIsRegenerating(true);
    try {
      const { error } = await supabase.functions.invoke('generate-opportunity-summaries', {
        body: { opportunityId },
      });
      if (error) throw error;
      // Small delay to ensure the DB write is committed before refetching
      await new Promise(r => setTimeout(r, 500));
      await queryClient.invalidateQueries({ queryKey: ['opportunity-summary', opportunityId] });
      await queryClient.refetchQueries({ queryKey: ['opportunity-summary', opportunityId] });
      toast.success('Situation report regenerated');
    } catch (e) {
      toast.error('Failed to regenerate report');
    }
    setIsRegenerating(false);
  };

  const brief = summary?.structured_brief as any;

  return (
    <Card className="border-primary/20 bg-primary/[0.02]">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            AI Situation Report
          </CardTitle>
          <div className="flex gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleRegenerate} disabled={isRegenerating}>
                  {isRegenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>Regenerate report</TooltipContent>
            </Tooltip>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </div>
        ) : summary ? (
          <div className="space-y-3">
            <p className="text-sm text-foreground leading-relaxed">{summary.one_liner}</p>

            {summary.next_critical_action && (
              <div className="flex items-start gap-2 p-2 rounded-md bg-amber-500/10 border border-amber-500/20">
                <Zap className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
                <span className="text-sm font-medium text-foreground">{summary.next_critical_action}</span>
              </div>
            )}

            {brief && (
              <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
                <CollapsibleTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-xs text-muted-foreground px-0 hover:text-foreground">
                    <ChevronRight className={cn("w-3 h-3 mr-1 transition-transform", isExpanded && "rotate-90")} />
                    {isExpanded ? 'Hide details' : 'Show full brief'}
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-3 pt-2">
                  {brief.status && (
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">Status</Label>
                      <p className="text-sm">{brief.status}</p>
                    </div>
                  )}
                  {brief.keyRisks?.length > 0 && (
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 text-amber-500" /> Key Risks
                      </Label>
                      <ul className="text-sm space-y-1">
                        {brief.keyRisks.map((risk: string, i: number) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-amber-500 mt-1">•</span>
                            <span>{risk}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {brief.nextSteps?.length > 0 && (
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground flex items-center gap-1">
                        <Target className="w-3 h-3 text-primary" /> Next Steps
                      </Label>
                      <ul className="text-sm space-y-1">
                        {brief.nextSteps.map((step: string, i: number) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            <span>{step}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {brief.closeTimeline && (
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground flex items-center gap-1">
                        <Calendar className="w-3 h-3" /> Close Timeline
                      </Label>
                      <p className="text-sm">{brief.closeTimeline}</p>
                    </div>
                  )}
                  {brief.competitiveLandscape && (
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground flex items-center gap-1">
                        <Swords className="w-3 h-3" /> Competitive
                      </Label>
                      <p className="text-sm">{brief.competitiveLandscape}</p>
                    </div>
                  )}
                </CollapsibleContent>
              </Collapsible>
            )}

            <p className="text-[11px] text-muted-foreground">
              Generated {new Date(summary.generated_at).toLocaleDateString()}
            </p>
          </div>
        ) : (
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground mb-2">No AI summary generated yet</p>
            <Button variant="outline" size="sm" onClick={handleRegenerate} disabled={isRegenerating}>
              {isRegenerating ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Sparkles className="w-4 h-4 mr-1" />}
              Generate Report
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// SE Update Card Component
function SEUpdateCard({ opportunityId }: { opportunityId: string }) {
  const { effectiveUserEmail } = useAuth();
  const { data: seUpdate, isLoading } = useOpportunitySEUpdate(opportunityId);
  const upsertSEUpdate = useUpsertSEUpdate();
  const [isEditing, setIsEditing] = useState(false);
  const [weeklyUpdate, setWeeklyUpdate] = useState('');
  const [potentialRisks, setPotentialRisks] = useState('');

  const startEditing = () => {
    setWeeklyUpdate(seUpdate?.weekly_update || '');
    setPotentialRisks(seUpdate?.potential_risks || '');
    setIsEditing(true);
  };

  const handleSave = async () => {
    if (!effectiveUserEmail) return;
    await upsertSEUpdate.mutateAsync({
      opportunity_id: opportunityId,
      updated_by: effectiveUserEmail,
      weekly_update: weeklyUpdate || null,
      potential_risks: potentialRisks || null,
    });
    setIsEditing(false);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            SE Update
          </CardTitle>
          {!isEditing ? (
            <Button variant="ghost" size="sm" onClick={startEditing}>
              <Edit2 className="w-4 h-4 mr-1" />
              {seUpdate ? 'Edit' : 'Add'}
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={() => setIsEditing(false)}>
                <X className="w-4 h-4 mr-1" /> Cancel
              </Button>
              <Button size="sm" onClick={handleSave} disabled={upsertSEUpdate.isPending}>
                <Save className="w-4 h-4 mr-1" /> Save
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {isEditing ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground">Weekly Update</Label>
              <Textarea
                value={weeklyUpdate}
                onChange={(e) => setWeeklyUpdate(e.target.value)}
                placeholder="What happened this week?"
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">Potential Risks</Label>
              <Textarea
                value={potentialRisks}
                onChange={(e) => setPotentialRisks(e.target.value)}
                placeholder="Any risks or blockers?"
                rows={3}
              />
            </div>
          </div>
        ) : seUpdate ? (
          <div className="space-y-3">
            {seUpdate.weekly_update && (
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Weekly Update</Label>
                <p className="text-sm text-foreground">{seUpdate.weekly_update}</p>
              </div>
            )}
            {seUpdate.potential_risks && (
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-amber-500" />
                  Potential Risks
                </Label>
                <p className="text-sm text-foreground">{seUpdate.potential_risks}</p>
              </div>
            )}
            {seUpdate.updated_at && (
              <p className="text-xs text-muted-foreground">
                Last updated {new Date(seUpdate.updated_at).toLocaleDateString()}
              </p>
            )}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No SE update yet. Click "Add" to write your weekly update.</p>
        )}
      </CardContent>
    </Card>
  );
}

// Activity Timeline Card Component
function OpportunityActivityTimelineCard({ opportunityId, accountId }: { opportunityId: string; accountId: string }) {
  const { data: activities, isLoading } = useOpportunityActivities(opportunityId);
  const { data: signalsData } = useOpportunitySignals(opportunityId);

  // Aggregate KPIs from activities
  const kpis = useMemo(() => {
    if (!activities || activities.length === 0) {
      return { totalActivities: 0, byType: {} };
    }

    const byType: Record<string, { count: number; label: string; icon: string; color: string }> = {};
    for (const activity of activities) {
      const activityType = activity.activity_type;
      if (!activityType) continue;
      
      const typeName = activityType.name;
      if (!byType[typeName]) {
        byType[typeName] = {
          count: 0,
          label: activityType.label,
          icon: activityType.icon,
          color: activityType.color,
        };
      }
      byType[typeName].count++;
    }

    return { totalActivities: activities.length, byType };
  }, [activities]);

  if (isLoading) {
    return (
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            Activity Timeline
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-16 w-full" />
        </CardContent>
      </Card>
    );
  }

 // Use allSignals to show every occurrence, not just one per rule type
 const signals = signalsData?.allSignals || [];
  const signalTypes = signalsData?.signalTypes || [];

  return (
    <Card className="md:col-span-2">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Activity Timeline
            </CardTitle>
            <CardDescription>
              Engagement activities and detected signals for this opportunity
            </CardDescription>
          </div>
          <AddActivityDialog 
            opportunityId={opportunityId} 
            accountId={accountId}
            trigger={
              <Button variant="outline" size="sm">
                <Plus className="w-4 h-4 mr-1" />
                Add Activity
              </Button>
            }
          />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* KPI Summary */}
        {activities && activities.length > 0 && (
          <ActivityKPICards 
            byType={kpis.byType} 
            totalActivities={kpis.totalActivities}
            compact 
          />
        )}

        {/* Timeline with signals */}
        <div className="pt-4 pb-6">
          <ActivityTimeline 
            activities={activities || []} 
            signals={signals.map(s => ({
              id: s.id,
              ruleId: s.ruleId,
              ruleName: s.ruleName,
              ruleKey: s.ruleKey,
              confidenceScore: s.confidenceScore,
              matchedPhrases: s.matchedPhrases,
              detectedAt: s.detectedAt,
              transcriptId: s.transcriptId,
              speakerType: s.speakerType,
              speakerName: s.speakerName,
            }))}
          />
        </div>

        {/* Signal Legend (deduplicated with counts) */}
        {signals.length > 0 && (
          <div className="flex flex-wrap gap-2 pt-2 border-t">
            {Object.values(
              signals.reduce<Record<string, { ruleId: string; ruleName: string; count: number }>>((acc, s) => {
                if (!acc[s.ruleId]) {
                  acc[s.ruleId] = { ruleId: s.ruleId, ruleName: s.ruleName, count: 0 };
                }
                acc[s.ruleId].count++;
                return acc;
              }, {})
            )
              .sort((a, b) => b.count - a.count)
              .map((group) => {
                const signalType = signalTypes.find(st => st.id === group.ruleId);
                const color = signalType?.color || '#6366f1';
                return (
                  <Badge
                    key={group.ruleId}
                    variant="outline"
                    className="text-xs"
                    style={{ 
                      borderColor: color, 
                      color: color,
                      backgroundColor: `${color}15`
                    }}
                  >
                    {group.ruleName}
                    {group.count > 1 && (
                      <span className="ml-1 font-semibold">×{group.count}</span>
                    )}
                  </Badge>
                );
              })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { 
  History, 
  TrendingUp, 
  TrendingDown,
  ArrowRight,
  User,
  Bot,
  RefreshCw,
  Target,
  Clock,
  Users,
  MessageSquareQuote,
  AlertCircle,
  Quote,
  ClipboardCheck,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, formatDistanceToNow } from 'date-fns';

interface OpportunityHistoryTabProps {
  opportunityId: string;
}

interface StageHistoryEntry {
  id: string;
  stage_type: 'sales_stage' | 'pre_sales_stage';
  old_value: string | null;
  new_value: string;
  changed_at: string;
  changed_by: string | null;
  change_source: string;
  duration_in_previous_stage: string | null;
  notes: string | null;
  changer?: {
    display_name: string | null;
  } | null;
}

interface MetricHistoryEntry {
  id: string;
  metric_type: string;
  old_value: any;
  new_value: any;
  changed_at: string;
  changed_by: string | null;
  change_source: string;
  change_reason: string | null;
  changer?: {
    display_name: string | null;
  } | null;
}

interface SignalOccurrence {
  id: string;
  detected_at: string;
  crm_stage: number | null;
  pre_sales_stage: number | null;
  matched_phrases: string[] | null;
  speaker_type: string | null;
  confidence_score: number | null;
  detection_rule_match: {
    detection_rule: {
      name: string;
    } | null;
  } | null;
}

interface ReadinessHistoryEntry {
  id: string;
  question_id: string;
  old_answer: any;
  new_answer: any;
  old_score: number | null;
  new_score: number | null;
  changed_at: string;
  changed_by: string | null;
  change_source: string;
  question?: {
    question: string;
  } | null;
  changer?: {
    display_name: string | null;
  } | null;
}

interface StakeholderSnapshot {
  id: string;
  contact_id: string;
  meeting_date: string;
  meeting_type: string;
  sentiment: number | null;
  influence_level: number | null;
  champion_score: number | null;
  key_quotes: string[] | null;
  notes: string | null;
  account_contact: {
    name: string;
    role: string | null;
  } | null;
}

function getSourceIcon(source: string) {
  switch (source) {
    case 'manual':
      return <User className="w-3 h-3" />;
    case 'signal_inferred':
    case 'transcript_analysis':
      return <Bot className="w-3 h-3" />;
    case 'crm_sync':
      return <RefreshCw className="w-3 h-3" />;
    default:
      return <Clock className="w-3 h-3" />;
  }
}

function getSourceLabel(source: string) {
  switch (source) {
    case 'manual':
      return 'Manual';
    case 'signal_inferred':
      return 'AI Inferred';
    case 'transcript_analysis':
      return 'Transcript';
    case 'crm_sync':
      return 'CRM Sync';
    default:
      return source;
  }
}

export function OpportunityHistoryTab({ opportunityId }: OpportunityHistoryTabProps) {
  // Fetch stage history with changer names
  const { data: stageHistory, isLoading: loadingStages } = useQuery({
    queryKey: ['opportunity-stage-history', opportunityId],
    queryFn: async () => {
      const { data: history, error } = await gateway
        .from('opportunity_stage_history')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('changed_at', { ascending: false })
        .execute();
      
      if (error) throw error;
      if (!history || history.length === 0) return [];

      // Get unique changer IDs
      const changerIds = [...new Set(history.filter(h => h.changed_by).map(h => h.changed_by))];
      
      let profileMap = new Map<string, { display_name: string | null }>();
      if (changerIds.length > 0) {
        const { data: profiles } = await gateway
          .from('profiles')
          .select('id, display_name')
          .in('id', changerIds)
          .execute();
        
        if (profiles) {
          profileMap = new Map(profiles.map(p => [p.id, { display_name: p.display_name }]));
        }
      }
      
      return history.map(h => ({
        ...h,
        changer: h.changed_by ? profileMap.get(h.changed_by) || null : null,
      })) as StageHistoryEntry[];
    },
  });

  // Fetch metric history with changer names
  const { data: metricHistory, isLoading: loadingMetrics } = useQuery({
    queryKey: ['opportunity-metric-history', opportunityId],
    queryFn: async () => {
      const { data: history, error } = await gateway
        .from('opportunity_metric_history')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('changed_at', { ascending: false })
        .execute();
      
      if (error) throw error;
      if (!history || history.length === 0) return [];

      // Get unique changer IDs
      const changerIds = [...new Set(history.filter(h => h.changed_by).map(h => h.changed_by))];
      
      let profileMap = new Map<string, { display_name: string | null }>();
      if (changerIds.length > 0) {
        const { data: profiles } = await gateway
          .from('profiles')
          .select('id, display_name')
          .in('id', changerIds)
          .execute();
        
        if (profiles) {
          profileMap = new Map(profiles.map(p => [p.id, { display_name: p.display_name }]));
        }
      }
      
      return history.map(h => ({
        ...h,
        changer: h.changed_by ? profileMap.get(h.changed_by) || null : null,
      })) as MetricHistoryEntry[];
    },
  });

  // Fetch signal occurrences - first get match IDs for this opportunity, then fetch occurrences
  const { data: signalOccurrences, isLoading: loadingSignals } = useQuery({
    queryKey: ['opportunity-signal-occurrences', opportunityId],
    queryFn: async () => {
      // Step 1: Get match IDs for this opportunity
      const { data: matches, error: matchError } = await gateway
        .from('detection_rule_matches')
        .select('id')
        .eq('opportunity_id', opportunityId)
        .execute();
      
      if (matchError) throw matchError;
      if (!matches || matches.length === 0) return [];
      
      const matchIds = matches.map((m: { id: string }) => m.id);
      
      // Step 2: Fetch signal occurrences with their rule names
      const { data, error } = await gateway
        .from('signal_occurrences')
        .select(`
          id, detected_at, crm_stage, pre_sales_stage, matched_phrases, speaker_type, confidence_score, match_id,
          detection_rule_match:match_id(
            id,
            rule_id,
            detection_rule:rule_id(name)
          )
        `)
        .in('match_id', matchIds)
        .order('detected_at', { ascending: false })
        .limit(50)
        .execute();
      
      if (error) throw error;
      return data as SignalOccurrence[];
    },
  });

  // Fetch stakeholder snapshots for this opportunity
  const { data: stakeholderSnapshots, isLoading: loadingStakeholders } = useQuery({
    queryKey: ['opportunity-stakeholder-snapshots', opportunityId],
    queryFn: async () => {
      // First fetch snapshots
      const { data: snapshots, error: snapshotsError } = await gateway
        .from('contact_meeting_snapshots')
        .select('id, contact_id, meeting_date, meeting_type, sentiment, influence_level, champion_score, key_quotes, notes')
        .eq('opportunity_id', opportunityId)
        .order('meeting_date', { ascending: false })
        .limit(50)
        .execute();
      
      if (snapshotsError) throw snapshotsError;
      if (!snapshots || snapshots.length === 0) return [];

      // Get unique contact IDs
      const contactIds = [...new Set(snapshots.map(s => s.contact_id))];
      
      // Fetch contacts through gateway for decryption
      const { data: contacts, error: contactsError } = await gateway
        .from('account_contacts')
        .select('id, name, role')
        .in('id', contactIds)
        .execute();
      
      if (contactsError) throw contactsError;
      
      // Create lookup map
      const contactMap = new Map((contacts || []).map(c => [c.id, c]));
      
      // Merge contact data into snapshots
      return snapshots.map(s => ({
        ...s,
        account_contact: contactMap.get(s.contact_id) || null,
      })) as StakeholderSnapshot[];
    },
  });

  // Fetch technical readiness history for this opportunity
  const { data: readinessHistory, isLoading: loadingReadiness } = useQuery({
    queryKey: ['opportunity-readiness-history', opportunityId],
    queryFn: async () => {
      // Fetch readiness history with question details
      const { data: history, error: historyError } = await gateway
        .from('technical_readiness_history')
        .select('id, question_id, old_answer, new_answer, old_score, new_score, changed_at, changed_by, change_source')
        .eq('opportunity_id', opportunityId)
        .order('changed_at', { ascending: false })
        .limit(50)
        .execute();
      
      if (historyError) throw historyError;
      if (!history || history.length === 0) return [];

      // Get unique question IDs
      const questionIds = [...new Set(history.map(h => h.question_id))];
      
      // Fetch question details
      const { data: questions, error: questionsError } = await gateway
        .from('readiness_template_questions')
        .select('id, question')
        .in('id', questionIds)
        .execute();
      
      if (questionsError) throw questionsError;
      
      // Get unique changer IDs
      const changerIds = [...new Set(history.filter(h => h.changed_by).map(h => h.changed_by))];
      
      // Fetch profile names if there are changers
      let profileMap = new Map<string, { display_name: string | null }>();
      if (changerIds.length > 0) {
        const { data: profiles } = await gateway
          .from('profiles')
          .select('id, display_name')
          .in('id', changerIds)
          .execute();
        
        if (profiles) {
          profileMap = new Map(profiles.map(p => [p.id, { display_name: p.display_name }]));
        }
      }
      
      // Create lookup map
      const questionMap = new Map((questions || []).map(q => [q.id, { question: q.question }]));
      
      // Merge data
      return history.map(h => ({
        ...h,
        question: questionMap.get(h.question_id) || null,
        changer: h.changed_by ? profileMap.get(h.changed_by) || null : null,
      })) as ReadinessHistoryEntry[];
    },
  });

  const isLoading = loadingStages || loadingMetrics || loadingSignals || loadingStakeholders || loadingReadiness;

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  // Combine and sort all history items
  const allHistory = [
    ...(stageHistory || []).map(h => ({ 
      ...h, 
      type: 'stage' as const, 
      timestamp: h.changed_at 
    })),
    ...(metricHistory || []).map(h => ({ 
      ...h, 
      type: 'metric' as const, 
      timestamp: h.changed_at 
    })),
    ...(signalOccurrences || []).map(s => ({ 
      ...s, 
      type: 'signal' as const, 
      timestamp: s.detected_at 
    })),
    ...(stakeholderSnapshots || []).map(s => ({ 
      ...s, 
      type: 'stakeholder' as const, 
      timestamp: s.meeting_date 
    })),
    ...(readinessHistory || []).map(r => ({ 
      ...r, 
      type: 'readiness' as const, 
      timestamp: r.changed_at 
    })),
  ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Opportunity History</h3>
        </div>
        <Badge variant="secondary">
          {allHistory.length} events
        </Badge>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        {/* Stage Changes */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Target className="w-4 h-4 text-primary" />
              Stage Changes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{stageHistory?.length || 0}</p>
            <p className="text-xs text-muted-foreground">Total transitions</p>
          </CardContent>
        </Card>

        {/* Metric Changes */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-chart-1" />
              Metric Updates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{metricHistory?.length || 0}</p>
            <p className="text-xs text-muted-foreground">Data changes</p>
          </CardContent>
        </Card>

        {/* Signal Detections */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Bot className="w-4 h-4 text-chart-2" />
              Signals Detected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{signalOccurrences?.length || 0}</p>
            <p className="text-xs text-muted-foreground">Activity signals</p>
          </CardContent>
        </Card>

        {/* Stakeholder Updates */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Users className="w-4 h-4 text-chart-3" />
              Stakeholder Updates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{stakeholderSnapshots?.length || 0}</p>
            <p className="text-xs text-muted-foreground">Score assessments</p>
          </CardContent>
        </Card>

        {/* Readiness Changes */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <ClipboardCheck className="w-4 h-4 text-chart-4" />
              Readiness Changes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{readinessHistory?.length || 0}</p>
            <p className="text-xs text-muted-foreground">Answer updates</p>
          </CardContent>
        </Card>
      </div>

      {/* Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Event Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px] pr-4">
            {allHistory.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                <History className="w-12 h-12 mb-4 opacity-50" />
                <p>No history recorded yet</p>
              </div>
            ) : (
              <div className="space-y-1">
                {allHistory.map((item, idx) => (
                  <div 
                    key={`${item.type}-${item.id}`}
                    className="flex items-center gap-2 py-1.5 px-2 rounded hover:bg-muted/50 group"
                  >
                    {/* Timeline dot */}
                    <div className={cn(
                      "w-2 h-2 rounded-full shrink-0",
                      item.type === 'stage' && "bg-primary",
                      item.type === 'metric' && "bg-chart-1",
                      item.type === 'signal' && "bg-chart-2",
                      item.type === 'stakeholder' && "bg-chart-3",
                      item.type === 'readiness' && "bg-chart-4",
                    )} />

                    {/* Type badge */}
                    <Badge variant="outline" className={cn(
                      "text-[10px] px-1.5 py-0 h-5 shrink-0",
                      item.type === 'stage' && "bg-primary/10",
                      item.type === 'metric' && "bg-chart-1/10",
                      item.type === 'signal' && "bg-chart-2/10",
                      item.type === 'stakeholder' && "bg-chart-3/10",
                      item.type === 'readiness' && "bg-chart-4/10",
                    )}>
                      {item.type === 'stage' && ((item as any).stage_type === 'sales_stage' ? 'Sales' : 'Pre-Sales')}
                      {item.type === 'metric' && 'Metric'}
                      {item.type === 'signal' && 'Signal'}
                      {item.type === 'stakeholder' && 'Stakeholder'}
                      {item.type === 'readiness' && 'Readiness'}
                    </Badge>

                    {/* Content - varies by type */}
                    <div className="flex items-center gap-1.5 min-w-0 flex-1 text-sm">
                      {item.type === 'stage' && (
                        <>
                          <span className="text-muted-foreground truncate">{(item as any).old_value || 'None'}</span>
                          <ArrowRight className="w-3 h-3 shrink-0 text-muted-foreground" />
                          <span className="font-medium truncate">{(item as any).new_value}</span>
                        </>
                      )}
                      {item.type === 'metric' && (
                        <>
                          <span className="text-muted-foreground capitalize truncate">{(item as any).metric_type.replace(/_/g, ' ')}</span>
                          <span className="text-muted-foreground mx-0.5">:</span>
                          <span className="truncate">{JSON.stringify((item as any).old_value)}</span>
                          <ArrowRight className="w-3 h-3 shrink-0 text-muted-foreground" />
                          <span className="font-medium truncate">{JSON.stringify((item as any).new_value)}</span>
                        </>
                      )}
                      {item.type === 'signal' && (() => {
                        const signalItem = item as SignalOccurrence & { type: 'signal'; timestamp: string };
                        const ruleName = signalItem.detection_rule_match?.detection_rule?.name || 'Unknown Signal';
                        const matchedPhrases = signalItem.matched_phrases || [];
                        const speakerType = signalItem.speaker_type || 'unknown';
                        const confidence = signalItem.confidence_score;
                        
                        return (
                          <HoverCard openDelay={150} closeDelay={100}>
                            <HoverCardTrigger asChild>
                              <div className="flex items-center gap-1.5 cursor-pointer hover:opacity-80 min-w-0">
                                <span className="font-medium truncate">{ruleName}</span>
                                {confidence && (
                                  <span className="text-[10px] text-muted-foreground">{Math.round(confidence * 100)}%</span>
                                )}
                                {speakerType && speakerType !== 'unknown' && (
                                  <Badge 
                                    variant="outline" 
                                    className={cn(
                                      "text-[10px] px-1 py-0 h-4",
                                      speakerType === 'external' && "border-green-500/50 text-green-600",
                                      speakerType === 'internal' && "border-blue-500/50 text-blue-600"
                                    )}
                                  >
                                    {speakerType === 'external' ? 'Cust' : 'Int'}
                                  </Badge>
                                )}
                              </div>
                            </HoverCardTrigger>
                            <HoverCardContent className="w-80" side="right">
                              <div className="space-y-2">
                                <div className="flex items-center gap-2">
                                  <AlertCircle className="w-4 h-4 text-amber-500" />
                                  <span className="font-semibold text-sm">Detection Diagnostics</span>
                                </div>
                                <div className="space-y-1.5 text-xs">
                                  <div><span className="text-muted-foreground">Rule:</span> <span className="ml-1">{ruleName}</span></div>
                                  <div><span className="text-muted-foreground">Speaker:</span> <span className="ml-1">{speakerType === 'external' ? 'Customer' : speakerType === 'internal' ? 'Internal' : 'Unknown'}</span></div>
                                  <div><span className="text-muted-foreground">Confidence:</span> <span className="ml-1">{confidence ? `${Math.round(confidence * 100)}%` : 'N/A'}</span></div>
                                  {matchedPhrases.length > 0 && (
                                    <div className="mt-1.5 pt-1.5 border-t">
                                      <div className="flex items-center gap-1 text-muted-foreground mb-1">
                                        <Quote className="w-3 h-3" />
                                        Matched Phrases:
                                      </div>
                                      <div className="max-h-24 overflow-y-auto space-y-0.5">
                                        {matchedPhrases.slice(0, 5).map((phrase, idx) => (
                                          <div key={idx} className="text-[10px] bg-muted/50 rounded px-1.5 py-0.5 border-l-2 border-chart-2">
                                            "{phrase}"
                                          </div>
                                        ))}
                                        {matchedPhrases.length > 5 && (
                                          <div className="text-[10px] text-muted-foreground">+{matchedPhrases.length - 5} more</div>
                                        )}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </HoverCardContent>
                          </HoverCard>
                        );
                      })()}
                      {item.type === 'stakeholder' && (() => {
                        const snapshot = item as StakeholderSnapshot & { type: 'stakeholder'; timestamp: string };
                        const contactName = snapshot.account_contact?.name || 'Unknown';
                        return (
                          <>
                            <span className="font-medium truncate">{contactName}</span>
                            {snapshot.sentiment !== null && <span className="text-[10px] text-muted-foreground">S:{snapshot.sentiment}%</span>}
                            {snapshot.champion_score !== null && <span className="text-[10px] text-muted-foreground">C:{snapshot.champion_score}%</span>}
                          </>
                        );
                      })()}
                      {item.type === 'readiness' && (() => {
                        const readinessItem = item as ReadinessHistoryEntry & { type: 'readiness'; timestamp: string };
                        const questionText = readinessItem.question?.question || 'Unknown Question';
                        const oldAnswer = typeof readinessItem.old_answer === 'object' ? readinessItem.old_answer?.answer || JSON.stringify(readinessItem.old_answer) : readinessItem.old_answer;
                        const newAnswer = typeof readinessItem.new_answer === 'object' ? readinessItem.new_answer?.answer || JSON.stringify(readinessItem.new_answer) : readinessItem.new_answer;
                        
                        return (
                          <>
                            <span className="truncate max-w-[200px]" title={questionText}>{questionText}</span>
                            <span className="text-muted-foreground truncate max-w-[60px]">{oldAnswer || 'null'}</span>
                            <ArrowRight className="w-3 h-3 shrink-0 text-muted-foreground" />
                            <span className="font-medium truncate max-w-[80px]">{newAnswer || 'null'}</span>
                            {readinessItem.new_score !== null && (
                              <span className="text-[10px] text-muted-foreground">{Math.round(readinessItem.new_score)}%</span>
                            )}
                          </>
                        );
                      })()}
                    </div>

                    {/* Attribution - who made the change */}
                    <div className="flex items-center gap-1 text-[10px] text-muted-foreground shrink-0">
                      {item.type === 'signal' && (
                        <span className="flex items-center gap-0.5">
                          <Bot className="w-3 h-3" />
                          <span>AI</span>
                        </span>
                      )}
                      {item.type === 'stakeholder' && (
                        <span className="flex items-center gap-0.5">
                          <Bot className="w-3 h-3" />
                          <span>AI</span>
                        </span>
                      )}
                      {item.type === 'stage' && (() => {
                        const stageItem = item as StageHistoryEntry & { type: 'stage'; timestamp: string };
                        const isAI = stageItem.change_source === 'transcript_analysis' || stageItem.change_source === 'signal_inferred';
                        const changerName = stageItem.changer?.display_name;
                        return (
                          <span className="flex items-center gap-0.5">
                            {isAI ? <Bot className="w-3 h-3" /> : <User className="w-3 h-3" />}
                            <span>{isAI ? 'AI' : changerName || 'User'}</span>
                          </span>
                        );
                      })()}
                      {item.type === 'metric' && (() => {
                        const metricItem = item as MetricHistoryEntry & { type: 'metric'; timestamp: string };
                        const isAI = metricItem.change_source === 'transcript_analysis' || metricItem.change_source === 'signal_inferred';
                        const changerName = metricItem.changer?.display_name;
                        return (
                          <span className="flex items-center gap-0.5">
                            {isAI ? <Bot className="w-3 h-3" /> : <User className="w-3 h-3" />}
                            <span>{isAI ? 'AI' : changerName || 'User'}</span>
                          </span>
                        );
                      })()}
                      {item.type === 'readiness' && (() => {
                        const readinessItem = item as ReadinessHistoryEntry & { type: 'readiness'; timestamp: string };
                        const isAI = readinessItem.change_source === 'transcript_ai' || readinessItem.change_source === 'ai';
                        const changerName = readinessItem.changer?.display_name;
                        return (
                          <span className="flex items-center gap-0.5">
                            {isAI ? <Bot className="w-3 h-3" /> : <User className="w-3 h-3" />}
                            <span>{isAI ? 'AI' : changerName || 'User'}</span>
                          </span>
                        );
                      })()}
                    </div>

                    {/* Timestamp */}
                    <span className="text-[10px] text-muted-foreground whitespace-nowrap shrink-0">
                      {formatDistanceToNow(new Date(item.timestamp), { addSuffix: true })}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

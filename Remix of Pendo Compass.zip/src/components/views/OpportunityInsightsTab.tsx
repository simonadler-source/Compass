import { useMemo, useState } from 'react';

import { AlertTriangle, Lightbulb, Zap, TrendingUp, TrendingDown, Target, Swords, Users, Shield, AlertCircle, Check, X, Layers, Loader2, RotateCcw, ArrowRight, Database, ExternalLink } from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useOpportunityTranscriptInsights } from '@/hooks/useOpportunityInsights';
import { useOpportunityCapturedInsights } from '@/hooks/useDetectionRules';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useCompetitiveAnalysis, getMaturityDescription, type FeatureComparison } from '@/hooks/useCompetitiveIntelligence';
import { fetchCompetitorsForAnalysis } from '@/hooks/useCompetitorsList';
import { ThemedInsightsPanel } from './ThemedInsightsPanel';
import { OpportunityMetricsSection } from './OpportunityMetricsSection';
import { format } from 'date-fns';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { OpportunityCompetitorManager } from '@/components/OpportunityCompetitorManager';

interface OpportunityInsightsTabProps {
  opportunityId: string;
  accountId: string;
}

interface ExtractedPerson {
  name: string;
  role: string | null;
  email: string | null;
  context: string;
}

interface NextBestAction {
  action: string;
  actionType: string;
  priority: string;
  reasoning: string;
}

interface CommercialInsight {
  insight: string;
  type: string;
  swotCategory: string;
  importance: string;
  context: string;
}

// Themed pain point structure from analysis
interface ThemedPainPoint {
  description: string;
  businessTheme: string;
  severity: 'high' | 'medium' | 'low';
  confidence: number;
}

// Themed use case structure from analysis
interface ThemedUseCase {
  description: string;
  businessTheme: string;
  priority: 'high' | 'medium' | 'low';
  confidence: number;
}

// Pain point can be a string or an object with description/severity/theme
type PainPointItem = string | { description?: string; pain_point?: string; painPoint?: string; severity?: string; businessTheme?: string; confidence?: number };
// Use case can be a string or an object with description/priority/theme
type UseCaseItem = string | { description?: string; use_case?: string; useCase?: string; priority?: string; businessTheme?: string; confidence?: number };

interface TranscriptInsights {
  painPoints?: PainPointItem[];
  useCases?: UseCaseItem[];
  competitorMentions?: string[];
  people?: ExtractedPerson[];
  nbas?: NextBestAction[];
  nextBestActions?: NextBestAction[];
  commercialInsights?: CommercialInsight[];
}

interface SwotItem {
  text: string;
  source: string;
  importance: 'high' | 'medium' | 'low';
  insightType?: string;
}

interface SwotAnalysis {
  strengths: SwotItem[];
  weaknesses: SwotItem[];
  opportunities: SwotItem[];
  threats: SwotItem[];
}

// Business theme metadata for display
const themeConfig: Record<string, { label: string; icon: typeof AlertTriangle; color: string }> = {
  operational_efficiency: { label: 'Operational Efficiency', icon: Zap, color: 'hsl(262 83% 58%)' },
  customer_experience: { label: 'Customer Experience', icon: Users, color: 'hsl(330 81% 60%)' },
  revenue_growth: { label: 'Revenue Growth', icon: TrendingUp, color: 'hsl(142 76% 36%)' },
  cost_reduction: { label: 'Cost Reduction', icon: TrendingDown, color: 'hsl(25 95% 53%)' },
  compliance_risk: { label: 'Compliance & Risk', icon: Shield, color: 'hsl(0 84% 60%)' },
  digital_transformation: { label: 'Digital Transformation', icon: Zap, color: 'hsl(199 89% 48%)' },
  data_insights: { label: 'Data & Insights', icon: Target, color: 'hsl(221 83% 53%)' },
  team_productivity: { label: 'Team Productivity', icon: Users, color: 'hsl(38 92% 50%)' },
};

// SWOT category colors
const swotColors = {
  strengths: { bg: 'hsl(142, 70%, 40%)', light: 'hsl(142, 50%, 94%)', text: 'hsl(142, 70%, 25%)' },
  weaknesses: { bg: 'hsl(0, 70%, 45%)', light: 'hsl(0, 50%, 95%)', text: 'hsl(0, 70%, 30%)' },
  opportunities: { bg: 'hsl(199, 89%, 48%)', light: 'hsl(199, 50%, 94%)', text: 'hsl(199, 89%, 30%)' },
  threats: { bg: 'hsl(25, 80%, 45%)', light: 'hsl(25, 50%, 94%)', text: 'hsl(25, 80%, 30%)' },
};

// SWOT Cluster Chart Component
function SwotClusterChart({ swot }: { swot: SwotAnalysis }) {
  const [hoveredItem, setHoveredItem] = useState<{ category: string; item: SwotItem } | null>(null);
  
  const totalItems = swot.strengths.length + swot.weaknesses.length + swot.opportunities.length + swot.threats.length;
  
  const chartWidth = 600;
  const chartHeight = 400;
  const quadrantWidth = chartWidth / 2;
  const quadrantHeight = chartHeight / 2;

  const clusters = useMemo(() => {
    if (totalItems === 0) return null;

    const seededRandom = (seed: number) => {
      const x = Math.sin(seed) * 10000;
      return x - Math.floor(x);
    };

    const getClusterPositions = (items: SwotItem[], centerX: number, centerY: number, radius: number, seedOffset: number) => {
      return items.map((item, idx) => {
        const seed = seedOffset + idx * 17;
        const angle = (idx / Math.max(items.length, 1)) * Math.PI * 0.8 - Math.PI * 0.4;
        const distance = radius * (0.3 + seededRandom(seed) * 0.6);
        return {
          item,
          x: centerX + Math.cos(angle) * distance,
          y: centerY + Math.sin(angle) * distance,
          size: item.importance === 'high' ? 40 : item.importance === 'medium' ? 30 : 20,
        };
      });
    };

    return {
      strengths: getClusterPositions(swot.strengths, quadrantWidth * 0.5, quadrantHeight * 0.5, 80, 100),
      weaknesses: getClusterPositions(swot.weaknesses, quadrantWidth * 1.5, quadrantHeight * 0.5, 80, 200),
      opportunities: getClusterPositions(swot.opportunities, quadrantWidth * 0.5, quadrantHeight * 1.5, 80, 300),
      threats: getClusterPositions(swot.threats, quadrantWidth * 1.5, quadrantHeight * 1.5, 80, 400),
    };
  }, [swot, totalItems, quadrantWidth, quadrantHeight]);
  
  if (totalItems === 0 || !clusters) {
    return (
      <div className="flex items-center justify-center h-[400px] text-muted-foreground">
        No SWOT data available
      </div>
    );
  }

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-[400px]">
        <rect x="0" y="0" width={quadrantWidth} height={quadrantHeight} fill={swotColors.strengths.light} />
        <rect x={quadrantWidth} y="0" width={quadrantWidth} height={quadrantHeight} fill={swotColors.weaknesses.light} />
        <rect x="0" y={quadrantHeight} width={quadrantWidth} height={quadrantHeight} fill={swotColors.opportunities.light} />
        <rect x={quadrantWidth} y={quadrantHeight} width={quadrantWidth} height={quadrantHeight} fill={swotColors.threats.light} />
        
        <line x1={quadrantWidth} y1="0" x2={quadrantWidth} y2={chartHeight} stroke="hsl(var(--border))" strokeWidth="2" />
        <line x1="0" y1={quadrantHeight} x2={chartWidth} y2={quadrantHeight} stroke="hsl(var(--border))" strokeWidth="2" />
        
        <text x="20" y="30" fontSize="14" fontWeight="600" fill={swotColors.strengths.text}>Strengths ({swot.strengths.length})</text>
        <text x={quadrantWidth + 20} y="30" fontSize="14" fontWeight="600" fill={swotColors.weaknesses.text}>Weaknesses ({swot.weaknesses.length})</text>
        <text x="20" y={quadrantHeight + 30} fontSize="14" fontWeight="600" fill={swotColors.opportunities.text}>Opportunities ({swot.opportunities.length})</text>
        <text x={quadrantWidth + 20} y={quadrantHeight + 30} fontSize="14" fontWeight="600" fill={swotColors.threats.text}>Threats ({swot.threats.length})</text>
        
        {Object.entries(clusters).map(([category, positions]) => 
          positions.map((pos, idx) => (
            <g key={`${category}-${idx}`}>
              <circle
                cx={pos.x}
                cy={pos.y}
                r={pos.size / 2}
                fill={swotColors[category as keyof typeof swotColors].bg}
                opacity={0.7}
                className="cursor-pointer transition-all duration-200 hover:opacity-100"
                onMouseEnter={() => setHoveredItem({ category, item: pos.item })}
                onMouseLeave={() => setHoveredItem(null)}
              />
              <text
                x={pos.x}
                y={pos.y}
                textAnchor="middle"
                dominantBaseline="central"
                fontSize="10"
                fill="white"
                className="pointer-events-none"
              >
                {idx + 1}
              </text>
            </g>
          ))
        )}
        
        <text x={chartWidth / 2} y="15" textAnchor="middle" fontSize="11" fill="hsl(var(--muted-foreground))">Internal ↔ External</text>
        <text x="10" y={chartHeight / 2} textAnchor="start" fontSize="11" fill="hsl(var(--muted-foreground))" transform={`rotate(-90 10 ${chartHeight / 2})`}>Positive ↔ Negative</text>
      </svg>
      
      {hoveredItem && (
        <div className="absolute top-4 right-4 max-w-[250px] p-3 rounded-lg shadow-lg border border-border bg-background z-10">
          <div 
            className="text-xs font-semibold uppercase mb-1"
            style={{ color: swotColors[hoveredItem.category as keyof typeof swotColors].bg }}
          >
            {hoveredItem.category}
          </div>
          <p className="text-sm">{hoveredItem.item.text}</p>
          <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
            <span>Source: {hoveredItem.item.source}</span>
            <Badge variant="outline" className="text-xs py-0">
              {hoveredItem.item.importance}
            </Badge>
          </div>
        </div>
      )}
    </div>
  );
}

// Competitor Differentiators Card
function CompetitorDifferentiatorsCard({ 
  competitorNames, 
  competitiveData,
  opportunityId,
  accountId,
}: { 
  competitorNames: string[];
  competitiveData: { strengths: FeatureComparison[]; threats: FeatureComparison[]; opportunities: FeatureComparison[] } | undefined;
  opportunityId: string;
  accountId: string;
}) {
  const topStrengths = competitiveData?.strengths?.slice(0, 3) || [];
  const topThreats = competitiveData?.threats?.slice(0, 2) || [];

  return (
    <div className="glass rounded-xl p-5 space-y-4">
      <h3 className="font-semibold text-foreground flex items-center gap-2">
        <Swords className="w-4 h-4 text-orange-500" />
        Competitive Positioning
      </h3>
      
      {/* Mentioned Competitors - with add/remove capability */}
      <div>
        <p className="text-xs text-muted-foreground mb-2">Competitors in this opportunity</p>
        <OpportunityCompetitorManager
          opportunityId={opportunityId}
          accountId={accountId}
          mentionedCompetitors={competitorNames}
        />
      </div>

      {/* Pendo Advantages */}
      {topStrengths.length > 0 && (
        <div className="pt-3 border-t border-border">
          <p className="text-xs font-medium text-green-600 mb-2 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            Pendo Advantages
          </p>
          <ul className="space-y-2">
            {topStrengths.map((comp, idx) => (
              <li key={idx} className="text-xs flex items-start gap-2">
                <Check className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
                <div>
                  <span className="font-medium">{comp.featureName}</span>
                  <span className="text-muted-foreground"> vs {comp.competitorName}: </span>
                  <span className="text-green-600">+{comp.pendoAdvantage} advantage</span>
                  <span className="text-muted-foreground"> ({comp.pendoScore}/5 vs {comp.competitorScore}/5)</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Areas to Address */}
      {topThreats.length > 0 && (
        <div className="pt-3 border-t border-border">
          <p className="text-xs font-medium text-amber-600 mb-2 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            Areas to Address
          </p>
          <ul className="space-y-2">
            {topThreats.map((comp, idx) => (
              <li key={idx} className="text-xs flex items-start gap-2">
                <X className="w-3 h-3 text-amber-500 mt-0.5 flex-shrink-0" />
                <div>
                  <span className="font-medium">{comp.featureName}</span>
                  <span className="text-muted-foreground">: {comp.competitorName} leads </span>
                  <span className="text-amber-600">({comp.competitorScore}/5 vs {comp.pendoScore}/5)</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}

      {!competitiveData?.strengths?.length && !competitiveData?.threats?.length && competitorNames.length > 0 && (
        <p className="text-xs text-muted-foreground italic">
          No competitive intelligence available for these competitors
        </p>
      )}
    </div>
  );
}

export function OpportunityInsightsTab({ opportunityId, accountId }: OpportunityInsightsTabProps) {
  const { data: transcripts, isLoading } = useOpportunityTranscriptInsights(opportunityId);
  const { data: capturedInsights, isLoading: loadingCaptured } = useOpportunityCapturedInsights(opportunityId);
  const [insightsView, setInsightsView] = useState<'overview' | 'swot'>('overview');
  const [showAllChallenges, setShowAllChallenges] = useState(false);
  const [showAllOutcomes, setShowAllOutcomes] = useState(false);
  const [showCapturedInsights, setShowCapturedInsights] = useState(true);

  // Fetch manually added competitors for this opportunity
  const { data: manualCompetitors } = useQuery({
    queryKey: ['opportunity-manual-competitors', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('product_mentions')
        .select('id, product_name')
        .eq('opportunity_id', opportunityId)
        .eq('mention_type', 'competitive')
        .eq('is_manual', true)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []).map((d: any) => d.product_name as string);
    },
  });

  // Group captured insights by rule name
  const groupedCapturedInsights = useMemo(() => {
    if (!capturedInsights) return {};
    return capturedInsights.reduce((acc, insight) => {
      const ruleName = (insight.capture_field as any)?.rule?.name || 'Other';
      if (!acc[ruleName]) acc[ruleName] = [];
      acc[ruleName].push(insight);
      return acc;
    }, {} as Record<string, any[]>);
  }, [capturedInsights]);

  // Aggregate insights from all transcripts - now with themed data
  const aggregatedInsights = useMemo(() => {
    if (!transcripts) return null;

    const themedPainPoints: ThemedPainPoint[] = [];
    const themedUseCases: ThemedUseCase[] = [];
    const plainPainPoints: string[] = [];
    const plainUseCases: string[] = [];
    const competitors: string[] = [];
    const people: ExtractedPerson[] = [];
    const nbas: NextBestAction[] = [];
    const commercialInsights: CommercialInsight[] = [];

    transcripts.forEach(transcript => {
      const insights = transcript.extracted_insights as unknown as TranscriptInsights | null;
      if (!insights) return;

      // Extract pain points - preserve theme if available
      (insights.painPoints || []).forEach((pp) => {
        if (typeof pp === 'string') {
          plainPainPoints.push(pp);
        } else {
          const text = pp?.description || (pp as any)?.painPoint || pp?.pain_point || '';
          if (text) {
            if (pp?.businessTheme) {
              themedPainPoints.push({
                description: text,
                businessTheme: pp.businessTheme,
                severity: (pp?.severity as 'high' | 'medium' | 'low') || 'medium',
                confidence: pp?.confidence || 0.7,
              });
            } else {
              plainPainPoints.push(text);
            }
          }
        }
      });

      // Extract use cases - preserve theme if available
      (insights.useCases || []).forEach((uc) => {
        if (typeof uc === 'string') {
          plainUseCases.push(uc);
        } else {
          const text = uc?.description || (uc as any)?.useCase || uc?.use_case || '';
          if (text) {
            if (uc?.businessTheme) {
              themedUseCases.push({
                description: text,
                businessTheme: uc.businessTheme,
                priority: (uc?.priority as 'high' | 'medium' | 'low') || 'medium',
                confidence: uc?.confidence || 0.7,
              });
            } else {
              plainUseCases.push(text);
            }
          }
        }
      });

      competitors.push(...(insights.competitorMentions || []));
      people.push(...(insights.people || []));
      nbas.push(...(insights.nbas || insights.nextBestActions || []));
      commercialInsights.push(...(insights.commercialInsights || []));
    });

    // Dedupe themed items by description
    const dedupedPains = themedPainPoints.filter(pp => pp.description).reduce((acc, pp) => {
      if (!acc.find(existing => existing.description?.toLowerCase() === pp.description?.toLowerCase())) {
        acc.push(pp);
      }
      return acc;
    }, [] as ThemedPainPoint[]);

    const dedupedUseCases = themedUseCases.filter(uc => uc.description).reduce((acc, uc) => {
      if (!acc.find(existing => existing.description?.toLowerCase() === uc.description?.toLowerCase())) {
        acc.push(uc);
      }
      return acc;
    }, [] as ThemedUseCase[]);

    // Group by theme
    const painsByTheme = dedupedPains.reduce((acc, pp) => {
      const theme = pp.businessTheme || 'other';
      if (!acc[theme]) acc[theme] = [];
      acc[theme].push(pp);
      return acc;
    }, {} as Record<string, ThemedPainPoint[]>);

    const useCasesByTheme = dedupedUseCases.reduce((acc, uc) => {
      const theme = uc.businessTheme || 'other';
      if (!acc[theme]) acc[theme] = [];
      acc[theme].push(uc);
      return acc;
    }, {} as Record<string, ThemedUseCase[]>);

    return {
      painsByTheme,
      useCasesByTheme,
      themedPainPoints: dedupedPains,
      themedUseCases: dedupedUseCases,
      plainPainPoints: [...new Set(plainPainPoints)],
      plainUseCases: [...new Set(plainUseCases)],
      competitors: [...new Set(competitors.filter((c): c is string => typeof c === 'string'))],
      people: people.filter(p => p && typeof p.name === 'string').reduce((acc, p) => {
        if (!acc.find(existing => existing.name.toLowerCase() === p.name.toLowerCase())) {
          acc.push(p);
        }
        return acc;
      }, [] as ExtractedPerson[]),
      nbas: nbas.reduce((acc, nba) => {
        if (!acc.find(existing => existing.action === nba.action)) {
          acc.push(nba);
        }
        return acc;
      }, [] as NextBestAction[]),
      commercialInsights: commercialInsights.reduce((acc, ci) => {
        if (!acc.find(existing => existing.insight === ci.insight)) {
          acc.push(ci);
        }
        return acc;
      }, [] as CommercialInsight[]),
      transcriptCount: transcripts.length,
    };
  }, [transcripts]);

  // Merge AI-extracted + manually added competitors
  const allCompetitorNames = useMemo(() => {
    const aiNames = (aggregatedInsights?.competitors || []).filter(n => typeof n === 'string').map(n => n.toLowerCase());
    const manualNames = (manualCompetitors || []).filter(n => typeof n === 'string').map(n => n.toLowerCase());
    const combined = new Set([...aiNames, ...manualNames]);
    return Array.from(combined).map(n => n.charAt(0).toUpperCase() + n.slice(1));
  }, [aggregatedInsights?.competitors, manualCompetitors]);

  // Fetch competitive analysis using merged competitor list
  const { data: competitiveData } = useCompetitiveAnalysis(allCompetitorNames);

  // Build SWOT from commercial insights + competitive intelligence
  const swot = useMemo((): SwotAnalysis => {
    const result: SwotAnalysis = { strengths: [], weaknesses: [], opportunities: [], threats: [] };
    
    // Add from commercial insights
    if (aggregatedInsights?.commercialInsights) {
      aggregatedInsights.commercialInsights.forEach(insight => {
        const category = insight.swotCategory?.toLowerCase();
        const swotItem: SwotItem = {
          text: insight.insight,
          source: insight.type || 'transcript',
          importance: (insight.importance as 'high' | 'medium' | 'low') || 'medium',
          insightType: insight.type,
        };
        
        if (category === 'strength') result.strengths.push(swotItem);
        else if (category === 'weakness') result.weaknesses.push(swotItem);
        else if (category === 'opportunity') result.opportunities.push(swotItem);
        else if (category === 'threat') result.threats.push(swotItem);
      });
    }

    // Enrich with competitive intelligence
    if (competitiveData?.strengths) {
      competitiveData.strengths.slice(0, 5).forEach((comp: FeatureComparison) => {
        result.strengths.push({
          text: `${comp.featureName}: Pendo scores ${comp.pendoScore}/5 vs ${comp.competitorName}'s ${comp.competitorScore}/5 (+${comp.pendoAdvantage} advantage)`,
          source: `Competitive Analysis - ${comp.categoryName}`,
          importance: comp.pendoAdvantage >= 3 ? 'high' : 'medium',
        });
      });
    }

    if (competitiveData?.threats) {
      competitiveData.threats.slice(0, 5).forEach((comp: FeatureComparison) => {
        result.threats.push({
          text: `${comp.competitorName} leads in ${comp.featureName} (${comp.competitorScore}/5 vs Pendo's ${comp.pendoScore}/5)`,
          source: `Competitive Analysis - ${comp.categoryName}`,
          importance: comp.pendoAdvantage <= -3 ? 'high' : 'medium',
        });
      });
    }

    if (competitiveData?.opportunities) {
      competitiveData.opportunities.slice(0, 3).forEach((comp: FeatureComparison) => {
        result.opportunities.push({
          text: `Opportunity to demonstrate ${comp.featureName} - Pendo at ${comp.pendoScore}/5, room to showcase ${getMaturityDescription(comp.pendoScore, comp)} capabilities`,
          source: `Competitive Positioning - ${comp.categoryName}`,
          importance: 'medium',
        });
      });
    }

    return result;
  }, [aggregatedInsights, competitiveData]);

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-32" />
        <Skeleton className="h-48" />
        <Skeleton className="h-32" />
      </div>
    );
  }

  if (!transcripts?.length) {
    return (
      <div className="p-6">
        <div className="glass rounded-xl p-8 text-center border-2 border-dashed border-border">
          <Lightbulb className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No analyzed transcripts for this opportunity</p>
          <p className="text-sm text-muted-foreground mt-1">
            Link transcripts and analyze them to see extracted insights here
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header with view toggle */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Opportunity Insights</h2>
          <p className="text-sm text-muted-foreground">
            Aggregated from {aggregatedInsights?.transcriptCount || 0} analyzed transcript{(aggregatedInsights?.transcriptCount || 0) !== 1 ? 's' : ''}
          </p>
        </div>
        <Tabs value={insightsView} onValueChange={(v) => setInsightsView(v as 'overview' | 'swot')}>
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="swot">SWOT Analysis</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {insightsView === 'swot' ? (
        <div className="space-y-6">
          {/* SWOT Cluster Chart */}
          <div className="glass rounded-xl p-5">
            <h3 className="font-semibold text-foreground mb-4">SWOT Cluster Chart</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Hover over bubbles to see details. Size indicates importance.
            </p>
            <SwotClusterChart swot={swot} />
          </div>

          {/* SWOT Grid */}
          <div className="grid grid-cols-2 gap-4">
            {/* Strengths */}
            <div className="rounded-lg p-4" style={{ backgroundColor: swotColors.strengths.light }}>
              <h4 className="font-semibold text-sm flex items-center gap-2 mb-3" style={{ color: swotColors.strengths.text }}>
                <TrendingUp className="w-4 h-4" />
                Strengths ({swot.strengths.length})
              </h4>
              <ul className="space-y-2">
                {swot.strengths.map((item, idx) => (
                  <li key={idx} className="text-xs" style={{ color: swotColors.strengths.text }}>
                    <span className="font-medium">{idx + 1}.</span> {item.text}
                  </li>
                ))}
                {swot.strengths.length === 0 && (
                  <li className="text-xs text-muted-foreground italic">No strengths identified</li>
                )}
              </ul>
            </div>

            {/* Weaknesses */}
            <div className="rounded-lg p-4" style={{ backgroundColor: swotColors.weaknesses.light }}>
              <h4 className="font-semibold text-sm flex items-center gap-2 mb-3" style={{ color: swotColors.weaknesses.text }}>
                <TrendingDown className="w-4 h-4" />
                Weaknesses ({swot.weaknesses.length})
              </h4>
              <ul className="space-y-2">
                {swot.weaknesses.map((item, idx) => (
                  <li key={idx} className="text-xs" style={{ color: swotColors.weaknesses.text }}>
                    <span className="font-medium">{idx + 1}.</span> {item.text}
                  </li>
                ))}
                {swot.weaknesses.length === 0 && (
                  <li className="text-xs text-muted-foreground italic">No weaknesses identified</li>
                )}
              </ul>
            </div>

            {/* Opportunities */}
            <div className="rounded-lg p-4" style={{ backgroundColor: swotColors.opportunities.light }}>
              <h4 className="font-semibold text-sm flex items-center gap-2 mb-3" style={{ color: swotColors.opportunities.text }}>
                <Lightbulb className="w-4 h-4" />
                Opportunities ({swot.opportunities.length})
              </h4>
              <ul className="space-y-2">
                {swot.opportunities.map((item, idx) => (
                  <li key={idx} className="text-xs" style={{ color: swotColors.opportunities.text }}>
                    <span className="font-medium">{idx + 1}.</span> {item.text}
                  </li>
                ))}
                {swot.opportunities.length === 0 && (
                  <li className="text-xs text-muted-foreground italic">No opportunities identified</li>
                )}
              </ul>
            </div>

            {/* Threats */}
            <div className="rounded-lg p-4" style={{ backgroundColor: swotColors.threats.light }}>
              <h4 className="font-semibold text-sm flex items-center gap-2 mb-3" style={{ color: swotColors.threats.text }}>
                <AlertTriangle className="w-4 h-4" />
                Threats ({swot.threats.length})
              </h4>
              <ul className="space-y-2">
                {swot.threats.map((item, idx) => (
                  <li key={idx} className="text-xs" style={{ color: swotColors.threats.text }}>
                    <span className="font-medium">{idx + 1}.</span> {item.text}
                  </li>
                ))}
                {swot.threats.length === 0 && (
                  <li className="text-xs text-muted-foreground italic">No threats identified</li>
                )}
              </ul>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Strategic Themes - Challenges & Initiatives */}
          <ThemedInsightsPanel accountId={accountId} opportunityId={opportunityId} />

          {/* Current vs Future State - Matching original visual style */}
          {((aggregatedInsights?.themedPainPoints?.length || 0) + (aggregatedInsights?.plainPainPoints?.length || 0) > 0 ||
            (aggregatedInsights?.themedUseCases?.length || 0) + (aggregatedInsights?.plainUseCases?.length || 0) > 0) && (
            <div className="glass rounded-xl p-5 space-y-4">
              <h3 className="font-semibold text-foreground flex items-center gap-2">
                <Layers className="w-4 h-4 text-primary" />
                Current vs Future State
              </h3>
              
              <div className="grid md:grid-cols-2 gap-4 relative">
                {/* Current State - Challenges (Red Card) */}
                {(() => {
                  const allChallenges = [
                    ...(aggregatedInsights?.themedPainPoints || []).map(pp => pp.description),
                    ...(aggregatedInsights?.plainPainPoints || [])
                  ];
                  const visibleChallenges = showAllChallenges ? allChallenges : allChallenges.slice(0, 6);
                  const remainingCount = allChallenges.length - 6;
                  
                  return (
                    <div className="rounded-lg border border-red-200 bg-red-50/50 dark:bg-red-950/20 dark:border-red-900/30 p-4 space-y-3">
                      <h4 className="text-sm font-semibold text-red-700 dark:text-red-400 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4" />
                        Current State — Challenges
                      </h4>
                      <div className="space-y-3">
                        {visibleChallenges.map((pain, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-sm">
                            <X className="w-3.5 h-3.5 text-red-500 mt-0.5 flex-shrink-0" />
                            <span className="text-foreground/90 leading-relaxed">{pain}</span>
                          </div>
                        ))}
                        {allChallenges.length === 0 && (
                          <p className="text-xs text-muted-foreground italic">No challenges identified yet</p>
                        )}
                        {remainingCount > 0 && (
                          <button
                            onClick={() => setShowAllChallenges(!showAllChallenges)}
                            className="text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer mt-2"
                          >
                            {showAllChallenges ? 'Show less' : `+${remainingCount} more challenges identified`}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })()}

                {/* Center Arrow */}
                <div className="hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
                  <div className="bg-background rounded-full p-2 border border-border shadow-sm">
                    <ArrowRight className="w-4 h-4 text-primary" />
                  </div>
                </div>

                {/* Future State - Potential Outcomes (Green Card) */}
                {(() => {
                  const allOutcomes = [
                    ...(aggregatedInsights?.themedUseCases || []).map(uc => uc.description),
                    ...(aggregatedInsights?.plainUseCases || [])
                  ];
                  const visibleOutcomes = showAllOutcomes ? allOutcomes : allOutcomes.slice(0, 6);
                  const remainingCount = allOutcomes.length - 6;
                  
                  return (
                    <div className="rounded-lg border border-green-200 bg-green-50/50 dark:bg-green-950/20 dark:border-green-900/30 p-4 space-y-3">
                      <h4 className="text-sm font-semibold text-green-700 dark:text-green-400 flex items-center gap-2">
                        <TrendingUp className="w-4 h-4" />
                        Future State — Potential Outcomes
                      </h4>
                      <div className="space-y-3">
                        {visibleOutcomes.map((uc, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-sm">
                            <Check className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />
                            <span className="text-foreground/90 leading-relaxed">{uc}</span>
                          </div>
                        ))}
                        {allOutcomes.length === 0 && (
                          <p className="text-xs text-muted-foreground italic">No outcomes identified yet</p>
                        )}
                        {remainingCount > 0 && (
                          <button
                            onClick={() => setShowAllOutcomes(!showAllOutcomes)}
                            className="text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer mt-2"
                          >
                            {showAllOutcomes ? 'Show less' : `+${remainingCount} more potential outcomes`}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })()}
              </div>
            </div>
          )}

          {/* Competitor Differentiators Card - always show for competitor management */}
          <CompetitorDifferentiatorsCard 
            competitorNames={allCompetitorNames}
            competitiveData={competitiveData}
            opportunityId={opportunityId}
            accountId={accountId}
          />

          {/* Key People */}
          {aggregatedInsights?.people && aggregatedInsights.people.length > 0 && (
            <div className="glass rounded-xl p-5 space-y-3">
              <h3 className="font-semibold text-foreground flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" />
                Key People
              </h3>
              <div className="grid gap-3 md:grid-cols-2">
                {aggregatedInsights.people.map((person, i) => (
                  <div key={i} className="bg-muted/30 rounded-lg p-3">
                    <div className="font-medium text-sm">{person.name}</div>
                    {person.role && (
                      <div className="text-xs text-primary mt-0.5">{person.role}</div>
                    )}
                    {person.email && (
                      <div className="text-xs text-muted-foreground mt-1">{person.email}</div>
                    )}
                    {person.context && (
                      <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{person.context}</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Extracted Metrics Section */}
          <OpportunityMetricsSection 
            accountId={accountId} 
            opportunityId={opportunityId} 
          />

          {/* Captured Insights from Detection Rules */}
          {capturedInsights && capturedInsights.length > 0 && (
            <Collapsible open={showCapturedInsights} onOpenChange={setShowCapturedInsights}>
              <div className="glass rounded-xl p-5 space-y-3">
                <CollapsibleTrigger asChild>
                  <div className="flex items-center justify-between cursor-pointer group">
                    <h3 className="font-semibold text-foreground flex items-center gap-2">
                      <Database className="w-4 h-4 text-primary" />
                      Captured Insights
                      <Badge variant="secondary" className="text-xs">{capturedInsights.length}</Badge>
                    </h3>
                    <Badge variant="outline" className="text-xs group-hover:bg-muted transition-colors">
                      {showCapturedInsights ? 'Collapse' : 'Expand'}
                    </Badge>
                  </div>
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-2">
                  <div className="space-y-4">
                    {Object.entries(groupedCapturedInsights).map(([ruleName, insights]) => {
                      // Get unique field names to use as column headers
                      const fieldNames = [...new Set((insights as any[]).map(i => i.capture_field?.field_name).filter(Boolean))];
                      
                      // Group by source transcript to show one row per transcript
                      const byTranscript = (insights as any[]).reduce((acc, insight) => {
                        const transcriptId = insight.source_transcript?.id || 'unknown';
                        if (!acc[transcriptId]) {
                          acc[transcriptId] = {
                            transcript: insight.source_transcript,
                            date: insight.extracted_at,
                            fields: {}
                          };
                        }
                        const fieldName = insight.capture_field?.field_name;
                        if (fieldName) {
                          const displayValue = insight.value_json 
                            ? (Array.isArray(insight.value_json) 
                                ? insight.value_json.map((v: any) => typeof v === 'string' ? v : JSON.stringify(v)).join(', ')
                                : JSON.stringify(insight.value_json))
                            : (insight.value || '—');
                          acc[transcriptId].fields[fieldName] = {
                            value: displayValue,
                            confidence: insight.confidence_score
                          };
                        }
                        return acc;
                      }, {} as Record<string, { transcript: any; date: string; fields: Record<string, { value: string; confidence: number | null }> }>);
                      
                      return (
                        <div key={ruleName} className="space-y-1.5">
                          <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{ruleName}</h4>
                          <div className="rounded-lg border border-border/50 overflow-hidden">
                            <table className="w-full text-sm">
                              <thead>
                                <tr className="bg-muted/40 border-b border-border/50">
                                  {fieldNames.map(name => (
                                    <th key={name} className="px-3 py-2 text-left font-medium text-muted-foreground">
                                      {name}
                                    </th>
                                  ))}
                                  <th className="px-3 py-2 text-left font-medium text-muted-foreground w-20">Date</th>
                                  <th className="px-3 py-2 w-8"></th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-border/50">
                                {Object.entries(byTranscript).map(([transcriptId, rowData]) => {
                                  const row = rowData as { transcript: any; date: string; fields: Record<string, { value: string; confidence: number | null }> };
                                  return (
                                    <tr key={transcriptId} className="hover:bg-muted/20">
                                      {fieldNames.map(name => {
                                        const field = row.fields[name];
                                        return (
                                          <td key={name} className="px-3 py-2 text-foreground/80">
                                            <div className="flex items-center gap-1.5">
                                              <span className="truncate max-w-[200px]" title={field?.value}>
                                                {field?.value || '—'}
                                              </span>
                                              {field?.confidence && (
                                                <Badge variant="secondary" className="text-[10px] shrink-0">
                                                  {Math.round(field.confidence * 100)}%
                                                </Badge>
                                              )}
                                            </div>
                                          </td>
                                        );
                                      })}
                                      <td className="px-3 py-2 text-xs text-muted-foreground">
                                        {format(new Date(row.date), 'MMM d')}
                                      </td>
                                      <td className="px-3 py-2">
                                        {row.transcript && (
                                          <a 
                                            href={`/transcripts?id=${row.transcript.id}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-muted-foreground hover:text-primary"
                                            title={row.transcript.file_name || 'View transcript'}
                                          >
                                            <ExternalLink className="w-3.5 h-3.5" />
                                          </a>
                                        )}
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CollapsibleContent>
              </div>
            </Collapsible>
          )}

        </>
      )}
    </div>
  );
}

import { useMemo, useState } from 'react';
import { BarChart3, TrendingUp, User, Calendar, FileText, ChevronDown, ChevronRight, AlertCircle, Check, Plus, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useAccountMetrics, useDeleteAccountMetric, type AccountMetric } from '@/hooks/useAccountMetrics';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { AddMetricDialog } from '@/components/dialogs/AddMetricDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
interface OpportunityMetricsSectionProps {
  accountId: string;
  opportunityId?: string;
  showAccountRollup?: boolean;
}

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  'Usage': <BarChart3 className="w-4 h-4" />,
  'Cost/Financial': <TrendingUp className="w-4 h-4" />,
  'Time/Efficiency': <Calendar className="w-4 h-4" />,
  'Performance': <TrendingUp className="w-4 h-4" />,
  'Support/Service': <FileText className="w-4 h-4" />,
  'Adoption': <User className="w-4 h-4" />,
  'Revenue': <TrendingUp className="w-4 h-4" />,
};

const CATEGORY_COLORS: Record<string, string> = {
  'Usage': 'bg-blue-500/10 text-blue-500 border-blue-500/30',
  'Cost/Financial': 'bg-green-500/10 text-green-500 border-green-500/30',
  'Time/Efficiency': 'bg-purple-500/10 text-purple-500 border-purple-500/30',
  'Performance': 'bg-orange-500/10 text-orange-500 border-orange-500/30',
  'Support/Service': 'bg-yellow-500/10 text-yellow-500 border-yellow-500/30',
  'Adoption': 'bg-cyan-500/10 text-cyan-500 border-cyan-500/30',
  'Revenue': 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30',
};

function normalizeCategory(category: string): string {
  const normalized = category.toLowerCase();
  if (normalized.includes('usage') || normalized.includes('user') || normalized.includes('licensing')) return 'Usage';
  if (normalized.includes('cost') || normalized.includes('financial') || normalized.includes('budget') || normalized.includes('price')) return 'Cost/Financial';
  if (normalized.includes('time') || normalized.includes('efficiency') || normalized.includes('duration')) return 'Time/Efficiency';
  if (normalized.includes('performance') || normalized.includes('sla') || normalized.includes('uptime')) return 'Performance';
  if (normalized.includes('support') || normalized.includes('service') || normalized.includes('ticket')) return 'Support/Service';
  if (normalized.includes('adoption') || normalized.includes('engagement') || normalized.includes('retention')) return 'Adoption';
  if (normalized.includes('revenue') || normalized.includes('sales') || normalized.includes('deal')) return 'Revenue';
  return category;
}

export function OpportunityMetricsSection({ 
  accountId, 
  opportunityId,
  showAccountRollup = false 
}: OpportunityMetricsSectionProps) {
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set(['Usage', 'Cost/Financial']));
  
  // Fetch opportunity-specific metrics or all account metrics
  const { data: metrics, isLoading } = useAccountMetrics(
    accountId, 
    showAccountRollup ? undefined : opportunityId
  );

  // Group metrics by normalized category
  const groupedMetrics = useMemo(() => {
    if (!metrics) return {};
    
    const groups: Record<string, AccountMetric[]> = {};
    
    for (const metric of metrics) {
      const category = normalizeCategory(metric.metric_category);
      if (!groups[category]) {
        groups[category] = [];
      }
      groups[category].push(metric);
    }
    
    // Sort each group by created_at descending
    for (const category of Object.keys(groups)) {
      groups[category].sort((a, b) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );
    }
    
    return groups;
  }, [metrics]);

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(category)) {
        next.delete(category);
      } else {
        next.add(category);
      }
      return next;
    });
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <BarChart3 className="w-5 h-5" />
            Extracted Metrics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const totalMetrics = metrics?.length || 0;
  const categoriesWithMetrics = Object.keys(groupedMetrics);

  if (totalMetrics === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-lg">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Extracted Metrics
            </div>
            <AddMetricDialog 
              accountId={accountId} 
              opportunityId={opportunityId}
              trigger={
                <Button variant="outline" size="sm" className="gap-1.5 h-7">
                  <Plus className="w-3.5 h-3.5" />
                  Add
                </Button>
              }
            />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground italic">
            No metrics extracted yet. Metrics like user counts, costs, time savings, and percentages will appear here as they're mentioned in transcripts.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between text-lg">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Extracted Metrics
            <Badge variant="secondary">
              {totalMetrics}
            </Badge>
          </div>
          <AddMetricDialog 
            accountId={accountId} 
            opportunityId={opportunityId}
            trigger={
              <Button variant="outline" size="sm" className="gap-1.5 h-7">
                <Plus className="w-3.5 h-3.5" />
                Add
              </Button>
            }
          />
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {categoriesWithMetrics.map(category => (
          <Collapsible
            key={category}
            open={expandedCategories.has(category)}
            onOpenChange={() => toggleCategory(category)}
          >
            <CollapsibleTrigger asChild>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-between p-3 h-auto",
                  CATEGORY_COLORS[category] || 'bg-muted/50'
                )}
              >
                <div className="flex items-center gap-2">
                  {CATEGORY_ICONS[category] || <BarChart3 className="w-4 h-4" />}
                  <span className="font-medium">{category}</span>
                  <Badge variant="outline" className="text-xs">
                    {groupedMetrics[category].length}
                  </Badge>
                </div>
                {expandedCategories.has(category) ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="pt-2 pl-4 space-y-2">
              {groupedMetrics[category].map(metric => (
                <MetricRow key={metric.id} metric={metric} />
              ))}
            </CollapsibleContent>
          </Collapsible>
        ))}
      </CardContent>
    </Card>
  );
}

function MetricRow({ metric }: { metric: AccountMetric }) {
  const deleteMetric = useDeleteAccountMetric();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const handleDelete = () => {
    deleteMetric.mutate({ 
      id: metric.id, 
      accountId: metric.account_id 
    });
    setShowDeleteConfirm(false);
  };

  return (
    <TooltipProvider>
      <div className="flex items-start gap-3 p-2 rounded-md bg-muted/30 hover:bg-muted/50 transition-colors group">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium text-sm">{metric.metric_name}</span>
            {metric.needs_review && (
              <Tooltip>
                <TooltipTrigger>
                  <AlertCircle className="w-3.5 h-3.5 text-yellow-500" />
                </TooltipTrigger>
                <TooltipContent>Needs review</TooltipContent>
              </Tooltip>
            )}
            {!metric.needs_review && metric.confidence_score >= 0.8 && (
              <Tooltip>
                <TooltipTrigger>
                  <Check className="w-3.5 h-3.5 text-green-500" />
                </TooltipTrigger>
                <TooltipContent>High confidence ({Math.round(metric.confidence_score * 100)}%)</TooltipContent>
              </Tooltip>
            )}
          </div>
          
          <div className="flex items-center gap-2 mt-1">
            <span className="text-lg font-semibold text-primary">
              {metric.metric_value}
            </span>
            {metric.metric_numeric_value !== null && (
              <Badge variant="outline" className="text-xs">
                #{metric.metric_numeric_value.toLocaleString()}
              </Badge>
            )}
          </div>

          {metric.context && (
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2 italic">
              "{metric.context}"
            </p>
          )}

          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
            {metric.mentioned_by_name && (
              <span className="flex items-center gap-1">
                <User className="w-3 h-3" />
                {metric.mentioned_by_name}
                {metric.mentioned_by_type && (
                  <Badge 
                    variant="outline" 
                    className={cn(
                      "text-[10px] py-0",
                      metric.mentioned_by_type === 'external' 
                        ? 'border-blue-500/50 text-blue-500' 
                        : 'border-muted-foreground'
                    )}
                  >
                    {metric.mentioned_by_type}
                  </Badge>
                )}
              </span>
            )}
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {format(new Date(metric.created_at), 'MMM d, yyyy')}
            </span>
          </div>
        </div>

        {/* Delete button */}
        <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
          <AlertDialogTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Metric</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete the metric "{metric.metric_name}: {metric.metric_value}"? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleDelete}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </TooltipProvider>
  );
}

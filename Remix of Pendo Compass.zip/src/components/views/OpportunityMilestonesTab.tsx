import { useState, useMemo } from 'react';
import { Calendar, CheckCircle2, Clock, Play, SkipForward, Plus, StickyNote, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import {
  useOpportunityMilestones,
  useUpdateMilestone,
  useMilestoneTemplates,
  type OpportunityMilestone,
} from '@/hooks/useOpportunityReadiness';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { AddMilestoneDialog } from '@/components/dialogs/AddMilestoneDialog';
import { EditMilestoneDialog } from '@/components/dialogs/EditMilestoneDialog';

interface OpportunityMilestonesTabProps {
  opportunityId: string;
  onInitialize: () => void;
  isInitializing: boolean;
}

const statusConfig: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  not_scheduled: { label: 'Not Scheduled', icon: Clock, color: 'text-muted-foreground' },
  scheduled: { label: 'Scheduled', icon: Calendar, color: 'text-primary' },
  in_progress: { label: 'In Progress', icon: Play, color: 'text-amber-500' },
  completed: { label: 'Completed', icon: CheckCircle2, color: 'text-green-500' },
  skipped: { label: 'Skipped', icon: SkipForward, color: 'text-muted-foreground' },
};

const phaseColors: Record<string, string> = {
  'Value Discovery': 'bg-layer-host-muted text-layer-host border-layer-host',
  'Eval Planning': 'bg-layer-build-muted text-layer-build border-layer-build',
  'Eval Deployment': 'bg-layer-adopt-muted text-layer-adopt border-layer-adopt',
  'Eval Workshops': 'bg-layer-growth-muted text-layer-growth border-layer-growth',
  'Conclusion': 'bg-primary/20 text-primary border-primary',
  'Procurement & Contracting': 'bg-amber-500/20 text-amber-600 border-amber-500',
  'Go Live & Value Realization': 'bg-green-500/20 text-green-600 border-green-500',
};

export function OpportunityMilestonesTab({ opportunityId, onInitialize, isInitializing }: OpportunityMilestonesTabProps) {
  const { data: milestones, isLoading } = useOpportunityMilestones(opportunityId);
  const { data: templates } = useMilestoneTemplates();
  const updateMilestone = useUpdateMilestone();
  
  const [editingMilestone, setEditingMilestone] = useState<any>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  
  // Group milestones by phase
  const groupedMilestones = useMemo(() => {
    if (!milestones) return [];
    
    const phases: { phase: string; milestones: typeof milestones }[] = [];
    let currentPhase = '';
    
    milestones.forEach(m => {
      if (m.phase !== currentPhase) {
        currentPhase = m.phase;
        phases.push({ phase: currentPhase, milestones: [] });
      }
      phases[phases.length - 1].milestones.push(m);
    });
    
    return phases;
  }, [milestones]);
  
  // Calculate phase progress
  const phaseProgress = useMemo(() => {
    const progress: Record<string, { completed: number; total: number }> = {};
    groupedMilestones.forEach(group => {
      const completed = group.milestones.filter(m => m.status === 'completed').length;
      progress[group.phase] = { completed, total: group.milestones.length };
    });
    return progress;
  }, [groupedMilestones]);
  
  const handleStatusChange = async (milestoneId: string, status: string) => {
    await updateMilestone.mutateAsync({
      id: milestoneId,
      opportunityId,
      status,
      completedDate: status === 'completed' ? new Date().toISOString().split('T')[0] : null,
    });
  };
  
  const handleDateChange = async (milestoneId: string, date: Date | undefined) => {
    try {
      await updateMilestone.mutateAsync({
        id: milestoneId,
        opportunityId,
        scheduledDate: date ? date.toISOString().split('T')[0] : null,
        status: date ? 'scheduled' : 'not_scheduled',
      });
    } catch (e) {
      // Handled by react-query onError / toast
      console.error('Failed to update milestone date:', e);
    }
  };

  const openEditDialog = (milestone: any) => {
    setEditingMilestone(milestone);
    setEditDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  if (!milestones || milestones.length === 0) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Mutual Action Plan Timeline</h2>
            <p className="text-sm text-muted-foreground">
              Track key milestones from discovery to go-live
            </p>
          </div>
          <AddMilestoneDialog opportunityId={opportunityId} />
        </div>
        <div className="glass rounded-xl p-8 text-center">
          <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Timeline Set Up</h3>
          <p className="text-muted-foreground mb-4">
            Initialize the mutual action plan timeline from the standard template.
          </p>
          <Button onClick={onInitialize} disabled={isInitializing}>
            {isInitializing ? 'Setting up...' : 'Initialize Timeline'}
          </Button>
        </div>

        <EditMilestoneDialog
          milestone={editingMilestone}
          opportunityId={opportunityId}
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
        />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Mutual Action Plan Timeline</h2>
          <p className="text-sm text-muted-foreground">
            Track key milestones from discovery to go-live
          </p>
        </div>
        <AddMilestoneDialog opportunityId={opportunityId} />
      </div>

      {/* Timeline */}
      <div className="space-y-6">
        {groupedMilestones.map(({ phase, milestones: phaseMilestones }) => {
          const progress = phaseProgress[phase];
          const isComplete = progress.completed === progress.total;
          
          return (
            <div key={phase} className="glass rounded-xl overflow-hidden">
              {/* Phase Header */}
              <div className={cn(
                "p-4 border-l-4",
                phaseColors[phase] || 'bg-muted border-muted-foreground'
              )}>
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{phase}</h3>
                  <div className="flex items-center gap-2">
                    <Badge variant={isComplete ? 'default' : 'outline'}>
                      {progress.completed} / {progress.total}
                    </Badge>
                    {isComplete && <CheckCircle2 className="w-5 h-5 text-green-500" />}
                  </div>
                </div>
              </div>
              
              {/* Milestones */}
              <div className="divide-y divide-border">
                {phaseMilestones.map((milestone: OpportunityMilestone) => {
                  const config = statusConfig[milestone.status] || statusConfig.not_scheduled;
                  const StatusIcon = config.icon;
                  const hasNotes = !!milestone.notes;
                  
                  return (
                    <div
                      key={milestone.id}
                      className={cn(
                        "p-4 hover:bg-muted/50 transition-colors",
                        milestone.status === 'completed' && "bg-green-500/5"
                      )}
                    >
                      <div className="flex items-start gap-4">
                        {/* Status Icon */}
                        <div className={cn("mt-1", config.color)}>
                          <StatusIcon className="w-5 h-5" />
                        </div>
                        
                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <div className="flex items-center gap-2">
                                <h4 className={cn(
                                  "font-medium",
                                  milestone.status === 'completed' && "line-through text-muted-foreground"
                                )}>
                                  {milestone.name}
                                </h4>
                                {milestone.assigned_to && (
                                  <Tooltip>
                                    <TooltipTrigger>
                                      <Badge variant="outline" className="text-xs gap-1">
                                        <User className="w-3 h-3" />
                                        {milestone.assigned_to.split('@')[0]}
                                      </Badge>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      Assigned to: {milestone.assigned_to}
                                    </TooltipContent>
                                  </Tooltip>
                                )}
                              </div>
                              {milestone.description && (
                                <p className="text-sm text-muted-foreground mt-1">
                                  {milestone.description}
                                </p>
                              )}
                              {milestone.required_participants && (
                                <p className="text-xs text-muted-foreground mt-1">
                                  Participants: {milestone.required_participants}
                                </p>
                              )}
                            </div>
                            
                            <div className="flex items-center gap-2 shrink-0">
                              {/* Date Picker */}
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button variant="outline" size="sm" className="gap-2">
                                    <Calendar className="w-4 h-4" />
                                    {milestone.scheduled_date 
                                      ? format(new Date(milestone.scheduled_date), 'MMM d, yyyy')
                                      : 'Set date'}
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0 pointer-events-auto" align="end" sideOffset={5}>
                                  <CalendarComponent
                                    mode="single"
                                    selected={milestone.scheduled_date ? new Date(milestone.scheduled_date) : undefined}
                                    onSelect={(date) => handleDateChange(milestone.id, date)}
                                    initialFocus
                                    className="p-3"
                                  />
                                </PopoverContent>
                              </Popover>
                              
                              {/* Notes/Edit Button */}
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    onClick={() => openEditDialog(milestone)}
                                    className={cn(
                                      hasNotes && "border-primary/50 text-primary"
                                    )}
                                  >
                                    <StickyNote className="w-4 h-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  {hasNotes ? 'View/Edit Notes' : 'Add Notes & Assignment'}
                                </TooltipContent>
                              </Tooltip>
                              
                              {/* Status Selector */}
                              <Select 
                                value={milestone.status} 
                                onValueChange={(v) => handleStatusChange(milestone.id, v)}
                              >
                                <SelectTrigger className="w-[140px]">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="not_scheduled">Not Scheduled</SelectItem>
                                  <SelectItem value="scheduled">Scheduled</SelectItem>
                                  <SelectItem value="in_progress">In Progress</SelectItem>
                                  <SelectItem value="completed">Completed</SelectItem>
                                  <SelectItem value="skipped">Skipped</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          
                          {/* Notes Preview */}
                          {milestone.notes && (
                            <div className="mt-2 p-2 bg-muted/50 rounded text-sm">
                              {milestone.notes}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit Dialog */}
      <EditMilestoneDialog
        milestone={editingMilestone}
        opportunityId={opportunityId}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
      />
    </div>
  );
}

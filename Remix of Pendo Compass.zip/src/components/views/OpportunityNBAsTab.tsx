import { useState, useMemo } from 'react';
import { 
  Target, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Mail, 
  Users, 
  ClipboardList,
  AlertCircle,
  Calendar,
  Eye,
  Sparkles,
} from 'lucide-react';
import { NewBadge, CompletedBadge, SourceTranscriptBadge } from '@/components/InsightChangeIndicators';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { useOpportunityNBAs, useCreateOpportunityNBA, useCompleteOpportunityNBA, useReopenOpportunityNBA, useUpdateOpportunityNBAOwner } from '@/hooks/useOpportunityNBAs';
import { useAssignableOpportunityUsers } from '@/hooks/useAssignableOpportunityUsers';
import { toast } from 'sonner';
import { format, differenceInDays } from 'date-fns';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { DueDatePicker } from '@/components/DueDatePicker';
import { useAuth } from '@/contexts/AuthContext';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useMutation, useQueryClient } from '@tanstack/react-query';

interface OpportunityNBAsTabProps {
  opportunityId: string;
  accountId: string;
  opportunityName: string;
}

const priorityColors: Record<string, string> = {
  high: 'border-destructive text-destructive bg-destructive/10',
  medium: 'border-layer-build text-layer-build bg-layer-build/10',
  low: 'border-muted-foreground text-muted-foreground bg-muted/50',
};

const actionTypeLabels: Record<string, string> = {
  discovery: 'Discovery',
  followup: 'Follow-up',
  follow_up: 'Follow-up',
  technical: 'Technical',
  whitespace: 'Whitespace',
  competitive_advantage: 'Competitive',
  research: 'Research',
  meeting: 'Meeting',
};

const deliveryMethodConfig = {
  email: { icon: Mail, label: 'Email', color: 'text-blue-500' },
  meeting: { icon: Users, label: 'Meeting', color: 'text-purple-500' },
  internal: { icon: ClipboardList, label: 'Internal', color: 'text-muted-foreground' },
};

// Helper to get initials from name or email
function getInitials(name: string | null, email: string): string {
  if (name) {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  }
  return email.substring(0, 2).toUpperCase();
}

export function OpportunityNBAsTab({ opportunityId, accountId, opportunityName }: OpportunityNBAsTabProps) {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('pending');
  const [hideCompleted, setHideCompleted] = useState(false);
  const [viewingTranscriptId, setViewingTranscriptId] = useState<string | null>(null);
  
  // Form state
  const [newAction, setNewAction] = useState('');
  const [newType, setNewType] = useState('followup');
  const [newPriority, setNewPriority] = useState('medium');
  const [newDeliveryMethod, setNewDeliveryMethod] = useState('email');
  const [newNotes, setNewNotes] = useState('');
  const [newAssignedTo, setNewAssignedTo] = useState('');
  const [newDueDate, setNewDueDate] = useState('');

  const { data: nbas, isLoading } = useOpportunityNBAs(opportunityId);
  const { data: assignableUsers } = useAssignableOpportunityUsers(accountId, opportunityId);
  const createNBA = useCreateOpportunityNBA();
  const completeNBA = useCompleteOpportunityNBA();
  const reopenNBA = useReopenOpportunityNBA();
  const updateNBAOwner = useUpdateOpportunityNBAOwner();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const userEmail = user?.email;

  // Update due date mutation with logging
  const updateDueDate = useMutation({
    mutationFn: async ({ 
      nbaId, 
      newDueDate, 
      previousDueDate 
    }: { 
      nbaId: string; 
      newDueDate: Date;
      previousDueDate: Date | null;
    }) => {
      let changeType = 'manual';
      let daysChanged = 0;
      
      if (!previousDueDate) {
        changeType = 'initial';
      } else {
        daysChanged = differenceInDays(newDueDate, previousDueDate);
        changeType = daysChanged > 0 ? 'postponed' : 'advanced';
      }

      const { error } = await gateway
        .from('account_nbas')
        .update({ due_date: newDueDate.toISOString() })
        .eq('id', nbaId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));

      // Log the change
      await gateway.from('nba_due_date_changes')
        .insert({
          nba_id: nbaId,
          previous_due_date: previousDueDate?.toISOString() || null,
          new_due_date: newDueDate.toISOString(),
          change_type: changeType,
          days_changed: daysChanged,
          changed_by: user?.id || null,
          changed_by_email: userEmail || null,
        })
        .execute();

      return { changeType, daysChanged };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      if (data.changeType === 'postponed') {
        toast.info(`Due date postponed by ${data.daysChanged} day${data.daysChanged !== 1 ? 's' : ''}`);
      } else if (data.changeType === 'advanced') {
        toast.success(`Due date moved up`);
      } else {
        toast.success('Due date set');
      }
    },
  });

  // Create a map of email to user info for displaying owners
  const userMap = useMemo(() => {
    const map = new Map<string, { name: string | null; email: string }>();
    assignableUsers?.allUsers.forEach(user => {
      map.set(user.email.toLowerCase(), { name: user.full_name, email: user.email });
    });
    return map;
  }, [assignableUsers]);

  const resetForm = () => {
    setNewAction('');
    setNewType('followup');
    setNewPriority('medium');
    setNewDeliveryMethod('email');
    setNewNotes('');
    setNewAssignedTo('');
    setNewDueDate('');
  };

  const handleCreate = () => {
    if (!newAction.trim()) {
      toast.error('Action description is required');
      return;
    }
    createNBA.mutate({
      account_id: accountId,
      opportunity_id: opportunityId,
      action: newAction,
      action_type: newType,
      priority: newPriority,
      delivery_method: newDeliveryMethod,
      notes: newNotes,
      assigned_to: newAssignedTo && newAssignedTo !== '__unassigned__' ? newAssignedTo : undefined,
      due_date: newDueDate || undefined,
    });
    setShowAddDialog(false);
    resetForm();
  };

  const handleComplete = (nbaId: string) => {
    completeNBA.mutate({ id: nbaId, accountId, opportunityId });
  };

  const handleReopen = (nbaId: string) => {
    reopenNBA.mutate({ id: nbaId, accountId, opportunityId });
  };

  // Filter NBAs
  const filteredNBAs = useMemo(() => {
    if (!nbas) return [];
    let result = nbas;
    if (filter === 'pending') result = nbas.filter(n => n.status !== 'completed');
    else if (filter === 'completed') result = nbas.filter(n => n.status === 'completed');
    // When viewing 'all', optionally hide completed
    if (filter === 'all' && hideCompleted) {
      result = result.filter(n => n.status !== 'completed');
    }
    return result;
  }, [nbas, filter, hideCompleted]);

  // Group by delivery method, with completed NBAs at the bottom of each group
  const groupedByDelivery = useMemo(() => {
    const groups: Record<string, typeof filteredNBAs> = {
      meeting: [],
      email: [],
      internal: [],
    };
    filteredNBAs.forEach(nba => {
      const method = nba.delivery_method || 'internal';
      if (groups[method]) {
        groups[method].push(nba);
      } else {
        groups['internal'].push(nba);
      }
    });
    // Sort each group: pending first, completed last
    Object.keys(groups).forEach(key => {
      groups[key].sort((a, b) => {
        const aCompleted = a.status === 'completed' ? 1 : 0;
        const bCompleted = b.status === 'completed' ? 1 : 0;
        return aCompleted - bCompleted;
      });
    });
    return groups;
  }, [filteredNBAs]);

  // Stats
  const stats = useMemo(() => {
    if (!nbas) return { total: 0, pending: 0, completed: 0, high: 0 };
    return {
      total: nbas.length,
      pending: nbas.filter(n => n.status !== 'completed').length,
      completed: nbas.filter(n => n.status === 'completed').length,
      high: nbas.filter(n => n.priority === 'high' && n.status !== 'completed').length,
    };
  }, [nbas]);

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <div className="h-8 w-48 bg-muted animate-pulse rounded" />
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-20 bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Next Best Actions</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Actions for {opportunityName}
          </p>
        </div>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add Action
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Next Best Action</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Action</Label>
                <Textarea
                  value={newAction}
                  onChange={(e) => setNewAction(e.target.value)}
                  placeholder="Describe the action to take..."
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Select value={newType} onValueChange={setNewType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="followup">Follow-up</SelectItem>
                      <SelectItem value="discovery">Discovery</SelectItem>
                      <SelectItem value="technical">Technical</SelectItem>
                      <SelectItem value="whitespace">Whitespace</SelectItem>
                      <SelectItem value="competitive_advantage">Competitive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Priority</Label>
                  <Select value={newPriority} onValueChange={setNewPriority}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Delivery Method</Label>
                <Select value={newDeliveryMethod} onValueChange={setNewDeliveryMethod}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="email">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4" />
                        Email
                      </div>
                    </SelectItem>
                    <SelectItem value="meeting">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        Meeting
                      </div>
                    </SelectItem>
                    <SelectItem value="internal">
                      <div className="flex items-center gap-2">
                        <ClipboardList className="w-4 h-4" />
                        Internal
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Owner</Label>
                  <Select value={newAssignedTo} onValueChange={setNewAssignedTo}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select owner..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__unassigned__">
                        <span className="text-muted-foreground">Unassigned</span>
                      </SelectItem>
                      {assignableUsers?.seUsers && assignableUsers.seUsers.length > 0 && (
                        <>
                          <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">Team Members</div>
                          {assignableUsers.seUsers.map((user) => (
                            <SelectItem key={user.email} value={user.email}>
                              <div className="flex items-center gap-2">
                                <Avatar className="h-5 w-5">
                                  <AvatarFallback className="text-[10px]">
                                    {getInitials(user.full_name, user.email)}
                                  </AvatarFallback>
                                </Avatar>
                                <span>{user.full_name || user.email}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </>
                      )}
                      {assignableUsers?.stakeholderUsers && assignableUsers.stakeholderUsers.length > 0 && (
                        <>
                          <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground border-t mt-1 pt-2">Stakeholders</div>
                          {assignableUsers.stakeholderUsers.map((user) => (
                            <SelectItem key={user.email} value={user.email}>
                              <div className="flex items-center gap-2">
                                <Avatar className="h-5 w-5">
                                  <AvatarFallback className="text-[10px] bg-accent">
                                    {getInitials(user.full_name, user.email)}
                                  </AvatarFallback>
                                </Avatar>
                                <span>{user.full_name || user.email}</span>
                                {user.role && <span className="text-xs text-muted-foreground">({user.role})</span>}
                              </div>
                            </SelectItem>
                          ))}
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Due Date (optional)</Label>
                  <Input
                    type="date"
                    value={newDueDate}
                    onChange={(e) => setNewDueDate(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Notes (optional)</Label>
                <Textarea
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="Additional context..."
                  rows={2}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={createNBA.isPending}>
                  Add Action
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Target className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stats.pending}</p>
                <p className="text-xs text-muted-foreground">Pending</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stats.high}</p>
                <p className="text-xs text-muted-foreground">High Priority</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stats.completed}</p>
                <p className="text-xs text-muted-foreground">Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                <Circle className="w-5 h-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stats.total}</p>
                <p className="text-xs text-muted-foreground">Total</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          {(['pending', 'completed', 'all'] as const).map((f) => (
            <Button
              key={f}
              variant={filter === f ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(f)}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </Button>
          ))}
        </div>
        {filter === 'all' && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setHideCompleted(!hideCompleted)}
            className="text-xs"
          >
            {hideCompleted ? 'Show Completed' : 'Hide Completed'}
          </Button>
        )}
      </div>

      {/* NBAs by Delivery Method */}
      {Object.entries(groupedByDelivery).map(([method, methodNBAs]) => {
        if (methodNBAs.length === 0) return null;
        const config = deliveryMethodConfig[method as keyof typeof deliveryMethodConfig];
        const Icon = config?.icon || ClipboardList;

        return (
          <div key={method} className="space-y-3">
            <div className="flex items-center gap-2">
              <Icon className={cn("w-4 h-4", config?.color)} />
              <span className="font-medium text-sm">{config?.label || method}</span>
              <Badge variant="outline" className="text-xs">
                {methodNBAs.length}
              </Badge>
            </div>

            <div className="space-y-2">
              {methodNBAs.map((nba) => (
                <div
                  key={nba.id}
                  className={cn(
                    "flex items-start gap-3 p-4 rounded-lg border transition-all",
                    nba.status === 'completed' 
                      ? "bg-muted/30 border-muted" 
                      : "bg-card border-border hover:border-primary/30"
                  )}
                >
                  <button
                    onClick={() => nba.status === 'completed' ? handleReopen(nba.id) : handleComplete(nba.id)}
                    className="mt-0.5"
                  >
                    {nba.status === 'completed' ? (
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                    ) : (
                      <Circle className="w-5 h-5 text-muted-foreground hover:text-primary" />
                    )}
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className={cn(
                        "text-sm",
                        nba.status === 'completed' && "line-through text-muted-foreground"
                      )}>
                        {nba.action}
                      </p>
                      <NewBadge createdAt={nba.created_at} />
                      {nba.status === 'completed' && nba.completed_at && (
                        <CompletedBadge 
                          completedAt={nba.completed_at} 
                          autoCompleted={!!nba.auto_complete_confidence && nba.auto_complete_confidence > 0}
                          autoCompleteReason={nba.auto_complete_reason}
                        />
                      )}
                      <SourceTranscriptBadge hasSource={!!nba.source_transcript_id} />
                    </div>
                    <div className="flex items-center gap-3 mt-2 flex-wrap">
                      <Select 
                        value={nba.assigned_to || '__unassigned__'} 
                        onValueChange={(value) => updateNBAOwner.mutate({ id: nba.id, accountId, opportunityId, assignedTo: value === '__unassigned__' ? null : value })}
                      >
                        <SelectTrigger className="h-7 w-auto min-w-[140px] border-dashed">
                          {nba.assigned_to ? (() => {
                            const owner = userMap.get(nba.assigned_to.toLowerCase());
                            const displayName = owner?.name || nba.assigned_to;
                            return (
                              <div className="flex items-center gap-1.5">
                                <Avatar className="h-5 w-5">
                                  <AvatarFallback className="text-[9px] bg-primary/10 text-primary">
                                    {getInitials(owner?.name || null, nba.assigned_to)}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-xs">{displayName}</span>
                              </div>
                            );
                          })() : (
                            <span className="text-xs text-muted-foreground">Assign owner...</span>
                          )}
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="__unassigned__">
                            <span className="text-muted-foreground">Unassigned</span>
                          </SelectItem>
                          {assignableUsers?.seUsers && assignableUsers.seUsers.length > 0 && (
                            <>
                              <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">Team Members</div>
                              {assignableUsers.seUsers.map((user) => (
                                <SelectItem key={user.email} value={user.email}>
                                  <div className="flex items-center gap-2">
                                    <Avatar className="h-5 w-5">
                                      <AvatarFallback className="text-[10px]">
                                        {getInitials(user.full_name, user.email)}
                                      </AvatarFallback>
                                    </Avatar>
                                    <span>{user.full_name || user.email}</span>
                                  </div>
                                </SelectItem>
                              ))}
                            </>
                          )}
                          {assignableUsers?.stakeholderUsers && assignableUsers.stakeholderUsers.length > 0 && (
                            <>
                              <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground border-t mt-1 pt-2">Stakeholders</div>
                              {assignableUsers.stakeholderUsers.map((user) => (
                                <SelectItem key={user.email} value={user.email}>
                                  <div className="flex items-center gap-2">
                                    <Avatar className="h-5 w-5">
                                      <AvatarFallback className="text-[10px] bg-accent">
                                        {getInitials(user.full_name, user.email)}
                                      </AvatarFallback>
                                    </Avatar>
                                    <span>{user.full_name || user.email}</span>
                                    {user.role && <span className="text-xs text-muted-foreground">({user.role})</span>}
                                  </div>
                                </SelectItem>
                              ))}
                            </>
                          )}
                        </SelectContent>
                      </Select>
                      <DueDatePicker
                        dueDate={nba.due_date}
                        onDateChange={(newDate, prevDate) => updateDueDate.mutate({ 
                          nbaId: nba.id, 
                          newDueDate: newDate, 
                          previousDueDate: prevDate 
                        })}
                        disabled={nba.status === 'completed'}
                      />
                    </div>
                    {nba.notes && (
                      <p className="text-xs text-muted-foreground mt-1.5">{nba.notes}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {/* Auto-completed indicator */}
                    {nba.auto_complete_confidence != null && nba.auto_complete_confidence > 0 && (
                      <Tooltip>
                        <TooltipTrigger>
                          <Badge variant="outline" className="text-[10px] text-green-600 border-green-500/50 bg-green-500/10 gap-1">
                            <Sparkles className="w-3 h-3" />
                            Auto-resolved
                          </Badge>
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="text-xs font-medium">Detected as completed</p>
                          {nba.auto_complete_reason && (
                            <p className="text-xs text-muted-foreground mt-1">{nba.auto_complete_reason}</p>
                          )}
                          <p className="text-xs text-muted-foreground mt-1">
                            Confidence: {Math.round((nba.auto_complete_confidence || 0) * 100)}%
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    )}
                    {/* Link to source transcript */}
                    {(nba.source_transcript_id || nba.auto_completed_by_transcript_id) && (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => {
                              const transcriptId = nba.auto_completed_by_transcript_id || nba.source_transcript_id;
                              // Navigate to transcript or open preview
                              window.open(`/accounts/${accountId}?tab=transcripts&highlight=${transcriptId}`, '_blank');
                            }}
                          >
                            <Eye className="w-3.5 h-3.5 text-muted-foreground" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs">View source transcript</p>
                        </TooltipContent>
                      </Tooltip>
                    )}
                    <Badge variant="outline" className="text-[10px]">
                      {actionTypeLabels[nba.action_type] || nba.action_type}
                    </Badge>
                    <Badge 
                      variant="outline" 
                      className={cn('text-[10px]', priorityColors[nba.priority || 'medium'])}
                    >
                      {nba.priority}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {filteredNBAs.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Target className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
            <h3 className="font-medium mb-2">No actions yet</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Add next best actions to track follow-ups and tasks
            </p>
            <Button onClick={() => setShowAddDialog(true)}>
              <Plus className="w-4 h-4 mr-1" />
              Add First Action
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

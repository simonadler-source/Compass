import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, AlertTriangle, ShieldAlert, Edit2, Save, CheckCircle2, Clock, XCircle, User, ChevronDown, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useAssignableOpportunityUsers } from '@/hooks/useAssignableOpportunityUsers';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface TechnicalRisk {
  id: string;
  opportunity_id: string;
  tracker_id: string | null;
  entry_type: string;
  risk_description: string;
  technical_root_cause: string | null;
  project_impact: string | null;
  severity: string;
  status: string;
  mitigation_plan: string | null;
  owner_email: string | null;
  customer_owner: string | null;
  source: string | null;
  created_at: string;
  updated_at: string;
}

const entryTypeConfig: Record<string, { label: string; color: string }> = {
  risk: { label: 'Risk', color: 'bg-orange-500/10 border-orange-500/30 text-orange-600' },
  issue: { label: 'Issue', color: 'bg-purple-500/10 border-purple-500/30 text-purple-600' },
};

const severityConfig: Record<string, { label: string; color: string; bgColor: string }> = {
  low: { label: 'Low', color: 'text-blue-600', bgColor: 'bg-blue-500/10 border-blue-500/30' },
  medium: { label: 'Medium', color: 'text-amber-600', bgColor: 'bg-amber-500/10 border-amber-500/30' },
  high: { label: 'High', color: 'text-orange-600', bgColor: 'bg-orange-500/10 border-orange-500/30' },
  critical: { label: 'Critical', color: 'text-destructive', bgColor: 'bg-destructive/10 border-destructive/30' },
};

const statusConfig: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  new: { label: 'New', icon: AlertTriangle, color: 'text-amber-500' },
  in_review: { label: 'In Review', icon: Clock, color: 'text-blue-500' },
  awaiting_feedback: { label: 'Awaiting Feedback', icon: Clock, color: 'text-orange-500' },
  mitigated: { label: 'Mitigated', icon: CheckCircle2, color: 'text-emerald-600' },
  accepted: { label: 'Accepted', icon: ShieldAlert, color: 'text-muted-foreground' },
  closed: { label: 'Closed', icon: XCircle, color: 'text-muted-foreground' },
};

interface Props {
  opportunityId: string;
  accountId: string;
}

export function OpportunityRisksIssuesTab({ opportunityId, accountId }: Props) {
  const queryClient = useQueryClient();
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<Set<string>>(new Set());
  const [newDescription, setNewDescription] = useState('');
  const [newSeverity, setNewSeverity] = useState('medium');
  const [newMitigation, setNewMitigation] = useState('');
  const [newOwner, setNewOwner] = useState('');
  const [newTrackerId, setNewTrackerId] = useState('');
  const [newRootCause, setNewRootCause] = useState('');
  const [newImpact, setNewImpact] = useState('');
  const [newCustomerOwner, setNewCustomerOwner] = useState('');
  const [newEntryType, setNewEntryType] = useState('risk');
  const [editValues, setEditValues] = useState<Partial<TechnicalRisk>>({});

  const { data: risks, isLoading } = useQuery({
    queryKey: ['technical-risks', opportunityId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('evaluation_technical_risks')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('created_at');
      if (error) throw error;
      return data as TechnicalRisk[];
    },
  });

  const { data: teamData } = useAssignableOpportunityUsers(accountId, opportunityId);
  const teamUsersList = teamData?.allUsers?.filter((u: any) => !u.isExternal) || [];

  const refresh = () => queryClient.invalidateQueries({ queryKey: ['technical-risks', opportunityId] });

  const handleAdd = async () => {
    if (!newDescription.trim()) return;
    const { error } = await supabase
      .from('evaluation_technical_risks')
      .insert({
        opportunity_id: opportunityId,
        risk_description: newDescription.trim(),
        severity: newSeverity,
        status: 'new',
        entry_type: newEntryType,
        mitigation_plan: newMitigation.trim() || null,
        owner_email: newOwner || null,
        tracker_id: newTrackerId.trim() || null,
        technical_root_cause: newRootCause.trim() || null,
        project_impact: newImpact.trim() || null,
        customer_owner: newCustomerOwner.trim() || null,
      } as any);
    if (error) { toast.error('Failed to add risk'); return; }
    toast.success('Risk/issue added');
    setNewDescription(''); setNewSeverity('medium'); setNewMitigation(''); setNewOwner('');
    setNewTrackerId(''); setNewRootCause(''); setNewImpact(''); setNewCustomerOwner(''); setNewEntryType('risk');
    setShowAddForm(false);
    refresh();
  };

  const handleStatusChange = async (id: string, status: string) => {
    const { error } = await supabase
      .from('evaluation_technical_risks')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) { toast.error('Failed to update'); return; }
    refresh();
  };

  const handleOwnerChange = async (id: string, ownerEmail: string) => {
    const { error } = await supabase
      .from('evaluation_technical_risks')
      .update({ owner_email: ownerEmail || null, updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) { toast.error('Failed to update owner'); return; }
    refresh();
  };

  const handleSaveEdit = async (id: string) => {
    const { error } = await supabase
      .from('evaluation_technical_risks')
      .update({ ...editValues, updated_at: new Date().toISOString() } as any)
      .eq('id', id);
    if (error) { toast.error('Failed to update'); return; }
    toast.success('Updated');
    setEditingId(null);
    refresh();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('evaluation_technical_risks').delete().eq('id', id);
    if (error) { toast.error('Failed to delete'); return; }
    toast.success('Risk removed');
    refresh();
  };

  const getOwnerLabel = (email: string | null) => {
    if (!email) return null;
    const user = teamUsersList.find((u: any) => u.email === email);
    return user?.full_name || email;
  };

  const openCount = risks?.filter(r => r.status === 'new' || r.status === 'in_review' || r.status === 'awaiting_feedback' || r.status === 'open' || r.status === 'investigating').length || 0;
  const criticalCount = risks?.filter(r => r.severity === 'critical' && r.status !== 'closed' && r.status !== 'mitigated').length || 0;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-primary" />
            Risks & Issues
          </h2>
          <p className="text-sm text-muted-foreground">
            Track technical risks and issues for this evaluation
          </p>
        </div>
        <div className="flex items-center gap-3">
          {openCount > 0 && (
            <Badge variant="outline" className={cn(
              "text-sm",
              criticalCount > 0 ? "border-destructive text-destructive" : "border-amber-500 text-amber-600"
            )}>
              {openCount} open{criticalCount > 0 ? ` (${criticalCount} critical)` : ''}
            </Badge>
          )}
          <Button size="sm" onClick={() => setShowAddForm(true)}>
            <Plus className="w-4 h-4 mr-1" /> Add Risk
          </Button>
        </div>
      </div>

      {/* Status filter chips */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs text-muted-foreground font-medium">Filter:</span>
        {Object.entries(statusConfig).map(([key, val]) => {
          const isActive = statusFilter.has(key);
          const count = risks?.filter(r => r.status === key).length || 0;
          if (count === 0 && !isActive) return null;
          return (
            <button
              key={key}
              onClick={() => {
                const next = new Set(statusFilter);
                if (isActive) next.delete(key); else next.add(key);
                setStatusFilter(next);
              }}
              className={cn(
                "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors",
                isActive
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-muted/50 text-muted-foreground border-border hover:bg-muted"
              )}
            >
              {val.label} <span className="opacity-70">({count})</span>
            </button>
          );
        })}
        {statusFilter.size > 0 && (
          <button
            onClick={() => setStatusFilter(new Set())}
            className="text-xs text-muted-foreground hover:text-foreground underline"
          >
            Clear
          </button>
        )}
      </div>

      {/* Add form */}
      {showAddForm && (
        <Card>
          <CardContent className="pt-6 space-y-4">
            <div className="grid grid-cols-[80px_100px_1fr] gap-4">
              <Select value={newEntryType} onValueChange={setNewEntryType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="risk">Risk</SelectItem>
                  <SelectItem value="issue">Issue</SelectItem>
                </SelectContent>
              </Select>
              <Input
                placeholder="ID (e.g. R-01)"
                value={newTrackerId}
                onChange={(e) => setNewTrackerId(e.target.value)}
              />
              <Input
                placeholder="Risk or issue description"
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
              />
            </div>
            <Textarea
              placeholder="Technical root cause"
              value={newRootCause}
              onChange={(e) => setNewRootCause(e.target.value)}
              rows={2}
            />
            <Input
              placeholder="Project impact"
              value={newImpact}
              onChange={(e) => setNewImpact(e.target.value)}
            />
            <div className="grid grid-cols-4 gap-4">
              <Select value={newSeverity} onValueChange={setNewSeverity}>
                <SelectTrigger>
                  <SelectValue placeholder="Severity" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(severityConfig).map(([key, val]) => (
                    <SelectItem key={key} value={key}>{val.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={newOwner} onValueChange={setNewOwner}>
                <SelectTrigger>
                  <SelectValue placeholder="Pendo Owner" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">Unassigned</SelectItem>
                  {teamUsersList.map((u: any) => (
                    <SelectItem key={u.email} value={u.email}>{u.full_name || u.email}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="Customer owner"
                value={newCustomerOwner}
                onChange={(e) => setNewCustomerOwner(e.target.value)}
              />
              <div />
            </div>
            <Textarea
              placeholder="Mitigation / solution (optional)"
              value={newMitigation}
              onChange={(e) => setNewMitigation(e.target.value)}
              rows={2}
            />
            <div className="flex gap-2">
              <Button size="sm" onClick={handleAdd}>Add</Button>
              <Button size="sm" variant="ghost" onClick={() => setShowAddForm(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Risks list */}
      {isLoading ? (
        <div className="text-sm text-muted-foreground">Loading...</div>
      ) : risks && risks.length > 0 ? (
        <div className="space-y-6">
          {(['risk', 'issue'] as const).map(entryType => {
            const groupItems = risks.filter(r =>
              (r.entry_type || 'risk') === entryType &&
              (statusFilter.size === 0 || statusFilter.has(r.status))
            );
            if (groupItems.length === 0) return null;
            const cfg = entryTypeConfig[entryType];
            return (
              <div key={entryType} className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={cn("text-xs", cfg.color)}>{cfg.label}s</Badge>
                  <span className="text-xs text-muted-foreground">({groupItems.length})</span>
                </div>
                {groupItems.map((r) => {
            const sevCfg = severityConfig[r.severity] || severityConfig.medium;
            const stCfg = statusConfig[r.status] || statusConfig.new;
            const StatusIcon = stCfg.icon;
            const isEditing = editingId === r.id;
            const isExpanded = expandedId === r.id;
            const hasDetails = r.technical_root_cause || r.project_impact || r.mitigation_plan;

            return (
              <Card key={r.id} className={cn("border", r.severity === 'critical' && r.status !== 'closed' && r.status !== 'mitigated' && "border-destructive/50")}>
                <CardContent className="pt-4 pb-4">
                  {isEditing ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-[80px_100px_1fr] gap-3">
                        <Select value={editValues.entry_type ?? r.entry_type ?? 'risk'} onValueChange={(v) => setEditValues({ ...editValues, entry_type: v })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="risk">Risk</SelectItem>
                            <SelectItem value="issue">Issue</SelectItem>
                          </SelectContent>
                        </Select>
                        <Input
                          placeholder="Tracker ID"
                          value={editValues.tracker_id ?? r.tracker_id ?? ''}
                          onChange={(e) => setEditValues({ ...editValues, tracker_id: e.target.value || null })}
                        />
                        <Input
                          value={editValues.risk_description ?? r.risk_description}
                          onChange={(e) => setEditValues({ ...editValues, risk_description: e.target.value })}
                        />
                      </div>
                      <Textarea
                        placeholder="Technical root cause"
                        value={editValues.technical_root_cause ?? r.technical_root_cause ?? ''}
                        onChange={(e) => setEditValues({ ...editValues, technical_root_cause: e.target.value || null })}
                        rows={2}
                      />
                      <Input
                        placeholder="Project impact"
                        value={editValues.project_impact ?? r.project_impact ?? ''}
                        onChange={(e) => setEditValues({ ...editValues, project_impact: e.target.value || null })}
                      />
                      <div className="grid grid-cols-4 gap-3">
                        <Select value={editValues.severity ?? r.severity} onValueChange={(v) => setEditValues({ ...editValues, severity: v })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {Object.entries(severityConfig).map(([key, val]) => (
                              <SelectItem key={key} value={key}>{val.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={editValues.status ?? r.status} onValueChange={(v) => setEditValues({ ...editValues, status: v })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {Object.entries(statusConfig).map(([key, val]) => (
                              <SelectItem key={key} value={key}>{val.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={editValues.owner_email ?? r.owner_email ?? '__none'} onValueChange={(v) => setEditValues({ ...editValues, owner_email: v === '__none' ? null : v })}>
                          <SelectTrigger><SelectValue placeholder="Pendo Owner" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="__none">Unassigned</SelectItem>
                            {teamUsersList.map((u: any) => (
                              <SelectItem key={u.email} value={u.email}>{u.full_name || u.email}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          placeholder="Customer owner"
                          value={editValues.customer_owner ?? r.customer_owner ?? ''}
                          onChange={(e) => setEditValues({ ...editValues, customer_owner: e.target.value || null })}
                        />
                      </div>
                      <Textarea
                        placeholder="Mitigation / solution"
                        value={editValues.mitigation_plan ?? r.mitigation_plan ?? ''}
                        onChange={(e) => setEditValues({ ...editValues, mitigation_plan: e.target.value || null })}
                        rows={2}
                      />
                      <div className="flex gap-2">
                        <Button size="sm" onClick={() => handleSaveEdit(r.id)}>
                          <Save className="w-3 h-3 mr-1" /> Save
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>Cancel</Button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            {hasDetails && (
                              <button
                                onClick={() => setExpandedId(isExpanded ? null : r.id)}
                                className="p-0.5 rounded hover:bg-muted"
                              >
                                {isExpanded ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
                              </button>
                            )}
                            <StatusIcon className={cn("w-4 h-4", stCfg.color)} />
                            {r.tracker_id && (
                              <span className="text-xs font-mono text-muted-foreground bg-muted px-1.5 py-0.5 rounded">{r.tracker_id}</span>
                            )}
                            <Badge variant="outline" className={cn("text-xs", entryTypeConfig[r.entry_type]?.color || entryTypeConfig.risk.color)}>
                              {entryTypeConfig[r.entry_type]?.label || 'Risk'}
                            </Badge>
                            <span className="font-medium text-sm">{r.risk_description}</span>
                            <Badge variant="outline" className={cn("text-xs", sevCfg.bgColor, sevCfg.color)}>
                              {sevCfg.label}
                            </Badge>
                            {r.source === 'ai_analysis' && (
                              <Badge variant="secondary" className="text-xs">AI</Badge>
                            )}
                            {r.source === 'imported' && (
                              <Badge variant="secondary" className="text-xs">Imported</Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-4 ml-6">
                            {r.owner_email && (
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <User className="w-3 h-3" />
                                {getOwnerLabel(r.owner_email)}
                              </span>
                            )}
                            {r.customer_owner && (
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <User className="w-3 h-3" />
                                <span className="font-medium">Customer:</span> {r.customer_owner}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <Select value={r.owner_email ?? '__none'} onValueChange={(v) => handleOwnerChange(r.id, v === '__none' ? '' : v)}>
                            <SelectTrigger className="h-8 w-[140px] text-xs">
                              <SelectValue placeholder="Owner" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="__none">Unassigned</SelectItem>
                              {teamUsersList.map((u: any) => (
                                <SelectItem key={u.email} value={u.email}>{u.full_name || u.email}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Select value={r.status} onValueChange={(v) => handleStatusChange(r.id, v)}>
                            <SelectTrigger className="h-8 w-[140px] text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.entries(statusConfig).map(([key, val]) => (
                                <SelectItem key={key} value={key}>{val.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditingId(r.id); setEditValues({}); }}>
                            <Edit2 className="w-3 h-3" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => handleDelete(r.id)}>
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>

                      {/* Expanded details */}
                      {isExpanded && hasDetails && (
                        <div className="mt-3 ml-6 space-y-2 border-l-2 border-muted pl-4">
                          {r.technical_root_cause && (
                            <div>
                              <p className="text-xs font-medium text-muted-foreground">Technical Root Cause</p>
                              <p className="text-sm">{r.technical_root_cause}</p>
                            </div>
                          )}
                          {r.project_impact && (
                            <div>
                              <p className="text-xs font-medium text-muted-foreground">Project Impact</p>
                              <p className="text-sm">{r.project_impact}</p>
                            </div>
                          )}
                          {r.mitigation_plan && (
                            <div>
                              <p className="text-xs font-medium text-muted-foreground">Mitigation / Solution</p>
                              <p className="text-sm whitespace-pre-wrap">{r.mitigation_plan}</p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
          </div>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <ShieldAlert className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground mb-4">No risks or issues logged yet</p>
            <Button size="sm" onClick={() => setShowAddForm(true)}>
              <Plus className="w-4 h-4 mr-1" /> Log First Risk
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

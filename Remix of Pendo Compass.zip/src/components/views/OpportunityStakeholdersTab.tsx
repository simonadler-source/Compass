import { useState, useEffect, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { encryptedInsert, encryptedUpdate } from '@/lib/encryptedDb';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Users, Mail, Phone, Plus, Trash2, UserCircle, Edit2, Merge, Crown, DollarSign, AlertTriangle, MessageSquare, Target, User, LayoutGrid, Network, Sparkles, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { detectDuplicates, useStakeholderDeduplication, type DuplicateGroup } from '@/hooks/useStakeholderDeduplication';
import { StakeholderOrgChart } from '@/components/stakeholder/StakeholderOrgChart';

interface OpportunityStakeholdersTabProps {
  opportunityId: string;
  accountId: string;
}

interface Contact {
  id: string;
  name: string;
  role: string | null;
  email: string | null;
  phone: string | null;
  influence_level: number | null;
  sentiment: number | null;
  champion_score: number | null;
  stakeholder_type: string | null;
  is_ignored: boolean | null;
}

const STAKEHOLDER_TYPES = [
  { value: 'champion', label: 'Champion', icon: Crown, color: 'text-yellow-500', description: 'Internal advocate who actively sells for you' },
  { value: 'economic_buyer', label: 'Economic Buyer', icon: DollarSign, color: 'text-green-500', description: 'Sponsor with budget authority' },
  { value: 'decision_maker', label: 'Decision Maker', icon: Target, color: 'text-blue-500', description: 'Has final say on technical decisions' },
  { value: 'technical_buyer', label: 'Technical Buyer', icon: User, color: 'text-purple-500', description: 'Evaluates technical fit' },
  { value: 'coach', label: 'Coach', icon: MessageSquare, color: 'text-cyan-500', description: 'Provides insider guidance' },
  { value: 'influencer', label: 'Influencer', icon: Users, color: 'text-indigo-500', description: 'Shapes opinions of others' },
  { value: 'blocker', label: 'Blocker/Detractor', icon: AlertTriangle, color: 'text-red-500', description: 'Actively opposes the solution' },
  { value: 'end_user', label: 'End User', icon: UserCircle, color: 'text-gray-500', description: 'Day-to-day user, limited decision power' },
  { value: 'unknown', label: 'Unknown', icon: User, color: 'text-muted-foreground', description: 'Needs further analysis' },
];

export function OpportunityStakeholdersTab({ opportunityId, accountId }: OpportunityStakeholdersTabProps) {
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const [mergeDialogOpen, setMergeDialogOpen] = useState(false);
  const [selectedForMerge, setSelectedForMerge] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<'list' | 'chart'>('list');
  const [duplicateGroups, setDuplicateGroups] = useState<DuplicateGroup[]>([]);
  const [autoMergeRan, setAutoMergeRan] = useState(false);
  
  // Add form state
  const [newContactName, setNewContactName] = useState('');
  const [newContactRole, setNewContactRole] = useState('');
  const [newContactEmail, setNewContactEmail] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [newContactType, setNewContactType] = useState('unknown');

  // Edit form state
  const [editInfluence, setEditInfluence] = useState(50);
  const [editSentiment, setEditSentiment] = useState(50);
  const [editChampion, setEditChampion] = useState(0);
  const [editType, setEditType] = useState('unknown');
  const [editRole, setEditRole] = useState('');

  // Deduplication hook
  const { autoMerge, manualMerge } = useStakeholderDeduplication(accountId, opportunityId);

  // Fetch contacts for this opportunity
  const { data: contacts, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['opportunity-stakeholders', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_contacts')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .not('is_ignored', 'is', true)
        .order('name', { ascending: true })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as Contact[];
    },
    retry: 2,
    retryDelay: 1000,
  });

  // Detect duplicates when contacts change
  useEffect(() => {
    if (contacts && contacts.length > 1) {
      const detected = detectDuplicates(contacts);
      setDuplicateGroups(detected);
      
      // Auto-merge high confidence duplicates (only once per load)
      if (!autoMergeRan && detected.filter(g => g.confidence === 'high').length > 0) {
        setAutoMergeRan(true);
        autoMerge.mutate(detected);
      }
    } else {
      setDuplicateGroups([]);
    }
  }, [contacts, autoMergeRan]);

  // Add contact mutation
  const addContact = useMutation({
    mutationFn: async (contact: { name: string; role: string; email: string; phone: string; stakeholder_type: string }) => {
      const { data, error } = await encryptedInsert('account_contacts', {
        account_id: accountId,
        opportunity_id: opportunityId,
        name: contact.name,
        role: contact.role || null,
        email: contact.email || null,
        phone: contact.phone || null,
        stakeholder_type: contact.stakeholder_type,
        is_ignored: false,
        is_internal: false,
        source: 'manual',
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-stakeholders', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-contacts', accountId] });
      toast.success('Stakeholder added');
      setIsAddDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast.error('Failed to add stakeholder: ' + error.message);
    },
  });

  // Update contact mutation
  const updateContact = useMutation({
    mutationFn: async ({ id, ...updates }: { id: string; influence_level?: number; sentiment?: number; champion_score?: number; stakeholder_type?: string; role?: string }) => {
      // Use gateway for non-encrypted fields
      const { error } = await gateway
        .from('account_contacts')
        .update(updates)
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-stakeholders', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-contacts', accountId] });
      toast.success('Stakeholder updated');
      setEditingContact(null);
    },
    onError: (error) => {
      toast.error('Failed to update stakeholder: ' + error.message);
    },
  });

  // Delete contact mutation
  const deleteContact = useMutation({
    mutationFn: async (contactId: string) => {
      const { error } = await gateway
        .from('account_contacts')
        .update({ is_ignored: true })
        .eq('id', contactId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-stakeholders', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-contacts', accountId] });
      toast.success('Stakeholder removed');
    },
  });

  // Merge handler using the hook
  const handleMergeContacts = () => {
    manualMerge.mutate(selectedForMerge, {
      onSuccess: () => {
        setMergeDialogOpen(false);
        setSelectedForMerge([]);
      },
    });
  };

  const resetForm = () => {
    setNewContactName('');
    setNewContactRole('');
    setNewContactEmail('');
    setNewContactPhone('');
    setNewContactType('unknown');
  };

  const handleAddContact = () => {
    if (!newContactName.trim()) {
      toast.error('Name is required');
      return;
    }
    addContact.mutate({
      name: newContactName,
      role: newContactRole,
      email: newContactEmail,
      phone: newContactPhone,
      stakeholder_type: newContactType,
    });
  };

  const openEditDialog = (contact: Contact) => {
    setEditingContact(contact);
    setEditInfluence(contact.influence_level ?? 50);
    setEditSentiment(contact.sentiment ?? 50);
    setEditChampion(contact.champion_score ?? 0);
    setEditType(contact.stakeholder_type ?? 'unknown');
    setEditRole(contact.role ?? '');
  };

  const handleUpdateContact = () => {
    if (!editingContact) return;
    updateContact.mutate({
      id: editingContact.id,
      influence_level: editInfluence,
      sentiment: editSentiment,
      champion_score: editChampion,
      stakeholder_type: editType,
    });
  };

  const toggleMergeSelection = (contactId: string) => {
    setSelectedForMerge(prev => 
      prev.includes(contactId) 
        ? prev.filter(id => id !== contactId)
        : [...prev, contactId]
    );
  };

  const getStakeholderTypeInfo = (type: string | null) => {
    return STAKEHOLDER_TYPES.find(t => t.value === type) || STAKEHOLDER_TYPES.find(t => t.value === 'unknown')!;
  };

  const getInfluenceLabel = (level: number | null) => {
    if (level === null) return 'Unknown';
    if (level >= 75) return 'High';
    if (level >= 50) return 'Medium';
    if (level >= 25) return 'Low';
    return 'Minimal';
  };

  const getSentimentLabel = (sentiment: number | null) => {
    if (sentiment === null) return 'Unknown';
    if (sentiment >= 75) return 'Positive';
    if (sentiment >= 50) return 'Neutral';
    if (sentiment >= 25) return 'Cautious';
    return 'Negative';
  };

  const getSentimentColor = (sentiment: number | null) => {
    if (sentiment === null) return 'bg-muted';
    if (sentiment >= 75) return 'bg-green-500/20 text-green-700 dark:text-green-400';
    if (sentiment >= 50) return 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-400';
    if (sentiment >= 25) return 'bg-orange-500/20 text-orange-700 dark:text-orange-400';
    return 'bg-red-500/20 text-red-700 dark:text-red-400';
  };

  // Filter duplicates by confidence for display (only show medium/low after auto-merge ran)
  // IMPORTANT: Must be called before any early returns to satisfy React hooks rules
  const pendingDuplicates = useMemo(() => {
    return duplicateGroups.filter(g => g.confidence !== 'high');
  }, [duplicateGroups]);

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <div className="h-8 w-48 bg-muted animate-pulse rounded" />
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-20 bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="p-6">
        <Card className="border-destructive/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="w-12 h-12 text-destructive mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">Failed to Load Stakeholders</h3>
            <p className="text-sm text-muted-foreground text-center max-w-md mb-4">
              {error instanceof Error ? error.message : 'An error occurred while loading stakeholders.'}
            </p>
            <Button variant="outline" onClick={() => refetch()}>
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Duplicate Alert */}
      {pendingDuplicates.length > 0 && (
        <Alert className="bg-amber-500/10 border-amber-500/30">
          <Sparkles className="h-4 w-4 text-amber-500" />
          <AlertTitle className="text-amber-700 dark:text-amber-400">
            Potential Duplicates Detected
          </AlertTitle>
          <AlertDescription className="text-amber-600 dark:text-amber-300">
            <span className="block mb-2">
              Found {pendingDuplicates.length} potential duplicate group{pendingDuplicates.length > 1 ? 's' : ''} ({pendingDuplicates.map(g => g.matchReason).join(', ')}).
              Click a group below to select and merge.
            </span>
            <div className="flex flex-wrap gap-2">
              {pendingDuplicates.map((group, i) => {
                const groupIds = [group.primary.id, ...group.duplicates.map(d => d.id)];
                const isSelected = groupIds.every(id => selectedForMerge.includes(id));
                return (
                  <Button
                    key={i}
                    variant={isSelected ? "default" : "outline"}
                    size="sm"
                    className={isSelected ? "" : "bg-background hover:bg-amber-500/20"}
                    onClick={() => {
                      if (isSelected) {
                        // Deselect this group
                        setSelectedForMerge(prev => prev.filter(id => !groupIds.includes(id)));
                      } else {
                        // Select this group (replace current selection to avoid mixing groups)
                        setSelectedForMerge(groupIds);
                      }
                    }}
                  >
                    <Merge className="w-3 h-3 mr-1.5" />
                    {group.primary.name} + {group.duplicates.length} more ({group.confidence})
                  </Button>
                );
              })}
            </div>
            {selectedForMerge.length >= 2 && (
              <div className="mt-3 pt-3 border-t border-amber-500/30">
                <Button 
                  size="sm"
                  onClick={() => setMergeDialogOpen(true)}
                  className="gap-2"
                >
                  <Merge className="w-4 h-4" />
                  Merge {selectedForMerge.length} Selected Contacts
                </Button>
              </div>
            )}
          </AlertDescription>
        </Alert>
      )}

      {/* Auto-merge success indicator */}
      {autoMerge.isSuccess && autoMerge.data?.merged > 0 && (
        <Alert className="bg-green-500/10 border-green-500/30">
          <CheckCircle2 className="h-4 w-4 text-green-500" />
          <AlertTitle className="text-green-700 dark:text-green-400">
            Auto-Merged Duplicates
          </AlertTitle>
          <AlertDescription className="text-green-600 dark:text-green-300">
            Automatically merged {autoMerge.data.merged} high-confidence duplicate group{autoMerge.data.merged > 1 ? 's' : ''}.
          </AlertDescription>
        </Alert>
      )}

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            Stakeholders
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            {contacts?.length || 0} contact{(contacts?.length || 0) !== 1 ? 's' : ''}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* View Toggle */}
          <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'list' | 'chart')} className="w-auto">
            <TabsList className="h-9">
              <TabsTrigger value="list" className="gap-1.5 px-3">
                <LayoutGrid className="w-4 h-4" />
                <span className="hidden sm:inline">List</span>
              </TabsTrigger>
              <TabsTrigger value="chart" className="gap-1.5 px-3">
                <Network className="w-4 h-4" />
                <span className="hidden sm:inline">Org Chart</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {selectedForMerge.length >= 2 && (
            <Button 
              variant="outline" 
              className="gap-2"
              onClick={() => setMergeDialogOpen(true)}
            >
              <Merge className="w-4 h-4" />
              Merge ({selectedForMerge.length})
            </Button>
          )}
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Add Stakeholder
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add Stakeholder</DialogTitle>
                <DialogDescription>
                  Add a new stakeholder to this opportunity
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label>Name *</Label>
                  <Input
                    value={newContactName}
                    onChange={(e) => setNewContactName(e.target.value)}
                    placeholder="Full name"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Stakeholder Type</Label>
                  <Select value={newContactType} onValueChange={setNewContactType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STAKEHOLDER_TYPES.map(type => {
                        const Icon = type.icon;
                        return (
                          <SelectItem key={type.value} value={type.value}>
                            <div className="flex items-center gap-2">
                              <Icon className={`w-4 h-4 ${type.color}`} />
                              <span>{type.label}</span>
                            </div>
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Role / Title</Label>
                  <Input
                    value={newContactRole}
                    onChange={(e) => setNewContactRole(e.target.value)}
                    placeholder="e.g., VP Engineering, Product Manager"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={newContactEmail}
                    onChange={(e) => setNewContactEmail(e.target.value)}
                    placeholder="email@company.com"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Phone</Label>
                  <Input
                    type="tel"
                    value={newContactPhone}
                    onChange={(e) => setNewContactPhone(e.target.value)}
                    placeholder="+1 (555) 123-4567"
                  />
                </div>

                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddContact} disabled={addContact.isPending}>
                    Add Stakeholder
                  </Button>
                </DialogFooter>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* View Content */}
      {contacts && contacts.length > 0 ? (
        <>
          {viewMode === 'list' ? (
            <>
              {/* Merge Selection Hint */}
              <p className="text-xs text-muted-foreground">
                💡 Tip: Select multiple stakeholders using checkboxes to merge duplicates (e.g., "Leanne" and "Lean")
              </p>

              {/* Contacts List */}
              <div className="grid gap-4 md:grid-cols-2">
                {contacts.map((contact) => {
                  const typeInfo = getStakeholderTypeInfo(contact.stakeholder_type);
                  const TypeIcon = typeInfo.icon;
                  
                  return (
                    <Card key={contact.id} className={selectedForMerge.includes(contact.id) ? 'ring-2 ring-primary' : ''}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          {/* Merge checkbox */}
                          <Checkbox
                            checked={selectedForMerge.includes(contact.id)}
                            onCheckedChange={() => toggleMergeSelection(contact.id)}
                            className="mt-1"
                          />
                          
                          {/* Stakeholder type icon */}
                          <div className={`w-10 h-10 rounded-full bg-muted flex items-center justify-center flex-shrink-0`}>
                            <TypeIcon className={`w-5 h-5 ${typeInfo.color}`} />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2 min-w-0">
                                <h3 className="font-medium truncate">{contact.name}</h3>
                                <Badge variant="secondary" className={`text-xs flex-shrink-0 ${typeInfo.color}`}>
                                  {typeInfo.label}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-1 flex-shrink-0">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-muted-foreground hover:text-primary"
                                  onClick={() => openEditDialog(contact)}
                                >
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                                  onClick={() => deleteContact.mutate(contact.id)}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                            
                            {contact.role && (
                              <p className="text-sm text-muted-foreground">{contact.role}</p>
                            )}
                            
                            <div className="flex flex-wrap gap-2 mt-2">
                              {contact.email && (
                                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                  <Mail className="w-3 h-3" />
                                  <span className="truncate max-w-[150px]">{contact.email}</span>
                                </div>
                              )}
                              {contact.phone && (
                                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                  <Phone className="w-3 h-3" />
                                  {contact.phone}
                                </div>
                              )}
                            </div>
                            
                            <div className="flex flex-wrap gap-2 mt-3">
                              <Badge variant="outline" className="text-xs">
                                Influence: {getInfluenceLabel(contact.influence_level)}
                              </Badge>
                              <Badge className={`text-xs ${getSentimentColor(contact.sentiment)}`}>
                                {getSentimentLabel(contact.sentiment)}
                              </Badge>
                              {contact.champion_score != null && contact.champion_score > 30 && (
                                <Badge variant="secondary" className="text-xs bg-yellow-500/20 text-yellow-700 dark:text-yellow-400">
                                  <Crown className="w-3 h-3 mr-1" />
                                  Champion: {contact.champion_score}%
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </>
          ) : (
            /* Org Chart View */
            <StakeholderOrgChart 
              contacts={contacts} 
              onContactClick={(contact) => openEditDialog(contact as Contact)}
            />
          )}
        </>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <Users className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
            <h3 className="font-medium mb-2">No stakeholders yet</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Add stakeholders to track contacts for this opportunity
            </p>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-1" />
              Add First Stakeholder
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Edit Dialog */}
      <Dialog open={!!editingContact} onOpenChange={(open) => !open && setEditingContact(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Stakeholder</DialogTitle>
            <DialogDescription>
              Update {editingContact?.name}'s assessment
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 pt-4">
            {/* Stakeholder Type */}
            <div className="space-y-2">
              <Label>Stakeholder Type</Label>
              <Select value={editType} onValueChange={setEditType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STAKEHOLDER_TYPES.map(type => {
                    const Icon = type.icon;
                    return (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center gap-2">
                          <Icon className={`w-4 h-4 ${type.color}`} />
                          <div>
                            <span>{type.label}</span>
                            <p className="text-xs text-muted-foreground">{type.description}</p>
                          </div>
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            {/* Influence Level */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Influence Level</Label>
                <span className="text-sm text-muted-foreground">{editInfluence}%</span>
              </div>
              <Slider
                value={[editInfluence]}
                onValueChange={([v]) => setEditInfluence(v)}
                max={100}
                step={5}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">
                C-level/VP: 80-100 | Director: 60-80 | Manager: 40-60 | IC: 20-40
              </p>
            </div>

            {/* Sentiment */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Sentiment</Label>
                <span className="text-sm text-muted-foreground">{editSentiment}%</span>
              </div>
              <Slider
                value={[editSentiment]}
                onValueChange={([v]) => setEditSentiment(v)}
                max={100}
                step={5}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">
                Enthusiastic: 80-100 | Positive: 60-80 | Neutral: 40-60 | Skeptical: 20-40
              </p>
            </div>

            {/* Champion Score */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-1">
                  <Crown className="w-4 h-4 text-yellow-500" />
                  Champion Score
                </Label>
                <span className="text-sm text-muted-foreground">{editChampion}%</span>
              </div>
              <Slider
                value={[editChampion]}
                onValueChange={([v]) => setEditChampion(v)}
                max={100}
                step={5}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">
                50+ requires both advocacy AND information sharing signals
              </p>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingContact(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateContact} disabled={updateContact.isPending}>
                Save Changes
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Merge Confirmation Dialog */}
      <Dialog open={mergeDialogOpen} onOpenChange={setMergeDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Merge Stakeholders</DialogTitle>
            <DialogDescription>
              Merge {selectedForMerge.length} selected stakeholders into one. The most complete record will be kept.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <p className="text-sm mb-3">Selected stakeholders to merge:</p>
            <div className="space-y-2">
              {selectedForMerge.map(id => {
                const contact = contacts?.find(c => c.id === id);
                return contact ? (
                  <div key={id} className="flex items-center gap-2 p-2 bg-muted rounded">
                    <UserCircle className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{contact.name}</span>
                    {contact.email && (
                      <span className="text-xs text-muted-foreground">({contact.email})</span>
                    )}
                  </div>
                ) : null;
              })}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setMergeDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleMergeContacts} 
              disabled={manualMerge.isPending}
              className="gap-2"
            >
              <Merge className="w-4 h-4" />
              Merge Stakeholders
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Plus, Trash2, Target, CheckCircle2, Clock, AlertCircle, Edit2, Save, X, Lightbulb, Link2, ListChecks, Sparkles, ThumbsUp, ThumbsDown, GitMerge, SquareCheck } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface SuccessCriterion {
  id: string;
  opportunity_id: string;
  criterion: string;
  metric_name: string | null;
  target_value: string | null;
  current_value: string | null;
  status: string;
  notes: string | null;
  source: string | null;
  linked_use_case_ids: string[] | null;
  created_at: string;
  updated_at: string;
}

interface Deliverable {
  id: string;
  criterion_id: string;
  title: string;
  is_completed: boolean;
  completed_at: string | null;
  sort_order: number;
}

interface LinkedUseCase {
  id: string;
  use_case: string | null;
  functional_area: string | null;
  acceptance_status: string | null;
  status: string;
}

const statusConfig: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  proposed: { label: 'AI Proposed', icon: Lightbulb, color: 'text-violet-500' },
  new: { label: 'New', icon: Clock, color: 'text-muted-foreground' },
  in_review: { label: 'In Review', icon: AlertCircle, color: 'text-blue-500' },
  awaiting_feedback: { label: 'Awaiting Feedback', icon: Clock, color: 'text-orange-500' },
  met: { label: 'Met', icon: CheckCircle2, color: 'text-emerald-600' },
  at_risk: { label: 'At Risk', icon: AlertCircle, color: 'text-destructive' },
  not_met: { label: 'Not Met', icon: X, color: 'text-destructive' },
  closed: { label: 'Closed', icon: X, color: 'text-muted-foreground' },
};

interface Props {
  opportunityId: string;
  accountId: string;
}

// Deliverables sub-component
function DeliverablesList({ criterionId }: { criterionId: string }) {
  const queryClient = useQueryClient();
  const [newTitle, setNewTitle] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  const { data: deliverables = [] } = useQuery({
    queryKey: ['deliverables', criterionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('success_criteria_deliverables')
        .select('*')
        .eq('criterion_id', criterionId)
        .order('sort_order')
        .order('created_at');
      if (error) throw error;
      return data as Deliverable[];
    },
  });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ['deliverables', criterionId] });

  const handleAdd = async () => {
    if (!newTitle.trim()) return;
    const { error } = await supabase
      .from('success_criteria_deliverables')
      .insert({ criterion_id: criterionId, title: newTitle.trim(), sort_order: deliverables.length, is_completed: false } as any);
    if (error) { toast.error('Failed to add deliverable'); return; }
    setNewTitle('');
    setShowAdd(false);
    refresh();
  };

  const handleToggle = async (id: string, completed: boolean) => {
    const { error } = await supabase
      .from('success_criteria_deliverables')
      .update({
        is_completed: completed,
        completed_at: completed ? new Date().toISOString() : null,
        updated_at: new Date().toISOString(),
      } as any)
      .eq('id', id);
    if (error) { toast.error('Failed to update'); return; }
    refresh();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('success_criteria_deliverables').delete().eq('id', id);
    if (error) { toast.error('Failed to delete'); return; }
    refresh();
  };

  const handleStartEdit = (d: Deliverable) => {
    setEditingId(d.id);
    setEditingTitle(d.title);
  };

  const handleSaveEdit = async () => {
    if (!editingId || !editingTitle.trim()) { setEditingId(null); return; }
    const { error } = await supabase
      .from('success_criteria_deliverables')
      .update({ title: editingTitle.trim(), updated_at: new Date().toISOString() } as any)
      .eq('id', editingId);
    if (error) { toast.error('Failed to update deliverable'); return; }
    setEditingId(null);
    refresh();
  };

  const handleEditKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') { e.preventDefault(); handleSaveEdit(); }
    if (e.key === 'Escape') { setEditingId(null); }
  };

  const completedCount = deliverables.filter(d => d.is_completed).length;

  return (
    <div className="ml-6 mt-3 border-l-2 border-primary/20 pl-4 space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs font-medium text-foreground">
          <ListChecks className="w-3.5 h-3.5 text-primary" />
          <span>Deliverables</span>
          {deliverables.length > 0 && (
            <Badge variant="outline" className={cn(
              "text-[10px] px-1.5 py-0 h-4",
              completedCount === deliverables.length && deliverables.length > 0 ? "border-emerald-500 text-emerald-600" : ""
            )}>
              {completedCount}/{deliverables.length}
            </Badge>
          )}
        </div>
        {!showAdd && (
          <Button
            variant="ghost"
            size="sm"
            className="h-6 text-xs gap-1 text-primary hover:text-primary"
            onClick={() => setShowAdd(true)}
          >
            <Plus className="w-3 h-3" /> Add
          </Button>
        )}
      </div>
      {deliverables.map((d) => (
        <div key={d.id} className="flex items-center gap-2 group py-0.5">
          <Checkbox
            checked={d.is_completed}
            onCheckedChange={(checked) => handleToggle(d.id, !!checked)}
            className="h-4 w-4"
          />
          {editingId === d.id ? (
            <Input
              className="h-7 text-sm flex-1"
              value={editingTitle}
              onChange={(e) => setEditingTitle(e.target.value)}
              onBlur={handleSaveEdit}
              onKeyDown={handleEditKeyDown}
              autoFocus
            />
          ) : (
            <span
              className={cn("text-sm flex-1 cursor-pointer hover:text-primary rounded px-1 -mx-1 transition-colors", d.is_completed && "line-through text-muted-foreground")}
              onClick={() => handleStartEdit(d)}
              title="Click to edit"
            >
              {d.title}
            </span>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={() => handleDelete(d.id)}
          >
            <X className="w-3 h-3 text-muted-foreground hover:text-destructive" />
          </Button>
        </div>
      ))}
      {showAdd && (
        <div className="flex items-center gap-2">
          <Input
            className="h-8 text-sm"
            placeholder="e.g. Create a funnel report showing user path from home to checkout"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
            autoFocus
          />
          <Button size="sm" className="h-8 text-xs px-3" onClick={handleAdd}>Add</Button>
          <Button size="sm" variant="ghost" className="h-8 text-xs px-2" onClick={() => { setShowAdd(false); setNewTitle(''); }}>Cancel</Button>
        </div>
      )}
      {deliverables.length === 0 && !showAdd && (
        <p className="text-xs text-muted-foreground italic">No deliverables yet — add specific tasks like reports, dashboards, or configurations to track.</p>
      )}
    </div>
  );
}

export function OpportunitySuccessCriteriaTab({ opportunityId, accountId }: Props) {
  const queryClient = useQueryClient();
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newCriterion, setNewCriterion] = useState('');
  const [newMetric, setNewMetric] = useState('');
  const [newTarget, setNewTarget] = useState('');
  const [newLinkedIds, setNewLinkedIds] = useState<string[]>([]);
  const [editValues, setEditValues] = useState<Partial<SuccessCriterion>>({});
  const [newNotes, setNewNotes] = useState('');
  const [newDeliverables, setNewDeliverables] = useState<string[]>([]);
  const [newDeliverableInput, setNewDeliverableInput] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // Bulk selection state
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [selectionMode, setSelectionMode] = useState(false);
  const [showMergeDialog, setShowMergeDialog] = useState(false);
  const [mergePrimaryId, setMergePrimaryId] = useState<string | null>(null);
  const [showBulkStatusDialog, setShowBulkStatusDialog] = useState(false);
  const [bulkStatusValue, setBulkStatusValue] = useState('new');
  const [showBulkUseCaseDialog, setShowBulkUseCaseDialog] = useState(false);
  const [bulkUseCaseIds, setBulkUseCaseIds] = useState<string[]>([]);
  const [isBulkProcessing, setIsBulkProcessing] = useState(false);

  const { data: criteria, isLoading } = useQuery({
    queryKey: ['success-criteria', opportunityId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('evaluation_success_criteria')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('created_at');
      if (error) throw error;
      return data as SuccessCriterion[];
    },
  });

  // Fetch linked use cases (those with acceptance_status set) for this opportunity
  const { data: linkedUseCases } = useQuery({
    queryKey: ['linked-use-cases-for-criteria', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_use_cases')
        .select('id, use_case, functional_area, acceptance_status, status')
        .eq('opportunity_id', opportunityId)
        .not('acceptance_status', 'is', null)
        .order('created_at')
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as LinkedUseCase[];
    },
  });

  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ['success-criteria', opportunityId] });
  };

  const addDeliverableToList = () => {
    const trimmed = newDeliverableInput.trim();
    if (!trimmed) return;
    setNewDeliverables(prev => [...prev, trimmed]);
    setNewDeliverableInput('');
  };

  const removeDeliverableFromList = (index: number) => {
    setNewDeliverables(prev => prev.filter((_, i) => i !== index));
  };

  const resetForm = () => {
    setNewCriterion(''); setNewMetric(''); setNewTarget(''); setNewLinkedIds([]);
    setNewNotes(''); setNewDeliverables([]); setNewDeliverableInput('');
    setShowAddForm(false);
  };

  const handleAdd = async () => {
    if (!newCriterion.trim()) return;
    setIsSaving(true);
    try {
      const { data: inserted, error } = await supabase
        .from('evaluation_success_criteria')
        .insert({
          opportunity_id: opportunityId,
          criterion: newCriterion.trim(),
          metric_name: newMetric.trim() || null,
          target_value: newTarget.trim() || null,
          notes: newNotes.trim() || null,
          linked_use_case_ids: newLinkedIds.length > 0 ? newLinkedIds : null,
          status: 'new',
        } as any)
        .select('id')
        .single();
      if (error) { toast.error('Failed to add criterion'); return; }

      // Batch-insert deliverables if any
      if (newDeliverables.length > 0 && inserted?.id) {
        const deliverableRows = newDeliverables.map((title, i) => ({
          criterion_id: inserted.id,
          title,
          sort_order: i,
          is_completed: false,
        }));
        const { error: delError } = await supabase
          .from('success_criteria_deliverables')
          .insert(deliverableRows as any);
        if (delError) {
          toast.error('Criterion added but failed to save deliverables');
        }
      }

      toast.success('Success criterion added');
      resetForm();
      refresh();
      // Also refresh deliverables for the new criterion
      if (inserted?.id) {
        queryClient.invalidateQueries({ queryKey: ['deliverables', inserted.id] });
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleStatusChange = async (id: string, status: string) => {
    const { error } = await supabase
      .from('evaluation_success_criteria')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) { toast.error('Failed to update'); return; }
    refresh();
  };

  const handleSaveEdit = async (id: string) => {
    const { error } = await supabase
      .from('evaluation_success_criteria')
      .update({ ...editValues, updated_at: new Date().toISOString() } as any)
      .eq('id', id);
    if (error) { toast.error('Failed to update'); return; }
    toast.success('Updated');
    setEditingId(null);
    refresh();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('evaluation_success_criteria').delete().eq('id', id);
    if (error) { toast.error('Failed to delete'); return; }
    toast.success('Criterion removed');
    refresh();
  };

  const handleAcceptProposal = async (id: string) => {
    const { error } = await supabase
      .from('evaluation_success_criteria')
      .update({ status: 'new', updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) { toast.error('Failed to accept'); return; }
    toast.success('Criterion accepted');
    refresh();
  };

  const handleRejectProposal = async (id: string) => {
    const { error } = await supabase.from('evaluation_success_criteria').delete().eq('id', id);
    if (error) { toast.error('Failed to reject'); return; }
    toast.success('Criterion rejected');
    refresh();
  };

  const handleAcceptAll = async () => {
    const proposed = criteria?.filter(c => c.status === 'proposed') || [];
    if (proposed.length === 0) return;
    const { error } = await supabase
      .from('evaluation_success_criteria')
      .update({ status: 'new', updated_at: new Date().toISOString() })
      .in('id', proposed.map(c => c.id));
    if (error) { toast.error('Failed to accept all'); return; }
    toast.success(`${proposed.length} criteria accepted`);
    refresh();
  };

  const toggleUseCaseLink = (ids: string[], ucId: string): string[] => {
    return ids.includes(ucId) ? ids.filter(i => i !== ucId) : [...ids, ucId];
  };

  const getUseCaseNames = (ucIds: string[] | null): LinkedUseCase[] => {
    if (!ucIds || !linkedUseCases) return [];
    return linkedUseCases.filter(uc => ucIds.includes(uc.id));
  };

  // Bulk selection helpers
  const toggleSelection = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const selectAll = () => {
    const allIds = (criteria || []).map(c => c.id);
    setSelectedIds(new Set(allIds));
  };

  const clearSelection = () => {
    setSelectedIds(new Set());
    setSelectionMode(false);
  };

  const selectedCriteria = (criteria || []).filter(c => selectedIds.has(c.id));

  // Bulk Accept (proposed → new)
  const handleBulkAccept = async () => {
    const proposed = selectedCriteria.filter(c => c.status === 'proposed');
    if (proposed.length === 0) { toast.error('No proposed criteria selected'); return; }
    setIsBulkProcessing(true);
    const { error } = await supabase
      .from('evaluation_success_criteria')
      .update({ status: 'new', updated_at: new Date().toISOString() })
      .in('id', proposed.map(c => c.id));
    setIsBulkProcessing(false);
    if (error) { toast.error('Failed to accept'); return; }
    toast.success(`${proposed.length} criteria accepted`);
    clearSelection();
    refresh();
  };

  // Bulk Delete
  const handleBulkDelete = async () => {
    if (selectedIds.size === 0) return;
    setIsBulkProcessing(true);
    const { error } = await supabase
      .from('evaluation_success_criteria')
      .delete()
      .in('id', Array.from(selectedIds));
    setIsBulkProcessing(false);
    if (error) { toast.error('Failed to delete'); return; }
    toast.success(`${selectedIds.size} criteria deleted`);
    clearSelection();
    refresh();
  };

  // Bulk Change Status
  const handleBulkStatusChange = async () => {
    if (selectedIds.size === 0) return;
    setIsBulkProcessing(true);
    const { error } = await supabase
      .from('evaluation_success_criteria')
      .update({ status: bulkStatusValue, updated_at: new Date().toISOString() })
      .in('id', Array.from(selectedIds));
    setIsBulkProcessing(false);
    if (error) { toast.error('Failed to update status'); return; }
    toast.success(`${selectedIds.size} criteria updated to ${statusConfig[bulkStatusValue]?.label || bulkStatusValue}`);
    setShowBulkStatusDialog(false);
    clearSelection();
    refresh();
  };

  // Bulk Assign Use Cases
  const handleBulkAssignUseCases = async () => {
    if (selectedIds.size === 0 || bulkUseCaseIds.length === 0) return;
    setIsBulkProcessing(true);
    // For each selected criterion, merge the new use case IDs with existing ones
    let success = 0;
    for (const c of selectedCriteria) {
      const existingIds = c.linked_use_case_ids || [];
      const mergedIds = [...new Set([...existingIds, ...bulkUseCaseIds])];
      const { error } = await supabase
        .from('evaluation_success_criteria')
        .update({ linked_use_case_ids: mergedIds, updated_at: new Date().toISOString() } as any)
        .eq('id', c.id);
      if (!error) success++;
    }
    setIsBulkProcessing(false);
    toast.success(`${success} criteria linked to use cases`);
    setShowBulkUseCaseDialog(false);
    setBulkUseCaseIds([]);
    clearSelection();
    refresh();
  };

  // Merge: pick primary, combine notes/deliverables/use-case links, delete others
  const handleMerge = async () => {
    if (!mergePrimaryId || selectedIds.size < 2) return;
    const primary = selectedCriteria.find(c => c.id === mergePrimaryId);
    const others = selectedCriteria.filter(c => c.id !== mergePrimaryId);
    if (!primary) return;

    setIsBulkProcessing(true);
    try {
      // Combine notes
      const allNotes = [primary.notes, ...others.map(c => c.notes)].filter(Boolean);
      const combinedNotes = allNotes.join('\n---\n');

      // Combine linked use case IDs
      const allUcIds = [
        ...(primary.linked_use_case_ids || []),
        ...others.flatMap(c => c.linked_use_case_ids || []),
      ];
      const uniqueUcIds = [...new Set(allUcIds)];

      // Update primary with merged data
      const { error: updateError } = await supabase
        .from('evaluation_success_criteria')
        .update({
          notes: combinedNotes || null,
          linked_use_case_ids: uniqueUcIds.length > 0 ? uniqueUcIds : null,
          updated_at: new Date().toISOString(),
        } as any)
        .eq('id', mergePrimaryId);
      if (updateError) throw updateError;

      // Move deliverables from others to primary
      const otherIds = others.map(c => c.id);
      const { error: moveError } = await supabase
        .from('success_criteria_deliverables')
        .update({ criterion_id: mergePrimaryId } as any)
        .in('criterion_id', otherIds);
      if (moveError) console.warn('Failed to move some deliverables:', moveError);

      // Delete the merged-away criteria
      const { error: deleteError } = await supabase
        .from('evaluation_success_criteria')
        .delete()
        .in('id', otherIds);
      if (deleteError) throw deleteError;

      toast.success(`Merged ${selectedIds.size} criteria into one`);
    } catch (e: any) {
      toast.error('Merge failed: ' + (e.message || 'Unknown error'));
    } finally {
      setIsBulkProcessing(false);
      setShowMergeDialog(false);
      setMergePrimaryId(null);
      clearSelection();
      refresh();
      // Refresh all deliverable queries
      queryClient.invalidateQueries({ queryKey: ['deliverables'] });
    }
  };

  const UseCaseLinkPicker = ({ selectedIds: selIds, onChange }: { selectedIds: string[]; onChange: (ids: string[]) => void }) => (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5 text-xs h-8">
          <Link2 className="w-3.5 h-3.5" />
          {selIds.length > 0 ? `${selIds.length} linked` : 'Link Use Cases'}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-3" align="start">
        <p className="text-xs font-medium text-muted-foreground mb-2">Link to use cases:</p>
        {linkedUseCases && linkedUseCases.length > 0 ? (
          <div className="space-y-2 max-h-48 overflow-auto">
            {linkedUseCases.map(uc => (
              <label key={uc.id} className="flex items-start gap-2 cursor-pointer hover:bg-muted/50 rounded p-1.5 -mx-1.5">
                <Checkbox
                  checked={selIds.includes(uc.id)}
                  onCheckedChange={() => onChange(toggleUseCaseLink(selIds, uc.id))}
                  className="mt-0.5"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{uc.use_case}</p>
                  {uc.functional_area && (
                    <p className="text-xs text-muted-foreground">{uc.functional_area}</p>
                  )}
                </div>
              </label>
            ))}
          </div>
        ) : (
          <p className="text-xs text-muted-foreground">No linked use cases available. Accept use cases first.</p>
        )}
      </PopoverContent>
    </Popover>
  );

  const proposedCriteria = criteria?.filter(c => c.status === 'proposed') || [];
  const activeCriteria = criteria?.filter(c => c.status !== 'proposed') || [];
  const metCount = activeCriteria.filter(c => c.status === 'met').length;
  const totalCount = activeCriteria.length;

  return (
    <div className="p-6 space-y-6">
      {/* Summary */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Success Criteria
          </h2>
          <p className="text-sm text-muted-foreground">
            Define measurable outcomes for this evaluation
          </p>
        </div>
        <div className="flex items-center gap-3">
          {(criteria || []).length > 0 && (
            <Button
              size="sm"
              variant={selectionMode ? "default" : "outline"}
              className="gap-1.5 text-xs"
              onClick={() => {
                if (selectionMode) clearSelection();
                else setSelectionMode(true);
              }}
            >
              <SquareCheck className="w-3.5 h-3.5" />
              {selectionMode ? 'Cancel' : 'Select'}
            </Button>
          )}
          {selectionMode && (criteria || []).length > 0 && (
            <Button size="sm" variant="outline" className="text-xs" onClick={selectAll}>
              Select All
            </Button>
          )}
          {totalCount > 0 && (
            <Badge variant="outline" className={cn(
              "text-sm",
              metCount === totalCount && totalCount > 0 ? "border-emerald-500 text-emerald-600" : ""
            )}>
              {metCount} / {totalCount} met
            </Badge>
          )}
          <Button size="sm" onClick={() => setShowAddForm(true)}>
            <Plus className="w-4 h-4 mr-1" /> Add Criterion
          </Button>
        </div>
      </div>

      {/* Add form */}
      {showAddForm && (
        <Card>
          <CardContent className="pt-6 space-y-4">
            <Input
              placeholder="Success criterion (e.g., 'Reduce onboarding time by 50%')"
              value={newCriterion}
              onChange={(e) => setNewCriterion(e.target.value)}
              autoFocus
            />
            <div className="grid grid-cols-2 gap-4">
              <Input
                placeholder="Metric name (optional)"
                value={newMetric}
                onChange={(e) => setNewMetric(e.target.value)}
              />
              <Input
                placeholder="Target value (optional)"
                value={newTarget}
                onChange={(e) => setNewTarget(e.target.value)}
              />
            </div>
            <Textarea
              placeholder="Notes (optional) — additional context, constraints, or background"
              value={newNotes}
              onChange={(e) => setNewNotes(e.target.value)}
              className="min-h-[60px]"
            />
            <UseCaseLinkPicker selectedIds={newLinkedIds} onChange={setNewLinkedIds} />
            {newLinkedIds.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {getUseCaseNames(newLinkedIds).map(uc => (
                  <Badge key={uc.id} variant="secondary" className="text-xs gap-1">
                    <Lightbulb className="w-3 h-3" />
                    {uc.use_case}
                    <button onClick={() => setNewLinkedIds(newLinkedIds.filter(i => i !== uc.id))} className="ml-1 hover:text-destructive">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}

            {/* Inline deliverables builder */}
            <div className="border-t border-border pt-3 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-medium text-foreground">
                <ListChecks className="w-3.5 h-3.5 text-primary" />
                Deliverables
                <span className="text-muted-foreground font-normal">(what needs to be built or shown)</span>
              </div>
              {newDeliverables.map((d, i) => (
                <div key={i} className="flex items-center gap-2 ml-5">
                  <Checkbox checked={false} disabled className="h-4 w-4 opacity-50" />
                  <span className="text-sm flex-1">{d}</span>
                  <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => removeDeliverableFromList(i)}>
                    <X className="w-3 h-3 text-muted-foreground hover:text-destructive" />
                  </Button>
                </div>
              ))}
              <div className="flex items-center gap-2 ml-5">
                <Plus className="w-4 h-4 text-muted-foreground shrink-0" />
                <Input
                  className="h-8 text-sm"
                  placeholder="e.g. Funnel report from homepage to checkout"
                  value={newDeliverableInput}
                  onChange={(e) => setNewDeliverableInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); addDeliverableToList(); }
                  }}
                />
                {newDeliverableInput.trim() && (
                  <Button size="sm" variant="ghost" className="h-8 text-xs shrink-0" onClick={addDeliverableToList}>
                    + Add
                  </Button>
                )}
              </div>
              {newDeliverables.length === 0 && (
                <p className="text-xs text-muted-foreground ml-5 italic">
                  Press Enter after each deliverable to add multiple
                </p>
              )}
            </div>

            <div className="flex gap-2 pt-1">
              <Button size="sm" onClick={handleAdd} disabled={isSaving || !newCriterion.trim()}>
                {isSaving ? 'Saving...' : `Add Criterion${newDeliverables.length > 0 ? ` + ${newDeliverables.length} deliverable${newDeliverables.length > 1 ? 's' : ''}` : ''}`}
              </Button>
              <Button size="sm" variant="ghost" onClick={resetForm}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* AI Proposed Criteria */}
      {proposedCriteria.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-violet-500" />
              <span className="text-sm font-medium">AI Proposed Criteria</span>
              <Badge variant="outline" className="text-xs border-violet-500/30 text-violet-600">
                {proposedCriteria.length} pending review
              </Badge>
            </div>
            <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={handleAcceptAll}>
              <ThumbsUp className="w-3 h-3" /> Accept All
            </Button>
          </div>
          {proposedCriteria.map((c) => {
            const linkedUcs = getUseCaseNames(c.linked_use_case_ids);
            return (
              <Card key={c.id} className={cn("border-violet-500/20 bg-violet-500/5", selectionMode && selectedIds.has(c.id) && "ring-2 ring-primary")}>
                <CardContent className="pt-4 pb-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        {selectionMode && (
                          <Checkbox
                            checked={selectedIds.has(c.id)}
                            onCheckedChange={() => toggleSelection(c.id)}
                            className="mt-0.5"
                          />
                        )}
                        <Sparkles className="w-4 h-4 text-violet-500" />
                        <span className="font-medium text-sm">{c.criterion}</span>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">AI Proposed</Badge>
                      </div>
                      {(c.metric_name || c.target_value) && (
                        <div className="flex items-center gap-4 text-xs text-muted-foreground ml-6">
                          {c.metric_name && <span>Metric: {c.metric_name}</span>}
                          {c.target_value && <span>Target: {c.target_value}</span>}
                        </div>
                      )}
                      {linkedUcs.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 ml-6 mt-1">
                          {linkedUcs.map(uc => (
                            <Badge key={uc.id} variant="outline" className="text-xs gap-1 border-primary/30 text-primary">
                              <Lightbulb className="w-3 h-3" />
                              {uc.use_case}
                            </Badge>
                          ))}
                        </div>
                      )}
                      {c.notes && (
                        <p className="text-xs text-muted-foreground ml-6">{c.notes}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <Button size="sm" variant="outline" className="h-8 gap-1 text-xs border-emerald-500/40 text-emerald-600 hover:bg-emerald-500/10" onClick={() => handleAcceptProposal(c.id)}>
                        <ThumbsUp className="w-3 h-3" /> Accept
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 gap-1 text-xs text-destructive" onClick={() => handleRejectProposal(c.id)}>
                        <ThumbsDown className="w-3 h-3" /> Reject
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditingId(c.id); setEditValues({}); }}>
                        <Edit2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <DeliverablesList criterionId={c.id} />
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Active Criteria list */}
      {isLoading ? (
        <div className="text-sm text-muted-foreground">Loading...</div>
      ) : activeCriteria.length > 0 ? (
        <div className="space-y-3">
          {activeCriteria.map((c) => {
            const cfg = statusConfig[c.status] || statusConfig.new;
            const StatusIcon = cfg.icon;
            const isEditing = editingId === c.id;
            const linkedUcs = getUseCaseNames(c.linked_use_case_ids);

            return (
              <Card key={c.id} className={cn(selectionMode && selectedIds.has(c.id) && "ring-2 ring-primary")}>
                <CardContent className="pt-4 pb-4">
                  {selectionMode && !isEditing && (
                    <div className="flex items-center gap-2 mb-2">
                      <Checkbox
                        checked={selectedIds.has(c.id)}
                        onCheckedChange={() => toggleSelection(c.id)}
                      />
                      <span className="text-xs text-muted-foreground">Select for bulk action</span>
                    </div>
                  )}
                  {isEditing ? (
                    <div className="space-y-3">
                      <Input
                        value={editValues.criterion ?? c.criterion}
                        onChange={(e) => setEditValues({ ...editValues, criterion: e.target.value })}
                      />
                      <div className="grid grid-cols-3 gap-3">
                        <Input
                          placeholder="Metric name"
                          value={editValues.metric_name ?? c.metric_name ?? ''}
                          onChange={(e) => setEditValues({ ...editValues, metric_name: e.target.value || null })}
                        />
                        <Input
                          placeholder="Target value"
                          value={editValues.target_value ?? c.target_value ?? ''}
                          onChange={(e) => setEditValues({ ...editValues, target_value: e.target.value || null })}
                        />
                        <Input
                          placeholder="Current value"
                          value={editValues.current_value ?? c.current_value ?? ''}
                          onChange={(e) => setEditValues({ ...editValues, current_value: e.target.value || null })}
                        />
                      </div>
                      <Textarea
                        placeholder="Notes"
                        value={editValues.notes ?? c.notes ?? ''}
                        onChange={(e) => setEditValues({ ...editValues, notes: e.target.value || null })}
                        rows={2}
                      />
                      <div className="flex items-center gap-2">
                        <UseCaseLinkPicker
                          selectedIds={(editValues.linked_use_case_ids ?? c.linked_use_case_ids ?? []) as string[]}
                          onChange={(ids) => setEditValues({ ...editValues, linked_use_case_ids: ids })}
                        />
                      </div>
                      {((editValues.linked_use_case_ids ?? c.linked_use_case_ids) || []).length > 0 && (
                        <div className="flex flex-wrap gap-1.5">
                          {getUseCaseNames((editValues.linked_use_case_ids ?? c.linked_use_case_ids) as string[]).map(uc => (
                            <Badge key={uc.id} variant="secondary" className="text-xs gap-1">
                              <Lightbulb className="w-3 h-3" />
                              {uc.use_case}
                            </Badge>
                          ))}
                        </div>
                      )}
                      <div className="flex gap-2">
                        <Button size="sm" onClick={() => handleSaveEdit(c.id)}>
                          <Save className="w-3 h-3 mr-1" /> Save
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>Cancel</Button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2">
                            <StatusIcon className={cn("w-4 h-4", cfg.color)} />
                            <span className="font-medium text-sm">{c.criterion}</span>
                            {c.source === 'ai_proposed' && (
                              <Badge variant="secondary" className="text-xs">AI</Badge>
                            )}
                          </div>
                          {(c.metric_name || c.target_value || c.current_value) && (
                            <div className="flex items-center gap-4 text-xs text-muted-foreground ml-6">
                              {c.metric_name && <span>Metric: {c.metric_name}</span>}
                              {c.target_value && <span>Target: {c.target_value}</span>}
                              {c.current_value && <span>Current: <strong>{c.current_value}</strong></span>}
                            </div>
                          )}
                          {linkedUcs.length > 0 && (
                            <div className="flex flex-wrap gap-1.5 ml-6 mt-1">
                              {linkedUcs.map(uc => (
                                <Badge key={uc.id} variant="outline" className="text-xs gap-1 border-primary/30 text-primary">
                                  <Lightbulb className="w-3 h-3" />
                                  {uc.use_case}
                                </Badge>
                              ))}
                            </div>
                          )}
                          {c.notes && (
                            <p className="text-xs text-muted-foreground ml-6">{c.notes}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <Select value={c.status} onValueChange={(v) => handleStatusChange(c.id, v)}>
                            <SelectTrigger className="h-8 w-[150px] text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.entries(statusConfig).filter(([key]) => key !== 'proposed').map(([key, val]) => (
                                <SelectItem key={key} value={key}>{val.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditingId(c.id); setEditValues({}); }}>
                            <Edit2 className="w-3 h-3" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => handleDelete(c.id)}>
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      {/* Deliverables checklist */}
                      <DeliverablesList criterionId={c.id} />
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : !proposedCriteria.length ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Target className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground mb-4">No success criteria defined yet</p>
            <Button size="sm" onClick={() => setShowAddForm(true)}>
              <Plus className="w-4 h-4 mr-1" /> Add First Criterion
            </Button>
          </CardContent>
        </Card>
      ) : null}

      {/* Floating Bulk Action Bar */}
      {selectionMode && selectedIds.size > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-background border border-border shadow-xl rounded-xl px-5 py-3 flex items-center gap-3 animate-in slide-in-from-bottom-4">
          <Badge variant="secondary" className="text-sm font-semibold px-3 py-1">
            {selectedIds.size} selected
          </Badge>
          <div className="h-6 w-px bg-border" />
          {selectedCriteria.some(c => c.status === 'proposed') && (
            <Button size="sm" variant="outline" className="gap-1.5 text-xs border-emerald-500/40 text-emerald-600 hover:bg-emerald-500/10" onClick={handleBulkAccept} disabled={isBulkProcessing}>
              <ThumbsUp className="w-3 h-3" /> Accept
            </Button>
          )}
          <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={() => setShowBulkStatusDialog(true)} disabled={isBulkProcessing}>
            <CheckCircle2 className="w-3 h-3" /> Status
          </Button>
          {selectedIds.size >= 2 && (
            <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={() => { setMergePrimaryId(null); setShowMergeDialog(true); }} disabled={isBulkProcessing}>
              <GitMerge className="w-3 h-3" /> Merge
            </Button>
          )}
          <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={() => { setBulkUseCaseIds([]); setShowBulkUseCaseDialog(true); }} disabled={isBulkProcessing}>
            <Link2 className="w-3 h-3" /> Assign Use Case
          </Button>
          <div className="h-6 w-px bg-border" />
          <Button size="sm" variant="outline" className="gap-1.5 text-xs text-destructive border-destructive/30 hover:bg-destructive/10" onClick={handleBulkDelete} disabled={isBulkProcessing}>
            <Trash2 className="w-3 h-3" /> Delete
          </Button>
          <Button size="sm" variant="ghost" className="text-xs ml-1" onClick={clearSelection}>
            <X className="w-3.5 h-3.5" />
          </Button>
        </div>
      )}

      {/* Merge Dialog */}
      <Dialog open={showMergeDialog} onOpenChange={setShowMergeDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Merge {selectedIds.size} Criteria</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Choose the primary criterion. Notes, deliverables, and use-case links from the others will be combined into it.
          </p>
          <RadioGroup value={mergePrimaryId || ''} onValueChange={setMergePrimaryId} className="space-y-2 mt-2 max-h-64 overflow-auto">
            {selectedCriteria.map(c => (
              <div key={c.id} className="flex items-start gap-3 p-2 rounded-lg border border-border hover:bg-muted/50">
                <RadioGroupItem value={c.id} id={`merge-${c.id}`} className="mt-0.5" />
                <Label htmlFor={`merge-${c.id}`} className="flex-1 cursor-pointer">
                  <span className="text-sm font-medium">{c.criterion}</span>
                  {c.notes && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{c.notes}</p>}
                </Label>
              </div>
            ))}
          </RadioGroup>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowMergeDialog(false)}>Cancel</Button>
            <Button onClick={handleMerge} disabled={!mergePrimaryId || isBulkProcessing}>
              {isBulkProcessing ? 'Merging...' : 'Merge into Selected'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Status Dialog */}
      <Dialog open={showBulkStatusDialog} onOpenChange={setShowBulkStatusDialog}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Change Status ({selectedIds.size} criteria)</DialogTitle>
          </DialogHeader>
          <Select value={bulkStatusValue} onValueChange={setBulkStatusValue}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(statusConfig).map(([key, val]) => (
                <SelectItem key={key} value={key}>{val.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowBulkStatusDialog(false)}>Cancel</Button>
            <Button onClick={handleBulkStatusChange} disabled={isBulkProcessing}>
              {isBulkProcessing ? 'Updating...' : 'Apply'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Use Case Assignment Dialog */}
      <Dialog open={showBulkUseCaseDialog} onOpenChange={setShowBulkUseCaseDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Assign Use Cases ({selectedIds.size} criteria)</DialogTitle>
          </DialogHeader>
          {linkedUseCases && linkedUseCases.length > 0 ? (
            <div className="space-y-2 max-h-64 overflow-auto">
              {linkedUseCases.map(uc => (
                <label key={uc.id} className="flex items-start gap-2 cursor-pointer hover:bg-muted/50 rounded p-2">
                  <Checkbox
                    checked={bulkUseCaseIds.includes(uc.id)}
                    onCheckedChange={() => {
                      setBulkUseCaseIds(prev =>
                        prev.includes(uc.id) ? prev.filter(i => i !== uc.id) : [...prev, uc.id]
                      );
                    }}
                    className="mt-0.5"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{uc.use_case}</p>
                    {uc.functional_area && <p className="text-xs text-muted-foreground">{uc.functional_area}</p>}
                  </div>
                </label>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No use cases available. Accept use cases first.</p>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowBulkUseCaseDialog(false)}>Cancel</Button>
            <Button onClick={handleBulkAssignUseCases} disabled={bulkUseCaseIds.length === 0 || isBulkProcessing}>
              {isBulkProcessing ? 'Assigning...' : `Link ${bulkUseCaseIds.length} Use Case${bulkUseCaseIds.length !== 1 ? 's' : ''}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

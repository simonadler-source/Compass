import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Users, Mail, Calendar, Plus, Trash2, UserCog, Briefcase, Check, ChevronsUpDown, UserPlus } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { useAssignableOpportunityUsers } from '@/hooks/useAssignableOpportunityUsers';
import { useInviteTeamMember } from '@/hooks/useInviteTeamMember';
import { useAllActiveUsers } from '@/hooks/useAllActiveUsers';
import { useCustomRoles } from '@/hooks/useCustomRoles';
import { cn } from '@/lib/utils';

// Helper to check if a value looks like a valid email (not a date or other invalid data)
const isValidEmail = (value: string | null | undefined): boolean => {
  if (!value) return false;
  // Check if it looks like an email (contains @ and doesn't contain / which indicates a date)
  return value.includes('@') && !value.includes('/');
};

interface OpportunityTeamTabProps {
  opportunityId: string;
}

export function OpportunityTeamTab({ opportunityId }: OpportunityTeamTabProps) {
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberRole, setNewMemberRole] = useState('member');
  const [userSearchOpen, setUserSearchOpen] = useState(false);
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const { inviteAsync } = useInviteTeamMember();
  const { users: allUsers, isLoading: loadingUsers } = useAllActiveUsers();
  const { roles: customRoles } = useCustomRoles();

  // Fetch opportunity details including owner, SE, and account_id
  const { data: opportunity } = useQuery({
    queryKey: ['opportunity-detail', opportunityId],
    queryFn: async () => {
      const result = await gateway
        .from('opportunities')
        .select('owner_email, primary_se_email, account_id')
        .eq('id', opportunityId)
        .maybeSingle()
        .execute();
      if (result.error) throw new Error(getErrorMessage(result.error));
      return result.data;
    },
  });

  const { data: assignable } = useAssignableOpportunityUsers((opportunity as any)?.account_id, opportunityId);
  const allAssignableUsers = assignable?.allUsers || [];
  const seUsers = assignable?.seUsers || [];
  const aeUsers = assignable?.aeUsers || [];


  // Fetch team members assigned to this opportunity (use gateway for decryption)
  const { data: teamMembers, isLoading } = useQuery({
    queryKey: ['opportunity-team-members', opportunityId],
    queryFn: async () => {
      const result = await gateway
        .from('opportunity_team_members')
        .select('id, team_member_email, role, created_at')
        .eq('opportunity_id', opportunityId)
        .execute();
      if (result.error) throw new Error(getErrorMessage(result.error));
      
      // Filter out primary AE and SE from the "additional members" list
      const ownerEmail = opportunity?.owner_email?.toLowerCase();
      const seEmail = (opportunity as any)?.primary_se_email?.toLowerCase();
      
      return (result.data || []).filter((m: any) => {
        const email = m.team_member_email?.toLowerCase();
        return email !== ownerEmail && email !== seEmail;
      });
    },
    enabled: !!opportunity,
  });

  // Fetch team member names from team_members table
  const { data: teamMemberDetails } = useQuery({
    queryKey: ['team-member-details'],
    queryFn: async () => {
      const result = await gateway
        .from('team_members')
        .select('member_email, member_name')
        .execute();
      if (result.error) throw new Error(getErrorMessage(result.error));
      return result.data || [];
    },
  });

  // Update opportunity owner/SE mutation
  const updateOpportunityAssignment = useMutation({
    mutationFn: async ({ field, value }: { field: 'owner_email' | 'primary_se_email'; value: string | null }) => {
      const result = await gateway
        .from('opportunities')
        .update({ [field]: value })
        .eq('id', opportunityId)
        .execute();
      if (result.error) throw new Error(getErrorMessage(result.error));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-detail', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunities'] });
      toast.success(variables.field === 'owner_email' ? 'Account Executive updated' : 'Sales Engineer updated');
    },
    onError: () => {
      toast.error('Failed to update assignment');
    },
  });

  // Add team member mutation - also creates identified/pending user profile
  const addTeamMember = useMutation({
    mutationFn: async ({ email, name, role }: { email: string; name?: string; role: string }) => {
      const normalizedEmail = email.toLowerCase().trim();
      
      // First, add to opportunity_team_members
      const { error } = await gateway
        .from('opportunity_team_members')
        .insert({ opportunity_id: opportunityId, team_member_email: normalizedEmail, role })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      
      // Check if user exists in profiles
      const existingUser = allUsers.find(u => u.email?.toLowerCase() === normalizedEmail);
      
      if (!existingUser && normalizedEmail.endsWith('@pendo.io')) {
        // New user - try invite first, then create identified profile
        try {
          await inviteAsync({ email: normalizedEmail, name: name?.trim() || undefined });
        } catch (inviteError: any) {
          // If invite fails, create as identified user directly
          const { v4: uuidv4 } = await import('uuid');
          await gateway
            .from('profiles')
            .insert([{
              id: uuidv4(),
              email: normalizedEmail,
              full_name: name?.trim() || normalizedEmail.split('@')[0],
              status: 'identified',
            }])
            .execute();
        }
      } else if (existingUser && name?.trim() && !existingUser.full_name) {
        // Existing user with no name - update their profile with the provided name
        await gateway
          .from('profiles')
          .update({ full_name: name.trim() })
          .eq('id', existingUser.id)
          .execute();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-team-members', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['assignable-users'] });
      queryClient.invalidateQueries({ queryKey: ['all-active-users'] });
      toast.success('Team member added');
      setIsAddDialogOpen(false);
      setNewMemberEmail('');
      setNewMemberName('');
      setNewMemberRole('member');
      setUserSearchQuery('');
    },
    onError: (error: any) => {
      if (error.code === '23505') {
        toast.error('Member already assigned');
      } else {
        toast.error('Failed to add team member');
      }
    },
  });

  // Remove team member mutation
  const removeTeamMember = useMutation({
    mutationFn: async (memberId: string) => {
      const { error } = await gateway
        .from('opportunity_team_members')
        .delete()
        .eq('id', memberId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-team-members', opportunityId] });
      toast.success('Team member removed');
    },
    onError: () => {
      toast.error('Failed to remove team member');
    },
  });

  const getMemberName = (email: string | null | undefined) => {
    if (!email) return null;
    const emailLower = email.toLowerCase();
    const profile = allAssignableUsers?.find(u => u.email?.toLowerCase() === emailLower);
    if (profile?.full_name) return profile.full_name;

    const member = teamMemberDetails?.find(m => m.member_email?.toLowerCase() === emailLower);
    return member?.member_name || null;
  };

  const getUserDisplayName = (email: string | null | undefined) => {
    if (!email) return 'Unknown';
    const name = getMemberName(email);
    return name ? `${name} (${email})` : email;
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="h-32 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Primary Assignments */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg flex items-center gap-2">
            <UserCog className="h-5 w-5 text-primary" />
            Primary Assignments
          </CardTitle>
          <CardDescription>
            Assign the primary Opportunity Owner (AE) and Sales Engineer for this opportunity
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            {/* Opportunity Owner / Account Executive */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Briefcase className="h-4 w-4 text-blue-500" />
                Opportunity Owner (AE)
              </Label>
              <Select
                value={isValidEmail(opportunity?.owner_email) ? opportunity.owner_email : 'unassigned'}
                onValueChange={(value) => 
                  updateOpportunityAssignment.mutate({ 
                    field: 'owner_email', 
                    value: value === 'unassigned' ? null : value 
                  })
                }
              >
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="Select AE..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="unassigned">
                    <span className="text-muted-foreground">Unassigned</span>
                  </SelectItem>
                  {/* Show current owner if valid email but not in list */}
                  {isValidEmail(opportunity?.owner_email) && 
                   !allAssignableUsers.some(u => u.email?.toLowerCase() === opportunity?.owner_email?.toLowerCase()) && (
                     <SelectItem key={opportunity?.owner_email} value={opportunity?.owner_email!}>
                       {opportunity?.owner_email}
                     </SelectItem>
                   )}
                  {allAssignableUsers?.map(user => (
                    <SelectItem key={user.email} value={user.email}>
                      {user.full_name ? `${user.full_name} (${user.email})` : user.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Sales Engineer (SE) */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <UserCog className="h-4 w-4 text-green-500" />
                Sales Engineer (SE)
              </Label>
              <Select
                value={isValidEmail((opportunity as any)?.primary_se_email) ? (opportunity as any).primary_se_email : 'unassigned'}
                onValueChange={(value) => 
                  updateOpportunityAssignment.mutate({ 
                    field: 'primary_se_email', 
                    value: value === 'unassigned' ? null : value 
                  })
                }
              >
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="Select SE..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="unassigned">
                    <span className="text-muted-foreground">Unassigned</span>
                  </SelectItem>
                  {/* Show current SE if valid email but not in list */}
                  {isValidEmail((opportunity as any)?.primary_se_email) && 
                   !seUsers.some(u => u.email?.toLowerCase() === (opportunity as any).primary_se_email?.toLowerCase()) && (
                     <SelectItem key={(opportunity as any).primary_se_email} value={(opportunity as any).primary_se_email}>
                       {(opportunity as any).primary_se_email}
                     </SelectItem>
                   )}
                  {seUsers?.map(user => (
                    <SelectItem key={user.email} value={user.email}>
                      {user.full_name ? `${user.full_name} (${user.email})` : user.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Additional Team Members */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Users className="h-5 w-5" />
            Additional Team Members
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Other internal team members engaged with this opportunity
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-1" />
              Add Member
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add Team Member</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Select or Enter User *</Label>
                <Popover open={userSearchOpen} onOpenChange={setUserSearchOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={userSearchOpen}
                      className="w-full justify-between font-normal"
                    >
                      {newMemberEmail ? (
                        <span className="flex items-center gap-2 truncate">
                          <Mail className="h-4 w-4 shrink-0 text-muted-foreground" />
                          {allUsers.find(u => u.email === newMemberEmail)?.full_name || newMemberEmail}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">Search users or enter email...</span>
                      )}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[350px] p-0" align="start">
                    <Command shouldFilter={false}>
                      <CommandInput 
                        placeholder="Search by name or email..." 
                        value={userSearchQuery}
                        onValueChange={setUserSearchQuery}
                      />
                      <CommandList>
                        <CommandEmpty>
                          {userSearchQuery.includes('@') ? (
                            <button
                              className="w-full p-2 text-left hover:bg-accent rounded flex items-center gap-2"
                              onClick={() => {
                                setNewMemberEmail(userSearchQuery.toLowerCase().trim());
                                setNewMemberName('');
                                setUserSearchOpen(false);
                              }}
                            >
                              <UserPlus className="h-4 w-4 text-primary" />
                              <span>Add "{userSearchQuery}" as new user</span>
                            </button>
                          ) : (
                            <span className="text-muted-foreground text-sm">
                              No users found. Enter a full email to add a new user.
                            </span>
                          )}
                        </CommandEmpty>
                        <CommandGroup heading="Existing Users">
                          {allUsers
                            .filter(user => {
                              if (!user.email) return false;
                              if (!userSearchQuery) return true;
                              const query = userSearchQuery.toLowerCase();
                              return (
                                user.email.toLowerCase().includes(query) ||
                                (user.full_name?.toLowerCase().includes(query))
                              );
                            })
                            .slice(0, 20)
                            .map((user) => (
                              <CommandItem
                                key={user.id}
                                value={user.email || user.id}
                                onSelect={() => {
                                  setNewMemberEmail(user.email || '');
                                  setNewMemberName(user.full_name || '');
                                  setUserSearchQuery('');
                                  setUserSearchOpen(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    newMemberEmail === user.email ? "opacity-100" : "opacity-0"
                                  )}
                                />
                                <div className="flex flex-col">
                                  <span className="font-medium">{user.full_name || (user.email || '').split('@')[0] || 'Unknown'}</span>
                                  <span className="text-xs text-muted-foreground">{user.email || 'No email'}</span>
                                </div>
                              </CommandItem>
                            ))}
                        </CommandGroup>
                        {userSearchQuery.includes('@') && !allUsers.some(u => u.email?.toLowerCase() === userSearchQuery.toLowerCase()) && (
                          <CommandGroup heading="Add New">
                            <CommandItem
                              value={`new-${userSearchQuery}`}
                              onSelect={() => {
                                setNewMemberEmail(userSearchQuery.toLowerCase().trim());
                                setNewMemberName('');
                                setUserSearchQuery('');
                                setUserSearchOpen(false);
                              }}
                            >
                              <UserPlus className="mr-2 h-4 w-4 text-primary" />
                              <div className="flex flex-col">
                                <span className="font-medium">Add new user</span>
                                <span className="text-xs text-muted-foreground">{userSearchQuery}</span>
                              </div>
                            </CommandItem>
                          </CommandGroup>
                        )}
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
                <p className="text-xs text-muted-foreground">
                  Select an existing user or enter a @pendo.io email to add a new team member
                </p>
              </div>
              
              {/* Show name field for new users OR existing users without a name */}
              {newMemberEmail && !allUsers.find(u => u.email?.toLowerCase() === newMemberEmail.toLowerCase())?.full_name && (
                <div className="space-y-2">
                  <Label htmlFor="opp-name">Name</Label>
                  <Input
                    id="opp-name"
                    type="text"
                    placeholder="Eva Bourke"
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    {allUsers.find(u => u.email?.toLowerCase() === newMemberEmail.toLowerCase()) 
                      ? "This user doesn't have a name set - you can add one now"
                      : "If this is a new user, they'll be added with 'identified' status"}
                  </p>
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="opp-role">Role</Label>
                <Select value={newMemberRole} onValueChange={setNewMemberRole}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {customRoles.length > 0 ? (
                      customRoles.map(role => (
                        <SelectItem key={role.id} value={role.name}>
                          {role.display_name}
                        </SelectItem>
                      ))
                    ) : (
                      <>
                        <SelectItem value="member">Member</SelectItem>
                        <SelectItem value="technical">Technical Support</SelectItem>
                        <SelectItem value="csm">Customer Success</SelectItem>
                        <SelectItem value="executive">Executive Sponsor</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <Button 
                className="w-full" 
                onClick={() => addTeamMember.mutate({ email: newMemberEmail, name: newMemberName, role: newMemberRole })}
                disabled={!newMemberEmail || addTeamMember.isPending}
              >
                {addTeamMember.isPending ? 'Adding...' : 'Add Member'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {!teamMembers?.length ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-medium text-lg">No additional team members</h3>
            <p className="text-muted-foreground">
              Add other team members who are supporting this opportunity
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {teamMembers.map(member => {
            const email = member.team_member_email || '';
            const name = getMemberName(email);
            return (
              <Card key={member.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-start gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <CardTitle className="text-base truncate">
                        {name || email.split('@')[0] || 'Unknown'}
                      </CardTitle>
                      <CardDescription className="flex items-center gap-1 truncate">
                        <Mail className="h-3 w-3 shrink-0" />
                        {email || 'No email'}
                      </CardDescription>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      onClick={() => removeTeamMember.mutate(member.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="capitalize">
                      {member.role}
                    </Badge>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      Since {format(new Date(member.created_at), 'MMM d, yyyy')}
                    </span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Team Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-500">
                {opportunity?.owner_email ? 1 : 0}
              </div>
              <div className="text-xs text-muted-foreground">AE Assigned</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-500">
                {(opportunity as any)?.primary_se_email ? 1 : 0}
              </div>
              <div className="text-xs text-muted-foreground">SE Assigned</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{teamMembers?.length || 0}</div>
              <div className="text-xs text-muted-foreground">Other Members</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

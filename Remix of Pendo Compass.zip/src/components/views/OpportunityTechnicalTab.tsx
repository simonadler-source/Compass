import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Lightbulb, Target, ClipboardList, Calendar, CheckCircle2, ShieldAlert, Presentation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { UseCasesPanel } from './UseCasesPanel';
import { OpportunitySuccessCriteriaTab } from './OpportunitySuccessCriteriaTab';
import { TechnicalReadinessTab } from './TechnicalReadinessTab';
import { OpportunityMilestonesTab } from './OpportunityMilestonesTab';
import { OpportunityValidationTasksTab } from './OpportunityValidationTasksTab';
import { OpportunityRisksIssuesTab } from './OpportunityRisksIssuesTab';
import { DetectedDeploymentType } from '@/hooks/useOpportunityReadiness';
import { EvaluationDeckViewer } from '@/components/evaluation-deck/EvaluationDeckViewer';

interface OpportunityTechnicalTabProps {
  opportunityId: string;
  accountId: string;
  accountName: string;
  opportunityName: string;
  deploymentTypeIds: string[];
  onDeploymentTypesDetected: (types: DetectedDeploymentType[]) => void;
  onInitializeMilestones: () => Promise<void>;
  isInitializingMilestones: boolean;
  initialSubTab?: string;
  onSubTabChange?: (subTab: string) => void;
}

export function OpportunityTechnicalTab({
  opportunityId,
  accountId,
  accountName,
  opportunityName,
  deploymentTypeIds,
  onDeploymentTypesDetected,
  onInitializeMilestones,
  isInitializingMilestones,
  initialSubTab,
  onSubTabChange,
}: OpportunityTechnicalTabProps) {
  const [activeSubTab, setActiveSubTab] = useState(initialSubTab || 'use-cases');
  const [showDeck, setShowDeck] = useState(false);

  // Sync with external initialSubTab changes (e.g. URL-driven navigation)
  const prevInitialSubTab = React.useRef(initialSubTab);
  React.useEffect(() => {
    if (initialSubTab && initialSubTab !== prevInitialSubTab.current) {
      prevInitialSubTab.current = initialSubTab;
      setActiveSubTab(initialSubTab);
    }
  }, [initialSubTab]);

  const handleSubTabChange = (tab: string) => {
    setActiveSubTab(tab);
    onSubTabChange?.(tab);
  };

  return (
    <div className="h-full flex flex-col">
      <Tabs value={activeSubTab} onValueChange={handleSubTabChange} className="flex-1 flex flex-col">
        <div className="px-6 pt-4 border-b border-border flex items-center justify-between">
          <TabsList className="h-10 inline-flex w-max">
            <TabsTrigger value="use-cases" className="gap-1.5 text-xs">
              <Lightbulb className="w-3.5 h-3.5" />
              Linked Use Cases
            </TabsTrigger>
            <TabsTrigger value="success-criteria" className="gap-1.5 text-xs">
              <Target className="w-3.5 h-3.5" />
              Success Criteria
            </TabsTrigger>
            <TabsTrigger value="readiness" className="gap-1.5 text-xs">
              <ClipboardList className="w-3.5 h-3.5" />
              Technical Readiness
            </TabsTrigger>
            <TabsTrigger value="timeline" className="gap-1.5 text-xs">
              <Calendar className="w-3.5 h-3.5" />
              Timeline
            </TabsTrigger>
            <TabsTrigger value="validation" className="gap-1.5 text-xs">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Validation Tasks
            </TabsTrigger>
            <TabsTrigger value="risks" className="gap-1.5 text-xs">
              <ShieldAlert className="w-3.5 h-3.5" />
              Risks & Issues
            </TabsTrigger>
          </TabsList>
          <Button size="sm" variant="outline" className="gap-1.5 ml-auto" onClick={() => setShowDeck(true)}>
            <Presentation className="w-3.5 h-3.5" />
            Generate Deck
          </Button>
        </div>

        <div className="flex-1 overflow-auto">
          <TabsContent value="use-cases" className="h-full m-0 overflow-auto">
            <UseCasesPanel accountId={accountId} opportunityId={opportunityId} linkedOnly />
          </TabsContent>

          <TabsContent value="success-criteria" className="h-full m-0 overflow-auto">
            <OpportunitySuccessCriteriaTab opportunityId={opportunityId} accountId={accountId} />
          </TabsContent>

          <TabsContent value="readiness" className="h-full m-0">
            <TechnicalReadinessTab
              opportunityId={opportunityId}
              accountId={accountId}
              deploymentTypeIds={deploymentTypeIds}
              onDeploymentTypesDetected={onDeploymentTypesDetected}
            />
          </TabsContent>

          <TabsContent value="timeline" className="h-full m-0">
            <OpportunityMilestonesTab
              opportunityId={opportunityId}
              onInitialize={onInitializeMilestones}
              isInitializing={isInitializingMilestones}
            />
          </TabsContent>

          <TabsContent value="validation" className="h-full m-0">
            <OpportunityValidationTasksTab
              opportunityId={opportunityId}
              deploymentTypeIds={deploymentTypeIds}
            />
          </TabsContent>

          <TabsContent value="risks" className="h-full m-0 overflow-auto">
            <OpportunityRisksIssuesTab opportunityId={opportunityId} accountId={accountId} />
          </TabsContent>
        </div>
      </Tabs>

      {showDeck && (
        <EvaluationDeckViewer
          opportunityId={opportunityId}
          accountId={accountId}
          accountName={accountName}
          opportunityName={opportunityName}
          onClose={() => setShowDeck(false)}
        />
      )}
    </div>
  );
}

import { useState, useMemo, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { AnalysisStatusPanel } from '@/components/AnalysisStatusPanel';
import { PipelineStageIndicator } from '@/components/PipelineStageIndicator';
import { FileText, Sparkles, Loader2, Calendar, AlertCircle, CheckCircle2, Link2, Unlink, RotateCcw, Maximize2, Wand2, Play, Upload, Mail, Bug, Layers, Target, AlertTriangle, Award, ArrowRightLeft, ChevronDown, Users } from 'lucide-react';
import { CallSummaryCard, type CallSummaryData } from '@/components/CallSummaryCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { encryptedInsert, encryptedUpsert } from '@/lib/encryptedDb';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { fetchCompetitorsForAnalysis } from '@/hooks/useCompetitorsList';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { ImportOpportunityTranscriptDialog } from '@/components/dialogs/ImportOpportunityTranscriptDialog';
import { MoveToOpportunityDialog } from '@/components/dialogs/MoveToOpportunityDialog';
import { detectContentType, inferEmailType, inferActivityType } from '@/hooks/useOpportunityActivities';
import { MEETING_TYPES } from '@/hooks/useMeetingTypeSelector';
import { saveInsightsWithEnrichment, saveNBAsWithDeduplication, type NBAInput } from '@/hooks/useInsightEnrichment';
import { dateTimeToISO, parseEmailDateToISO, extractEmailSentAtISO, parseEmailThreadWithTimestamps, type ParsedEmailMessage, dateOnlyToMiddayISO } from '@/lib/emailTemporal';
import { decryptTranscript } from '@/lib/encryption';
import { useRunCoachingAnalysis } from '@/hooks/useSECoachingScores';
import { useUserRole } from '@/hooks/useUserRole';
import {
  useReadinessTemplates,
  useExtractReadinessFromTranscript,
  DetectedDeploymentType,
} from '@/hooks/useOpportunityReadiness';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';
import { analyzeTranscript } from '@/features/transcript-analysis';

// Meeting types for quick input
const QUICK_MEETING_TYPES = [
  { value: 'discovery', label: 'Discovery' },
  { value: 'demo', label: 'Demo' },
  { value: 'technical', label: 'Technical' },
  { value: 'workshop', label: 'Workshop' },
  { value: 'check_in', label: 'Check-in' },
] as const;

// Email types for quick input
const QUICK_EMAIL_TYPES = [
  { value: 'email_followup', label: 'Follow-up' },
  { value: 'email_proposal', label: 'Proposal' },
  { value: 'email_technical', label: 'Technical' },
  { value: 'email_status_update', label: 'Status Update' },
] as const;

// Helper to parse email thread into individual messages
function parseEmailThread(content: string): Array<{ sender: string; date: string; body: string }> {
  // Common email separators
  const separatorPatterns = [
    /^-{3,}\s*Original Message\s*-{3,}$/gim,
    /^-{3,}\s*Forwarded Message\s*-{3,}$/gim,
    /^On .+ wrote:$/gim,
    /^From: .+\nSent: .+\nTo: .+\nSubject: .+$/gim,
    /^_{5,}$/gm,
    /^>{1,}\s*On .+ at .+, .+ wrote:$/gim,
  ];

  // Try to split by common patterns
  let messages: string[] = [content];
  
  for (const pattern of separatorPatterns) {
    const newMessages: string[] = [];
    for (const msg of messages) {
      const parts = msg.split(pattern);
      newMessages.push(...parts.filter(p => p.trim()));
    }
    if (newMessages.length > messages.length) {
      messages = newMessages;
    }
  }

  // Parse each message for sender/date info
  return messages.map((msg, index) => {
    const fromMatch = msg.match(/^From:\s*(.+)$/im);
    const dateMatch = msg.match(/(?:Sent|Date):\s*(.+)$/im);
    
    return {
      sender: fromMatch?.[1]?.trim() || `Message ${index + 1}`,
      date: dateMatch?.[1]?.trim() || '',
      body: msg.trim(),
    };
  });
}

// Helper to extract Momentum meeting ID from file_name
function getMomentumId(fileName: string | null): string | null {
  if (!fileName || !fileName.startsWith('momentum_')) return null;
  return fileName.replace('momentum_', '');
}

// Helper to build Momentum meeting URL
function getMomentumUrl(momentumId: string): string {
  return `https://app.momentum.io/meeting/${momentumId}/summary?sourceTab=MY_CALLS`;
}

interface OpportunityTranscriptsTabProps {
  opportunityId: string;
  accountId: string;
  deploymentTypeIds: string[];
  onDeploymentTypesDetected?: (types: DetectedDeploymentType[]) => void;
  primarySeEmail?: string | null;
}

interface TranscriptReview {
  id: string;
  file_name: string | null;
  meeting_title: string | null;
  meeting_type: string | null;
  meeting_type_confidence: number | null;
  transcript_content: string | null;
  status: string;
  created_at: string;
  extracted_insights: any;
  extracted_technologies: any[];
  momentum_meeting_id: string | null;
  momentum_meetings?: { start_time: string } | null;
  enrichment_status?: string | null;
  call_summary?: any;
}

const toArray = <T,>(value: unknown): T[] => (Array.isArray(value) ? value as T[] : []);

function toDisplayText(value: any, fallback: string): string {
  if (typeof value === 'string' && value.trim()) return value;
  if (value && typeof value === 'object') {
    const preferred = value.action || value.description || value.name || value.use_case || value.pain_point || value.ruleName;
    if (typeof preferred === 'string' && preferred.trim()) return preferred;
  }
  return fallback;
}

function buildFallbackCallSummary(transcript: TranscriptReview | null, generatedSummary: CallSummaryData | null): CallSummaryData | null {
  if (!transcript) return null;

  const stored = transcript.call_summary;
  if (stored?.quickRecap) return stored as CallSummaryData;

  if (stored?.quick_recap) {
    return {
      quickRecap: stored.quick_recap,
      themeSections: toArray<any>(stored.themeSections || stored.theme_sections).map((section, index) => ({
        title: section?.title || `Theme ${index + 1}`,
        content: toDisplayText(section?.content, ''),
      })).filter(section => section.content),
      nextSteps: toArray<any>(stored.nextSteps || stored.next_steps).map((step) => ({
        action: toDisplayText(step, 'Follow up'),
        owner: typeof step?.owner === 'string' ? step.owner : undefined,
      })),
      attendees: stored.attendees,
      durationMinutes: stored.durationMinutes,
      opportunityContext: stored.opportunityContext,
      suggestedActions: toArray<any>(stored.suggestedActions || stored.suggested_actions).map((action) => ({
        action: toDisplayText(action, 'Suggested action'),
        rationale: typeof action?.rationale === 'string' ? action.rationale : undefined,
      })),
    };
  }

  if (generatedSummary?.quickRecap) return generatedSummary;

  const insights = (transcript.extracted_insights || {}) as Record<string, any>;
  const detectionMatches = toArray<any>(insights.detectionRuleMatches || insights.detection_rule_matches);
  const nextBestActions = toArray<any>(insights.nextBestActions || insights.next_best_actions || insights.nbas);

  const firstContext = detectionMatches
    .map(match => match?.context)
    .find((context: unknown): context is string => typeof context === 'string' && context.trim().length > 0);

  const quickRecap = firstContext
    || (typeof insights?.meetingPurpose?.reasoning === 'string' ? insights.meetingPurpose.reasoning : null);

  if (!quickRecap) return null;

  return {
    quickRecap,
    themeSections: detectionMatches.slice(0, 3).map((match: any, index: number) => ({
      title: toDisplayText(match?.ruleName, `Signal ${index + 1}`),
      content: toDisplayText(match?.context, ''),
    })).filter((section) => section.content),
    nextSteps: nextBestActions.slice(0, 5).map((step: any) => ({
      action: toDisplayText(step, 'Follow up on this discussion'),
      owner: typeof step?.owner === 'string' ? step.owner : undefined,
    })),
  };
}

function buildEnrichmentSummary(transcript: TranscriptReview | null) {
  if (!transcript) return null;

  const insights = (transcript.extracted_insights || {}) as Record<string, any>;
  const useCases = toArray<any>(insights.useCases || insights.use_cases);
  const painPoints = toArray<any>(insights.painPoints || insights.pain_points);
  const actions = toArray<any>(insights.nextBestActions || insights.next_best_actions || insights.nbas);
  const technologies = toArray<any>(transcript.extracted_technologies).length > 0
    ? toArray<any>(transcript.extracted_technologies)
    : toArray<any>(insights.technologies || insights.productMentions || insights.product_mentions);
  const detectionMatches = toArray<any>(insights.detectionRuleMatches || insights.detection_rule_matches);
  const readinessAnswers = toArray<any>(insights.readinessAnswers || insights.readiness_answers);
  const deploymentTypes = toArray<any>(insights.detectedDeploymentTypes || insights.detected_deployment_types);

  const hasAny = [
    useCases.length,
    painPoints.length,
    actions.length,
    technologies.length,
    detectionMatches.length,
    readinessAnswers.length,
    deploymentTypes.length,
  ].some(Boolean);

  if (!hasAny) return null;

  return {
    useCases,
    painPoints,
    actions,
    technologies,
    detectionMatches,
    readinessAnswers,
    deploymentTypes,
  };
}

export function OpportunityTranscriptsTab({ 
  opportunityId, 
  accountId, 
  deploymentTypeIds,
  onDeploymentTypesDetected,
  primarySeEmail,
}: OpportunityTranscriptsTabProps) {
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [expandedTranscripts, setExpandedTranscripts] = useState<Set<string>>(new Set());
  const [processingTranscriptId, setProcessingTranscriptId] = useState<string | null>(null);
  const [reanalyzingTranscriptId, setReanalyzingTranscriptId] = useState<string | null>(null);
  const [viewingFullTranscript, setViewingFullTranscript] = useState<TranscriptReview | null>(null);
  const [decryptedTranscriptContent, setDecryptedTranscriptContent] = useState<string | null>(null);
  const [isDecryptingTranscript, setIsDecryptingTranscript] = useState(false);
  const [generatedCallSummary, setGeneratedCallSummary] = useState<CallSummaryData | null>(null);
  const [isGeneratingCallSummary, setIsGeneratingCallSummary] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [analysisStage, setAnalysisStage] = useState<string>('');
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [moveToOppTranscript, setMoveToOppTranscript] = useState<{ id: string; title: string } | null>(null);
  
  // Inline import state
  const [inlineContent, setInlineContent] = useState('');
  const [inlineTitle, setInlineTitle] = useState('');
  const [inlineContentType, setInlineContentType] = useState<'meeting' | 'email'>('meeting');
  const [inlineMeetingType, setInlineMeetingType] = useState('discovery');
  const [inlineEmailType, setInlineEmailType] = useState('email_followup');
  const [inlineMeetingDate, setInlineMeetingDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [isInlineImporting, setIsInlineImporting] = useState(false);
  const [inlineImportProgress, setInlineImportProgress] = useState(0);
  const [inlineImportStage, setInlineImportStage] = useState('');
  const [splitEmailsMode, setSplitEmailsMode] = useState(false);
  const [detectedEmailCount, setDetectedEmailCount] = useState(0);
  const runCoaching = useRunCoachingAnalysis();
  const { isSE, isManager, isAdmin } = useUserRole();
  const canCoach = isSE || isManager || isAdmin;
  const { user: currentUser } = useAuth();

  const modalCallSummary = useMemo(
    () => buildFallbackCallSummary(viewingFullTranscript, generatedCallSummary),
    [viewingFullTranscript, generatedCallSummary],
  );

  const modalEnrichment = useMemo(
    () => buildEnrichmentSummary(viewingFullTranscript),
    [viewingFullTranscript],
  );

  // Decrypt transcript content when viewing full transcript
  useEffect(() => {
    if (!viewingFullTranscript) {
      setDecryptedTranscriptContent(null);
      setIsDecryptingTranscript(false);
      setGeneratedCallSummary(null);
      setIsGeneratingCallSummary(false);
      return;
    }

    setGeneratedCallSummary(null);

    // If cleartext content is already available, use it
    if (viewingFullTranscript.transcript_content) {
      setDecryptedTranscriptContent(viewingFullTranscript.transcript_content);
      setIsDecryptingTranscript(false);
      return;
    }

    // Otherwise decrypt via the dedicated edge function
    let cancelled = false;
    setIsDecryptingTranscript(true);
    decryptTranscript(viewingFullTranscript.id, 'transcript_reviews')
      .then(content => {
        if (!cancelled) setDecryptedTranscriptContent(content);
      })
      .catch(err => {
        console.error('Failed to decrypt transcript:', err);
        if (!cancelled) setDecryptedTranscriptContent('[Unable to decrypt transcript content]');
      })
      .finally(() => {
        if (!cancelled) setIsDecryptingTranscript(false);
      });

    return () => { cancelled = true; };
  }, [viewingFullTranscript]);

  // Generate a call summary on demand for legacy transcripts where call_summary is missing
  useEffect(() => {
    if (!viewingFullTranscript || viewingFullTranscript.call_summary?.quickRecap) return;
    if (!decryptedTranscriptContent || isDecryptingTranscript || isGeneratingCallSummary || generatedCallSummary) return;
    if (decryptedTranscriptContent.startsWith('[Unable to decrypt transcript content]')) return;

    let cancelled = false;
    setIsGeneratingCallSummary(true);

    analyzeTranscript({
      transcript: decryptedTranscriptContent,
      skipEnrichment: true,
    })
      .then((result) => {
        if (cancelled || !result.success) return;
        const summary = result.analysis?.callSummary;
        if (summary?.quickRecap) {
          setGeneratedCallSummary(summary as CallSummaryData);
        }
      })
      .catch((error) => {
        console.error('Failed to generate modal call summary:', error);
      })
      .finally(() => {
        if (!cancelled) setIsGeneratingCallSummary(false);
      });

    return () => {
      cancelled = true;
    };
  }, [
    viewingFullTranscript,
    decryptedTranscriptContent,
    isDecryptingTranscript,
    isGeneratingCallSummary,
    generatedCallSummary,
  ]);

  const { data: teamUsers = [] } = useQuery({
    queryKey: ['coaching-team-users', accountId, opportunityId],
    queryFn: async () => {
      // Gather emails from opportunity team, account team, and opp owner/SE
      const [oppTeamRes, acctTeamRes, oppRes] = await Promise.all([
        gateway.from('opportunity_team_members').select('team_member_email').eq('opportunity_id', opportunityId).execute(),
        gateway.from('account_team_members').select('team_member_email').eq('account_id', accountId).execute(),
        gateway.from('opportunities').select('owner_email, primary_se_email').eq('id', opportunityId).single().execute(),
      ]);

      const emails = new Set<string>();
      (oppTeamRes.data || []).forEach((r: any) => r.team_member_email && emails.add(r.team_member_email.toLowerCase()));
      (acctTeamRes.data || []).forEach((r: any) => r.team_member_email && emails.add(r.team_member_email.toLowerCase()));
      if (oppRes.data?.owner_email) emails.add(oppRes.data.owner_email.toLowerCase());
      if (oppRes.data?.primary_se_email) emails.add(oppRes.data.primary_se_email.toLowerCase());

      if (emails.size === 0) return [];

      const profileRes = await gateway.from('profiles')
        .select('id, email, full_name')
        .in('email', [...emails])
        .order('full_name', { ascending: true })
        .execute();

      return (profileRes.data || []).map((p: any) => ({
        id: p.id,
        email: p.email,
        full_name: p.full_name,
      }));
    },
    enabled: !!accountId && !!opportunityId,
    staleTime: 5 * 60 * 1000,
  });

  // Check which transcripts already have coaching scores
  // Use gateway (service role) to bypass RLS on se_coaching_scores
  const { data: coachedTranscriptIds } = useQuery({
    queryKey: ['coached-transcript-ids', opportunityId],
    queryFn: async () => {
      if (!opportunityId) return new Set<string>();
      const result = await gateway
        .from('se_coaching_scores')
        .select('transcript_id')
        .eq('opportunity_id', opportunityId)
        .execute();
      return new Set((result.data || []).map((d: any) => d.transcript_id));
    },
    enabled: !!opportunityId,
    staleTime: 0,
    refetchOnMount: true,
  });
  
  // Simulate progress for long-running analysis operations
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    
    if (reanalyzingTranscriptId || processingTranscriptId) {
      setAnalysisProgress(0);
      setAnalysisStage('Initializing...');
      
      const stages = [
        { progress: 10, stage: 'Fetching competitors...' },
        { progress: 20, stage: 'Preparing transcript...' },
        { progress: 30, stage: 'Analyzing technologies...' },
        { progress: 45, stage: 'Extracting insights...' },
        { progress: 60, stage: 'Identifying stakeholders...' },
        { progress: 75, stage: 'Generating actions...' },
        { progress: 85, stage: 'Processing detection rules...' },
        { progress: 92, stage: 'Finalizing analysis...' },
      ];
      
      let stageIndex = 0;
      interval = setInterval(() => {
        if (stageIndex < stages.length) {
          setAnalysisProgress(stages[stageIndex].progress);
          setAnalysisStage(stages[stageIndex].stage);
          stageIndex++;
        }
      }, 2500);
    } else {
      setAnalysisProgress(0);
      setAnalysisStage('');
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [reanalyzingTranscriptId, processingTranscriptId]);
  
  // Auto-detect content type when inline content changes
  useEffect(() => {
    if (inlineContent.length > 100) {
      const detected = detectContentType(inlineContent);
      setInlineContentType(detected);
      
      if (detected === 'email') {
        const inferredType = inferEmailType(inlineTitle, inlineContent);
        setInlineEmailType(inferredType);
        
        // Detect email thread count
        const emails = parseEmailThread(inlineContent);
        setDetectedEmailCount(emails.length);
        if (emails.length > 1) {
          setSplitEmailsMode(true);
        }
      } else {
        setDetectedEmailCount(0);
        setSplitEmailsMode(false);
      }
    }
  }, [inlineContent, inlineTitle]);

  // File upload handler
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    setInlineContent(text);
    if (!inlineTitle) {
      setInlineTitle(file.name.replace(/\.[^.]+$/, ''));
    }
  };

  // Reset inline form
  const resetInlineForm = () => {
    setInlineContent('');
    setInlineTitle('');
    setInlineMeetingType('discovery');
    setInlineEmailType('email_followup');
    setInlineMeetingDate(format(new Date(), 'yyyy-MM-dd'));
    setIsInlineImporting(false);
    setInlineImportProgress(0);
    setInlineImportStage('');
    setSplitEmailsMode(false);
    setDetectedEmailCount(0);
  };

  // Inline import mutation
  const inlineImportMutation = useMutation({
    mutationFn: async () => {
      if (!inlineContent.trim()) {
        throw new Error('Please paste transcript or email content');
      }
      if (!inlineTitle.trim()) {
        throw new Error('Please enter a title');
      }

      setIsInlineImporting(true);
      setInlineImportProgress(5);
      setInlineImportStage('Preparing content...');

      const selectedType = inlineContentType === 'email' ? inlineEmailType : inlineMeetingType;
      
      // Pre-fetch contacts for sender attribution in emails
      const { data: existingContactsData } = await gateway
        .from('account_contacts')
        .select('id, name, email')
        .eq('account_id', accountId)
        .execute();
      const existingContacts = existingContactsData || [];
      
      // Determine if we should split emails - use enhanced parsing with timestamps
      const emailMessages: Array<{ sender: string; timestamp: string | null; body: string }> = 
        inlineContentType === 'email' && splitEmailsMode 
          ? parseEmailThreadWithTimestamps(inlineContent).map(m => ({ sender: m.sender, timestamp: m.timestamp, body: m.body }))
          : [{ sender: '', timestamp: null, body: inlineContent }];
      
      const totalMessages = emailMessages.length;
      let processedCount = 0;

      for (const emailMsg of emailMessages) {
        const isMultiple = totalMessages > 1;
        const msgTitle = isMultiple ? `${inlineTitle} - ${emailMsg.sender || `Part ${processedCount + 1}`}` : inlineTitle;
        const msgContent = emailMsg.body;
        const analysisTranscript = msgContent.length > 120000 ? msgContent.slice(0, 120000) : msgContent;

        // Use timestamp from parsed message, fallback to extracting from content, then to provided date
        const occurredAt = inlineContentType === 'email'
          ? (emailMsg.timestamp ?? extractEmailSentAtISO(msgContent) ?? dateOnlyToMiddayISO(inlineMeetingDate))
          : dateOnlyToMiddayISO(inlineMeetingDate);

        const baseProgress = 10 + (processedCount / totalMessages) * 80;
        setInlineImportProgress(baseProgress);
        setInlineImportStage(`Processing ${isMultiple ? `message ${processedCount + 1}/${totalMessages}` : 'content'}...`);

        // Create transcript record with opportunity pre-linked (using encrypted insert)
        const { data: encryptedResult, error: transcriptError } = await encryptedInsert('transcript_reviews', {
          transcript_content: msgContent,
          meeting_title: msgTitle,
          meeting_type: selectedType,
          status: 'approved',
          final_account_id: accountId,
          opportunity_id: opportunityId,
          file_name: `manual_${Date.now()}_${processedCount}`,
          created_at: occurredAt,
        });

        if (transcriptError) throw transcriptError;
        const transcriptReviewId = (encryptedResult as any)?.id;

        setInlineImportStage(`Analyzing ${isMultiple ? `message ${processedCount + 1}/${totalMessages}` : 'content'}...`);

        // Analyze transcript using the streaming endpoint
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
        let analysis: any = null;

        try {
          const response = await fetch(`${supabaseUrl}/functions/v1/analyze-transcript-streaming`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${supabaseKey}`,
              'apikey': supabaseKey,
            },
            body: JSON.stringify({
              transcript: analysisTranscript,
              skipEnrichment: false,
              opportunityId,
              transcriptReviewId,
            }),
          });

          if (!response.ok) {
            console.warn('Analysis failed:', response.status);
          } else {
            const reader = response.body?.getReader();
            const decoder = new TextDecoder();

            if (reader) {
              let buffer = '';
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n\n');
                buffer = lines.pop() || '';

                for (const chunk of lines) {
                  if (!chunk.trim()) continue;
                  const eventMatch = chunk.match(/^event: (\w+)\ndata: (.+)$/s);
                  if (!eventMatch) continue;

                  const [, eventType, dataStr] = eventMatch;
                  try {
                    const data = JSON.parse(dataStr);
                    // Handle unified-transcript-analysis events
                    if (eventType === 'pass_complete' && data.passKey === 'core_extraction') {
                      analysis = data.result;
                    } else if (eventType === 'complete') {
                      analysis = data.result;
                    }
                    // Handle analyze-transcript-streaming events (uses numeric pass, core_complete)
                    if (eventType === 'pass_complete' && data.pass === 1) {
                      analysis = data.result;
                    } else if (eventType === 'core_complete') {
                      analysis = data.result;
                    }
                  } catch {}
                }
              }
            }
          }
        } catch (analysisError) {
          console.error('Analysis error:', analysisError);
        }

        // Update transcript with analysis results
        if (analysis) {
          await gateway
            .from('transcript_reviews')
            .update({
              extracted_technologies: analysis?.technologies ?? null,
              extracted_insights: {
                painPoints: analysis?.insights?.painPoints || analysis?.painPoints || [],
                useCases: analysis?.insights?.useCases || analysis?.useCases || [],
                competitorMentions: analysis?.insights?.competitorMentions || analysis?.competitorMentions || [],
                operationalMetrics: analysis?.operationalMetrics ?? [],
                commercialInsights: analysis?.commercialInsights ?? [],
                nextBestActions: analysis?.nbas ?? [],
                people: analysis?.people ?? [],
                detectionRuleMatches: analysis?.detectionRuleMatches ?? [],
                meetingPurpose: analysis?.meetingPurpose ?? null,
              },
              call_summary: analysis?.callSummary ?? null,
              last_analyzed_at: new Date().toISOString(),
              // Persist AI-classified meeting type + confidence
              ...(analysis?.meetingPurpose ? {
                meeting_type: analysis.meetingPurpose.meetingType,
                meeting_type_confidence: analysis.meetingPurpose.confidence,
              } : {}),
            })
            .eq('id', transcriptReviewId)
            .execute();

          // Save NBAs with semantic deduplication to prevent similar actions
          const nbas = analysis?.nbas || analysis?.nextBestActions || [];
          if (nbas.length > 0) {
            const nbaInputs: NBAInput[] = nbas.map((nba: any) => ({
              action: nba.action,
              actionType: nba.actionType || 'follow_up',
              ownerEmail: nba.ownerEmail,
              ownerName: nba.ownerName,
              ownerType: nba.ownerType || 'sales_engineer',
              priority: nba.priority || 'medium',
              reasoning: nba.reasoning,
              dueDate: nba.dueDate,
              deliveryMethod: nba.deliveryMethod || 'email',
            }));
            
            const dedupeStats = await saveNBAsWithDeduplication(
              accountId,
              nbaInputs,
              opportunityId,
              transcriptReviewId
            );
            console.log(`[Transcripts] NBAs: ${dedupeStats.created} created, ${dedupeStats.skipped} skipped as duplicates`);
          }

          // Save use cases and pain points with enrichment
          const useCases = analysis?.insights?.useCases || analysis?.useCases || [];
          const painPoints = analysis?.insights?.painPoints || analysis?.painPoints || [];

          if (useCases.length > 0 || painPoints.length > 0) {
            const themedUseCases = useCases.map((uc: any) => ({
              description: typeof uc === 'string' ? uc : uc.description || uc.name || uc,
              businessTheme: typeof uc === 'object' ? uc.businessTheme : 'operational_efficiency',
              priority: typeof uc === 'object' ? uc.priority : 'medium',
              confidence: 0.5,
            }));

            const themedPainPoints = painPoints.map((pp: any) => ({
              description: typeof pp === 'string' ? pp : pp.description || pp,
              businessTheme: typeof pp === 'object' ? pp.businessTheme : 'operational_efficiency',
              severity: typeof pp === 'object' ? pp.severity : 'medium',
              confidence: 0.5,
            }));

            await saveInsightsWithEnrichment(
              accountId,
              themedPainPoints,
              themedUseCases,
              opportunityId,
              transcriptReviewId
            );
          }

          // Save contacts - fetch all contacts first and match in memory
          // (name column is encrypted, so we can't filter by it in the query)
          const people = analysis?.people || [];
          if (people.length > 0) {
            const { data: existingContacts } = await gateway
              .from('account_contacts')
              .select('id, name, email')
              .eq('account_id', accountId)
              .execute();
            
            // Build lookup maps for existing contacts
            const contactByName = new Map<string, { id: string; email: string | null }>();
            const contactByEmail = new Map<string, { id: string; name: string | null }>();
            
            for (const c of existingContacts || []) {
              if (c.name) contactByName.set(c.name.toLowerCase().trim(), { id: c.id, email: c.email });
              if (c.email) contactByEmail.set(c.email.toLowerCase().trim(), { id: c.id, name: c.name });
            }

            for (const person of people) {
              // Detect internal team members by AI flag OR email domain
              const personEmail = person.email?.toLowerCase().trim();
              const isInternalEmail = personEmail && personEmail.endsWith('@pendo.io');
              const isInternal = person.isInternal === true || isInternalEmail;
              
              if (isInternal) continue; // Skip internal team members from stakeholder list
              
              const personName = person.name?.toLowerCase().trim();
              
              // Find existing contact by email (preferred) or name
              const existingByEmail = personEmail ? contactByEmail.get(personEmail) : null;
              const existingByName = personName ? contactByName.get(personName) : null;
              const existingContact = existingByEmail || existingByName;

              if (existingContact) {
                // UPDATE existing contact with new AI scores (enrichment)
                // Only update if AI provided meaningful scores
                const updateData: Record<string, any> = {
                  last_assessed_at: new Date().toISOString(),
                  assessment_source: 'ai_transcript',
                };
                
                if (person.stakeholderType && person.stakeholderType !== 'unknown') {
                  updateData.stakeholder_type = person.stakeholderType;
                }
                if (person.influenceLevel != null) {
                  updateData.influence_level = person.influenceLevel;
                }
                if (person.sentiment != null) {
                  updateData.sentiment = person.sentiment;
                }
                if (person.championScore != null) {
                  updateData.champion_score = person.championScore;
                }
                if (person.advocacySignals) {
                  updateData.advocacy_signals = person.advocacySignals;
                }
                if (person.infoSharingSignals) {
                  updateData.info_sharing_signals = person.infoSharingSignals;
                }
                if (person.role && !existingByEmail?.name) {
                  updateData.role = person.role;
                }
                
                await gateway
                  .from('account_contacts')
                  .update(updateData)
                  .eq('id', existingContact.id)
                  .execute();
              } else {
                // INSERT new contact
                await encryptedInsert('account_contacts', {
                  account_id: accountId,
                  opportunity_id: opportunityId,
                  name: person.name,
                  role: person.role,
                  email: person.email,
                  notes: person.context,
                  source: inlineContentType === 'email' ? 'email' : 'transcript',
                  stakeholder_type: person.stakeholderType || 'unknown',
                  influence_level: person.influenceLevel,
                  sentiment: person.sentiment,
                  champion_score: person.championScore,
                  advocacy_signals: person.advocacySignals || { detected: false, examples: [] },
                  info_sharing_signals: person.infoSharingSignals || { detected: false, examples: [] },
                  last_assessed_at: new Date().toISOString(),
                  assessment_source: 'ai_transcript',
                });
                // Add to maps to avoid duplicate inserts in same batch
                if (personName) contactByName.set(personName, { id: 'new', email: personEmail || null });
                if (personEmail) contactByEmail.set(personEmail, { id: 'new', name: person.name });
              }
            }
          }

          // Save operational metrics to account_metrics table
          const operationalMetrics = analysis?.operationalMetrics || [];
          if (operationalMetrics.length > 0) {
            // Fetch existing metrics to deduplicate
            const { data: existingMetrics } = await gateway
              .from('account_metrics')
              .select('metric_name, metric_value')
              .eq('account_id', accountId)
              .execute();
            
            const existingMetricSet = new Set(
              (existingMetrics || []).map(m => 
                `${String(m.metric_name || '').toLowerCase().trim()}::${String(m.metric_value || '').toLowerCase().trim()}`
              )
            );

            for (const metric of operationalMetrics) {
              const key = `${String(metric.metricName || '').toLowerCase().trim()}::${String(metric.metricValue || '').toLowerCase().trim()}`;
              if (key === '::' || existingMetricSet.has(key)) continue;

              try {
                await encryptedInsert('account_metrics', {
                  account_id: accountId,
                  opportunity_id: opportunityId,
                  source_transcript_id: transcriptReviewId,
                  metric_name: metric.metricName,
                  metric_value: metric.metricValue,
                  metric_numeric_value: metric.metricNumericValue ?? null,
                  metric_category: metric.metricCategory || 'general',
                  confidence_score: metric.confidence ?? 0.8,
                  needs_review: metric.needsReview ?? false,
                  context: metric.context || '',
                  source: 'transcript_analysis',
                });
                existingMetricSet.add(key);
              } catch (e) {
                console.error('Failed to save metric:', e);
              }
            }
          }
        }

        // Create activity for timeline with sender attribution for emails
        const { data: oppData } = await gateway
          .from('opportunities')
          .select('owner_email, primary_se_email')
          .eq('id', opportunityId)
          .single()
          .execute();

        if (inlineContentType === 'email') {
          // Extract email from sender string (e.g., "John Doe <john@example.com>")
          const emailMatch = emailMsg.sender.match(/<([^>]+)>/) || emailMsg.sender.match(/([^\s]+@[^\s]+)/);
          const senderEmail = emailMatch?.[1]?.toLowerCase();
          const senderName = emailMsg.sender.replace(/<[^>]+>/, '').trim() || emailMsg.sender;
          
          // Fetch team members to determine if internal
          const { data: teamMembers } = await gateway
            .from('account_team_members')
            .select('team_member_email')
            .eq('account_id', accountId)
            .execute();
          const teamMemberEmails = new Set((teamMembers || []).map(tm => tm.team_member_email?.toLowerCase()).filter(Boolean));
          const isInternal = senderEmail ? teamMemberEmails.has(senderEmail) : false;
          
          // Find matching contact for external senders
          const matchingContact = !isInternal && senderEmail 
            ? (existingContacts || []).find((c: any) => c.email?.toLowerCase() === senderEmail)
            : null;
          
          // Use direction-specific activity type
          const msgActivityType = isInternal ? 'email_sent' : 'email_received';
          let activityTypeId: string | null = null;
          
          const { data: directionType } = await gateway
            .from('activity_types')
            .select('id')
            .eq('name', msgActivityType)
            .single()
            .execute();
          
          if (directionType) {
            activityTypeId = directionType.id;
          } else {
            // Fallback to general email type
            const { data: fallbackType } = await gateway
              .from('activity_types')
              .select('id')
              .eq('name', inlineEmailType)
              .single()
              .execute();
            activityTypeId = fallbackType?.id || null;
          }

          if (activityTypeId) {
            await gateway.insert('opportunity_activities', {
              opportunity_id: opportunityId,
              account_id: accountId,
              transcript_id: transcriptReviewId,
              activity_type_id: activityTypeId,
              activity_date: occurredAt,
              title: msgTitle,
              notes: senderName ? `From: ${senderName}` : null,
              detection_source: 'manual_import',
              ae_email: isInternal ? senderEmail : oppData?.owner_email,
              se_email: oppData?.primary_se_email,
            });
          }
        } else {
          // Meeting - single activity
          const activityTypeName = inferActivityType(msgTitle, msgContent);
          const { data: activityType } = await gateway
            .from('activity_types')
            .select('id')
            .eq('name', activityTypeName)
            .single()
            .execute();

          if (activityType) {
            await gateway.insert('opportunity_activities', {
              opportunity_id: opportunityId,
              account_id: accountId,
              transcript_id: transcriptReviewId,
              activity_type_id: activityType.id,
              activity_date: occurredAt,
              title: msgTitle,
              detection_source: 'manual_import',
              ae_email: oppData?.owner_email,
              se_email: oppData?.primary_se_email,
            });
          }
        }

        processedCount++;
      }

      setInlineImportProgress(100);
      setInlineImportStage('Complete!');

      return { count: totalMessages };
    },
    onSuccess: (result) => {
      const msg = result.count > 1 
        ? `${result.count} messages imported and analyzed` 
        : `${inlineContentType === 'email' ? 'Email' : 'Meeting transcript'} imported and analyzed`;
      toast.success(msg);
      
      queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-activities', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-contacts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-strategic-themes', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-pain-points', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-themed-use-cases', opportunityId] });
      resetInlineForm();
      
      // Trigger account intelligence synthesis
      supabase.functions.invoke('synthesize-account-insights', {
        body: { accountId }
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['account-strategic-themes', accountId] });
        queryClient.invalidateQueries({ queryKey: ['account-exec-summary', accountId] });
        queryClient.invalidateQueries({ queryKey: ['aggregated-account-insights', accountId] });
        console.log('Account synthesis completed after opportunity transcript import');
      }).catch(err => console.error('Account synthesis failed:', err));

      // Invalidate strategic theme/exec summary queries
      queryClient.invalidateQueries({ queryKey: ['account-strategic-themes', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-exec-summary', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-metrics', accountId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-deployment-types', opportunityId] });
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : 'Import failed');
      setIsInlineImporting(false);
    },
  });

  // Readiness extraction hooks (still needed for manual re-extraction feature)
  const { data: categories } = useReadinessTemplates(deploymentTypeIds);
  const extractFromTranscript = useExtractReadinessFromTranscript();

  // Fetch transcripts linked to this opportunity
  const { data: linkedTranscripts, isLoading: loadingLinked } = useQuery({
    queryKey: ['opportunity-transcripts', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('transcript_reviews')
        .select('*, momentum_meetings(start_time)')
        .eq('opportunity_id', opportunityId)
        .order('created_at', { ascending: false })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as TranscriptReview[];
    },
  });

  // Fetch momentum meetings directly linked to this opportunity (for meetings without transcript_reviews)
  const { data: linkedMeetings, isLoading: loadingMeetings } = useQuery({
    queryKey: ['opportunity-momentum-meetings', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select('id, title, start_time, status, momentum_id, transcript_content, salesforce_opportunity_id, opportunity_id')
        .eq('opportunity_id', opportunityId)
        .order('start_time', { ascending: false })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as Array<{
        id: string;
        title: string;
        start_time: string;
        status: string;
        momentum_id: string;
        transcript_content: string | null;
        salesforce_opportunity_id: string | null;
        opportunity_id: string | null;
      }>;
    },
  });

  // Meetings linked to opportunity but without a transcript_review (not yet analyzed)
  const meetingsWithoutTranscripts = useMemo(() => {
    if (!linkedMeetings) return [];
    const linkedTranscriptMeetingIds = new Set(
      (linkedTranscripts || [])
        .map(tr => tr.momentum_meeting_id)
        .filter(Boolean)
    );
    // Also check by file_name pattern
    const linkedTranscriptMomentumIds = new Set(
      (linkedTranscripts || [])
        .map(tr => tr.file_name?.startsWith('momentum_') ? tr.file_name.replace('momentum_', '') : null)
        .filter(Boolean)
    );
    return linkedMeetings.filter(m => 
      !linkedTranscriptMeetingIds.has(m.id) && 
      !linkedTranscriptMomentumIds.has(String(m.momentum_id))
    );
  }, [linkedMeetings, linkedTranscripts]);

  // Fetch all account transcripts that are NOT linked to any opportunity
  const { data: availableTranscripts, isLoading: loadingAvailable } = useQuery({
    queryKey: ['account-transcripts-unlinked', accountId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('transcript_reviews')
        .select('*')
        .eq('final_account_id', accountId)
        .is('opportunity_id', null)
        .order('created_at', { ascending: false })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as TranscriptReview[];
    },
  });

  // Link transcript to opportunity
  const linkTranscript = useMutation({
    mutationFn: async (transcriptId: string) => {
      const { error } = await gateway
        .from('transcript_reviews')
        .update({ opportunity_id: opportunityId })
        .eq('id', transcriptId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['account-transcripts-unlinked', accountId] });
      toast.success('Transcript linked to opportunity');
    },
    onError: () => {
      toast.error('Failed to link transcript');
    },
  });

  // Unlink transcript from opportunity
  const unlinkTranscript = useMutation({
    mutationFn: async (transcriptId: string) => {
      const { error } = await gateway
        .from('transcript_reviews')
        .update({ opportunity_id: null })
        .eq('id', transcriptId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['account-transcripts-unlinked', accountId] });
      toast.success('Transcript unlinked from opportunity');
    },
    onError: () => {
      toast.error('Failed to unlink transcript');
    },
  });

  // Extract readiness from a specific transcript
  const handleExtractReadiness = async (transcript: TranscriptReview) => {
    if (!categories || categories.length === 0) {
      toast.error('Select deployment types first to extract readiness answers');
      return;
    }

    setProcessingTranscriptId(transcript.id);
    
    // Flatten all questions with category names
    const allQuestions = categories.flatMap(cat => 
      cat.questions.map(q => ({
        id: q.id,
        question: q.question,
        category_name: cat.name,
      }))
    );

    try {
      const transcriptContent = transcript.transcript_content
        ? transcript.transcript_content
        : await decryptTranscript(transcript.id, 'transcript_reviews');

      if (!transcriptContent || !transcriptContent.trim()) {
        toast.error('Transcript content is empty (unable to extract readiness)');
        return;
      }

      const result = await extractFromTranscript.mutateAsync({
        transcript: transcriptContent,
        opportunityId,
        questions: allQuestions,
      });

      // Notify parent of detected deployment types and invalidate queries
      if (result.detected_deployment_types?.length > 0) {
        if (onDeploymentTypesDetected) {
          onDeploymentTypesDetected(result.detected_deployment_types);
        }
        queryClient.invalidateQueries({ queryKey: ['opportunity-deployment-types', opportunityId] });
        queryClient.invalidateQueries({ queryKey: ['readiness-templates'] });
      }

      const deploymentTypesDetected = result.detected_deployment_types?.length || 0;
      toast.success(
        `Extracted ${result.extracted_count} answers${deploymentTypesDetected > 0 ? ` and detected ${deploymentTypesDetected} deployment type(s)` : ''}`
      );
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to extract readiness');
    } finally {
      setProcessingTranscriptId(null);
    }
  };

  // Analyze a linked momentum meeting that doesn't have a transcript_review yet
  const handleAnalyzeMomentumMeeting = async (meeting: { id: string; title: string; start_time: string; transcript_content: string | null; momentum_id: string }) => {
    if (!meeting.transcript_content || !meeting.transcript_content.trim()) {
      toast.error('This meeting has no transcript content to analyze');
      return;
    }

    setReanalyzingTranscriptId(meeting.id);

    try {
      // Create a transcript_review record from the momentum meeting
      const { data: newReview, error: insertError } = await encryptedInsert('transcript_reviews', {
        transcript_content: meeting.transcript_content,
        meeting_title: meeting.title,
        meeting_type: 'discovery',
        status: 'approved',
        final_account_id: accountId,
        opportunity_id: opportunityId,
        momentum_meeting_id: meeting.id,
        file_name: `momentum_${meeting.momentum_id}`,
        created_at: meeting.start_time,
      });

      if (insertError) throw insertError;
      const transcriptReviewId = (newReview as any)?.id;
      if (!transcriptReviewId) throw new Error('Failed to create transcript record');

      // Fetch competitors for analysis
      const competitors = await fetchCompetitorsForAnalysis();

      // Use streaming endpoint
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
      let analysis: any = null;

      const response = await fetch(`${supabaseUrl}/functions/v1/analyze-transcript-streaming`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
          'apikey': supabaseKey,
        },
        body: JSON.stringify({
          transcript: meeting.transcript_content.slice(0, 120000),
          competitors,
          skipEnrichment: false,
          opportunityId,
        }),
      });

      if (!response.ok) throw new Error(`Analysis failed: ${response.status}`);

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      if (reader) {
        let buffer = '';
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n\n');
          buffer = lines.pop() || '';
          for (const chunk of lines) {
            if (!chunk.trim()) continue;
            const eventMatch = chunk.match(/^event: (\w+)\ndata: (.+)$/s);
            if (!eventMatch) continue;
            try {
              const data = JSON.parse(eventMatch[2]);
              if (eventMatch[1] === 'pass_complete' && data.passKey === 'core_extraction') analysis = data.result;
              else if (eventMatch[1] === 'pass_complete' && data.pass === 1) analysis = data.result;
              else if (eventMatch[1] === 'core_complete') analysis = data.result;
              else if (eventMatch[1] === 'complete') analysis = data.result;
            } catch {}
          }
        }
      }

      if (analysis) {
        await gateway
          .from('transcript_reviews')
          .update({
            extracted_technologies: analysis?.technologies ?? null,
            extracted_insights: {
              painPoints: analysis?.insights?.painPoints || analysis?.painPoints || [],
              useCases: analysis?.insights?.useCases || analysis?.useCases || [],
              competitorMentions: analysis?.insights?.competitorMentions || analysis?.competitorMentions || [],
              operationalMetrics: analysis?.operationalMetrics || [],
              nextBestActions: analysis?.nbas || [],
              people: analysis?.people || [],
              detectionRuleMatches: analysis?.detectionRuleMatches || [],
              meetingPurpose: analysis?.meetingPurpose || null,
            },
            call_summary: analysis?.callSummary ?? null,
            last_analyzed_at: new Date().toISOString(),
            ...(analysis?.meetingPurpose ? {
              meeting_type: analysis.meetingPurpose.meetingType,
              meeting_type_confidence: analysis.meetingPurpose.confidence,
            } : {}),
          })
          .eq('id', transcriptReviewId)
          .execute();

        // Save NBAs
        const nbas = analysis?.nbas || [];
        if (nbas.length > 0) {
          await saveNBAsWithDeduplication(accountId, nbas, opportunityId, transcriptReviewId);
        }

        // Save insights
        const useCases = analysis?.insights?.useCases ?? [];
        const painPoints = analysis?.insights?.painPoints ?? [];
        if (useCases.length > 0 || painPoints.length > 0) {
          const themedUseCases = useCases.map((uc: any) => ({
            description: typeof uc === 'string' ? uc : uc.description || uc.name || uc,
            businessTheme: typeof uc === 'object' ? uc.businessTheme : 'operational_efficiency',
            priority: typeof uc === 'object' ? uc.priority : 'medium',
            confidence: 0.5,
          }));
          const themedPainPoints = painPoints.map((pp: any) => ({
            description: typeof pp === 'string' ? pp : pp.description || pp,
            businessTheme: typeof pp === 'object' ? pp.businessTheme : 'operational_efficiency',
            severity: typeof pp === 'object' ? pp.severity : 'medium',
            confidence: 0.5,
          }));
          await saveInsightsWithEnrichment(accountId, themedPainPoints, themedUseCases, opportunityId, transcriptReviewId);
        }
      }

      // Notify parent of detected deployment types from initial analysis
      const detectedTypes = analysis?.detectedDeploymentTypes || [];
      if (detectedTypes.length > 0 && onDeploymentTypesDetected) {
        onDeploymentTypesDetected(detectedTypes);
      }

      // Trigger enrichment (detection rules, activity signals, readiness) - fire and forget
      supabase.functions.invoke('enrich-transcript', {
        body: { transcriptReviewId }
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['activity-signals'] });
        queryClient.invalidateQueries({ queryKey: ['detection-rule-matches'] });
        queryClient.invalidateQueries({ queryKey: ['opportunity-readiness', opportunityId] });
        queryClient.invalidateQueries({ queryKey: ['opportunity-deployment-types', opportunityId] });
        queryClient.invalidateQueries({ queryKey: ['readiness-templates'] });
        console.log('Enrichment (incl. readiness) completed for momentum meeting:', transcriptReviewId);
      }).catch(err => console.error('Enrichment failed:', err));

      // Also fire readiness extraction via the dedicated endpoint for immediate results
      if (categories && categories.length > 0 && meeting.transcript_content) {
        const allQuestions = categories.flatMap(cat =>
          cat.questions.map(q => ({
            id: q.id,
            question: q.question,
            category_name: cat.name,
          }))
        );

        extractFromTranscript.mutateAsync({
          transcript: meeting.transcript_content,
          opportunityId,
          questions: allQuestions,
        }).then((result) => {
          if (result.detected_deployment_types?.length > 0 && onDeploymentTypesDetected) {
            onDeploymentTypesDetected(result.detected_deployment_types);
          }
          queryClient.invalidateQueries({ queryKey: ['opportunity-readiness', opportunityId] });
          queryClient.invalidateQueries({ queryKey: ['opportunity-deployment-types', opportunityId] });
          queryClient.invalidateQueries({ queryKey: ['readiness-templates'] });
          console.log(`Readiness extraction completed for initial analysis: ${result.extracted_count} answers`);
        }).catch(err => console.error('Readiness extraction failed:', err));
      }

      toast.success('Meeting analyzed successfully');
      queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-momentum-meetings', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-contacts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-pain-points', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-themed-use-cases', opportunityId] });

      // Trigger account intelligence synthesis
      supabase.functions.invoke('synthesize-account-insights', {
        body: { accountId }
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['account-strategic-themes', accountId] });
        queryClient.invalidateQueries({ queryKey: ['account-exec-summary', accountId] });
        queryClient.invalidateQueries({ queryKey: ['aggregated-account-insights', accountId] });
        console.log('Account synthesis completed after momentum meeting analysis');
      }).catch(err => console.error('Account synthesis failed:', err));
    } catch (error) {
      console.error('Failed to analyze momentum meeting:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to analyze meeting');
    } finally {
      setReanalyzingTranscriptId(null);
    }
  };

  // Full re-analysis of transcript with opportunity-level data enrichment
  const handleFullReanalyze = async (transcript: TranscriptReview) => {
    setReanalyzingTranscriptId(transcript.id);
    // Invalidate pipeline indicator so it picks up new 'running' entries
    queryClient.invalidateQueries({ queryKey: ['analysis-run-logs', transcript.id] });
    
    try {
      // Get transcript content - decrypt if needed
      const transcriptContent = transcript.transcript_content
        ? transcript.transcript_content
        : await decryptTranscript(transcript.id, 'transcript_reviews');

      if (!transcriptContent || !transcriptContent.trim()) {
        toast.error('Transcript content is empty or could not be decrypted');
        setReanalyzingTranscriptId(null);
        return;
      }

      // Fetch competitors for analysis
      const competitors = await fetchCompetitorsForAnalysis();

      // Use unified analysis pipeline (includes richer call summary generation)
      const analysisResult = await analyzeTranscript({
        transcript: transcriptContent.slice(0, 120000),
        transcriptReviewId: transcript.id,
        accountId,
        opportunityId,
        competitors,
        skipEnrichment: false,
      });

      if (!analysisResult.success || !analysisResult.analysis) {
        throw new Error(analysisResult.error || 'No analysis result received');
      }

      const analysis: any = analysisResult.analysis;

      // Update the transcript with new insights
      const { error: updateError } = await gateway
        .from('transcript_reviews')
        .update({
          extracted_technologies: analysis?.technologies ?? null,
          extracted_insights: {
            painPoints: analysis?.insights?.painPoints || analysis?.painPoints || [],
            useCases: analysis?.insights?.useCases || analysis?.useCases || [],
            competitorMentions: analysis?.insights?.competitorMentions || analysis?.competitorMentions || [],
            commercialInsights: analysis?.commercialInsights || [],
            operationalMetrics: analysis?.operationalMetrics || [],
            nextBestActions: analysis?.nbas || [],
            people: analysis?.people || [],
            detectionRuleMatches: analysis?.detectionRuleMatches || [],
            readinessAnswers: analysis?.readinessAnswers || [],
            detectedDeploymentTypes: analysis?.detectedDeploymentTypes || [],
          },
          call_summary: analysis?.callSummary ?? null,
          last_analyzed_at: new Date().toISOString(),
          // Persist meeting type from analysis result (server also does this, but belt-and-suspenders)
          ...(analysis?.meetingPurpose?.meetingType ? {
            meeting_type: analysis.meetingPurpose.meetingType,
            meeting_type_confidence: analysis.meetingPurpose.confidence ?? null,
          } : {}),
        })
        .eq('id', transcript.id)
        .execute();

      if (updateError) {
        throw updateError;
      }

      // Save NBAs with deduplication (check both field names for compatibility)
      const nbas = analysis?.nbas || analysis?.nextBestActions || [];
      let savedNbas = 0;
      if (nbas.length > 0) {
        const { saveNBAsWithDeduplication } = await import('@/hooks/useInsightEnrichment');
        const nbaStats = await saveNBAsWithDeduplication(
          accountId,
          nbas,
          opportunityId,
          transcript.id
        );
        savedNbas = nbaStats.created;
      }

      // Save contacts with opportunity_id - fetch all contacts first and match in memory
      // (name column is encrypted, so we can't filter by it in the query)
      const people = analysis?.people || [];
      let savedContacts = 0;
      
      if (people.length > 0) {
        const { data: existingContacts } = await gateway
          .from('account_contacts')
          .select('id, name, email')
          .eq('account_id', accountId)
          .execute();
        
        const existingNames = new Set(
          (existingContacts || [])
            .map(c => c.name?.toLowerCase().trim())
            .filter(Boolean)
        );
        const existingEmails = new Set(
          (existingContacts || [])
            .map(c => c.email?.toLowerCase().trim())
            .filter(Boolean)
        );

        for (const person of people) {
          if (person.isInternal) continue; // Skip internal team members
          
          const personName = person.name?.toLowerCase().trim();
          const personEmail = person.email?.toLowerCase().trim();
          
          // Check if contact already exists by name or email
          const exists = (personName && existingNames.has(personName)) ||
                       (personEmail && existingEmails.has(personEmail));
          
          if (!exists) {
            try {
              await encryptedInsert('account_contacts', {
                account_id: accountId,
                opportunity_id: opportunityId,
                name: person.name,
                role: person.role,
                email: person.email,
                phone: person.phone,
                notes: person.context,
                source: 'transcript',
                stakeholder_type: person.stakeholderType || 'unknown',
                influence_level: person.influenceLevel,
                sentiment: person.sentiment,
                champion_score: person.championScore,
                advocacy_signals: person.advocacySignals,
                info_sharing_signals: person.infoSharingSignals,
              });
              savedContacts++;
              // Add to sets to avoid duplicate inserts in same batch
              if (personName) existingNames.add(personName);
              if (personEmail) existingEmails.add(personEmail);
            } catch (e) {
              console.error('Failed to save contact:', e);
            }
          }
        }
      }

      // Save readiness answers with opportunity_id
      const readinessAnswers = analysis?.readinessAnswers || [];
      let savedAnswers = 0;
      for (const answer of readinessAnswers) {
        try {
          // Upsert using encrypted helper
          const { error: answerError } = await encryptedUpsert('opportunity_readiness_answers', {
            opportunity_id: opportunityId,
            question_id: answer.questionId,
            answer: answer.answer,
            confidence_score: answer.confidence,
            notes: answer.context,
            source: 'ai_extraction',
            source_transcript_id: transcript.id,
          });
          
          if (!answerError) savedAnswers++;
        } catch (e) {
          console.error('Failed to save readiness answer:', e);
        }
      }

      // Save operational metrics to account_metrics table
      const operationalMetrics = analysis?.operationalMetrics || [];
      let savedMetrics = 0;
      if (operationalMetrics.length > 0) {
        // Fetch existing metrics to deduplicate
        const { data: existingMetrics } = await gateway
          .from('account_metrics')
          .select('metric_name, metric_value')
          .eq('account_id', accountId)
          .execute();
        
        const existingSet = new Set(
          (existingMetrics || []).map(m => 
            `${String(m.metric_name || '').toLowerCase().trim()}::${String(m.metric_value || '').toLowerCase().trim()}`
          )
        );

        for (const metric of operationalMetrics) {
          const key = `${String(metric.metricName || '').toLowerCase().trim()}::${String(metric.metricValue || '').toLowerCase().trim()}`;
          if (key === '::' || existingSet.has(key)) continue;

          try {
            await encryptedInsert('account_metrics', {
              account_id: accountId,
              opportunity_id: opportunityId,
              source_transcript_id: transcript.id,
              metric_name: metric.metricName,
              metric_value: metric.metricValue,
              metric_numeric_value: metric.metricNumericValue ?? null,
              metric_category: metric.metricCategory || 'general',
              confidence_score: metric.confidence ?? 0.8,
              needs_review: metric.needsReview ?? false,
              context: metric.context || '',
              source: 'transcript_analysis',
            });
            savedMetrics++;
            existingSet.add(key);
          } catch (e) {
            console.error('Failed to save metric:', e);
          }
        }
      }

      // Notify parent of detected deployment types
      const detectedTypes = analysis?.detectedDeploymentTypes || [];
      if (detectedTypes.length > 0 && onDeploymentTypesDetected) {
        onDeploymentTypesDetected(detectedTypes);
      }

      // Run enrichment and synthesis in parallel — await both so pipeline indicator stays live
      const enrichmentPromise = supabase.functions.invoke('enrich-transcript', {
        body: { transcriptReviewId: transcript.id }
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['activity-signals'] });
        queryClient.invalidateQueries({ queryKey: ['detection-rule-matches'] });
        console.log('Enrichment completed for transcript:', transcript.id);
      }).catch(err => console.error('Enrichment failed:', err));

      const synthesisPromise = supabase.functions.invoke('synthesize-account-insights', {
        body: { accountId }
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['account-strategic-themes', accountId] });
        queryClient.invalidateQueries({ queryKey: ['account-exec-summary', accountId] });
        queryClient.invalidateQueries({ queryKey: ['aggregated-account-insights', accountId] });
        console.log('Account synthesis completed after full re-analysis');
      }).catch(err => console.error('Account synthesis failed:', err));

      // Auto-trigger readiness extraction if deployment types are configured
      if (categories && categories.length > 0) {
        const readinessContent = transcript.transcript_content
          ? transcript.transcript_content
          : await decryptTranscript(transcript.id, 'transcript_reviews').catch(() => null);

        if (readinessContent?.trim()) {
          const allQuestions = categories.flatMap(cat =>
            cat.questions.map(q => ({
              id: q.id,
              question: q.question,
              category_name: cat.name,
            }))
          );

          extractFromTranscript.mutateAsync({
            transcript: readinessContent,
            opportunityId,
            questions: allQuestions,
          }).then((result) => {
            if (result.detected_deployment_types?.length > 0 && onDeploymentTypesDetected) {
              onDeploymentTypesDetected(result.detected_deployment_types);
            }
            queryClient.invalidateQueries({ queryKey: ['opportunity-readiness', opportunityId] });
            queryClient.invalidateQueries({ queryKey: ['opportunity-deployment-types', opportunityId] });
            queryClient.invalidateQueries({ queryKey: ['readiness-templates'] });
            console.log(`Readiness extraction completed: ${result.extracted_count} answers`);
          }).catch(err => console.error('Readiness extraction failed:', err));
        }
      }

      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-transcript-insights', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-contacts', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['account-contacts', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-metrics', accountId] });

      // Wait for enrichment + synthesis to finish before clearing isAnalyzing
      await Promise.allSettled([enrichmentPromise, synthesisPromise]);

      toast.success(
        `Re-analyzed transcript: ${analysis?.technologies?.length || 0} technologies, ${savedNbas} actions, ${savedContacts} contacts, ${savedAnswers} readiness answers, ${savedMetrics} metrics`
      );
    } catch (error) {
      console.error('Re-analyze error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to re-analyze transcript');
    } finally {
      setReanalyzingTranscriptId(null);
      queryClient.invalidateQueries({ queryKey: ['analysis-run-logs', transcript.id] });
    }
  };

  const setTranscriptExpanded = (id: string, isExpanded: boolean) => {
    setExpandedTranscripts(prev => {
      const next = new Set(prev);
      if (isExpanded) {
        next.add(id);
      } else {
        next.delete(id);
      }
      return next;
    });
  };

  const isLoading = loadingLinked || loadingAvailable || loadingMeetings;

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Inline Import Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Add Transcript or Email</h3>
            <p className="text-sm text-muted-foreground">
              Paste content for AI analysis - emails will be auto-detected
            </p>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.md,.doc,.docx,.eml"
            className="hidden"
            onChange={handleFileUpload}
          />
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
              <Upload className="w-4 h-4 mr-2" />
              Upload File
            </Button>
            <Button variant="outline" size="sm" onClick={() => setIsImportDialogOpen(true)}>
              Advanced Import
            </Button>
          </div>
        </div>

        {/* Progress bar for inline import */}
        {isInlineImporting && (
          <div className="rounded-lg border bg-primary/5 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-primary flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                {inlineImportStage}
              </span>
              <span className="text-xs text-muted-foreground">{Math.round(inlineImportProgress)}%</span>
            </div>
            <Progress value={inlineImportProgress} className="h-2" />
          </div>
        )}

        {/* Content Type Tabs */}
        <Tabs value={inlineContentType} onValueChange={(v) => setInlineContentType(v as 'meeting' | 'email')}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="meeting" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Meeting
            </TabsTrigger>
            <TabsTrigger value="email" className="flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Email
            </TabsTrigger>
          </TabsList>

          <TabsContent value="meeting" className="space-y-3 mt-3">
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Title</Label>
                <Input
                  placeholder="e.g., Discovery Call"
                  value={inlineTitle}
                  onChange={(e) => setInlineTitle(e.target.value)}
                  disabled={isInlineImporting}
                  className="h-9"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Type</Label>
                <Select value={inlineMeetingType} onValueChange={setInlineMeetingType} disabled={isInlineImporting}>
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {QUICK_MEETING_TYPES.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Date</Label>
                <Input
                  type="date"
                  value={inlineMeetingDate}
                  onChange={(e) => setInlineMeetingDate(e.target.value)}
                  disabled={isInlineImporting}
                  className="h-9"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="email" className="space-y-3 mt-3">
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Subject</Label>
                <Input
                  placeholder="e.g., RE: Follow-up"
                  value={inlineTitle}
                  onChange={(e) => setInlineTitle(e.target.value)}
                  disabled={isInlineImporting}
                  className="h-9"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Type</Label>
                <Select value={inlineEmailType} onValueChange={setInlineEmailType} disabled={isInlineImporting}>
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {QUICK_EMAIL_TYPES.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Date</Label>
                <Input
                  type="date"
                  value={inlineMeetingDate}
                  onChange={(e) => setInlineMeetingDate(e.target.value)}
                  disabled={isInlineImporting}
                  className="h-9"
                />
              </div>
            </div>
            
            {/* Email thread detection notice */}
            {detectedEmailCount > 1 && (
              <div className="flex items-center justify-between rounded-lg bg-blue-500/10 border border-blue-500/30 px-3 py-2">
                <span className="text-sm text-blue-600 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Detected {detectedEmailCount} messages in email thread
                </span>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    checked={splitEmailsMode}
                    onChange={(e) => setSplitEmailsMode(e.target.checked)}
                    className="rounded border-blue-500/50"
                  />
                  <span className="text-muted-foreground">Create separate activities</span>
                </label>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Content textarea */}
        <Textarea
          placeholder={inlineContentType === 'email' 
            ? "Paste the email thread here..." 
            : "Paste your meeting transcript here..."
          }
          value={inlineContent}
          onChange={(e) => setInlineContent(e.target.value)}
          className="min-h-[150px] font-mono text-sm"
          disabled={isInlineImporting}
        />

        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            {inlineContent.length.toLocaleString()} characters
            {inlineContent.length > 120000 && ' (will be truncated for analysis)'}
          </p>
          <div className="flex items-center gap-2">
            {inlineContent && (
              <Button
                variant="ghost"
                size="sm"
                onClick={resetInlineForm}
                disabled={isInlineImporting}
              >
                Clear
              </Button>
            )}
            <Button
              variant="glow"
              onClick={() => inlineImportMutation.mutate()}
              disabled={!inlineContent.trim() || !inlineTitle.trim() || isInlineImporting}
            >
              {isInlineImporting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Analyze & Import
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Linked Transcripts */}
      <div className="space-y-4">
          <h3 className="font-medium text-foreground flex items-center gap-2">
          <FileText className="w-4 h-4" />
          Linked Transcripts ({(linkedTranscripts?.length || 0) + meetingsWithoutTranscripts.length})
        </h3>

        {(linkedTranscripts && linkedTranscripts.length > 0) || meetingsWithoutTranscripts.length > 0 ? (
          <div className="space-y-3">
            {/* Transcript reviews linked to opportunity */}
            {linkedTranscripts?.map(transcript => {
              const isExpanded = expandedTranscripts.has(transcript.id);
              const isProcessing = processingTranscriptId === transcript.id;
              const isReanalyzing = reanalyzingTranscriptId === transcript.id;
              const insights = transcript.extracted_insights || {};
              const hasInsights = insights.painPoints?.length > 0 || 
                                  insights.useCases?.length > 0 || 
                                  insights.commercialInsights?.length > 0 ||
                                  insights.nextBestActions?.length > 0 ||
                                  insights.people?.length > 0;
              const hasTechnologies = transcript.extracted_technologies?.length > 0;
              const isAnalyzed = hasInsights || hasTechnologies || transcript.status === 'approved' || transcript.status === 'analyzed';

              return (
                <Collapsible key={transcript.id} open={isExpanded} onOpenChange={(open) => setTranscriptExpanded(transcript.id, open)}>
                  <div className="glass rounded-xl overflow-hidden">
                    {/* Progress bar for active analysis */}
                    {(isReanalyzing || isProcessing) && (
                      <div className="px-4 pt-4 pb-2 bg-primary/5 border-b border-primary/20">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-primary flex items-center gap-2">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            {isReanalyzing ? 'Re-analyzing transcript...' : 'Extracting readiness...'}
                          </span>
                          <span className="text-xs text-muted-foreground">{analysisProgress}%</span>
                        </div>
                        <Progress value={analysisProgress} className="h-2" />
                        <p className="text-xs text-muted-foreground mt-1.5">{analysisStage}</p>
                      </div>
                    )}
                    
                    <div className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <CollapsibleTrigger asChild>
                        <button type="button" className="flex flex-1 min-w-0 items-start gap-3 text-left group">
                          {isAnalyzed ? (
                            <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 shrink-0" />
                          ) : (
                            <FileText className="w-5 h-5 text-muted-foreground mt-0.5 shrink-0" />
                          )}
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-medium text-foreground truncate">{transcript.meeting_title || transcript.file_name || 'Unnamed Transcript'}</p>
                              <ChevronDown
                                className={cn(
                                  "w-4 h-4 text-muted-foreground transition-transform shrink-0",
                                  isExpanded && "rotate-180",
                                )}
                              />
                            </div>
                            <div className="flex items-center gap-2 mt-1 flex-wrap">
                              <p className="text-xs text-muted-foreground flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {format(new Date(transcript.momentum_meetings?.start_time || transcript.created_at), 'MMM d, yyyy h:mm a')}
                              </p>
                              {transcript.meeting_type?.startsWith('email_') && (
                                <Badge variant="outline" className="text-xs text-purple-600 border-purple-500/50 bg-purple-500/10">
                                  <Mail className="w-3 h-3 mr-1" />
                                  Email
                                </Badge>
                              )}
                              {transcript.meeting_type && !transcript.meeting_type.startsWith('email_') && (
                                <Badge variant="outline" className="text-xs text-amber-600 border-amber-500/50 bg-amber-500/10">
                                  {MEETING_TYPES.find(t => t.value === transcript.meeting_type)?.label || transcript.meeting_type}
                                  {transcript.meeting_type_confidence != null && (
                                    <span className="ml-1 opacity-70">{Math.round(transcript.meeting_type_confidence * 100)}%</span>
                                  )}
                                </Badge>
                              )}
                              <PipelineStageIndicator transcriptId={transcript.id} isAnalyzing={isReanalyzing || isProcessing} />
                            </div>
                          </div>
                        </button>
                      </CollapsibleTrigger>
                      <div className="flex items-center gap-2 flex-wrap justify-end">
                        {getMomentumId(transcript.file_name) && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const momentumId = getMomentumId(transcript.file_name);
                                  if (momentumId) {
                                    window.open(getMomentumUrl(momentumId), '_blank');
                                  }
                                }}
                              >
                                <Play className="w-4 h-4 text-primary" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>View in Momentum</TooltipContent>
                          </Tooltip>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            setViewingFullTranscript(transcript);
                          }}
                          className="gap-1"
                        >
                          <Maximize2 className="w-3 h-3" />
                          Full
                        </Button>
                        <Button
                          variant="default"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleFullReanalyze(transcript);
                          }}
                          disabled={isReanalyzing || isProcessing}
                          className="gap-1"
                        >
                          {isReanalyzing ? (
                            <>
                              <Loader2 className="w-3 h-3 animate-spin" />
                              Re-analyzing...
                            </>
                          ) : (
                            <>
                              <Wand2 className="w-4 h-4" />
                              Re-analyze
                            </>
                          )}
                        </Button>
                        {canCoach && isAnalyzed && transcript.meeting_type && !transcript.meeting_type.startsWith('email_') && (() => {
                          const alreadyCoached = coachedTranscriptIds?.has(transcript.id);
                          const defaultSeLabel = primarySeEmail 
                            ? (teamUsers.find(u => u.email === primarySeEmail)?.full_name || primarySeEmail)
                            : 'Assigned SE';
                          return (
                            <div className="flex items-center">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      runCoaching.mutate({ transcriptId: transcript.id, meetingType: transcript.meeting_type || undefined, seEmail: primarySeEmail || undefined });
                                    }}
                                    disabled={runCoaching.isPending}
                                    className={cn(
                                      "gap-1 transition-colors rounded-r-none border-r-0",
                                      alreadyCoached
                                        ? "border-green-600 bg-green-600/10 text-green-600 hover:bg-green-600/20 hover:text-green-700"
                                        : ""
                                    )}
                                  >
                                    <Award className={cn("w-3 h-3", alreadyCoached && "text-green-600")} />
                                    {runCoaching.isPending ? 'Scoring...' : alreadyCoached ? 'Re-Coach' : 'Coach'}
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>{alreadyCoached ? `Re-run coaching as ${defaultSeLabel}` : `Run coaching as ${defaultSeLabel}`}</TooltipContent>
                              </Tooltip>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    disabled={runCoaching.isPending}
                                    className={cn(
                                      "px-1.5 rounded-l-none",
                                      alreadyCoached
                                        ? "border-green-600 bg-green-600/10 text-green-600 hover:bg-green-600/20 hover:text-green-700"
                                        : ""
                                    )}
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    <ChevronDown className="w-3 h-3" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-64 max-h-64 overflow-auto">
                                  <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">Coach as a different SE</div>
                                  <DropdownMenuSeparator />
                                  {currentUser?.email && currentUser.email !== primarySeEmail && (
                                    <>
                                      <DropdownMenuItem
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          runCoaching.mutate({ transcriptId: transcript.id, meetingType: transcript.meeting_type || undefined, seEmail: currentUser.email! });
                                        }}
                                      >
                                        <Users className="w-3 h-3 mr-2" />
                                        <span className="truncate">Me ({currentUser.email})</span>
                                      </DropdownMenuItem>
                                      <DropdownMenuSeparator />
                                    </>
                                  )}
                                  {teamUsers
                                    .filter(u => u.email !== primarySeEmail && u.email !== currentUser?.email)
                                    .map(u => (
                                      <DropdownMenuItem
                                        key={u.id}
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          runCoaching.mutate({ transcriptId: transcript.id, meetingType: transcript.meeting_type || undefined, seEmail: u.email });
                                        }}
                                      >
                                        <span className="truncate">{u.full_name || u.email}</span>
                                        {u.full_name && <span className="text-xs text-muted-foreground ml-1 truncate">({u.email})</span>}
                                      </DropdownMenuItem>
                                    ))}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          );
                        })()}
                        {deploymentTypeIds.length > 0 && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleExtractReadiness(transcript);
                            }}
                            disabled={isProcessing || isReanalyzing}
                            className="gap-1"
                          >
                            {isProcessing ? (
                              <>
                                <Loader2 className="w-3 h-3 animate-spin" />
                                Extracting...
                              </>
                            ) : (
                              <>
                                <RotateCcw className="w-4 h-4" />
                                Extract Readiness
                              </>
                            )}
                          </Button>
                        )}
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                setMoveToOppTranscript({
                                  id: transcript.id,
                                  title: transcript.meeting_title || transcript.file_name || 'Unnamed Transcript',
                                });
                              }}
                            >
                              <ArrowRightLeft className="w-4 h-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Move to different opportunity</TooltipContent>
                        </Tooltip>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                unlinkTranscript.mutate(transcript.id);
                              }}
                              disabled={unlinkTranscript.isPending}
                            >
                              <Unlink className="w-4 h-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Unlink from opportunity</TooltipContent>
                        </Tooltip>
                      </div>
                    </div>
                    </div>
                    
                    <CollapsibleContent>
                      <div className="px-4 pb-4">
                        <div className="border-t border-border/50 pt-4">
                          {/* Call Summary (if available) */}
                          {transcript.call_summary?.quickRecap ? (
                            <div className="mb-4">
                              <CallSummaryCard summary={transcript.call_summary} />
                            </div>
                          ) : (
                            <ScrollArea className="h-[200px]">
                              <pre className="text-xs text-muted-foreground whitespace-pre-wrap font-mono">
                                {transcript.transcript_content ? (
                                  <>
                                    {transcript.transcript_content.slice(0, 2000)}
                                    {transcript.transcript_content.length > 2000 && '...'}
                                  </>
                                ) : (
                                  <span className="italic text-muted-foreground/70">No transcript content available</span>
                                )}
                              </pre>
                            </ScrollArea>
                          )}
                          
                          {/* Show extracted insights summary */}
                          {hasInsights && (
                            <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                              {insights.useCases?.length > 0 && (
                                <div>
                                  <div className="font-medium text-muted-foreground mb-1">Use Cases</div>
                                  <div className="flex flex-wrap gap-1">
                                    {insights.useCases.slice(0, 3).map((uc: any, i: number) => (
                                      <Badge key={i} variant="outline" className="text-xs">
                                        {typeof uc === 'string' ? uc : uc?.description || uc?.name || 'Use case'}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                              {insights.painPoints?.length > 0 && (
                                <div>
                                  <div className="font-medium text-muted-foreground mb-1">Pain Points</div>
                                  <div className="flex flex-wrap gap-1">
                                    {insights.painPoints.slice(0, 3).map((pp: any, i: number) => (
                                      <Badge key={i} variant="outline" className="text-xs">
                                        {typeof pp === 'string' ? pp : pp?.description || 'Pain point'}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                              {hasTechnologies && (
                                <div>
                                  <div className="font-medium text-muted-foreground mb-1">Technologies</div>
                                  <div className="flex flex-wrap gap-1">
                                    {transcript.extracted_technologies.slice(0, 3).map((t: any, i: number) => (
                                      <Badge key={i} variant="secondary" className="text-xs">{t.name}</Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              );
            })}

            {/* Momentum meetings linked to opportunity but without transcript_reviews */}
            {meetingsWithoutTranscripts.map(meeting => (
              <div key={meeting.id} className="glass rounded-xl p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="font-medium text-foreground">{meeting.title || 'Untitled Meeting'}</p>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(meeting.start_time), 'MMM d, yyyy h:mm a')}
                        </p>
                        <Badge variant="outline" className="text-xs">
                          {meeting.status}
                        </Badge>
                        <Badge variant="outline" className="text-xs text-blue-600 border-blue-500/50 bg-blue-500/10">
                          <Link2 className="w-3 h-3 mr-1" />
                          Linked
                        </Badge>
                        {!meeting.transcript_content && (
                          <Badge variant="outline" className="text-xs text-amber-600 border-amber-500/50 bg-amber-500/10">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Not Analyzed
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {meeting.momentum_id && (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => window.open(getMomentumUrl(meeting.momentum_id), '_blank')}
                          >
                            <Play className="w-4 h-4 text-primary" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>View in Momentum</TooltipContent>
                      </Tooltip>
                    )}
                    {meeting.transcript_content && (
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => handleAnalyzeMomentumMeeting(meeting)}
                        disabled={reanalyzingTranscriptId === meeting.id}
                        className="gap-1"
                      >
                        {reanalyzingTranscriptId === meeting.id ? (
                          <>
                            <Loader2 className="w-3 h-3 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4" />
                            Analyze
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="glass rounded-xl p-8 text-center">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Transcripts Linked</h3>
            <p className="text-muted-foreground mb-4">
              Link account transcripts to this opportunity to extract technical readiness information.
            </p>
          </div>
        )}
      </div>

      {/* Available Transcripts to Link */}
      {availableTranscripts && availableTranscripts.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-medium text-foreground flex items-center gap-2">
            <Link2 className="w-4 h-4" />
            Available Account Transcripts ({availableTranscripts.length})
          </h3>
          <p className="text-sm text-muted-foreground">
            These transcripts are linked to the account but not to any specific opportunity
          </p>

          <div className="space-y-2">
            {availableTranscripts.map(transcript => {
              const isAnalyzed = transcript.status === 'approved' || transcript.status === 'analyzed';
              const extractedInsights = transcript.extracted_insights as any;
              const hasTechnologies = extractedInsights?.technologies?.length > 0;
              const hasUseCases = extractedInsights?.use_cases?.length > 0;
              const hasPainPoints = extractedInsights?.pain_points?.length > 0;
              const hasActions = extractedInsights?.next_best_actions?.length > 0;
              
              return (
                <div 
                  key={transcript.id} 
                  className="glass rounded-lg p-4 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <FileText className="w-4 h-4 text-muted-foreground shrink-0" />
                        <span className="font-medium text-sm truncate">
                          {transcript.meeting_title || transcript.file_name || 'Unnamed Transcript'}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(transcript.created_at), 'MMM d, yyyy h:mm a')}
                        </span>
                        {transcript.meeting_type && !transcript.meeting_type.startsWith('email_') && (
                          <Badge variant="outline" className="text-xs text-amber-600 border-amber-500/50 bg-amber-500/10">
                            {MEETING_TYPES.find(t => t.value === transcript.meeting_type)?.label || transcript.meeting_type}
                            {transcript.meeting_type_confidence != null && (
                              <span className="ml-1 opacity-70">{Math.round(transcript.meeting_type_confidence * 100)}%</span>
                            )}
                          </Badge>
                        )}
                        {isAnalyzed && (
                          <Badge variant="outline" className="text-xs bg-green-500/10 text-green-600 border-green-500/30">
                            Analyzed
                          </Badge>
                        )}
                        {transcript.status === 'processing' && (
                          <Badge variant="outline" className="text-xs bg-amber-500/10 text-amber-600 border-amber-500/30">
                            Processing
                          </Badge>
                        )}
                      </div>
                      
                      {/* Show extracted insights summary */}
                      {isAnalyzed && (hasTechnologies || hasUseCases || hasPainPoints || hasActions) && (
                        <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                          {hasTechnologies && (
                            <span className="flex items-center gap-1">
                              <Layers className="w-3 h-3" />
                              {extractedInsights.technologies.length} technologies
                            </span>
                          )}
                          {hasUseCases && (
                            <span className="flex items-center gap-1">
                              <Target className="w-3 h-3" />
                              {extractedInsights.use_cases.length} use cases
                            </span>
                          )}
                          {hasPainPoints && (
                            <span className="flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" />
                              {extractedInsights.pain_points.length} pain points
                            </span>
                          )}
                          {hasActions && (
                            <span className="flex items-center gap-1">
                              <Sparkles className="w-3 h-3" />
                              {extractedInsights.next_best_actions.length} actions
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => linkTranscript.mutate(transcript.id)}
                      disabled={linkTranscript.isPending}
                      className="gap-1 shrink-0"
                    >
                      <Link2 className="w-3 h-3" />
                      Link to Opportunity
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty state for no deployment types */}
      {deploymentTypeIds.length === 0 && (
        <div className="glass rounded-xl p-4 border-l-4 border-l-amber-500">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium">Select Deployment Types First</h4>
              <p className="text-sm text-muted-foreground">
                Go to the Overview tab and select deployment types to enable readiness extraction from transcripts.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Full Transcript Modal */}
      <Dialog open={!!viewingFullTranscript} onOpenChange={() => setViewingFullTranscript(null)}>
        <DialogContent className="max-w-5xl h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {viewingFullTranscript?.meeting_title || viewingFullTranscript?.file_name || 'Transcript'}
              {viewingFullTranscript?.enrichment_status && (
                <Badge variant="outline" className="text-xs">
                  Enrichment: {viewingFullTranscript.enrichment_status}
                </Badge>
              )}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Call summary, enrichment details, and full transcript text for this meeting.
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 min-h-0 overflow-y-auto mt-2 pr-2">
            <div className="flex flex-col gap-4 pr-2 pb-2">
              {/* Call Summary at the top */}
              {modalCallSummary ? (
                <div className="shrink-0">
                  <CallSummaryCard summary={modalCallSummary} />
                </div>
              ) : isGeneratingCallSummary ? (
                <div className="shrink-0 rounded-lg border border-border bg-muted/30 p-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Generating call summary…
                  </div>
                </div>
              ) : (
                <div className="shrink-0 rounded-lg border border-border bg-muted/30 p-4 text-sm text-muted-foreground">
                  No call summary was generated for this transcript yet.
                </div>
              )}

              {/* Analysis Pipeline Status */}
              <AnalysisStatusPanel transcriptId={viewingFullTranscript?.id || null} />

              {/* Extracted Insights Summary */}
              {modalEnrichment && (
                <div className="shrink-0 rounded-lg border border-border bg-muted/30 p-4 space-y-3">
                  <h4 className="text-sm font-semibold text-foreground flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-primary" />
                    Enrichment Details
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                    {modalEnrichment.useCases.length > 0 && (
                      <div>
                        <div className="font-medium text-muted-foreground mb-1 flex items-center gap-1">
                          <Target className="w-3 h-3" /> Use Cases ({modalEnrichment.useCases.length})
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {modalEnrichment.useCases.slice(0, 5).map((useCase: any, index: number) => (
                            <Badge key={`use-case-${index}`} variant="outline" className="text-xs">
                              {toDisplayText(useCase, 'Use case')}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {modalEnrichment.painPoints.length > 0 && (
                      <div>
                        <div className="font-medium text-muted-foreground mb-1 flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" /> Pain Points ({modalEnrichment.painPoints.length})
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {modalEnrichment.painPoints.slice(0, 5).map((painPoint: any, index: number) => (
                            <Badge key={`pain-point-${index}`} variant="outline" className="text-xs">
                              {toDisplayText(painPoint, 'Pain point')}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {modalEnrichment.technologies.length > 0 && (
                      <div>
                        <div className="font-medium text-muted-foreground mb-1 flex items-center gap-1">
                          <Layers className="w-3 h-3" /> Technologies ({modalEnrichment.technologies.length})
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {modalEnrichment.technologies.slice(0, 6).map((technology: any, index: number) => (
                            <Badge key={`technology-${index}`} variant="secondary" className="text-xs">
                              {toDisplayText(technology, 'Technology')}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {modalEnrichment.actions.length > 0 && (
                      <div>
                        <div className="font-medium text-muted-foreground mb-1 flex items-center gap-1">
                          <Sparkles className="w-3 h-3" /> Actions ({modalEnrichment.actions.length})
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {modalEnrichment.actions.slice(0, 5).map((action: any, index: number) => (
                            <Badge key={`action-${index}`} variant="outline" className="text-xs">
                              {toDisplayText(action, 'Action')}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {modalEnrichment.detectionMatches.length > 0 && (
                      <div>
                        <div className="font-medium text-muted-foreground mb-1 flex items-center gap-1">
                          <Bug className="w-3 h-3" /> Signal Matches ({modalEnrichment.detectionMatches.length})
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {modalEnrichment.detectionMatches.slice(0, 6).map((match: any, index: number) => (
                            <Badge key={`match-${index}`} variant="outline" className="text-xs">
                              {toDisplayText(match?.ruleName, 'Detected signal')}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {modalEnrichment.readinessAnswers.length > 0 && (
                      <div>
                        <div className="font-medium text-muted-foreground mb-1 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Readiness Answers ({modalEnrichment.readinessAnswers.length})
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {modalEnrichment.readinessAnswers.slice(0, 5).map((answer: any, index: number) => (
                            <Badge key={`readiness-${index}`} variant="outline" className="text-xs">
                              {toDisplayText(answer?.answer, 'Answer captured')}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {modalEnrichment.deploymentTypes.length > 0 && (
                      <div>
                        <div className="font-medium text-muted-foreground mb-1 flex items-center gap-1">
                          <Layers className="w-3 h-3" /> Deployment Types ({modalEnrichment.deploymentTypes.length})
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {modalEnrichment.deploymentTypes.slice(0, 5).map((deploymentType: any, index: number) => (
                            <Badge key={`deployment-type-${index}`} variant="outline" className="text-xs">
                              {toDisplayText(deploymentType?.name || deploymentType?.type || deploymentType, 'Deployment type')}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Full Transcript Content */}
              <div className="border rounded-md min-h-0">
                {isDecryptingTranscript ? (
                  <div className="flex items-center justify-center p-8 gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">Decrypting transcript…</span>
                  </div>
                ) : decryptedTranscriptContent ? (
                  <div className="max-h-[52vh] overflow-y-auto">
                    <pre className="text-sm text-muted-foreground whitespace-pre-wrap font-mono p-4 leading-relaxed">
                      {decryptedTranscriptContent}
                    </pre>
                  </div>
                ) : (
                  <div className="flex items-center justify-center p-8">
                    <span className="text-sm text-muted-foreground">No transcript content available</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Import Transcript/Email Dialog */}
      <ImportOpportunityTranscriptDialog
        open={isImportDialogOpen}
        onOpenChange={setIsImportDialogOpen}
        opportunityId={opportunityId}
        accountId={accountId}
      />

      {/* Move to Opportunity Dialog */}
      {moveToOppTranscript && (
        <MoveToOpportunityDialog
          open={!!moveToOppTranscript}
          onOpenChange={(open) => { if (!open) setMoveToOppTranscript(null); }}
          transcriptId={moveToOppTranscript.id}
          transcriptTitle={moveToOppTranscript.title}
          accountId={accountId}
          currentOpportunityId={opportunityId}
          onMoved={() => {
            queryClient.invalidateQueries({ queryKey: ['opportunity-transcripts', opportunityId] });
          }}
        />
      )}
    </div>
  );
}

import { UseCasesPanel } from './UseCasesPanel';

interface OpportunityUseCasesTabProps {
  opportunityId: string;
  accountId: string;
}

export function OpportunityUseCasesTab({ opportunityId, accountId }: OpportunityUseCasesTabProps) {
  return <UseCasesPanel accountId={accountId} opportunityId={opportunityId} />;
}
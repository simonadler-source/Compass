import { useState, useMemo, useEffect } from 'react';
import { CheckCircle2, Circle, Clock, AlertCircle, ExternalLink, ChevronDown, ChevronRight, Pencil, Trash2, Target, Link2, X, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import {
  useOpportunityValidationTasks,
  useValidationTaskTemplates,
  useInitializeValidationTasks,
  useUpdateValidationTask,
  useDeleteValidationTask,
  OpportunityValidationTask,
} from '@/hooks/useOpportunityReadiness';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { toast } from 'sonner';
import { MoreVertical } from 'lucide-react';

interface OpportunityValidationTasksTabProps {
  opportunityId: string;
  deploymentTypeIds: string[];
}

interface SuccessCriterion {
  id: string;
  criterion: string;
  status: string;
  metric_name: string | null;
}

const statusConfig: Record<string, { label: string; color: string; bgColor: string }> = {
  not_started: { label: 'Not Started', color: 'text-muted-foreground', bgColor: 'bg-muted' },
  in_progress: { label: 'In Progress', color: 'text-amber-500', bgColor: 'bg-amber-500/20' },
  completed: { label: 'Completed', color: 'text-green-500', bgColor: 'bg-green-500/20' },
  blocked: { label: 'Blocked', color: 'text-destructive', bgColor: 'bg-destructive/20' },
  skipped: { label: 'Skipped', color: 'text-muted-foreground', bgColor: 'bg-muted' },
};

const moduleColors: Record<string, string> = {
  'Deployment and Configuration': 'border-l-layer-build',
  'Gather': 'border-l-layer-adopt',
  'Learn': 'border-l-layer-growth',
  'Act': 'border-l-primary',
};

export function OpportunityValidationTasksTab({ opportunityId, deploymentTypeIds }: OpportunityValidationTasksTabProps) {
  const { data: tasks, isLoading: loadingTasks } = useOpportunityValidationTasks(opportunityId);
  const { data: templates } = useValidationTaskTemplates(deploymentTypeIds);
  const initializeTasks = useInitializeValidationTasks();
  const updateTask = useUpdateValidationTask();
  const deleteTask = useDeleteValidationTask();
  
  const [expandedModules, setExpandedModules] = useState<Set<string>>(new Set(['Deployment and Configuration']));
  const [filter, setFilter] = useState<'all' | 'incomplete' | 'completed'>('all');
  const [editingTask, setEditingTask] = useState<OpportunityValidationTask | null>(null);
  const [deleteTaskId, setDeleteTaskId] = useState<string | null>(null);
  const [linkingTask, setLinkingTask] = useState<OpportunityValidationTask | null>(null);

  // Fetch success criteria for this opportunity
  const { data: successCriteria } = useQuery({
    queryKey: ['validation-tasks-success-criteria', opportunityId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('evaluation_success_criteria')
        .select('id, criterion, status, metric_name')
        .eq('opportunity_id', opportunityId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data || []) as SuccessCriterion[];
    },
    enabled: !!opportunityId,
  });
  
  // Initialize tasks if none exist but templates are available
  useEffect(() => {
    if (tasks && tasks.length === 0 && templates && templates.length > 0 && deploymentTypeIds.length > 0) {
      initializeTasks.mutate({ opportunityId, templates });
    }
  }, [tasks, templates, deploymentTypeIds, opportunityId]);
  
  // Group tasks by module and sub_module
  const groupedTasks = useMemo(() => {
    if (!tasks) return [];
    
    const filtered = tasks.filter(t => {
      if (filter === 'incomplete') return t.status !== 'completed' && t.status !== 'skipped';
      if (filter === 'completed') return t.status === 'completed';
      return true;
    });
    
    const modules: { module: string; subModules: { subModule: string | null; tasks: typeof tasks }[] }[] = [];
    let currentModule = '';
    let currentSubModule: string | null = null;
    
    filtered.forEach(task => {
      if (task.module !== currentModule) {
        currentModule = task.module;
        currentSubModule = task.sub_module;
        modules.push({ 
          module: currentModule, 
          subModules: [{ subModule: currentSubModule, tasks: [task] }] 
        });
      } else if (task.sub_module !== currentSubModule) {
        currentSubModule = task.sub_module;
        modules[modules.length - 1].subModules.push({ subModule: currentSubModule, tasks: [task] });
      } else {
        const lastModule = modules[modules.length - 1];
        lastModule.subModules[lastModule.subModules.length - 1].tasks.push(task);
      }
    });
    
    return modules;
  }, [tasks, filter]);
  
  // Calculate stats
  const stats = useMemo(() => {
    if (!tasks) return { total: 0, completed: 0, inProgress: 0, blocked: 0 };
    
    return {
      total: tasks.length,
      completed: tasks.filter(t => t.status === 'completed').length,
      inProgress: tasks.filter(t => t.status === 'in_progress').length,
      blocked: tasks.filter(t => t.status === 'blocked').length,
    };
  }, [tasks]);
  
  const toggleModule = (module: string) => {
    setExpandedModules(prev => {
      const next = new Set(prev);
      if (next.has(module)) next.delete(module);
      else next.add(module);
      return next;
    });
  };
  
  const handleStatusChange = async (taskId: string, status: string) => {
    await updateTask.mutateAsync({ id: taskId, opportunityId, status });
  };
  
  const handleQuickComplete = async (taskId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'completed' ? 'not_started' : 'completed';
    await updateTask.mutateAsync({ id: taskId, opportunityId, status: newStatus });
  };

  const handleDelete = async () => {
    if (!deleteTaskId) return;
    try {
      await deleteTask.mutateAsync({ id: deleteTaskId, opportunityId });
      toast.success('Task deleted');
    } catch {
      toast.error('Failed to delete task');
    }
    setDeleteTaskId(null);
  };

  const handleToggleCriteriaLink = async (task: OpportunityValidationTask, criterionId: string) => {
    const current = task.linked_success_criteria_ids || [];
    const isLinked = current.includes(criterionId);
    const updated = isLinked
      ? current.filter(id => id !== criterionId)
      : [...current, criterionId];
    
    try {
      await updateTask.mutateAsync({
        id: task.id,
        opportunityId,
        linked_success_criteria_ids: updated,
      });
    } catch {
      toast.error('Failed to update link');
    }
  };

  // Get linked criteria names for display
  const getCriteriaNames = (ids: string[] | null) => {
    if (!ids || ids.length === 0 || !successCriteria) return [];
    return successCriteria.filter(sc => ids.includes(sc.id));
  };

  if (loadingTasks) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  if (deploymentTypeIds.length === 0) {
    return (
      <div className="p-6">
        <div className="glass rounded-xl p-8 text-center">
          <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Deployment Types Selected</h3>
          <p className="text-muted-foreground">
            Select deployment types in the Overview tab to see relevant validation tasks.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Validation Tasks</h2>
          <p className="text-sm text-muted-foreground">
            Track deployment, configuration, and enablement tasks
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={filter} onValueChange={(v: any) => setFilter(v)}>
            <SelectTrigger className="w-[150px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tasks</SelectItem>
              <SelectItem value="incomplete">Incomplete</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <div className="glass rounded-lg p-4">
          <div className="text-2xl font-bold">{stats.total}</div>
          <div className="text-sm text-muted-foreground">Total Tasks</div>
        </div>
        <div className="glass rounded-lg p-4">
          <div className="text-2xl font-bold text-green-500">{stats.completed}</div>
          <div className="text-sm text-muted-foreground">Completed</div>
        </div>
        <div className="glass rounded-lg p-4">
          <div className="text-2xl font-bold text-amber-500">{stats.inProgress}</div>
          <div className="text-sm text-muted-foreground">In Progress</div>
        </div>
        <div className="glass rounded-lg p-4">
          <div className="text-2xl font-bold text-destructive">{stats.blocked}</div>
          <div className="text-sm text-muted-foreground">Blocked</div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="glass rounded-lg p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Overall Progress</span>
          <span className="text-sm text-muted-foreground">
            {stats.completed} of {stats.total} tasks completed
          </span>
        </div>
        <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
          <div 
            className="h-full bg-primary transition-all"
            style={{ width: `${stats.total > 0 ? (stats.completed / stats.total) * 100 : 0}%` }}
          />
        </div>
      </div>

      {/* Task Groups */}
      <div className="space-y-4">
        {groupedTasks.map(({ module, subModules }) => {
          const isExpanded = expandedModules.has(module);
          const moduleCompleted = subModules.reduce(
            (sum, sm) => sum + sm.tasks.filter(t => t.status === 'completed').length, 0
          );
          const moduleTotal = subModules.reduce((sum, sm) => sum + sm.tasks.length, 0);
          
          return (
            <Collapsible key={module} open={isExpanded} onOpenChange={() => toggleModule(module)}>
              <CollapsibleTrigger asChild>
                <div className={cn(
                  "glass rounded-xl p-4 cursor-pointer hover:bg-muted/50 transition-colors border-l-4",
                  moduleColors[module] || 'border-l-muted-foreground'
                )}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {isExpanded ? (
                        <ChevronDown className="w-5 h-5 text-muted-foreground" />
                      ) : (
                        <ChevronRight className="w-5 h-5 text-muted-foreground" />
                      )}
                      <h3 className="font-semibold">{module}</h3>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={moduleCompleted === moduleTotal ? 'default' : 'outline'}>
                        {moduleCompleted} / {moduleTotal}
                      </Badge>
                      {moduleCompleted === moduleTotal && (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      )}
                    </div>
                  </div>
                </div>
              </CollapsibleTrigger>
              
              <CollapsibleContent>
                <div className="mt-2 space-y-4 pl-4">
                  {subModules.map(({ subModule, tasks: subTasks }) => (
                    <div key={subModule || 'default'} className="glass rounded-lg overflow-hidden">
                      {subModule && (
                        <div className="px-4 py-2 bg-muted/50 border-b border-border">
                          <span className="text-sm font-medium text-muted-foreground">{subModule}</span>
                        </div>
                      )}
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-px bg-border">
                        {subTasks.map(task => {
                          const linkedCriteria = getCriteriaNames(task.linked_success_criteria_ids);
                          
                          return (
                            <div
                              key={task.id}
                              className={cn(
                                "p-3 bg-card hover:bg-muted/30 transition-colors group",
                                task.status === 'completed' && "bg-green-500/5"
                              )}
                            >
                              <div className="flex items-start gap-3">
                                <Checkbox
                                  checked={task.status === 'completed'}
                                  onCheckedChange={() => handleQuickComplete(task.id, task.status)}
                                  className="mt-0.5 shrink-0"
                                />
                                
                                <div className="flex-1 min-w-0">
                                  <p className={cn(
                                    "text-sm leading-tight",
                                    task.status === 'completed' && "line-through text-muted-foreground"
                                  )}>
                                    {task.activity}
                                  </p>
                                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                                    {task.owner && (
                                      <span className="text-xs text-muted-foreground">
                                        {task.owner}
                                      </span>
                                    )}
                                    <Select 
                                      value={task.status} 
                                      onValueChange={(v) => handleStatusChange(task.id, v)}
                                    >
                                      <SelectTrigger className="h-6 text-xs w-auto px-2 py-0">
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="not_started">Not Started</SelectItem>
                                        <SelectItem value="in_progress">In Progress</SelectItem>
                                        <SelectItem value="completed">Completed</SelectItem>
                                        <SelectItem value="blocked">Blocked</SelectItem>
                                        <SelectItem value="skipped">Skipped</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>

                                  {/* Linked criteria chips */}
                                  {linkedCriteria.length > 0 && (
                                    <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                                      <Target className="w-3 h-3 text-emerald-500 shrink-0" />
                                      {linkedCriteria.map(sc => (
                                        <Badge key={sc.id} variant="outline" className="text-[10px] px-1.5 py-0 h-4 gap-0.5 border-emerald-500/30 text-emerald-600">
                                          {sc.criterion.length > 35 ? sc.criterion.slice(0, 35) + '…' : sc.criterion}
                                        </Badge>
                                      ))}
                                    </div>
                                  )}

                                  {/* Notes preview */}
                                  {task.notes && (
                                    <p className="text-xs text-muted-foreground mt-1 line-clamp-1 italic">
                                      {task.notes}
                                    </p>
                                  )}
                                </div>

                                {/* Action menu */}
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                                      <MoreVertical className="w-3.5 h-3.5" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem onClick={() => setEditingTask(task)}>
                                      <Pencil className="w-3.5 h-3.5 mr-2" />
                                      Edit Task
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => setLinkingTask(task)}>
                                      <Link2 className="w-3.5 h-3.5 mr-2" />
                                      Link Success Criteria
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem
                                      onClick={() => setDeleteTaskId(task.id)}
                                      className="text-destructive focus:text-destructive"
                                    >
                                      <Trash2 className="w-3.5 h-3.5 mr-2" />
                                      Delete Task
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </CollapsibleContent>
            </Collapsible>
          );
        })}
      </div>

      {groupedTasks.length === 0 && (
        <div className="glass rounded-xl p-8 text-center">
          {filter === 'completed' ? (
            <>
              <Circle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Completed Tasks Yet</h3>
              <p className="text-muted-foreground">Start completing tasks to see them here.</p>
            </>
          ) : (
            <>
              <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">All Tasks Complete!</h3>
              <p className="text-muted-foreground">Great job! All validation tasks have been completed.</p>
            </>
          )}
        </div>
      )}

      {/* Edit Task Dialog */}
      <EditTaskDialog
        task={editingTask}
        opportunityId={opportunityId}
        onClose={() => setEditingTask(null)}
        onSave={updateTask.mutateAsync}
      />

      {/* Link Success Criteria Dialog */}
      <LinkCriteriaDialog
        task={linkingTask}
        successCriteria={successCriteria || []}
        onClose={() => setLinkingTask(null)}
        onToggle={handleToggleCriteriaLink}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTaskId} onOpenChange={() => setDeleteTaskId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Validation Task?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove this task from the validation plan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ─── Edit Task Dialog ────────────────────────────────────────────────────────

interface EditTaskDialogProps {
  task: OpportunityValidationTask | null;
  opportunityId: string;
  onClose: () => void;
  onSave: (params: any) => Promise<any>;
}

function EditTaskDialog({ task, opportunityId, onClose, onSave }: EditTaskDialogProps) {
  const [activity, setActivity] = useState('');
  const [owner, setOwner] = useState('');
  const [notes, setNotes] = useState('');
  const [module, setModule] = useState('');
  const [subModule, setSubModule] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (task) {
      setActivity(task.activity || '');
      setOwner(task.owner || '');
      setNotes(task.notes || '');
      setModule(task.module || '');
      setSubModule(task.sub_module || '');
    }
  }, [task?.id]);

  const handleSave = async () => {
    if (!task || !activity.trim()) return;
    setSaving(true);
    try {
      await onSave({
        id: task.id,
        opportunityId,
        activity: activity.trim(),
        owner: owner.trim() || null,
        notes: notes.trim() || null,
        module: module.trim() || task.module,
        sub_module: subModule.trim() || null,
      });
      toast.success('Task updated');
      onClose();
    } catch {
      toast.error('Failed to update task');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={!!task} onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit Validation Task</DialogTitle>
          <DialogDescription>Update the task details, owner, and notes.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="task-activity">Activity</Label>
            <Input
              id="task-activity"
              value={activity}
              onChange={(e) => setActivity(e.target.value)}
              placeholder="Task description"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="task-module">Module</Label>
              <Input
                id="task-module"
                value={module}
                onChange={(e) => setModule(e.target.value)}
                placeholder="e.g. Gather"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="task-submodule">Sub Module</Label>
              <Input
                id="task-submodule"
                value={subModule}
                onChange={(e) => setSubModule(e.target.value)}
                placeholder="e.g. Analytics"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="task-owner">Owner</Label>
            <Input
              id="task-owner"
              value={owner}
              onChange={(e) => setOwner(e.target.value)}
              placeholder="e.g. Eval Champion"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="task-notes">Notes</Label>
            <Textarea
              id="task-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes..."
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving || !activity.trim()}>
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Link Success Criteria Dialog ────────────────────────────────────────────

interface LinkCriteriaDialogProps {
  task: OpportunityValidationTask | null;
  successCriteria: SuccessCriterion[];
  onClose: () => void;
  onToggle: (task: OpportunityValidationTask, criterionId: string) => Promise<void>;
}

function LinkCriteriaDialog({ task, successCriteria, onClose, onToggle }: LinkCriteriaDialogProps) {
  const [search, setSearch] = useState('');

  const linkedIds = new Set(task?.linked_success_criteria_ids || []);

  const filtered = useMemo(() => {
    if (!search.trim()) return successCriteria;
    const q = search.toLowerCase();
    return successCriteria.filter(sc =>
      sc.criterion.toLowerCase().includes(q) ||
      (sc.metric_name && sc.metric_name.toLowerCase().includes(q))
    );
  }, [successCriteria, search]);

  // Split into linked-first ordering
  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      const aLinked = linkedIds.has(a.id) ? 0 : 1;
      const bLinked = linkedIds.has(b.id) ? 0 : 1;
      return aLinked - bLinked;
    });
  }, [filtered, linkedIds]);

  const statusColors: Record<string, string> = {
    proposed: 'bg-muted text-muted-foreground',
    new: 'bg-primary/10 text-primary',
    in_progress: 'bg-amber-500/10 text-amber-600',
    met: 'bg-green-500/10 text-green-600',
    not_met: 'bg-destructive/10 text-destructive',
    at_risk: 'bg-orange-500/10 text-orange-600',
  };

  return (
    <Dialog open={!!task} onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-lg max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Target className="w-4 h-4 text-emerald-500" />
            Link Success Criteria
          </DialogTitle>
          <DialogDescription>
            Link this task to success criteria (suggested or approved). 
            <span className="font-medium block mt-1 text-foreground">{task?.activity}</span>
          </DialogDescription>
        </DialogHeader>

        <Input
          placeholder="Search criteria..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="mb-2"
        />

        <div className="flex-1 overflow-auto space-y-1 min-h-0 max-h-[40vh]">
          {sorted.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">
              {successCriteria.length === 0 ? 'No success criteria found for this opportunity.' : 'No matching criteria.'}
            </p>
          ) : sorted.map(sc => {
            const isLinked = linkedIds.has(sc.id);
            return (
              <button
                key={sc.id}
                onClick={() => task && onToggle(task, sc.id)}
                className={cn(
                  "w-full text-left p-3 rounded-lg border transition-colors flex items-start gap-3",
                  isLinked
                    ? "border-emerald-500/40 bg-emerald-500/5 hover:bg-emerald-500/10"
                    : "border-border hover:bg-muted/50"
                )}
              >
                <Checkbox checked={isLinked} className="mt-0.5 shrink-0 pointer-events-none" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm leading-tight">{sc.criterion}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 h-4", statusColors[sc.status] || '')}>
                      {sc.status}
                    </Badge>
                    {sc.metric_name && (
                      <span className="text-[10px] text-muted-foreground">{sc.metric_name}</span>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        <DialogFooter className="mt-2">
          <Button onClick={onClose}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

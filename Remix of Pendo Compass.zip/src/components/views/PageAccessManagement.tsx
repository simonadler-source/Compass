import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
// (Table components not used here; using native table for reliable sticky headers)
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { usePageAccess, ALL_PAGES, AppRole } from '@/hooks/usePageAccess';
import { useCustomRoles, CustomRole } from '@/hooks/useCustomRoles';
import { Lock, Shield, AlertTriangle, ChevronRight, Plus, Trash2, Edit2, Copy } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';

// Dynamic color assignment for roles
const getRoleColor = (roleName: string): string => {
  const colorMap: Record<string, string> = {
    admin: 'bg-[hsl(var(--pendo-pink))]/20 text-[hsl(var(--pendo-pink))] border-[hsl(var(--pendo-pink))]/30',
    manager: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    se: 'bg-green-500/20 text-green-400 border-green-500/30',
    ae: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    product: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    user: 'bg-muted text-muted-foreground',
  };
  return colorMap[roleName] || 'bg-slate-500/20 text-slate-400 border-slate-500/30';
};

export function PageAccessManagement() {
  const { pageAccess, isLoading: pageAccessLoading, addAccess, removeAccess, hasPageAccess } = usePageAccess();
  const { roles: customRoles, isLoading: rolesLoading, createRole, updateRole, deleteRole, duplicateRole } = useCustomRoles();
  
  // Role management state
  const [showCreateRole, setShowCreateRole] = useState(false);
  const [showEditRole, setShowEditRole] = useState(false);
  const [editingRole, setEditingRole] = useState<CustomRole | null>(null);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleDisplayName, setNewRoleDisplayName] = useState('');
  const [newRoleDescription, setNewRoleDescription] = useState('');

  const handleToggleAccess = (pagePath: string, pageName: string, role: AppRole) => {
    if (hasPageAccess(pagePath, role)) {
      removeAccess.mutate({ pagePath, role });
    } else {
      addAccess.mutate({ pagePath, pageName, role });
    }
  };

  const handleCreateRole = () => {
    if (!newRoleName.trim() || !newRoleDisplayName.trim()) return;
    
    createRole.mutate({
      name: newRoleName,
      display_name: newRoleDisplayName,
      description: newRoleDescription || undefined,
    }, {
      onSuccess: () => {
        setShowCreateRole(false);
        setNewRoleName('');
        setNewRoleDisplayName('');
        setNewRoleDescription('');
      }
    });
  };

  const handleDeleteRole = (role: CustomRole) => {
    if (role.is_system) return;
    if (confirm(`Are you sure you want to delete the "${role.display_name}" role?`)) {
      deleteRole.mutate(role.id);
    }
  };

  const handleDuplicateRole = (role: CustomRole) => {
    duplicateRole.mutate(role.id);
  };

  const handleEditRole = (role: CustomRole) => {
    setEditingRole(role);
    setNewRoleDisplayName(role.display_name);
    setNewRoleDescription(role.description || '');
    setShowEditRole(true);
  };

  const handleSaveEditRole = () => {
    if (!editingRole || !newRoleDisplayName.trim()) return;
    
    updateRole.mutate({
      id: editingRole.id,
      display_name: newRoleDisplayName,
      description: newRoleDescription || undefined,
    }, {
      onSuccess: () => {
        setShowEditRole(false);
        setEditingRole(null);
        setNewRoleDisplayName('');
        setNewRoleDescription('');
      }
    });
  };

  const isLoading = pageAccessLoading || rolesLoading;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Use custom roles from database, excluding 'user' role for page access (it's too generic)
  const displayRoles = customRoles.filter(r => r.name !== 'user');

  // Separate pages by hierarchy level
  const topLevelPages = ALL_PAGES.filter(p => !('parent' in p));
  const childPages = ALL_PAGES.filter(p => 'parent' in p && !ALL_PAGES.some(pp => (pp as any).parent === p.path));
  const grandchildPages = ALL_PAGES.filter(p => 'parent' in p && ALL_PAGES.some(pp => (pp as any).parent === p.path));

  // Group children by parent
  const getChildrenForParent = (parentPath: string) => 
    ALL_PAGES.filter(p => (p as any).parent === parentPath);
  
  // Check if a page has grandchildren
  const hasGrandchildren = (pagePath: string) => 
    ALL_PAGES.some(p => (p as any).parent === pagePath && ALL_PAGES.some(pp => (pp as any).parent === p.path));

  return (
    <div className="space-y-6">
      {/* Role Management Section */}
      <Card className="glass border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                Manage Roles
              </CardTitle>
              <CardDescription>
                Create custom roles for your organization. System roles cannot be deleted.
              </CardDescription>
            </div>
            <Dialog open={showCreateRole} onOpenChange={setShowCreateRole}>
              <DialogTrigger asChild>
                <Button variant="glow" size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Role
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Role</DialogTitle>
                  <DialogDescription>
                    Add a custom role for page access control.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="roleName">Role Name (internal)</Label>
                    <Input
                      id="roleName"
                      placeholder="e.g., team_lead"
                      value={newRoleName}
                      onChange={(e) => setNewRoleName(e.target.value.toLowerCase().replace(/\s+/g, '_'))}
                    />
                    <p className="text-xs text-muted-foreground">Lowercase, underscores for spaces</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="displayName">Display Name</Label>
                    <Input
                      id="displayName"
                      placeholder="e.g., Team Lead"
                      value={newRoleDisplayName}
                      onChange={(e) => setNewRoleDisplayName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description (optional)</Label>
                    <Input
                      id="description"
                      placeholder="e.g., Leads a team of engineers"
                      value={newRoleDescription}
                      onChange={(e) => setNewRoleDescription(e.target.value)}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowCreateRole(false)}>Cancel</Button>
                  <Button 
                    variant="glow" 
                    onClick={handleCreateRole}
                    disabled={!newRoleName.trim() || !newRoleDisplayName.trim() || createRole.isPending}
                  >
                    {createRole.isPending ? 'Creating...' : 'Create Role'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Dialog open={showEditRole} onOpenChange={setShowEditRole}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Edit Role</DialogTitle>
                  <DialogDescription>
                    Update the display name and description for this role.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Role Name (internal)</Label>
                    <Input
                      value={editingRole?.name || ''}
                      disabled
                      className="opacity-50"
                    />
                    <p className="text-xs text-muted-foreground">Internal name cannot be changed</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editDisplayName">Display Name</Label>
                    <Input
                      id="editDisplayName"
                      placeholder="e.g., Team Lead"
                      value={newRoleDisplayName}
                      onChange={(e) => setNewRoleDisplayName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editDescription">Description (optional)</Label>
                    <Input
                      id="editDescription"
                      placeholder="e.g., Leads a team of engineers"
                      value={newRoleDescription}
                      onChange={(e) => setNewRoleDescription(e.target.value)}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowEditRole(false)}>Cancel</Button>
                  <Button 
                    variant="glow" 
                    onClick={handleSaveEditRole}
                    disabled={!newRoleDisplayName.trim() || updateRole.isPending}
                  >
                    {updateRole.isPending ? 'Saving...' : 'Save Changes'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {customRoles.map(role => (
              <div key={role.id} className="group relative">
                <Badge className={cn('text-xs pr-14', getRoleColor(role.name))}>
                  <Shield className="w-3 h-3 mr-1" />
                  {role.display_name}
                  {role.is_system && <span className="ml-1 opacity-50">(system)</span>}
                </Badge>
                <div className="absolute right-1 top-1/2 -translate-y-1/2 hidden group-hover:flex items-center gap-0.5">
                  <button
                    onClick={() => handleEditRole(role)}
                    className="flex items-center justify-center w-4 h-4 rounded-full bg-muted hover:bg-primary text-muted-foreground hover:text-primary-foreground text-xs transition-colors"
                    title="Edit role"
                  >
                    <Edit2 className="w-2.5 h-2.5" />
                  </button>
                  <button
                    onClick={() => handleDuplicateRole(role)}
                    className="flex items-center justify-center w-4 h-4 rounded-full bg-muted hover:bg-primary text-muted-foreground hover:text-primary-foreground text-xs transition-colors"
                    title="Duplicate role"
                  >
                    <Copy className="w-2.5 h-2.5" />
                  </button>
                  {!role.is_system && (
                    <button
                      onClick={() => handleDeleteRole(role)}
                      className="flex items-center justify-center w-4 h-4 rounded-full bg-destructive text-destructive-foreground text-xs"
                      title="Delete role"
                    >
                      ×
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Page Access Control Section */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            Page Access Control
          </CardTitle>
          <CardDescription>
            Configure which roles can access each page and sub-menu. Users need at least one matching role to access a page.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="rounded-md border overflow-hidden">
            <div className="max-h-[600px] overflow-auto">
              <table className="w-full min-w-max table-fixed caption-bottom text-sm">
                <thead className="[&_tr]:border-b">
                  <tr className="border-b bg-card">
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground sticky top-0 z-20 bg-card w-[280px]">
                      Page / Tab
                    </th>
                    {displayRoles.map(role => (
                      <th
                        key={role.id}
                        className="h-12 px-4 text-center align-middle font-medium text-muted-foreground sticky top-0 z-20 bg-card w-[100px]"
                      >
                        <Badge className={cn('text-xs', getRoleColor(role.name))}>
                          {role.display_name}
                        </Badge>
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody className="[&_tr:last-child]:border-0">
                  {topLevelPages.map(page => {
                    const children = getChildrenForParent(page.path);
                    const isParentPage = 'isParent' in page && (page as any).isParent;

                    return (
                      <>
                        <tr
                          key={page.path}
                          className={cn(
                            'border-b transition-colors hover:bg-muted/50',
                            isParentPage ? 'bg-muted/30' : ''
                          )}
                        >
                          <td className="p-4 align-middle font-medium w-[280px]">
                            <div className="flex items-center gap-2">
                              {page.name}
                              {children.length > 0 && (
                                <Badge variant="outline" className="text-xs">
                                  {children.length} tabs
                                </Badge>
                              )}
                            </div>
                          </td>
                          {displayRoles.map(role => {
                            const hasAccess = hasPageAccess(page.path, role.name);
                            const isPending = addAccess.isPending || removeAccess.isPending;

                            return (
                              <td key={role.id} className="p-4 align-middle text-center w-[100px]">
                                <Checkbox
                                  checked={hasAccess}
                                  onCheckedChange={() => handleToggleAccess(page.path, page.name, role.name)}
                                  disabled={isPending}
                                  className={cn(
                                    hasAccess && 'data-[state=checked]:bg-primary data-[state=checked]:border-primary'
                                  )}
                                />
                              </td>
                            );
                          })}
                        </tr>

                        {/* Render child pages/tabs */}
                        {children.map(child => {
                          const grandchildren = getChildrenForParent(child.path);
                          const hasGrandchildrenFlag = grandchildren.length > 0;

                          return (
                            <>
                              <tr
                                key={child.path}
                                className={cn(
                                  'border-b transition-colors hover:bg-muted/50',
                                  hasGrandchildrenFlag ? 'bg-muted/20' : 'bg-muted/10'
                                )}
                              >
                                <td className="p-4 align-middle font-medium pl-8 w-[280px]">
                                  <div className="flex items-center gap-2 text-muted-foreground">
                                    <ChevronRight className="w-4 h-4" />
                                    <span className="text-foreground">{child.name.split(' → ').pop()}</span>
                                    {hasGrandchildrenFlag && (
                                      <Badge variant="outline" className="text-xs">
                                        {grandchildren.length} sub-tabs
                                      </Badge>
                                    )}
                                  </div>
                                </td>
                                {displayRoles.map(role => {
                                  const hasAccess = hasPageAccess(child.path, role.name);
                                  const isPending = addAccess.isPending || removeAccess.isPending;

                                  return (
                                    <td key={role.id} className="p-4 align-middle text-center w-[100px]">
                                      <Checkbox
                                        checked={hasAccess}
                                        onCheckedChange={() => handleToggleAccess(child.path, child.name, role.name)}
                                        disabled={isPending}
                                        className={cn(
                                          hasAccess && 'data-[state=checked]:bg-primary data-[state=checked]:border-primary'
                                        )}
                                      />
                                    </td>
                                  );
                                })}
                              </tr>

                              {/* Render grandchild pages/tabs (e.g., Opportunity tabs) */}
                              {grandchildren.map(grandchild => (
                                <tr
                                  key={grandchild.path}
                                  className="border-b transition-colors hover:bg-muted/50 bg-muted/5"
                                >
                                  <td className="p-4 align-middle font-medium pl-14 w-[280px]">
                                    <div className="flex items-center gap-2 text-muted-foreground">
                                      <ChevronRight className="w-3 h-3" />
                                      <span className="text-foreground text-sm">
                                        {grandchild.name.split(' → ').pop()}
                                      </span>
                                    </div>
                                  </td>
                                  {displayRoles.map(role => {
                                    const hasAccess = hasPageAccess(grandchild.path, role.name);
                                    const isPending = addAccess.isPending || removeAccess.isPending;

                                    return (
                                      <td key={role.id} className="p-4 align-middle text-center w-[100px]">
                                        <Checkbox
                                          checked={hasAccess}
                                          onCheckedChange={() =>
                                            handleToggleAccess(grandchild.path, grandchild.name, role.name)
                                          }
                                          disabled={isPending}
                                          className={cn(
                                            hasAccess &&
                                              'data-[state=checked]:bg-primary data-[state=checked]:border-primary'
                                          )}
                                        />
                                      </td>
                                    );
                                  })}
                                </tr>
                              ))}
                            </>
                          );
                        })}
                      </>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            Important Notes
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p>• Changes take effect immediately when users navigate to a page.</p>
          <p>• Admins should always have access to Settings to avoid being locked out.</p>
          <p>• The sidebar navigation will automatically hide pages users cannot access.</p>
          <p>• Sub-tabs can be individually restricted - users will see the page but not restricted tabs.</p>
          <p>• Users with no role assigned will not have access to any restricted pages.</p>
        </CardContent>
      </Card>
    </div>
  );
}

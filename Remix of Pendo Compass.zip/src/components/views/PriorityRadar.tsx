import { useState, useMemo, useRef, useCallback, useEffect } from 'react';
import { useDrag, useDrop } from 'react-dnd';
import { cn } from '@/lib/utils';
import { Account, PriorityLevel } from '@/types/architecture';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X, ChevronLeft, Target, Info, ZoomIn, ZoomOut, RotateCcw, Camera, ListTree, Plus, Circle, Search, Sparkles, CheckCircle2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import { toast } from 'sonner';
import { useAccountUseCases, useUpdateUseCase, useCreateUseCase, AccountUseCase } from '@/hooks/useAccountUseCases';
import { useOpportunityUseCases, useUpdateOpportunityUseCase, useCreateOpportunityUseCase } from '@/hooks/useOpportunityUseCases';
import { useFunctionalAreas, FunctionalArea } from '@/hooks/useTechnologyRepository';
import { useUseCaseTemplates, UseCaseTemplate } from '@/hooks/useFunctionalAreaDetails';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown } from 'lucide-react';

interface PriorityRadarProps {
  account: Account;
  opportunityId?: string;
  onUpdateAccount: (account: Account) => void;
  onBack: () => void;
  embedded?: boolean;
}

interface UseCaseItem {
  id: string;
  name: string;
  functionalArea: string;
  functionalAreaId?: string;
  description?: string;
  priority?: PriorityLevel;
  status?: string;
  source: 'discovered' | 'whitespace' | 'manual';
  radarX?: number | null;
  radarY?: number | null;
  linkedTemplateId?: string;
  linkedTemplateName?: string;
  isLinked?: boolean;
}

// Helper to check if a use case is linked to a template
function isUseCaseLinked(uc: { description?: string | null; linkedTemplateId?: string }): boolean {
  return !!(
    uc.linkedTemplateId ||
    uc.description?.startsWith('Linked from discovered:') ||
    uc.description?.startsWith('Originally:')
  );
}

// Find best matching template for a use case
function findBestMatchingTemplate(
  useCaseName: string,
  functionalArea: string,
  templates: UseCaseTemplate[],
  functionalAreas: FunctionalArea[]
): UseCaseTemplate | null {
  const normalizedName = useCaseName.toLowerCase().trim();
  
  // First try exact match
  const exactMatch = templates.find(t => t.name.toLowerCase().trim() === normalizedName);
  if (exactMatch) return exactMatch;
  
  // Then try to find a match in the same functional area
  const areaId = functionalAreas.find(fa => fa.name === functionalArea)?.id;
  const sameAreaTemplates = areaId 
    ? templates.filter(t => t.functional_area_id === areaId)
    : templates;
  
  // Try partial match with keywords
  const useCaseWords = normalizedName.split(/\s+/).filter(w => w.length > 2);
  let bestMatch: { template: UseCaseTemplate; score: number } | null = null;
  
  for (const template of sameAreaTemplates) {
    const templateWords = template.name.toLowerCase().split(/\s+/).filter(w => w.length > 2);
    const matchingWords = useCaseWords.filter(uw => 
      templateWords.some(tw => tw.includes(uw) || uw.includes(tw))
    );
    const score = matchingWords.length / Math.max(useCaseWords.length, 1);
    
    if (score > 0.3 && (!bestMatch || score > bestMatch.score)) {
      bestMatch = { template, score };
    }
  }
  
  // If no match in same area, try all templates
  if (!bestMatch && areaId) {
    for (const template of templates) {
      const templateWords = template.name.toLowerCase().split(/\s+/).filter(w => w.length > 2);
      const matchingWords = useCaseWords.filter(uw => 
        templateWords.some(tw => tw.includes(uw) || uw.includes(tw))
      );
      const score = matchingWords.length / Math.max(useCaseWords.length, 1);
      
      if (score > 0.4 && (!bestMatch || score > bestMatch.score)) {
        bestMatch = { template, score };
      }
    }
  }
  
  return bestMatch?.template || null;
}

const priorityRings: { level: PriorityLevel; label: string; description: string }[] = [
  { level: 'critical', label: 'Critical', description: 'Immediate focus - high data value' },
  { level: 'high', label: 'High', description: 'Strategic priority' },
  { level: 'medium', label: 'Medium', description: 'Important but not urgent' },
  { level: 'low', label: 'Low', description: 'Nice to have' },
];

const priorityColors: Record<PriorityLevel, string> = {
  critical: 'bg-priority-critical/20 border-priority-critical',
  high: 'bg-priority-high/20 border-priority-high',
  medium: 'bg-priority-medium/20 border-priority-medium',
  low: 'bg-priority-low/20 border-priority-low',
};

const priorityHexColors: Record<PriorityLevel, string> = {
  critical: '#ef4444',
  high: '#f97316',
  medium: '#eab308',
  low: '#22c55e',
};

const AREA_COLORS: Record<string, string> = {
  'Analytics & Insights': 'hsl(220, 70%, 50%)',
  'CRM': 'hsl(0, 70%, 50%)',
  'Digital Adoption & Guides': 'hsl(330, 70%, 50%)',
  'Digital Adoption & In-App Guides': 'hsl(330, 70%, 50%)',
  'Customer Success': 'hsl(160, 70%, 40%)',
  'Marketing Automation': 'hsl(280, 70%, 50%)',
  'Data Infrastructure': 'hsl(200, 70%, 45%)',
  'Data Lake / Warehouse': 'hsl(200, 70%, 45%)',
  'Communication': 'hsl(45, 80%, 45%)',
  'Support & Ticketing': 'hsl(25, 80%, 50%)',
  'Development Tools': 'hsl(180, 60%, 40%)',
  'Security & Identity': 'hsl(350, 70%, 45%)',
  'Content Management': 'hsl(140, 60%, 40%)',
  'Knowledge Base & Content': 'hsl(140, 60%, 40%)',
  'E-commerce': 'hsl(30, 70%, 50%)',
  'Collaboration': 'hsl(260, 60%, 55%)',
  'Host Application': 'hsl(180, 50%, 45%)',
  'Third-Party Apps': 'hsl(290, 50%, 50%)',
  'Roadmap & Feedback': 'hsl(50, 70%, 50%)',
  'Back Office Processes': 'hsl(100, 40%, 50%)',
  'Executive Dashboards & BI': 'hsl(220, 60%, 55%)',
  'Financial & Planning Systems (ERP, FP&A)': 'hsl(10, 60%, 50%)',
  'Learning Management System (LMS)': 'hsl(270, 50%, 55%)',
  'Issue Tracking & Agile': 'hsl(170, 50%, 45%)',
  'Pendo Javascript Snippet / SDK / API': 'hsl(340, 60%, 50%)',
  'Other': 'hsl(0, 0%, 50%)',
};

const RING_RADII = {
  critical: 140,
  high: 240,
  medium: 340,
  low: 440,
};

function getPriorityFromDistance(distance: number): PriorityLevel {
  if (distance <= RING_RADII.critical) return 'critical';
  if (distance <= RING_RADII.high) return 'high';
  if (distance <= RING_RADII.medium) return 'medium';
  return 'low';
}

function UseCaseChip({ 
  useCase, 
  onOpenLinkDialog 
}: { 
  useCase: UseCaseItem;
  onOpenLinkDialog?: (uc: UseCaseItem) => void;
}) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'use-case',
    item: { ...useCase, type: 'use-case' },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }), [useCase]);

  const color = AREA_COLORS[useCase.functionalArea] || AREA_COLORS['Other'];
  
  // Determine source icon and tooltip based on linked status
  const getSourceInfo = () => {
    if (useCase.isLinked) {
      return {
        icon: <CheckCircle2 className="w-3 h-3 text-green-500" />,
        tooltip: useCase.linkedTemplateName 
          ? `Linked to: ${useCase.linkedTemplateName}`
          : 'Linked use case'
      };
    }
    if (useCase.source === 'discovered') {
      return {
        icon: <Sparkles className="w-3 h-3 text-amber-500" />,
        tooltip: 'Discovered from transcript - drag to radar to link'
      };
    }
    if (useCase.source === 'whitespace') {
      return {
        icon: <Circle className="w-3 h-3 text-muted-foreground" />,
        tooltip: 'Template use case - drag to radar to add'
      };
    }
    return {
      icon: <Plus className="w-3 h-3 text-primary" />,
      tooltip: 'Manually added - drag to radar to link'
    };
  };

  const sourceInfo = getSourceInfo();

  return (
    <div
      ref={drag}
      className={cn(
        "px-3 py-2 rounded-lg border-2 cursor-grab active:cursor-grabbing transition-all group",
        "hover:scale-[1.02] hover:shadow-md",
        isDragging && "opacity-50 scale-95",
        useCase.isLinked && "ring-1 ring-green-500/30"
      )}
      style={{
        backgroundColor: `${color}15`,
        borderColor: color,
      }}
      title={useCase.name}
    >
      <div className="flex items-center gap-2">
        <span title={sourceInfo.tooltip}>
          {sourceInfo.icon}
        </span>
        <ListTree className="w-3.5 h-3.5" style={{ color }} />
        <span className="text-sm font-medium truncate max-w-[120px]" title={useCase.name}>
          {useCase.name}
        </span>
        {useCase.isLinked && (
          <Badge 
            variant="default" 
            className="text-[10px] px-1 py-0 bg-green-600 hover:bg-green-600"
          >
            Linked
          </Badge>
        )}
        {useCase.priority && (
          <Badge 
            variant="outline" 
            className="text-[10px] px-1 py-0"
            style={{ borderColor: priorityHexColors[useCase.priority], color: priorityHexColors[useCase.priority] }}
          >
            {useCase.priority}
          </Badge>
        )}
      </div>
      <div className="mt-1 flex items-center justify-between">
        <span className="text-xs text-muted-foreground truncate max-w-[160px]" title={useCase.functionalArea}>
          {useCase.functionalArea}
        </span>
        {!useCase.isLinked && useCase.source === 'discovered' && onOpenLinkDialog && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenLinkDialog(useCase);
            }}
            className="text-xs text-primary hover:underline opacity-0 group-hover:opacity-100 transition-opacity"
            title="Link to a template use case"
          >
            Link
          </button>
        )}
      </div>
    </div>
  );
}

function PlacedRadarChip({
  item,
  position,
  onMove,
  onRemove,
  zoom,
}: {
  item: UseCaseItem;
  position: { x: number; y: number };
  onMove: (newPos: { x: number; y: number }) => void;
  onRemove: () => void;
  zoom: number;
}) {
  const chipRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartPos = useRef({ x: 0, y: 0 });
  const chipStartPos = useRef({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
    dragStartPos.current = { x: e.clientX, y: e.clientY };
    chipStartPos.current = { x: position.x, y: position.y };
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      const dx = (e.clientX - dragStartPos.current.x) / zoom;
      const dy = (e.clientY - dragStartPos.current.y) / zoom;
      onMove({
        x: chipStartPos.current.x + dx,
        y: chipStartPos.current.y + dy,
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, zoom, onMove]);

  const color = AREA_COLORS[item.functionalArea] || AREA_COLORS['Other'];
  
  // All placed items should be linked, show green checkmark
  const getSourceIcon = () => {
    return <CheckCircle2 className="w-3 h-3 text-green-500" />;
  };

  const getTooltip = () => {
    let tooltip = item.name;
    if (item.linkedTemplateName) {
      tooltip += ` (Linked to: ${item.linkedTemplateName})`;
    } else {
      tooltip += ' (Linked)';
    }
    return tooltip;
  };

  return (
    <div
      ref={chipRef}
      className={cn(
        "absolute group cursor-grab active:cursor-grabbing select-none",
        isDragging && "z-50"
      )}
      style={{
        left: position.x,
        top: position.y,
        transform: 'translate(-50%, -50%)',
      }}
      onMouseDown={handleMouseDown}
    >
      <div
        className="px-2 py-1 rounded-md border-2 text-xs font-medium whitespace-nowrap relative pr-6 shadow-md"
        style={{
          backgroundColor: `${color}40`,
          borderColor: color,
          color: 'hsl(var(--foreground))',
        }}
        title={getTooltip()}
      >
        <div className="flex items-center gap-1">
          {getSourceIcon()}
          <ListTree className="w-3 h-3" style={{ color }} />
          <span className="max-w-[100px] truncate">{item.name}</span>
        </div>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="absolute right-1 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity p-0.5 rounded hover:bg-destructive/20"
          title="Remove from radar"
        >
          <X className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}

export function PriorityRadar({ account, opportunityId, onUpdateAccount, onBack, embedded }: PriorityRadarProps) {
  const [zoom, setZoom] = useState(0.85);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedAreas, setExpandedAreas] = useState<Record<string, boolean>>({});
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [linkingUseCase, setLinkingUseCase] = useState<UseCaseItem | null>(null);
  const [newUseCaseName, setNewUseCaseName] = useState('');
  const [newUseCaseArea, setNewUseCaseArea] = useState('');
  const [newUseCaseDescription, setNewUseCaseDescription] = useState('');
  
  const lastMousePos = useRef({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const radarRef = useRef<HTMLDivElement>(null);

  const { data: functionalAreas = [] } = useFunctionalAreas();
  
  // Use opportunity-specific or account-level use cases based on opportunityId
  const { data: accountUseCases = [] } = useAccountUseCases(account.id);
  const { data: opportunityUseCases = [] } = useOpportunityUseCases(opportunityId || '');
  
  // Choose the appropriate use cases based on whether we're viewing opportunity or account level
  const useCases = opportunityId ? opportunityUseCases : accountUseCases;
  
  const { data: useCaseTemplates = [] } = useUseCaseTemplates();
  const updateUseCaseMutation = useUpdateUseCase();
  const createUseCaseMutation = useCreateUseCase();
  const updateOpportunityUseCaseMutation = useUpdateOpportunityUseCase();
  const createOpportunityUseCaseMutation = useCreateOpportunityUseCase();

  const ringSizes = [280, 480, 680, 880];
  const RADAR_CENTER = 500;

  const safeLower = (v: unknown) => (typeof v === 'string' ? v.toLowerCase() : '');

  // Build unified use case list: discovered (from account) + whitespace (templates not in account)
  const allUseCases: UseCaseItem[] = useMemo(() => {
    const items: UseCaseItem[] = [];
    
    // Build a map of template names (normalized) to templates for matching
    const templatesByName = new Map<string, UseCaseTemplate>();
    useCaseTemplates.forEach(template => {
      templatesByName.set(template.name.toLowerCase().trim(), template);
    });
    
    // Track which templates have been matched to discovered use cases
    const matchedTemplateIds = new Set<string>();
    
    // Add discovered/manual use cases - try to match with templates
    useCases.forEach((uc: any) => {
      const rawName = typeof uc?.use_case === 'string' ? uc.use_case : '';
      const displayName = rawName.trim() ? rawName : 'Untitled use case';
      const normalizedName = rawName.toLowerCase().trim();
      const matchedTemplate = templatesByName.get(normalizedName);

      const functionalArea = typeof uc?.functional_area === 'string' && uc.functional_area.trim()
        ? uc.functional_area
        : 'Other';
      
      // Determine source: if from transcript, it's discovered; if manually added or whitespace, keep that
      let source: 'discovered' | 'whitespace' | 'manual' = 'discovered';
      if (uc.source === 'manual') {
        source = 'manual';
      } else if (uc.source === 'whitespace') {
        source = 'whitespace';
      } else if (uc.source_transcript_id || uc.source === 'transcript') {
        source = 'discovered';
      }
      
      if (matchedTemplate) {
        matchedTemplateIds.add(matchedTemplate.id);
      }
      
      const isLinked = isUseCaseLinked({ description: uc.description, linkedTemplateId: matchedTemplate?.id });
      
      items.push({
        id: uc.id,
        name: displayName,
        functionalArea,
        description: uc.description || matchedTemplate?.description || undefined,
        priority: uc.priority as PriorityLevel | undefined,
        status: uc.status,
        source,
        radarX: uc.radar_x,
        radarY: uc.radar_y,
        linkedTemplateId: matchedTemplate?.id,
        linkedTemplateName: matchedTemplate?.name,
        isLinked,
      });
    });

    // Add whitespace use cases (templates not yet matched)
    useCaseTemplates.forEach(template => {
      if (!matchedTemplateIds.has(template.id)) {
        // Check if there's a partial match by checking if any use case contains similar words
        const templateWords = template.name.toLowerCase().split(/\s+/);
        const hasPartialMatch = useCases.some((uc: any) => {
          const ucWords = safeLower(uc?.use_case).split(/\s+/).filter(Boolean);
          const matchingWords = templateWords.filter((tw: string) => 
            ucWords.some((uw: string) => uw.includes(tw) || tw.includes(uw))
          );
          return matchingWords.length >= Math.min(2, templateWords.length);
        });
        
        // Only add as whitespace if no partial match found
        if (!hasPartialMatch) {
          const area = functionalAreas.find(fa => fa.id === template.functional_area_id);
          items.push({
            id: `template-${template.id}`,
            name: template.name,
            functionalArea: area?.name || 'Other',
            functionalAreaId: template.functional_area_id,
            description: template.description || undefined,
            source: 'whitespace',
          });
        }
      }
    });

    return items;
  }, [useCases, useCaseTemplates, functionalAreas]);

  // Group use cases by functional area
  const useCasesByArea = useMemo(() => {
    const grouped: Record<string, UseCaseItem[]> = {};
    
    allUseCases.forEach(uc => {
      const area = uc.functionalArea;
      if (!grouped[area]) {
        grouped[area] = [];
      }
      grouped[area].push(uc);
    });

    // Sort areas by number of discovered use cases (descending)
    return Object.entries(grouped)
      .sort((a, b) => {
        const aDiscovered = a[1].filter(u => u.source === 'discovered').length;
        const bDiscovered = b[1].filter(u => u.source === 'discovered').length;
        return bDiscovered - aDiscovered;
      });
  }, [allUseCases]);

  // Filter use cases based on search
  const filteredUseCasesByArea = useMemo(() => {
    if (!searchQuery.trim()) return useCasesByArea;
    
    const query = searchQuery.toLowerCase();
    return useCasesByArea
      .map(([area, useCases]) => {
        const filtered = useCases.filter(uc => 
          safeLower(uc.name).includes(query) ||
          safeLower(uc.functionalArea).includes(query) ||
          safeLower(uc.description).includes(query)
        );
        return [area, filtered] as [string, UseCaseItem[]];
      })
      .filter(([_, useCases]) => useCases.length > 0);
  }, [useCasesByArea, searchQuery]);

  // Get placed items - ONLY linked use cases should appear on the radar
  const placedItems = useMemo(() => {
    return allUseCases.filter(uc => 
      uc.isLinked && (uc.priority || (uc.radarX !== null && uc.radarX !== undefined))
    );
  }, [allUseCases]);

  // Get unplaced items for the palette (all items not on the radar)
  const unplacedItems = useMemo(() => {
    return allUseCases.filter(uc => 
      !uc.isLinked || (!uc.priority && (uc.radarX === null || uc.radarX === undefined))
    );
  }, [allUseCases]);

  // Auto-link existing placed use cases that aren't linked yet
  useEffect(() => {
    const unlinkePlacedItems = allUseCases.filter(uc => 
      !uc.isLinked && 
      !uc.id.startsWith('template-') &&
      (uc.priority || (uc.radarX !== null && uc.radarX !== undefined))
    );
    
    unlinkePlacedItems.forEach(uc => {
      const bestMatch = findBestMatchingTemplate(uc.name, uc.functionalArea, useCaseTemplates, functionalAreas);
      if (bestMatch) {
        const area = functionalAreas.find(fa => fa.id === bestMatch.functional_area_id);
        updateUseCaseMutation.mutate({
          id: uc.id,
          accountId: account.id,
          functional_area: area?.name || uc.functionalArea,
          use_case: bestMatch.name,
          description: `Originally: "${uc.name}"\n\n${bestMatch.description || ''}`,
        });
      }
    });
  }, [allUseCases.length]); // Only run when use cases list changes

  const handleSaveAsImage = useCallback(async () => {
    if (!radarRef.current) return;
    
    try {
      const originalTransform = radarRef.current.style.transform;
      radarRef.current.style.transform = 'none';
      
      const canvas = await html2canvas(radarRef.current, {
        backgroundColor: '#ffffff',
        scale: 2,
      });
      
      radarRef.current.style.transform = originalTransform;
      
      const link = document.createElement('a');
      link.download = `${account.name.replace(/\s+/g, '_')}_priority_radar.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      
      toast.success('Radar image saved');
    } catch (error) {
      console.error('Failed to save image:', error);
      toast.error('Failed to save image');
    }
  }, [account.name]);

  const handleZoomIn = useCallback(() => setZoom(prev => Math.min(prev + 0.15, 2)), []);
  const handleZoomOut = useCallback(() => setZoom(prev => Math.max(prev - 0.15, 0.3)), []);
  const handleResetZoom = useCallback(() => {
    setZoom(0.85);
    setPan({ x: 0, y: 0 });
  }, []);

  // Scroll pans the canvas, zoom is via buttons only
  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    // Pan instead of zoom on scroll
    setPan(prev => ({
      x: prev.x - e.deltaX,
      y: prev.y - e.deltaY,
    }));
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    // Middle mouse button or left click + alt for panning
    if (e.button === 1 || (e.button === 0 && e.altKey)) {
      setIsPanning(true);
      lastMousePos.current = { x: e.clientX, y: e.clientY };
      e.preventDefault();
    }
    // Left click without alt also initiates panning for easier navigation
    if (e.button === 0 && !e.altKey && e.target === e.currentTarget) {
      setIsPanning(true);
      lastMousePos.current = { x: e.clientX, y: e.clientY };
    }
  }, []);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (isPanning) {
      const dx = e.clientX - lastMousePos.current.x;
      const dy = e.clientY - lastMousePos.current.y;
      setPan(prev => ({ x: prev.x + dx, y: prev.y + dy }));
      lastMousePos.current = { x: e.clientX, y: e.clientY };
    }
  }, [isPanning]);

  const handleMouseUp = useCallback(() => setIsPanning(false), []);

  // Handle drop from palette onto radar - auto-links to best template
  const [{ isOver }, dropRef] = useDrop(() => ({
    accept: 'use-case',
    drop: (item: UseCaseItem & { type: string }, monitor) => {
      const offset = monitor.getClientOffset();
      if (!offset || !radarRef.current) return;

      const rect = radarRef.current.getBoundingClientRect();
      const x = ((offset.x - rect.left) / zoom) - RADAR_CENTER + (RADAR_CENTER - rect.width / zoom / 2);
      const y = ((offset.y - rect.top) / zoom) - RADAR_CENTER + (RADAR_CENTER - rect.height / zoom / 2);
      
      const distance = Math.sqrt(x * x + y * y);
      const priority = getPriorityFromDistance(distance);
      const radarX = RADAR_CENTER + x;
      const radarY = RADAR_CENTER + y;

      // If whitespace template, create as account use case (already linked by definition)
      if (item.id.startsWith('template-')) {
        const templateId = item.id.replace('template-', '');
        const template = useCaseTemplates.find(t => t.id === templateId);
        createUseCaseMutation.mutate({
          account_id: account.id,
          opportunity_id: null,
          functional_area: item.functionalArea,
          use_case: item.name,
          description: template?.description || null,
          status: 'identified',
          priority,
          source: 'whitespace',
          source_transcript_id: null,
          sort_order: 0,
          radar_x: radarX,
          radar_y: radarY,
        });
        toast.success(`Added "${item.name}" to radar`);
      } else {
        // For discovered/manual use cases, auto-link to best matching template
        const bestMatch = findBestMatchingTemplate(item.name, item.functionalArea, useCaseTemplates, functionalAreas);
        
        if (bestMatch) {
          const area = functionalAreas.find(fa => fa.id === bestMatch.functional_area_id);
          updateUseCaseMutation.mutate({
            id: item.id,
            accountId: account.id,
            functional_area: area?.name || item.functionalArea,
            use_case: bestMatch.name,
            description: `Originally: "${item.name}"\n\n${bestMatch.description || ''}`,
            priority,
            radar_x: radarX,
            radar_y: radarY,
          });
          toast.success(`Linked to "${bestMatch.name}" and added to radar`);
        } else {
          // No matching template found - just place on radar with manual marker
          updateUseCaseMutation.mutate({
            id: item.id,
            accountId: account.id,
            description: `Originally: "${item.name}"`,
            priority,
            radar_x: radarX,
            radar_y: radarY,
          });
          toast.success(`Added "${item.name}" to radar (no template match found)`);
        }
      }
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  }), [zoom, account.id, updateUseCaseMutation, createUseCaseMutation, useCaseTemplates, functionalAreas]);

  const handleMoveItem = useCallback((itemId: string, newPos: { x: number; y: number }) => {
    const dx = newPos.x - RADAR_CENTER;
    const dy = newPos.y - RADAR_CENTER;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const priority = getPriorityFromDistance(distance);

    updateUseCaseMutation.mutate({
      id: itemId,
      accountId: account.id,
      priority,
      radar_x: newPos.x,
      radar_y: newPos.y,
    });
  }, [account.id, updateUseCaseMutation]);

  const handleRemoveFromRadar = useCallback((itemId: string) => {
    updateUseCaseMutation.mutate({
      id: itemId,
      accountId: account.id,
      priority: null,
      radar_x: null,
      radar_y: null,
    });
  }, [account.id, updateUseCaseMutation]);

  const handleAddManualUseCase = async () => {
    if (!newUseCaseName.trim() || !newUseCaseArea) return;
    
    await createUseCaseMutation.mutateAsync({
      account_id: account.id,
      opportunity_id: null,
      functional_area: newUseCaseArea,
      use_case: newUseCaseName.trim(),
      description: newUseCaseDescription.trim() || null,
      status: 'identified',
      priority: null,
      source: 'manual',
      source_transcript_id: null,
      sort_order: 0,
      radar_x: null,
      radar_y: null,
    });
    
    setShowAddDialog(false);
    setNewUseCaseName('');
    setNewUseCaseArea('');
    setNewUseCaseDescription('');
    toast.success('Use case added');
  };

  const handleOpenLinkDialog = (uc: UseCaseItem) => {
    setLinkingUseCase(uc);
    setShowLinkDialog(true);
  };

  // Expand all areas initially that have discovered use cases
  useEffect(() => {
    const initial: Record<string, boolean> = {};
    useCasesByArea.forEach(([area, useCases]) => {
      initial[area] = useCases.some(uc => uc.source === 'discovered');
    });
    setExpandedAreas(initial);
  }, [useCasesByArea.length]);

  const toggleAreaExpanded = (area: string) => {
    setExpandedAreas(prev => ({ ...prev, [area]: !prev[area] }));
  };

  return (
    <div className="flex h-full animate-fade-in">
      {/* Left: Radar Visualization */}
      <div className="flex-1 p-6 overflow-hidden">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="page-heading">{account.name}</h1>
            <p className="text-muted-foreground">Priority Radar - Use Cases</p>
          </div>
        </div>

        <div className="flex items-center gap-2 mb-4 p-3 rounded-lg bg-primary/10 border border-primary/20">
          <Info className="w-4 h-4 text-primary" />
          <p className="text-sm text-muted-foreground flex-1">
            Drag use cases onto the radar to link and prioritize them. Priority = distance from center.
          </p>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center gap-2 mb-4">
          <Button variant="outline" size="sm" onClick={handleZoomOut} disabled={zoom <= 0.3}>
            <ZoomOut className="w-4 h-4" />
          </Button>
          <span className="text-sm text-muted-foreground w-16 text-center">
            {Math.round(zoom * 100)}%
          </span>
          <Button variant="outline" size="sm" onClick={handleZoomIn} disabled={zoom >= 2}>
            <ZoomIn className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={handleResetZoom}>
            <RotateCcw className="w-4 h-4" />
          </Button>
          <div className="flex-1" />
          <Button variant="outline" size="sm" onClick={handleSaveAsImage}>
            <Camera className="w-4 h-4 mr-2" />
            Save as Image
          </Button>
          <span className="text-xs text-muted-foreground ml-2">
            Scroll to zoom • Alt+drag to pan
          </span>
        </div>

        {/* Radar Container */}
        <div 
          ref={containerRef}
          className={cn(
            "relative w-full h-[800px] overflow-hidden rounded-lg border border-border bg-background/50",
            isPanning && "cursor-grabbing",
            isOver && "ring-2 ring-primary"
          )}
          onWheel={handleWheel}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {/* Legend */}
          <div className="absolute top-3 left-3 z-20 bg-background/90 backdrop-blur-sm rounded-lg border border-border p-2 text-xs">
            <div className="flex items-center gap-1 mb-1 font-medium">
              <Target className="w-3 h-3 text-primary" />
              <span>Priority →</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-muted-foreground">Center = Highest</span>
            </div>
            <div className="flex gap-1 mt-1">
              {priorityRings.map((ring) => (
                <div
                  key={ring.level}
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: priorityHexColors[ring.level] }}
                  title={ring.label}
                />
              ))}
            </div>
          </div>

          <div
            ref={(node) => {
              radarRef.current = node;
              dropRef(node);
            }}
            className="absolute inset-0 flex items-center justify-center transition-transform duration-100"
            style={{
              transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
              transformOrigin: 'center center',
              width: '1000px',
              height: '1000px',
              margin: 'auto',
            }}
          >
            {/* Priority Rings */}
            {priorityRings.map((ring, index) => (
              <div
                key={ring.level}
                className={cn(
                  "absolute rounded-full border-2 pointer-events-none",
                  priorityColors[ring.level]
                )}
                style={{
                  width: ringSizes[index],
                  height: ringSizes[index],
                  top: '50%',
                  left: '50%',
                  transform: 'translate(-50%, -50%)',
                }}
              >
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 whitespace-nowrap">
                  <span className="text-xs font-medium text-muted-foreground">{ring.label}</span>
                </div>
              </div>
            ))}

            {/* Center Target */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none">
              <div className="w-16 h-16 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center animate-pulse-slow">
                <Target className="w-8 h-8 text-primary" />
              </div>
            </div>

            {/* Placed Items */}
            {placedItems.map((item) => {
              // Skip whitespace items (they become real use cases when placed)
              if (item.id.startsWith('template-')) return null;

              let position = { 
                x: item.radarX ?? RADAR_CENTER, 
                y: item.radarY ?? RADAR_CENTER 
              };
              
              // If no saved position, calculate from priority
              if (!item.radarX && !item.radarY && item.priority) {
                const ringIndex = priorityRings.findIndex(r => r.level === item.priority);
                const radius = ringIndex >= 0 ? (ringSizes[ringIndex] / 2) - 50 : 200;
                const samepriorityItems = placedItems.filter(i => i.priority === item.priority && !i.id.startsWith('template-'));
                const idx = samepriorityItems.indexOf(item);
                const angle = (idx / Math.max(samepriorityItems.length, 1)) * 2 * Math.PI - Math.PI / 2;
                position = {
                  x: RADAR_CENTER + Math.cos(angle) * radius,
                  y: RADAR_CENTER + Math.sin(angle) * radius,
                };
              }

              return (
                <PlacedRadarChip
                  key={item.id}
                  item={item}
                  position={position}
                  onMove={(newPos) => handleMoveItem(item.id, newPos)}
                  onRemove={() => handleRemoveFromRadar(item.id)}
                  zoom={zoom}
                />
              );
            })}
          </div>
        </div>
      </div>

      {/* Right: Use Cases Palette */}
      <div className="w-96 border-l border-border bg-card/50 flex flex-col">
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold">Use Cases</h2>
            <Button variant="outline" size="sm" onClick={() => setShowAddDialog(true)}>
              <Plus className="w-4 h-4 mr-1" />
              Add
            </Button>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search use cases..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>

          {/* Legend */}
          <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
            <div className="flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-green-500" />
              <span>Linked</span>
            </div>
            <div className="flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-500" />
              <span>Discovered</span>
            </div>
            <div className="flex items-center gap-1">
              <Circle className="w-3 h-3" />
              <span>Template</span>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-4 space-y-2">
          {filteredUseCasesByArea.map(([area, useCases]) => {
            const discoveredCount = useCases.filter(uc => uc.source === 'discovered').length;
            const whitespaceCount = useCases.filter(uc => uc.source === 'whitespace').length;
            const color = AREA_COLORS[area] || AREA_COLORS['Other'];

            return (
              <Collapsible 
                key={area} 
                open={expandedAreas[area] ?? false} 
                onOpenChange={() => toggleAreaExpanded(area)}
              >
                <CollapsibleTrigger className="flex items-center justify-between w-full p-2 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-2">
                    <ChevronDown 
                      className={cn(
                        "w-4 h-4 transition-transform",
                        !expandedAreas[area] && "-rotate-90"
                      )} 
                    />
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: color }}
                    />
                    <span className="text-sm font-medium truncate max-w-[180px]">{area}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {discoveredCount > 0 && (
                      <Badge variant="secondary" className="text-[10px] px-1.5">
                        {discoveredCount}
                      </Badge>
                    )}
                    {whitespaceCount > 0 && (
                      <Badge variant="outline" className="text-[10px] px-1.5 text-muted-foreground">
                        +{whitespaceCount}
                      </Badge>
                    )}
                  </div>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-2 mt-2 ml-4">
                  {useCases.map(useCase => (
                    <UseCaseChip 
                      key={useCase.id} 
                      useCase={useCase}
                      onOpenLinkDialog={handleOpenLinkDialog}
                    />
                  ))}
                </CollapsibleContent>
              </Collapsible>
            );
          })}

          {filteredUseCasesByArea.length === 0 && (
            <div className="text-center py-8">
              <ListTree className="w-12 h-12 text-muted-foreground/50 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">
                {searchQuery ? 'No matching use cases' : 'No use cases defined yet'}
              </p>
            </div>
          )}
        </div>

        {/* Priority Legend */}
        <div className="p-4 border-t border-border">
          <h3 className="text-xs font-medium uppercase tracking-wider mb-3 text-muted-foreground">
            Priority Legend
          </h3>
          <div className="grid grid-cols-2 gap-2">
            {priorityRings.map(ring => (
              <div key={ring.level} className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: priorityHexColors[ring.level] }}
                />
                <span className="text-xs font-medium">{ring.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Add Use Case Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Use Case</DialogTitle>
            <DialogDescription>
              Manually add a new use case to track for this account.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Use Case Name</Label>
              <Input
                placeholder="e.g., Feature Adoption Tracking"
                value={newUseCaseName}
                onChange={(e) => setNewUseCaseName(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label>Functional Area</Label>
              <Select value={newUseCaseArea} onValueChange={setNewUseCaseArea}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a functional area" />
                </SelectTrigger>
                <SelectContent>
                  {functionalAreas.map(area => (
                    <SelectItem key={area.id} value={area.name}>
                      {area.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Description (optional)</Label>
              <Textarea
                placeholder="Describe the use case..."
                value={newUseCaseDescription}
                onChange={(e) => setNewUseCaseDescription(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddManualUseCase}
              disabled={!newUseCaseName.trim() || !newUseCaseArea}
            >
              Add Use Case
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Link Use Case Dialog - for hybrid auto-match */}
      <Dialog open={showLinkDialog} onOpenChange={setShowLinkDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Link to Template</DialogTitle>
            <DialogDescription>
              Link this discovered use case to a template for better organization.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            {linkingUseCase && (
              <div className="mb-4 p-3 rounded-lg bg-muted">
                <p className="text-sm font-medium">{linkingUseCase.name}</p>
                <p className="text-xs text-muted-foreground">{linkingUseCase.functionalArea}</p>
              </div>
            )}
            
            <div className="space-y-2">
              <Label>Suggested Matches</Label>
              <div className="space-y-2 max-h-60 overflow-auto">
                {useCaseTemplates
                  .filter(t => {
                    if (!linkingUseCase) return false;
                    const area = functionalAreas.find(fa => fa.id === t.functional_area_id);
                    return area?.name === linkingUseCase.functionalArea;
                  })
                  .map(template => (
                    <button
                      key={template.id}
                      className="w-full p-3 text-left rounded-lg border hover:bg-muted/50 transition-colors"
                      onClick={() => {
                        // In a full implementation, this would update the use case with a linked_template_id
                        toast.success(`Linked to "${template.name}"`);
                        setShowLinkDialog(false);
                        setLinkingUseCase(null);
                      }}
                    >
                      <p className="text-sm font-medium">{template.name}</p>
                      {template.description && (
                        <p className="text-xs text-muted-foreground mt-1">{template.description}</p>
                      )}
                    </button>
                  ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowLinkDialog(false);
              setLinkingUseCase(null);
            }}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

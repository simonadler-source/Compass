import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { gateway } from "@/lib/apiGateway";
import { cn } from "@/lib/utils";
import { directImportMomentumMeetingById } from "@/features/momentum/import/importMomentumMeeting";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import {
  RefreshCw,
  Loader2,
  Clock,
  CheckCircle,
  AlertCircle,
  FileText,
  Calendar,
  Building2,
  Sparkles,
  RotateCcw,
  Play,
  Trash2,
  XCircle,
  SkipForward,
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { useProcessingQueue, QueuedMeeting, TranscriptQueueItem as TranscriptQueueItemType } from "@/hooks/useProcessingQueue";

export default function ProcessingQueueTab() {
  const queryClient = useQueryClient();
  const { queuedMeetings, pendingTranscripts, stats, isLoading, refetch } = useProcessingQueue();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedMeetingIds, setSelectedMeetingIds] = useState<Set<string>>(new Set());
  const [selectedTranscriptIds, setSelectedTranscriptIds] = useState<Set<string>>(new Set());

  // Toggle meeting selection
  const toggleMeeting = (id: string) => {
    setSelectedMeetingIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleAllMeetings = () => {
    if (selectedMeetingIds.size === queuedMeetings.length) {
      setSelectedMeetingIds(new Set());
    } else {
      setSelectedMeetingIds(new Set(queuedMeetings.map(m => m.id)));
    }
  };

  const toggleTranscript = (id: string) => {
    setSelectedTranscriptIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleAllTranscripts = () => {
    if (selectedTranscriptIds.size === pendingTranscripts.length) {
      setSelectedTranscriptIds(new Set());
    } else {
      setSelectedTranscriptIds(new Set(pendingTranscripts.map(t => t.id)));
    }
  };

  // Trigger sync-momentum to process queued meetings
  const syncMutation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke('sync-momentum', {
        body: {},
      });
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      toast.success(`Sync complete: ${data.newMeetings || 0} new, ${data.autoImportQueued || 0} queued for import`);
      refetch();
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
    },
    onError: (error) => {
      toast.error(`Sync failed: ${error.message}`);
    },
  });

  // Trigger enrichment for pending transcripts
  const enrichMutation = useMutation({
    mutationFn: async (transcriptId: string) => {
      const { data, error } = await supabase.functions.invoke('enrich-transcript', {
        body: { transcriptReviewId: transcriptId },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success('Enrichment started');
      refetch();
    },
    onError: (error) => {
      toast.error(`Enrichment failed: ${error.message}`);
    },
  });

  // Bulk enrich selected transcripts
  const bulkEnrichMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      let successCount = 0;
      let failCount = 0;
      for (const id of ids) {
        try {
          const { error } = await supabase.functions.invoke('enrich-transcript', {
            body: { transcriptReviewId: id },
          });
          if (error) throw error;
          successCount++;
        } catch {
          failCount++;
        }
      }
      return { successCount, failCount };
    },
    onSuccess: ({ successCount, failCount }) => {
      toast.success(`Enrichment started for ${successCount} transcript(s)${failCount > 0 ? `, ${failCount} failed` : ''}`);
      setSelectedTranscriptIds(new Set());
      refetch();
    },
  });

  // Clear selected transcripts from enrichment queue (mark as skipped)
  const clearTranscriptsMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      // Mark enrichment_status as 'skipped' so they don't show up and aren't retried
      const { error } = await gateway
        .from('transcript_reviews')
        .update({ enrichment_status: 'skipped' } as any)
        .in('id', ids)
        .execute();
      if (error) throw error;
      return ids.length;
    },
    onSuccess: (count) => {
      toast.success(`Cleared ${count} transcript(s) from enrichment queue`);
      setSelectedTranscriptIds(new Set());
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Clear failed: ${error.message}`);
    },
  });

  // Process (import) selected meetings
  const processSelectedMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      let successCount = 0;
      let failCount = 0;
      for (const id of ids) {
        try {
          await directImportMomentumMeetingById(id);
          successCount++;
        } catch {
          failCount++;
        }
      }
      return { successCount, failCount };
    },
    onSuccess: ({ successCount, failCount }) => {
      toast.success(`Imported ${successCount} meeting(s)${failCount > 0 ? `, ${failCount} failed` : ''}`);
      setSelectedMeetingIds(new Set());
      refetch();
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
    },
    onError: (error) => {
      toast.error(`Import failed: ${error.message}`);
    },
  });

  // Clear selected meetings from queue (set status back to 'pending')
  const clearMeetingsMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      const { error } = await gateway
        .from('momentum_meetings')
        .update({ status: 'pending' })
        .in('id', ids)
        .execute();
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(`Cleared ${selectedMeetingIds.size} meeting(s) from queue`);
      setSelectedMeetingIds(new Set());
      refetch();
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
    },
    onError: (error) => {
      toast.error(`Clear failed: ${error.message}`);
    },
  });

  // Reset stuck processing meetings
  const resetStuckMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from('momentum_meetings')
        .update({ status: 'queued' })
        .eq('status', 'processing');
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Reset stuck meetings to queued');
      refetch();
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings'] });
    },
    onError: (error) => {
      toast.error(`Reset failed: ${error.message}`);
    },
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };

  const totalQueueSize = stats.meetingsQueued + stats.meetingsProcessing;
  const progressPercent = totalQueueSize > 0 
    ? Math.round((stats.meetingsProcessing / totalQueueSize) * 100) 
    : 0;

  return (
    <div className="space-y-6">
      {/* Pending backlog banner */}
      {stats.meetingsPending > 0 && (
        <div className="flex items-start gap-3 rounded-lg border border-amber-500/30 bg-amber-500/5 px-4 py-3 text-sm">
          <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
          <div>
            <span className="font-medium text-amber-600 dark:text-amber-400">
              {stats.meetingsPending.toLocaleString()} meetings in discovery backlog
            </span>
            <span className="text-muted-foreground ml-1">
              — discovered but awaiting import. The cron processes 20 per run; this resolves automatically over time.
            </span>
          </div>
        </div>
      )}

      {/* Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="border-border/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/10">
                <Clock className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.meetingsPending > 0 ? stats.meetingsPending : stats.meetingsQueued}</p>
                <p className="text-sm text-muted-foreground">{stats.meetingsPending > 0 ? 'Pending Discovery' : 'Meetings Queued'}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Clock className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.meetingsQueued}</p>
                <p className="text-sm text-muted-foreground">Queued for Import</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <Loader2 className={cn("h-5 w-5 text-amber-500", stats.meetingsProcessing > 0 && "animate-spin")} />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.meetingsProcessing}</p>
                <p className="text-sm text-muted-foreground">Processing Now</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <FileText className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.transcriptsTotalStuck}</p>
                <p className="text-sm text-muted-foreground">Awaiting Enrichment</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <Loader2 className={cn("h-5 w-5 text-green-500", stats.transcriptsInProgress > 0 && "animate-spin")} />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.transcriptsInProgress}</p>
                <p className="text-sm text-muted-foreground">Enriching Now</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3">
        <Button
          onClick={handleRefresh}
          variant="outline"
          disabled={isRefreshing}
        >
          <RefreshCw className={cn("h-4 w-4 mr-2", isRefreshing && "animate-spin")} />
          Refresh
        </Button>

        <Button
          onClick={() => syncMutation.mutate()}
          disabled={syncMutation.isPending}
        >
          {syncMutation.isPending ? (
            <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Syncing...</>
          ) : (
            <><Play className="h-4 w-4 mr-2" />Run Sync Now</>
          )}
        </Button>

        {stats.meetingsProcessing > 0 && (
          <Button
            onClick={() => resetStuckMutation.mutate()}
            variant="destructive"
            disabled={resetStuckMutation.isPending}
          >
            {resetStuckMutation.isPending ? (
              <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Resetting...</>
            ) : (
              <><RotateCcw className="h-4 w-4 mr-2" />Reset Stuck ({stats.meetingsProcessing})</>
            )}
          </Button>
        )}
      </div>

      {/* Progress Bar */}
      {totalQueueSize > 0 && (
        <Card className="border-border/50">
          <CardContent className="pt-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Import Progress</span>
                <span className="font-medium">{stats.meetingsProcessing} / {totalQueueSize}</span>
              </div>
              <Progress value={progressPercent} className="h-2" />
            </div>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Meetings Queue */}
          <Card className="border-border/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Meeting Import Queue
                  {queuedMeetings.length > 0 && (
                    <Badge variant="secondary">{queuedMeetings.length}</Badge>
                  )}
                </CardTitle>
                {queuedMeetings.length > 0 && (
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={toggleAllMeetings}
                      className="text-xs h-7"
                    >
                      {selectedMeetingIds.size === queuedMeetings.length ? 'Deselect All' : 'Select All'}
                    </Button>
                  </div>
                )}
              </div>
              {selectedMeetingIds.size > 0 && (
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-sm text-muted-foreground">{selectedMeetingIds.size} selected</span>
                  <Button
                    size="sm"
                    onClick={() => processSelectedMutation.mutate(Array.from(selectedMeetingIds))}
                    disabled={processSelectedMutation.isPending || clearMeetingsMutation.isPending}
                    className="h-7 text-xs"
                  >
                    {processSelectedMutation.isPending ? (
                      <><Loader2 className="h-3 w-3 mr-1 animate-spin" />Importing...</>
                    ) : (
                      <><Play className="h-3 w-3 mr-1" />Process Selected</>
                    )}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => clearMeetingsMutation.mutate(Array.from(selectedMeetingIds))}
                    disabled={clearMeetingsMutation.isPending || processSelectedMutation.isPending}
                    className="h-7 text-xs"
                  >
                    {clearMeetingsMutation.isPending ? (
                      <><Loader2 className="h-3 w-3 mr-1 animate-spin" />Clearing...</>
                    ) : (
                      <><XCircle className="h-3 w-3 mr-1" />Clear from Queue</>
                    )}
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent>
              {queuedMeetings.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No meetings in queue</p>
                  <p className="text-sm mt-1">All meetings have been processed</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {queuedMeetings.slice(0, 50).map((meeting) => (
                    <MeetingQueueItem
                      key={meeting.id}
                      meeting={meeting}
                      selected={selectedMeetingIds.has(meeting.id)}
                      onToggle={() => toggleMeeting(meeting.id)}
                    />
                  ))}
                  {queuedMeetings.length > 50 && (
                    <p className="text-center text-sm text-muted-foreground py-2">
                      +{queuedMeetings.length - 50} more in queue
                    </p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Transcripts Queue */}
          <Card className="border-border/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  Enrichment Queue
                  {pendingTranscripts.length > 0 && (
                    <Badge variant="secondary">
                      {pendingTranscripts.length}
                      {stats.transcriptsTotalStuck > pendingTranscripts.length && (
                        <span className="ml-1 opacity-70">/ {stats.transcriptsTotalStuck} total</span>
                      )}
                    </Badge>
                  )}
                </CardTitle>
                {pendingTranscripts.length > 0 && (
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={toggleAllTranscripts}
                      className="text-xs h-7"
                    >
                      {selectedTranscriptIds.size === pendingTranscripts.length ? 'Deselect All' : 'Select All'}
                    </Button>
                  </div>
                )}
              </div>
              {selectedTranscriptIds.size > 0 && (
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-sm text-muted-foreground">{selectedTranscriptIds.size} selected</span>
                  <Button
                    size="sm"
                    onClick={() => bulkEnrichMutation.mutate(Array.from(selectedTranscriptIds))}
                    disabled={bulkEnrichMutation.isPending || clearTranscriptsMutation.isPending}
                    className="h-7 text-xs"
                  >
                    {bulkEnrichMutation.isPending ? (
                      <><Loader2 className="h-3 w-3 mr-1 animate-spin" />Enriching...</>
                    ) : (
                      <><Sparkles className="h-3 w-3 mr-1" />Enrich Selected</>
                    )}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => clearTranscriptsMutation.mutate(Array.from(selectedTranscriptIds))}
                    disabled={clearTranscriptsMutation.isPending || bulkEnrichMutation.isPending}
                    className="h-7 text-xs"
                  >
                    {clearTranscriptsMutation.isPending ? (
                      <><Loader2 className="h-3 w-3 mr-1 animate-spin" />Clearing...</>
                    ) : (
                      <><SkipForward className="h-3 w-3 mr-1" />Skip Selected</>
                    )}
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent>
              {pendingTranscripts.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No transcripts pending enrichment</p>
                  <p className="text-sm mt-1">All transcripts have been analyzed</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {pendingTranscripts.slice(0, 100).map((transcript) => (
                    <TranscriptQueueCard 
                      key={transcript.id} 
                      transcript={transcript}
                      selected={selectedTranscriptIds.has(transcript.id)}
                      onToggle={() => toggleTranscript(transcript.id)}
                      onEnrich={() => enrichMutation.mutate(transcript.id)}
                      isEnriching={enrichMutation.isPending}
                    />
                  ))}
                  {pendingTranscripts.length > 100 && (
                    <p className="text-center text-sm text-muted-foreground py-2">
                      +{pendingTranscripts.length - 100} more pending
                    </p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

function MeetingQueueItem({ meeting, selected, onToggle }: { meeting: QueuedMeeting; selected: boolean; onToggle: () => void }) {
  const isProcessing = meeting.status === 'processing';
  
  return (
    <div className={cn(
      "flex items-center gap-3 p-3 rounded-lg border transition-all",
      selected ? "bg-primary/5 border-primary/30" : isProcessing ? "bg-amber-500/5 border-amber-500/30" : "bg-background/50 border-border/50"
    )}>
      <Checkbox checked={selected} onCheckedChange={onToggle} className="shrink-0" />
      {isProcessing ? (
        <Loader2 className="h-4 w-4 animate-spin text-amber-500 shrink-0" />
      ) : (
        <Clock className="h-4 w-4 text-blue-500 shrink-0" />
      )}
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{meeting.title || 'Untitled Meeting'}</p>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
          <Calendar className="h-3 w-3" />
          <span>{format(new Date(meeting.start_time), 'MMM d, h:mm a')}</span>
          {meeting.host_name && (
            <span className="truncate">• {meeting.host_name}</span>
          )}
        </div>
      </div>
      <Badge variant={isProcessing ? "default" : "outline"} className="text-xs shrink-0">
        {isProcessing ? 'Processing' : 'Queued'}
      </Badge>
    </div>
  );
}

function TranscriptQueueCard({ 
  transcript,
  selected,
  onToggle,
  onEnrich,
  isEnriching 
}: { 
  transcript: TranscriptQueueItemType;
  selected: boolean;
  onToggle: () => void;
  onEnrich: () => void;
  isEnriching: boolean;
}) {
  const displayName = transcript.meeting_title || transcript.file_name || transcript.id.slice(0, 8);
  const isInProgress = transcript.enrichment_status === 'in_progress';
  
  return (
    <div className={cn(
      "flex items-center gap-3 p-3 rounded-lg border transition-all",
      selected ? "bg-primary/5 border-primary/30" : isInProgress ? "bg-amber-500/5 border-amber-500/30" : "bg-background/50 border-border/50"
    )}>
      <Checkbox checked={selected} onCheckedChange={onToggle} className="shrink-0" />
      {isInProgress ? (
        <Loader2 className="h-4 w-4 animate-spin text-amber-500 shrink-0" />
      ) : (
        <FileText className="h-4 w-4 text-purple-500 shrink-0" />
      )}
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{displayName}</p>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
          <Calendar className="h-3 w-3" />
          <span>{format(new Date(transcript.meeting_start_time || transcript.created_at), 'MMM d, h:mm a')}</span>
          {transcript.opportunity_id ? (
            <Badge variant="outline" className="text-[10px] h-4 px-1">Linked</Badge>
          ) : (
            <Badge variant="secondary" className="text-[10px] h-4 px-1 opacity-60">No Opp</Badge>
          )}
        </div>
      </div>
      <Button
        size="sm"
        variant="ghost"
        onClick={onEnrich}
        disabled={isEnriching}
        className="shrink-0"
      >
        {isEnriching ? (
          <Loader2 className="h-3 w-3 animate-spin" />
        ) : (
          <Sparkles className="h-3 w-3" />
        )}
      </Button>
    </div>
  );
}

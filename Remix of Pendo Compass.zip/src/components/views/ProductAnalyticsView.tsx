import { useState, useMemo } from 'react';
import { format, subDays, subMonths, differenceInDays } from 'date-fns';
import { Calendar as CalendarIcon, TrendingUp, Package, Swords, Info, ChevronDown, ExternalLink, FileText, ChevronRight, Target, Users, MessageSquare, Clock, EyeOff, Undo2, Building2, Eye } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { 
  useProductMentionStats, 
  useProductMentionTrends, 
  useTopProductMentions,
  useSuppressedProductMentions,
  useSuppressProductMention,
  useUnsuppressProductMention,
  usePreviousPeriodStats,
  useSelectedProductTrends,
  useCallVolumeTrends,
  groupTrendsByPeriod,
  groupSingleProductTrends,
  autoGrouping,
  type DateRange,
  type PeriodGrouping,
  type MentionTrend,
} from '@/hooks/useProductMentions';
import {
  usePendoProductDetectionStats,
  usePendoProductRecentMatches,
  usePendoProductDetectionSummary,
} from '@/hooks/usePendoProductDetection';
import { useDealCycleBleedData } from '@/hooks/useDealCycleBleedData';
import { DealCycleBleedPlot } from '@/components/product-analytics/DealCycleBleedPlot';
import { ProductDistributionPies } from '@/components/product-analytics/ProductDistributionPies';
import { PeriodChangeIndicator } from '@/components/product-analytics/PeriodChangeIndicator';
import { SentimentDetailPanel } from '@/components/product-analytics/SentimentDetailPanel';
import { ProductDetailPanel } from '@/components/product-analytics/ProductDetailPanel';
import { PieChartTooltip } from '@/components/product-analytics/PieChartTooltip';
import { 
  LineChart, 
  ComposedChart,
  Line, 
  Area,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { cn } from '@/lib/utils';

const PRESET_RANGES = [
  { label: 'Last 7 days', days: 7 },
  { label: 'Last 30 days', days: 30 },
  { label: 'Last 90 days', days: 90 },
  { label: 'Last 6 months', months: 6 },
  { label: 'Last 12 months', months: 12 },
];

const SENTIMENT_COLORS = {
  positive: 'hsl(142 71% 45%)',
  neutral: 'hsl(var(--muted-foreground))',
  negative: 'hsl(var(--destructive))',
  mixed: 'hsl(45 93% 47%)',
};

const MENTION_TYPE_COLORS = {
  owned: 'hsl(var(--primary))',
  complementary: 'hsl(142 71% 45%)',
  competitive: 'hsl(var(--destructive))',
};

export function ProductAnalyticsView() {
  const [dateRange, setDateRange] = useState<DateRange>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });
  const [selectedPreset, setSelectedPreset] = useState('Last 30 days');
  const [periodGrouping, setPeriodGrouping] = useState<PeriodGrouping | 'auto'>('auto');
  const [sentimentPanelOpen, setSentimentPanelOpen] = useState(false);
  const [initialSentiment, setInitialSentiment] = useState('positive');
  const [productPanelOpen, setProductPanelOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState({ name: '', type: 'owned' as 'owned' | 'competitive' });
  const [highlightedProduct, setHighlightedProduct] = useState<string | null>(null);
  const [includeInternal, setIncludeInternal] = useState(false);

  const effectiveGrouping = periodGrouping === 'auto' ? autoGrouping(dateRange) : periodGrouping;
  
  // When includeInternal is false (default), filter to external only
  // When true, pass undefined to get all (combined)
  const meetingContextFilter = includeInternal ? undefined : 'external';

  const { data: stats, isLoading: statsLoading } = useProductMentionStats(dateRange, meetingContextFilter);
  const { data: trends, isLoading: trendsLoading } = useProductMentionTrends(dateRange, meetingContextFilter);
  const { data: recentMentions, isLoading: mentionsLoading } = useTopProductMentions(dateRange, undefined, 20);
  const { data: prevPeriod } = usePreviousPeriodStats(dateRange, meetingContextFilter);
  
  // Pendo Product Detection data
  const { data: pendoDetectionStats, isLoading: pendoStatsLoading } = usePendoProductDetectionStats(dateRange);
  const { data: pendoRecentMatches, isLoading: pendoMatchesLoading } = usePendoProductRecentMatches(dateRange, 20);
  const { data: pendoSummary } = usePendoProductDetectionSummary(dateRange);
  
  // Deal cycle bleed data
  const { data: bleedData, isLoading: bleedLoading } = useDealCycleBleedData(dateRange);
  
  // Product mention suppression
  const { data: suppressedMentions } = useSuppressedProductMentions();
  const suppressMutation = useSuppressProductMention();
  const unsuppressMutation = useUnsuppressProductMention();

  // Per-product trend overlay
  const { data: selectedProductTrends } = useSelectedProductTrends(highlightedProduct, dateRange);

  // Call volume backdrop
  const { data: callVolume } = useCallVolumeTrends(dateRange, meetingContextFilter);

  const handlePresetChange = (preset: string) => {
    setSelectedPreset(preset);
    const presetConfig = PRESET_RANGES.find(p => p.label === preset);
    if (presetConfig) {
      const to = new Date();
      let from: Date;
      if (presetConfig.days) {
        from = subDays(to, presetConfig.days);
      } else if (presetConfig.months) {
        from = subMonths(to, presetConfig.months);
      } else {
        from = subDays(to, 30);
      }
      setDateRange({ from, to });
    }
  };

  // Aggregate stats by type
  const aggregatedStats = useMemo(() => {
    if (!stats) return { owned: [], complementary: [], competitive: [] };
    return {
      owned: stats.filter(s => s.mention_type === 'owned'),
      complementary: stats.filter(s => s.mention_type === 'complementary'),
      competitive: stats.filter(s => s.mention_type === 'competitive'),
    };
  }, [stats]);

  // Summary counts
  const summaryCounts = useMemo(() => {
    if (!stats) return { owned: 0, complementary: 0, competitive: 0, total: 0 };
    const owned = stats.filter(s => s.mention_type === 'owned').reduce((sum, s) => sum + s.total_mentions, 0);
    const complementary = stats.filter(s => s.mention_type === 'complementary').reduce((sum, s) => sum + s.total_mentions, 0);
    const competitive = stats.filter(s => s.mention_type === 'competitive').reduce((sum, s) => sum + s.total_mentions, 0);
    return { owned, complementary, competitive, total: owned + complementary + competitive };
  }, [stats]);

  // Grouped trend data — merge call volume + per-product overlay
  const groupedTrends = useMemo(() => {
    // Build a union of all dates from trends AND call volume
    const trendMap = new Map<string, MentionTrend>();
    (trends || []).forEach(t => trendMap.set(t.date, t));

    const callMap = new Map((callVolume || []).map(c => [c.date, c.count]));

    // Union all dates from both sources
    const allDates = new Set([...trendMap.keys(), ...callMap.keys()]);
    const trendsWithCalls: MentionTrend[] = Array.from(allDates).sort().map(date => {
      const t = trendMap.get(date);
      return {
        date,
        owned: t?.owned || 0,
        competitive: t?.competitive || 0,
        complementary: t?.complementary || 0,
        total: t?.total || 0,
        calls: callMap.get(date) || 0,
      };
    });
    
    const base = groupTrendsByPeriod(trendsWithCalls, effectiveGrouping);
    if (!highlightedProduct || !selectedProductTrends?.length) return base;

    const grouped = groupSingleProductTrends(selectedProductTrends, effectiveGrouping);
    const productMap = new Map(grouped.map(d => [d.date, d.count]));

    return base.map(t => ({
      ...t,
      selectedProduct: productMap.get(t.date) || 0,
    }));
  }, [trends, effectiveGrouping, highlightedProduct, selectedProductTrends, callVolume]);

  // Sentiment distribution for pie
  const sentimentData = useMemo(() => {
    if (!stats) return [];
    let positive = 0, neutral = 0, negative = 0, mixed = 0;
    stats.forEach(s => {
      positive += s.positive_count;
      neutral += s.neutral_count;
      negative += s.negative_count;
      mixed += s.mixed_count;
    });
    return [
      { name: 'Positive', value: positive, fill: SENTIMENT_COLORS.positive },
      { name: 'Neutral', value: neutral, fill: SENTIMENT_COLORS.neutral },
      { name: 'Negative', value: negative, fill: SENTIMENT_COLORS.negative },
      { name: 'Mixed', value: mixed, fill: SENTIMENT_COLORS.mixed },
    ].filter(d => d.value > 0);
  }, [stats]);

  const handleProductClick = (productName: string, mentionType: 'owned' | 'competitive') => {
    setSelectedProduct({ name: productName, type: mentionType });
    setHighlightedProduct(productName);
    setProductPanelOpen(true);
  };

  const handleSentimentClick = (data: any) => {
    if (data?.name) {
      setInitialSentiment(data.name.toLowerCase());
      setSentimentPanelOpen(true);
    }
  };

  // Trend tick formatter based on grouping
  const trendTickFormatter = (value: string) => {
    const d = new Date(value);
    if (effectiveGrouping === 'monthly') return format(d, 'MMM yyyy');
    if (effectiveGrouping === 'weekly') return format(d, 'MMM d');
    return format(d, 'MMM d');
  };

  const trendLabelFormatter = (value: string) => {
    const d = new Date(value);
    if (effectiveGrouping === 'monthly') return format(d, 'MMMM yyyy');
    if (effectiveGrouping === 'weekly') return `Week of ${format(d, 'MMM d, yyyy')}`;
    return format(d, 'MMM d, yyyy');
  };

  const isLoading = statsLoading || trendsLoading || mentionsLoading;

  return (
    <div className="p-6 space-y-6">
      {/* Header + Filters */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold">Product Analytics</h1>
          <p className="text-muted-foreground mt-1">
            Understand how products are mentioned in customer conversations
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Period Grouping */}
          <ToggleGroup
            type="single"
            value={periodGrouping}
            onValueChange={(v) => { if (v) setPeriodGrouping(v as PeriodGrouping | 'auto'); }}
            className="bg-muted rounded-md p-0.5"
          >
            <ToggleGroupItem value="auto" className="text-xs h-7 px-2.5 data-[state=on]:bg-background">
              Auto
            </ToggleGroupItem>
            <ToggleGroupItem value="daily" className="text-xs h-7 px-2.5 data-[state=on]:bg-background">
              Daily
            </ToggleGroupItem>
            <ToggleGroupItem value="weekly" className="text-xs h-7 px-2.5 data-[state=on]:bg-background">
              Weekly
            </ToggleGroupItem>
            <ToggleGroupItem value="monthly" className="text-xs h-7 px-2.5 data-[state=on]:bg-background">
              Monthly
            </ToggleGroupItem>
          </ToggleGroup>

          {/* Internal/External filter */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant={includeInternal ? 'default' : 'outline'}
                size="sm"
                className="gap-1.5 text-xs h-8"
                onClick={() => setIncludeInternal(!includeInternal)}
              >
                <Building2 className="h-3.5 w-3.5" />
                {includeInternal ? 'All Sources' : 'External Only'}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs">{includeInternal ? 'Showing external + internal calls' : 'Click to include internal calls (win/loss, strategy, debriefs)'}</p>
            </TooltipContent>
          </Tooltip>

          {/* Preset Range */}
          <Select value={selectedPreset} onValueChange={handlePresetChange}>
            <SelectTrigger className="w-[160px] h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PRESET_RANGES.map((preset) => (
                <SelectItem key={preset.label} value={preset.label}>
                  {preset.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Custom Date Range */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2 text-xs h-8">
                <CalendarIcon className="h-3.5 w-3.5" />
                {format(dateRange.from, 'MMM d')} – {format(dateRange.to, 'MMM d, yyyy')}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                mode="range"
                selected={{ from: dateRange.from, to: dateRange.to }}
                onSelect={(range) => {
                  if (range?.from) {
                    setDateRange({ 
                      from: range.from, 
                      to: range.to || range.from 
                    });
                    if (range.to) {
                      setSelectedPreset('');
                    }
                  }
                }}
                numberOfMonths={2}
                className="pointer-events-auto"
              />
            </PopoverContent>
          </Popover>
        </div>
      </div>

      {/* Summary Cards with period-over-period change */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Total Mentions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between">
              <div className="text-3xl font-bold">{summaryCounts.total}</div>
              {prevPeriod && (
                <PeriodChangeIndicator current={summaryCounts.total} previous={prevPeriod.total} />
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Pendo products & competitors
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2" style={{ color: MENTION_TYPE_COLORS.owned }}>
              <Package className="h-4 w-4" />
              Pendo Products
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between">
              <div className="text-3xl font-bold">{summaryCounts.owned}</div>
              {prevPeriod && (
                <PeriodChangeIndicator current={summaryCounts.owned} previous={prevPeriod.owned} />
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {aggregatedStats.owned.length} unique products
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2" style={{ color: MENTION_TYPE_COLORS.competitive }}>
              <Swords className="h-4 w-4" />
              Competitive
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between">
              <div className="text-3xl font-bold">{summaryCounts.competitive}</div>
              {prevPeriod && (
                <PeriodChangeIndicator current={summaryCounts.competitive} previous={prevPeriod.competitive} />
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {aggregatedStats.competitive.length} competitors mentioned
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Full-width Mention Trends */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="flex items-center gap-2">
              Mention Trends
              {highlightedProduct && (
                <Badge variant="secondary" className="text-xs font-normal gap-1">
                  {highlightedProduct}
                  <button
                    onClick={() => setHighlightedProduct(null)}
                    className="ml-1 hover:text-foreground"
                  >
                    ×
                  </button>
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              Product mentions over time ({effectiveGrouping} view)
            </CardDescription>
          </div>
          <Badge variant="outline" className="text-xs capitalize">
            {effectiveGrouping}
          </Badge>
        </CardHeader>
        <CardContent>
          {trendsLoading ? (
            <div className="h-[300px] flex items-center justify-center">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
            </div>
          ) : groupedTrends.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <ComposedChart data={groupedTrends}>
                <defs>
                  <linearGradient id="callVolumeGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={trendTickFormatter}
                  className="text-xs"
                  interval="preserveStartEnd"
                />
                <YAxis yAxisId="left" className="text-xs" />
                <YAxis yAxisId="right" orientation="right" className="text-xs" tickFormatter={(v: number) => `${v}`} />
                <RechartsTooltip 
                  labelFormatter={trendLabelFormatter}
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--popover))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Area
                  yAxisId="right"
                  type="monotone"
                  dataKey="calls"
                  name="Calls"
                  fill="url(#callVolumeGradient)"
                  stroke="hsl(var(--muted-foreground))"
                  strokeWidth={1}
                  strokeOpacity={0.4}
                  dot={false}
                />
                <Line 
                  yAxisId="left"
                  type="monotone" 
                  dataKey="owned" 
                  name="Pendo Products"
                  stroke={MENTION_TYPE_COLORS.owned} 
                  strokeWidth={2}
                  dot={effectiveGrouping !== 'daily'}
                />
                <Line 
                  yAxisId="left"
                  type="monotone" 
                  dataKey="competitive" 
                  name="Competitive"
                  stroke={MENTION_TYPE_COLORS.competitive} 
                  strokeWidth={2}
                  dot={effectiveGrouping !== 'daily'}
                />
                {highlightedProduct && (
                  <Line 
                    yAxisId="left"
                    type="monotone" 
                    dataKey="selectedProduct" 
                    name={highlightedProduct}
                    stroke="hsl(280 70% 55%)" 
                    strokeWidth={2.5}
                    strokeDasharray="5 3"
                    dot={effectiveGrouping !== 'daily'}
                  />
                )}
              </ComposedChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No mention data available for this period</p>
                <p className="text-sm mt-1">Product mentions are extracted when transcripts are analyzed</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Distribution Row: Pendo Pie | Competitor Pie | Sentiment */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <ProductDistributionPies stats={stats || []} isLoading={statsLoading} onProductClick={handleProductClick} />

        {/* Sentiment Distribution */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Sentiment Distribution
            </CardTitle>
            <CardDescription className="text-xs">Click a segment for conversation excerpts</CardDescription>
          </CardHeader>
          <CardContent>
            {statsLoading ? (
              <div className="h-[260px] flex items-center justify-center">
                <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
              </div>
            ) : sentimentData.length > 0 ? (
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie
                    data={sentimentData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={80}
                    paddingAngle={2}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={{ strokeWidth: 1 }}
                    fontSize={10}
                    onClick={handleSentimentClick}
                    className="cursor-pointer"
                  >
                    {sentimentData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <RechartsTooltip 
                    content={<PieChartTooltip total={sentimentData.reduce((s, d) => s + d.value, 0)} />}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[260px] flex items-center justify-center text-muted-foreground">
                No sentiment data
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tabs */}
      <Tabs defaultValue="trends" className="space-y-4">
        <TabsList className="flex-wrap">
          <TabsTrigger value="trends" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            Trends
          </TabsTrigger>
          <TabsTrigger value="product-coverage" className="gap-2">
            <Target className="h-4 w-4" />
            Product Coverage ({pendoSummary?.productsWithMentions || 0}/{pendoSummary?.totalProducts || 0})
          </TabsTrigger>
          <TabsTrigger value="recent-detections" className="gap-2">
            <Clock className="h-4 w-4" />
            Recent Detections
          </TabsTrigger>
          <TabsTrigger value="by-person" className="gap-2">
            <Users className="h-4 w-4" />
            Deal Cycle Bleed
          </TabsTrigger>
        </TabsList>

        <TabsContent value="trends">
          <div className="space-y-6">
            {/* Owned Products Table */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2" style={{ color: MENTION_TYPE_COLORS.owned }}>
                  <Package className="h-5 w-5" />
                  Pendo Products ({aggregatedStats.owned.length})
                </CardTitle>
                <CardDescription>Products in your portfolio mentioned in conversations</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <ProductTable products={aggregatedStats.owned} type="owned" onSuppress={(name) => suppressMutation.mutate({ productName: name, reason: 'Not a real product' })} onProductClick={handleProductClick} />
              </CardContent>
            </Card>

            {/* Competitive Products Table */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2" style={{ color: MENTION_TYPE_COLORS.competitive }}>
                  <Swords className="h-5 w-5" />
                  Competitive Products ({aggregatedStats.competitive.length})
                </CardTitle>
                <CardDescription>Competitor mentions detected in conversations</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <ProductTable products={aggregatedStats.competitive} type="competitive" onSuppress={(name) => suppressMutation.mutate({ productName: name, reason: 'Not a real product' })} onProductClick={handleProductClick} />
              </CardContent>
             </Card>

            {/* Hidden Products Section */}
            {suppressedMentions && suppressedMentions.length > 0 && (
              <Card className="border-dashed border-muted-foreground/30">
                <Collapsible>
                  <CollapsibleTrigger asChild>
                    <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
                      <div className="flex items-center gap-2">
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                        <CardTitle className="text-sm font-medium text-muted-foreground">
                          Hidden Products ({suppressedMentions.length})
                        </CardTitle>
                        <ChevronDown className="h-4 w-4 text-muted-foreground ml-auto" />
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent className="pt-0">
                      <div className="flex flex-wrap gap-2">
                        {suppressedMentions.map((item) => (
                          <Badge
                            key={item.id}
                            variant="outline"
                            className="gap-1.5 pr-1 text-muted-foreground"
                          >
                            {item.product_name}
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-4 w-4 p-0 hover:text-foreground"
                              onClick={() => unsuppressMutation.mutate(item.id)}
                            >
                              <Eye className="h-3 w-3" />
                            </Button>
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Collapsible>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="product-coverage">
          <PendoProductCoverageSection 
            stats={pendoDetectionStats || []} 
            recentMatches={pendoRecentMatches || []}
            summary={pendoSummary}
            isLoading={pendoStatsLoading || pendoMatchesLoading}
          />
        </TabsContent>

        <TabsContent value="recent-detections">
          <RecentMentionsTable mentions={recentMentions || []} />
        </TabsContent>

        <TabsContent value="by-person">
          <DealCycleBleedPlot 
            data={bleedData}
            isLoading={bleedLoading} 
          />
        </TabsContent>
      </Tabs>

      {/* Sentiment Detail Side Panel */}
      <SentimentDetailPanel
        open={sentimentPanelOpen}
        onOpenChange={setSentimentPanelOpen}
        dateRange={dateRange}
        initialSentiment={initialSentiment}
      />

      {/* Product Detail Side Panel */}
      <ProductDetailPanel
        open={productPanelOpen}
        onOpenChange={setProductPanelOpen}
        productName={selectedProduct.name}
        mentionType={selectedProduct.type}
        dateRange={dateRange}
      />
    </div>
  );
}

// ── Sub-components (kept in same file for co-location) ──────────────────

interface ProductTableProps {
  products: Array<{
    product_name: string;
    mention_type: string;
    total_mentions: number;
    avg_sentiment: number | null;
    positive_count: number;
    neutral_count: number;
    negative_count: number;
    mixed_count: number;
  }>;
  type: 'owned' | 'complementary' | 'competitive';
  onSuppress?: (productName: string) => void;
  onProductClick?: (productName: string, mentionType: 'owned' | 'competitive') => void;
}

function ProductTable({ products, type, onSuppress, onProductClick }: ProductTableProps) {
  if (products.length === 0) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="text-center text-muted-foreground">
            <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>No {type} products mentioned in this period</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <table className="w-full">
          <thead className="border-b bg-muted/50">
            <tr>
              <th className="text-left p-4 font-medium">Product</th>
              <th className="text-center p-4 font-medium">Mentions</th>
              <th className="text-center p-4 font-medium">Sentiment</th>
              <th className="text-right p-4 font-medium">Distribution</th>
              {onSuppress && <th className="w-12 p-4"></th>}
            </tr>
          </thead>
          <tbody>
            {products.map((product, idx) => {
              const totalSentiment = product.positive_count + product.neutral_count + product.negative_count + product.mixed_count;
              return (
                <tr key={idx} className="border-b last:border-0 hover:bg-muted/30 group cursor-pointer" onClick={() => onProductClick?.(product.product_name, type === 'complementary' ? 'owned' : type)}>
                  <td className="p-4">
                    <div className="font-medium">{product.product_name}</div>
                  </td>
                  <td className="p-4 text-center">
                    <Badge variant="secondary" className="font-mono">
                      {product.total_mentions}
                    </Badge>
                  </td>
                  <td className="p-4 text-center">
                    {product.avg_sentiment !== null ? (
                      <SentimentBadge score={product.avg_sentiment} />
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </td>
                  <td className="p-4">
                    <div className="flex items-center justify-end gap-1">
                      {product.positive_count > 0 && (
                        <Tooltip>
                          <TooltipTrigger>
                            <div 
                              className="h-2 rounded"
                              style={{ 
                                width: `${(product.positive_count / totalSentiment) * 100}px`,
                                backgroundColor: SENTIMENT_COLORS.positive,
                                minWidth: '8px'
                              }} 
                            />
                          </TooltipTrigger>
                          <TooltipContent>Positive: {product.positive_count}</TooltipContent>
                        </Tooltip>
                      )}
                      {product.neutral_count > 0 && (
                        <Tooltip>
                          <TooltipTrigger>
                            <div 
                              className="h-2 rounded"
                              style={{ 
                                width: `${(product.neutral_count / totalSentiment) * 100}px`,
                                backgroundColor: SENTIMENT_COLORS.neutral,
                                minWidth: '8px'
                              }} 
                            />
                          </TooltipTrigger>
                          <TooltipContent>Neutral: {product.neutral_count}</TooltipContent>
                        </Tooltip>
                      )}
                      {product.negative_count > 0 && (
                        <Tooltip>
                          <TooltipTrigger>
                            <div 
                              className="h-2 rounded"
                              style={{ 
                                width: `${(product.negative_count / totalSentiment) * 100}px`,
                                backgroundColor: SENTIMENT_COLORS.negative,
                                minWidth: '8px'
                              }} 
                            />
                          </TooltipTrigger>
                          <TooltipContent>Negative: {product.negative_count}</TooltipContent>
                        </Tooltip>
                      )}
                      {product.mixed_count > 0 && (
                        <Tooltip>
                          <TooltipTrigger>
                            <div 
                              className="h-2 rounded"
                              style={{ 
                                width: `${(product.mixed_count / totalSentiment) * 100}px`,
                                backgroundColor: SENTIMENT_COLORS.mixed,
                                minWidth: '8px'
                              }} 
                            />
                          </TooltipTrigger>
                          <TooltipContent>Mixed: {product.mixed_count}</TooltipContent>
                        </Tooltip>
                      )}
                    </div>
                  </td>
                  {onSuppress && (
                    <td className="p-2">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                            onClick={(e) => { e.stopPropagation(); onSuppress(product.product_name); }}
                          >
                            <EyeOff className="h-3.5 w-3.5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Hide from analytics</TooltipContent>
                      </Tooltip>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}

function SentimentBadge({ score }: { score: number }) {
  let label: string;
  let color: string;

  if (score >= 70) {
    label = 'Positive';
    color = 'bg-green-500/20 text-green-500 border-green-500/30';
  } else if (score >= 40) {
    label = 'Neutral';
    color = 'bg-muted text-muted-foreground';
  } else {
    label = 'Negative';
    color = 'bg-destructive/20 text-destructive border-destructive/30';
  }

  return (
    <Badge variant="outline" className={cn('font-normal', color)}>
      {label} ({Math.round(score)})
    </Badge>
  );
}

interface RecentMentionsTableProps {
  mentions: Array<{
    id: string;
    product_name: string;
    mention_type: string;
    context_snippet: string | null;
    sentiment_label: string | null;
    transcript_date: string | null;
    transcript_id: string;
    account_id: string | null;
    accounts: { name: string } | null;
    transcript_reviews: { id: string; meeting_title: string | null; final_account_id: string | null } | null;
  }>;
}

function RecentMentionsTable({ mentions }: RecentMentionsTableProps) {
  const navigate = useNavigate();
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  const toggleRow = (id: string) => {
    setExpandedRows(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleNavigateToTranscript = (mention: RecentMentionsTableProps['mentions'][0]) => {
    const accountId = mention.transcript_reviews?.final_account_id || mention.account_id;
    if (accountId) {
      navigate(`/accounts/${accountId}?tab=transcripts&transcript=${mention.transcript_id}`);
    }
  };

  if (mentions.length === 0) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="text-center text-muted-foreground">
            <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>No recent mentions found</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <table className="w-full">
          <thead className="border-b bg-muted/50">
            <tr>
              <th className="w-8 p-4"></th>
              <th className="text-left p-4 font-medium">Product</th>
              <th className="text-left p-4 font-medium">Type</th>
              <th className="text-left p-4 font-medium">Account</th>
              <th className="text-left p-4 font-medium">Source</th>
              <th className="text-center p-4 font-medium">Sentiment</th>
              <th className="text-right p-4 font-medium">Date</th>
            </tr>
          </thead>
          <tbody>
            {mentions.map((mention) => {
              const isExpanded = expandedRows.has(mention.id);
              const hasContext = mention.context_snippet && mention.context_snippet.length > 0;
              const accountId = mention.transcript_reviews?.final_account_id || mention.account_id;
              
              return (
                <>
                  <tr key={mention.id} className="border-b last:border-0 hover:bg-muted/30">
                    <td className="p-4">
                      {hasContext && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0"
                          onClick={() => toggleRow(mention.id)}
                        >
                          <ChevronRight className={cn(
                            "h-4 w-4 transition-transform",
                            isExpanded && "rotate-90"
                          )} />
                        </Button>
                      )}
                    </td>
                    <td className="p-4 font-medium">{mention.product_name}</td>
                    <td className="p-4">
                      <Badge 
                        variant="outline"
                        style={{ 
                          borderColor: MENTION_TYPE_COLORS[mention.mention_type as keyof typeof MENTION_TYPE_COLORS],
                          color: MENTION_TYPE_COLORS[mention.mention_type as keyof typeof MENTION_TYPE_COLORS]
                        }}
                      >
                        {mention.mention_type}
                      </Badge>
                    </td>
                    <td className="p-4 text-muted-foreground">
                      {mention.accounts?.name || '-'}
                    </td>
                    <td className="p-4">
                      {mention.transcript_reviews ? (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-auto py-1 px-2 text-left gap-2 max-w-[200px]"
                              onClick={() => handleNavigateToTranscript(mention)}
                              disabled={!accountId}
                            >
                              <FileText className="h-3.5 w-3.5 flex-shrink-0 text-muted-foreground" />
                              <span className="truncate text-xs">
                                {mention.transcript_reviews.meeting_title || 'View Transcript'}
                              </span>
                              <ExternalLink className="h-3 w-3 flex-shrink-0 text-muted-foreground" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>View source transcript</p>
                            {mention.transcript_reviews.meeting_title && (
                              <p className="text-xs text-muted-foreground">{mention.transcript_reviews.meeting_title}</p>
                            )}
                          </TooltipContent>
                        </Tooltip>
                      ) : (
                        <span className="text-xs text-muted-foreground">-</span>
                      )}
                    </td>
                    <td className="p-4 text-center">
                      {mention.sentiment_label ? (
                        <Badge 
                          variant="outline"
                          className={cn(
                            mention.sentiment_label === 'positive' && 'bg-green-500/20 text-green-500 border-green-500/30',
                            mention.sentiment_label === 'neutral' && 'bg-muted text-muted-foreground',
                            mention.sentiment_label === 'negative' && 'bg-destructive/20 text-destructive border-destructive/30',
                            mention.sentiment_label === 'mixed' && 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30'
                          )}
                        >
                          {mention.sentiment_label}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </td>
                    <td className="p-4 text-right text-sm text-muted-foreground">
                      {mention.transcript_date 
                        ? format(new Date(mention.transcript_date), 'MMM d, yyyy')
                        : '-'
                      }
                    </td>
                  </tr>
                  {isExpanded && hasContext && (
                    <tr key={`${mention.id}-context`} className="bg-muted/20">
                      <td colSpan={7} className="p-4">
                        <div className="pl-8 border-l-2 border-primary/30">
                          <div className="flex items-start gap-2 mb-2">
                            <Badge variant="outline" className="text-xs">Source Context</Badge>
                          </div>
                          <blockquote className="text-sm text-muted-foreground italic leading-relaxed">
                            "{mention.context_snippet}"
                          </blockquote>
                          {accountId && (
                            <Button
                              variant="link"
                              size="sm"
                              className="mt-2 h-auto p-0 text-xs"
                              onClick={() => handleNavigateToTranscript(mention)}
                            >
                              View full transcript <ExternalLink className="h-3 w-3 ml-1" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  )}
                </>
              );
            })}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}

// Pendo Product Coverage Section
interface PendoProductCoverageSectionProps {
  stats: Array<{
    rule_id: string;
    rule_name: string;
    match_count: number;
    total_mentions: number;
    avg_confidence: number;
    transcripts_count: number;
    last_detected: string | null;
    interest_levels: { high: number; medium: number; low: number; none: number };
    speaker_breakdown: { internal: number; customer: number; both: number };
  }>;
  recentMatches: Array<{
    id: string;
    rule_name: string;
    rule_id: string;
    transcript_id: string;
    opportunity_id: string | null;
    account_id: string | null;
    account_name: string | null;
    meeting_title: string | null;
    meeting_date: string | null;
    confidence_score: number | null;
    matched_phrases: string[];
    speaker_type: string | null;
    speaker_name: string | null;
    interest_level: string | null;
    use_case_context: string | null;
    mention_count: number | null;
    context_quotes: any[] | null;
    related_products: string[];
    created_at: string;
  }>;
  summary?: {
    totalProducts: number;
    totalMentions: number;
    totalTranscripts: number;
    productsWithMentions: number;
  } | null;
  isLoading: boolean;
}

function PendoProductCoverageSection({ stats, recentMatches, summary, isLoading }: PendoProductCoverageSectionProps) {
  const navigate = useNavigate();
  const [expandedMatch, setExpandedMatch] = useState<string | null>(null);

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex items-center justify-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const coveragePercentage = summary ? 
    Math.round((summary.productsWithMentions / Math.max(summary.totalProducts, 1)) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Coverage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{coveragePercentage}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              {summary?.productsWithMentions || 0} of {summary?.totalProducts || 0} products discussed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Mentions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{summary?.totalMentions || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Across all transcripts</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Transcripts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{summary?.totalTranscripts || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">With Pendo product mentions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">High Interest</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ color: 'hsl(var(--success))' }}>
              {stats.reduce((sum, s) => sum + s.interest_levels.high, 0)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">High interest signals</p>
          </CardContent>
        </Card>
      </div>

      {/* Product Coverage Table */}
      <Card>
        <CardHeader>
          <CardTitle>Product Coverage</CardTitle>
          <CardDescription>How often each Pendo product is being discussed in sales conversations</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {stats.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground">
              <Target className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No Pendo product mentions detected yet</p>
              <p className="text-sm mt-1">Product mentions are detected during transcript analysis</p>
            </div>
          ) : (
            <table className="w-full">
              <thead className="border-b bg-muted/50">
                <tr>
                  <th className="text-left p-4 font-medium">Product</th>
                  <th className="text-center p-4 font-medium">Mentions</th>
                  <th className="text-center p-4 font-medium">Transcripts</th>
                  <th className="text-center p-4 font-medium">Interest Level</th>
                  <th className="text-center p-4 font-medium">Speaker</th>
                  <th className="text-right p-4 font-medium">Last Detected</th>
                </tr>
              </thead>
              <tbody>
                {stats.map((product) => {
                  const totalInterest = product.interest_levels.high + product.interest_levels.medium + 
                    product.interest_levels.low + product.interest_levels.none;
                  const totalSpeakers = product.speaker_breakdown.internal + 
                    product.speaker_breakdown.customer + product.speaker_breakdown.both;
                  
                  return (
                    <tr key={product.rule_id} className="border-b last:border-0 hover:bg-muted/30">
                      <td className="p-4">
                        <div className="font-medium">{product.rule_name}</div>
                      </td>
                      <td className="p-4 text-center">
                        <Badge variant="secondary" className="font-mono">
                          {product.total_mentions}
                        </Badge>
                      </td>
                      <td className="p-4 text-center">
                        <span className="text-muted-foreground">{product.transcripts_count}</span>
                      </td>
                      <td className="p-4">
                        {totalInterest > 0 ? (
                          <div className="flex items-center justify-center gap-1">
                            {product.interest_levels.high > 0 && (
                              <Tooltip>
                                <TooltipTrigger>
                                  <div 
                                    className="h-2 rounded"
                                    style={{ width: `${(product.interest_levels.high / totalInterest) * 60}px`, minWidth: '4px', backgroundColor: 'hsl(var(--success))' }}
                                  />
                                </TooltipTrigger>
                                <TooltipContent>High: {product.interest_levels.high}</TooltipContent>
                              </Tooltip>
                            )}
                            {product.interest_levels.medium > 0 && (
                              <Tooltip>
                                <TooltipTrigger>
                                  <div 
                                    className="h-2 rounded"
                                    style={{ width: `${(product.interest_levels.medium / totalInterest) * 60}px`, minWidth: '4px', backgroundColor: 'hsl(var(--warning))' }}
                                  />
                                </TooltipTrigger>
                                <TooltipContent>Medium: {product.interest_levels.medium}</TooltipContent>
                              </Tooltip>
                            )}
                            {product.interest_levels.low > 0 && (
                              <Tooltip>
                                <TooltipTrigger>
                                  <div 
                                    className="h-2 rounded"
                                    style={{ width: `${(product.interest_levels.low / totalInterest) * 60}px`, minWidth: '4px', backgroundColor: 'hsl(var(--destructive))' }}
                                  />
                                </TooltipTrigger>
                                <TooltipContent>Low: {product.interest_levels.low}</TooltipContent>
                              </Tooltip>
                            )}
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-center block">-</span>
                        )}
                      </td>
                      <td className="p-4">
                        {totalSpeakers > 0 ? (
                          <div className="flex items-center justify-center gap-2 text-xs">
                            {product.speaker_breakdown.internal > 0 && (
                              <Badge variant="outline" className="text-xs">
                                <Users className="h-3 w-3 mr-1" />
                                {product.speaker_breakdown.internal}
                              </Badge>
                            )}
                            {product.speaker_breakdown.customer > 0 && (
                              <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-600 border-blue-500/30">
                                <MessageSquare className="h-3 w-3 mr-1" />
                                {product.speaker_breakdown.customer}
                              </Badge>
                            )}
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-center block">-</span>
                        )}
                      </td>
                      <td className="p-4 text-right text-sm text-muted-foreground">
                        {product.last_detected 
                          ? format(new Date(product.last_detected), 'MMM d, yyyy')
                          : '-'
                        }
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      {/* Recent Matches */}
      {recentMatches.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Detections</CardTitle>
            <CardDescription>Latest Pendo product mentions across conversations</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <table className="w-full">
              <thead className="border-b bg-muted/50">
                <tr>
                  <th className="w-8 p-4"></th>
                  <th className="text-left p-4 font-medium">Product</th>
                  <th className="text-left p-4 font-medium">Account</th>
                  <th className="text-left p-4 font-medium">Meeting</th>
                  <th className="text-center p-4 font-medium">Interest</th>
                  <th className="text-center p-4 font-medium">Speaker</th>
                  <th className="text-right p-4 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {recentMatches.map((match) => {
                  const isExpanded = expandedMatch === match.id;
                  const hasDetails = (match.context_quotes && match.context_quotes.length > 0) || 
                    match.matched_phrases.length > 0 || 
                    match.related_products?.length > 0 ||
                    match.use_case_context;
                  
                  return (
                    <>
                      <tr 
                        key={match.id} 
                        className={cn(
                          "border-b last:border-0 hover:bg-muted/30",
                          hasDetails && "cursor-pointer",
                          isExpanded && "bg-muted/20"
                        )}
                        onClick={() => hasDetails && setExpandedMatch(isExpanded ? null : match.id)}
                      >
                        <td className="p-4 text-center">
                          {hasDetails && (
                            <ChevronRight className={cn(
                              "h-4 w-4 transition-transform text-muted-foreground",
                              isExpanded && "rotate-90"
                            )} />
                          )}
                        </td>
                        <td className="p-4">
                          <Badge variant="secondary">{match.rule_name}</Badge>
                          {match.mention_count && match.mention_count > 1 && (
                            <Badge variant="outline" className="ml-2 text-xs">
                              ×{match.mention_count}
                            </Badge>
                          )}
                        </td>
                        <td className="p-4">
                          {match.account_name ? (
                            <Button
                              variant="link"
                              className="p-0 h-auto font-medium"
                              onClick={(e) => {
                                e.stopPropagation();
                                if (match.account_id) {
                                  navigate(`/accounts/${match.account_id}`);
                                }
                              }}
                            >
                              {match.account_name}
                            </Button>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </td>
                        <td className="p-4">
                          <span className="text-muted-foreground text-sm">
                            {match.meeting_title || 'Untitled meeting'}
                          </span>
                        </td>
                        <td className="p-4 text-center">
                          {match.interest_level ? (
                            <Badge 
                              variant="outline"
                              className={cn(
                                match.interest_level === 'high' && 'bg-green-500/20 text-green-600 border-green-500/30',
                                match.interest_level === 'medium' && 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30',
                                match.interest_level === 'low' && 'bg-orange-500/20 text-orange-600 border-orange-500/30'
                              )}
                            >
                              {match.interest_level}
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </td>
                        <td className="p-4 text-center">
                          {match.speaker_type ? (
                            <Badge 
                              variant="outline"
                              className={cn(
                                'text-xs',
                                match.speaker_type.toLowerCase().includes('customer') && 'bg-blue-500/10 text-blue-600 border-blue-500/30',
                                match.speaker_type.toLowerCase().includes('internal') && 'bg-muted'
                              )}
                            >
                              {match.speaker_name || match.speaker_type}
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </td>
                        <td className="p-4 text-right text-sm text-muted-foreground">
                          {format(new Date(match.created_at), 'MMM d, yyyy')}
                        </td>
                      </tr>
                      {isExpanded && hasDetails && (
                        <tr key={`${match.id}-details`} className="bg-muted/10 border-b">
                          <td colSpan={7} className="p-6">
                            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                              {/* Context Quotes */}
                              {match.context_quotes && match.context_quotes.length > 0 && (
                                <div className="space-y-3 lg:col-span-2">
                                  <div className="flex items-center gap-2 text-sm font-medium">
                                    <MessageSquare className="h-4 w-4 text-primary" />
                                    Context Quotes
                                  </div>
                                  <div className="space-y-3 pl-4 border-l-2 border-primary/30">
                                    {match.context_quotes.slice(0, 3).map((quote: any, idx: number) => (
                                      <blockquote key={idx} className="text-sm text-muted-foreground">
                                        <p className="italic leading-relaxed">
                                          "{typeof quote === 'string' ? quote : quote.text || quote.quote || JSON.stringify(quote)}"
                                        </p>
                                        {(quote.speaker || quote.speaker_type) && (
                                          <footer className="text-xs mt-1 flex items-center gap-2">
                                            <Users className="h-3 w-3" />
                                            <span className="font-medium">{quote.speaker || quote.speaker_type}</span>
                                          </footer>
                                        )}
                                      </blockquote>
                                    ))}
                                    {match.context_quotes.length > 3 && (
                                      <p className="text-xs text-muted-foreground">
                                        +{match.context_quotes.length - 3} more quotes
                                      </p>
                                    )}
                                  </div>
                                </div>
                              )}

                              {/* Details Column */}
                              <div className="space-y-4">
                                {match.matched_phrases.length > 0 && (
                                  <div className="space-y-2">
                                    <div className="flex items-center gap-2 text-sm font-medium">
                                      <Target className="h-4 w-4 text-primary" />
                                      Matched Keywords
                                    </div>
                                    <div className="flex flex-wrap gap-1">
                                      {match.matched_phrases.map((phrase, idx) => (
                                        <Badge key={idx} variant="outline" className="text-xs">
                                          {phrase}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                )}
                                {match.use_case_context && (
                                  <div className="space-y-2">
                                    <div className="flex items-center gap-2 text-sm font-medium">
                                      <Info className="h-4 w-4 text-primary" />
                                      Use Case Context
                                    </div>
                                    <p className="text-sm text-muted-foreground">{match.use_case_context}</p>
                                  </div>
                                )}
                                {match.related_products && match.related_products.length > 0 && (
                                  <div className="space-y-2">
                                    <div className="text-sm font-medium">Related Products</div>
                                    <div className="flex flex-wrap gap-1">
                                      {match.related_products.map((p, idx) => (
                                        <Badge key={idx} variant="secondary" className="text-xs">{p}</Badge>
                                      ))}
                                    </div>
                                  </div>
                                )}
                                {match.account_id && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="gap-2"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      navigate(`/accounts/${match.account_id}?tab=transcripts&transcript=${match.transcript_id}`);
                                    }}
                                  >
                                    <ExternalLink className="h-3.5 w-3.5" />
                                    View Transcript
                                  </Button>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

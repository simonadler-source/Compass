import { useState, useMemo } from 'react';
import { format, parseISO, differenceInDays } from 'date-fns';
import { ChevronDown, Filter, Info, ExternalLink, User, Users, ArrowUpDown, Award, BarChart3, SortAsc } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { 
  ProductMentionBubble, 
  ProductMentionBubblesResult,
  PRODUCT_COLORS,
} from '@/hooks/useProductMentionBubbles';
import type { DateRange } from '@/hooks/useProductMentions';

type SortMode = 'score' | 'hierarchy' | 'alpha';

interface ProductMentionsBubbleTimelineProps {
  data: ProductMentionBubblesResult | undefined;
  dateRange: DateRange;
  isLoading: boolean;
}

function getProductColor(productName: string, products: { name: string }[]): string {
  const index = products.findIndex(p => p.name === productName);
  return PRODUCT_COLORS[index % PRODUCT_COLORS.length];
}

function BubbleTooltipContent({ bubble }: { bubble: ProductMentionBubble }) {
  const navigate = useNavigate();
  
  return (
    <div className="space-y-2 max-w-xs">
      <div className="flex items-center justify-between gap-2">
        <p className="font-semibold">{bubble.productName}</p>
        {bubble.interestLevel && (
          <Badge 
            variant="outline" 
            className={cn(
              "text-xs",
              bubble.interestLevel.toLowerCase() === 'high' && "bg-green-500/20 text-green-600",
              bubble.interestLevel.toLowerCase() === 'medium' && "bg-amber-500/20 text-amber-600",
              bubble.interestLevel.toLowerCase() === 'low' && "bg-muted text-muted-foreground",
            )}
          >
            {bubble.interestLevel}
          </Badge>
        )}
      </div>
      
      <div className="text-xs text-muted-foreground space-y-1">
        <p className="flex items-center gap-1">
          <User className="h-3 w-3" />
          {bubble.personName}
        </p>
        <p>{format(parseISO(bubble.detectedAt), 'MMM d, yyyy h:mm a')}</p>
      </div>
      
      {bubble.meetingTitle && (
        <div className="pt-1 border-t">
          <p className="text-xs font-medium">Meeting:</p>
          <p className="text-xs text-muted-foreground truncate">{bubble.meetingTitle}</p>
        </div>
      )}
      
      {bubble.accountName && (
        <div className="pt-1 border-t">
          <p className="text-xs font-medium">Account:</p>
          <p className="text-xs text-muted-foreground">{bubble.accountName}</p>
        </div>
      )}
      
      {bubble.contextQuotes.length > 0 && (
        <div className="pt-1 border-t">
          <p className="text-xs font-medium">Context:</p>
          <p className="text-xs italic text-muted-foreground line-clamp-3">
            "{bubble.contextQuotes[0]}"
          </p>
        </div>
      )}
      
      {bubble.matchedPhrases.length > 0 && (
        <div className="pt-1 border-t">
          <p className="text-xs font-medium">Matched:</p>
          <p className="text-xs text-muted-foreground">
            {bubble.matchedPhrases.slice(0, 3).join(', ')}
          </p>
        </div>
      )}
      
      <div className="pt-2 flex gap-2">
        {bubble.accountId && (
          <Button 
            size="sm" 
            variant="outline" 
            className="h-6 text-xs gap-1"
            onClick={() => navigate(`/accounts/${bubble.accountId}?tab=transcripts&transcript=${bubble.transcriptId}`)}
          >
            <ExternalLink className="h-3 w-3" />
            View Transcript
          </Button>
        )}
      </div>
    </div>
  );
}

function ProductLegend({ 
  products, 
  selectedProducts,
  onToggle,
}: { 
  products: { id: string; name: string }[];
  selectedProducts: Set<string>;
  onToggle: (productId: string) => void;
}) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Filter className="h-4 w-4" />
          Products ({selectedProducts.size}/{products.length})
          <ChevronDown className="h-4 w-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="font-medium text-sm">Filter Products</p>
            <Button 
              variant="ghost" 
              size="sm"
              className="h-6 text-xs"
              onClick={() => {
                // Toggle all
                const allSelected = selectedProducts.size === products.length;
                products.forEach(p => {
                  if (allSelected ? selectedProducts.has(p.id) : !selectedProducts.has(p.id)) {
                    onToggle(p.id);
                  }
                });
              }}
            >
              {selectedProducts.size === products.length ? 'Deselect All' : 'Select All'}
            </Button>
          </div>
          <ScrollArea className="h-[300px]">
            <div className="space-y-2">
              {products.map((product, idx) => (
                <label 
                  key={product.id}
                  className="flex items-center gap-3 p-2 rounded hover:bg-muted cursor-pointer"
                >
                  <Checkbox
                    checked={selectedProducts.has(product.id)}
                    onCheckedChange={() => onToggle(product.id)}
                  />
                  <div 
                    className="w-3 h-3 rounded-full flex-shrink-0"
                    style={{ backgroundColor: PRODUCT_COLORS[idx % PRODUCT_COLORS.length] }}
                  />
                  <span className="text-sm truncate">{product.name}</span>
                </label>
              ))}
            </div>
          </ScrollArea>
        </div>
      </PopoverContent>
    </Popover>
  );
}

export function ProductMentionsBubbleTimeline({ data, dateRange, isLoading }: ProductMentionsBubbleTimelineProps) {
  const [selectedManager, setSelectedManager] = useState<string>('all');
  const [selectedProducts, setSelectedProducts] = useState<Set<string>>(new Set());
  const [sortMode, setSortMode] = useState<SortMode>('score');
  
  // Initialize selected products when data loads
  useMemo(() => {
    if (data?.products && selectedProducts.size === 0) {
      setSelectedProducts(new Set(data.products.map(p => p.id)));
    }
  }, [data?.products]);
  
  const toggleProduct = (productId: string) => {
    setSelectedProducts(prev => {
      const next = new Set(prev);
      if (next.has(productId)) {
        next.delete(productId);
      } else {
        next.add(productId);
      }
      return next;
    });
  };

  // Get all team members under a manager (recursively)
  const getTeamMemberIds = (managerId: string, persons: typeof data.persons): Set<string> => {
    const result = new Set<string>();
    const addReports = (mId: string) => {
      persons.forEach(p => {
        if (p.managerId === mId && p.id) {
          result.add(p.id);
          addReports(p.id); // Recursive
        }
      });
    };
    addReports(managerId);
    return result;
  };

  // Filter and process bubbles
  const { filteredBubbles, personRows, dateRange: displayRange } = useMemo(() => {
    if (!data) return { filteredBubbles: [], personRows: [], dateRange: { min: dateRange.from, max: dateRange.to } };
    
    // Filter by products
    let bubbles = data.bubbles.filter(b => selectedProducts.has(b.productRuleId));
    
    // Filter by manager/team
    if (selectedManager !== 'all') {
      const teamIds = getTeamMemberIds(selectedManager, data.persons);
      // Also include the manager themselves
      teamIds.add(selectedManager);
      bubbles = bubbles.filter(b => b.personId && teamIds.has(b.personId));
    }
    
    // Calculate date range from bubbles
    const dates = bubbles.map(b => parseISO(b.detectedAt).getTime());
    const minDate = dates.length > 0 ? new Date(Math.min(...dates)) : dateRange.from;
    const maxDate = dates.length > 0 ? new Date(Math.max(...dates)) : dateRange.to;
    
    // Group by person and calculate stats
    const personStats = new Map<string, { 
      email: string;
      name: string; 
      managerId: string | null;
      count: number; 
      products: Set<string>;
    }>();
    
    bubbles.forEach(b => {
      const key = b.personEmail || b.personName;
      if (!personStats.has(key)) {
        personStats.set(key, {
          email: b.personEmail,
          name: b.personName,
          managerId: b.managerId,
          count: 0,
          products: new Set(),
        });
      }
      const stats = personStats.get(key)!;
      stats.count++;
      stats.products.add(b.productName);
    });
    
    // Sort persons based on mode
    let sortedPersons = Array.from(personStats.entries());
    
    switch (sortMode) {
      case 'score':
        // Score = product breadth × mention count
        sortedPersons.sort((a, b) => {
          const scoreA = a[1].products.size * Math.log(a[1].count + 1);
          const scoreB = b[1].products.size * Math.log(b[1].count + 1);
          return scoreB - scoreA;
        });
        break;
      case 'hierarchy':
        // Group by manager first, then by count
        sortedPersons.sort((a, b) => {
          const mgrA = a[1].managerId || 'zzz';
          const mgrB = b[1].managerId || 'zzz';
          if (mgrA !== mgrB) return mgrA.localeCompare(mgrB);
          return b[1].count - a[1].count;
        });
        break;
      case 'alpha':
        sortedPersons.sort((a, b) => a[1].name.localeCompare(b[1].name));
        break;
    }
    
    const personRows = sortedPersons.map(([key, stats]) => ({
      key,
      ...stats,
    }));
    
    return {
      filteredBubbles: bubbles,
      personRows,
      dateRange: { min: minDate, max: maxDate },
    };
  }, [data, selectedProducts, selectedManager, sortMode, dateRange]);

  const totalDays = Math.max(differenceInDays(displayRange.max, displayRange.min), 1);
  
  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex items-center justify-center gap-3">
            <div className="animate-spin w-6 h-6 border-4 border-primary border-t-transparent rounded-full" />
            <p className="text-muted-foreground">Loading product mentions...</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!data || data.bubbles.length === 0) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="text-center text-muted-foreground">
            <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>No product mentions with speaker attribution found</p>
            <p className="text-sm mt-1">Mentions require speaker email to be tracked</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Users className="h-4 w-4" />
              Team Members
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{personRows.length}</div>
            <p className="text-xs text-muted-foreground mt-1">mentioning products</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Total Mentions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{filteredBubbles.length}</div>
            <p className="text-xs text-muted-foreground mt-1">in selected period</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Award className="h-4 w-4" />
              Top Performer
            </CardTitle>
          </CardHeader>
          <CardContent>
            {personRows[0] ? (
              <>
                <div className="text-lg font-bold truncate">{personRows[0].name}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {personRows[0].count} mentions • {personRows[0].products.size} products
                </p>
              </>
            ) : (
              <div className="text-muted-foreground">-</div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Products Tracked
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{selectedProducts.size}</div>
            <p className="text-xs text-muted-foreground mt-1">of {data.products.length} total</p>
          </CardContent>
        </Card>
      </div>
      
      {/* Timeline Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <CardTitle>Product Mention Timeline</CardTitle>
              <CardDescription>
                Each bubble represents a product mention - hover for details
              </CardDescription>
            </div>
            
            <div className="flex items-center gap-3 flex-wrap">
              {/* Manager filter */}
              <Select value={selectedManager} onValueChange={setSelectedManager}>
                <SelectTrigger className="w-[200px]">
                  <Users className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Select team" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Team Members</SelectItem>
                  {data.managers.map(manager => (
                    <SelectItem key={manager.id} value={manager.id}>
                      {manager.name} ({manager.reportCount})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              {/* Product filter */}
              <ProductLegend 
                products={data.products}
                selectedProducts={selectedProducts}
                onToggle={toggleProduct}
              />
              
              {/* Sort mode */}
              <ToggleGroup type="single" value={sortMode} onValueChange={(v) => v && setSortMode(v as SortMode)}>
                <ToggleGroupItem value="score" aria-label="Sort by score" className="gap-1">
                  <Award className="h-4 w-4" />
                  Score
                </ToggleGroupItem>
                <ToggleGroupItem value="hierarchy" aria-label="Sort by hierarchy" className="gap-1">
                  <Users className="h-4 w-4" />
                  Team
                </ToggleGroupItem>
                <ToggleGroupItem value="alpha" aria-label="Sort alphabetically" className="gap-1">
                  <SortAsc className="h-4 w-4" />
                  A-Z
                </ToggleGroupItem>
              </ToggleGroup>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          {personRows.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              No mentions found with current filters
            </div>
          ) : (
            <TooltipProvider>
              <div className="overflow-x-auto">
                {/* Timeline header with dates */}
                <div className="flex border-b bg-muted/30 sticky top-0">
                  <div className="w-48 flex-shrink-0 p-3 font-medium text-sm border-r">
                    Person
                  </div>
                  <div className="flex-1 relative h-8">
                    {/* Date markers */}
                    {[0, 0.25, 0.5, 0.75, 1].map(pct => {
                      const date = new Date(displayRange.min.getTime() + (displayRange.max.getTime() - displayRange.min.getTime()) * pct);
                      return (
                        <div 
                          key={pct}
                          className="absolute text-xs text-muted-foreground"
                          style={{ left: `${pct * 100}%`, transform: 'translateX(-50%)' }}
                        >
                          {format(date, 'MMM d')}
                        </div>
                      );
                    })}
                  </div>
                </div>
                
                {/* Person rows with bubbles */}
                <ScrollArea className="h-[500px]">
                  {personRows.map((person, rowIdx) => {
                    const personBubbles = filteredBubbles.filter(
                      b => (b.personEmail || b.personName) === person.key
                    );
                    
                    return (
                      <div 
                        key={person.key}
                        className={cn(
                          "flex border-b hover:bg-muted/20 transition-colors",
                          rowIdx % 2 === 0 && "bg-muted/5"
                        )}
                      >
                        {/* Person name */}
                        <div className="w-48 flex-shrink-0 p-3 border-r flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-medium">
                            {person.name.charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-medium truncate">{person.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {person.count} • {person.products.size} products
                            </p>
                          </div>
                        </div>
                        
                        {/* Timeline with bubbles */}
                        <div className="flex-1 relative h-16 py-2">
                          {personBubbles.map(bubble => {
                            const bubbleDate = parseISO(bubble.detectedAt);
                            const dayOffset = differenceInDays(bubbleDate, displayRange.min);
                            const leftPct = Math.max(0, Math.min(100, (dayOffset / totalDays) * 100));
                            const color = getProductColor(bubble.productName, data.products);
                            const size = Math.min(20, 10 + (bubble.confidenceScore / 20));
                            
                            return (
                              <Tooltip key={bubble.id}>
                                <TooltipTrigger asChild>
                                  <div
                                    className="absolute cursor-pointer transition-transform hover:scale-150 hover:z-10"
                                    style={{
                                      left: `${leftPct}%`,
                                      top: '50%',
                                      transform: 'translate(-50%, -50%)',
                                    }}
                                  >
                                    <div
                                      className="rounded-full opacity-70 hover:opacity-100 border-2 border-white shadow-sm"
                                      style={{
                                        width: `${size}px`,
                                        height: `${size}px`,
                                        backgroundColor: color,
                                      }}
                                    />
                                  </div>
                                </TooltipTrigger>
                                <TooltipContent side="top" className="p-3">
                                  <BubbleTooltipContent bubble={bubble} />
                                </TooltipContent>
                              </Tooltip>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </ScrollArea>
              </div>
            </TooltipProvider>
          )}
        </CardContent>
      </Card>
      
      {/* Product Legend */}
      <Card>
        <CardHeader className="py-3">
          <CardTitle className="text-sm">Product Legend</CardTitle>
        </CardHeader>
        <CardContent className="py-2">
          <div className="flex flex-wrap gap-3">
            {data.products.filter(p => selectedProducts.has(p.id)).map((product, idx) => (
              <div key={product.id} className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: PRODUCT_COLORS[data.products.indexOf(product) % PRODUCT_COLORS.length] }}
                />
                <span className="text-sm">{product.name}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

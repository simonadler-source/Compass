import { useState, useMemo } from 'react';
import { format } from 'date-fns';
import { ChevronDown, ChevronRight, User, Users, TrendingUp, Award, BarChart3, Grid3X3, LineChart as LineChartIcon, Info } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Progress } from '@/components/ui/progress';
import { 
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  Cell,
  LineChart,
  Line,
} from 'recharts';
import { cn } from '@/lib/utils';
import { 
  PersonProductMention, 
  TeamNode, 
  ProductMentionsByPersonResult 
} from '@/hooks/useProductMentionsByPerson';

type VisualizationType = 'heatmap' | 'sparkline' | 'bars';
type GroupingType = 'team' | 'user' | 'product';

interface ProductMentionsByPersonSectionProps {
  data: ProductMentionsByPersonResult | undefined;
  isLoading: boolean;
}

const HEATMAP_COLORS = [
  'hsl(var(--muted))',
  'hsl(142 50% 80%)',
  'hsl(142 60% 65%)',
  'hsl(142 70% 50%)',
  'hsl(142 80% 40%)',
];

function getHeatmapColor(value: number, max: number): string {
  if (value === 0) return HEATMAP_COLORS[0];
  const intensity = Math.min(Math.ceil((value / max) * 4), 4);
  return HEATMAP_COLORS[intensity];
}

function EnablementScoreBadge({ score, teamAvg }: { score: number; teamAvg: number }) {
  const comparison = score - teamAvg;
  let colorClass = 'bg-muted text-muted-foreground';
  
  if (score >= 70) {
    colorClass = 'bg-green-500/20 text-green-600 border-green-500/30';
  } else if (score >= 40) {
    colorClass = 'bg-amber-500/20 text-amber-600 border-amber-500/30';
  } else {
    colorClass = 'bg-red-500/20 text-red-600 border-red-500/30';
  }
  
  return (
    <Tooltip>
      <TooltipTrigger>
        <Badge variant="outline" className={cn('font-mono', colorClass)}>
          {score}
        </Badge>
      </TooltipTrigger>
      <TooltipContent>
        <div className="space-y-1">
          <p className="font-medium">Enablement Score: {score}/100</p>
          <p className="text-xs text-muted-foreground">
            {comparison > 0 ? '+' : ''}{comparison} vs team avg ({teamAvg})
          </p>
          <div className="text-xs space-y-0.5 pt-1 border-t">
            <p>• Breadth: products mentioned / total</p>
            <p>• Frequency: mention count (capped)</p>
            <p>• Confidence: AI detection confidence</p>
          </div>
        </div>
      </TooltipContent>
    </Tooltip>
  );
}

function PersonRow({ 
  person, 
  products, 
  periodLabels, 
  teamAvg, 
  visualization,
  maxMentions,
}: { 
  person: PersonProductMention;
  products: string[];
  periodLabels: string[];
  teamAvg: number;
  visualization: VisualizationType;
  maxMentions: number;
}) {
  const [expanded, setExpanded] = useState(false);
  
  // Calculate max value for heatmap scaling
  const maxPeriodValue = Math.max(...Object.values(person.mentionsByPeriod), 1);
  
  // Sparkline data
  const sparklineData = periodLabels.map(label => ({
    period: label,
    value: person.mentionsByPeriod[label] || 0,
  }));
  
  return (
    <Collapsible open={expanded} onOpenChange={setExpanded}>
      <div className={cn(
        "border-b hover:bg-muted/30 transition-colors",
        expanded && "bg-muted/20"
      )}>
        <CollapsibleTrigger asChild>
          <div className="flex items-center gap-4 p-4 cursor-pointer">
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
              {expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </Button>
            
            <div className="flex items-center gap-2 min-w-[200px]">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium",
                person.isInternal 
                  ? "bg-primary/10 text-primary" 
                  : "bg-muted text-muted-foreground"
              )}>
                {person.personName.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="font-medium text-sm">{person.personName}</p>
                {person.personEmail && (
                  <p className="text-xs text-muted-foreground">{person.personEmail}</p>
                )}
              </div>
            </div>
            
            <div className="flex items-center gap-6 flex-1">
              <div className="text-center min-w-[60px]">
                <p className="text-lg font-semibold">{person.totalMentions}</p>
                <p className="text-xs text-muted-foreground">mentions</p>
              </div>
              
              <div className="text-center min-w-[60px]">
                <p className="text-lg font-semibold">{person.uniqueProducts}</p>
                <p className="text-xs text-muted-foreground">products</p>
              </div>
              
              <EnablementScoreBadge score={person.enablementScore} teamAvg={teamAvg} />
              
              {/* Visualization */}
              <div className="flex-1 min-w-[200px] max-w-[400px]">
                {visualization === 'heatmap' && (
                  <div className="flex gap-0.5">
                    {periodLabels.map(label => (
                      <Tooltip key={label}>
                        <TooltipTrigger>
                          <div 
                            className="h-6 flex-1 min-w-[12px] rounded-sm border border-transparent hover:border-foreground/20"
                            style={{ backgroundColor: getHeatmapColor(person.mentionsByPeriod[label] || 0, maxPeriodValue) }}
                          />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>{label}: {person.mentionsByPeriod[label] || 0} mentions</p>
                        </TooltipContent>
                      </Tooltip>
                    ))}
                  </div>
                )}
                
                {visualization === 'sparkline' && (
                  <ResponsiveContainer width="100%" height={30}>
                    <LineChart data={sparklineData}>
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="hsl(var(--primary))" 
                        strokeWidth={1.5}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                )}
                
                {visualization === 'bars' && (
                  <ResponsiveContainer width="100%" height={30}>
                    <BarChart data={sparklineData}>
                      <Bar dataKey="value" fill="hsl(var(--primary))" radius={[2, 2, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>
          </div>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <div className="px-4 pb-4 pl-16 space-y-3">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
              {person.products.map(product => (
                <div 
                  key={product.productName}
                  className="flex items-center justify-between p-2 rounded-md bg-muted/50 border"
                >
                  <span className="text-sm font-medium truncate">{product.productName}</span>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {product.mentionCount}
                    </Badge>
                    {product.interestLevels.high > 0 && (
                      <Badge variant="default" className="text-xs bg-green-500">
                        High
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
            
            {person.managerName && (
              <p className="text-xs text-muted-foreground">
                Reports to: {person.managerName}
              </p>
            )}
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}

function TeamTreeNode({
  node,
  products,
  periodLabels,
  teamAvg,
  visualization,
  maxMentions,
  depth = 0,
}: {
  node: TeamNode;
  products: string[];
  periodLabels: string[];
  teamAvg: number;
  visualization: VisualizationType;
  maxMentions: number;
  depth?: number;
}) {
  const [expanded, setExpanded] = useState(depth < 2);
  const hasReports = node.directReports.length > 0;
  
  return (
    <div className={cn("border-l-2", depth === 0 ? "border-transparent" : "border-muted ml-4")}>
      <Collapsible open={expanded} onOpenChange={setExpanded}>
        <div className="flex items-center gap-2 py-2">
          {hasReports && (
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                {expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </Button>
            </CollapsibleTrigger>
          )}
          {!hasReports && <div className="w-6" />}
          
          <div className="flex items-center gap-3 flex-1">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">{node.name}</span>
            </div>
            
            <Badge variant="outline" className="text-xs">
              {node.teamTotalMentions} team mentions
            </Badge>
            
            <Tooltip>
              <TooltipTrigger>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-xs",
                    node.teamAvgEnablement >= 50 
                      ? "bg-green-500/10 text-green-600"
                      : node.teamAvgEnablement >= 30
                        ? "bg-amber-500/10 text-amber-600"
                        : "bg-red-500/10 text-red-600"
                  )}
                >
                  Avg: {node.teamAvgEnablement}
                </Badge>
              </TooltipTrigger>
              <TooltipContent>Team average enablement score</TooltipContent>
            </Tooltip>
          </div>
        </div>
        
        <CollapsibleContent>
          {/* Show the manager's own data if available */}
          {node.personData && (
            <div className="ml-6">
              <PersonRow
                person={node.personData}
                products={products}
                periodLabels={periodLabels}
                teamAvg={teamAvg}
                visualization={visualization}
                maxMentions={maxMentions}
              />
            </div>
          )}
          
          {/* Show direct reports */}
          {node.directReports.map(report => (
            <TeamTreeNode
              key={report.id}
              node={report}
              products={products}
              periodLabels={periodLabels}
              teamAvg={teamAvg}
              visualization={visualization}
              maxMentions={maxMentions}
              depth={depth + 1}
            />
          ))}
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}

function ProductGroupedView({
  data,
  teamAvg,
}: {
  data: ProductMentionsByPersonResult;
  teamAvg: number;
}) {
  const [selectedProduct, setSelectedProduct] = useState<string>(data.products[0] || '');
  
  const filteredPersons = useMemo(() => {
    if (!selectedProduct) return [];
    return data.persons
      .filter(p => p.products.some(prod => prod.productName === selectedProduct))
      .map(p => ({
        ...p,
        productMentions: p.products.find(prod => prod.productName === selectedProduct)?.mentionCount || 0,
      }))
      .sort((a, b) => b.productMentions - a.productMentions);
  }, [data.persons, selectedProduct]);
  
  if (data.products.length === 0) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="text-center text-muted-foreground">
            <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>No products detected in this period</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">Mentions by Product</CardTitle>
            <CardDescription>See who mentions each product most</CardDescription>
          </div>
          <Select value={selectedProduct} onValueChange={setSelectedProduct}>
            <SelectTrigger className="w-[250px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {data.products.map(product => (
                <SelectItem key={product} value={product}>{product}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {filteredPersons.slice(0, 10).map(person => (
            <div key={person.personEmail || person.personName} className="flex items-center gap-4">
              <div className="flex items-center gap-2 min-w-[200px]">
                <div className={cn(
                  "w-6 h-6 rounded-full flex items-center justify-center text-xs",
                  person.isInternal 
                    ? "bg-primary/10 text-primary" 
                    : "bg-muted text-muted-foreground"
                )}>
                  {person.personName.charAt(0).toUpperCase()}
                </div>
                <span className="text-sm truncate">{person.personName}</span>
              </div>
              
              <div className="flex-1">
                <Progress value={(person.productMentions / (filteredPersons[0]?.productMentions || 1)) * 100} />
              </div>
              
              <Badge variant="secondary" className="min-w-[50px] justify-center">
                {person.productMentions}
              </Badge>
              
              <EnablementScoreBadge score={person.enablementScore} teamAvg={teamAvg} />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export function ProductMentionsByPersonSection({ data, isLoading }: ProductMentionsByPersonSectionProps) {
  const [visualization, setVisualization] = useState<VisualizationType>('heatmap');
  const [grouping, setGrouping] = useState<GroupingType>('user');
  const [showInternal, setShowInternal] = useState(true);
  
  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex items-center justify-center gap-3">
            <div className="animate-spin w-6 h-6 border-4 border-primary border-t-transparent rounded-full" />
            <p className="text-muted-foreground">Loading product mentions by person...</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!data || (data.persons.length === 0 && data.teamHierarchy.length === 0)) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="text-center text-muted-foreground">
            <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>No product mentions with speaker attribution found</p>
            <p className="text-sm mt-1">Mentions require speaker email or name to be tracked</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  const filteredPersons = showInternal 
    ? data.persons.filter(p => p.isInternal)
    : data.persons;
  
  const maxMentions = Math.max(...filteredPersons.map(p => p.totalMentions), 1);
  
  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Users className="h-4 w-4" />
              Team Members
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{data.persons.filter(p => p.isInternal).length}</div>
            <p className="text-xs text-muted-foreground mt-1">mentioning products</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Award className="h-4 w-4" />
              Team Avg Enablement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{data.teamAverageEnablement}</div>
            <p className="text-xs text-muted-foreground mt-1">out of 100</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Top Performer
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredPersons[0] ? (
              <>
                <div className="text-lg font-bold truncate">{filteredPersons[0].personName}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  Score: {filteredPersons[0].enablementScore} • {filteredPersons[0].totalMentions} mentions
                </p>
              </>
            ) : (
              <div className="text-muted-foreground">-</div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <User className="h-4 w-4" />
              Needs Enablement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {filteredPersons.filter(p => p.enablementScore < 30).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">score below 30</p>
          </CardContent>
        </Card>
      </div>
      
      {/* Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <CardTitle>Product Mentions by Person</CardTitle>
              <CardDescription>
                Track who is talking about which products and when in the sales cycle
              </CardDescription>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">View:</span>
                <ToggleGroup type="single" value={grouping} onValueChange={(v) => v && setGrouping(v as GroupingType)}>
                  <ToggleGroupItem value="team" aria-label="Team hierarchy" className="gap-1">
                    <Users className="h-4 w-4" />
                    Team
                  </ToggleGroupItem>
                  <ToggleGroupItem value="user" aria-label="User list" className="gap-1">
                    <User className="h-4 w-4" />
                    User
                  </ToggleGroupItem>
                  <ToggleGroupItem value="product" aria-label="By product" className="gap-1">
                    <BarChart3 className="h-4 w-4" />
                    Product
                  </ToggleGroupItem>
                </ToggleGroup>
              </div>
              
              {grouping !== 'product' && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Timeline:</span>
                  <ToggleGroup type="single" value={visualization} onValueChange={(v) => v && setVisualization(v as VisualizationType)}>
                    <ToggleGroupItem value="heatmap" aria-label="Heatmap">
                      <Grid3X3 className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="sparkline" aria-label="Sparkline">
                      <LineChartIcon className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="bars" aria-label="Bars">
                      <BarChart3 className="h-4 w-4" />
                    </ToggleGroupItem>
                  </ToggleGroup>
                </div>
              )}
              
              <Button
                variant={showInternal ? "default" : "outline"}
                size="sm"
                onClick={() => setShowInternal(!showInternal)}
              >
                {showInternal ? "Internal Only" : "All Speakers"}
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          {grouping === 'team' && data.teamHierarchy.length > 0 ? (
            <div className="p-4 space-y-2">
              {data.teamHierarchy.map(node => (
                <TeamTreeNode
                  key={node.id}
                  node={node}
                  products={data.products}
                  periodLabels={data.periodLabels}
                  teamAvg={data.teamAverageEnablement}
                  visualization={visualization}
                  maxMentions={maxMentions}
                />
              ))}
            </div>
          ) : grouping === 'product' ? (
            <div className="p-4">
              <ProductGroupedView data={data} teamAvg={data.teamAverageEnablement} />
            </div>
          ) : (
            <div>
              {filteredPersons.map(person => (
                <PersonRow
                  key={person.personEmail || person.personName}
                  person={person}
                  products={data.products}
                  periodLabels={data.periodLabels}
                  teamAvg={data.teamAverageEnablement}
                  visualization={visualization}
                  maxMentions={maxMentions}
                />
              ))}
              {filteredPersons.length === 0 && (
                <div className="p-8 text-center text-muted-foreground">
                  No {showInternal ? 'internal' : ''} speakers found with product mentions
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

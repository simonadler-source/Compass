import { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Plus, Edit2, Trash2, GripVertical, HelpCircle, FileText, AlertTriangle, ChevronRight, ChevronDown, Link2, Link2Off } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface Category {
  id: string;
  name: string;
  description: string | null;
  deployment_type_id: string | null;
  sort_order: number | null;
  questions: Question[];
}

interface Question {
  id: string;
  category_id: string;
  question: string;
  field_type: string;
  options: any;
  placeholder: string | null;
  help_text: string | null;
  discovery_prompts: string[] | null;
  is_required: boolean | null;
  sort_order: number | null;
  parent_question_id: string | null;
  trigger_condition: { type: string; value?: string } | null;
  red_flag_condition: any;
}

interface DetectionRuleMapping {
  rule_id: string;
  readiness_question_id: string;
  rule_name?: string;
  is_active?: boolean;
}

export function ReadinessQuestionsManagement() {
  const queryClient = useQueryClient();
  const [showCategoryDialog, setShowCategoryDialog] = useState(false);
  const [showQuestionDialog, setShowQuestionDialog] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [dialogStep, setDialogStep] = useState<'question' | 'detection'>('question');
  const [expandedQuestions, setExpandedQuestions] = useState<Set<string>>(new Set());
  
  // Form states
  const [categoryName, setCategoryName] = useState('');
  const [categoryDescription, setCategoryDescription] = useState('');
  const [categoryDeploymentType, setCategoryDeploymentType] = useState<string>('');
  
  const [questionText, setQuestionText] = useState('');
  const [questionFieldType, setQuestionFieldType] = useState('text');
  const [questionPlaceholder, setQuestionPlaceholder] = useState('');
  const [questionHelpText, setQuestionHelpText] = useState('');
  const [questionOptions, setQuestionOptions] = useState('');
  const [questionRequired, setQuestionRequired] = useState(false);
  const [parentQuestionId, setParentQuestionId] = useState<string>('');
  const [triggerConditionType, setTriggerConditionType] = useState<string>('any');
  const [triggerConditionValue, setTriggerConditionValue] = useState('');
  const [discoveryPrompts, setDiscoveryPrompts] = useState('');
  
  // Detection rule form states
  const [createDetectionRule, setCreateDetectionRule] = useState(true);
  const [detectionRuleName, setDetectionRuleName] = useState('');
  const [detectionTreeId, setDetectionTreeId] = useState('');
  const [triggerPhrases, setTriggerPhrases] = useState('');
  const [autoAnswer, setAutoAnswer] = useState('');
  const [newQuestionId, setNewQuestionId] = useState<string | null>(null);
  
  // Fetch deployment types
  const { data: deploymentTypes } = useQuery({
    queryKey: ['deployment-types'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('deployment_types')
        .select('*')
        .order('sort_order')
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
  });
  
  // Fetch detection rule trees
  const { data: detectionTrees } = useQuery({
    queryKey: ['detection-trees'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('detection_rule_trees')
        .select('id, name')
        .order('name')
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
  });
  
  // Fetch detection rule mappings to know which questions have rules
  const { data: ruleMappings } = useQuery({
    queryKey: ['detection-rule-mappings-all'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('detection_rule_readiness_mappings')
        .select(`
          rule_id,
          readiness_question_id,
          detection_rules!inner(name, is_active)
        `)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []).map((m: any) => ({
        rule_id: m.rule_id,
        readiness_question_id: m.readiness_question_id,
        rule_name: m.detection_rules?.name,
        is_active: m.detection_rules?.is_active,
      })) as DetectionRuleMapping[];
    },
  });
  
  // Create a set of question IDs that have detection rules
  const questionsWithRules = useMemo(() => {
    const set = new Set<string>();
    ruleMappings?.forEach(m => set.add(m.readiness_question_id));
    return set;
  }, [ruleMappings]);
  
  // Fetch categories with questions
  const { data: categories, isLoading } = useQuery({
    queryKey: ['readiness-categories-admin'],
    queryFn: async () => {
      const { data: cats, error: catsError } = await gateway
        .from('readiness_template_categories')
        .select('*')
        .order('sort_order')
        .execute();
      if (catsError) throw new Error(getErrorMessage(catsError));
      
      const { data: questions, error: qError } = await gateway
        .from('readiness_template_questions')
        .select('*')
        .order('sort_order')
        .execute();
      if (qError) throw new Error(getErrorMessage(qError));
      
      return cats.map(cat => ({
        ...cat,
        questions: questions.filter(q => q.category_id === cat.id),
      })) as Category[];
    },
  });
  
  // Get all questions for parent selection
  const allQuestions = useMemo(() => {
    if (!categories) return [];
    return categories.flatMap(cat => cat.questions.map(q => ({ ...q, categoryName: cat.name })));
  }, [categories]);
  
  // Build hierarchical structure for tree view - supports multi-level nesting
  type QuestionNode = Question & { children: QuestionNode[]; depth: number };
  
  const buildQuestionTree = (questions: Question[]): QuestionNode[] => {
    const questionMap = new Map<string, Question>();
    const childMap = new Map<string, Question[]>();
    
    // Index all questions
    questions.forEach(q => {
      questionMap.set(q.id, q);
      if (q.parent_question_id) {
        const children = childMap.get(q.parent_question_id) || [];
        children.push(q);
        childMap.set(q.parent_question_id, children);
      }
    });
    
    // Recursive function to build tree with depth tracking
    const addChildren = (q: Question, depth: number): QuestionNode => ({
      ...q,
      depth,
      children: (childMap.get(q.id) || [])
        .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0))
        .map(child => addChildren(child, depth + 1)),
    });
    
    // Find root questions (those without parents OR whose parent is in a different category)
    const rootQuestions = questions
      .filter(q => !q.parent_question_id || !questionMap.has(q.parent_question_id))
      .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
    
    return rootQuestions.map(q => addChildren(q, 0));
  };
  
  // Get all descendant IDs for a question (for cascading exclude)
  const getDescendantIds = (questionId: string, questions: Question[]): string[] => {
    const descendants: string[] = [];
    const children = questions.filter(q => q.parent_question_id === questionId);
    children.forEach(child => {
      descendants.push(child.id);
      descendants.push(...getDescendantIds(child.id, questions));
    });
    return descendants;
  };
  
  // Count total descendants for a question
  const countDescendants = (questionId: string, questions: Question[]): number => {
    return getDescendantIds(questionId, questions).length;
  };
  
  // Mutations
  const saveCategory = useMutation({
    mutationFn: async (data: { id?: string; name: string; description: string | null; deployment_type_id: string | null }) => {
      if (data.id) {
        const { error } = await gateway
          .from('readiness_template_categories')
          .update({ name: data.name, description: data.description, deployment_type_id: data.deployment_type_id })
          .eq('id', data.id)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      } else {
        const maxSort = categories?.reduce((max, c) => Math.max(max, c.sort_order || 0), 0) || 0;
        const { error } = await gateway
          .from('readiness_template_categories')
          .insert({ name: data.name, description: data.description, deployment_type_id: data.deployment_type_id, sort_order: maxSort + 1 })
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['readiness-categories-admin'] });
      setShowCategoryDialog(false);
      resetCategoryForm();
      toast.success(editingCategory ? 'Category updated' : 'Category created');
    },
    onError: (error) => {
      toast.error('Failed to save category: ' + error.message);
    },
  });
  
  const deleteCategory = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway
        .from('readiness_template_categories')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['readiness-categories-admin'] });
      toast.success('Category deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete category: ' + error.message);
    },
  });
  
  const saveQuestion = useMutation({
    mutationFn: async (data: { 
      id?: string; 
      category_id: string; 
      question: string; 
      field_type: string; 
      options: any;
      placeholder: string | null;
      help_text: string | null;
      discovery_prompts: string[] | null;
      is_required: boolean;
      parent_question_id: string | null;
      trigger_condition: any;
    }) => {
      if (data.id) {
        const { error } = await gateway
          .from('readiness_template_questions')
          .update({
            category_id: data.category_id, // Allow moving between categories
            question: data.question,
            field_type: data.field_type,
            options: data.options,
            placeholder: data.placeholder,
            help_text: data.help_text,
            discovery_prompts: data.discovery_prompts,
            is_required: data.is_required,
            parent_question_id: data.parent_question_id,
            trigger_condition: data.trigger_condition,
          })
          .eq('id', data.id)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        return data.id;
      } else {
        const category = categories?.find(c => c.id === data.category_id);
        const maxSort = category?.questions.reduce((max, q) => Math.max(max, q.sort_order || 0), 0) || 0;
        const { data: inserted, error } = await gateway
          .from('readiness_template_questions')
          .insert({
            category_id: data.category_id,
            question: data.question,
            field_type: data.field_type,
            options: data.options,
            placeholder: data.placeholder,
            help_text: data.help_text,
            discovery_prompts: data.discovery_prompts,
            is_required: data.is_required,
            parent_question_id: data.parent_question_id,
            trigger_condition: data.trigger_condition,
            sort_order: maxSort + 1,
          })
          .select('id')
          .single()
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        return inserted.id;
      }
    },
    onSuccess: (questionId) => {
      queryClient.invalidateQueries({ queryKey: ['readiness-categories-admin'] });
      
      // Check if this question already has a detection rule
      const hasExistingRule = editingQuestion && questionsWithRules.has(editingQuestion.id);
      
      if (editingQuestion && !createDetectionRule) {
        // Editing and not creating a rule
        setShowQuestionDialog(false);
        resetQuestionForm();
        toast.success('Question updated');
      } else if (editingQuestion && createDetectionRule && !hasExistingRule) {
        // Editing and wants to create a detection rule (doesn't have one)
        setNewQuestionId(questionId);
        setDetectionRuleName(questionText.substring(0, 50) + ' Detection');
        setDialogStep('detection');
        toast.success('Question updated - now configure detection rule');
      } else if (!editingQuestion && createDetectionRule) {
        // Creating new question with detection rule
        setNewQuestionId(questionId);
        setDetectionRuleName(questionText.substring(0, 50) + ' Detection');
        setDialogStep('detection');
        toast.success('Question created - now configure detection rule');
      } else {
        setShowQuestionDialog(false);
        resetQuestionForm();
        toast.success(editingQuestion ? 'Question updated' : 'Question created');
      }
    },
    onError: (error) => {
      toast.error('Failed to save question: ' + error.message);
    },
  });
  
  const saveDetectionRule = useMutation({
    mutationFn: async (data: {
      questionId: string;
      name: string;
      treeId: string;
      triggerPhrases: string[];
      autoAnswer: string | null;
      isPending?: boolean;
      parentQuestionId?: string | null;
      categoryId?: string | null;
    }) => {
      // If this is a sub-question, find the parent question's detection rule
      let parentRuleId: string | null = null;
      let inheritedTreeId = data.treeId;
      
      // Auto-default tree based on category's deployment type
      if (!inheritedTreeId && data.categoryId) {
        const category = categories?.find((c: any) => c.id === data.categoryId);
        if (category?.deployment_type_id) {
          const depType = deploymentTypes?.find((dt: any) => dt.id === category.deployment_type_id);
          if (depType?.name === 'listen') {
            inheritedTreeId = 'd0000001-0001-4000-8000-000000000001'; // Listen Evaluation Detection tree
          }
        }
      }
      
      if (data.parentQuestionId) {
        // Look up parent question's detection rule
        const parentMapping = ruleMappings?.find(m => m.readiness_question_id === data.parentQuestionId);
        if (parentMapping) {
          parentRuleId = parentMapping.rule_id;
          
          // If no tree specified, inherit from parent rule's tree
          if (!inheritedTreeId && parentRuleId) {
            const { data: parentRule } = await gateway
              .from('detection_rules')
              .select('tree_id')
              .eq('id', parentRuleId)
              .single()
              .execute();
            if (parentRule?.tree_id) {
              inheritedTreeId = parentRule.tree_id;
            }
          }
        }
      }
      
      // Create the detection rule (mark as pending if no tree/phrases)
      const { data: rule, error: ruleError } = await gateway
        .from('detection_rules')
        .insert({
          tree_id: inheritedTreeId || null,
          parent_rule_id: parentRuleId,
          name: data.name,
          trigger_phrases: data.triggerPhrases.length > 0 ? data.triggerPhrases : [],
          is_active: !data.isPending, // Inactive if pending
        })
        .select('id')
        .single()
        .execute();
      if (ruleError) throw new Error(getErrorMessage(ruleError));
      
      // Create the mapping to the readiness question
      const { error: mappingError } = await gateway
        .from('detection_rule_readiness_mappings')
        .insert({
          rule_id: rule.id,
          readiness_question_id: data.questionId,
          auto_answer: data.autoAnswer,
        })
        .execute();
      if (mappingError) throw new Error(getErrorMessage(mappingError));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-mappings-all'] });
      queryClient.invalidateQueries({ queryKey: ['detection-rules'] });
      setShowQuestionDialog(false);
      resetQuestionForm();
      const isChildRule = !!variables.parentQuestionId;
      toast.success(
        variables.isPending 
          ? `Question created with pending ${isChildRule ? 'child ' : ''}detection rule` 
          : `${isChildRule ? 'Child detection' : 'Detection'} rule created and mapped`
      );
    },
    onError: (error) => {
      toast.error('Failed to create detection rule: ' + error.message);
    },
  });
  
  const deleteQuestion = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway
        .from('readiness_template_questions')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['readiness-categories-admin'] });
      toast.success('Question deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete question: ' + error.message);
    },
  });
  
  const resetCategoryForm = () => {
    setCategoryName('');
    setCategoryDescription('');
    setCategoryDeploymentType('');
    setEditingCategory(null);
  };
  
  const resetQuestionForm = () => {
    setQuestionText('');
    setQuestionFieldType('text');
    setQuestionPlaceholder('');
    setQuestionHelpText('');
    setQuestionOptions('');
    setQuestionRequired(false);
    setParentQuestionId('');
    setTriggerConditionType('any');
    setTriggerConditionValue('');
    setDiscoveryPrompts('');
    setEditingQuestion(null);
    setSelectedCategoryId(null);
    // Reset detection rule form
    setDialogStep('question');
    setCreateDetectionRule(true);
    setDetectionRuleName('');
    setDetectionTreeId('');
    setTriggerPhrases('');
    setAutoAnswer('');
    setNewQuestionId(null);
  };
  
  const openCategoryDialog = (category?: Category) => {
    if (category) {
      setEditingCategory(category);
      setCategoryName(category.name);
      setCategoryDescription(category.description || '');
      setCategoryDeploymentType(category.deployment_type_id || '');
    } else {
      resetCategoryForm();
    }
    setShowCategoryDialog(true);
  };
  
  const openQuestionDialog = (categoryId: string, question?: Question) => {
    setSelectedCategoryId(categoryId);
    if (question) {
      setEditingQuestion(question);
      setQuestionText(question.question);
      setQuestionFieldType(question.field_type);
      setQuestionPlaceholder(question.placeholder || '');
      setQuestionHelpText(question.help_text || '');
      setQuestionOptions(question.options ? JSON.stringify(question.options, null, 2) : '');
      setQuestionRequired(question.is_required || false);
      setParentQuestionId(question.parent_question_id || '');
      setTriggerConditionType(question.trigger_condition?.type || 'any');
      setTriggerConditionValue(question.trigger_condition?.value || '');
      setDiscoveryPrompts(question.discovery_prompts?.join('\n') || '');
    } else {
      resetQuestionForm();
      setSelectedCategoryId(categoryId);
    }
    setShowQuestionDialog(true);
  };
  
  const openAddChildQuestion = (parentQuestion: Question) => {
    resetQuestionForm();
    setSelectedCategoryId(parentQuestion.category_id);
    setParentQuestionId(parentQuestion.id);
    setTriggerConditionType('any');
    setShowQuestionDialog(true);
  };
  
  const handleSaveCategory = () => {
    saveCategory.mutate({
      id: editingCategory?.id,
      name: categoryName,
      description: categoryDescription || null,
      deployment_type_id: categoryDeploymentType || null,
    });
  };
  
  const handleSaveQuestion = () => {
    if (!selectedCategoryId) return;
    
    let parsedOptions = null;
    if (questionOptions.trim()) {
      try {
        parsedOptions = JSON.parse(questionOptions);
      } catch {
        toast.error('Invalid JSON for options');
        return;
      }
    }
    
    const parsedDiscoveryPrompts = discoveryPrompts.trim() 
      ? discoveryPrompts.split('\n').map(p => p.trim()).filter(Boolean)
      : null;
    
    const triggerCondition = parentQuestionId 
      ? { type: triggerConditionType, ...(triggerConditionValue ? { value: triggerConditionValue } : {}) }
      : null;
    
    saveQuestion.mutate({
      id: editingQuestion?.id,
      category_id: selectedCategoryId,
      question: questionText,
      field_type: questionFieldType,
      options: parsedOptions,
      placeholder: questionPlaceholder || null,
      help_text: questionHelpText || null,
      discovery_prompts: parsedDiscoveryPrompts,
      is_required: questionRequired,
      parent_question_id: parentQuestionId || null,
      trigger_condition: triggerCondition,
    });
  };
  
  const handleSaveDetectionRule = () => {
    if (!newQuestionId) {
      toast.error('No question to link');
      return;
    }
    
    const phrases = triggerPhrases.split('\n').map(p => p.trim()).filter(Boolean);
    
    // If no tree or phrases (and no parent to inherit from), create as pending
    const hasParentRule = parentQuestionId && ruleMappings?.some(m => m.readiness_question_id === parentQuestionId);
    const isPending = !detectionTreeId && !hasParentRule && phrases.length === 0;
    
    saveDetectionRule.mutate({
      questionId: newQuestionId,
      name: detectionRuleName || questionText.substring(0, 50) + ' Detection',
      treeId: detectionTreeId,
      triggerPhrases: phrases,
      autoAnswer: autoAnswer.trim() || null,
      isPending,
      parentQuestionId: parentQuestionId || null,
      categoryId: selectedCategoryId || null,
    });
  };
  
  const handleSkipDetectionRule = () => {
    setShowQuestionDialog(false);
    resetQuestionForm();
    toast.success('Question created without detection rule');
  };
  
  const getDeploymentTypeName = (id: string | null) => {
    if (!id) return 'All Deployments';
    return deploymentTypes?.find(dt => dt.id === id)?.name || id;
  };
  
  const toggleQuestionExpanded = (questionId: string) => {
    setExpandedQuestions(prev => {
      const next = new Set(prev);
      if (next.has(questionId)) {
        next.delete(questionId);
      } else {
        next.add(questionId);
      }
      return next;
    });
  };
  
  // Helper to count all questions including nested sub-questions
  const countAllQuestionsInCategory = (questions: Question[]): number => {
    return questions.reduce((sum, q) => {
      const childCount = countDescendants(q.id, questions);
      return sum + 1 + childCount;
    }, 0);
  };
  
  // Stats - count total including all hierarchical sub-questions
  const stats = useMemo(() => {
    if (!categories) return { total: 0, withRules: 0, withoutRules: 0 };
    // Use allQuestions which is already flattened to get accurate total
    const total = allQuestions.length;
    const withRules = questionsWithRules.size;
    return { total, withRules, withoutRules: total - withRules };
  }, [categories, questionsWithRules, allQuestions]);
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-72" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
        </CardContent>
      </Card>
    );
  }

  // Render a question node in the tree with simple indentation
  const renderQuestionNode = (question: QuestionNode, allCategoryQuestions: Question[]) => {
    const hasChildren = question.children && question.children.length > 0;
    const isExpanded = expandedQuestions.has(question.id);
    const hasRule = questionsWithRules.has(question.id);
    const depth = question.depth;
    const descendantCount = countDescendants(question.id, allCategoryQuestions);
    
    return (
      <div key={question.id}>
        <div
          className={cn(
            "flex items-start gap-2 p-3 rounded-lg border transition-all hover:bg-muted/50",
            depth === 0 ? "bg-card border-border" : "bg-transparent border-transparent"
          )}
          style={{ paddingLeft: depth > 0 ? `${depth * 24 + 12}px` : undefined }}
        >
          {/* Expand/collapse for parent questions */}
          {hasChildren ? (
            <button
              type="button"
              onClick={() => toggleQuestionExpanded(question.id)}
              className="p-1 hover:bg-primary/10 rounded transition-colors mt-0.5 shrink-0"
            >
              {isExpanded ? (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              )}
            </button>
          ) : (
            <div className="w-6 shrink-0" />
          )}
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start gap-2 flex-wrap">
              <span className={cn(
                "text-sm",
                depth === 0 && "font-medium"
              )}>
                {question.question}
              </span>
              
              {/* Child count badge */}
              {hasChildren && (
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0 shrink-0">
                  {descendantCount}
                </Badge>
              )}
              
              {question.is_required && (
                <Badge variant="destructive" className="text-xs shrink-0">Required</Badge>
              )}
              
              {/* Detection rule status */}
              {hasRule ? (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Badge variant="outline" className="text-xs shrink-0 border-green-500 text-green-600 bg-green-50 dark:bg-green-950">
                        <Link2 className="w-3 h-3 mr-1" />
                        Linked
                      </Badge>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">Has detection rule(s) configured</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              ) : (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Badge variant="outline" className="text-xs shrink-0 border-amber-500 text-amber-600 bg-amber-50 dark:bg-amber-950">
                        <Link2Off className="w-3 h-3 mr-1" />
                        No Rule
                      </Badge>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">No detection rule - won't auto-populate from transcripts</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>
            
            <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground flex-wrap">
              <Badge variant="outline" className="text-xs">{question.field_type}</Badge>
              {question.parent_question_id && question.trigger_condition && (
                <span className="flex items-center gap-1">
                  <span className="text-muted-foreground">Trigger:</span>
                  <Badge variant="secondary" className="text-xs">
                    {question.trigger_condition.type}
                    {question.trigger_condition.value !== undefined && ` = "${String(question.trigger_condition.value)}"`}
                  </Badge>
                </span>
              )}
              {question.help_text && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="flex items-center gap-1 cursor-help">
                        <HelpCircle className="w-3 h-3 shrink-0" />
                        <span className="truncate max-w-[150px]">{question.help_text}</span>
                      </span>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p className="text-xs">{question.help_text}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>
          </div>
          
          <div className="flex gap-1 shrink-0">
            {/* Add child question button */}
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => openAddChildQuestion(question)}
                    className="h-8 w-8 hover:bg-primary/10"
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs">Add sub-question</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => openQuestionDialog(question.category_id, question)}
              className="h-8 w-8"
            >
              <Edit2 className="w-3 h-3" />
            </Button>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      const msg = descendantCount > 0
                        ? `Delete this question and its ${descendantCount} sub-question(s)?`
                        : 'Delete this question?';
                      if (confirm(msg)) {
                        deleteQuestion.mutate(question.id);
                      }
                    }}
                    className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </TooltipTrigger>
                {descendantCount > 0 && (
                  <TooltipContent>
                    <p className="text-xs text-destructive">Will also delete {descendantCount} sub-question(s)</p>
                  </TooltipContent>
                )}
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
        
        {/* Render children with simple indentation */}
        {hasChildren && isExpanded && (
          <div className="mt-1 space-y-1">
            {question.children.map(child => renderQuestionNode(child, allCategoryQuestions))}
          </div>
        )}
      </div>
    );
  };

  return (
    <Card className="glass border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
              Technical Readiness Questions
            </CardTitle>
            <CardDescription>
              Manage application & metadata readiness categories and questions
            </CardDescription>
          </div>
          <div className="flex items-center gap-4">
            {/* Stats */}
            <div className="flex items-center gap-3 text-sm">
              <span className="text-muted-foreground">{stats.total} questions</span>
              {stats.withoutRules > 0 && (
                <Badge variant="outline" className="gap-1 border-amber-500 text-amber-600">
                  <AlertTriangle className="w-3 h-3" />
                  {stats.withoutRules} without rules
                </Badge>
              )}
            </div>
            <Button onClick={() => openCategoryDialog()} variant="outline" size="sm" className="gap-2">
              <Plus className="w-4 h-4" />
              Add Category
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {categories?.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No categories defined yet. Add your first category to get started.</p>
          </div>
        ) : (
          <Accordion type="multiple" className="space-y-2">
            {categories?.map(category => {
              const questionTree = buildQuestionTree(category.questions);
              
              return (
                <AccordionItem key={category.id} value={category.id} className="glass rounded-lg border-border px-4">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-center gap-3 flex-1">
                      <GripVertical className="w-4 h-4 text-muted-foreground" />
                      <div className="text-left">
                        <div className="font-medium">{category.name}</div>
                        {category.description && (
                          <div className="text-sm text-muted-foreground">{category.description}</div>
                        )}
                      </div>
                      <Badge variant="outline" className="ml-auto mr-4">
                        {getDeploymentTypeName(category.deployment_type_id)}
                      </Badge>
                      <Badge variant="secondary">{category.questions.length} questions</Badge>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pb-4">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openCategoryDialog(category)}
                            className="gap-1"
                          >
                            <Edit2 className="w-3 h-3" />
                            Edit Category
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              if (confirm('Delete this category and all its questions?')) {
                                deleteCategory.mutate(category.id);
                              }
                            }}
                            className="gap-1 text-destructive hover:text-destructive"
                          >
                            <Trash2 className="w-3 h-3" />
                            Delete
                          </Button>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openQuestionDialog(category.id)}
                          className="gap-1"
                        >
                          <Plus className="w-3 h-3" />
                          Add Question
                        </Button>
                      </div>
                      
                      {category.questions.length === 0 ? (
                        <div className="text-center py-4 text-muted-foreground text-sm">
                          No questions in this category yet.
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {questionTree.map(q => renderQuestionNode(q, category.questions))}
                        </div>
                      )}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        )}
      </CardContent>
      
      {/* Category Dialog */}
      <Dialog open={showCategoryDialog} onOpenChange={setShowCategoryDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingCategory ? 'Edit Category' : 'Add Category'}</DialogTitle>
            <DialogDescription>
              Categories group related technical readiness questions together.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Category Name</Label>
              <Input
                value={categoryName}
                onChange={(e) => setCategoryName(e.target.value)}
                placeholder="e.g., Application & Metadata"
              />
            </div>
            <div className="space-y-2">
              <Label>Description (optional)</Label>
              <Textarea
                value={categoryDescription}
                onChange={(e) => setCategoryDescription(e.target.value)}
                placeholder="Brief description of this category..."
              />
            </div>
            <div className="space-y-2">
              <Label>Deployment Type</Label>
              <Select value={categoryDeploymentType || '__none__'} onValueChange={(v) => setCategoryDeploymentType(v === '__none__' ? '' : v)}>
                <SelectTrigger>
                  <SelectValue placeholder="All deployment types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">All deployment types</SelectItem>
                  {deploymentTypes?.map(dt => (
                    <SelectItem key={dt.id} value={dt.id}>{dt.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Leave empty to show for all deployment types.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCategoryDialog(false)}>Cancel</Button>
            <Button onClick={handleSaveCategory} disabled={!categoryName.trim() || saveCategory.isPending}>
              {saveCategory.isPending ? 'Saving...' : 'Save'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Question Dialog */}
      <Dialog open={showQuestionDialog} onOpenChange={(open) => {
        if (!open) resetQuestionForm();
        setShowQuestionDialog(open);
      }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingQuestion ? 'Edit Question' : dialogStep === 'question' ? 'Add Question (Step 1/2)' : 'Configure Detection Rule (Step 2/2)'}
            </DialogTitle>
            <DialogDescription>
              {dialogStep === 'question' 
                ? 'Define the question and how it should be answered.'
                : 'Configure a detection rule to auto-populate this answer from transcripts.'}
            </DialogDescription>
          </DialogHeader>
          
          {dialogStep === 'question' ? (
            <>
              <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                {/* Category Selection - shown when editing to allow moving */}
                {editingQuestion && (
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select value={selectedCategoryId || ''} onValueChange={setSelectedCategoryId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories?.map(cat => (
                          <SelectItem key={cat.id} value={cat.id}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      Move this question to a different category
                    </p>
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label>Question Text</Label>
                  <Textarea
                    value={questionText}
                    onChange={(e) => setQuestionText(e.target.value)}
                    placeholder="What is the application name?"
                  />
                </div>
                
                {/* Parent Question Selection */}
                <div className="space-y-2">
                  <Label>Parent Question (optional)</Label>
                  <Select value={parentQuestionId || '__none__'} onValueChange={(v) => setParentQuestionId(v === '__none__' ? '' : v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="None (top-level question)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">None (top-level question)</SelectItem>
                      {allQuestions
                        .filter(q => q.id !== editingQuestion?.id)
                        .map(q => (
                          <SelectItem key={q.id} value={q.id}>
                            [{q.categoryName}] {q.question.substring(0, 50)}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Select a parent to make this a follow-up question
                  </p>
                </div>
                
                {/* Trigger Condition (only if parent selected) */}
                {parentQuestionId && (
                  <div className="space-y-2 p-3 rounded-lg bg-muted/50 border border-border">
                    <Label>Show when parent answer...</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Select value={triggerConditionType} onValueChange={setTriggerConditionType}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="any">Has any value</SelectItem>
                          <SelectItem value="equals">Equals</SelectItem>
                          <SelectItem value="contains">Contains</SelectItem>
                          <SelectItem value="not_equals">Does not equal</SelectItem>
                        </SelectContent>
                      </Select>
                      {triggerConditionType !== 'any' && (
                        <Input
                          value={triggerConditionValue}
                          onChange={(e) => setTriggerConditionValue(e.target.value)}
                          placeholder="Value..."
                        />
                      )}
                    </div>
                  </div>
                )}
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Field Type</Label>
                    <Select value={questionFieldType} onValueChange={setQuestionFieldType}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="text">Text</SelectItem>
                        <SelectItem value="textarea">Long Text</SelectItem>
                        <SelectItem value="select">Dropdown</SelectItem>
                        <SelectItem value="multi-select">Multi-Select</SelectItem>
                        <SelectItem value="boolean">Yes/No</SelectItem>
                        <SelectItem value="number">Number</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2 flex items-end">
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="required"
                        checked={questionRequired}
                        onCheckedChange={(checked) => setQuestionRequired(checked === true)}
                      />
                      <Label htmlFor="required" className="cursor-pointer">Required</Label>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Placeholder (optional)</Label>
                  <Input
                    value={questionPlaceholder}
                    onChange={(e) => setQuestionPlaceholder(e.target.value)}
                    placeholder="Enter placeholder text..."
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Help Text (optional)</Label>
                  <Textarea
                    value={questionHelpText}
                    onChange={(e) => setQuestionHelpText(e.target.value)}
                    placeholder="Additional guidance for answering this question..."
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Discovery Prompts (one per line)</Label>
                  <Textarea
                    value={discoveryPrompts}
                    onChange={(e) => setDiscoveryPrompts(e.target.value)}
                    placeholder="What questions should be asked?&#10;How is this configured?"
                    className="min-h-[80px]"
                  />
                  <p className="text-xs text-muted-foreground">
                    Suggested questions to ask during discovery calls
                  </p>
                </div>
                
                {['select', 'multi-select'].includes(questionFieldType) && (
                  <div className="space-y-2">
                    <Label>Options (JSON array)</Label>
                    <Textarea
                      value={questionOptions}
                      onChange={(e) => setQuestionOptions(e.target.value)}
                      placeholder='["Option 1", "Option 2", "Option 3"]'
                      className="font-mono text-sm"
                    />
                    <p className="text-xs text-muted-foreground">
                      Enter a JSON array of options, e.g., ["Yes", "No", "Maybe"]
                    </p>
                  </div>
                )}
                
                {/* Show detection rule option for new questions OR existing questions without a rule */}
                {(() => {
                  const hasExistingRule = editingQuestion && questionsWithRules.has(editingQuestion.id);
                  const showDetectionOption = !editingQuestion || !hasExistingRule;
                  
                  if (!showDetectionOption) return null;
                  
                  return (
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 border border-border">
                      <Checkbox
                        id="create-detection-rule"
                        checked={createDetectionRule}
                        onCheckedChange={(checked) => setCreateDetectionRule(checked === true)}
                      />
                      <Label htmlFor="create-detection-rule" className="text-sm cursor-pointer flex-1">
                        {editingQuestion 
                          ? 'Create detection rule for this question (currently has none)'
                          : 'Create detection rule to auto-populate from transcripts'}
                      </Label>
                      {editingQuestion && (
                        <Badge variant="outline" className="text-xs border-amber-500 text-amber-600">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          No Rule
                        </Badge>
                      )}
                    </div>
                  );
                })()}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowQuestionDialog(false)}>Cancel</Button>
                <Button onClick={handleSaveQuestion} disabled={!questionText.trim() || saveQuestion.isPending}>
                  {saveQuestion.isPending 
                    ? 'Saving...' 
                    : (() => {
                        const hasExistingRule = editingQuestion && questionsWithRules.has(editingQuestion.id);
                        const willShowDetection = createDetectionRule && (!editingQuestion || !hasExistingRule);
                        return willShowDetection ? 'Next' : 'Save';
                      })()
                  }
                </Button>
              </DialogFooter>
            </>
          ) : (
            <>
              <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                <div className="p-3 rounded-lg bg-primary/10 border border-primary/20 text-sm">
                  <span className="font-medium">Question:</span> {questionText}
                </div>
                
                {/* Show parent context for sub-questions */}
                {parentQuestionId && (() => {
                  const parentMapping = ruleMappings?.find(m => m.readiness_question_id === parentQuestionId);
                  const parentQuestion = allQuestions.find(q => q.id === parentQuestionId);
                  return (
                    <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-sm space-y-2">
                      <div className="flex items-center gap-2 font-medium text-emerald-700 dark:text-emerald-400">
                        <Link2 className="h-4 w-4" />
                        Creating Child Detection Rule
                      </div>
                      <p className="text-muted-foreground">
                        This will create a <strong>child rule</strong> under the parent question's detection rule
                        {parentMapping?.rule_name && <> "<span className="font-medium">{parentMapping.rule_name}</span>"</>}.
                      </p>
                      {parentMapping ? (
                        <div className="flex items-center gap-2 text-xs">
                          <Badge variant="secondary" className="bg-emerald-500/20">
                            Inherits tree from parent
                          </Badge>
                          <span className="text-muted-foreground">
                            Trigger condition: {triggerConditionType === 'equals' && triggerConditionValue ? `equals "${triggerConditionValue}"` : triggerConditionType === 'contains' && triggerConditionValue ? `contains "${triggerConditionValue}"` : 'any value'}
                          </span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 text-xs text-amber-600 dark:text-amber-400">
                          <AlertTriangle className="h-3 w-3" />
                          Parent question has no detection rule - this will be created as a standalone rule
                        </div>
                      )}
                    </div>
                  );
                })()}
                
                <div className="space-y-2">
                  <Label>Detection Rule Name</Label>
                  <Input
                    value={detectionRuleName}
                    onChange={(e) => setDetectionRuleName(e.target.value)}
                    placeholder="e.g., App Name Detection"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Detection Tree {parentQuestionId && ruleMappings?.some(m => m.readiness_question_id === parentQuestionId) ? '(inherited from parent)' : '(optional)'}</Label>
                  <Select 
                    value={detectionTreeId || '__none__'} 
                    onValueChange={(v) => setDetectionTreeId(v === '__none__' ? '' : v)}
                    disabled={!!parentQuestionId && ruleMappings?.some(m => m.readiness_question_id === parentQuestionId)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a detection tree..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">{parentQuestionId ? 'Inherit from parent' : 'None (create as pending)'}</SelectItem>
                      {detectionTrees?.map(tree => (
                        <SelectItem key={tree.id} value={tree.id}>{tree.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {parentQuestionId && ruleMappings?.some(m => m.readiness_question_id === parentQuestionId) 
                      ? 'Tree is inherited from the parent detection rule'
                      : 'Leave empty to create a pending rule for later configuration'}
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label>Trigger Phrases (one per line)</Label>
                  <Textarea
                    value={triggerPhrases}
                    onChange={(e) => setTriggerPhrases(e.target.value)}
                    placeholder={parentQuestionId 
                      ? "cross-origin iframe\nhas its own authentication\nseparate login required"
                      : "our application is called\nthe app name is\nwe call it"}
                    className="min-h-[100px] font-mono text-sm"
                  />
                  <p className="text-xs text-muted-foreground">
                    {parentQuestionId 
                      ? 'Phrases that indicate the follow-up information is being discussed in context of the parent answer'
                      : 'Phrases that indicate this information is being discussed'}
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label>Auto-Answer Value (optional)</Label>
                  <Input
                    value={autoAnswer}
                    onChange={(e) => setAutoAnswer(e.target.value)}
                    placeholder="e.g., Yes, Confirmed, etc."
                  />
                  <p className="text-xs text-muted-foreground">
                    Value to auto-fill when triggered (leave blank to extract from context)
                  </p>
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={handleSkipDetectionRule}>Skip</Button>
                <Button 
                  onClick={handleSaveDetectionRule} 
                  disabled={saveDetectionRule.isPending}
                >
                  {saveDetectionRule.isPending ? 'Creating...' : !detectionTreeId || !triggerPhrases.trim() ? 'Create Pending Rule' : 'Create Rule'}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}

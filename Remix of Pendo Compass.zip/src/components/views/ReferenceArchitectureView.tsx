import { useState, useEffect, useMemo } from 'react';
import { Loader2, Layers, Star, Check, Circle, Save, History, ChevronDown, RotateCcw, RotateCw, PanelLeftClose, PanelLeft, SlidersHorizontal } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { TechnologyPalette } from '@/components/canvas/TechnologyPalette';
import { FunctionalAreaCanvas, CanvasTechNode, CanvasAreaNode, CanvasConnection } from '@/components/canvas/FunctionalAreaCanvas';
import { LayerPanel } from '@/components/canvas/LayerPanel';
import { useLayers } from '@/hooks/useLayers';
import { 
  useFunctionalAreas, 
  useCreateFunctionalArea, 
  useUpdateFunctionalArea, 
  useDeleteFunctionalArea,
  TechnologyRepoItem 
} from '@/hooks/useTechnologyRepository';
import { useReferenceTechnologies, useCreateReferenceTechnology, useDeleteReferenceTechnology } from '@/hooks/useReferenceArchitecture';
import {
  useArchitectureVersions,
  useSaveArchitectureVersion,
  useRestoreArchitectureVersion,
  ArchitectureSnapshot,
} from '@/hooks/useArchitectureVersions';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

export function ReferenceArchitectureView() {
  const [paletteCollapsed, setPaletteCollapsed] = useState(false);
  const [layerSheetOpen, setLayerSheetOpen] = useState(false);
  const { data: technologies, isLoading: techLoading } = useReferenceTechnologies();
  const { data: functionalAreas, isLoading: areasLoading } = useFunctionalAreas();
  const { data: layers, isLoading: layersLoading } = useLayers();
  const { data: versions, isLoading: versionsLoading } = useArchitectureVersions();
  const createTech = useCreateReferenceTechnology();
  const deleteTech = useDeleteReferenceTechnology();
  const createArea = useCreateFunctionalArea();
  const updateArea = useUpdateFunctionalArea();
  const deleteArea = useDeleteFunctionalArea();
  const saveVersion = useSaveArchitectureVersion();
  const restoreVersion = useRestoreArchitectureVersion();
  
  const [areaPositions, setAreaPositions] = useState<Record<string, { x: number; y: number; width: number; height: number }>>({});
  const [techPositions, setTechPositions] = useState<Record<string, { x: number; y: number }>>({});
  const [connections, setConnections] = useState<CanvasConnection[]>([]);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showHistoryDialog, setShowHistoryDialog] = useState(false);
  const [versionName, setVersionName] = useState('');
  const [versionDescription, setVersionDescription] = useState('');
  const [currentVersionIndex, setCurrentVersionIndex] = useState(-1);

  const positionsKey = 'reference-architecture-area-positions';
  const techPosKey = 'reference-architecture-tech-positions';
  const connectionsKey = 'reference-architecture-connections';

  // Load saved positions
  useEffect(() => {
    const savedAreas = localStorage.getItem(positionsKey);
    if (savedAreas) {
      try { setAreaPositions(JSON.parse(savedAreas)); } catch {}
    }
    const savedTechs = localStorage.getItem(techPosKey);
    if (savedTechs) {
      try { setTechPositions(JSON.parse(savedTechs)); } catch {}
    }
    const savedConnections = localStorage.getItem(connectionsKey);
    if (savedConnections) {
      try { setConnections(JSON.parse(savedConnections)); } catch {}
    }
  }, []);

  // Save positions
  useEffect(() => {
    localStorage.setItem(positionsKey, JSON.stringify(areaPositions));
  }, [areaPositions]);

  useEffect(() => {
    localStorage.setItem(techPosKey, JSON.stringify(techPositions));
  }, [techPositions]);

  useEffect(() => {
    localStorage.setItem(connectionsKey, JSON.stringify(connections));
  }, [connections]);

  // Track current version in history
  useEffect(() => {
    if (versions && versions.length > 0) {
      const currentIdx = versions.findIndex(v => v.is_current);
      setCurrentVersionIndex(currentIdx);
    }
  }, [versions]);

  // Calculate dynamic layer heights based on functional areas
  const dynamicLayerHeights = useMemo(() => {
    const heights: Record<string, number> = {};
    const MIN_LAYER_HEIGHT = 140;
    const PADDING = 50;
    
    // Initialize with default heights from layers data
    if (layers) {
      layers.forEach(layer => {
        heights[layer.name] = layer.height;
      });
    }
    
    // Calculate max area height per layer
    if (functionalAreas && technologies) {
      const TECH_CHIP_HEIGHT = 36;
      const HEADER_HEIGHT = 30;
      const GAP = 8;
      const AREA_PADDING = 15;
      
      // Group areas by layer and calculate their heights
      const areaHeightsByLayer: Record<string, number[]> = {};
      functionalAreas.forEach(area => {
        const techCount = technologies.filter(t => t.category === area.name).length;
        const cols = Math.min(3, Math.max(2, Math.ceil(Math.sqrt(techCount || 1))));
        const rows = Math.ceil((techCount || 0) / cols);
        const areaHeight = techCount > 0 
          ? HEADER_HEIGHT + AREA_PADDING + rows * TECH_CHIP_HEIGHT + (rows - 1) * GAP + AREA_PADDING
          : area.default_height ?? 100;
        
        if (!areaHeightsByLayer[area.layer]) areaHeightsByLayer[area.layer] = [];
        areaHeightsByLayer[area.layer].push(areaHeight);
      });
      
      // Set layer height to max area height + padding
      Object.entries(areaHeightsByLayer).forEach(([layerName, areaHeights]) => {
        const maxHeight = Math.max(...areaHeights, MIN_LAYER_HEIGHT - PADDING);
        heights[layerName] = Math.max(heights[layerName] || MIN_LAYER_HEIGHT, maxHeight + PADDING);
      });
    }
    
    return heights;
  }, [layers, functionalAreas, technologies]);

  // Calculate layer Y offsets dynamically from calculated heights
  const layerYOffsets = useMemo(() => {
    const offsets: Record<string, number> = {};
    if (layers && layers.length > 0) {
      let currentY = 0;
      layers.forEach(layer => {
        offsets[layer.name] = currentY;
        currentY += dynamicLayerHeights[layer.name] || layer.height;
      });
    } else {
      // Fallback defaults
      offsets['host'] = 0;
      offsets['build'] = 160;
      offsets['adopt'] = 320;
      offsets['growth'] = 480;
      offsets['operations'] = 640;
    }
    return offsets;
  }, [layers, dynamicLayerHeights]);

  // Count technologies per functional area
  const techCountByArea = useMemo(() => {
    const counts: Record<string, number> = {};
    if (!technologies || !functionalAreas) return counts;
    
    functionalAreas.forEach(area => {
      counts[area.name] = technologies.filter(t => t.category === area.name).length;
    });
    return counts;
  }, [technologies, functionalAreas]);

  // Calculate dynamic area dimensions based on tech count
  const getAreaDimensions = (areaName: string, defaultWidth: number, defaultHeight: number) => {
    const techCount = techCountByArea[areaName] || 0;
    const TECH_CHIP_WIDTH = 100;
    const TECH_CHIP_HEIGHT = 36;
    const PADDING = 15;
    const HEADER_HEIGHT = 30;
    const GAP = 8;
    
    if (techCount === 0) {
      return { width: defaultWidth, height: defaultHeight };
    }
    
    // Calculate grid layout - 2 columns for narrow, 3 for wide
    const cols = Math.min(3, Math.max(2, Math.ceil(Math.sqrt(techCount))));
    const rows = Math.ceil(techCount / cols);
    
    const width = Math.max(defaultWidth, PADDING * 2 + cols * TECH_CHIP_WIDTH + (cols - 1) * GAP);
    const height = Math.max(defaultHeight, HEADER_HEIGHT + PADDING + rows * TECH_CHIP_HEIGHT + (rows - 1) * GAP + PADDING);
    
    return { width, height };
  };

  // Convert functional areas to canvas nodes with dynamic sizing
  const areaNodes: CanvasAreaNode[] = useMemo(() => {
    if (!functionalAreas) return [];
    
    const areasByLayer: Record<string, typeof functionalAreas> = {};
    functionalAreas.forEach(area => {
      if (!areasByLayer[area.layer]) areasByLayer[area.layer] = [];
      areasByLayer[area.layer].push(area);
    });

    // First pass: calculate sizes and positions for all areas
    const result: CanvasAreaNode[] = [];
    
    Object.entries(areasByLayer).forEach(([layerName, layerAreas]) => {
      let xOffset = 170;
      const GAP_BETWEEN_AREAS = 15;
      
      layerAreas.forEach((area) => {
        const saved = areaPositions[area.id];
        const { width, height } = getAreaDimensions(
          area.name,
          area.default_width ?? 200,
          area.default_height ?? 100
        );
        
        result.push({
          id: area.id,
          name: area.name,
          layer: area.layer,
          x: saved?.x ?? xOffset,
          y: saved?.y ?? (layerYOffsets[area.layer] ?? 0) + 25,
          width: saved?.width ?? width,
          height: saved?.height ?? height,
          color: area.color ?? '#fef9c3',
        });
        
        xOffset += width + GAP_BETWEEN_AREAS;
      });
    });
    
    return result;
  }, [functionalAreas, areaPositions, layerYOffsets, techCountByArea]);

  // Convert technologies to canvas tech nodes - positioned within their areas
  const techNodes: CanvasTechNode[] = useMemo(() => {
    if (!technologies) return [];
    
    const TECH_CHIP_WIDTH = 100;
    const TECH_CHIP_HEIGHT = 36;
    const PADDING = 12;
    const HEADER_HEIGHT = 28;
    const GAP = 8;
    
    // Group techs by their functional area
    const techsByArea: Record<string, typeof technologies> = {};
    technologies.forEach(tech => {
      if (!techsByArea[tech.category]) techsByArea[tech.category] = [];
      techsByArea[tech.category].push(tech);
    });
    
    return technologies.map((tech) => {
      const saved = techPositions[tech.id];
      if (saved) {
        return {
          id: tech.id,
          techId: tech.id,
          name: tech.name,
          functionalArea: tech.category,
          layer: tech.layer,
          x: saved.x,
          y: saved.y,
          isCompetitor: false,
          status: 'confirmed' as const,
        };
      }
      
      // Find the area this tech belongs to
      const area = areaNodes.find(a => a.name === tech.category);
      if (!area) {
        return {
          id: tech.id,
          techId: tech.id,
          name: tech.name,
          functionalArea: tech.category,
          layer: tech.layer,
          x: 200,
          y: (layerYOffsets[tech.layer] ?? 0) + 60,
          isCompetitor: false,
          status: 'confirmed' as const,
        };
      }
      
      // Calculate position within area using grid layout
      const techsInArea = techsByArea[tech.category] || [];
      const indexInArea = techsInArea.findIndex(t => t.id === tech.id);
      const cols = Math.min(3, Math.max(2, Math.ceil(Math.sqrt(techsInArea.length))));
      
      const col = indexInArea % cols;
      const row = Math.floor(indexInArea / cols);
      
      const x = area.x + PADDING + col * (TECH_CHIP_WIDTH + GAP);
      const y = area.y + HEADER_HEIGHT + row * (TECH_CHIP_HEIGHT + GAP);
      
      return {
        id: tech.id,
        techId: tech.id,
        name: tech.name,
        functionalArea: tech.category,
        layer: tech.layer,
        x,
        y,
        isCompetitor: false,
        status: 'confirmed' as const,
      };
    });
  }, [technologies, techPositions, areaNodes, layerYOffsets]);

  const handleAreasChange = (updated: CanvasAreaNode[]) => {
    const newPositions: Record<string, { x: number; y: number; width: number; height: number }> = {};
    updated.forEach(area => {
      newPositions[area.id] = { x: area.x, y: area.y, width: area.width, height: area.height };
    });
    setAreaPositions(newPositions);
  };

  const handleTechsChange = (updated: CanvasTechNode[]) => {
    const newPositions: Record<string, { x: number; y: number }> = {};
    updated.forEach(tech => {
      newPositions[tech.id] = { x: tech.x, y: tech.y };
    });
    setTechPositions(newPositions);
  };

  const handleDropTechnology = async (tech: TechnologyRepoItem, areaId: string, x: number, y: number) => {
    try {
      await createTech.mutateAsync({
        name: tech.name,
        category: tech.functional_area,
        layer: tech.layer,
        integration_type: 'core',
        description: tech.description,
      });
      
      // Don't save position - let the grid layout auto-position the tech
      // The techNodes useMemo will calculate the correct position within the area
      
      toast.success(`Added ${tech.name} to reference architecture`);
    } catch (error) {
      console.error('Failed to add technology:', error);
    }
  };

  const handleRemoveTechnology = async (techId: string) => {
    try {
      await deleteTech.mutateAsync(techId);
      setConnections(prev => prev.filter(c => c.fromTechId !== techId && c.toTechId !== techId));
      toast.success('Technology removed');
    } catch (error) {
      console.error('Failed to remove technology:', error);
    }
  };

  const handleSaveVersion = async () => {
    if (!versionName.trim()) {
      toast.error('Please enter a version name');
      return;
    }

    const snapshot: ArchitectureSnapshot = {
      functionalAreas: areaNodes,
      technologies: techNodes,
      connections: connections,
    };

    await saveVersion.mutateAsync({
      name: versionName,
      description: versionDescription,
      snapshot,
    });

    setShowSaveDialog(false);
    setVersionName('');
    setVersionDescription('');
  };

  const handleRestoreVersion = async (versionId: string, snapshot: ArchitectureSnapshot) => {
    // Restore positions from snapshot
    const newAreaPositions: Record<string, { x: number; y: number; width: number; height: number }> = {};
    snapshot.functionalAreas.forEach(area => {
      newAreaPositions[area.id] = { x: area.x, y: area.y, width: area.width, height: area.height };
    });
    setAreaPositions(newAreaPositions);

    const newTechPositions: Record<string, { x: number; y: number }> = {};
    snapshot.technologies.forEach(tech => {
      newTechPositions[tech.id] = { x: tech.x, y: tech.y };
    });
    setTechPositions(newTechPositions);

    setConnections(snapshot.connections.map(c => ({
      ...c,
      fromPort: c.fromPort as 'left' | 'right' | 'top' | 'bottom' | undefined,
      toPort: c.toPort as 'left' | 'right' | 'top' | 'bottom' | undefined,
    })));

    await restoreVersion.mutateAsync(versionId);
    setShowHistoryDialog(false);
  };

  const handleRollback = () => {
    if (!versions || currentVersionIndex <= 0) return;
    const prevVersion = versions[currentVersionIndex + 1]; // versions are sorted desc
    if (prevVersion) {
      handleRestoreVersion(prevVersion.id, prevVersion.snapshot);
    }
  };

  const handleRollforward = () => {
    if (!versions || currentVersionIndex < 0) return;
    const nextVersion = versions[currentVersionIndex - 1]; // versions are sorted desc
    if (nextVersion) {
      handleRestoreVersion(nextVersion.id, nextVersion.snapshot);
    }
  };

  const canRollback = versions && currentVersionIndex >= 0 && currentVersionIndex < versions.length - 1;
  const canRollforward = versions && currentVersionIndex > 0;
  const currentVersion = versions && currentVersionIndex >= 0 ? versions[currentVersionIndex] : null;

  const isLoading = techLoading || areasLoading || layersLoading;

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex h-full animate-fade-in">
      {/* Left Palette - Collapsible */}
      <div className={cn(
        "flex-shrink-0 transition-all duration-300 overflow-hidden border-r border-border",
        paletteCollapsed ? "w-0" : "w-72"
      )}>
        <TechnologyPalette onDragStart={() => {}} />
      </div>

      {/* Main Canvas Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-background">
          <div className="flex items-center gap-3">
            {/* Palette Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setPaletteCollapsed(!paletteCollapsed)}
              title={paletteCollapsed ? "Show technology palette" : "Hide technology palette"}
            >
              {paletteCollapsed ? <PanelLeft className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
            </Button>
            
            <div>
              <h1 className="page-heading">Reference Architecture</h1>
              <p className="text-sm text-muted-foreground">
                Define the ideal integration landscape
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Version Controls */}
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleRollback}
                disabled={!canRollback}
                title="Rollback to previous version"
              >
                <RotateCcw className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleRollforward}
                disabled={!canRollforward}
                title="Roll forward to next version"
              >
                <RotateCw className="w-4 h-4" />
              </Button>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <History className="w-4 h-4" />
                  {currentVersion ? `v${currentVersion.version_number}` : 'No version'}
                  <ChevronDown className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64">
                {versions && versions.length > 0 ? (
                  <>
                    {versions.slice(0, 5).map((version) => (
                      <DropdownMenuItem
                        key={version.id}
                        onClick={() => handleRestoreVersion(version.id, version.snapshot)}
                        className="flex flex-col items-start"
                      >
                        <div className="flex items-center gap-2 w-full">
                          <span className="font-medium">v{version.version_number}: {version.name}</span>
                          {version.is_current && (
                            <Badge variant="secondary" className="text-xs ml-auto">Current</Badge>
                          )}
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(version.created_at), 'MMM d, h:mm a')}
                        </span>
                      </DropdownMenuItem>
                    ))}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => setShowHistoryDialog(true)}>
                      View all versions...
                    </DropdownMenuItem>
                  </>
                ) : (
                  <DropdownMenuItem disabled>No saved versions</DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button onClick={() => setShowSaveDialog(true)} size="sm" variant="outline" className="gap-2">
              <Save className="w-4 h-4" />
              Save Version
            </Button>

            {/* Layers Button - Opens Sheet */}
            <Sheet open={layerSheetOpen} onOpenChange={setLayerSheetOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm">
                  <SlidersHorizontal className="w-4 h-4 mr-2" />
                  Layers
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom" className="h-[400px]">
                <SheetHeader>
                  <SheetTitle>Manage Layers</SheetTitle>
                </SheetHeader>
                <div className="mt-4 h-[320px] overflow-auto">
                  <LayerPanel />
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Stats Row */}
        <div className="flex items-center gap-4 px-4 py-2 border-b border-border bg-muted/30">
          <Badge variant="outline" className="text-xs">
            <Layers className="w-3 h-3 mr-1" />
            {technologies?.length || 0} technologies
          </Badge>
          <Badge variant="outline" className="text-xs">
            {areaNodes.length} functional areas
          </Badge>
          <Badge variant="outline" className="text-xs">
            <Star className="w-3 h-3 mr-1" />
            {technologies?.filter(t => t.integration_type === 'core').length || 0} core
          </Badge>
        </div>

        {/* Canvas */}
        <div className="flex-1 overflow-auto p-4">
          <div className="bg-card rounded-xl border border-border overflow-hidden min-h-[700px]">
            <FunctionalAreaCanvas
              areas={areaNodes}
              technologies={techNodes}
              connections={connections}
              layers={layers}
              layerHeights={dynamicLayerHeights}
              onAreasChange={handleAreasChange}
              onTechnologiesChange={handleTechsChange}
              onConnectionsChange={setConnections}
              onDropTechnology={handleDropTechnology}
              onRemoveTechnology={handleRemoveTechnology}
              onAddArea={async (area) => {
                await createArea.mutateAsync({
                  name: area.name,
                  layer: area.layer,
                  color: area.color,
                  description: null,
                  default_width: 200,
                  default_height: 100,
                  sort_order: functionalAreas?.length || 0,
                });
              }}
              onEditArea={async (id, updates) => {
                await updateArea.mutateAsync({ id, ...updates });
              }}
              onDeleteArea={async (id) => {
                await deleteArea.mutateAsync(id);
              }}
              mode="reference"
              height={850}
            />
          </div>
        </div>
      </div>

      {/* Save Version Dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Architecture Version</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Version Name *</Label>
              <Input
                placeholder="e.g., Initial Setup, Q1 2024 Update"
                value={versionName}
                onChange={(e) => setVersionName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Description (optional)</Label>
              <Textarea
                placeholder="Describe what changed in this version..."
                value={versionDescription}
                onChange={(e) => setVersionDescription(e.target.value)}
                rows={3}
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveVersion} disabled={saveVersion.isPending}>
                {saveVersion.isPending ? 'Saving...' : 'Save Version'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* History Dialog */}
      <Dialog open={showHistoryDialog} onOpenChange={setShowHistoryDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Version History</DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[400px] mt-4">
            <div className="space-y-2">
              {versions?.map((version) => (
                <div
                  key={version.id}
                  className={`p-3 rounded-lg border transition-colors cursor-pointer hover:border-primary ${
                    version.is_current ? 'border-primary bg-primary/5' : 'border-border'
                  }`}
                  onClick={() => handleRestoreVersion(version.id, version.snapshot)}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">v{version.version_number}: {version.name}</span>
                        {version.is_current && (
                          <Badge variant="secondary" className="text-xs">Current</Badge>
                        )}
                      </div>
                      {version.description && (
                        <p className="text-sm text-muted-foreground mt-1">{version.description}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">
                        {format(new Date(version.created_at), 'MMMM d, yyyy at h:mm a')}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm">
                      Restore
                    </Button>
                  </div>
                </div>
              ))}
              {(!versions || versions.length === 0) && (
                <p className="text-center text-muted-foreground py-8">
                  No saved versions yet. Click "Save Version" to create your first snapshot.
                </p>
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
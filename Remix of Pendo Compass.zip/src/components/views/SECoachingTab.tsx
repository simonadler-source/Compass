import { useState, useMemo, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTeamCoachingScores, aggregateSEStats, SECoachingScore, useDeleteCoachingScore } from '@/hooks/useSECoachingScores';
import { useManagerDashboard } from '@/hooks/useManagerDashboard';
import { useOrgTree, OrgNode, collectSubtreeEmails } from '@/hooks/useOrgTree';
import { useUserRole } from '@/hooks/useUserRole';
import OrgTreePicker from '@/components/OrgTreePicker';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { gateway } from '@/lib/apiGateway';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScoreSparkline } from '@/components/ui/score-sparkline';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { 
  Users, Award, MessageSquare, Target, ChevronDown, ChevronRight, 
  Mic, Timer, Quote, Lightbulb, AlertTriangle, ArrowRight, TrendingUp, TrendingDown, Minus,
  ThumbsUp, ThumbsDown, GraduationCap, Info, FileDown, Trash2, Network
} from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { exportCoachingPdf } from '@/lib/exportCoachingPdf';

const DIMENSION_LABELS: Record<string, string> = {
  pov_challenge_score: 'POV & Challenge',
  ownership_control_score: 'Ownership & Control',
  storytelling_proof_score: 'Storytelling',
  reverse_demo_score: 'Reverse Demo',
  champion_arming_score: 'Champion Arming',
  objection_handling_score: 'Objection Handling',
  pain_quantification_score: 'Pain Quantification',
  questioning_score: 'Questioning',
  differentiation_score: 'Differentiation',
  strategy_rigor_score: 'Strategy & Rigor',
  technical_competency_score: 'Technical Competency',
  value_anchoring_score: 'Value Anchoring',
  energy_inspiration_score: 'Energy & Inspiration',
};

const DIMENSION_TOOLTIPS: Record<string, string> = {
  pov_challenge_score: 'Did the SE present a clear point of view, challenge assumptions, and push the prospect to think differently about their problem?',
  ownership_control_score: 'Did the SE maintain control of the conversation flow, set agendas, establish next steps, and guide the discussion purposefully?',
  storytelling_proof_score: 'Did the SE use customer stories, case studies, or concrete examples to prove value rather than just listing features?',
  reverse_demo_score: 'Did the SE ask the prospect to demonstrate their current workflow or articulate their process before showing the solution?',
  champion_arming_score: 'Did the SE equip internal advocates with the language, data, and materials needed to sell internally on their behalf?',
  objection_handling_score: 'Did the SE address concerns directly, reframe objections as opportunities, and use evidence to overcome resistance?',
  pain_quantification_score: 'Did the SE help the prospect quantify the cost of inaction — in time, money, risk, or opportunity cost?',
  questioning_score: 'Did the SE ask open-ended, layered questions that uncovered real needs rather than leading or surface-level questions?',
  differentiation_score: 'Did the SE clearly articulate what makes the solution uniquely better than alternatives for this specific prospect?',
  strategy_rigor_score: 'Did the SE demonstrate preparation, account knowledge, and a strategic approach tailored to the prospect\'s situation?',
  technical_competency_score: 'How effectively did the SE demonstrate the product? Measured by prospect affirmations, SE depth expansion, confusion/rework signals, and engagement questions.',
  value_anchoring_score: 'Did the SE connect each demonstrated capability to the prospect\'s specific needs? Measures the ratio of features anchored to customer value vs. features presented in isolation (feature dumping).',
  energy_inspiration_score: 'Did the SE deliver with vocal variety and enthusiasm that inspires the prospect? Scored across 5 delivery techniques: Pitch Variation, Value Word Emphasis, Pace Variation, Vocal Warmth, and Verbal Highlighters.',
};

const DELIVERY_TECHNIQUE_LABELS: Record<string, string> = {
  pitch_variation: 'Pitch Variation (Staircase)',
  value_word_emphasis: 'Value Word Emphasis',
  pace_variation: 'Pace Variation (BPM)',
  vocal_warmth: 'Vocal Warmth',
  verbal_highlighters: 'Verbal Highlighters',
};

function getScoreColor(score: number | null): string {
  if (score == null) return 'text-muted-foreground';
  if (score >= 4) return 'text-green-600';
  if (score >= 3) return 'text-amber-600';
  return 'text-red-600';
}

function getScoreBg(score: number | null): string {
  if (score == null) return 'bg-muted';
  if (score >= 4) return 'bg-green-500/20';
  if (score >= 3) return 'bg-amber-500/20';
  return 'bg-red-500/20';
}

function ScoreCell({ score }: { score: number | null }) {
  if (score == null) return <span className="text-muted-foreground">—</span>;
  return (
    <span className={cn("font-semibold", getScoreColor(score))}>
      {score.toFixed(1)}
    </span>
  );
}

function TrendIcon({ trend }: { trend: 'improving' | 'declining' | 'stable' | null }) {
  if (!trend) return null;
  if (trend === 'improving') return <TrendingUp className="h-3 w-3 text-green-600" />;
  if (trend === 'declining') return <TrendingDown className="h-3 w-3 text-red-600" />;
  return <Minus className="h-3 w-3 text-muted-foreground" />;
}

function TalkRatioTooltip({ score }: { score: SECoachingScore }) {
  const seTalk = score.se_talk_ratio != null ? Math.round(score.se_talk_ratio) : null;
  const customerTalk = seTalk != null ? 100 - seTalk : null;
  const inRange = seTalk != null && score.target_talk_ratio_min != null && score.target_talk_ratio_max != null
    && seTalk >= score.target_talk_ratio_min && seTalk <= score.target_talk_ratio_max;

  return (
    <TooltipContent side="top" className="max-w-[260px] p-3 space-y-2">
      <p className="text-xs font-medium">Talk Time Breakdown</p>
      <div className="space-y-1 text-xs">
        <div className="flex justify-between">
          <span>SE Talk Time</span>
          <span className={cn("font-semibold", inRange ? 'text-green-600' : 'text-amber-600')}>
            {seTalk != null ? `${seTalk}%` : '—'}
          </span>
        </div>
        <div className="flex justify-between">
          <span>Customer Talk Time</span>
          <span className="font-semibold">{customerTalk != null ? `${customerTalk}%` : '—'}</span>
        </div>
        {score.target_talk_ratio_min != null && score.target_talk_ratio_max != null && (
          <div className="flex justify-between border-t border-border pt-1 mt-1">
            <span>Ideal SE Range</span>
            <span className="text-muted-foreground">{Math.round(score.target_talk_ratio_min)}–{Math.round(score.target_talk_ratio_max)}%</span>
          </div>
        )}
        {score.avg_words_per_minute != null && (
          <div className="flex justify-between">
            <span>Pace</span>
            <span className="text-muted-foreground">{Math.round(score.avg_words_per_minute)} wpm</span>
          </div>
        )}
        {score.pause_for_impact_count > 0 && (
          <div className="flex justify-between">
            <span>Pauses for Impact</span>
            <span className="text-muted-foreground">{score.pause_for_impact_count}</span>
          </div>
        )}
        {score.rushed_speech_detected && (
          <p className="text-amber-600 text-[10px] mt-1">⚡ Rushed speech detected</p>
        )}
      </div>
    </TooltipContent>
  );
}

/** Expandable individual call row */
function CallDetailRow({ score, onDelete }: { score: SECoachingScore; onDelete: (id: string) => void }) {
  const [expanded, setExpanded] = useState(false);
  const whatWorked = (score.what_worked_well as Array<{snippet: string; explanation: string; timecode?: string}>) || [];
  const whatDidnt = (score.what_didnt_work as Array<{snippet: string; explanation: string; timecode?: string}>) || [];
  const guidance = (score.coaching_guidance as Array<{pattern_observed: string; technique: string; expected_impact: string}>) || [];

  return (
    <>
      <TableRow className="cursor-pointer hover:bg-muted/50" onClick={() => setExpanded(!expanded)}>
        <TableCell className="text-xs w-6">
          {expanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
        </TableCell>
        <TableCell className="text-xs">{format(new Date(score.meeting_date || score.analyzed_at), 'MMM d, yyyy')}</TableCell>
        <TableCell className="text-xs max-w-[160px] truncate" title={score.opportunity_name || ''}>
          {score.opportunity_id && score.opportunity_name ? (
            <a 
              href={`/opportunities/${score.opportunity_id}`}
              className="text-primary hover:underline"
              onClick={(e) => e.stopPropagation()}
            >
              {score.opportunity_name}
            </a>
          ) : (
            <span className="text-muted-foreground">—</span>
          )}
        </TableCell>
        <TableCell>
          <Badge variant="outline" className="text-xs">{score.meeting_type.replace(/_/g, ' ')}</Badge>
        </TableCell>
        <TableCell><ScoreCell score={score.overall_score} /></TableCell>
        <TableCell>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span className={cn(
                  "text-xs cursor-help underline decoration-dotted",
                  score.se_talk_ratio != null && score.target_talk_ratio_min != null && score.target_talk_ratio_max != null &&
                  score.se_talk_ratio >= score.target_talk_ratio_min && score.se_talk_ratio <= score.target_talk_ratio_max
                    ? 'text-green-600' : 'text-amber-600'
                )}>
                  {score.se_talk_ratio != null ? `${Math.round(score.se_talk_ratio)}%` : '—'}
                </span>
              </TooltipTrigger>
              <TalkRatioTooltip score={score} />
            </Tooltip>
          </TooltipProvider>
        </TableCell>
        <TableCell>
          <Badge variant="outline" className={cn("text-xs", 
            score.prospect_sentiment === 'positive' && 'border-green-500/50 text-green-600',
            score.prospect_sentiment === 'negative' && 'border-red-500/50 text-red-600',
            score.prospect_sentiment === 'neutral' && 'border-muted-foreground/50',
          )}>
            {score.prospect_sentiment || '—'}
          </Badge>
        </TableCell>
        <TableCell className="text-xs max-w-[200px] truncate" title={score.greatness_moment || ''}>
          {score.greatness_moment || '—'}
        </TableCell>
      </TableRow>
      {expanded && (
        <TableRow>
          <TableCell colSpan={8} className="p-0">
            <div className="p-4 bg-muted/30 border-t space-y-4">
              {/* Export button */}
              <div className="flex justify-end gap-2">
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" size="sm" className="text-destructive hover:text-destructive" onClick={(e) => e.stopPropagation()}>
                      <Trash2 className="h-3.5 w-3.5 mr-1.5" />
                      Delete
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete coaching record?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently remove this coaching analysis. You can re-run the analysis later from the transcript.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => onDelete(score.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <Button variant="outline" size="sm" onClick={(e) => { e.stopPropagation(); exportCoachingPdf(score); }}>
                  <FileDown className="h-3.5 w-3.5 mr-1.5" />
                  Export PDF
                </Button>
              </div>
              {/* Per-call dimension scores */}
              <div className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-6 gap-2">
                <TooltipProvider>
                  {Object.entries(DIMENSION_LABELS).map(([dim, label]) => {
                    const val = score[dim as keyof SECoachingScore] as number | null;
                    const weightKey = dim.replace('_score', '');
                    const weight = score.weights_used?.[weightKey];
                    const weightPct = weight != null ? Math.round(weight * 100) : null;
                    const breakdown = dim === 'energy_inspiration_score' ? (score as any).energy_delivery_breakdown : null;
                    return (
                      <Tooltip key={dim}>
                        <TooltipTrigger asChild>
                          <div className={cn("p-1.5 rounded text-center cursor-help", getScoreBg(val))}>
                            <p className="text-[10px] text-muted-foreground">{label}</p>
                            <p className={cn("text-sm font-bold", getScoreColor(val))}>{val != null ? val.toFixed(1) : '—'}</p>
                            {weightPct != null && (
                              <p className="text-[9px] text-muted-foreground/70">Weight: {weightPct}%</p>
                            )}
                          </div>
                        </TooltipTrigger>
                        <TooltipContent side="top" className={cn("text-xs", breakdown ? "max-w-[380px]" : "max-w-[280px]")}>
                          <p className="mb-1">{DIMENSION_TOOLTIPS[dim]}</p>
                          {breakdown && (
                            <div className="border-t border-border pt-1.5 mt-1.5 space-y-1.5">
                              <p className="font-medium text-[11px]">Delivery Technique Breakdown:</p>
                              {Object.entries(DELIVERY_TECHNIQUE_LABELS).map(([techKey, techLabel]) => {
                                const techScore = breakdown[`${techKey}_score` as keyof typeof breakdown] as number | undefined;
                                const techEvidence = breakdown[`${techKey}_evidence` as keyof typeof breakdown] as string | undefined;
                                return (
                                  <div key={techKey} className="space-y-0.5">
                                    <div className="flex items-center justify-between gap-2">
                                      <span className="text-muted-foreground">{techLabel}</span>
                                      <span className={cn("font-bold", getScoreColor(techScore ?? null))}>{techScore != null ? `${techScore}/5` : '—'}</span>
                                    </div>
                                    {techEvidence && (
                                      <p className="text-[10px] text-muted-foreground/80 italic pl-1 leading-tight">{techEvidence}</p>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </TooltipContent>
                      </Tooltip>
                    );
                  })}
                </TooltipProvider>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Good Moments */}
                {whatWorked.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-medium flex items-center gap-1.5 text-green-600">
                      <ThumbsUp className="h-3.5 w-3.5" /> Good Moments
                    </p>
                    {whatWorked.map((item, i) => (
                      <div key={i} className="space-y-1">
                        <div className="bg-green-500/5 rounded-md p-2 border border-green-500/10">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <Quote className="h-3 w-3 text-green-600 mt-0.5 shrink-0" />
                            {item.timecode && (
                              <span className="flex items-center gap-0.5 text-[10px] text-green-700/70 bg-green-500/10 px-1.5 py-0.5 rounded font-mono shrink-0">
                                <Timer className="h-2.5 w-2.5" />
                                {item.timecode}
                              </span>
                            )}
                          </div>
                          <p className="text-xs italic text-foreground/90">"{item.snippet}"</p>
                        </div>
                        <p className="text-[11px] text-muted-foreground pl-1">{item.explanation}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Moments for Improvement */}
                {whatDidnt.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-medium flex items-center gap-1.5 text-amber-600">
                      <AlertTriangle className="h-3.5 w-3.5" /> Moments for Improvement
                    </p>
                    {whatDidnt.map((item, i) => {
                      const matchedTip = guidance[i];
                      return (
                        <div key={i} className="space-y-1">
                          <div className="bg-amber-500/5 rounded-md p-2 border border-amber-500/10">
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <Quote className="h-3 w-3 text-amber-600 mt-0.5 shrink-0" />
                              {item.timecode && (
                                <span className="flex items-center gap-0.5 text-[10px] text-amber-700/70 bg-amber-500/10 px-1.5 py-0.5 rounded font-mono shrink-0">
                                  <Timer className="h-2.5 w-2.5" />
                                  {item.timecode}
                                </span>
                              )}
                            </div>
                            <p className="text-xs italic text-foreground/90">"{item.snippet}"</p>
                          </div>
                          <p className="text-[11px] text-muted-foreground pl-1">{item.explanation}</p>
                          {matchedTip && (
                            <div className="bg-primary/5 rounded-md p-2 border border-primary/10">
                              <p className="text-[11px] font-medium text-primary flex items-center gap-1">
                                <Lightbulb className="h-3 w-3" /> What to do instead
                              </p>
                              <p className="text-[11px] text-muted-foreground mt-0.5">{matchedTip.technique}</p>
                              <p className="text-[10px] text-muted-foreground/70 mt-0.5">
                                <span className="font-medium">Impact:</span> {matchedTip.expected_impact}
                              </p>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </TableCell>
        </TableRow>
      )}
    </>
  );
}

function SEDetailCard({ seEmail, scores, onDelete }: { seEmail: string; scores: SECoachingScore[]; onDelete: (id: string) => void }) {
  const [expanded, setExpanded] = useState(false);
  const stats = useMemo(() => aggregateSEStats(scores), [scores]);
  
  if (!stats) return null;

  return (
    <Collapsible open={expanded} onOpenChange={setExpanded}>
      <Card className="overflow-hidden">
        <CollapsibleTrigger className="w-full">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Users className="h-5 w-5 text-primary" />
                </div>
                <div className="text-left">
                  <p className="font-medium">{seEmail}</p>
                  <p className="text-xs text-muted-foreground">{stats.meetingCount} meetings scored</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right flex items-center gap-1.5">
                  <div>
                    <p className={cn("text-2xl font-bold", getScoreColor(stats.avgScore))}>
                      {stats.avgScore}
                    </p>
                    <p className="text-xs text-muted-foreground">Avg Score</p>
                  </div>
                  <TrendIcon trend={stats.overallTrend} />
                </div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Badge variant="outline" className="text-xs cursor-help">
                        <Mic className="h-3 w-3 mr-1" />
                        {stats.avgTalkRatio}% talk
                      </Badge>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="max-w-[240px] p-3 space-y-1.5">
                      <p className="text-xs font-medium">Average Talk Time</p>
                      <div className="text-xs space-y-0.5">
                        <div className="flex justify-between">
                          <span>SE Talk (avg)</span>
                          <span className="font-semibold">{stats.avgTalkRatio}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Customer Talk (avg)</span>
                          <span className="font-semibold">{100 - stats.avgTalkRatio}%</span>
                        </div>
                      </div>
                      <p className="text-[10px] text-muted-foreground pt-1">Averaged across {stats.meetingCount} calls. Hover each call for per-call breakdown.</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                {expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </div>
            </div>
          </CardContent>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="border-t px-4 pb-4 space-y-4">
            {/* Dimension averages with trends */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 pt-3">
              <TooltipProvider>
              {Object.entries(stats.dimensionAvgs).map(([dim, avg]) => {
                if (avg == null) return null;
                const trend = stats.dimensionTrends[dim];
                return (
                  <Tooltip key={dim}>
                    <TooltipTrigger asChild>
                      <div className={cn("p-2 rounded-md cursor-help", getScoreBg(avg))}>
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          {DIMENSION_LABELS[dim] || dim}
                          <Info className="h-3 w-3 opacity-50" />
                        </p>
                        <div className="flex items-center gap-1">
                          <p className={cn("text-lg font-bold", getScoreColor(avg))}>{avg.toFixed(1)}</p>
                          <TrendIcon trend={trend} />
                        </div>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="max-w-[280px] text-xs space-y-1">
                      <p>{DIMENSION_TOOLTIPS[dim] || 'No description available.'}</p>
                      {trend && (
                        <p className={cn("text-[10px]",
                          trend === 'improving' && 'text-green-600',
                          trend === 'declining' && 'text-red-600',
                          trend === 'stable' && 'text-muted-foreground',
                        )}>
                          Trend: {trend === 'improving' ? '↑ Improving' : trend === 'declining' ? '↓ Declining' : '→ Stable'}
                        </p>
                      )}
                    </TooltipContent>
                  </Tooltip>
                );
              })}
              </TooltipProvider>
            </div>

            {/* Expandable call rows */}
            <div>
              <p className="text-sm font-medium mb-2">Individual Calls</p>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-6"></TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Opportunity</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Overall</TableHead>
                    <TableHead>Talk %</TableHead>
                    <TableHead>Sentiment</TableHead>
                    <TableHead>Greatness Moment</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                {stats.recentScores.map(score => (
                    <CallDetailRow key={score.id} score={score} onDelete={onDelete} />
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}

const DIMENSION_KEYS = Object.keys(DIMENSION_LABELS) as (keyof typeof DIMENSION_LABELS)[];

function DimensionRollupGrid({ scores, title, subtitle }: { scores: SECoachingScore[]; title?: string; subtitle?: string }) {
  const rollups = useMemo(() => {
    return DIMENSION_KEYS.map((dim) => {
      const chronological = [...scores].sort((a, b) =>
        new Date(a.meeting_date || a.analyzed_at).getTime() - new Date(b.meeting_date || b.analyzed_at).getTime()
      );

      const vals = chronological
        .map(s => ({ date: s.meeting_date || s.analyzed_at, value: s[dim as keyof SECoachingScore] as number | null }))
        .filter((d): d is { date: string; value: number } => d.value != null);

      const avg = vals.length ? vals.reduce((sum, d) => sum + d.value, 0) / vals.length : null;

      let trend: 'improving' | 'declining' | 'stable' | null = null;
      if (vals.length >= 4) {
        const third = Math.floor(vals.length / 3);
        const older = vals.slice(0, third);
        const newer = vals.slice(-third);
        const olderAvg = older.reduce((s, d) => s + d.value, 0) / older.length;
        const newerAvg = newer.reduce((s, d) => s + d.value, 0) / newer.length;
        const diff = newerAvg - olderAvg;
        trend = diff > 0.2 ? 'improving' : diff < -0.2 ? 'declining' : 'stable';
      }

      return { dim, avg, vals, trend };
    });
  }, [scores]);

  if (!scores.length) return null;

  const sorted = [...rollups].sort((a, b) => (a.avg ?? 5) - (b.avg ?? 5));

  return (
    <div className="space-y-2">
      <div>
        <h3 className="text-sm font-semibold">{title || 'Team Dimension Breakdown'}</h3>
        <p className="text-xs text-muted-foreground">{subtitle || 'Averaged across all scored calls — weakest areas first'}</p>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <TooltipProvider>
          {sorted.map(({ dim, avg, vals, trend }) => (
            <Tooltip key={dim}>
              <TooltipTrigger asChild>
                <Card className={cn(
                  "cursor-help border transition-colors hover:border-primary/40",
                  avg != null && avg < 3 && "border-destructive/30 bg-destructive/5",
                  avg != null && avg >= 4 && "border-green-500/30 bg-green-500/5",
                )}>
                  <CardContent className="p-3 space-y-1.5">
                    <p className="text-[11px] text-muted-foreground leading-tight">{DIMENSION_LABELS[dim]}</p>
                    <div className="flex items-end justify-between gap-2">
                      <p className={cn("text-xl font-bold", getScoreColor(avg))}>
                        {avg != null ? avg.toFixed(1) : '—'}
                      </p>
                      {vals.length >= 2 && (
                        <ScoreSparkline
                          data={vals}
                          height={28}
                          width={52}
                          showTooltip={false}
                        />
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      {trend === 'improving' && <TrendingUp className="h-3 w-3 text-green-600" />}
                      {trend === 'declining' && <TrendingDown className="h-3 w-3 text-destructive" />}
                      {trend === 'stable' && <Minus className="h-3 w-3 text-muted-foreground" />}
                      <p className="text-[10px] text-muted-foreground">{vals.length} calls</p>
                    </div>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent side="top" className="max-w-[280px] text-xs space-y-1">
                <p className="font-medium">{DIMENSION_LABELS[dim]}</p>
                <p>{DIMENSION_TOOLTIPS[dim]}</p>
                {trend && (
                  <p className={cn("text-[10px] pt-0.5",
                    trend === 'improving' && 'text-green-600',
                    trend === 'declining' && 'text-destructive',
                    trend === 'stable' && 'text-muted-foreground',
                  )}>
                    Trend: {trend === 'improving' ? '↑ Improving' : trend === 'declining' ? '↓ Declining' : '→ Stable'}
                  </p>
                )}
              </TooltipContent>
            </Tooltip>
          ))}
        </TooltipProvider>
      </div>
    </div>
  );
}

// OrgTreePicker extracted to shared component: @/components/OrgTreePicker

export default function SECoachingTab({ seEmailFilter }: { seEmailFilter?: string }) {
  const { teamEmailsWithSelf } = useManagerDashboard();
  const { roots, nodeMap, isManager: isOrgManager, currentUserId, isLoading: orgLoading } = useOrgTree();
  const { effectiveUserEmail, effectiveUserId } = useAuth();
  const { isManager: hasManagerRole, isAdmin } = useUserRole();
  const [days, setDays] = useState(90);
  const [selectedTeamNodeId, setSelectedTeamNodeId] = useState<string | null>(null);

  // A user can browse the full org tree only if they have manager/admin role
  const canBrowseFullTree = hasManagerRole || isAdmin;

  // For non-manager/non-admin users, fetch their branch (peers + own subtree) via get_team_branch
  const { data: branchData } = useQuery({
    queryKey: ['coaching-branch-emails', effectiveUserId],
    queryFn: async () => {
      if (!effectiveUserId) return [];
      const { data, error } = await supabase
        .rpc('get_team_branch', { _user_id: effectiveUserId });
      if (error) throw error;
      return data as Array<{ user_id: string; depth: number }>;
    },
    enabled: !!effectiveUserId && !canBrowseFullTree && !seEmailFilter,
    staleTime: 5 * 60 * 1000,
  });

  // Resolve branch user IDs to emails
  const branchUserIds = branchData?.map(b => b.user_id) || [];
  const { data: branchProfiles } = useQuery({
    queryKey: ['coaching-branch-profiles', branchUserIds],
    queryFn: async () => {
      if (!branchUserIds.length) return [];
      const result = await gateway.from('profiles')
        .select('id, email')
        .in('id', branchUserIds)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return (result.data || []).map((p: any) => (p.email as string).toLowerCase());
    },
    enabled: branchUserIds.length > 0 && !canBrowseFullTree && !seEmailFilter,
    staleTime: 5 * 60 * 1000,
  });

  // Determine default selected node (current user if manager, or their manager)
  const effectiveSelectedId = selectedTeamNodeId || currentUserId || null;
  const selectedNode = effectiveSelectedId ? nodeMap.get(effectiveSelectedId) : null;

  // Compute emails based on selected team node and role
  const selectedTeamEmails = useMemo(() => {
    if (seEmailFilter) return [seEmailFilter];
    
    // Non-manager/non-admin: restrict to branch emails only
    if (!canBrowseFullTree) {
      if (branchProfiles && branchProfiles.length > 0) return branchProfiles;
      // Fallback to just self while branch loads
      return effectiveUserEmail ? [effectiveUserEmail.toLowerCase()] : [];
    }
    
    // Manager/admin: use org tree selection or team emails
    if (selectedNode) return collectSubtreeEmails(selectedNode);
    return teamEmailsWithSelf || [];
  }, [seEmailFilter, canBrowseFullTree, branchProfiles, effectiveUserEmail, selectedNode, teamEmailsWithSelf]);

  // If seEmailFilter is set (SE self-view), only fetch their own scores
  const emailsToFetch = selectedTeamEmails;
  const { data: scores = [] as SECoachingScore[], isLoading } = useTeamCoachingScores(emailsToFetch, days);
  
  // Always fetch team-wide scores for the Team Dimension Breakdown so it's consistent across all viewers
  const teamEmails = selectedTeamEmails;
  const { data: teamScores = [] as SECoachingScore[] } = useTeamCoachingScores(teamEmails, days);
  
  const deleteScore = useDeleteCoachingScore();

  // Group by SE
  const bySE = useMemo(() => {
    const grouped: Record<string, SECoachingScore[]> = {};
    for (const s of scores) {
      if (!grouped[s.se_email]) grouped[s.se_email] = [];
      grouped[s.se_email].push(s);
    }
    return grouped;
  }, [scores]);

  // Team-wide stats
  const teamStats = useMemo(() => {
    if (!scores.length) return null;
    const avgOverall = scores.reduce((sum, s) => sum + (s.overall_score || 0), 0) / scores.length;
    const meetingTypes: Record<string, number> = {};
    scores.forEach(s => { meetingTypes[s.meeting_type] = (meetingTypes[s.meeting_type] || 0) + 1; });
    return {
      totalMeetings: scores.length,
      teamMembers: Object.keys(bySE).length,
      avgOverall: Math.round(avgOverall * 10) / 10,
      meetingTypes,
    };
  }, [scores, bySE]);

  // Sort SEs by average score ascending (worst first for coaching priority)
  const sortedSEs = useMemo(() => {
    return Object.entries(bySE).sort(([, a], [, b]) => {
      const aAvg = a.reduce((sum, s) => sum + (s.overall_score || 0), 0) / a.length;
      const bAvg = b.reduce((sum, s) => sum + (s.overall_score || 0), 0) / b.length;
      return aAvg - bAvg;
    });
  }, [bySE]);

  if (isLoading) {
    return <div className="flex items-center justify-center h-64 text-muted-foreground">Loading coaching data...</div>;
  }

  const isSelfView = !!seEmailFilter;
  const myScores = isSelfView ? scores : undefined;
  const myStats = isSelfView && myScores ? aggregateSEStats(myScores) : undefined;

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Award className="h-5 w-5 text-amber-500" />
            {isSelfView ? 'My Coaching Scorecard' : 'SE Coaching Scorecard'}
          </h2>
          <p className="text-sm text-muted-foreground">
            {isSelfView
              ? 'Your personal performance scores by meeting type'
              : 'Performance scoring by meeting type with evidence-based coaching'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* Team selector — only for managers/admins who can browse the full org */}
          {!isSelfView && canBrowseFullTree && roots.length > 0 && (
            <OrgTreePicker
              roots={roots}
              selectedId={effectiveSelectedId}
              onSelect={(node) => setSelectedTeamNodeId(node.id)}
            />
          )}
          <Select value={String(days)} onValueChange={(v) => setDays(Number(v))}>
            <SelectTrigger className="w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="60">Last 60 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
              <SelectItem value="180">Last 6 months</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* KPIs — team view shows team stats; SE self-view shows personal stats */}
      {isSelfView ? (
        myStats && (
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className={cn("text-2xl font-bold", getScoreColor(myStats.avgScore))}>{myStats.avgScore}</p>
                    <p className="text-xs text-muted-foreground">Avg Score</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-2xl font-bold">{myStats.meetingCount}</p>
                    <p className="text-xs text-muted-foreground">Meetings Scored</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )
      ) : (
        teamStats && (
          <div className="grid grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className={cn("text-2xl font-bold", getScoreColor(teamStats.avgOverall))}>{teamStats.avgOverall}</p>
                    <p className="text-xs text-muted-foreground">Team Avg Score</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-2xl font-bold">{teamStats.totalMeetings}</p>
                    <p className="text-xs text-muted-foreground">Meetings Scored</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-2xl font-bold">{teamStats.teamMembers}</p>
                    <p className="text-xs text-muted-foreground">SEs Scored</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )
      )}

      {/* Meeting type pills */}
      {(() => {
        const typeCounts = isSelfView
          ? scores.reduce((acc, s) => { acc[s.meeting_type] = (acc[s.meeting_type] || 0) + 1; return acc; }, {} as Record<string, number>)
          : teamStats?.meetingTypes || {};
        const entries = Object.entries(typeCounts);
        if (entries.length === 0) return null;
        return (
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-muted-foreground mr-1">Meeting Types:</span>
            {entries
              .sort(([, a], [, b]) => (b as number) - (a as number))
              .map(([type, count]) => (
                <Badge key={type} variant="outline" className="text-xs">
                  {type.replace(/_/g, ' ')} ({count})
                </Badge>
              ))}
          </div>
        );
      })()}

      {/* No data state */}
      {!scores.length && (
        <Card>
          <CardContent className="p-8 text-center text-muted-foreground">
            <Award className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p className="font-medium">No coaching scores yet</p>
            <p className="text-sm mt-1">Coaching analysis runs automatically for demos and evaluations, or can be triggered manually on any transcript.</p>
          </CardContent>
        </Card>
      )}

      {/* Team Dimension Breakdown — always uses full team scores for consistency */}
      {teamScores.length > 0 && (
        <DimensionRollupGrid 
          scores={teamScores} 
          title={selectedNode ? `${selectedNode.full_name || selectedNode.email}'s Org — Dimension Breakdown` : 'Team Dimension Breakdown'}
          subtitle={`Averaged across all ${teamScores.length} scored calls — weakest areas first`}
        />
      )}
      {/* Personal Dimension Breakdown — only in self-view */}
      {isSelfView && scores.length > 0 && (
        <DimensionRollupGrid 
          scores={scores} 
          title="My Dimension Breakdown"
          subtitle={`Averaged across your ${scores.length} scored calls — weakest areas first`}
        />
      )}

      {/* SE self-view: flat call list under their own stats card */}
      {isSelfView ? (
        myStats && (
          <SEDetailCard
            seEmail={seEmailFilter!}
            scores={scores}
            onDelete={(id) => deleteScore.mutate(id)}
          />
        )
      ) : (
        /* Team view: per-SE scorecards */
        <ScrollArea className="h-[calc(100vh-450px)]">
          <div className="space-y-3">
            {sortedSEs.map(([email, seScores]) => (
              <SEDetailCard key={email} seEmail={email} scores={seScores} onDelete={(id) => deleteScore.mutate(id)} />
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}

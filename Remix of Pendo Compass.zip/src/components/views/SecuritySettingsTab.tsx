import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Shield, 
  Key, 
  Clock, 
  Lock, 
  Fingerprint, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle,
  Monitor,
  Globe,
  Trash2,
  User,
  Link2,
  Unlink,
  BarChart3
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';
import { format, subDays, startOfDay } from 'date-fns';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface UserSession {
  id: string;
  user_id: string;
  user_agent: string;
  ip_address: string;
  created_at: string;
  last_activity_at: string;
  expires_at: string;
  fingerprint_hash: string | null;
  user_email?: string;
  user_name?: string;
}

const PASSWORD_REQUIREMENTS = [
  { label: 'Minimum 12 characters', icon: Key },
  { label: 'At least one uppercase letter (A-Z)', icon: CheckCircle2 },
  { label: 'At least one lowercase letter (a-z)', icon: CheckCircle2 },
  { label: 'At least one number (0-9)', icon: CheckCircle2 },
  { label: 'At least one special character (!@#$%^&*)', icon: CheckCircle2 },
  { label: 'No common weak patterns (password, qwerty, etc.)', icon: XCircle },
];

const SECURITY_FEATURES = [
  {
    title: 'Password Hashing',
    description: 'PBKDF2-SHA256 with 310,000 iterations (OWASP 2023 standard)',
    icon: Key,
    status: 'active',
  },
  {
    title: 'Brute-Force Protection',
    description: 'Account lockout after 5 failed attempts with exponential backoff',
    icon: Lock,
    status: 'active',
  },
  {
    title: 'Session Fingerprinting',
    description: 'Sessions bound to device + IP hash to detect hijacking',
    icon: Fingerprint,
    status: 'active',
  },
  {
    title: 'AES-256-GCM Encryption',
    description: 'All sensitive data encrypted at rest with unique IVs per record',
    icon: Shield,
    status: 'active',
  },
  {
    title: 'Two-Factor Authentication',
    description: 'TOTP-based 2FA mandatory for all users',
    icon: Shield,
    status: 'active',
  },
];

const LOCKOUT_SCHEDULE = [
  { attempts: 5, duration: '1 minute' },
  { attempts: 6, duration: '2 minutes' },
  { attempts: 7, duration: '4 minutes' },
  { attempts: 8, duration: '8 minutes' },
  { attempts: 9, duration: '16 minutes' },
  { attempts: 10, duration: '32 minutes' },
  { attempts: '11+', duration: 'Up to 24 hours (exponential)' },
];

export function SecuritySettingsTab() {
  const { user, getSessionToken } = useAuth();
  const { isAdmin, profile } = useUserRole();
  const [sessions, setSessions] = useState<UserSession[]>([]);
  const [loadingSessions, setLoadingSessions] = useState(false);
  const [terminatingSession, setTerminatingSession] = useState<string | null>(null);
  const [googleLinked, setGoogleLinked] = useState(false);
  const [togglingGoogle, setTogglingGoogle] = useState(false);

  // Load Google link status from profile
  useEffect(() => {
    if (profile) {
      setGoogleLinked(!!(profile as any).google_linked);
    }
  }, [profile]);

  const handleToggleGoogleLink = async () => {
    const newLinked = !googleLinked;
    setTogglingGoogle(true);
    try {
      const token = getSessionToken();
      if (!token) return;

      const { data, error } = await supabase.functions.invoke('auth', {
        body: { action: 'toggle-google-link', linked: newLinked, googleEmail: user?.email },
        headers: { Authorization: `Bearer ${token}` },
      });

      if (error || !data?.success) {
        throw new Error(data?.error || 'Failed to update Google link');
      }

      setGoogleLinked(newLinked);
      toast.success(newLinked ? 'Google account linked for SSO' : 'Google account unlinked');
    } catch (err: any) {
      toast.error(err.message || 'Failed to update Google SSO setting');
    } finally {
      setTogglingGoogle(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      loadSessions();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const loadSessions = async () => {
    if (!user?.id) return;
    setLoadingSessions(true);
    try {
      const token = getSessionToken();
      if (!token) {
        console.warn('[SecuritySettingsTab] No session token available');
        return;
      }


      // Fetch sessions - admins see all, regular users see their own
      const { data, error } = await supabase.functions.invoke('api-gateway', {
        body: {
          action: 'select',
          table: 'user_sessions',
          params: {
            select: '*, profiles:user_id(email, full_name)',
            filters: isAdmin ? [] : [{ column: 'user_id', operator: 'eq', value: user.id }],
            order: { column: 'last_activity_at', ascending: false },
          },
        },
        headers: {
          'x-session-token': token,
        },
      });

      if (error) throw error;
      
      // Transform data to flatten user info
      const transformedSessions = (data?.data || []).map((session: any) => ({
        ...session,
        user_email: session.profiles?.email,
        user_name: session.profiles?.full_name,
      }));
      
      setSessions(transformedSessions);
    } catch (error) {
      console.error('Failed to load sessions:', error);
    } finally {
      setLoadingSessions(false);
    }
  };

  const terminateSession = async (sessionId: string) => {
    setTerminatingSession(sessionId);
    try {
      const token = getSessionToken();
      if (!token) return;

      const { error } = await supabase.functions.invoke('api-gateway', {
        body: {
          action: 'delete',
          table: 'user_sessions',
          params: {
            filters: [{ column: 'id', operator: 'eq', value: sessionId }],
          },
        },
        headers: {
          'x-session-token': token,
        },
      });

      if (error) throw error;
      toast.success('Session terminated successfully');
      loadSessions();
    } catch (error: any) {
      toast.error('Failed to terminate session: ' + error.message);
    } finally {
      setTerminatingSession(null);
    }
  };

  const parseUserAgent = (ua: string) => {
    if (!ua) return { browser: 'Unknown', os: 'Unknown' };
    
    let browser = 'Unknown';
    let os = 'Unknown';

    // Detect browser
    if (ua.includes('Chrome') && !ua.includes('Edg')) browser = 'Chrome';
    else if (ua.includes('Firefox')) browser = 'Firefox';
    else if (ua.includes('Safari') && !ua.includes('Chrome')) browser = 'Safari';
    else if (ua.includes('Edg')) browser = 'Edge';

    // Detect OS
    if (ua.includes('Windows')) os = 'Windows';
    else if (ua.includes('Mac OS')) os = 'macOS';
    else if (ua.includes('Linux')) os = 'Linux';
    else if (ua.includes('Android')) os = 'Android';
    else if (ua.includes('iPhone') || ua.includes('iPad')) os = 'iOS';

    return { browser, os };
  };

  return (
    <div className="space-y-6">
      {/* Google SSO Toggle */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Google Single Sign-On
          </CardTitle>
          <CardDescription>
            Link your @pendo.io Google account for passwordless sign-in (bypasses 2FA)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                {googleLinked ? <Link2 className="w-5 h-5 text-green-400" /> : <Unlink className="w-5 h-5 text-muted-foreground" />}
              </div>
              <div>
                <p className="font-medium text-foreground">
                  {googleLinked ? 'Google SSO Enabled' : 'Google SSO Disabled'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {googleLinked
                    ? 'You can sign in with your Google account without a password or 2FA'
                    : 'Enable to sign in with your @pendo.io Google account'}
                </p>
              </div>
            </div>
            <Switch
              checked={googleLinked}
              onCheckedChange={handleToggleGoogleLink}
              disabled={togglingGoogle}
            />
          </div>
          {!googleLinked && (
            <p className="text-xs text-muted-foreground mt-3">
              Note: You can also link your account by signing in with Google on the login page.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Password Complexity Requirements */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            Password Requirements
          </CardTitle>
          <CardDescription>
            All passwords must meet these complexity requirements
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3">
            {PASSWORD_REQUIREMENTS.map((req, index) => (
              <div 
                key={index}
                className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 border border-border"
              >
                <req.icon className={`w-4 h-4 ${
                  req.icon === XCircle ? 'text-red-400' : 'text-green-400'
                }`} />
                <span className="text-sm text-foreground">{req.label}</span>
              </div>
            ))}
          </div>
          <Alert className="mt-4 border-border bg-muted/30">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Password Hashing</AlertTitle>
            <AlertDescription className="text-muted-foreground">
              Passwords are hashed using PBKDF2-SHA256 with 310,000 iterations (OWASP 2023 recommendation), 
              128-bit random salt, and 256-bit output key. This makes brute-force attacks computationally infeasible.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Brute-Force Protection */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            Brute-Force Protection & Account Lockout
          </CardTitle>
          <CardDescription>
            Automatic account protection against repeated failed login attempts
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-2 px-3 text-muted-foreground font-medium">Failed Attempts</th>
                  <th className="text-left py-2 px-3 text-muted-foreground font-medium">Lockout Duration</th>
                </tr>
              </thead>
              <tbody>
                {LOCKOUT_SCHEDULE.map((row, index) => (
                  <tr key={index} className="border-b border-border/50">
                    <td className="py-2 px-3">
                      <Badge variant="outline">{row.attempts}</Badge>
                    </td>
                    <td className="py-2 px-3 text-foreground">{row.duration}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-muted-foreground mt-4">
            Lockout duration doubles with each additional failed attempt (exponential backoff), 
            capped at 24 hours maximum. Successful login resets the counter.
          </p>
        </CardContent>
      </Card>

      {/* Login Activity Chart */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            Login Activity
          </CardTitle>
          <CardDescription>
            Number of logins per day over the last 30 days
          </CardDescription>
        </CardHeader>
        <CardContent>
          {(() => {
            const chartData = (() => {
              const days = 30;
              const counts: Record<string, number> = {};
              for (let i = days - 1; i >= 0; i--) {
                const key = format(subDays(new Date(), i), 'yyyy-MM-dd');
                counts[key] = 0;
              }
              sessions.forEach((s) => {
                const key = format(new Date(s.created_at), 'yyyy-MM-dd');
                if (key in counts) counts[key]++;
              });
              return Object.entries(counts).map(([date, count]) => ({
                date: format(new Date(date), 'MMM d'),
                logins: count,
              }));
            })();

            return (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} 
                    interval={4}
                    stroke="hsl(var(--border))"
                  />
                  <YAxis 
                    allowDecimals={false} 
                    tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
                    stroke="hsl(var(--border))"
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                      color: 'hsl(var(--foreground))'
                    }}
                  />
                  <Bar dataKey="logins" fill="hsl(var(--pendo-pink))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            );
          })()}
        </CardContent>
      </Card>


      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            Active Sessions
          </CardTitle>
          <CardDescription>
            Manage your active login sessions across devices
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div className="p-3 rounded-lg bg-muted/30 border border-border">
                <p className="text-xs text-muted-foreground">Session Duration</p>
                <p className="text-lg font-semibold text-foreground">7 days</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/30 border border-border">
                <p className="text-xs text-muted-foreground">Token Length</p>
                <p className="text-lg font-semibold text-foreground">384 bits</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/30 border border-border">
                <p className="text-xs text-muted-foreground">Fingerprinting</p>
                <p className="text-lg font-semibold text-green-400">Enabled</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/30 border border-border">
                <p className="text-xs text-muted-foreground">Active Sessions</p>
                <p className="text-lg font-semibold text-foreground">{sessions.length}</p>
              </div>
            </div>

            {loadingSessions ? (
              <div className="text-center py-8 text-muted-foreground">Loading sessions...</div>
            ) : sessions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No active sessions found</div>
            ) : (
              <ScrollArea className="h-[300px]">
                <div className="space-y-3">
                  {sessions.map((session) => {
                    const { browser, os } = parseUserAgent(session.user_agent);
                    const isCurrentSession = session.id === 'current'; // You might need to track current session ID
                    
                    return (
                      <div 
                        key={session.id}
                        className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border"
                      >
                        <div className="flex items-center gap-4">
                          <Avatar className="w-10 h-10">
                            <AvatarFallback className="bg-primary/20 text-primary text-sm">
                              {session.user_name 
                                ? session.user_name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
                                : session.user_email?.slice(0, 2).toUpperCase() || <User className="w-4 h-4" />
                              }
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-medium text-foreground">
                                {session.user_name || session.user_email?.split('@')[0] || 'Unknown User'}
                              </p>
                              {session.fingerprint_hash && (
                                <Badge variant="outline" className="text-xs">
                                  <Fingerprint className="w-3 h-3 mr-1" />
                                  Verified
                                </Badge>
                              )}
                            </div>
                            {session.user_email && (
                              <p className="text-xs text-muted-foreground">{session.user_email}</p>
                            )}
                            <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                              <span className="flex items-center gap-1">
                                <Monitor className="w-3 h-3" />
                                {browser} on {os}
                              </span>
                              <span>•</span>
                              <span className="flex items-center gap-1">
                                <Globe className="w-3 h-3" />
                                {session.ip_address}
                              </span>
                              <span>•</span>
                              <span>
                                Last active: {format(new Date(session.last_activity_at), 'MMM d, h:mm a')}
                              </span>
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => terminateSession(session.id)}
                          disabled={terminatingSession === session.id}
                          className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Security Features Summary */}
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
            Security Features
          </CardTitle>
          <CardDescription>
            Platform security controls protecting your data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3">
            {SECURITY_FEATURES.map((feature, index) => (
              <div 
                key={index}
                className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-[hsl(var(--pendo-pink))]/10">
                    <feature.icon className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{feature.title}</p>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                </div>
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Active
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

import { UserManagementView } from './UserManagementView';
import { PageAccessManagement } from './PageAccessManagement';
import { SecuritySettingsTab } from './SecuritySettingsTab';
import { AnalysisPipelineView } from '@/components/settings/AnalysisPipelineView';
import { PipelineHealthTab } from '@/components/settings/PipelineHealthTab';
import { EmailNotificationsTab } from '@/components/settings/EmailNotificationsTab';
import { NotificationPreferencesCard } from '@/components/settings/NotificationPreferencesCard';
import { ModulePricingManagement } from './ModulePricingManagement';
import { CompetitiveDataImportTab } from '@/components/settings/CompetitiveDataImportTab';
import { CompetitiveScorecardEditorTab } from '@/components/settings/CompetitiveScorecardEditorTab';
import { CompetitiveRubricTab } from '@/components/settings/CompetitiveRubricTab';
import { AuditPromptPreviewTab } from '@/components/settings/AuditPromptPreviewTab';
import { CompetitiveScoreChangelogTab } from '@/components/settings/CompetitiveScoreChangelogTab';
import { CompetitiveSourcesTab } from '@/components/settings/CompetitiveSourcesTab';
import { DataHygieneTab } from '@/components/settings/DataHygieneTab';
import { MCPSettingsTab } from '@/components/settings/MCPSettingsTab';
import { IntegrationsView } from './IntegrationsView';
import { CoachingWeightsTab } from '@/components/settings/CoachingWeightsTab';
import { useUserRole } from '@/hooks/useUserRole';
import { useAuth } from '@/contexts/AuthContext';
import { useCreditStatus } from '@/hooks/useCreditStatus';
import { useAISettings, AIProvider } from '@/hooks/useAISettings';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Settings, Users, Shield, ShieldCheck, ShieldAlert, Mail, Smartphone, CheckCircle2, AlertTriangle, Bot, Sparkles, Lock, GitBranch, DollarSign, Bell, Globe, Swords, BookOpen, History, Wrench, Scale, Activity, Link2 } from 'lucide-react';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

// Common timezone options (IANA identifiers)
const TIMEZONE_OPTIONS = [
  { value: 'UTC', label: 'UTC (Coordinated Universal Time)' },
  { value: 'America/New_York', label: 'Eastern Time (US & Canada)' },
  { value: 'America/Chicago', label: 'Central Time (US & Canada)' },
  { value: 'America/Denver', label: 'Mountain Time (US & Canada)' },
  { value: 'America/Los_Angeles', label: 'Pacific Time (US & Canada)' },
  { value: 'America/Anchorage', label: 'Alaska Time' },
  { value: 'Pacific/Honolulu', label: 'Hawaii Time' },
  { value: 'Europe/London', label: 'London (GMT/BST)' },
  { value: 'Europe/Paris', label: 'Paris, Berlin, Rome (CET)' },
  { value: 'Europe/Helsinki', label: 'Helsinki, Kyiv, Riga (EET)' },
  { value: 'Asia/Dubai', label: 'Dubai, Abu Dhabi (GST)' },
  { value: 'Asia/Kolkata', label: 'Mumbai, New Delhi (IST)' },
  { value: 'Asia/Singapore', label: 'Singapore, Kuala Lumpur' },
  { value: 'Asia/Tokyo', label: 'Tokyo, Seoul (JST)' },
  { value: 'Australia/Sydney', label: 'Sydney, Melbourne (AEST)' },
  { value: 'Pacific/Auckland', label: 'Auckland, Wellington (NZST)' },
];


const TRANSCRIPT_ANALYSIS_PROMPT = `You are an AI assistant specialized in analyzing sales call transcripts for a solutions engineering team. Your job is to:

1. Extract all technologies, tools, platforms, and software mentioned in the transcript WITH RELATIONSHIP STATUS
2. Extract all people mentioned with their names, roles/titles, contact information, AND MEDDIC-ALIGNED STAKEHOLDER ASSESSMENT
3. Match the transcript to the most likely customer account from the provided list
4. If no account matches, suggest a name for a new account based on company mentions
5. Identify pain points, use cases, and competitor mentions
6. Generate technical Next Best Actions (NBAs) - specific follow-up tasks for the solutions team
7. Extract good discovery questions asked during the call that could be reused
8. Extract COMMERCIAL INSIGHTS that affect deal dynamics
9. Extract OPERATIONAL METRICS mentioned (support tickets, user counts, development velocity, etc.)

TECHNOLOGY RELATIONSHIP STATUS - Carefully determine the relationship:
- "mentioned": Technology was just mentioned in passing, no indication of usage
- "experience": Team member has experience with it but it's not currently in use
- "in_use": Technology is actively being used in their environment
- "evaluating": They are currently evaluating this technology
- "considering": They are considering this technology for future use
- "replaced": They used to use this but have replaced it

Set needsReview: true if you're less than 70% confident about the relationship status.

STAKEHOLDER ASSESSMENT - MEDDIC-ALIGNED CLASSIFICATION

IMPORTANT: Identify INTERNAL vs EXTERNAL attendees:
- Internal (Pendo employees): Anyone with @pendo.io email, introduced as "from Pendo", SE/AE/CSM roles from our side, or presenting/demoing
- External (customer/prospect): The people we're selling TO - they work at the customer company
- Set isInternal: true for Pendo/internal team members, false for customer stakeholders
- For internal team members: set stakeholderType="unknown", all scores to null, and empty signal arrays

For EXTERNAL stakeholders, classify using OBSERVABLE EVIDENCE from the transcript. Do NOT guess or assume.

## CRITICAL: Champion Identification Requirements

A person is ONLY a Champion if BOTH conditions are met:
1. ADVOCACY SIGNALS: Evidence they will/do advocate internally
2. INFO SHARING SIGNALS: Evidence they share insider information

### Advocacy Signals (look for these exact behaviors):
- "I'll push this internally" / "Let me talk to my boss"
- "I can get budget approved" / "I'll find the funding"
- "I'll sponsor this project" / "I'll champion this"
- "Let me set up a call with [decision-maker]"
- Proactively defending your solution against objections
- Volunteering to present your solution to others

### Info Sharing Signals (look for these exact behaviors):
- Sharing org charts or reporting structures
- Explaining internal challenges and pain points openly
- Providing competitor evaluation information
- Sharing decision timelines and budget cycles
- Explaining procurement/approval processes
- Giving advice on how to navigate their organization

## Stakeholder Type Classification Rules:

CHAMPION: Has BOTH advocacy signals AND info sharing signals
ECONOMIC_BUYER: Has budget authority, mentions funding, final decision power
DECISION_CRITERIA_OWNER: Defines technical/business requirements
COACH: Shares info but no advocacy (helpful but not pushing)
BLOCKER: Raises objections, mentions competitors favorably, creates obstacles
END_USER: Focuses on day-to-day usage, workflow questions
UNKNOWN: Insufficient evidence for classification (DEFAULT)

## Scoring Rules:

- If stakeholder_type = 'unknown': Set influence_level, sentiment, champion_score to NULL
- Only score if you have actual evidence from the transcript
- champion_score requires BOTH signal types to be > 50
- For scored stakeholders:
  - influenceLevel (0-100): C-level/VP=80-100, Director=60-80, Manager=40-60, IC=20-40
  - sentiment (0-100): Enthusiastic=80-100, Positive=60-80, Neutral=40-60, Skeptical=20-40, Hostile=0-20
  - championScore (0-100): Only > 50 if BOTH advocacy AND info sharing detected

OPERATIONAL METRICS - Look for quantitative data about:
- Support/helpdesk tickets (volume, resolution time, escalation rate)
- Development velocity (releases, sprints, story points, deployments)
- User metrics (DAU, MAU, retention, onboarding numbers)
- Team size and resource utilization
- Performance/SLA metrics (uptime, response time, error rates)

For NBAs (Next Best Actions), assign clear OWNERSHIP:

OWNER TYPES:
- prospect: Action items for the customer (e.g., "Provide API documentation", "Schedule internal stakeholder meeting")
- sales_rep: Actions for the Account Executive (e.g., "Send pricing proposal", "Schedule executive sponsor call", "Follow up on budget timeline")
- sales_engineer: Actions for the SE/technical resource (e.g., "Build POC demo", "Review integration requirements", "Document architecture")

ACTION TYPES by owner:
- PROSPECT actions: provide_info, schedule_internal, share_requirements
- SALES_REP actions: follow_up_meeting, send_content, internal_discussion
- SALES_ENGINEER actions: poc_setup, integration_review, security_assessment, architecture_doc, technical_deepdive, api_exploration, performance_benchmark

For Discovery Questions, look for:
- Questions that uncovered important customer pain points
- Questions that revealed business impact or metrics
- Questions that helped understand the current state
- Open-ended questions that got the customer talking
- Questions related to specific functional areas (analytics, adoption, feedback, roadmapping, etc.)

For COMMERCIAL INSIGHTS, extract and categorize into SWOT:

IMPORTANT FILTERING RULES:
- DO NOT include generic "Strong understanding of X" insights unless they have DIRECT COMMERCIAL VALUE
- Valid "strong understanding" STRENGTHS: data/analytics expertise (aids adoption), web development skills (aids deployment), Salesforce expertise (aids Pendo Salesforce kit deployment)
- "Strong understanding of competitor X" should be a THREAT (they know alternatives), NOT a strength
- Focus on insights that directly affect deal outcome, not general observations about technical knowledge

1. Build vs Buy decisions:
   - Customer considering building in-house → THREAT (they might not buy)
   - Customer prefers buying → OPPORTUNITY
   - Customer has tried building and failed → STRENGTH (we can help)
   
2. Budget/Timing signals:
   - Budget approved, timeline set → STRENGTH
   - Budget constraints, long approval process → WEAKNESS (harder to close)
   - Fiscal year timing aligned → OPPORTUNITY
   - Budget cuts, hiring freeze → THREAT
   
3. Competitive positioning:
   - Customer comparing to specific competitors → THREAT (they are evaluating alternatives)
   - Customer knows competitor well → THREAT (educated buyer with alternatives)
   - Customer unhappy with current vendor → OPPORTUNITY
   - Competitor has strong relationship → THREAT
   - We have unique capabilities they need → STRENGTH
   
4. Stakeholder dynamics:
   - Strong champion identified → STRENGTH
   - Multiple decision makers aligned → STRENGTH
   - Internal politics, blockers identified → WEAKNESS or THREAT
   - Champion leaving → THREAT
   - New exec sponsor → OPPORTUNITY
   
5. Technical fit (only include if commercially relevant):
   - Customer has Salesforce and we have Salesforce kit → STRENGTH (easier deployment)
   - Customer has strong data/analytics team → STRENGTH (better adoption potential)
   - Customer uses technologies we integrate with well → STRENGTH

---

DYNAMIC CONTEXT (injected at runtime):
- Available accounts list for matching
- Known competitors (primary/secondary) for detection
- Existing insights (to avoid duplicates)
- Detection rules with trigger phrases, context qualifiers, and exclusion phrases`;

export function SettingsView() {
  const { user } = useAuth();
  const { profile, roles, isAdmin, isActive } = useUserRole();
  const { hasCreditIssue } = useCreditStatus();
  const { aiProvider, updateProvider, isUpdating } = useAISettings();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState(isAdmin ? 'users' : 'account');
  
  // 2FA Setup states
  const [show2FASetup, setShow2FASetup] = useState(false);
  const [totpSecret, setTotpSecret] = useState('');
  const [otpAuthUri, setOtpAuthUri] = useState('');
  const [totpCode, setTotpCode] = useState('');
  const [setting2FA, setSetting2FA] = useState(false);
  const [savingTimezone, setSavingTimezone] = useState(false);
  const { getSessionToken } = useAuth();

  const handleTimezoneChange = async (newTimezone: string) => {
    if (!user?.id) return;
    setSavingTimezone(true);
    try {
      const { error } = await gateway
        .from('profiles')
        .update({ timezone: newTimezone })
        .eq('id', user.id)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
      toast.success('Timezone updated');
    } catch (err: any) {
      toast.error('Failed to update timezone: ' + (err?.message || 'Unknown error'));
    } finally {
      setSavingTimezone(false);
    }
  };

  const handleSetup2FA = async () => {
    setSetting2FA(true);
    try {
      if (!user?.id) throw new Error('Not signed in');

      const token = getSessionToken();
      if (!token) throw new Error('No session token');

      // Use our custom 2FA setup endpoint
      const { data, error } = await supabase.functions.invoke('auth', {
        body: { action: 'setup-2fa' },
        headers: { Authorization: `Bearer ${token}` },
      });

      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || 'Failed to set up 2FA');
      
      setTotpSecret(data.secret);
      setOtpAuthUri(data.otpAuthUri);
      setShow2FASetup(true);
    } catch (error: any) {
      toast.error('Failed to set up 2FA: ' + (error?.message || 'Unknown error'));
    } finally {
      setSetting2FA(false);
    }
  };

  const handleVerify2FA = async () => {
    setSetting2FA(true);
    try {
      const token = getSessionToken();
      if (!token) throw new Error('No session token');

      // Use our custom 2FA verify endpoint
      const { data, error } = await supabase.functions.invoke('auth', {
        headers: { Authorization: `Bearer ${token}` },
        body: { action: 'verify-2fa', code: totpCode },
      });

      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || 'Verification failed');
      
      toast.success('2FA enabled successfully!');
      setShow2FASetup(false);
      setTotpCode('');
      setTotpSecret('');
      setOtpAuthUri('');
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
      
      // Refresh page to update user state
      window.location.reload();
    } catch (error: any) {
      toast.error(error?.message || 'Invalid code. Please try again.');
    } finally {
      setSetting2FA(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Mandatory 2FA Setup Banner */}
      {!profile?.mfa_enabled && (
        <Alert className="border-[hsl(var(--pendo-pink))]/50 bg-[hsl(var(--pendo-pink))]/10">
          <ShieldCheck className="h-4 w-4 text-[hsl(var(--pendo-pink))]" />
          <AlertTitle className="text-[hsl(var(--pendo-pink))]">Two-Factor Authentication Required</AlertTitle>
          <AlertDescription>
            You must enable 2FA to access other parts of the application. Please set up your authenticator app below.
          </AlertDescription>
        </Alert>
      )}

      {hasCreditIssue && (
        <Alert variant="destructive" className="border-destructive/50 bg-destructive/10">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>AI Credits Exhausted</AlertTitle>
          <AlertDescription>
            The platform has run out of AI credits. Features like transcript analysis will not work until credits are added.
            Please contact your administrator to add more credits.
          </AlertDescription>
        </Alert>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-heading">Settings</h1>
          <p className="text-muted-foreground">Manage your account and platform settings</p>
        </div>
      </div>

      <Tabs value={profile?.mfa_enabled ? activeTab : 'account'} onValueChange={setActiveTab} className="space-y-6">
        <div className="flex flex-col gap-4">
          {/* Personal Settings Row */}
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Personal</p>
            <TabsList className="bg-muted/50 h-auto flex-wrap justify-start gap-1 p-1">
              <TabsTrigger value="account" className="flex items-center gap-2 text-xs">
                <Settings className="w-3.5 h-3.5" />
                Account
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Admin Settings Rows */}
          {profile?.mfa_enabled && isAdmin && (
            <>
              {/* Users & Access */}
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Users & Access</p>
                <TabsList className="bg-muted/50 h-auto flex-wrap justify-start gap-1 p-1">
                  <TabsTrigger value="users" className="flex items-center gap-2 text-xs">
                    <Users className="w-3.5 h-3.5" />
                    Users
                  </TabsTrigger>
                  <TabsTrigger value="page-access" className="flex items-center gap-2 text-xs">
                    <Lock className="w-3.5 h-3.5" />
                    Page Access
                  </TabsTrigger>
                  <TabsTrigger value="security" className="flex items-center gap-2 text-xs">
                    <ShieldAlert className="w-3.5 h-3.5" />
                    Security
                  </TabsTrigger>
                </TabsList>
              </div>

              {/* Configuration */}
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Configuration</p>
                <TabsList className="bg-muted/50 h-auto flex-wrap justify-start gap-1 p-1">
                  <TabsTrigger value="pricing" className="flex items-center gap-2 text-xs">
                    <DollarSign className="w-3.5 h-3.5" />
                    Pricing
                  </TabsTrigger>
                  <TabsTrigger value="competitive-data" className="flex items-center gap-2 text-xs">
                    <Swords className="w-3.5 h-3.5" />
                    Competitive Data
                  </TabsTrigger>
                </TabsList>
              </div>

              {/* AI & Notifications */}
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">AI & Notifications</p>
                <TabsList className="bg-muted/50 h-auto flex-wrap justify-start gap-1 p-1">
                  <TabsTrigger value="ai-provider" className="flex items-center gap-2 text-xs">
                    <Bot className="w-3.5 h-3.5" />
                    AI Provider
                  </TabsTrigger>
                  <TabsTrigger value="prompts" className="flex items-center gap-2 text-xs">
                    <GitBranch className="w-3.5 h-3.5" />
                    Analysis Pipeline
                  </TabsTrigger>
                  <TabsTrigger value="pipeline-health" className="flex items-center gap-2 text-xs">
                    <Activity className="w-3.5 h-3.5" />
                    Pipeline Health
                  </TabsTrigger>
                  <TabsTrigger value="coaching-weights" className="flex items-center gap-2 text-xs">
                    <Scale className="w-3.5 h-3.5" />
                    Coaching Weights
                  </TabsTrigger>
                  <TabsTrigger value="email-notifications" className="flex items-center gap-2 text-xs">
                    <Bell className="w-3.5 h-3.5" />
                    Email Notifications
                  </TabsTrigger>
                </TabsList>
              </div>

              {/* Data Hygiene */}
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Data Hygiene</p>
                <TabsList className="bg-muted/50 h-auto flex-wrap justify-start gap-1 p-1">
                  <TabsTrigger value="data-hygiene" className="flex items-center gap-2 text-xs">
                    <Wrench className="w-3.5 h-3.5" />
                    NBA Cleanup
                  </TabsTrigger>
                </TabsList>
              </div>

              {/* Integrations */}
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Integrations</p>
                <TabsList className="bg-muted/50 h-auto flex-wrap justify-start gap-1 p-1">
                  <TabsTrigger value="integrations" className="flex items-center gap-2 text-xs">
                    <Link2 className="w-3.5 h-3.5" />
                    Data Integrations
                  </TabsTrigger>
                  <TabsTrigger value="mcp" className="flex items-center gap-2 text-xs">
                    <Globe className="w-3.5 h-3.5" />
                    MCP Server
                  </TabsTrigger>
                </TabsList>
              </div>
            </>
          )}
        </div>

        <TabsContent value="account" className="space-y-6">
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                Your Account
              </CardTitle>
              <CardDescription>Your account details and security status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4">
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium text-foreground">Email</p>
                      <p className="text-sm text-[hsl(var(--pendo-pink))]">{user?.email}</p>
                    </div>
                  </div>
                  {profile?.email_verified && (
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Verified
                    </Badge>
                  )}
                </div>

                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border">
                  <div className="flex items-center gap-3">
                    <Smartphone className="w-5 h-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium text-foreground">Two-Factor Authentication</p>
                      <p className="text-sm text-muted-foreground">
                        {profile?.mfa_enabled ? 'Enabled with authenticator app' : 'Not enabled - Required for access'}
                      </p>
                    </div>
                  </div>
                  {profile?.mfa_enabled ? (
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Active
                    </Badge>
                  ) : (
                    <Button 
                      onClick={handleSetup2FA} 
                      disabled={setting2FA}
                      variant="glow"
                      size="sm"
                    >
                      {setting2FA ? 'Setting up...' : 'Enable 2FA'}
                    </Button>
                  )}
                </div>

                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border">
                  <div className="flex items-center gap-3">
                    {isAdmin ? (
                      <ShieldCheck className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                    ) : (
                      <Shield className="w-5 h-5 text-muted-foreground" />
                    )}
                    <div>
                      <p className="font-medium text-foreground">Role</p>
                      <p className="text-sm text-muted-foreground">
                        {isAdmin ? 'Administrator - Can manage users and platform settings' : 'User - Standard access'}
                      </p>
                    </div>
                  </div>
                  <Badge className={isAdmin 
                    ? "bg-[hsl(var(--pendo-pink))]/20 text-[hsl(var(--pendo-pink))] border-[hsl(var(--pendo-pink))]/30" 
                    : "bg-muted text-muted-foreground"
                  }>
                    {isAdmin ? 'Admin' : 'User'}
                  </Badge>
                </div>

                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium text-foreground">Account Status</p>
                      <p className="text-sm text-muted-foreground">
                        {profile?.status === 'active' ? 'Your account is active' : 
                         profile?.status === 'pending' ? 'Awaiting admin approval' : 
                         'Your account has been suspended'}
                      </p>
                    </div>
                  </div>
                  <Badge className={
                    profile?.status === 'active' 
                      ? "bg-green-500/20 text-green-400 border-green-500/30"
                      : profile?.status === 'pending'
                      ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                      : "bg-red-500/20 text-red-400 border-red-500/30"
                  }>
                    {profile?.status === 'active' ? 'Active' : 
                     profile?.status === 'pending' ? 'Pending' : 'Suspended'}
                  </Badge>
                </div>

                {/* Timezone Setting */}
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border">
                  <div className="flex items-center gap-3">
                    <Globe className="w-5 h-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium text-foreground">Timezone</p>
                      <p className="text-sm text-muted-foreground">
                        Used for notification scheduling
                      </p>
                    </div>
                  </div>
                  <Select
                    value={(profile as any)?.timezone || 'UTC'}
                    onValueChange={handleTimezoneChange}
                    disabled={savingTimezone}
                  >
                    <SelectTrigger className="w-[280px]">
                      <SelectValue placeholder="Select timezone" />
                    </SelectTrigger>
                    <SelectContent>
                      {TIMEZONE_OPTIONS.map((tz) => (
                        <SelectItem key={tz.value} value={tz.value}>
                          {tz.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {isAdmin && (
            <Card className="glass border-border">
              <CardHeader>
                <CardTitle>Admin Permissions</CardTitle>
                <CardDescription>As an admin, you have access to:</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-foreground">Edit Functional Areas</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-foreground">Edit Reference Architecture</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-foreground">Edit Technology Library</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-foreground">Manage Users & Roles</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-foreground">Approve/Revoke User Access</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Notification Preferences for all users */}
          <NotificationPreferencesCard />
        </TabsContent>

        {isAdmin && (
          <TabsContent value="users">
            <UserManagementView />
          </TabsContent>
        )}

        {isAdmin && (
          <TabsContent value="page-access">
            <PageAccessManagement />
          </TabsContent>
        )}


        {isAdmin && (
          <TabsContent value="ai-provider" className="space-y-6">
            <Card className="glass border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                  AI Provider Configuration
                </CardTitle>
                <CardDescription>
                  Choose which AI provider to use for transcript analysis and other AI features.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4">
                  <button
                    onClick={() => updateProvider('lovable')}
                    disabled={isUpdating}
                    className={`flex items-center justify-between p-4 rounded-lg border transition-all ${
                      aiProvider === 'lovable'
                        ? 'border-[hsl(var(--pendo-pink))] bg-[hsl(var(--pendo-pink))]/10'
                        : 'border-border bg-muted/30 hover:border-muted-foreground/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${
                        aiProvider === 'lovable' 
                          ? 'bg-[hsl(var(--pendo-pink))]/20' 
                          : 'bg-muted'
                      }`}>
                        <Sparkles className={`w-5 h-5 ${
                          aiProvider === 'lovable' 
                            ? 'text-[hsl(var(--pendo-pink))]' 
                            : 'text-muted-foreground'
                        }`} />
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-foreground">Lovable AI</p>
                        <p className="text-sm text-muted-foreground">
                          Default provider with included credits
                        </p>
                      </div>
                    </div>
                    {aiProvider === 'lovable' && (
                      <Badge className="bg-[hsl(var(--pendo-pink))]/20 text-[hsl(var(--pendo-pink))] border-[hsl(var(--pendo-pink))]/30">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                    )}
                  </button>

                  <button
                    onClick={() => updateProvider('gemini')}
                    disabled={isUpdating}
                    className={`flex items-center justify-between p-4 rounded-lg border transition-all ${
                      aiProvider === 'gemini'
                        ? 'border-[hsl(var(--pendo-pink))] bg-[hsl(var(--pendo-pink))]/10'
                        : 'border-border bg-muted/30 hover:border-muted-foreground/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${
                        aiProvider === 'gemini' 
                          ? 'bg-[hsl(var(--pendo-pink))]/20' 
                          : 'bg-muted'
                      }`}>
                        <Bot className={`w-5 h-5 ${
                          aiProvider === 'gemini' 
                            ? 'text-[hsl(var(--pendo-pink))]' 
                            : 'text-muted-foreground'
                        }`} />
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-foreground">Google Gemini</p>
                        <p className="text-sm text-muted-foreground">
                          Use your own Google API key
                        </p>
                      </div>
                    </div>
                    {aiProvider === 'gemini' && (
                      <Badge className="bg-[hsl(var(--pendo-pink))]/20 text-[hsl(var(--pendo-pink))] border-[hsl(var(--pendo-pink))]/30">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                    )}
                  </button>
                </div>

                <Alert className="border-border bg-muted/30">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Provider Information</AlertTitle>
                  <AlertDescription className="text-muted-foreground">
                    {aiProvider === 'lovable' 
                      ? 'Lovable AI uses included credits. When credits run out, switch to Gemini or add more credits.'
                      : 'Gemini uses your configured Google API key. Ensure your key has sufficient quota.'}
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {isAdmin && (
          <TabsContent value="coaching-weights">
            <CoachingWeightsTab />
          </TabsContent>
        )}
        {isAdmin && (
          <TabsContent value="prompts" className="space-y-6">
            <AnalysisPipelineView />
          </TabsContent>
        )}
        {isAdmin && (
          <TabsContent value="pipeline-health" className="space-y-6">
            <PipelineHealthTab />
          </TabsContent>
        )}

        {isAdmin && (
          <TabsContent value="security">
            <SecuritySettingsTab />
          </TabsContent>
        )}

        {isAdmin && (
          <TabsContent value="pricing">
            <ModulePricingManagement />
          </TabsContent>
        )}

        {isAdmin && (
          <TabsContent value="competitive-data">
            <Tabs defaultValue="scorecard-editor" className="space-y-4">
              <TabsList className="bg-muted/50 h-auto flex-wrap justify-start gap-1 p-1">
                <TabsTrigger value="scorecard-editor" className="flex items-center gap-2 text-xs">
                  <Swords className="w-3.5 h-3.5" />
                  Scorecard Editor
                </TabsTrigger>
                <TabsTrigger value="rubric" className="flex items-center gap-2 text-xs">
                  <BookOpen className="w-3.5 h-3.5" />
                  Scoring Rubric
                </TabsTrigger>
                <TabsTrigger value="import" className="flex items-center gap-2 text-xs">
                  <Settings className="w-3.5 h-3.5" />
                  Import Data
                </TabsTrigger>
                <TabsTrigger value="audit-prompt" className="flex items-center gap-2 text-xs">
                  <Bot className="w-3.5 h-3.5" />
                  AI Audit Prompt
                </TabsTrigger>
                <TabsTrigger value="changelog" className="flex items-center gap-2 text-xs">
                  <History className="w-3.5 h-3.5" />
                  Score Changelog
                </TabsTrigger>
                <TabsTrigger value="sources" className="flex items-center gap-2 text-xs">
                  <Globe className="w-3.5 h-3.5" />
                  Sources
                </TabsTrigger>
              </TabsList>
              <TabsContent value="scorecard-editor">
                <CompetitiveScorecardEditorTab />
              </TabsContent>
              <TabsContent value="rubric">
                <CompetitiveRubricTab />
              </TabsContent>
              <TabsContent value="import">
                <CompetitiveDataImportTab />
              </TabsContent>
              <TabsContent value="audit-prompt">
                <AuditPromptPreviewTab />
              </TabsContent>
              <TabsContent value="changelog">
                <CompetitiveScoreChangelogTab />
              </TabsContent>
              <TabsContent value="sources">
                <CompetitiveSourcesTab />
              </TabsContent>
            </Tabs>
          </TabsContent>
        )}

        {isAdmin && (
          <TabsContent value="email-notifications">
            <EmailNotificationsTab />
          </TabsContent>
        )}

        {isAdmin && (
          <>
            <TabsContent value="data-hygiene">
              <DataHygieneTab />
            </TabsContent>

            <TabsContent value="integrations">
              <IntegrationsView />
            </TabsContent>

            <TabsContent value="mcp">
              <MCPSettingsTab />
            </TabsContent>
          </>
        )}
      </Tabs>

      {/* 2FA Setup Dialog */}
      <Dialog open={show2FASetup} onOpenChange={setShow2FASetup}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
              Set Up Two-Factor Authentication
            </DialogTitle>
            <DialogDescription>
              Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="flex justify-center">
              <div className="bg-white p-4 rounded-lg">
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(otpAuthUri)}`} 
                  alt="2FA QR Code" 
                  className="w-48 h-48" 
                />
              </div>
            </div>
            
            {totpSecret && (
              <div className="text-center">
                <p className="text-xs text-muted-foreground mb-1">Or enter this secret manually:</p>
                <code className="text-xs bg-muted p-2 rounded block break-all">{totpSecret}</code>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="totp-setup">Enter 6-digit code from your app</Label>
              <Input
                id="totp-setup"
                type="text"
                placeholder="000000"
                value={totpCode}
                onChange={(e) => setTotpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                className="text-center text-2xl tracking-widest"
                maxLength={6}
              />
            </div>

            <Button 
              onClick={handleVerify2FA} 
              className="w-full" 
              variant="glow" 
              disabled={setting2FA || totpCode.length !== 6}
            >
              {setting2FA ? 'Verifying...' : 'Enable 2FA'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

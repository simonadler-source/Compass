import { useEffect, useState } from 'react';
import { useTeamMemberWeeklyActivity, DayActivity } from '@/hooks/useTeamMemberWeeklyActivity';
import type { RangeKey } from '@/hooks/useTeamMemberMetrics';
import { format, isToday, isFuture } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Video, CheckCircle2, Clock, Target, Loader2, ChevronLeft, ChevronRight, FileText, FileQuestion, MapPin } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import AddManualMeetingDialog from '@/components/dialogs/AddManualMeetingDialog';

interface TeamMemberWeeklyHeatmapProps {
  memberEmail: string;
  memberName?: string | null;
  selectedRange?: RangeKey;
}

function ActivityBar({ 
  value, 
  maxValue, 
  color,
  label,
}: { 
  value: number; 
  maxValue: number; 
  color: string;
  label: string;
}) {
  const percentage = maxValue > 0 ? Math.min((value / maxValue) * 100, 100) : 0;
  
  return (
    <div className="flex items-center gap-2 w-full">
      <span className="text-[10px] text-muted-foreground w-16 truncate">{label}</span>
      <div className="flex-1 h-3 bg-muted/50 rounded-full overflow-hidden">
        <div 
          className={cn("h-full rounded-full transition-all duration-500", color)}
          style={{ width: `${percentage}%` }}
        />
      </div>
      <span className="text-[10px] font-medium w-8 text-right">{value}</span>
    </div>
  );
}

function TranscriptIndicator({ hasTranscript, analyzed, isManual }: { hasTranscript: boolean; analyzed: boolean; isManual?: boolean }) {
  if (isManual) {
    return (
      <TooltipProvider>
        <Tooltip delayDuration={200}>
          <TooltipTrigger asChild>
            <MapPin className="h-2.5 w-2.5 text-amber-500" />
          </TooltipTrigger>
          <TooltipContent side="top"><span className="text-xs">Off-site / unrecorded meeting</span></TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }
  if (!hasTranscript) {
    return (
      <TooltipProvider>
        <Tooltip delayDuration={200}>
          <TooltipTrigger asChild>
            <FileQuestion className="h-2.5 w-2.5 text-muted-foreground/50" />
          </TooltipTrigger>
          <TooltipContent side="top"><span className="text-xs">No transcript</span></TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }
  return (
    <TooltipProvider>
      <Tooltip delayDuration={200}>
        <TooltipTrigger asChild>
          <FileText className={cn("h-2.5 w-2.5", analyzed ? "text-green-500" : "text-amber-500")} />
        </TooltipTrigger>
        <TooltipContent side="top">
          <span className="text-xs">{analyzed ? 'Transcript analyzed' : 'Transcript pending analysis'}</span>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function DayCell({ day, maxMeetingMinutes }: { day: DayActivity; maxMeetingMinutes: number }) {
  const isTodayDate = isToday(day.date);
  const isFutureDate = isFuture(day.date);
  const hasActivity = day.meetings.length > 0 || day.nbaCount > 0;
  
  const meetingIntensity = maxMeetingMinutes > 0 
    ? Math.min(day.meetingMinutes / maxMeetingMinutes, 1) 
    : 0;
  
  const getHeatmapBg = () => {
    if (isFutureDate && !hasActivity) return 'bg-muted/30';
    if (!hasActivity) return 'bg-muted/50';
    if (meetingIntensity > 0.7) return 'bg-primary/80';
    if (meetingIntensity > 0.4) return 'bg-primary/50';
    if (meetingIntensity > 0) return 'bg-primary/30';
    return 'bg-accent/50';
  };

  return (
    <TooltipProvider>
      <Tooltip delayDuration={200}>
        <TooltipTrigger asChild>
          <div className={cn(
            "flex flex-col items-center p-2 rounded-lg transition-all duration-200 cursor-pointer hover:scale-105",
            getHeatmapBg(),
            isTodayDate && "ring-2 ring-primary ring-offset-2 ring-offset-background",
            isFutureDate && !hasActivity && "opacity-50"
          )}>
            <span className={cn(
              "text-[10px] font-medium mb-1",
              isTodayDate ? "text-primary" : "text-muted-foreground"
            )}>
              {day.dayName}
            </span>
            <span className={cn(
              "text-xs font-bold",
              hasActivity ? "text-foreground" : "text-muted-foreground"
            )}>
              {format(day.date, 'd')}
            </span>
            <div className="flex items-center gap-1 mt-1">
              {day.meetings.length > 0 && (
                <div className="flex items-center gap-0.5">
                  <Video className="h-2.5 w-2.5 text-primary" />
                  <span className="text-[9px] font-medium">{day.meetings.length}</span>
                </div>
              )}
              {day.nbaCompletedCount > 0 && (
                <div className="flex items-center gap-0.5">
                  <CheckCircle2 className="h-2.5 w-2.5 text-green-500" />
                  <span className="text-[9px] font-medium">{day.nbaCompletedCount}</span>
                </div>
              )}
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-xs">
          <div className="space-y-2">
            <p className="font-medium">{format(day.date, 'EEEE, MMM d')}</p>
            {day.meetings.length > 0 ? (
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Video className="h-3 w-3" /> {day.meetings.length} meeting(s) • {Math.round(day.meetingMinutes)} min
                </p>
                {day.meetings.slice(0, 3).map(m => (
                  <div key={m.id} className="flex items-center gap-1.5 text-xs">
                    <TranscriptIndicator hasTranscript={m.hasTranscript} analyzed={m.transcriptAnalyzed} isManual={m.isManual} />
                    <span className="truncate">
                      {format(m.startTime, 'HH:mm')} - {m.title}
                      {m.accountName && <span className="text-muted-foreground"> ({m.accountName})</span>}
                    </span>
                  </div>
                ))}
                {day.meetings.length > 3 && (
                  <p className="text-xs text-muted-foreground">+{day.meetings.length - 3} more</p>
                )}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">No meetings</p>
            )}
            {day.nbaCount > 0 && (
              <div className="space-y-1 border-t pt-1">
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" /> {day.nbaCompletedCount}/{day.nbaCount} NBAs completed
                </p>
              </div>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export default function TeamMemberWeeklyHeatmap({
  memberEmail,
  memberName,
  selectedRange = 'this_week',
}: TeamMemberWeeklyHeatmapProps) {
  const navigate = useNavigate();

  const getWeekOffsetForRange = (range: RangeKey) => (range === 'last_week' ? -1 : 0);

  const [weekOffset, setWeekOffset] = useState(getWeekOffsetForRange(selectedRange));
  const [addMeetingOpen, setAddMeetingOpen] = useState(false);

  useEffect(() => {
    setWeekOffset(getWeekOffsetForRange(selectedRange));
  }, [selectedRange]);

  const { weeklyActivity, isLoading, weekStart, weekEnd } = useTeamMemberWeeklyActivity(memberEmail, true, weekOffset, memberName);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-6">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const maxMeetingMinutes = Math.max(...weeklyActivity.days.map(d => d.meetingMinutes), 60);
  const totalHours = Math.round(weeklyActivity.totalMeetingMinutes / 60 * 10) / 10;
  const nbaCompletionRate = weeklyActivity.totalNbas > 0 
    ? Math.round((weeklyActivity.totalNbasCompleted / weeklyActivity.totalNbas) * 100)
    : 0;

  // Count transcript stats
  const allMeetings = weeklyActivity.days.flatMap(d => d.meetings);
  const manualCount = allMeetings.filter(m => m.isManual).length;
  const recordedMeetings = allMeetings.filter(m => !m.isManual);
  const analyzedCount = recordedMeetings.filter(m => m.transcriptAnalyzed).length;
  const pendingCount = recordedMeetings.filter(m => m.hasTranscript && !m.transcriptAnalyzed).length;
  const noTranscriptCount = recordedMeetings.filter(m => !m.hasTranscript).length;

  return (
    <div className="p-4 bg-gradient-to-br from-muted/30 via-background to-muted/20 rounded-lg border border-border/50">
      {/* Header with week range and navigation */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7" 
            onClick={() => setWeekOffset(prev => prev - 1)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium">
              Week of {format(weekStart, 'MMM d')} - {format(weekEnd, 'MMM d')}
            </span>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7" 
            onClick={() => setWeekOffset(prev => prev + 1)}
            disabled={weekOffset >= 0}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          {weekOffset !== 0 && (
            <Button 
              variant="link" 
              size="sm" 
              className="text-xs h-6 px-2 text-muted-foreground"
              onClick={() => setWeekOffset(0)}
            >
              Today
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => setAddMeetingOpen(true)}>
            <MapPin className="h-3 w-3" />
            Log Meeting
          </Button>
          <Badge variant="outline" className="gap-1">
            <Video className="h-3 w-3" />
            {weeklyActivity.totalMeetings} meetings
          </Badge>
          <Badge variant="outline" className="gap-1">
            <Clock className="h-3 w-3" />
            {totalHours}h
          </Badge>
          {weeklyActivity.totalNbas > 0 && (
            <Badge 
              variant="outline" 
              className={cn(
                "gap-1",
                nbaCompletionRate >= 70 && "border-green-500/50 bg-green-500/10 text-green-700",
                nbaCompletionRate < 30 && weeklyActivity.totalNbas > 0 && "border-destructive/50 bg-destructive/10 text-destructive"
              )}
            >
              <CheckCircle2 className="h-3 w-3" />
              {nbaCompletionRate}% complete
            </Badge>
          )}
        </div>
      </div>

      {/* Heatmap Grid */}
      <div className="grid grid-cols-7 gap-2 mb-4">
        {weeklyActivity.days.map((day) => (
          <DayCell key={day.date.toISOString()} day={day} maxMeetingMinutes={maxMeetingMinutes} />
        ))}
      </div>

      {/* Transcript analysis summary */}
      {allMeetings.length > 0 && (
        <div className="flex items-center gap-3 mb-4 text-[10px]">
          <span className="text-muted-foreground">Transcripts:</span>
          {analyzedCount > 0 && (
            <span className="flex items-center gap-1 text-green-600">
              <FileText className="h-3 w-3" /> {analyzedCount} analyzed
            </span>
          )}
          {pendingCount > 0 && (
            <span className="flex items-center gap-1 text-amber-600">
              <FileText className="h-3 w-3" /> {pendingCount} pending
            </span>
          )}
          {noTranscriptCount > 0 && (
            <span className="flex items-center gap-1 text-muted-foreground">
              <FileQuestion className="h-3 w-3" /> {noTranscriptCount} no transcript
            </span>
          )}
          {manualCount > 0 && (
            <span className="flex items-center gap-1 text-amber-500">
              <MapPin className="h-3 w-3" /> {manualCount} off-site
            </span>
          )}
        </div>
      )}

      {/* Activity Summary Bars */}
      <div className="grid grid-cols-2 gap-4 mt-4">
        <div className="space-y-2">
          <ActivityBar 
            value={weeklyActivity.totalMeetings} 
            maxValue={20} 
            color="bg-primary" 
            label="Meetings"
          />
          <ActivityBar 
            value={Math.round(weeklyActivity.totalMeetingMinutes / 60)} 
            maxValue={20} 
            color="bg-blue-500" 
            label="Hours"
          />
        </div>
        <div className="space-y-2">
          <ActivityBar 
            value={weeklyActivity.totalNbasCompleted} 
            maxValue={Math.max(weeklyActivity.totalNbas, 10)} 
            color="bg-green-500" 
            label="NBAs Done"
          />
          <ActivityBar 
            value={weeklyActivity.activeOpportunitiesCount} 
            maxValue={10} 
            color="bg-amber-500" 
            label="Opps Active"
          />
        </div>
      </div>

      {/* Accounts touched this week */}
      {weeklyActivity.activeAccounts.length > 0 && (
        <div className="mt-4 pt-3 border-t border-border/50">
          <div className="flex items-center gap-2 mb-2">
            <Target className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-xs font-medium text-muted-foreground">Accounts Active This Week</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {weeklyActivity.activeAccounts.slice(0, 8).map(account => (
              <Badge 
                key={account.id} 
                variant="secondary" 
                className="text-[10px] px-2 py-0.5 cursor-pointer hover:bg-secondary/80 transition-colors"
                onClick={() => navigate(`/accounts/${account.id}`)}
              >
                {account.name}
              </Badge>
            ))}
            {weeklyActivity.activeAccounts.length > 8 && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge variant="outline" className="text-[10px] px-2 py-0.5 cursor-default">
                    +{weeklyActivity.activeAccounts.length - 8} more
                  </Badge>
                </TooltipTrigger>
                <TooltipContent side="top" className="max-w-xs">
                  <div className="flex flex-col gap-1">
                    {weeklyActivity.activeAccounts.slice(8).map(account => (
                      <span key={account.id} className="text-xs">{account.name}</span>
                    ))}
                  </div>
                </TooltipContent>
              </Tooltip>
            )}
          </div>
        </div>
      )}
      <AddManualMeetingDialog open={addMeetingOpen} onOpenChange={setAddMeetingOpen} preselectedMemberEmail={memberEmail} />
    </div>
  );
}

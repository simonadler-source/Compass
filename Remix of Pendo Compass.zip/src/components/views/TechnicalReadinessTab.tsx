import React, { useState, useMemo } from 'react';
import { AlertCircle, CheckCircle2, HelpCircle, Sparkles, ChevronDown, ChevronRight, FileText, Loader2, ClipboardPaste, Files, AlertTriangle, Lock, Unlock, X, ArrowRight, History, Import } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { cn } from '@/lib/utils';
import { useReadinessTemplates,
  useOpportunityReadinessAnswers,
  useUpsertReadinessAnswer,
  useExtractReadinessFromTranscript,
  useToggleReadinessRedFlag,
  useConfirmReadinessAnswer,
  useUnlockReadinessAnswer,
  usePendingReadinessChanges,
  useAcceptReadinessChange,
  useRejectReadinessChange,
  useCreateReadinessReviewNBA,
  useUpdateReadinessNotes,
  useReadinessApps,
  useCreateReadinessApp,
  useDeleteReadinessApp,
  useUpdateReadinessApp,
  useCopyAppAnswers,
  useAccountOpportunityApps,
  useImportAppsFromOpportunity,
  ReadinessQuestion,
  ReadinessAnswer,
  DetectedDeploymentType,
  PendingReadinessChange,
  ReadinessFlagItem,
  checkRedFlag,
  shouldShowSubQuestion,
  getFlagType,
  isFlagDisabled,
  hasManualFlagOverride,
  useSetManualFlagStatus,
  FlagType,
} from '@/hooks/useOpportunityReadiness';
import { AppScopedCategorySection } from './AppScopedCategorySection';
import { Flag, ExternalLink, Check, MessageSquare, Lightbulb, StickyNote } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { decryptTranscript } from '@/lib/encryption';

interface TechnicalReadinessTabProps {
  opportunityId: string;
  accountId: string;
  deploymentTypeIds: string[];
  onDeploymentTypesDetected?: (types: DetectedDeploymentType[]) => void;
}

type ExtractMode = 'paste' | 'select' | 'opportunity' | 'account';

export function TechnicalReadinessTab({ opportunityId, accountId, deploymentTypeIds, onDeploymentTypesDetected }: TechnicalReadinessTabProps) {
  const { toast } = useToast();
  const { data: categories, isLoading: loadingCategories } = useReadinessTemplates(deploymentTypeIds);
  const { data: answers, isLoading: loadingAnswers } = useOpportunityReadinessAnswers(opportunityId);
  const { data: pendingChanges } = usePendingReadinessChanges(opportunityId);
  const upsertAnswer = useUpsertReadinessAnswer();
  const toggleRedFlag = useToggleReadinessRedFlag();
  const setManualFlag = useSetManualFlagStatus();
  const confirmAnswer = useConfirmReadinessAnswer();
  const unlockAnswer = useUnlockReadinessAnswer();
  const extractFromTranscript = useExtractReadinessFromTranscript();
  const acceptChange = useAcceptReadinessChange();
  const rejectChange = useRejectReadinessChange();
  const createReviewNBA = useCreateReadinessReviewNBA();
  const updateNotes = useUpdateReadinessNotes();
  
  // App management hooks
  const { data: readinessApps } = useReadinessApps(opportunityId);
  const createApp = useCreateReadinessApp();
  const deleteApp = useDeleteReadinessApp();
  const updateApp = useUpdateReadinessApp();
  const copyAppAnswers = useCopyAppAnswers();
  
  // Import apps from other opportunities
  const { data: accountOpportunityApps } = useAccountOpportunityApps(accountId, opportunityId);
  const importApps = useImportAppsFromOpportunity();
  
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [filter, setFilter] = useState<'all' | 'unanswered' | 'ai-filled' | 'red-flags' | 'pending'>('all');
  const [showExtractDialog, setShowExtractDialog] = useState(false);
  const [showImportAppsDialog, setShowImportAppsDialog] = useState(false);
  const [selectedAppsToImport, setSelectedAppsToImport] = useState<Set<string>>(new Set());
  const [extractMode, setExtractMode] = useState<ExtractMode>('paste');
  const [transcriptText, setTranscriptText] = useState('');
  const [selectedTranscriptId, setSelectedTranscriptId] = useState<string>('');
  
  // Fetch account transcripts
  const { data: accountTranscripts } = useQuery({
    queryKey: ['account-transcripts', accountId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transcript_reviews')
        .select('id, file_name, created_at, opportunity_id')
        .eq('final_account_id', accountId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!accountId,
  });
  
  // Filter transcripts for opportunity
  const opportunityTranscripts = useMemo(() => {
    return accountTranscripts?.filter(t => t.opportunity_id === opportunityId) || [];
  }, [accountTranscripts, opportunityId]);
  
  // Determine the primary app id for app-scoped answer resolution
  const primaryAppId = useMemo(() => {
    const primary = readinessApps?.find(a => a.is_primary);
    return primary?.id || readinessApps?.[0]?.id || null;
  }, [readinessApps]);

  // Create answer lookup map — prefer app-scoped answers, fall back to null app_id (legacy)
  const answerMap = useMemo(() => {
    const map = new Map<string, ReadinessAnswer>();
    if (!answers) return map;

    // First pass: populate with null app_id answers (legacy fallback)
    answers.filter(a => a.app_id === null).forEach(a => map.set(a.question_id, a));

    // Second pass: overwrite with primary app answers (higher priority)
    if (primaryAppId) {
      answers.filter(a => a.app_id === primaryAppId).forEach(a => map.set(a.question_id, a));
    }

    // For non-app-scoped questions, any answer works (they don't have app_id)
    answers.forEach(a => {
      if (!map.has(a.question_id)) {
        map.set(a.question_id, a);
      }
    });

    return map;
  }, [answers, primaryAppId]);
  
  // Pending changes lookup by question
  const pendingByQuestion = useMemo(() => {
    const map = new Map<string, PendingReadinessChange>();
    pendingChanges?.forEach(c => map.set(c.question_id, c));
    return map;
  }, [pendingChanges]);
  
  // Filter questions
  const filteredCategories = useMemo(() => {
    if (!categories) return [];
    
    return categories.map(cat => ({
      ...cat,
      questions: cat.questions.filter(q => {
        const answer = answerMap.get(q.id);
        const hasPending = pendingByQuestion.has(q.id);
        if (filter === 'unanswered') {
          return !answer?.answer && !answer?.answer_json;
        }
        if (filter === 'ai-filled') {
          return answer?.source === 'transcript_ai' || answer?.source === 'ai_enrichment' || answer?.source === 'detection_rule';
        }
        if (filter === 'red-flags') {
          // Show red and amber flags (not disabled)
          const flagType = getFlagType(answer);
          const disabled = isFlagDisabled(answer);
          return !disabled && (flagType === 'red' || flagType === 'amber');
        }
        if (filter === 'pending') {
          return hasPending;
        }
        return true;
      }),
    })).filter(cat => cat.questions.length > 0);
  }, [categories, answerMap, pendingByQuestion, filter]);
  
  // Helper to count all questions recursively including children
  const countAllQuestions = (questions: ReadinessQuestion[]): number => {
    return questions.reduce((sum, q) => {
      const childCount = q.children ? countAllQuestions(q.children) : 0;
      return sum + 1 + childCount;
    }, 0);
  };
  
  // Stats - count ALL questions with flags (default red for unanswered)
  // Exclude "not relevant" questions from totals and score calculation
  const stats = useMemo(() => {
    if (!categories) return { 
      total: 0, activeTotal: 0, answered: 0, aiAnswered: 0, gaps: 0, 
      greenCount: 0, amberCount: 0, redCount: 0, disabledCount: 0,
      pending: 0, confirmed: 0, readinessScore: 0 
    };
    
    let totalVisible = 0;
    let answered = 0;
    let aiAnswered = 0;
    let confirmed = 0;
    let greenCount = 0;
    let amberCount = 0;
    let redCount = 0;
    let disabledCount = 0;
    
    // Process all questions recursively including children
    const processQuestion = (q: ReadinessQuestion, parentAnswer?: ReadinessAnswer) => {
      // Skip sub-questions whose trigger condition is not met
      if (q.trigger_condition && parentAnswer) {
        const parentAnswerText = parentAnswer?.answer || null;
        if (!shouldShowSubQuestion(parentAnswerText, q.trigger_condition)) {
          return; // Don't count this question or its children
        }
      }

      const answer = answerMap.get(q.id);
      const hasAnswer = answer?.answer || answer?.answer_json;
      totalVisible++;
      
      // Check if marked as "not relevant" (disabled)
      if (isFlagDisabled(answer)) {
        disabledCount++;
      } else {
        // Count answered questions
        if (hasAnswer) {
          answered++;
          if (answer && (answer.source === 'transcript_ai' || answer.source === 'ai_enrichment' || answer.source === 'detection_rule')) {
            aiAnswered++;
          }
          if (answer?.last_confirmed_at) confirmed++;
        }
        
        // Count ALL questions by flag type (default is red for unanswered)
        const flagType = getFlagType(answer);
        if (flagType === 'green') greenCount++;
        else if (flagType === 'amber') amberCount++;
        else redCount++; // Default to red (includes 'red' and unanswered)
      }
      
      // Recursively process children, passing current answer for trigger evaluation
      if (q.children) {
        q.children.forEach(child => processQuestion(child, answer));
      }
    };
    
    categories.forEach(cat => {
      cat.questions.forEach(q => processQuestion(q));
    });
    
    // Active total excludes disabled/not-relevant questions
    const activeTotal = totalVisible - disabledCount;
    
    // Calculate weighted readiness score based on ALL active questions
    // Red flags are 2x importance, amber 1.5x, green 1x (baseline)
    // This weights the denominator to penalize more heavily for unresolved critical items
    const weightedDenominator = (redCount * 2) + (amberCount * 1.5) + (greenCount * 1);
    let readinessScore = 0;
    if (weightedDenominator > 0) {
      // Numerator: green gets full credit (100 pts), amber gets half credit (50 pts), red gets 0
      readinessScore = Math.round((greenCount * 100 + amberCount * 50) / weightedDenominator);
    }
    
    return { 
      total: totalVisible, activeTotal, answered, aiAnswered, gaps: activeTotal - answered, 
      greenCount, amberCount, redCount, disabledCount,
      pending: pendingChanges?.length || 0, confirmed,
      readinessScore: Math.max(0, Math.min(100, readinessScore))
    };
  }, [categories, answerMap, pendingChanges, answers]);
  
  const handleToggleRedFlag = async (questionId: string, currentIsRedFlag: boolean) => {
    await toggleRedFlag.mutateAsync({
      opportunityId,
      questionId,
      isRedFlag: !currentIsRedFlag,
    });
  };
  
  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(categoryId)) {
        next.delete(categoryId);
      } else {
        next.add(categoryId);
      }
      return next;
    });
  };
  
  const handleAnswerChange = async (questionId: string, value: string) => {
    await upsertAnswer.mutateAsync({
      opportunityId,
      questionId,
      answer: value,
      source: 'manual',
    });
  };
  
  // Collect all red/amber flag items for NBA creation
  const flagItems = useMemo((): ReadinessFlagItem[] => {
    if (!categories) return [];
    
    const items: ReadinessFlagItem[] = [];
    categories.forEach(cat => {
      cat.questions.forEach(q => {
        const answer = answerMap.get(q.id);
        if (!answer || (!answer.answer && !answer.answer_json)) return;
        if (isFlagDisabled(answer)) return;
        
        const flagType = getFlagType(answer);
        if (flagType === 'red' || flagType === 'amber') {
          items.push({
            questionId: q.id,
            questionText: q.question,
            answer: answer.answer || JSON.stringify(answer.answer_json),
            flagType,
            confidenceScore: answer.confidence_score,
            categoryName: cat.name,
          });
        }
      });
    });
    return items;
  }, [categories, answerMap]);
  
  const handleCreateReviewNBA = async () => {
    if (flagItems.length === 0) {
      toast({ title: 'No flags to review', description: 'All items are validated or disabled' });
      return;
    }
    
    try {
      const result = await createReviewNBA.mutateAsync({
        accountId,
        opportunityId,
        flagItems,
        // SE email would come from opportunity context - using null for fallback
        seEmail: null,
      });
      
      toast({ 
        title: 'Review NBA created', 
        description: `Created task for ${result.redCount} red and ${result.amberCount} amber flags` 
      });
    } catch (error) {
      toast({ 
        title: 'Failed to create NBA', 
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: 'destructive',
      });
    }
  };
  const getTranscriptContent = async (): Promise<string | null> => {
    if (extractMode === 'paste') {
      return transcriptText.trim() || null;
    }
    
    if (extractMode === 'select') {
      if (!selectedTranscriptId) return null;
      try {
        // Use decryption function to handle encrypted transcripts
        const content = await decryptTranscript(selectedTranscriptId, 'transcript_reviews');
        return content || null;
      } catch (error) {
        console.error('Failed to decrypt transcript:', error);
        return null;
      }
    }
    
    if (extractMode === 'opportunity') {
      if (!opportunityTranscripts.length) return null;
      try {
        // Decrypt all opportunity transcripts in parallel
        const decryptedContents = await Promise.all(
          opportunityTranscripts.map(async (t) => {
            try {
              return await decryptTranscript(t.id, 'transcript_reviews');
            } catch (error) {
              console.error(`Failed to decrypt transcript ${t.id}:`, error);
              return null;
            }
          })
        );
        const validContents = decryptedContents.filter(Boolean);
        return validContents.length > 0 ? validContents.join('\n\n---\n\n') : null;
      } catch (error) {
        console.error('Failed to decrypt opportunity transcripts:', error);
        return null;
      }
    }
    
    if (extractMode === 'account') {
      if (!accountTranscripts?.length) return null;
      try {
        // Decrypt all account transcripts in parallel
        const decryptedContents = await Promise.all(
          accountTranscripts.map(async (t) => {
            try {
              return await decryptTranscript(t.id, 'transcript_reviews');
            } catch (error) {
              console.error(`Failed to decrypt transcript ${t.id}:`, error);
              return null;
            }
          })
        );
        const validContents = decryptedContents.filter(Boolean);
        return validContents.length > 0 ? validContents.join('\n\n---\n\n') : null;
      } catch (error) {
        console.error('Failed to decrypt account transcripts:', error);
        return null;
      }
    }
    
    return null;
  };
  
  const handleExtractFromTranscript = async () => {
    if (!categories) return;
    
    const content = await getTranscriptContent();
    if (!content) {
      toast({
        title: 'No Content',
        description: 'Please provide transcript content to extract from.',
        variant: 'destructive',
      });
      return;
    }
    
    // Flatten all questions with category names
    const allQuestions = categories.flatMap(cat => 
      cat.questions.map(q => ({
        id: q.id,
        question: q.question,
        category_name: cat.name,
      }))
    );
    
    try {
      const result = await extractFromTranscript.mutateAsync({
        transcript: content,
        opportunityId,
        questions: allQuestions,
      });
      
      // Notify parent of detected deployment types
      if (result.detected_deployment_types?.length > 0 && onDeploymentTypesDetected) {
        onDeploymentTypesDetected(result.detected_deployment_types);
      }
      
      const deploymentTypesDetected = result.detected_deployment_types?.length || 0;
      toast({
        title: 'Extraction Complete',
        description: `Extracted ${result.extracted_count} answers${deploymentTypesDetected > 0 ? ` and detected ${deploymentTypesDetected} deployment type(s)` : ''}. ${result.unanswered_count} questions remain unanswered.`,
      });
      
      setShowExtractDialog(false);
      setTranscriptText('');
      setSelectedTranscriptId('');
    } catch (error) {
      toast({
        title: 'Extraction Failed',
        description: error instanceof Error ? error.message : 'Failed to extract answers',
        variant: 'destructive',
      });
    }
  };
  
  const openExtractDialog = (mode: ExtractMode) => {
    setExtractMode(mode);
    setTranscriptText('');
    setSelectedTranscriptId('');
    setShowExtractDialog(true);
  };
  
  const handleImportApps = async () => {
    if (selectedAppsToImport.size === 0) return;
    
    const appsToImport = (accountOpportunityApps || [])
      .filter(app => selectedAppsToImport.has(app.id))
      .map(app => ({
        appId: app.id,
        appName: app.app_name,
        sourceOpportunityId: app.opportunity_id,
      }));
    
    try {
      const imported = await importApps.mutateAsync({
        targetOpportunityId: opportunityId,
        sourceApps: appsToImport,
      });
      
      toast({
        title: 'Apps imported',
        description: `Imported ${imported.length} application(s) with their answers`,
      });
      
      setShowImportAppsDialog(false);
      setSelectedAppsToImport(new Set());
    } catch (error) {
      toast({
        title: 'Import failed',
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: 'destructive',
      });
    }
  };
  
  const toggleAppSelection = (appId: string) => {
    setSelectedAppsToImport(prev => {
      const next = new Set(prev);
      if (next.has(appId)) {
        next.delete(appId);
      } else {
        next.add(appId);
      }
      return next;
    });
  };

  if (loadingCategories || loadingAnswers) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  // Show info banner if no deployment types selected, but still show questions
  const noDeploymentTypesSelected = deploymentTypeIds.length === 0;

  return (
    <div className="p-6 space-y-6">
      {/* Info banner when no deployment types selected */}
      {noDeploymentTypesSelected && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-amber-700 dark:text-amber-400">No deployment types selected</p>
            <p className="text-xs text-muted-foreground mt-1">
              Showing all readiness questions. Select deployment types in the Overview tab to filter to relevant questions.
            </p>
          </div>
        </div>
      )}

      {/* Header with stats */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Technical Readiness</h2>
          <p className="text-sm text-muted-foreground">
            Answer these questions to document technical requirements and identify gaps
          </p>
        </div>
        <div className="flex items-center gap-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Sparkles className="w-4 h-4" />
                Extract from Transcript
                <ChevronDown className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem onClick={() => openExtractDialog('paste')}>
                <ClipboardPaste className="w-4 h-4 mr-2" />
                Paste Transcript
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => openExtractDialog('select')}
                disabled={!accountTranscripts?.length}
              >
                <FileText className="w-4 h-4 mr-2" />
                Select a Transcript
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                onClick={() => openExtractDialog('opportunity')}
                disabled={!opportunityTranscripts.length}
              >
                <Files className="w-4 h-4 mr-2" />
                All Opportunity Transcripts ({opportunityTranscripts.length})
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => openExtractDialog('account')}
                disabled={!accountTranscripts?.length}
              >
                <Files className="w-4 h-4 mr-2" />
                All Account Transcripts ({accountTranscripts?.length || 0})
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                onClick={() => {
                  setSelectedAppsToImport(new Set());
                  setShowImportAppsDialog(true);
                }}
                disabled={!accountOpportunityApps?.length}
              >
                <Import className="w-4 h-4 mr-2" />
                Import Apps from Other Opportunities ({accountOpportunityApps?.length || 0})
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          {/* Create Review NBA button - only show when there are red/amber flags */}
          {(stats.redCount > 0 || stats.amberCount > 0) && (
            <Button 
              variant="outline" 
              className="gap-2 border-amber-500/50 text-amber-600 hover:bg-amber-500/10"
              onClick={handleCreateReviewNBA}
              disabled={createReviewNBA.isPending}
            >
              {createReviewNBA.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <AlertTriangle className="w-4 h-4" />
              )}
              Create Review Task
            </Button>
          )}
          
          <Dialog open={showExtractDialog} onOpenChange={setShowExtractDialog}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {extractMode === 'paste' && 'Paste Transcript'}
                  {extractMode === 'select' && 'Select a Transcript'}
                  {extractMode === 'opportunity' && 'Extract from All Opportunity Transcripts'}
                  {extractMode === 'account' && 'Extract from All Account Transcripts'}
                </DialogTitle>
                <DialogDescription>
                  {extractMode === 'paste' && 'Paste a meeting transcript and AI will automatically extract answers to the technical readiness questions.'}
                  {extractMode === 'select' && 'Select a transcript from this account to extract answers from.'}
                  {extractMode === 'opportunity' && `AI will analyze ${opportunityTranscripts.length} transcript(s) linked to this opportunity.`}
                  {extractMode === 'account' && `AI will analyze ${accountTranscripts?.length || 0} transcript(s) from this account.`}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                {extractMode === 'paste' && (
                  <Textarea
                    value={transcriptText}
                    onChange={(e) => setTranscriptText(e.target.value)}
                    placeholder="Paste the transcript content here..."
                    className="min-h-[300px]"
                  />
                )}
                
                {extractMode === 'select' && (
                  <Select value={selectedTranscriptId} onValueChange={setSelectedTranscriptId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a transcript..." />
                    </SelectTrigger>
                    <SelectContent>
                      {accountTranscripts?.map(t => (
                        <SelectItem key={t.id} value={t.id}>
                          {t.file_name || `Transcript from ${new Date(t.created_at).toLocaleDateString()}`}
                          {t.opportunity_id === opportunityId && (
                            <Badge variant="outline" className="ml-2 text-xs">This Opportunity</Badge>
                          )}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
                
                {(extractMode === 'opportunity' || extractMode === 'account') && (
                  <div className="glass rounded-lg p-4">
                    <div className="text-sm text-muted-foreground mb-2">
                      {extractMode === 'opportunity' ? 'Opportunity' : 'Account'} transcripts to process:
                    </div>
                    <ul className="space-y-1 text-sm max-h-[200px] overflow-y-auto">
                      {(extractMode === 'opportunity' ? opportunityTranscripts : accountTranscripts)?.map(t => (
                        <li key={t.id} className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-muted-foreground" />
                          {t.file_name || `Transcript from ${new Date(t.created_at).toLocaleDateString()}`}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowExtractDialog(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleExtractFromTranscript} 
                    disabled={
                      extractFromTranscript.isPending ||
                      (extractMode === 'paste' && !transcriptText.trim()) ||
                      (extractMode === 'select' && !selectedTranscriptId) ||
                      (extractMode === 'opportunity' && !opportunityTranscripts.length) ||
                      (extractMode === 'account' && !accountTranscripts?.length)
                    }
                    className="gap-2"
                  >
                    {extractFromTranscript.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Extracting...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        Extract Answers
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          
          {/* Import Apps Dialog */}
          <Dialog open={showImportAppsDialog} onOpenChange={setShowImportAppsDialog}>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Import Apps from Other Opportunities</DialogTitle>
                <DialogDescription>
                  Select applications from other opportunities in this account to import. 
                  Their readiness answers will be copied to this opportunity.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 mt-4 max-h-[400px] overflow-y-auto">
                {accountOpportunityApps && accountOpportunityApps.length > 0 ? (
                  <>
                    {/* Group by opportunity */}
                    {Object.entries(
                      accountOpportunityApps.reduce((acc, app) => {
                        if (!acc[app.opportunity_id]) {
                          acc[app.opportunity_id] = {
                            opportunityName: app.opportunity_name,
                            apps: [],
                          };
                        }
                        acc[app.opportunity_id].apps.push(app);
                        return acc;
                      }, {} as Record<string, { opportunityName: string; apps: typeof accountOpportunityApps }>)
                    ).map(([oppId, { opportunityName, apps }]) => (
                      <div key={oppId} className="space-y-2">
                        <div className="text-sm font-medium text-muted-foreground">{opportunityName}</div>
                        <div className="space-y-1 pl-2">
                          {apps.map(app => (
                            <label
                              key={app.id}
                              className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 cursor-pointer"
                            >
                              <Checkbox
                                checked={selectedAppsToImport.has(app.id)}
                                onCheckedChange={() => toggleAppSelection(app.id)}
                              />
                              <span className="text-sm">{app.app_name}</span>
                              {app.is_primary && (
                                <Badge variant="outline" className="text-[10px] h-5">Primary</Badge>
                              )}
                            </label>
                          ))}
                        </div>
                      </div>
                    ))}
                  </>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <p className="text-sm">No applications found in other opportunities for this account.</p>
                  </div>
                )}
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={() => setShowImportAppsDialog(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleImportApps}
                  disabled={selectedAppsToImport.size === 0 || importApps.isPending}
                  className="gap-2"
                >
                  {importApps.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Importing...
                    </>
                  ) : (
                    <>
                      <Import className="w-4 h-4" />
                      Import {selectedAppsToImport.size > 0 ? `(${selectedAppsToImport.size})` : ''}
                    </>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          <div className="flex items-center gap-2">
            <Select value={filter} onValueChange={(v: any) => setFilter(v)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Questions</SelectItem>
                <SelectItem value="unanswered">Unanswered ({stats.gaps})</SelectItem>
                <SelectItem value="ai-filled">AI-Filled ({stats.aiAnswered})</SelectItem>
                {stats.pending > 0 && (
                  <SelectItem value="pending">
                    <span className="flex items-center gap-1">
                      <History className="w-3 h-3 text-amber-500" />
                      Pending Review ({stats.pending})
                    </span>
                  </SelectItem>
                )}
                <SelectItem value="red-flags">
                  <span className="flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-destructive" />
                    Red/Amber Flags ({stats.redCount + stats.amberCount})
                  </span>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-6 gap-4">
        <div className="glass rounded-lg p-4">
          <div className="text-2xl font-bold">{stats.readinessScore}%</div>
          <div className="text-sm text-muted-foreground">Readiness Score</div>
        </div>
        <div className="glass rounded-lg p-4">
          <div className="text-2xl font-bold text-primary">{stats.answered}/{stats.activeTotal}</div>
          <div className="text-sm text-muted-foreground">Answered</div>
          {stats.disabledCount > 0 && (
            <div className="text-xs text-muted-foreground mt-1">{stats.disabledCount} excluded</div>
          )}
        </div>
        <div className="glass rounded-lg p-4 flex items-center gap-2 border border-green-500/30 bg-green-500/5">
          <CheckCircle2 className="w-5 h-5 text-green-500" />
          <div>
            <div className="text-2xl font-bold text-green-600">{stats.greenCount}</div>
            <div className="text-sm text-muted-foreground">Green</div>
          </div>
        </div>
        <div className={cn(
          "glass rounded-lg p-4 flex items-center gap-2",
          stats.amberCount > 0 && "border border-amber-500/50 bg-amber-500/5"
        )}>
          <AlertCircle className={cn("w-5 h-5", stats.amberCount > 0 ? "text-amber-500" : "text-muted-foreground")} />
          <div>
            <div className={cn("text-2xl font-bold", stats.amberCount > 0 && "text-amber-600")}>{stats.amberCount}</div>
            <div className="text-sm text-muted-foreground">Amber</div>
          </div>
        </div>
        <div className={cn(
          "glass rounded-lg p-4 flex items-center gap-2",
          stats.redCount > 0 && "border border-destructive/50 bg-destructive/5"
        )}>
          <AlertTriangle className={cn("w-5 h-5", stats.redCount > 0 ? "text-destructive" : "text-muted-foreground")} />
          <div>
            <div className={cn("text-2xl font-bold", stats.redCount > 0 && "text-destructive")}>{stats.redCount}</div>
            <div className="text-sm text-muted-foreground">Red</div>
          </div>
        </div>
        <div className="glass rounded-lg p-4 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          <div>
            <div className="text-2xl font-bold">{stats.aiAnswered}</div>
            <div className="text-sm text-muted-foreground">AI-Extracted</div>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="space-y-4">
        {filteredCategories.map(category => {
          const isExpanded = expandedCategories.has(category.id);
          
          // Recursively count answered questions including sub-questions (excluding disabled and hidden by trigger)
          const countAnsweredRecursive = (questions: ReadinessQuestion[], parentAnswer?: ReadinessAnswer): { answered: number; active: number } => {
            return questions.reduce((acc, q) => {
              // Skip sub-questions whose trigger condition is not met
              if (q.trigger_condition && parentAnswer) {
                const parentAnswerText = parentAnswer?.answer || null;
                if (!shouldShowSubQuestion(parentAnswerText, q.trigger_condition)) {
                  return acc;
                }
              }
              const a = answerMap.get(q.id);
              const disabled = isFlagDisabled(a);
              const isAnswered = !disabled && (a?.answer || a?.answer_json) ? 1 : 0;
              const activeCount = disabled ? 0 : 1;
              const childStats = q.children ? countAnsweredRecursive(q.children, a) : { answered: 0, active: 0 };
              return { 
                answered: acc.answered + isAnswered + childStats.answered, 
                active: acc.active + activeCount + childStats.active 
              };
            }, { answered: 0, active: 0 });
          };
          
          const categoryStats = countAnsweredRecursive(category.questions);
          const categoryAnswered = categoryStats.answered;
          const categoryTotal = categoryStats.active;
          
          return (
            <Collapsible key={category.id} open={isExpanded} onOpenChange={() => toggleCategory(category.id)}>
              <CollapsibleTrigger asChild>
                <div className="glass rounded-xl p-4 cursor-pointer hover:bg-muted/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {isExpanded ? (
                        <ChevronDown className="w-5 h-5 text-muted-foreground" />
                      ) : (
                        <ChevronRight className="w-5 h-5 text-muted-foreground" />
                      )}
                      <div>
                        <h3 className="font-semibold">{category.name}</h3>
                        {category.description && (
                          <p className="text-sm text-muted-foreground">{category.description}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={categoryAnswered === categoryTotal ? 'default' : 'outline'}>
                        {categoryAnswered} / {categoryTotal}
                      </Badge>
                      {categoryAnswered === categoryTotal && categoryTotal > 0 && (
                        <CheckCircle2 className="w-5 h-5 text-primary" />
                      )}
                    </div>
                  </div>
                </div>
              </CollapsibleTrigger>
              
              <CollapsibleContent>
                <div className="mt-2 pl-8">
                  {category.is_app_scoped ? (
                    <div className="glass rounded-lg p-4">
                      <AppScopedCategorySection
                        apps={readinessApps || []}
                        onCreateApp={async (name, isPrimary) => {
                          return await createApp.mutateAsync({ opportunityId, appName: name, isPrimary });
                        }}
                        onDeleteApp={async (appId) => {
                          await deleteApp.mutateAsync({ appId, opportunityId });
                        }}
                        onUpdateApp={async (appId, name) => {
                          await updateApp.mutateAsync({ appId, appName: name, opportunityId });
                        }}
                        onCopyAppAnswers={async (sourceAppId, targetAppId) => {
                          await copyAppAnswers.mutateAsync({ opportunityId, sourceAppId, targetAppId });
                        }}
                        renderQuestionsForApp={(appId) => (
                          <>
                            {category.questions.map(question => {
                              // For app-scoped, look up answer by question_id + app_id
                              // Fallback: if no answer found for this app_id, check for null app_id answers
                              // (legacy answers created before app system was added)
                              const appAnswer = (answers || []).find(
                                a => a.question_id === question.id && a.app_id === appId
                              ) || (answers || []).find(
                                a => a.question_id === question.id && a.app_id === null
                              );
                              return (
                                <QuestionField
                                  key={question.id}
                                  question={question}
                                  answer={appAnswer}
                                  answerMap={answerMap}
                                  onAnswerChange={async (qId, value) => {
                                    await upsertAnswer.mutateAsync({
                                      opportunityId,
                                      questionId: qId,
                                      appId,
                                      answer: value,
                                      source: 'manual',
                                    });
                                  }}
                                  onNotesChange={async (qId, notes) => {
                                    await updateNotes.mutateAsync({ opportunityId, questionId: qId, notes });
                                  }}
                                  onToggleRedFlag={(qId) => {
                                    const a = (answers || []).find(
                                      ans => ans.question_id === qId && ans.app_id === appId
                                    ) || (answers || []).find(
                                      ans => ans.question_id === qId && ans.app_id === null
                                    );
                                    handleToggleRedFlag(qId, a?.is_red_flag || false);
                                  }}
                                  onSetManualFlag={async (qId, flagStatus) => {
                                    await setManualFlag.mutateAsync({ opportunityId, questionId: qId, flagStatus });
                                    toast({ title: flagStatus ? `Flag set to ${flagStatus}` : 'Flag reset to auto' });
                                  }}
                                  onConfirmAnswer={async (qId) => {
                                    await confirmAnswer.mutateAsync({ opportunityId, questionId: qId });
                                    toast({ title: 'Answer locked' });
                                  }}
                                  onUnlockAnswer={async (qId) => {
                                    await unlockAnswer.mutateAsync({ opportunityId, questionId: qId });
                                    toast({ title: 'Answer unlocked - you can now edit it' });
                                  }}
                                  opportunityId={opportunityId}
                                  accountId={accountId}
                                  isPending={upsertAnswer.isPending}
                                  isTogglingFlag={toggleRedFlag.isPending}
                                  isSettingFlag={setManualFlag.isPending}
                                  isConfirming={confirmAnswer.isPending}
                                  isUnlocking={unlockAnswer.isPending}
                                  depth={0}
                                />
                              );
                            })}
                          </>
                        )}
                      />
                    </div>
                  ) : (
                  <div className="glass rounded-lg p-4 space-y-2">
                    {category.questions.map(question => {
                      const answer = answerMap.get(question.id);
                      return (
                        <QuestionField
                          key={question.id}
                          question={question}
                          answer={answer}
                          answerMap={answerMap}
                          onAnswerChange={(qId, value) => handleAnswerChange(qId, value)}
                          onNotesChange={async (qId, notes) => {
                            await updateNotes.mutateAsync({ opportunityId, questionId: qId, notes });
                          }}
                          onToggleRedFlag={(qId) => {
                            const a = answerMap.get(qId);
                            handleToggleRedFlag(qId, a?.is_red_flag || false);
                          }}
                          onSetManualFlag={async (qId, flagStatus) => {
                            await setManualFlag.mutateAsync({ opportunityId, questionId: qId, flagStatus });
                            toast({ title: flagStatus ? `Flag set to ${flagStatus}` : 'Flag reset to auto' });
                          }}
                          onConfirmAnswer={async (qId) => {
                            await confirmAnswer.mutateAsync({ opportunityId, questionId: qId });
                            toast({ title: 'Answer locked' });
                          }}
                          onUnlockAnswer={async (qId) => {
                            await unlockAnswer.mutateAsync({ opportunityId, questionId: qId });
                            toast({ title: 'Answer unlocked - you can now edit it' });
                          }}
                          opportunityId={opportunityId}
                          accountId={accountId}
                          isPending={upsertAnswer.isPending}
                          isTogglingFlag={toggleRedFlag.isPending}
                          isSettingFlag={setManualFlag.isPending}
                          isConfirming={confirmAnswer.isPending}
                          isUnlocking={unlockAnswer.isPending}
                          depth={0}
                        />
                      );
                    })}
                  </div>
                  )}
                </div>
              </CollapsibleContent>
            </Collapsible>
          );
        })}
      </div>

      {filteredCategories.length === 0 && filter !== 'all' && (
        <div className="glass rounded-xl p-8 text-center">
          <CheckCircle2 className="w-12 h-12 text-primary mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">
            {filter === 'unanswered' ? 'All Questions Answered!' : 'No AI-Extracted Answers'}
          </h3>
          <p className="text-muted-foreground">
            {filter === 'unanswered' 
              ? 'Great job! All technical readiness questions have been answered.'
              : 'Process transcripts to auto-extract technical details.'}
          </p>
        </div>
      )}
    </div>
  );
}

interface QuestionFieldProps {
  question: ReadinessQuestion;
  answer: ReadinessAnswer | undefined;
  answerMap: Map<string, ReadinessAnswer>;
  onAnswerChange: (questionId: string, value: string) => void;
  onNotesChange: (questionId: string, notes: string | null) => void;
  onToggleRedFlag: (questionId: string) => void;
  onSetManualFlag: (questionId: string, flagStatus: FlagType | null) => void;
  onConfirmAnswer: (questionId: string) => void;
  onUnlockAnswer: (questionId: string) => void;
  opportunityId: string;
  accountId: string;
  isPending: boolean;
  isTogglingFlag: boolean;
  isSettingFlag: boolean;
  isConfirming: boolean;
  isUnlocking: boolean;
  depth: number;
}

function QuestionField({ question, answer, answerMap, onAnswerChange, onNotesChange, onToggleRedFlag, onSetManualFlag, onConfirmAnswer, onUnlockAnswer, opportunityId, accountId, isPending, isTogglingFlag, isSettingFlag, isConfirming, isUnlocking, depth }: QuestionFieldProps) {
  const [localValue, setLocalValue] = useState(answer?.answer || '');
  const [showDiscoveryTips, setShowDiscoveryTips] = useState(false);
  const [showNotes, setShowNotes] = useState(!!answer?.notes);
  const [localNotes, setLocalNotes] = useState(answer?.notes || '');
  
  // Sync localValue when answer changes (e.g., after fetch/decryption/extraction)
  // NOTE: do not compare against localValue here; the closure can go stale and prevent updates.
  React.useEffect(() => {
    setLocalValue(answer?.answer || '');
  }, [answer?.id, answer?.answer]);
  
  React.useEffect(() => {
    setLocalNotes(answer?.notes || '');
    if (answer?.notes) setShowNotes(true);
  }, [answer?.id, answer?.notes]);
  
  const hasValue = !!answer?.answer || !!answer?.answer_json;
  const isAiExtracted = answer?.source === 'transcript_ai' || answer?.source === 'ai_enrichment';
  const isConfirmed = !!answer?.last_confirmed_at;
  
  // Confidence-based flag system
  const flagType = getFlagType(answer);
  const isDisabled = isFlagDisabled(answer);
  const hasManualOverride = hasManualFlagOverride(answer);
  
  // Get visible child questions (hierarchical structure)
  const visibleChildren = useMemo(() => {
    if (!question.children) return [];
    return question.children.filter(child => 
      shouldShowSubQuestion(answer?.answer || null, child.trigger_condition || { type: 'any' })
    );
  }, [question.children, answer?.answer]);
  
  const handleBlur = () => {
    if (localValue !== (answer?.answer || '')) {
      onAnswerChange(question.id, localValue);
    }
  };

  // Determine if this is a "long form" question that needs full width
  const isLongForm = question.question.length > 100 || question.field_type === 'textarea' || visibleChildren.length > 0;
  
  // Visual nesting styles for sub-questions
  const isSubQuestion = depth > 0;
  
  // Flag styling - now defaults to red for unanswered questions
  // For sub-questions, use inner border instead of outer
  const getFlagBorderClass = () => {
    if (isDisabled) return '';
    // All questions show flag styling based on their status (red is default)
    if (flagType === 'red') return isSubQuestion 
      ? 'bg-destructive/5 rounded-lg pr-3 py-2 border border-destructive/30' 
      : 'border-l-2 border-l-destructive pl-3 bg-destructive/5 rounded-r-lg pr-3 py-2 -ml-3';
    if (flagType === 'amber') return isSubQuestion
      ? 'bg-amber-500/5 rounded-lg pr-3 py-2 border border-amber-500/30'
      : 'border-l-2 border-l-amber-500 pl-3 bg-amber-500/5 rounded-r-lg pr-3 py-2 -ml-3';
    if (flagType === 'green') return isSubQuestion
      ? 'border border-green-500/30 rounded-lg'
      : 'border-l-2 border-l-green-500 pl-3';
    return '';
  };
  
  return (
    <div 
      className={cn(
        "transition-colors space-y-2",
        getFlagBorderClass()
      )}
    >
      <div className="flex items-center gap-2 mb-1 flex-wrap">
        {/* Flag status dropdown - allows setting manual flag */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              disabled={isTogglingFlag || isSettingFlag}
              className={cn(
                "p-0.5 rounded transition-colors hover:bg-muted",
                isDisabled && "text-muted-foreground/40",
                !isDisabled && flagType === 'red' && "text-destructive",
                !isDisabled && flagType === 'amber' && "text-amber-500",
                !isDisabled && flagType === 'green' && "text-green-500"
              )}
            >
              <Flag className={cn(
                "w-3.5 h-3.5", 
                isDisabled && "opacity-30",
                !isDisabled && flagType === 'red' && "fill-destructive",
                !isDisabled && flagType === 'amber' && "fill-amber-500",
                !isDisabled && flagType === 'green' && "fill-green-500",
                hasManualOverride && "ring-1 ring-offset-1 ring-primary/50 rounded-sm"
              )} />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-48">
            <DropdownMenuItem 
              onClick={() => onSetManualFlag(question.id, 'red')}
              className="text-destructive focus:text-destructive"
            >
              <Flag className="w-3.5 h-3.5 mr-2 fill-destructive" />
              Set as Red Flag
              {!isDisabled && flagType === 'red' && hasManualOverride && <Check className="w-3 h-3 ml-auto" />}
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => onSetManualFlag(question.id, 'amber')}
              className="text-amber-600 focus:text-amber-600"
            >
              <Flag className="w-3.5 h-3.5 mr-2 fill-amber-500" />
              Set as Amber Flag
              {!isDisabled && flagType === 'amber' && hasManualOverride && <Check className="w-3 h-3 ml-auto" />}
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => onSetManualFlag(question.id, 'green')}
              className="text-green-600 focus:text-green-600"
            >
              <Flag className="w-3.5 h-3.5 mr-2" />
              Set as Green Flag
              {!isDisabled && flagType === 'green' && hasManualOverride && <Check className="w-3 h-3 ml-auto" />}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            {hasManualOverride && !isDisabled && (
              <DropdownMenuItem onClick={() => onSetManualFlag(question.id, null)}>
                <X className="w-3.5 h-3.5 mr-2" />
                Reset to Auto
              </DropdownMenuItem>
            )}
            <DropdownMenuItem 
              onClick={() => onToggleRedFlag(question.id)}
              className={isDisabled ? "text-muted-foreground" : ""}
            >
              {isDisabled ? (
                <>
                  <Check className="w-3.5 h-3.5 mr-2" />
                  Re-enable Flag
                </>
              ) : (
                <>
                  <X className="w-3.5 h-3.5 mr-2" />
                  Mark as Not Relevant
                </>
              )}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <span className="text-sm font-medium text-muted-foreground">{question.question}</span>
        {question.is_required && <span className="text-destructive text-xs">*</span>}
        
        {/* Discovery tips button */}
        {question.discovery_prompts && question.discovery_prompts.length > 0 && (
          <TooltipProvider>
            <Tooltip open={showDiscoveryTips} onOpenChange={setShowDiscoveryTips}>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  onClick={() => setShowDiscoveryTips(!showDiscoveryTips)}
                  className="p-0.5 rounded transition-colors hover:bg-muted text-amber-500"
                >
                  <Lightbulb className="w-3.5 h-3.5" />
                </button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <div className="space-y-1">
                  <p className="text-xs font-semibold">Discovery Questions:</p>
                  <ul className="text-xs space-y-1">
                    {question.discovery_prompts.map((prompt, i) => (
                      <li key={i} className="flex items-start gap-1">
                        <MessageSquare className="w-3 h-3 mt-0.5 shrink-0" />
                        {prompt}
                      </li>
                    ))}
                  </ul>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
        
        {question.help_text && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger>
                <HelpCircle className="w-3 h-3 text-muted-foreground" />
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs text-xs">{question.help_text}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
        
        {/* Confidence-based flag badge */}
        {hasValue && !isDisabled && (
          <>
            {flagType === 'red' && (
              <Badge variant="destructive" className="gap-1 text-[10px] h-5 px-1.5">
                <AlertTriangle className="w-2.5 h-2.5" />
                Low Confidence
              </Badge>
            )}
            {flagType === 'amber' && (
              <Badge className="gap-1 text-[10px] h-5 px-1.5 bg-amber-500 text-white border-amber-500">
                <AlertCircle className="w-2.5 h-2.5" />
                Needs Review
              </Badge>
            )}
            {flagType === 'green' && answer?.source !== 'manual' && (
              <Badge className="gap-1 text-[10px] h-5 px-1.5 bg-green-500/20 text-green-600 border-green-500">
                <CheckCircle2 className="w-2.5 h-2.5" />
                Validated
              </Badge>
            )}
          </>
        )}
        
        {isDisabled && (
          <Badge variant="outline" className="gap-1 text-[10px] h-5 px-1.5 text-muted-foreground">
            Disabled
          </Badge>
        )}
        
        {/* Confidence score */}
        {isAiExtracted && answer?.confidence_score && (
          <Badge variant="outline" className="gap-1 text-[10px] h-5 px-1.5">
            <Sparkles className="w-2.5 h-2.5" />
            {Math.round(answer.confidence_score)}%
          </Badge>
        )}
        
        {/* View in transcript link */}
        {answer?.source_transcript_id && (
          <a
            href={`/accounts/${accountId}?opportunity=${opportunityId}&tab=transcripts&transcript=${answer.source_transcript_id}`}
            className="flex items-center gap-1 text-xs text-primary hover:underline"
          >
            <ExternalLink className="w-3 h-3" />
            View source
          </a>
        )}
        
        {/* Confirm/Lock button for any answer with a value */}
        {hasValue && !isConfirmed && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  onClick={() => onConfirmAnswer(question.id)}
                  disabled={isConfirming}
                  className="flex items-center gap-1 text-xs text-primary hover:bg-primary/10 px-1.5 py-0.5 rounded border border-primary/30"
                >
                  <Lock className="w-3 h-3" />
                  Lock
                </button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Lock this answer to prevent AI from overwriting it</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
        
        {isConfirmed && (
          <div className="flex items-center gap-1">
            <Badge variant="outline" className="gap-1 text-[10px] h-5 px-1.5 border-green-500 text-green-600">
              <Lock className="w-2.5 h-2.5" />
              Locked
            </Badge>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    type="button"
                    onClick={() => onUnlockAnswer(question.id)}
                    disabled={isUnlocking}
                    className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground hover:bg-muted px-1.5 py-0.5 rounded"
                  >
                    <Unlock className="w-3 h-3" />
                  </button>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs">Unlock to allow editing and AI updates</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        )}
        
        {/* Notes toggle */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                onClick={() => setShowNotes(!showNotes)}
                className={cn(
                  "p-0.5 rounded transition-colors hover:bg-muted",
                  (showNotes || answer?.notes) ? "text-primary" : "text-muted-foreground"
                )}
              >
                <StickyNote className="w-3.5 h-3.5" />
              </button>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs">{answer?.notes ? 'View/edit notes' : 'Add notes'}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      
      {question.field_type === 'boolean' ? (
        <Select 
          value={localValue || 'undefined'} 
          onValueChange={(v) => {
            setLocalValue(v === 'undefined' ? '' : v);
            onAnswerChange(question.id, v === 'undefined' ? '' : v);
          }}
          disabled={isConfirmed}
        >
          <SelectTrigger className="h-8 text-sm">
            <SelectValue placeholder="Select..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="undefined">Not answered</SelectItem>
            <SelectItem value="yes">Yes</SelectItem>
            <SelectItem value="no">No</SelectItem>
          </SelectContent>
        </Select>
      ) : question.field_type === 'select' && question.options ? (
        <Select 
          value={localValue} 
          onValueChange={(v) => {
            setLocalValue(v);
            onAnswerChange(question.id, v);
          }}
          disabled={isConfirmed}
        >
          <SelectTrigger className="h-8 text-sm">
            <SelectValue placeholder={question.placeholder || 'Select...'} />
          </SelectTrigger>
          <SelectContent>
            {(Array.isArray(question.options) ? question.options : []).map((opt: string) => (
              <SelectItem key={opt} value={opt || '__empty__'}>{opt || 'Empty'}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      ) : isLongForm ? (
        <Textarea
          value={localValue}
          onChange={(e) => setLocalValue(e.target.value)}
          onBlur={handleBlur}
          placeholder={question.placeholder || 'Enter answer...'}
          className="min-h-[60px] text-sm"
          disabled={isConfirmed}
        />
      ) : (
        <Input
          value={localValue}
          onChange={(e) => setLocalValue(e.target.value)}
          onBlur={handleBlur}
          placeholder={question.placeholder || 'Enter answer...'}
          className="h-8 text-sm"
          disabled={isConfirmed}
        />
      )}
      
      {/* AI extraction reasoning - auto-displayed for AI-sourced answers */}
      {isAiExtracted && answer?.notes && answer.notes.startsWith('AI extracted') && (
        <div className="mt-1 px-2 py-1.5 rounded bg-muted/30 border border-muted">
          <p className="text-xs text-muted-foreground italic leading-relaxed">
            {answer.notes}
          </p>
        </div>
      )}
      
      {/* Notes section - editable, toggled by user */}
      {showNotes && (
        <div className="mt-1">
          <Textarea
            value={localNotes}
            onChange={(e) => setLocalNotes(e.target.value)}
            onBlur={() => {
              if (localNotes !== (answer?.notes || '')) {
                onNotesChange(question.id, localNotes || null);
              }
            }}
            placeholder="Add notes..."
            className="min-h-[40px] text-xs bg-muted/30 border-muted"
            rows={2}
          />
        </div>
      )}
      
      {/* Child questions (follow-up questions) - rendered recursively with increased depth */}
      {visibleChildren.length > 0 && (
        <div className="space-y-3 mt-3 pt-2 ml-2 pl-4 border-l-2 border-muted-foreground/20">
          {visibleChildren.map(child => {
            const childAnswer = answerMap.get(child.id);
            return (
              <QuestionField
                key={child.id}
                question={child}
                answer={childAnswer}
                answerMap={answerMap}
                onAnswerChange={onAnswerChange}
                onNotesChange={onNotesChange}
                onToggleRedFlag={onToggleRedFlag}
                onSetManualFlag={onSetManualFlag}
                onConfirmAnswer={onConfirmAnswer}
                onUnlockAnswer={onUnlockAnswer}
                opportunityId={opportunityId}
                accountId={accountId}
                isPending={isPending}
                isTogglingFlag={isTogglingFlag}
                isSettingFlag={isSettingFlag}
                isConfirming={isConfirming}
                isUnlocking={isUnlocking}
                depth={depth + 1}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}


import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Search, 
  Plus, 
  Edit2, 
  Trash2, 
  ExternalLink, 
  AlertTriangle,
  Check,
  Layers,
  Grid3X3,
  List,
  FileSpreadsheet,
  Building2,
  Users,
  FolderTree,
  Lightbulb,
  ChevronDown,
  ChevronRight,
  X,
  Tag,
  Target,
  Package,
  Zap,
  Link2
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { ImportCompetitiveDataDialog } from '@/components/dialogs/ImportCompetitiveDataDialog';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CompetitorScoreEditor } from '@/components/CompetitorScoreEditor';
import { CompetitorScoreBadge } from '@/components/CompetitorScoreBadge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  useTechnologyRepository, 
  useFunctionalAreas,
  useCreateRepositoryTechnology,
  useUpdateRepositoryTechnology,
  useDeleteRepositoryTechnology,
  useTechnologyCategories,
  TechnologyRepoItem
} from '@/hooks/useTechnologyRepository';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const TECHNOLOGY_TYPE_OPTIONS = [
  { value: 'vendor', label: 'Vendor', icon: Building2, description: 'Specific company/product (e.g., Okta, Salesforce)' },
  { value: 'category', label: 'Category', icon: FolderTree, description: 'Technology type (e.g., CRM, SSO, Analytics)' },
  { value: 'concept', label: 'Concept', icon: Lightbulb, description: 'Generic term (e.g., SQL, SaaS, API)' },
];

const LAYER_OPTIONS = [
  { value: 'host', label: 'Host Environment' },
  { value: 'build', label: 'Build Stack' },
  { value: 'adopt', label: 'Adopt Stack' },
  { value: 'growth', label: 'Growth Stack' },
  { value: 'operations', label: 'Business Operations' },
];

const STATUS_OPTIONS = [
  { value: 'approved', label: 'Approved', color: 'bg-green-500/20 text-green-400' },
  { value: 'draft', label: 'Draft', color: 'bg-amber-500/20 text-amber-400' },
];

interface TechFormData {
  name: string;
  functional_areas: string[];
  layers: string[];
  description: string;
  website_url: string;
  logo_url: string;
  is_competitor: boolean;
  competitor_overlap: string;
  competitor_id: string | null;
  capabilities: string[];
  status: string;
  parent_company: string;
  is_customer: boolean;
  customer_notes: string;
  // New taxonomy fields
  technology_type: 'vendor' | 'category' | 'concept';
  parent_category_id: string | null;
  aliases: string[];
  competing_module_ids: string[];
  // Detection rule auto-creation
  create_detection_rule: boolean;
}

const emptyFormData: TechFormData = {
  name: '',
  functional_areas: [],
  layers: [],
  description: '',
  website_url: '',
  logo_url: '',
  is_competitor: false,
  competitor_overlap: '',
  competitor_id: null,
  capabilities: [],
  status: 'draft',
  parent_company: '',
  is_customer: false,
  customer_notes: '',
  technology_type: 'vendor',
  parent_category_id: null,
  aliases: [],
  competing_module_ids: [],
  create_detection_rule: false,
};

export function TechnologyLibraryView() {
  const [searchQuery, setSearchQuery] = useState('');
  const [layerFilter, setLayerFilter] = useState<string>('all');
  const [areaFilter, setAreaFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [competitorFilter, setCompetitorFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list' | 'grouped'>('grouped');
  
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingTech, setEditingTech] = useState<TechnologyRepoItem | null>(null);
  const [deletingTech, setDeletingTech] = useState<TechnologyRepoItem | null>(null);
  const [formData, setFormData] = useState<TechFormData>(emptyFormData);
  const [capabilityInput, setCapabilityInput] = useState('');
  const [aliasInput, setAliasInput] = useState('');

  const { data: technologies, isLoading } = useTechnologyRepository(searchQuery);
  const { data: functionalAreas } = useFunctionalAreas();
  const { data: categories } = useTechnologyCategories();
  const createTech = useCreateRepositoryTechnology();
  const updateTech = useUpdateRepositoryTechnology();
  const deleteTech = useDeleteRepositoryTechnology();

  // Fetch module pricing for competing modules selector
  interface ModulePricingItem {
    id: string;
    module_name: string;
    functional_area_id: string | null;
  }
  const { data: modulePricing } = useQuery({
    queryKey: ['module-pricing-for-tech-library'],
    queryFn: async () => {
      const response = await gateway.from('module_pricing')
        .select('id, module_name, functional_area_id')
        .eq('is_active', true)
        .order('module_name')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as ModulePricingItem[];
    },
  });

  // Filter technologies
  const filteredTechs = useMemo(() => {
    if (!technologies) return [];
    
    return technologies
      .filter(tech => {
        if (layerFilter !== 'all' && tech.layer !== layerFilter) return false;
        if (areaFilter !== 'all' && tech.functional_area !== areaFilter) return false;
        if (statusFilter !== 'all' && tech.status !== statusFilter) return false;
        if (competitorFilter === 'competitor' && !tech.is_competitor) return false;
        if (competitorFilter === 'non-competitor' && tech.is_competitor) return false;
        if (typeFilter !== 'all' && tech.technology_type !== typeFilter) return false;
        return true;
      })
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [technologies, layerFilter, areaFilter, statusFilter, competitorFilter, typeFilter]);

  // Get unique functional areas from data
  const uniqueAreas = useMemo(() => {
    if (!technologies) return [];
    const areas = [...new Set(technologies.map(t => t.functional_area))];
    return areas.sort();
  }, [technologies]);

  const handleOpenAdd = () => {
    setFormData(emptyFormData);
    setEditingTech(null);
    setShowAddDialog(true);
  };

  const handleOpenEdit = (tech: TechnologyRepoItem) => {
    // Parse comma-separated values into arrays
    const parsedLayers = tech.layer ? tech.layer.split(',').map(l => l.trim()).filter(Boolean) : [];
    const parsedAreas = tech.functional_area ? tech.functional_area.split(',').map(a => a.trim()).filter(Boolean) : [];
    
    setFormData({
      name: tech.name,
      functional_areas: parsedAreas,
      layers: parsedLayers,
      description: tech.description || '',
      website_url: tech.website_url || '',
      logo_url: tech.logo_url || '',
      is_competitor: tech.is_competitor || false,
      competitor_overlap: tech.competitor_overlap || '',
      competitor_id: tech.competitor_id || null,
      capabilities: tech.capabilities || [],
      status: tech.status,
      parent_company: tech.parent_company || '',
      is_customer: tech.is_customer || false,
      customer_notes: tech.customer_notes || '',
      technology_type: tech.technology_type || 'vendor',
      parent_category_id: tech.parent_category_id || null,
      aliases: tech.aliases || [],
      competing_module_ids: tech.competing_module_ids || [],
      create_detection_rule: tech.create_detection_rule || false,
    });
    setEditingTech(tech);
    setShowAddDialog(true);
  };

  const handleSave = async () => {
    if (!formData.name.trim() || formData.functional_areas.length === 0) {
      toast.error('Name and at least one Functional Area are required');
      return;
    }
    if (formData.layers.length === 0) {
      toast.error('At least one Layer is required');
      return;
    }

    // Convert arrays to comma-separated strings for database storage
    const dataToSave = {
      name: formData.name,
      functional_area: formData.functional_areas.join(', '),
      layer: formData.layers.join(', '),
      description: formData.description,
      website_url: formData.website_url,
      logo_url: formData.logo_url,
      is_competitor: formData.is_competitor,
      competitor_overlap: formData.competitor_overlap,
      competitor_id: formData.competitor_id,
      capabilities: formData.capabilities,
      status: formData.status,
      parent_company: formData.parent_company,
      is_customer: formData.is_customer,
      customer_notes: formData.customer_notes,
      technology_type: formData.technology_type,
      parent_category_id: formData.parent_category_id,
      aliases: formData.aliases,
      competing_module_ids: formData.competing_module_ids,
      create_detection_rule: formData.create_detection_rule,
    };

    try {
      if (editingTech) {
        await updateTech.mutateAsync({
          id: editingTech.id,
          ...dataToSave,
        });
        toast.success('Technology updated');
      } else {
        await createTech.mutateAsync(dataToSave);
        toast.success('Technology added to library');
      }
      setShowAddDialog(false);
      setEditingTech(null);
    } catch (error) {
      toast.error('Failed to save technology');
    }
  };

  const handleDelete = async () => {
    if (!deletingTech) return;
    
    try {
      await deleteTech.mutateAsync(deletingTech.id);
      toast.success('Technology removed');
      setDeletingTech(null);
    } catch (error) {
      toast.error('Failed to delete technology');
    }
  };

  const addCapability = () => {
    if (capabilityInput.trim() && !formData.capabilities.includes(capabilityInput.trim())) {
      setFormData(prev => ({
        ...prev,
        capabilities: [...prev.capabilities, capabilityInput.trim()],
      }));
      setCapabilityInput('');
    }
  };

  const removeCapability = (cap: string) => {
    setFormData(prev => ({
      ...prev,
      capabilities: prev.capabilities.filter(c => c !== cap),
    }));
  };

  const stats = useMemo(() => {
    if (!technologies) return { total: 0, approved: 0, draft: 0, competitors: 0, customers: 0 };
    return {
      total: technologies.length,
      approved: technologies.filter(t => t.status === 'approved').length,
      draft: technologies.filter(t => t.status === 'draft').length,
      competitors: technologies.filter(t => t.is_competitor).length,
      customers: technologies.filter(t => t.is_customer).length,
    };
  }, [technologies]);

  // State for expanded categories in accordion
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(categoryId)) {
        next.delete(categoryId);
      } else {
        next.add(categoryId);
      }
      return next;
    });
  };

  const expandAll = () => {
    const allIds = groupedTechs.map(g => g.categoryId);
    setExpandedCategories(new Set(allIds));
  };

  const collapseAll = () => {
    setExpandedCategories(new Set());
  };

  // Group technologies by category for grouped view - alphabetical index
  const groupedTechs = useMemo(() => {
    if (!filteredTechs || filteredTechs.length === 0) return [];
    
    // Get all categories
    const categoryTechs = filteredTechs.filter(t => t.technology_type === 'category');
    const vendorTechs = filteredTechs.filter(t => t.technology_type === 'vendor');
    const conceptTechs = filteredTechs.filter(t => t.technology_type === 'concept');
    
    // Create grouped structure
    const groups: { categoryId: string; categoryName: string; category: TechnologyRepoItem | null; items: TechnologyRepoItem[]; type: 'category' | 'uncategorized' | 'concepts' }[] = [];
    
    // Add categories with their vendors
    categoryTechs.forEach(cat => {
      const vendors = vendorTechs.filter(v => v.parent_category_id === cat.id);
      if (vendors.length > 0 || true) { // Show category even if empty
        groups.push({ 
          categoryId: cat.id, 
          categoryName: cat.name, 
          category: cat, 
          items: vendors.sort((a, b) => a.name.localeCompare(b.name)),
          type: 'category'
        });
      }
    });
    
    // Add uncategorized vendors (no parent_category_id)
    const uncategorizedVendors = vendorTechs.filter(v => !v.parent_category_id);
    if (uncategorizedVendors.length > 0) {
      groups.push({ 
        categoryId: 'uncategorized', 
        categoryName: 'Uncategorized', 
        category: null, 
        items: uncategorizedVendors.sort((a, b) => a.name.localeCompare(b.name)),
        type: 'uncategorized'
      });
    }
    
    // Add concepts as a separate group if any
    if (conceptTechs.length > 0) {
      groups.push({ 
        categoryId: 'concepts', 
        categoryName: 'Concepts & Generic Terms', 
        category: null, 
        items: conceptTechs.sort((a, b) => a.name.localeCompare(b.name)),
        type: 'concepts'
      });
    }
    
    // Sort alphabetically by category name, with Uncategorized and Concepts at end
    return groups.sort((a, b) => {
      if (a.type === 'uncategorized') return 1;
      if (b.type === 'uncategorized') return -1;
      if (a.type === 'concepts') return 1;
      if (b.type === 'concepts') return -1;
      return a.categoryName.localeCompare(b.categoryName);
    });
  }, [filteredTechs]);

  return (
    <div className="flex flex-col h-full p-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="page-heading">Technology Library</h1>
          <p className="text-sm text-muted-foreground">
            Manage the master list of technologies for your reference architecture
          </p>
        </div>
        <div className="flex items-center gap-2">
          <ImportCompetitiveDataDialog>
            <Button variant="outline" className="gap-2">
              <FileSpreadsheet className="w-4 h-4" />
              Import Competitive Data
            </Button>
          </ImportCompetitiveDataDialog>
          <Button onClick={handleOpenAdd} className="gap-2">
            <Plus className="w-4 h-4" />
            Add Technology
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card className="glass">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Layers className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-xs text-muted-foreground">Total</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                <Check className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.approved}</p>
                <p className="text-xs text-muted-foreground">Approved</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                <Edit2 className="w-5 h-5 text-amber-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.draft}</p>
                <p className="text-xs text-muted-foreground">Draft</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.competitors}</p>
                <p className="text-xs text-muted-foreground">Competitors</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search technologies..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        
        <Select value={layerFilter} onValueChange={setLayerFilter}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Layer" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Layers</SelectItem>
            {LAYER_OPTIONS.map(opt => (
              <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={areaFilter} onValueChange={setAreaFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Functional Area" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Areas</SelectItem>
            {uniqueAreas.map(area => (
              <SelectItem key={area} value={area}>{area}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[130px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
          </SelectContent>
        </Select>

        <Select value={competitorFilter} onValueChange={setCompetitorFilter}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Competitor" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="competitor">Competitors</SelectItem>
            <SelectItem value="non-competitor">Non-competitors</SelectItem>
          </SelectContent>
        </Select>

        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {TECHNOLOGY_TYPE_OPTIONS.map(opt => (
              <SelectItem key={opt.value} value={opt.value}>
                <div className="flex items-center gap-2">
                  <opt.icon className="w-3 h-3" />
                  {opt.label}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="flex items-center gap-1 ml-auto">
          <Button
            variant={viewMode === 'grouped' ? 'secondary' : 'ghost'}
            size="icon"
            onClick={() => setViewMode('grouped')}
            title="Grouped by Category"
          >
            <FolderTree className="w-4 h-4" />
          </Button>
          <Button
            variant={viewMode === 'grid' ? 'secondary' : 'ghost'}
            size="icon"
            onClick={() => setViewMode('grid')}
            title="Grid View"
          >
            <Grid3X3 className="w-4 h-4" />
          </Button>
          <Button
            variant={viewMode === 'list' ? 'secondary' : 'ghost'}
            size="icon"
            onClick={() => setViewMode('list')}
            title="List View"
          >
            <List className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Results count and expand/collapse controls */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm text-muted-foreground">
          Showing {filteredTechs.length} of {technologies?.length || 0} technologies
        </span>
        {viewMode === 'grouped' && groupedTechs.length > 0 && (
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={expandAll}>
              Expand All
            </Button>
            <Button variant="ghost" size="sm" onClick={collapseAll}>
              Collapse All
            </Button>
          </div>
        )}
      </div>

      {/* Technology List */}
      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="flex items-center justify-center h-40 text-muted-foreground">
            Loading technologies...
          </div>
        ) : viewMode === 'grouped' ? (
          <div className="space-y-1 pb-4">
            {groupedTechs.map((group) => {
              const isExpanded = expandedCategories.has(group.categoryId);
              return (
                <div key={group.categoryId} className="border border-border rounded-lg overflow-hidden">
                  {/* Category Header - Clickable */}
                  <button
                    onClick={() => toggleCategory(group.categoryId)}
                    className="w-full flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors text-left"
                  >
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    )}
                    <div className={cn(
                      "w-7 h-7 rounded flex items-center justify-center flex-shrink-0",
                      group.type === 'concepts' ? 'bg-purple-500/20' : 
                      group.type === 'uncategorized' ? 'bg-muted' : 'bg-blue-500/20'
                    )}>
                      {group.type === 'concepts' ? (
                        <Lightbulb className="w-4 h-4 text-purple-400" />
                      ) : group.type === 'uncategorized' ? (
                        <Building2 className="w-4 h-4 text-muted-foreground" />
                      ) : (
                        <FolderTree className="w-4 h-4 text-blue-400" />
                      )}
                    </div>
                    <span className="font-medium text-foreground flex-1">
                      {group.categoryName}
                    </span>
                    <Badge variant="secondary" className="text-xs">
                      {group.items.length}
                    </Badge>
                  </button>
                  
                  {/* Expanded Content */}
                  {isExpanded && group.items.length > 0 && (
                    <div className="border-t border-border bg-muted/30 p-3">
                      <div className="space-y-1">
                        {group.items.map(tech => (
                          <div 
                            key={tech.id} 
                            className="flex items-center gap-3 p-2 rounded hover:bg-background transition-colors group"
                          >
                            {tech.logo_url ? (
                              <img 
                                src={tech.logo_url} 
                                alt={tech.name}
                                className="w-6 h-6 object-contain rounded bg-muted p-0.5 flex-shrink-0"
                              />
                            ) : (
                              <div className="w-6 h-6 bg-muted rounded flex items-center justify-center text-xs font-bold text-muted-foreground flex-shrink-0">
                                {tech.name.charAt(0)}
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <span className="text-sm font-medium text-foreground">{tech.name}</span>
                              {tech.aliases && tech.aliases.length > 0 && (
                                <span className="text-xs text-muted-foreground ml-2 italic">
                                  ({tech.aliases.slice(0, 2).join(', ')}{tech.aliases.length > 2 ? '...' : ''})
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-1.5">
                              {tech.is_competitor && (
                                <CompetitorScoreBadge vendorName={tech.name} compact />
                              )}
                              {tech.is_customer && (
                                <Users className="w-3 h-3 text-green-500" />
                              )}
                              {tech.is_competitor && (
                                <AlertTriangle className="w-3 h-3 text-red-500" />
                              )}
                            </div>
                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => handleOpenEdit(tech)}>
                                <Edit2 className="w-3 h-3" />
                              </Button>
                              {tech.website_url && (
                                <Button variant="ghost" size="sm" className="h-6 w-6 p-0" asChild>
                                  <a href={tech.website_url} target="_blank" rel="noopener noreferrer">
                                    <ExternalLink className="w-3 h-3" />
                                  </a>
                                </Button>
                              )}
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                                onClick={() => setDeletingTech(tech)}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {isExpanded && group.items.length === 0 && (
                    <div className="border-t border-border bg-muted/30 p-4 text-center text-sm text-muted-foreground">
                      No technologies in this category
                    </div>
                  )}
                </div>
              );
            })}
            {groupedTechs.length === 0 && (
              <div className="text-center text-muted-foreground py-8">
                No technologies match your filters
              </div>
            )}
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredTechs.map(tech => (
              <Card key={tech.id} className="glass hover:border-pendo-pink/50 transition-colors group">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3 mb-3">
                    {tech.logo_url ? (
                      <img 
                        src={tech.logo_url} 
                        alt={tech.name}
                        className="w-10 h-10 object-contain rounded-lg bg-muted p-1"
                      />
                    ) : (
                      <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center text-lg font-bold text-muted-foreground">
                        {tech.name.charAt(0)}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-foreground truncate">{tech.name}</h3>
                      <p className="text-xs text-muted-foreground truncate">
                        {tech.parent_company ? `${tech.parent_company} · ` : ''}{tech.functional_area}
                      </p>
                    </div>
                    <TooltipProvider>
                      <div className="flex items-center gap-1">
                        {tech.is_customer && (
                          <Tooltip>
                            <TooltipTrigger>
                              <Users className="w-4 h-4 text-green-500 flex-shrink-0" />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-xs">Customer{tech.customer_notes ? `: ${tech.customer_notes}` : ''}</p>
                            </TooltipContent>
                          </Tooltip>
                        )}
                        {tech.is_competitor && (
                          <Tooltip>
                            <TooltipTrigger>
                              <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0" />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-xs">Competitor{tech.parent_company ? ` (${tech.parent_company} portfolio)` : ''}</p>
                            </TooltipContent>
                          </Tooltip>
                        )}
                      </div>
                    </TooltipProvider>
                  </div>
                  
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-3 min-h-[2.5rem]">
                    {tech.description || 'No description'}
                  </p>

                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    {/* Technology type badge */}
                    <Badge 
                      variant="outline" 
                      className={cn(
                        "text-xs gap-1",
                        tech.technology_type === 'category' && 'border-blue-500/50 text-blue-400',
                        tech.technology_type === 'concept' && 'border-purple-500/50 text-purple-400'
                      )}
                    >
                      {tech.technology_type === 'category' && <FolderTree className="w-3 h-3" />}
                      {tech.technology_type === 'concept' && <Lightbulb className="w-3 h-3" />}
                      {tech.technology_type === 'vendor' && <Building2 className="w-3 h-3" />}
                      {tech.technology_type}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {LAYER_OPTIONS.find(l => l.value === tech.layer)?.label || tech.layer}
                    </Badge>
                    <Badge 
                      variant="secondary" 
                      className={cn(
                        "text-xs",
                        tech.status === 'approved' ? 'bg-green-500/20 text-green-400' : 'bg-amber-500/20 text-amber-400'
                      )}
                    >
                      {tech.status}
                    </Badge>
                  </div>

                  {/* Show aliases if any */}
                  {tech.aliases && tech.aliases.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-2">
                      <span className="text-xs text-muted-foreground">aka:</span>
                      {tech.aliases.slice(0, 2).map((alias, i) => (
                        <span key={i} className="text-xs text-muted-foreground italic">{alias}</span>
                      ))}
                      {tech.aliases.length > 2 && (
                        <span className="text-xs text-muted-foreground">+{tech.aliases.length - 2}</span>
                      )}
                    </div>
                  )}

                  {tech.is_competitor && (
                    <div className="mb-3">
                      <CompetitorScoreBadge vendorName={tech.name} />
                    </div>
                  )}

                  {tech.capabilities && tech.capabilities.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {tech.capabilities.slice(0, 3).map((cap, i) => (
                        <span key={i} className="text-xs bg-muted px-2 py-0.5 rounded">
                          {cap}
                        </span>
                      ))}
                      {tech.capabilities.length > 3 && (
                        <span className="text-xs text-muted-foreground">+{tech.capabilities.length - 3}</span>
                      )}
                    </div>
                  )}

                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="sm" onClick={() => handleOpenEdit(tech)}>
                      <Edit2 className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    {tech.website_url && (
                      <Button variant="ghost" size="sm" asChild>
                        <a href={tech.website_url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-3 h-3 mr-1" />
                          Visit
                        </a>
                      </Button>
                    )}
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-destructive hover:text-destructive ml-auto"
                      onClick={() => setDeletingTech(tech)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {filteredTechs.map(tech => (
              <div 
                key={tech.id} 
                className="flex items-center gap-4 p-3 rounded-lg bg-card border border-border hover:border-pendo-pink/50 transition-colors group"
              >
                {tech.logo_url ? (
                  <img 
                    src={tech.logo_url} 
                    alt={tech.name}
                    className="w-8 h-8 object-contain rounded bg-muted p-1"
                  />
                ) : (
                  <div className="w-8 h-8 bg-muted rounded flex items-center justify-center font-bold text-muted-foreground">
                    {tech.name.charAt(0)}
                  </div>
                )}
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-foreground">{tech.name}</span>
                    {tech.is_competitor && <AlertTriangle className="w-3 h-3 text-red-500" />}
                    {tech.is_competitor && <CompetitorScoreBadge vendorName={tech.name} compact />}
                  </div>
                  <p className="text-xs text-muted-foreground">{tech.functional_area}</p>
                </div>

                <Badge variant="outline" className="text-xs hidden md:inline-flex">
                  {LAYER_OPTIONS.find(l => l.value === tech.layer)?.label || tech.layer}
                </Badge>
                
                <Badge 
                  variant="secondary" 
                  className={cn(
                    "text-xs",
                    tech.status === 'approved' ? 'bg-green-500/20 text-green-400' : 'bg-amber-500/20 text-amber-400'
                  )}
                >
                  {tech.status}
                </Badge>

                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="icon" onClick={() => handleOpenEdit(tech)}>
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-destructive hover:text-destructive"
                    onClick={() => setDeletingTech(tech)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {filteredTechs.length === 0 && !isLoading && (
          <div className="flex flex-col items-center justify-center h-40 text-muted-foreground">
            <Layers className="w-12 h-12 mb-2 opacity-50" />
            <p>No technologies found</p>
            <Button variant="link" onClick={handleOpenAdd}>Add one now</Button>
          </div>
        )}
      </ScrollArea>

      {/* Add/Edit Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className={cn(
          "max-h-[90vh] overflow-y-auto",
          formData.is_competitor && editingTech ? "max-w-4xl" : "max-w-lg"
        )}>
          <DialogHeader>
            <DialogTitle>{editingTech ? 'Edit Technology' : 'Add Technology'}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Name *</Label>
                <Input
                  placeholder="e.g., Salesforce"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label>Type *</Label>
                <Select 
                  value={formData.technology_type} 
                  onValueChange={(v: 'vendor' | 'category' | 'concept') => setFormData(prev => ({ ...prev, technology_type: v }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TECHNOLOGY_TYPE_OPTIONS.map(opt => (
                      <SelectItem key={opt.value} value={opt.value}>
                        <div className="flex items-center gap-2">
                          <opt.icon className="w-4 h-4" />
                          <span>{opt.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {TECHNOLOGY_TYPE_OPTIONS.find(o => o.value === formData.technology_type)?.description}
                </p>
              </div>

              {formData.technology_type === 'vendor' && (
                <div className="space-y-2 col-span-2">
                  <Label>Parent Category</Label>
                  <Select 
                    value={formData.parent_category_id || 'none'} 
                    onValueChange={(v) => setFormData(prev => ({ ...prev, parent_category_id: v === 'none' ? null : v }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No parent category</SelectItem>
                      {categories?.map(cat => (
                        <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">Link this vendor to a technology category (e.g., Okta → SSO)</p>
                </div>
              )}

              <div className="space-y-2 col-span-2">
                <Label>Aliases / Synonyms</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add alternative name (e.g., Act 1, Act One)..."
                    value={aliasInput}
                    onChange={(e) => setAliasInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        if (aliasInput.trim() && !formData.aliases.includes(aliasInput.trim())) {
                          setFormData(prev => ({ ...prev, aliases: [...prev.aliases, aliasInput.trim()] }));
                          setAliasInput('');
                        }
                      }
                    }}
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      if (aliasInput.trim() && !formData.aliases.includes(aliasInput.trim())) {
                        setFormData(prev => ({ ...prev, aliases: [...prev.aliases, aliasInput.trim()] }));
                        setAliasInput('');
                      }
                    }}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                {formData.aliases.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.aliases.map((alias, i) => (
                      <Badge key={i} variant="outline" className="gap-1">
                        <Tag className="w-3 h-3" />
                        {alias}
                        <button onClick={() => setFormData(prev => ({ ...prev, aliases: prev.aliases.filter((_, idx) => idx !== i) }))}>
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
                <p className="text-xs text-muted-foreground">Alternative names or spellings that should match this technology</p>
              </div>

              <div className="space-y-2 col-span-2">
                <Label>Layers * (select one or more)</Label>
                <div className="grid grid-cols-2 gap-2 p-3 border rounded-md bg-muted/30">
                  {LAYER_OPTIONS.map(opt => (
                    <div key={opt.value} className="flex items-center gap-2">
                      <Checkbox
                        id={`layer-${opt.value}`}
                        checked={formData.layers.includes(opt.value)}
                        onCheckedChange={(checked) => {
                          setFormData(prev => ({
                            ...prev,
                            layers: checked 
                              ? [...prev.layers, opt.value]
                              : prev.layers.filter(l => l !== opt.value)
                          }));
                        }}
                      />
                      <Label htmlFor={`layer-${opt.value}`} className="text-sm cursor-pointer">
                        {opt.label}
                      </Label>
                    </div>
                  ))}
                </div>
                {formData.layers.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-1">
                    {formData.layers.map(l => (
                      <Badge key={l} variant="secondary" className="text-xs">
                        {LAYER_OPTIONS.find(opt => opt.value === l)?.label || l}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2 col-span-2">
                <Label>Functional Areas * (select one or more)</Label>
                <div className="grid grid-cols-2 gap-2 p-3 border rounded-md bg-muted/30 max-h-48 overflow-y-auto">
                  {functionalAreas?.map(area => (
                    <div key={area.id} className="flex items-center gap-2">
                      <Checkbox
                        id={`area-${area.id}`}
                        checked={formData.functional_areas.includes(area.name)}
                        onCheckedChange={(checked) => {
                          setFormData(prev => ({
                            ...prev,
                            functional_areas: checked 
                              ? [...prev.functional_areas, area.name]
                              : prev.functional_areas.filter(a => a !== area.name)
                          }));
                        }}
                      />
                      <Label htmlFor={`area-${area.id}`} className="text-sm cursor-pointer">
                        {area.name}
                      </Label>
                    </div>
                  ))}
                </div>
                {formData.functional_areas.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-1">
                    {formData.functional_areas.map(a => (
                      <Badge key={a} variant="outline" className="text-xs">
                        {a}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2 col-span-2">
                <Label>Description</Label>
                <Textarea
                  placeholder="Brief description of this technology..."
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label>Website URL</Label>
                <Input
                  placeholder="https://..."
                  value={formData.website_url}
                  onChange={(e) => setFormData(prev => ({ ...prev, website_url: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label>Logo URL</Label>
                <Input
                  placeholder="https://..."
                  value={formData.logo_url}
                  onChange={(e) => setFormData(prev => ({ ...prev, logo_url: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label>Status</Label>
                <Select 
                  value={formData.status} 
                  onValueChange={(v) => setFormData(prev => ({ ...prev, status: v }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 col-span-2">
                <Label>Parent Company / Portfolio</Label>
                <Input
                  placeholder="e.g., SAP, Adobe, Microsoft..."
                  value={formData.parent_company}
                  onChange={(e) => setFormData(prev => ({ ...prev, parent_company: e.target.value }))}
                />
              </div>

              <div className="flex items-center gap-3 pt-2">
                <Switch
                  checked={formData.is_competitor}
                  onCheckedChange={(v) => setFormData(prev => ({ ...prev, is_competitor: v }))}
                />
                <div>
                  <Label className="cursor-pointer">Competitor</Label>
                  {formData.is_competitor && !editingTech && (
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Will be enrolled in competitive scorecard analysis (93 subcategories)
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <Switch
                  checked={formData.is_customer}
                  onCheckedChange={(v) => setFormData(prev => ({ ...prev, is_customer: v }))}
                />
                <Label className="cursor-pointer">Customer</Label>
              </div>

              {/* Detection Rule Auto-Creation Toggle */}
              {(formData.is_competitor || formData.is_customer) && (
                <div className="col-span-2 border-t pt-4 mt-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={formData.create_detection_rule}
                        onCheckedChange={(v) => setFormData(prev => ({ ...prev, create_detection_rule: v }))}
                      />
                      <div>
                        <Label className="cursor-pointer flex items-center gap-2">
                          <Zap className="w-4 h-4 text-amber-500" />
                          Auto-create Detection Rule
                        </Label>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Automatically create a detection rule to identify this technology in transcripts
                        </p>
                      </div>
                    </div>
                    {editingTech?.detection_rule_id && (
                      <Badge variant="secondary" className="gap-1">
                        <Link2 className="w-3 h-3" />
                        Rule Linked
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              {formData.is_competitor && (
                <div className="space-y-2 col-span-2">
                  <Label>Competitor Overlap Notes</Label>
                  <Textarea
                    placeholder="Describe overlap with Pendo..."
                    value={formData.competitor_overlap}
                    onChange={(e) => setFormData(prev => ({ ...prev, competitor_overlap: e.target.value }))}
                    rows={2}
                  />
                </div>
              )}

              {formData.is_competitor && editingTech && (
                <div className="space-y-2 col-span-2 border-t pt-4 mt-2">
                  <div className="flex items-center gap-2 mb-2">
                    <Target className="w-4 h-4 text-primary" />
                    <Label className="text-base font-semibold">Competitive Intelligence</Label>
                  </div>
                  <CompetitorScoreEditor
                    technologyId={editingTech.id}
                    technologyName={formData.name}
                    competitorId={formData.competitor_id}
                    onCompetitorLink={(competitorId) => setFormData(prev => ({ ...prev, competitor_id: competitorId }))}
                  />
                </div>
              )}

              {formData.is_customer && (
                <div className="space-y-2 col-span-2">
                  <Label>Customer Notes</Label>
                  <Textarea
                    placeholder="e.g., SAP is a customer but owns competitor WalkMe..."
                    value={formData.customer_notes}
                    onChange={(e) => setFormData(prev => ({ ...prev, customer_notes: e.target.value }))}
                    rows={2}
                  />
                </div>
              )}

              {/* Competing Modules - only for competitors or technologies that compete with our products */}
              <div className="space-y-2 col-span-2 border-t pt-4 mt-2">
                <div className="flex items-center gap-2 mb-2">
                  <Package className="w-4 h-4 text-amber-500" />
                  <Label className="text-base font-semibold">Competing Modules</Label>
                </div>
                <p className="text-xs text-muted-foreground mb-2">
                  Select which of our modules this technology competes with. If an account has this technology, those modules will be excluded from whitespace calculations.
                </p>
                <div className="grid grid-cols-2 gap-2 p-3 border rounded-md bg-muted/30 max-h-48 overflow-y-auto">
                  {modulePricing?.map(mod => (
                    <div key={mod.id} className="flex items-center gap-2">
                      <Checkbox
                        id={`module-${mod.id}`}
                        checked={formData.competing_module_ids.includes(mod.id)}
                        onCheckedChange={(checked) => {
                          setFormData(prev => ({
                            ...prev,
                            competing_module_ids: checked 
                              ? [...prev.competing_module_ids, mod.id]
                              : prev.competing_module_ids.filter(id => id !== mod.id)
                          }));
                        }}
                      />
                      <Label htmlFor={`module-${mod.id}`} className="text-sm cursor-pointer">
                        {mod.module_name}
                      </Label>
                    </div>
                  ))}
                </div>
                {formData.competing_module_ids.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {formData.competing_module_ids.map(id => {
                      const mod = modulePricing?.find(m => m.id === id);
                      return mod ? (
                        <Badge key={id} variant="secondary" className="text-xs gap-1">
                          <Package className="w-3 h-3" />
                          {mod.module_name}
                          <button onClick={() => setFormData(prev => ({ 
                            ...prev, 
                            competing_module_ids: prev.competing_module_ids.filter(cid => cid !== id) 
                          }))}>
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ) : null;
                    })}
                  </div>
                )}
              </div>

              <div className="space-y-2 col-span-2">
                <Label>Capabilities</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add capability..."
                    value={capabilityInput}
                    onChange={(e) => setCapabilityInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addCapability())}
                  />
                  <Button type="button" variant="outline" onClick={addCapability}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                {formData.capabilities.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.capabilities.map((cap, i) => (
                      <Badge key={i} variant="secondary" className="gap-1">
                        {cap}
                        <button onClick={() => removeCapability(cap)}>
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={createTech.isPending || updateTech.isPending}>
                {editingTech ? 'Save Changes' : 'Add Technology'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingTech} onOpenChange={() => setDeletingTech(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Technology</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deletingTech?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
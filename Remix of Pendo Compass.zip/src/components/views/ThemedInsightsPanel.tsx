import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  AlertTriangle, Lightbulb, TrendingUp, Shield, Target, ChevronDown, 
  ChevronRight, RefreshCw, Sparkles, AlertCircle, CheckCircle2, Activity, ArrowUpRight
} from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { NewBadge, ValidationBadge } from '@/components/InsightChangeIndicators';
import { 
  useAccountStrategicThemes, 
  useAccountExecSummary, 
  useSynthesizeAccountInsights,
  type StrategicTheme,
  type ExecSummary
} from '@/hooks/useAccountStrategicThemes';
import { useOpportunityStrategicThemes } from '@/hooks/useOpportunityStrategicThemes';
import { useAccountPainPoints } from '@/hooks/useAccountPainPoints';
import { useOpportunityPainPoints } from '@/hooks/useOpportunityPainPoints';
import { useThemedUseCases } from '@/hooks/useThemedUseCases';
import { useOpportunityUseCasesThemed } from '@/hooks/useOpportunityUseCasesThemed';
import { cn } from '@/lib/utils';
import { HealthMetricKPICards } from '@/components/HealthMetricKPICards';

interface ThemedInsightsPanelProps {
  accountId: string;
  opportunityId?: string;
}

// Impact level colors
const impactColors: Record<string, string> = {
  critical: 'hsl(var(--destructive))',
  high: 'hsl(346 87% 43%)',
  medium: 'hsl(38 92% 50%)',
  low: 'hsl(var(--muted-foreground))',
};


// Health indicator colors
const healthColors: Record<string, { color: string; icon: React.ReactNode; label: string }> = {
  strong: { color: 'hsl(142 76% 36%)', icon: <CheckCircle2 className="w-4 h-4" />, label: 'Strong' },
  stable: { color: 'hsl(217 91% 60%)', icon: <Activity className="w-4 h-4" />, label: 'Stable' },
  at_risk: { color: 'hsl(38 92% 50%)', icon: <AlertCircle className="w-4 h-4" />, label: 'At Risk' },
  critical: { color: 'hsl(var(--destructive))', icon: <AlertTriangle className="w-4 h-4" />, label: 'Critical' },
  high: { color: 'hsl(142 76% 36%)', icon: <ArrowUpRight className="w-4 h-4" />, label: 'High' },
  moderate: { color: 'hsl(217 91% 60%)', icon: <Activity className="w-4 h-4" />, label: 'Moderate' },
  low: { color: 'hsl(38 92% 50%)', icon: <TrendingUp className="w-4 h-4 rotate-90" />, label: 'Low' },
  declining: { color: 'hsl(var(--destructive))', icon: <TrendingUp className="w-4 h-4 rotate-180" />, label: 'Declining' },
  accelerating: { color: 'hsl(142 76% 36%)', icon: <ArrowUpRight className="w-4 h-4" />, label: 'Accelerating' },
  steady: { color: 'hsl(217 91% 60%)', icon: <Activity className="w-4 h-4" />, label: 'Steady' },
  stalled: { color: 'hsl(38 92% 50%)', icon: <AlertCircle className="w-4 h-4" />, label: 'Stalled' },
};

// Executive Summary Card
function ExecSummaryCard({ 
  summary, 
  onResynthesize, 
  isSynthesizing,
  rawPainCount,
  rawUseCaseCount,
  accountId
}: { 
  summary: ExecSummary | null; 
  onResynthesize: () => void;
  isSynthesizing: boolean;
  rawPainCount: number;
  rawUseCaseCount: number;
  accountId: string;
}) {
  return (
    <div className="glass rounded-xl p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-foreground flex items-center gap-2">
          <Target className="w-4 h-4 text-primary" />
          Account Intelligence
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            {rawPainCount} pain points • {rawUseCaseCount} use cases
          </span>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onResynthesize}
            disabled={isSynthesizing}
            className="h-7 text-xs gap-1"
          >
            {isSynthesizing ? (
              <RefreshCw className="w-3 h-3 animate-spin" />
            ) : (
              <Sparkles className="w-3 h-3" />
            )}
            {isSynthesizing ? 'Synthesizing...' : 'Refresh'}
          </Button>
        </div>
      </div>

      {/* Health Metric KPI Cards */}
      <HealthMetricKPICards accountId={accountId} />

      {/* Narrative Summary */}
      {summary?.summary_narrative ? (
        <p className="text-sm text-foreground leading-relaxed">
          {summary.summary_narrative}
        </p>
      ) : (
        <p className="text-sm text-muted-foreground italic">
          No executive summary generated yet. Click "Refresh" to synthesize insights from {rawPainCount} pain points and {rawUseCaseCount} use cases.
        </p>
      )}

      {/* Risks & Opportunities */}
      {((summary?.key_risks?.length || 0) > 0 || (summary?.key_opportunities?.length || 0) > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {(summary?.key_risks?.length || 0) > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-medium text-destructive uppercase tracking-wide flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                Key Risks
              </h4>
              <ul className="space-y-1">
                {summary?.key_risks?.map((risk, i) => (
                  <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-destructive mt-1">•</span>
                    {risk}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {(summary?.key_opportunities?.length || 0) > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-medium text-green-600 uppercase tracking-wide flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                Key Opportunities
              </h4>
              <ul className="space-y-1">
                {summary?.key_opportunities?.map((opp, i) => (
                  <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-green-600 mt-1">•</span>
                    {opp}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Strategic Theme Card
function StrategicThemeCard({ theme, type }: { theme: StrategicTheme; type: 'pain' | 'initiative' }) {
  const [isOpen, setIsOpen] = useState(false);
  const impactLevel = theme.impact_level || 'medium';
  const evidence = Array.isArray(theme.supporting_evidence) ? theme.supporting_evidence : [];
  
  const Icon = type === 'pain' ? AlertTriangle : Lightbulb;
  const iconColor = type === 'pain' ? impactColors[impactLevel] : 'hsl(142 76% 36%)';
  
  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <CollapsibleTrigger className="w-full">
        <div 
          className={cn(
            "flex items-start gap-3 p-4 rounded-lg border transition-colors text-left",
            "hover:bg-muted/50",
            isOpen && "bg-muted/30"
          )}
          style={{ borderColor: `${impactColors[impactLevel]}30` }}
        >
          <div 
            className="mt-0.5 p-1.5 rounded-md flex-shrink-0"
            style={{ backgroundColor: `${iconColor}15` }}
          >
            <Icon className="w-4 h-4" style={{ color: iconColor }} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-foreground">{theme.theme_name}</span>
              <Badge 
                variant="outline" 
                className="text-[10px] px-1.5 py-0"
                style={{ 
                  borderColor: impactColors[impactLevel],
                  color: impactColors[impactLevel]
                }}
              >
                {impactLevel}
              </Badge>
              {theme.item_count > 0 && (
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                  {theme.item_count} items
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
              {theme.description}
            </p>
          </div>
          <ChevronDown className={cn(
            "w-4 h-4 text-muted-foreground transition-transform flex-shrink-0 mt-1",
            isOpen && "rotate-180"
          )} />
        </div>
      </CollapsibleTrigger>
      <CollapsibleContent>
        {evidence.length > 0 && (
          <div className="ml-11 mr-4 mb-4 mt-2 pl-4 border-l-2 border-muted">
            <h5 className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">
              Supporting Evidence
            </h5>
            <ul className="space-y-1.5">
              {evidence.map((item, i) => (
                <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                  <ChevronRight className="w-3 h-3 mt-1 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CollapsibleContent>
    </Collapsible>
  );
}

export function ThemedInsightsPanel({ accountId, opportunityId }: ThemedInsightsPanelProps) {
  const [activeTab, setActiveTab] = useState<'challenges' | 'initiatives'>('challenges');
  
  // Always fetch account-level themes
  const { data: accountThemes, isLoading: loadingAccountThemes } = useAccountStrategicThemes(accountId);
  // Also fetch opportunity-specific themes if opportunityId provided
  const { data: opportunityThemes, isLoading: loadingOpportunityThemes } = useOpportunityStrategicThemes(
    opportunityId || null
  );
  const { data: execSummary, isLoading: loadingSummary } = useAccountExecSummary(accountId);
  
  // Fetch raw counts for display
  const { data: accountPainPoints = [] } = useAccountPainPoints(accountId);
  const { data: opportunityPainPoints = [] } = useOpportunityPainPoints(opportunityId || null);
  const { data: accountUseCases = [] } = useThemedUseCases(accountId);
  const { data: opportunityUseCases = [] } = useOpportunityUseCasesThemed(opportunityId || null);
  
  // Priority: Opportunity-specific data first, then fall back to account-level aggregations
  // This reflects that data flows from opportunities (via transcript imports) up to account aggregations
  
  // Themes: use opportunity-linked themes first, fall back to account themes
  const opportunityHasThemes = (opportunityThemes?.painThemes?.length || 0) > 0 || (opportunityThemes?.initiatives?.length || 0) > 0;
  const themes = opportunityId 
    ? (opportunityHasThemes ? opportunityThemes : accountThemes) 
    : accountThemes;
  
  // Pain points & use cases: use opportunity-specific first, fall back to account-level if empty
  const opportunityHasPainPoints = opportunityPainPoints.length > 0;
  const opportunityHasUseCases = opportunityUseCases.length > 0;
  const painPoints = opportunityId 
    ? (opportunityHasPainPoints ? opportunityPainPoints : accountPainPoints)
    : accountPainPoints;
  const useCases = opportunityId 
    ? (opportunityHasUseCases ? opportunityUseCases : accountUseCases)
    : accountUseCases;
  
  // Synthesize mutation (account-level only)
  const synthesizeMutation = useSynthesizeAccountInsights();
  
  const isLoading = loadingAccountThemes || (opportunityId && loadingOpportunityThemes) || loadingSummary;
  const painThemes = themes?.painThemes || [];
  const initiatives = themes?.initiatives || [];
  
  const handleSynthesize = () => {
    synthesizeMutation.mutate(accountId);
  };
  
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="glass rounded-xl p-5 space-y-3">
          <div className="h-6 w-48 bg-muted animate-pulse rounded" />
          <div className="h-20 w-full bg-muted animate-pulse rounded" />
        </div>
      </div>
    );
  }

  // If no themes yet but we have raw data, show prompt to synthesize
  const hasRawData = painPoints.length > 0 || useCases.length > 0;
  const hasThemes = painThemes.length > 0 || initiatives.length > 0;
  
  // At opportunity level, always show the panel (even if empty, to maintain consistency)
  const shouldShowThemesPanel = opportunityId ? true : (hasThemes || hasRawData);

  return (
    <div className="space-y-4">
      {/* Executive Summary - only show at account level */}
      {!opportunityId && (
        <ExecSummaryCard 
          summary={execSummary} 
          onResynthesize={handleSynthesize}
          isSynthesizing={synthesizeMutation.isPending}
          rawPainCount={painPoints.length}
          rawUseCaseCount={useCases.length}
          accountId={accountId}
        />
      )}
      
      {/* Strategic Themes */}
      {shouldShowThemesPanel && (
        <div className="glass rounded-xl p-5">
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
            <TabsList className="mb-4">
              <TabsTrigger value="challenges" className="gap-1.5">
                <Shield className="w-3.5 h-3.5" />
                Strategic Challenges ({painThemes.length})
              </TabsTrigger>
              <TabsTrigger value="initiatives" className="gap-1.5">
                <Lightbulb className="w-3.5 h-3.5" />
                Strategic Initiatives ({initiatives.length})
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="challenges" className="mt-0">
              {painThemes.length === 0 ? (
                <div className="text-center py-8 space-y-3">
                  <p className="text-sm text-muted-foreground">
                    {opportunityId
                      ? "No strategic challenges linked to this opportunity yet. Themes are synthesized at the account level and linked to opportunities automatically."
                      : hasRawData 
                        ? `${painPoints.length} pain points found. Click "Refresh" above to synthesize into strategic themes.`
                        : "No strategic challenges identified yet."}
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {painThemes.map((theme) => (
                    <StrategicThemeCard key={theme.id} theme={theme} type="pain" />
                  ))}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="initiatives" className="mt-0">
              {initiatives.length === 0 ? (
                <div className="text-center py-8 space-y-3">
                  <p className="text-sm text-muted-foreground">
                    {opportunityId
                      ? "No strategic initiatives linked to this opportunity yet. Themes are synthesized at the account level and linked to opportunities automatically."
                      : hasRawData 
                        ? `${useCases.length} use cases found. Click "Refresh" above to synthesize into strategic initiatives.`
                        : "No strategic initiatives identified yet."}
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {initiatives.map((theme) => (
                    <StrategicThemeCard key={theme.id} theme={theme} type="initiative" />
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
}

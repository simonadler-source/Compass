import { useState } from 'react';
import { Building2, Check, X, AlertCircle, Loader2, Plus, Users, Zap, AlertTriangle, HelpCircle, TrendingUp, TrendingDown, Target, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { 
  useTranscriptReviews, 
  useUpdateTranscriptReview,
  useCreateAccountTechnology,
  useCreateAccountDocument,
  useCreateAccountContact,
  useCreateAccountNba,
  useAccounts,
  useCreateAccount
} from '@/hooks/useAccounts';
import { useCreateDiscoveryQuestion, useFunctionalAreaByName } from '@/hooks/useDiscoveryQuestions';
import { useSaveProductMentions, transformProductMentions } from '@/hooks/useSaveProductMentions';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { toast } from 'sonner';

interface TranscriptReviewQueueProps {
  onAccountSelect?: (accountId: string) => void;
  onNavigateToAccount?: (accountId: string) => void;
}

export function TranscriptReviewQueue({ onAccountSelect, onNavigateToAccount }: TranscriptReviewQueueProps) {
  const { data: reviews, isLoading, refetch: refetchReviews } = useTranscriptReviews('pending');
  const { data: accounts, refetch: refetchAccounts } = useAccounts();
  const { data: functionalAreaMap } = useFunctionalAreaByName();
  const updateReview = useUpdateTranscriptReview();
  const createTechnology = useCreateAccountTechnology();
  const createDocument = useCreateAccountDocument();
  const createContact = useCreateAccountContact();
  const createNba = useCreateAccountNba();
  const createAccount = useCreateAccount();
  const createDiscoveryQuestion = useCreateDiscoveryQuestion();
  const saveProductMentions = useSaveProductMentions();
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [reviewTechnologies, setReviewTechnologies] = useState<Record<string, any[]>>({});

  const getTechnologiesForReview = (reviewId: string, originalTechs: any[]) => {
    if (reviewTechnologies[reviewId]) {
      return reviewTechnologies[reviewId];
    }
    return originalTechs;
  };

  const handleRemoveTechnology = (reviewId: string, techIndex: number, originalTechs: any[]) => {
    const currentTechs = getTechnologiesForReview(reviewId, originalTechs);
    const newTechs = currentTechs.filter((_, i) => i !== techIndex);
    setReviewTechnologies(prev => ({ ...prev, [reviewId]: newTechs }));
  };

  const handleApprove = async (reviewId: string, accountId: string) => {
    setProcessingId(reviewId);
    
    try {
      const review = reviews?.find(r => r.id === reviewId);
      if (!review) return;

      // Note: We no longer save transcript to account_documents
      // Transcript content stays in momentum_meetings (linked via momentum_meeting_id)
      // or in transcript_reviews for manually imported transcripts

      // Use the filtered technologies if available
      const originalTechs = review.extracted_technologies as any[] || [];
      const techs = getTechnologiesForReview(reviewId, originalTechs);
      
      for (const tech of techs) {
        if (tech.confidence >= 0.5) {
          await createTechnology.mutateAsync({
            account_id: accountId,
            name: tech.name,
            layer: tech.suggestedLayer || 'adopt',
            category: tech.category || 'Extracted',
            notes: tech.context || null,
            status: 'unconfirmed',
          });
        }
      }

      // Add extracted people as contacts
      const insights = review.extracted_insights as any || {};
      const people = insights.people || [];
      for (const person of people) {
        await createContact.mutateAsync({
          account_id: accountId,
          name: person.name,
          role: person.role,
          email: person.email,
          phone: person.phone,
          notes: person.context,
          source: 'transcript',
        } as any);
      }

      // Add NBAs - link to opportunity if available
      const nbas = insights.nbas || insights.nextBestActions || [];
      for (const nba of nbas) {
        await createNba.mutateAsync({
          account_id: accountId,
          opportunity_id: review.opportunity_id || null, // Link NBAs to the opportunity
          action: nba.action,
          action_type: nba.actionType || 'technical',
          priority: nba.priority || 'medium',
          notes: nba.reasoning,
          source_transcript_id: reviewId,
          status: 'pending',
        });
      }

      // Add discovery questions as drafts (is_active = false)
      const discoveryQuestions = insights.discoveryQuestions || [];
      for (const dq of discoveryQuestions) {
        // Match functional area name to ID
        const functionalAreaId = functionalAreaMap?.get(dq.functionalArea?.toLowerCase());
        if (functionalAreaId) {
          try {
            await createDiscoveryQuestion.mutateAsync({
              functional_area_id: functionalAreaId,
              question: dq.question,
              category: dq.category || 'General',
              is_active: false, // Draft - needs review
            });
          } catch (e) {
            // Silently skip duplicates
            console.log('Skipped duplicate discovery question:', dq.question);
          }
        }
      }

      // Save product mentions for analytics
      const productMentions = insights.productMentions || [];
      if (productMentions.length > 0) {
        try {
          const mentionsToSave = transformProductMentions(
            productMentions,
            reviewId,
            accountId,
            review.opportunity_id,
            review.created_at
          );
          await saveProductMentions.mutateAsync(mentionsToSave);
        } catch (e) {
          console.error('Failed to save product mentions:', e);
          // Non-blocking - don't fail the approval
        }
      }

      // Mark review as approved
      await updateReview.mutateAsync({
        id: reviewId,
        status: 'approved',
        final_account_id: accountId,
        reviewed_at: new Date().toISOString(),
      });

      // Clear cached technologies for this review
      setReviewTechnologies(prev => {
        const updated = { ...prev };
        delete updated[reviewId];
        return updated;
      });

      toast.success('Transcript approved and saved to account');
      
      if (onNavigateToAccount) {
        onNavigateToAccount(accountId);
      }
    } catch (error) {
      console.error('Approve error:', error);
      toast.error('Failed to approve transcript');
    } finally {
      setProcessingId(null);
    }
  };

  const handleCreateAndApprove = async (reviewId: string, accountName: string) => {
    setProcessingId(reviewId);
    
    try {
      // Create the new account
      const newAccount = await createAccount.mutateAsync({
        name: accountName,
        status: 'active',
      });

      await refetchAccounts();

      // Now approve with the new account
      await handleApproveWithAccountId(reviewId, newAccount.id);
      
      toast.success(`Account "${accountName}" created and transcript approved`);
    } catch (error) {
      console.error('Create account error:', error);
      toast.error('Failed to create account');
      setProcessingId(null);
    }
  };

  const handleApproveWithAccountId = async (reviewId: string, accountId: string) => {
    try {
      const review = reviews?.find(r => r.id === reviewId);
      if (!review) return;

      // Save transcript to account
      await createDocument.mutateAsync({
        account_id: accountId,
        name: review.file_name || `Transcript - ${new Date().toLocaleDateString()}`,
        type: 'transcript',
        content: review.transcript_content,
      });

      // Use the filtered technologies if available
      const originalTechs = review.extracted_technologies as any[] || [];
      const techs = getTechnologiesForReview(reviewId, originalTechs);
      
      for (const tech of techs) {
        if (tech.confidence >= 0.5) {
          await createTechnology.mutateAsync({
            account_id: accountId,
            name: tech.name,
            layer: tech.suggestedLayer || 'adopt',
            category: tech.category || 'Extracted',
            notes: tech.context || null,
            status: 'unconfirmed',
          });
        }
      }

      // Add extracted people as contacts
      const insights = review.extracted_insights as any || {};
      const people = insights.people || [];
      for (const person of people) {
        await createContact.mutateAsync({
          account_id: accountId,
          name: person.name,
          role: person.role,
          email: person.email,
          phone: person.phone,
          notes: person.context,
          source: 'transcript',
        } as any);
      }

      // Add NBAs
      const nbas = insights.nbas || [];
      for (const nba of nbas) {
        await createNba.mutateAsync({
          account_id: accountId,
          action: nba.action,
          action_type: nba.actionType || 'technical',
          priority: nba.priority || 'medium',
          notes: nba.reasoning,
          status: 'pending',
        });
      }

      // Add discovery questions as drafts (is_active = false)
      const discoveryQuestions = insights.discoveryQuestions || [];
      for (const dq of discoveryQuestions) {
        // Match functional area name to ID
        const functionalAreaId = functionalAreaMap?.get(dq.functionalArea?.toLowerCase());
        if (functionalAreaId) {
          try {
            await createDiscoveryQuestion.mutateAsync({
              functional_area_id: functionalAreaId,
              question: dq.question,
              category: dq.category || 'General',
              is_active: false, // Draft - needs review
            });
          } catch (e) {
            // Silently skip duplicates
            console.log('Skipped duplicate discovery question:', dq.question);
          }
        }
      }

      // Save product mentions for analytics
      const productMentions = insights.productMentions || [];
      if (productMentions.length > 0) {
        try {
          const mentionsToSave = transformProductMentions(
            productMentions,
            reviewId,
            accountId,
            review.opportunity_id,
            review.created_at
          );
          await saveProductMentions.mutateAsync(mentionsToSave);
        } catch (e) {
          console.error('Failed to save product mentions:', e);
          // Non-blocking - don't fail the approval
        }
      }

      // Mark review as approved
      await updateReview.mutateAsync({
        id: reviewId,
        status: 'approved',
        final_account_id: accountId,
        reviewed_at: new Date().toISOString(),
      });

      // Clear cached technologies for this review
      setReviewTechnologies(prev => {
        const updated = { ...prev };
        delete updated[reviewId];
        return updated;
      });

      if (onNavigateToAccount) {
        onNavigateToAccount(accountId);
      }
    } catch (error) {
      console.error('Approve error:', error);
      toast.error('Failed to approve transcript');
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (reviewId: string) => {
    setProcessingId(reviewId);
    
    try {
      await updateReview.mutateAsync({
        id: reviewId,
        status: 'rejected',
        reviewed_at: new Date().toISOString(),
      });
      
      // Clear cached technologies for this review
      setReviewTechnologies(prev => {
        const updated = { ...prev };
        delete updated[reviewId];
        return updated;
      });
      
      toast.success('Transcript rejected');
    } catch (error) {
      console.error('Reject error:', error);
      toast.error('Failed to reject transcript');
    } finally {
      setProcessingId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24" />
        <Skeleton className="h-24" />
      </div>
    );
  }

  if (!reviews || reviews.length === 0) {
    return (
      <div className="glass rounded-xl p-8 text-center border-2 border-dashed border-border">
        <Check className="w-12 h-12 text-layer-growth mx-auto mb-4" />
        <p className="text-muted-foreground">No transcripts pending review</p>
        <p className="text-sm text-muted-foreground mt-1">
          Analyzed transcripts needing account confirmation will appear here
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <AlertCircle className="w-5 h-5 text-layer-build" />
        <h3 className="font-semibold text-foreground">
          {reviews.length} transcript{reviews.length !== 1 ? 's' : ''} pending review
        </h3>
      </div>

      {reviews.map((review: any) => (
        <ReviewCard
          key={review.id}
          review={review}
          accounts={accounts || []}
          technologies={getTechnologiesForReview(review.id, review.extracted_technologies || [])}
          onRemoveTechnology={(index) => handleRemoveTechnology(review.id, index, review.extracted_technologies || [])}
          onApprove={handleApprove}
          onCreateAndApprove={handleCreateAndApprove}
          onReject={handleReject}
          isProcessing={processingId === review.id}
        />
      ))}
    </div>
  );
}

interface ReviewCardProps {
  review: any;
  accounts: any[];
  technologies: any[];
  onRemoveTechnology: (index: number) => void;
  onApprove: (reviewId: string, accountId: string) => void;
  onCreateAndApprove: (reviewId: string, accountName: string) => void;
  onReject: (reviewId: string) => void;
  isProcessing: boolean;
}

function ReviewCard({ 
  review, 
  accounts, 
  technologies,
  onRemoveTechnology,
  onApprove, 
  onCreateAndApprove,
  onReject, 
  isProcessing 
}: ReviewCardProps) {
  const [selectedAccountId, setSelectedAccountId] = useState(
    review.suggested_account_id || ''
  );
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newAccountName, setNewAccountName] = useState(
    review.extracted_insights?.suggestedNewAccountName || ''
  );
  const [showAllExtracted, setShowAllExtracted] = useState(false);

  const insights = review.extracted_insights as any || {};
  const people = insights.people || [];
  const nbas = insights.nbas || [];
  const painPoints = insights.painPoints || [];
  const useCases = insights.useCases || [];
  const discoveryQuestions = insights.discoveryQuestions || [];
  const commercialInsights = insights.commercialInsights || [];
  const confidence = review.suggested_account_confidence || 0;
  const suggestedAccountName = review.accounts?.name;

  const handleApproveClick = () => {
    if (isCreatingNew) {
      if (newAccountName.trim()) {
        onCreateAndApprove(review.id, newAccountName.trim());
      }
    } else {
      if (selectedAccountId) {
        onApprove(review.id, selectedAccountId);
      }
    }
  };

  const canApprove = isCreatingNew ? newAccountName.trim().length > 0 : selectedAccountId.length > 0;

  return (
    <div className="glass rounded-xl p-5 space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h4 className="font-medium text-foreground">
            {review.file_name || 'Uploaded Transcript'}
          </h4>
          <p className="text-xs text-muted-foreground">
            Uploaded {new Date(review.created_at).toLocaleString()}
          </p>
        </div>
        {confidence > 0 && (
          <Badge 
            variant="outline" 
            className={cn(
              confidence >= 0.7 ? 'border-layer-growth/50 text-layer-growth' : 
              confidence >= 0.4 ? 'border-layer-build/50 text-layer-build' :
              'border-destructive/50 text-destructive'
            )}
          >
            {Math.round(confidence * 100)}% confidence
          </Badge>
        )}
      </div>

      {/* Transcript Preview */}
      {review.transcript_content && (
        <div className="bg-muted/30 rounded-lg p-3 max-h-24 overflow-hidden">
          <p className="text-sm text-muted-foreground line-clamp-3">
            {review.transcript_content.substring(0, 300)}...
          </p>
        </div>
      )}

      {/* Extracted Technologies - Removable */}
      {technologies.length > 0 && (
        <div>
          <p className="text-xs text-muted-foreground mb-2">Extracted Technologies (click to remove)</p>
          <div className="flex flex-wrap gap-1">
            {technologies.map((tech: any, i: number) => (
              <Badge 
                key={i} 
                variant="secondary" 
                className="text-xs cursor-pointer hover:bg-destructive/20 hover:text-destructive transition-colors group"
                onClick={() => onRemoveTechnology(i)}
              >
                {tech.name}
                <X className="w-3 h-3 ml-1 opacity-50 group-hover:opacity-100" />
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Other Extracted Data - Collapsible */}
      <Collapsible open={showAllExtracted} onOpenChange={setShowAllExtracted}>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm" className="w-full justify-between text-xs text-muted-foreground">
            <span className="flex items-center gap-2">
              View all extracted data
              <span className="flex gap-1 flex-wrap">
                {people.length > 0 && <Badge variant="outline" className="text-[10px] px-1">{people.length} people</Badge>}
                {nbas.length > 0 && <Badge variant="outline" className="text-[10px] px-1">{nbas.length} actions</Badge>}
                {useCases.length > 0 && <Badge variant="outline" className="text-[10px] px-1">{useCases.length} use cases</Badge>}
                {painPoints.length > 0 && <Badge variant="outline" className="text-[10px] px-1">{painPoints.length} pain points</Badge>}
                {discoveryQuestions.length > 0 && <Badge variant="outline" className="text-[10px] px-1 bg-primary/10 text-primary">{discoveryQuestions.length} questions</Badge>}
                {commercialInsights.length > 0 && <Badge variant="outline" className="text-[10px] px-1 bg-orange-500/10 text-orange-500">{commercialInsights.length} commercial</Badge>}
              </span>
            </span>
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-3 pt-3">
          {/* People */}
          {people.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                <Users className="w-3 h-3" /> People
              </p>
              <div className="flex flex-wrap gap-1">
                {people.map((person: any, i: number) => (
                  <Badge key={i} variant="outline" className="text-xs">
                    {person.name} {person.role && `(${person.role})`}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* NBAs */}
          {nbas.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                <Zap className="w-3 h-3" /> Next Best Actions
              </p>
              <div className="space-y-1">
                {nbas.map((nba: any, i: number) => (
                  <div key={i} className="text-xs bg-muted/30 rounded px-2 py-1">
                    <span className={cn(
                      "font-medium mr-1",
                      nba.priority === 'high' && 'text-destructive',
                      nba.priority === 'medium' && 'text-layer-build',
                      nba.priority === 'low' && 'text-muted-foreground'
                    )}>
                      [{nba.priority}]
                    </span>
                    {nba.action}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Use Cases */}
          {useCases.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-2">Use Cases</p>
              <div className="flex flex-wrap gap-1">
                {useCases.map((uc: string, i: number) => (
                  <Badge key={i} variant="secondary" className="text-xs">
                    {uc}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Pain Points */}
          {painPoints.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Pain Points
              </p>
              <div className="flex flex-wrap gap-1">
                {painPoints.map((pp: string, i: number) => (
                  <Badge key={i} variant="outline" className="text-xs border-destructive/30 text-destructive">
                    {pp}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Discovery Questions */}
          {discoveryQuestions.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                <HelpCircle className="w-3 h-3 text-primary" /> Discovery Questions (will be added as drafts)
              </p>
              <div className="space-y-1">
                {discoveryQuestions.map((dq: any, i: number) => (
                  <div key={i} className="text-xs bg-primary/5 border border-primary/20 rounded px-2 py-1.5">
                    <div className="font-medium text-foreground">{dq.question}</div>
                    <div className="flex items-center gap-2 mt-1 text-muted-foreground">
                      <Badge variant="outline" className="text-[10px] px-1">{dq.category}</Badge>
                      <span>→ {dq.functionalArea}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Commercial Insights */}
          {commercialInsights.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                <Target className="w-3 h-3 text-orange-500" /> Commercial Insights (will feed into SWOT)
              </p>
              <div className="space-y-1">
                {commercialInsights.map((ci: any, i: number) => {
                  const swotColors: Record<string, string> = {
                    strength: 'bg-green-500/10 border-green-500/30 text-green-600',
                    weakness: 'bg-red-500/10 border-red-500/30 text-red-600',
                    opportunity: 'bg-blue-500/10 border-blue-500/30 text-blue-600',
                    threat: 'bg-orange-500/10 border-orange-500/30 text-orange-600',
                  };
                  const typeLabels: Record<string, string> = {
                    build_vs_buy: 'Build vs Buy',
                    budget_timing: 'Budget/Timing',
                    competitive_positioning: 'Competitive',
                    stakeholder_dynamics: 'Stakeholder',
                  };
                  return (
                    <div key={i} className={cn("text-xs border rounded px-2 py-1.5", swotColors[ci.swotCategory] || 'bg-muted/30')}>
                      <div className="font-medium text-foreground">{ci.insight}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-[10px] px-1 capitalize">{ci.swotCategory}</Badge>
                        <Badge variant="outline" className="text-[10px] px-1">{typeLabels[ci.type] || ci.type}</Badge>
                        <Badge variant="outline" className={cn("text-[10px] px-1",
                          ci.importance === 'high' && 'border-destructive/50 text-destructive',
                          ci.importance === 'medium' && 'border-layer-build/50 text-layer-build',
                          ci.importance === 'low' && 'border-muted-foreground/50'
                        )}>{ci.importance}</Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </CollapsibleContent>
      </Collapsible>

      {/* Account Selection or Creation */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Button
            variant={!isCreatingNew ? "default" : "outline"}
            size="sm"
            onClick={() => setIsCreatingNew(false)}
            className="text-xs"
          >
            <Building2 className="w-3 h-3 mr-1" />
            Existing Account
          </Button>
          <Button
            variant={isCreatingNew ? "default" : "outline"}
            size="sm"
            onClick={() => setIsCreatingNew(true)}
            className="text-xs"
          >
            <Plus className="w-3 h-3 mr-1" />
            Create New
          </Button>
        </div>

        {isCreatingNew ? (
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">
              New Account Name
              {review.extracted_insights?.suggestedNewAccountName && (
                <span className="ml-2 text-primary">
                  (AI suggests: {review.extracted_insights.suggestedNewAccountName})
                </span>
              )}
            </p>
            <Input
              placeholder="Enter account name..."
              value={newAccountName}
              onChange={(e) => setNewAccountName(e.target.value)}
              className="h-9"
            />
          </div>
        ) : (
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">
              Assign to Account
              {suggestedAccountName && (
                <span className="ml-2 text-primary">
                  (AI suggests: {suggestedAccountName})
                </span>
              )}
            </p>
            <Select value={selectedAccountId} onValueChange={setSelectedAccountId}>
              <SelectTrigger className="h-9">
                <SelectValue placeholder="Select an account..." />
              </SelectTrigger>
              <SelectContent>
                {[...accounts].sort((a, b) => a.name.localeCompare(b.name)).map((account) => (
                  <SelectItem key={account.id} value={account.id}>
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4" />
                      {account.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-2 pt-2 border-t border-border">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onReject(review.id)}
          disabled={isProcessing}
        >
          <X className="w-4 h-4 mr-1" />
          Reject
        </Button>
        <Button
          size="sm"
          onClick={handleApproveClick}
          disabled={!canApprove || isProcessing}
        >
          {isProcessing ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <>
              <Check className="w-4 h-4 mr-1" />
              {isCreatingNew ? 'Create & Approve' : 'Approve'}
            </>
          )}
        </Button>
      </div>
    </div>
  );
}

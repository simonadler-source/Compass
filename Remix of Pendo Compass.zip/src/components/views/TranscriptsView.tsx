import { useState, useRef } from 'react';
import { Upload, FileText, Sparkles, Check, AlertCircle, Loader2, Target, Users, ChevronDown, ChevronUp, Building2, ClipboardList, UserPlus, Zap, Mail, Phone, Briefcase, Inbox } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { TechnologyChip } from '@/components/TechnologyChip';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { TranscriptReviewQueue } from './TranscriptReviewQueue';
import { InboundEmailQueue } from './InboundEmailQueue';
import { 
  useAccounts, 
  useCreateAccount,
  useCreateTranscriptReview, 
  useTranscriptReviews,
  useCreateAccountContact,
  useCreateAccountNba,
  useCreateAccountTechnology,
} from '@/hooks/useAccounts';
import { useCompetitorsList } from '@/hooks/useCompetitorsList';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { analyzeTranscript as analyzeTranscriptStreaming } from '@/features/transcript-analysis';

interface TranscriptsViewProps {
  onTechnologiesExtracted: (techs: any[]) => void;
  onNavigateToAccount?: (accountId: string) => void;
}

interface ExtractedPerson {
  name: string;
  role: string | null;
  email: string | null;
  phone: string | null;
  context: string;
}

interface NextBestAction {
  action: string;
  actionType: string;
  priority: string;
  reasoning: string;
}

interface AnalysisResult {
  id: string;
  fileName: string;
  status: 'pending' | 'processing' | 'complete' | 'failed';
  technologies: any[];
  people: ExtractedPerson[];
  nbas: NextBestAction[];
  insights: {
    painPoints: string[];
    useCases: string[];
    competitorMentions: string[];
  };
  suggestedAccountId: string | null;
  suggestedAccountName: string | null;
  suggestedNewAccountName: string | null;
  accountConfidence: number;
  accountExists: boolean;
  transcript: string;
  analyzedAt: Date;
}

export function TranscriptsView({ onTechnologiesExtracted, onNavigateToAccount }: TranscriptsViewProps) {
  const { user } = useAuth();
  const [analyses, setAnalyses] = useState<AnalysisResult[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState('transcripts');
  const [expandedAnalysis, setExpandedAnalysis] = useState<string | null>(null);
  const [pastedTranscript, setPastedTranscript] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { data: accounts, refetch: refetchAccounts } = useAccounts();
  const { data: competitors } = useCompetitorsList();
  const { data: pendingReviews } = useTranscriptReviews('pending');
  const createReview = useCreateTranscriptReview();
  const createAccount = useCreateAccount();
  const createContact = useCreateAccountContact();
  const createNba = useCreateAccountNba();
  const createTech = useCreateAccountTechnology();

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    await processFiles(files);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    await processFiles(files);
  };

  const processFiles = async (files: File[]) => {
    for (const file of files) {
      const text = await file.text();
      await analyzeTranscript(text, file.name);
    }
  };

  const handleAnalyzePasted = async () => {
    if (!pastedTranscript.trim()) return;
    await analyzeTranscript(pastedTranscript, 'Pasted Transcript');
    setPastedTranscript('');
  };

  const analyzeTranscript = async (transcript: string, fileName: string) => {
    const analysisId = crypto.randomUUID();
    
    const newAnalysis: AnalysisResult = {
      id: analysisId,
      fileName,
      status: 'processing',
      technologies: [],
      people: [],
      nbas: [],
      insights: { painPoints: [], useCases: [], competitorMentions: [] },
      suggestedAccountId: null,
      suggestedAccountName: null,
      suggestedNewAccountName: null,
      accountConfidence: 0,
      accountExists: false,
      transcript,
      analyzedAt: new Date(),
    };

    setAnalyses(prev => [newAnalysis, ...prev]);
    setIsProcessing(true);

    try {
      // Use the shared streaming analysis utility
      const result = await analyzeTranscriptStreaming({
        transcript,
        accounts: accounts?.map(a => ({ id: a.id, name: a.name, industry: a.industry })) || [],
        competitors: competitors?.map(c => ({ id: c.id, name: c.name })) || [],
        onProgress: (progress) => {
          // Could update UI with progress if desired
          console.log(`Analysis progress: Pass ${progress.pass}/${progress.totalPasses} - ${progress.stage}`);
        },
      });

      if (!result.success || !result.analysis) {
        throw new Error(result.error || 'Analysis failed');
      }

      const data = result.analysis;

      // Map to local types (add missing properties with defaults)
      const mappedPeople: ExtractedPerson[] = (data.people || []).map(p => ({
        name: p.name,
        role: p.role || null,
        email: p.email || null,
        phone: null,
        context: '',
      }));

      const mappedNbas: NextBestAction[] = (data.nbas || (data as any).nextBestActions || []).map(n => ({
        action: n.action,
        actionType: n.actionType || 'follow_up',
        priority: n.priority || 'medium',
        reasoning: n.reasoning || '',
      }));

      const updatedAnalysis: AnalysisResult = {
        ...newAnalysis,
        status: 'complete',
        technologies: data.technologies || [],
        people: mappedPeople,
        nbas: mappedNbas,
        insights: data.insights || { painPoints: [], useCases: [], competitorMentions: [] },
        suggestedAccountId: data.suggestedAccountId || null,
        suggestedAccountName: data.suggestedAccountName || null,
        suggestedNewAccountName: data.suggestedNewAccountName || null,
        accountConfidence: data.accountConfidence || 0,
        accountExists: data.accountExists || false,
      };

      setAnalyses(prev => prev.map(a => a.id === analysisId ? updatedAnalysis : a));
      onTechnologiesExtracted(data.technologies || []);

      // Save to review queue with created_by - convert to JSON-compatible format
      const reviewData = await createReview.mutateAsync({
        transcript_content: transcript,
        file_name: fileName,
        suggested_account_id: data.suggestedAccountId || null,
        suggested_account_confidence: data.accountConfidence || 0,
        extracted_technologies: JSON.parse(JSON.stringify(data.technologies || [])),
        extracted_insights: JSON.parse(JSON.stringify({
          ...data.insights,
          people: data.people || [],
          nbas: data.nbas || [],
          suggestedNewAccountName: data.suggestedNewAccountName,
        })),
        status: data.accountExists && (data.accountConfidence || 0) >= 0.7 ? 'approved' : 'pending',
        created_by: user?.id || null,
      });

      if (data.accountExists && (data.accountConfidence || 0) >= 0.7) {
        toast.success(`Transcript analyzed - matched to ${data.suggestedAccountName}`);
      } else if (data.suggestedNewAccountName) {
        toast.info(`No matching account found. Suggested new account: "${data.suggestedNewAccountName}"`);
      } else {
        toast.info('Transcript added to review queue for account assignment');
      }

    } catch (error) {
      console.error('Analysis error:', error);
      setAnalyses(prev => prev.map(a => 
        a.id === analysisId ? { ...a, status: 'failed' } : a
      ));
      toast.error('Failed to analyze transcript');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCreateAccountAndEnrich = async (analysis: AnalysisResult) => {
    const accountName = analysis.suggestedNewAccountName || analysis.suggestedAccountName || 'New Account';
    
    try {
      // Create account with pending_review status and current user as owner
      const newAccount = await createAccount.mutateAsync({
        name: accountName,
        status: 'pending_review',
        owner_id: user?.id || null,
      });

      // Add contacts
      for (const person of analysis.people) {
        await createContact.mutateAsync({
          account_id: newAccount.id,
          name: person.name,
          role: person.role,
          email: person.email,
          phone: person.phone,
          notes: person.context,
          source: 'transcript',
        } as any);
      }

      // Add technologies with unconfirmed status
      for (const tech of analysis.technologies) {
        await createTech.mutateAsync({
          account_id: newAccount.id,
          name: tech.name,
          layer: tech.suggestedLayer || 'adopt',
          category: 'Extracted',
          status: 'unconfirmed',
          notes: tech.context,
        });
      }

      // Add NBAs
      for (const nba of analysis.nbas) {
        await createNba.mutateAsync({
          account_id: newAccount.id,
          action: nba.action,
          action_type: nba.actionType,
          priority: nba.priority,
          notes: nba.reasoning,
          status: 'pending',
        });
      }

      // Update analysis with new account
      setAnalyses(prev => prev.map(a => 
        a.id === analysis.id 
          ? { ...a, suggestedAccountId: newAccount.id, accountExists: true }
          : a
      ));

      await refetchAccounts();
      toast.success(`Account "${accountName}" created with pending review status`);
      
      // Navigate to the new account
      if (onNavigateToAccount) {
        onNavigateToAccount(newAccount.id);
      }
    } catch (error) {
      console.error('Error creating account:', error);
      toast.error('Failed to create account');
    }
  };

  const handleEnrichExistingAccount = async (analysis: AnalysisResult) => {
    if (!analysis.suggestedAccountId) return;

    try {
      // Add contacts
      for (const person of analysis.people) {
        await createContact.mutateAsync({
          account_id: analysis.suggestedAccountId,
          name: person.name,
          role: person.role,
          email: person.email,
          phone: person.phone,
          notes: person.context,
          source: 'transcript',
        } as any);
      }

      // Add technologies with unconfirmed status
      for (const tech of analysis.technologies) {
        await createTech.mutateAsync({
          account_id: analysis.suggestedAccountId,
          name: tech.name,
          layer: tech.suggestedLayer || 'adopt',
          category: 'Extracted',
          status: 'unconfirmed',
          notes: tech.context,
        });
      }

      // Add NBAs
      for (const nba of analysis.nbas) {
        await createNba.mutateAsync({
          account_id: analysis.suggestedAccountId,
          action: nba.action,
          action_type: nba.actionType,
          priority: nba.priority,
          notes: nba.reasoning,
          status: 'pending',
        });
      }

      toast.success(`Account "${analysis.suggestedAccountName}" enriched with transcript data`);
      
      // Navigate to the enriched account
      if (onNavigateToAccount && analysis.suggestedAccountId) {
        onNavigateToAccount(analysis.suggestedAccountId);
      }
    } catch (error) {
      console.error('Error enriching account:', error);
      toast.error('Failed to enrich account');
    }
  };

  const pendingCount = pendingReviews?.length || 0;

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="page-heading">AI Discovery Center</h1>
        <p className="text-muted-foreground mt-1">
          Analyze transcripts and automatically extract technologies, contacts, and actions
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full max-w-2xl grid-cols-4">
          <TabsTrigger value="transcripts" className="gap-2">
            <FileText className="w-4 h-4" />
            Analyze
          </TabsTrigger>
          <TabsTrigger value="emails" className="gap-2">
            <Inbox className="w-4 h-4" />
            Inbound Emails
          </TabsTrigger>
          <TabsTrigger value="review" className="gap-2">
            <ClipboardList className="w-4 h-4" />
            Review Queue
            {pendingCount > 0 && (
              <Badge variant="destructive" className="ml-1 text-xs h-5 w-5 p-0 flex items-center justify-center">
                {pendingCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <Target className="w-4 h-4" />
            History
          </TabsTrigger>
        </TabsList>

        {/* Analyze Tab */}
        <TabsContent value="transcripts" className="space-y-6">
          {/* Drop Zone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={cn(
              "border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-300",
              isDragging 
                ? "border-primary bg-primary/10 scale-[1.02]" 
                : "border-border hover:border-primary/50 hover:bg-muted/30"
            )}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".txt,.md,.doc,.docx"
              multiple
              onChange={handleFileSelect}
              className="hidden"
            />
            
            <div className="flex flex-col items-center gap-3">
              <div className={cn(
                "w-14 h-14 rounded-full flex items-center justify-center transition-colors",
                isDragging ? "bg-primary/20" : "bg-muted"
              )}>
                <Upload className={cn(
                  "w-7 h-7 transition-colors",
                  isDragging ? "text-primary" : "text-muted-foreground"
                )} />
              </div>
              <div>
                <p className="font-medium text-foreground">
                  Drop transcript files here or click to upload
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Supports .txt, .md, .doc, .docx
                </p>
              </div>
            </div>
          </div>

          {/* Or Paste */}
          <div className="space-y-3">
            <p className="text-sm font-medium text-muted-foreground">Or paste transcript:</p>
            <Textarea
              placeholder="Paste your call transcript here..."
              value={pastedTranscript}
              onChange={(e) => setPastedTranscript(e.target.value)}
              className="min-h-[150px] font-mono text-sm"
            />
            <Button
              variant="glow"
              onClick={handleAnalyzePasted}
              disabled={!pastedTranscript.trim() || isProcessing}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Analyze with AI
                </>
              )}
            </Button>
          </div>

          {/* Recent Analyses */}
          {analyses.filter(a => a.status !== 'complete' || analyses.indexOf(a) < 3).map((analysis) => (
            <AnalysisCard
              key={analysis.id}
              analysis={analysis}
              isExpanded={expandedAnalysis === analysis.id}
              onToggle={() => setExpandedAnalysis(expandedAnalysis === analysis.id ? null : analysis.id)}
              onCreateAccount={() => handleCreateAccountAndEnrich(analysis)}
              onEnrichAccount={() => handleEnrichExistingAccount(analysis)}
            />
          ))}
        </TabsContent>

        {/* Inbound Emails Tab */}
        <TabsContent value="emails" className="space-y-6">
          <InboundEmailQueue onNavigateToAccount={onNavigateToAccount} />
        </TabsContent>

        {/* Review Queue Tab */}
        <TabsContent value="review" className="space-y-6">
          <TranscriptReviewQueue onNavigateToAccount={onNavigateToAccount} />
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-6">
          {analyses.length === 0 ? (
            <div className="glass rounded-xl p-8 text-center">
              <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No transcripts analyzed yet</p>
              <p className="text-sm text-muted-foreground mt-1">
                Upload or paste transcripts to see analysis history
              </p>
            </div>
          ) : (
            analyses.map((analysis) => (
              <AnalysisCard
                key={analysis.id}
                analysis={analysis}
                isExpanded={expandedAnalysis === analysis.id}
                onToggle={() => setExpandedAnalysis(expandedAnalysis === analysis.id ? null : analysis.id)}
                onCreateAccount={() => handleCreateAccountAndEnrich(analysis)}
                onEnrichAccount={() => handleEnrichExistingAccount(analysis)}
              />
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface AnalysisCardProps {
  analysis: AnalysisResult;
  isExpanded: boolean;
  onToggle: () => void;
  onCreateAccount: () => void;
  onEnrichAccount: () => void;
}

function AnalysisCard({ analysis, isExpanded, onToggle, onCreateAccount, onEnrichAccount }: AnalysisCardProps) {
  return (
    <Collapsible open={isExpanded} onOpenChange={onToggle}>
      <div className="glass rounded-xl p-5">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
              <FileText className="w-5 h-5 text-muted-foreground" />
            </div>
            <div>
              <h3 className="font-medium">{analysis.fileName}</h3>
              <p className="text-xs text-muted-foreground">
                {analysis.analyzedAt.toLocaleString()}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <StatusBadge status={analysis.status} />
            {analysis.status === 'complete' && (
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="icon">
                  {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </Button>
              </CollapsibleTrigger>
            )}
          </div>
        </div>

        {analysis.status === 'complete' && (
          <>
            {/* Summary badges */}
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge variant="secondary">
                {analysis.technologies.length} technologies
              </Badge>
              <Badge variant="secondary">
                <Users className="w-3 h-3 mr-1" />
                {analysis.people.length} people
              </Badge>
              <Badge variant="secondary">
                <Zap className="w-3 h-3 mr-1" />
                {analysis.nbas.length} actions
              </Badge>
              {analysis.accountExists && analysis.suggestedAccountName && (
                <Badge variant="outline" className={cn(
                  analysis.accountConfidence >= 0.7 
                    ? "border-layer-growth/50 text-layer-growth"
                    : "border-layer-build/50 text-layer-build"
                )}>
                  <Building2 className="w-3 h-3 mr-1" />
                  {analysis.suggestedAccountName} ({Math.round(analysis.accountConfidence * 100)}%)
                </Badge>
              )}
              {!analysis.accountExists && analysis.suggestedNewAccountName && (
                <Badge variant="outline" className="border-amber-500/50 text-amber-500">
                  <UserPlus className="w-3 h-3 mr-1" />
                  New: {analysis.suggestedNewAccountName}
                </Badge>
              )}
            </div>

            {/* Account action buttons */}
            {!analysis.accountExists && analysis.suggestedNewAccountName && (
              <div className="mb-4">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={onCreateAccount}
                  className="text-amber-500 border-amber-500/50 hover:bg-amber-500/10"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Create Account & Enrich
                </Button>
              </div>
            )}
            {analysis.accountExists && analysis.suggestedAccountId && (
              <div className="mb-4">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={onEnrichAccount}
                  className="text-layer-growth border-layer-growth/50 hover:bg-layer-growth/10"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Enrich Account with Transcript Data
                </Button>
              </div>
            )}

            <CollapsibleContent className="space-y-4 mt-4">
              {/* People Extracted */}
              {analysis.people.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    People Mentioned
                  </h4>
                  <div className="grid gap-2">
                    {analysis.people.map((person, i) => (
                      <div key={i} className="flex items-start gap-3 p-3 bg-muted/30 rounded-lg">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Users className="w-4 h-4 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm">{person.name}</p>
                          {person.role && (
                            <p className="text-xs text-muted-foreground flex items-center gap-1">
                              <Briefcase className="w-3 h-3" />
                              {person.role}
                            </p>
                          )}
                          <div className="flex flex-wrap gap-2 mt-1">
                            {person.email && (
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Mail className="w-3 h-3" />
                                {person.email}
                              </span>
                            )}
                            {person.phone && (
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Phone className="w-3 h-3" />
                                {person.phone}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* NBAs */}
              {analysis.nbas.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    Next Best Actions (NBAs)
                  </h4>
                  <div className="grid gap-2">
                    {analysis.nbas.map((nba, i) => (
                      <div key={i} className="p-3 bg-muted/30 rounded-lg">
                        <div className="flex items-start gap-2">
                          <Badge variant={nba.priority === 'high' ? 'destructive' : nba.priority === 'medium' ? 'default' : 'secondary'} className="text-xs">
                            {nba.priority}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {nba.actionType.replace(/_/g, ' ')}
                          </Badge>
                        </div>
                        <p className="text-sm mt-2">{nba.action}</p>
                        <p className="text-xs text-muted-foreground mt-1">{nba.reasoning}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Technologies */}
              {analysis.technologies.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-muted-foreground">Extracted Technologies</h4>
                  <div className="flex flex-wrap gap-2">
                    {analysis.technologies.map((tech, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <TechnologyChip
                          technology={{
                            id: `extracted-${i}`,
                            name: tech.name,
                            layer: tech.suggestedLayer || 'adopt',
                            category: 'Extracted',
                          }}
                          size="sm"
                          isDraggable={false}
                        />
                        <span className="text-xs text-muted-foreground">
                          {Math.round(tech.confidence * 100)}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Insights */}
              {(analysis.insights.painPoints.length > 0 || 
                analysis.insights.useCases.length > 0 ||
                analysis.insights.competitorMentions.length > 0) && (
                <div className="space-y-3">
                  {analysis.insights.painPoints.length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Pain Points</p>
                      <ul className="list-disc list-inside text-sm">
                        {analysis.insights.painPoints.map((point, i) => (
                          <li key={i}>{point}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {analysis.insights.useCases.length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Use Cases</p>
                      <ul className="list-disc list-inside text-sm">
                        {analysis.insights.useCases.map((uc, i) => (
                          <li key={i}>{uc}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {analysis.insights.competitorMentions.length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Competitor Mentions</p>
                      <div className="flex flex-wrap gap-1">
                        {analysis.insights.competitorMentions.map((comp, i) => (
                          <Badge key={i} variant="outline" className="text-orange-400 border-orange-400/50">
                            {comp}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CollapsibleContent>
          </>
        )}

        {analysis.status === 'processing' && (
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <Loader2 className="w-4 h-4 animate-spin text-primary" />
            Extracting technologies, contacts, and actions...
          </div>
        )}

        {analysis.status === 'failed' && (
          <div className="flex items-center gap-3 text-sm text-destructive">
            <AlertCircle className="w-4 h-4" />
            Analysis failed - please try again
          </div>
        )}
      </div>
    </Collapsible>
  );
}

function StatusBadge({ status }: { status: string }) {
  return (
    <div className={cn(
      "flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium",
      status === 'complete' && "bg-layer-growth/20 text-layer-growth",
      status === 'processing' && "bg-primary/20 text-primary",
      status === 'pending' && "bg-muted text-muted-foreground",
      status === 'failed' && "bg-destructive/20 text-destructive"
    )}>
      {status === 'complete' && <Check className="w-3 h-3" />}
      {status === 'processing' && <Loader2 className="w-3 h-3 animate-spin" />}
      {status === 'failed' && <AlertCircle className="w-3 h-3" />}
      <span className="capitalize">{status}</span>
    </div>
  );
}

import { useState, useMemo } from 'react';
import { Plus, Lightbulb, ChevronDown, ChevronRight, Sparkles, Link2, Info, User, Users, MessageSquare, Filter, TrendingUp, ShieldAlert, Scissors, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { UseCaseDialog } from '@/components/dialogs/UseCaseDialog';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';
import { NewBadge, ValidationBadge, StatusChangeIndicator, SourceTranscriptBadge } from '@/components/InsightChangeIndicators';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface UseCasesPanelProps {
  accountId: string;
  opportunityId?: string;
  linkedOnly?: boolean;
}

interface UseCase {
  id: string;
  account_id: string;
  opportunity_id?: string | null;
  functional_area: string;
  use_case: string;
  description?: string | null;
  status: string;
  priority?: string | null;
  source?: string | null;
  source_transcript_id?: string | null;
  created_at?: string;
  updated_at?: string;
  confidence_score?: number | null;
  validation_count?: number | null;
  last_validated_at?: string | null;
  mentioned_by_type?: 'internal' | 'external' | 'unknown' | null;
  mentioned_by_name?: string | null;
  mentioned_by_email?: string | null;
  acceptance_status?: 'validated' | 'proposed' | 'accepted' | null;
  acceptance_evidence?: string | null;
  use_case_template_id?: string | null;
  business_outcome?: string | null;
  solution_description?: string | null;
  required_module_ids?: string[] | null;
}

const STATUS_COLORS: Record<string, string> = {
  identified: 'bg-slate-500',
  validated: 'bg-blue-500',
  in_progress: 'bg-amber-500',
  implemented: 'bg-green-500',
  blocked: 'bg-red-500',
  proposed: 'bg-slate-400',
};

const ACCEPTANCE_COLORS: Record<string, { bg: string; text: string; label: string }> = {
  validated: { bg: 'bg-green-100 dark:bg-green-900/30', text: 'text-green-700 dark:text-green-400', label: 'Prospect Mentioned' },
  accepted: { bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-700 dark:text-blue-400', label: 'Prospect Confirmed' },
  proposed: { bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-700 dark:text-amber-400', label: 'Team Proposed' },
};

const PRIORITY_COLORS: Record<string, string> = {
  critical: 'bg-red-500',
  high: 'bg-orange-500',
  medium: 'bg-yellow-500',
  low: 'bg-slate-400',
};

const OUTCOME_CONFIG: Record<string, { icon: typeof TrendingUp; color: string; bg: string; border: string }> = {
  'Increase Revenue': { icon: TrendingUp, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-950/30', border: 'border-emerald-200 dark:border-emerald-800' },
  'Cut Costs': { icon: Scissors, color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-950/30', border: 'border-blue-200 dark:border-blue-800' },
  'Reduce Risk': { icon: ShieldAlert, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-950/30', border: 'border-amber-200 dark:border-amber-800' },
};

interface ExtractedUseCase {
  useCase: string;
  functionalArea?: string;
  transcriptId: string;
  transcriptName: string;
}

interface UseCaseTemplate {
  id: string;
  name: string;
  description: string | null;
  functional_area_id: string;
  functional_area_name?: string;
  business_outcome?: string | null;
  solution_description?: string | null;
}

interface MatchResult {
  template: UseCaseTemplate;
  score: number;
  matchedTerms: string[];
  reasoning: string;
}

interface UseCaseWithMatches extends UseCase {
  suggestedMatches: MatchResult[];
}

interface ModuleInfo {
  id: string;
  module_name: string;
}

const HIGH_VALUE_TERMS = new Set([
  'onboarding', 'adoption', 'churn', 'retention', 'revenue', 'upsell', 'cross-sell',
  'analytics', 'insights', 'migration', 'training', 'support', 'engagement',
  'productivity', 'efficiency', 'experience', 'satisfaction', 'health', 'score',
  'predict', 'forecast', 'risk', 'expansion', 'growth', 'cost', 'reduce', 'improve',
  'automate', 'integrate', 'optimize', 'track', 'measure', 'monitor', 'guide', 'in-app'
]);

function calculateSimilarityWithDetails(
  text1: string | null | undefined, 
  text2: string | null | undefined
): { score: number; matchedTerms: string[] } {
  if (!text1 || !text2) return { score: 0, matchedTerms: [] };
  const normalize = (text: string) => text.toLowerCase().replace(/[^a-z0-9\s-]/g, ' ');
  const words1 = new Set(normalize(text1).split(/\s+/).filter(w => w.length > 2));
  const words2 = new Set(normalize(text2).split(/\s+/).filter(w => w.length > 2));
  const matchedTerms: string[] = [];
  let weightedScore = 0;
  words1.forEach(w1 => {
    words2.forEach(w2 => {
      if (w1 === w2 || (w1.length >= 5 && w2.length >= 5 && (w1.includes(w2) || w2.includes(w1)))) {
        const term = w1.length > w2.length ? w1 : w2;
        if (!matchedTerms.includes(term)) {
          matchedTerms.push(term);
          weightedScore += HIGH_VALUE_TERMS.has(term) || HIGH_VALUE_TERMS.has(w1) || HIGH_VALUE_TERMS.has(w2) ? 3 : 1;
        }
      }
    });
  });
  const minWords = Math.min(words1.size, words2.size);
  const score = minWords > 0 ? Math.min(weightedScore / minWords, 1) : 0;
  return { score, matchedTerms };
}

function findBestMatches(discoveredUseCase: string, templates: UseCaseTemplate[], topN: number = 3): MatchResult[] {
  const scored = templates.map(template => {
    const nameMatch = calculateSimilarityWithDetails(discoveredUseCase, template.name);
    const descMatch = template.description 
      ? calculateSimilarityWithDetails(discoveredUseCase, template.description)
      : { score: 0, matchedTerms: [] };
    const combinedScore = (nameMatch.score * 0.6) + (descMatch.score * 0.4);
    const allMatchedTerms = [...new Set([...nameMatch.matchedTerms, ...descMatch.matchedTerms])];
    const reasoning = allMatchedTerms.length > 0
      ? `Matched terms: ${allMatchedTerms.slice(0, 5).join(', ')}${allMatchedTerms.length > 5 ? ` (+${allMatchedTerms.length - 5} more)` : ''}`
      : 'No direct term matches';
    return { template, score: combinedScore, matchedTerms: allMatchedTerms, reasoning };
  });
  return scored.filter(s => s.score > 0.05).sort((a, b) => b.score - a.score).slice(0, topN);
}

export function UseCasesPanel({ accountId, opportunityId, linkedOnly }: UseCasesPanelProps) {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedArea, setSelectedArea] = useState<string | undefined>();
  const [editingUseCase, setEditingUseCase] = useState<UseCase | undefined>();
  const [expandedProposals, setExpandedProposals] = useState<Set<number>>(new Set());
  const [expandedExistingUseCase, setExpandedExistingUseCase] = useState<string | null>(null);
  const [expandedUseCaseDetails, setExpandedUseCaseDetails] = useState<Set<string>>(new Set());
  const [isLinking, setIsLinking] = useState<string | null>(null);
  const [acceptanceFilter, setAcceptanceFilter] = useState<string>('all');

  // Fetch use cases
  const { data: useCases, isLoading } = useQuery({
    queryKey: linkedOnly
      ? ['use-cases-panel', 'linked', opportunityId || accountId]
      : opportunityId 
        ? ['use-cases-panel', 'opportunity', opportunityId]
        : ['use-cases-panel', 'account', accountId],
    queryFn: async () => {
      let query = gateway
        .from('account_use_cases')
        .select('*')
        .eq('account_id', accountId)
        .order('sort_order', { ascending: true })
        .order('created_at', { ascending: false });
      if (opportunityId) {
        query = query.eq('opportunity_id', opportunityId);
      }
      if (linkedOnly) {
        query = query.not('acceptance_status', 'is', null);
      }
      const response = await query.execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as UseCase[];
    },
  });

  // Fetch use case templates
  const { data: useCaseTemplates } = useQuery({
    queryKey: ['use-case-templates-with-areas-full'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('use_case_templates')
        .select('id, name, description, functional_area_id, business_outcome, solution_description, functional_areas(name)')
        .eq('is_active', true);
      if (error) throw error;
      return data.map((t: any) => ({
        id: t.id,
        name: t.name,
        description: t.description,
        functional_area_id: t.functional_area_id,
        functional_area_name: t.functional_areas?.name || 'Other',
        business_outcome: t.business_outcome,
        solution_description: t.solution_description,
      })) as UseCaseTemplate[];
    },
  });

  // Fetch template-to-module mapping
  const { data: templateProducts } = useQuery({
    queryKey: ['use-case-template-products'],
    queryFn: async () => {
      const response = await gateway.from('use_case_template_products')
        .select('use_case_template_id, module_pricing_id')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as { use_case_template_id: string; module_pricing_id: string }[];
    },
  });

  // Fetch module names
  const { data: modules } = useQuery({
    queryKey: ['module-pricing-names'],
    queryFn: async () => {
      const response = await gateway.from('module_pricing')
        .select('id, module_name')
        .eq('is_active', true)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as ModuleInfo[];
    },
  });

  // Build template-to-modules map
  const templateToModules = useMemo(() => {
    const map = new Map<string, string[]>();
    templateProducts?.forEach(tp => {
      const existing = map.get(tp.use_case_template_id) || [];
      existing.push(tp.module_pricing_id);
      map.set(tp.use_case_template_id, existing);
    });
    return map;
  }, [templateProducts]);

  // Module id to name map
  const moduleNameMap = useMemo(() => {
    const map = new Map<string, string>();
    modules?.forEach(m => map.set(m.id, m.module_name));
    return map;
  }, [modules]);

  // Fetch extracted use cases from transcripts
  const { data: extractedUseCases } = useQuery({
    queryKey: opportunityId 
      ? ['extracted-use-cases', 'opportunity', opportunityId]
      : ['extracted-use-cases', 'account', accountId],
    queryFn: async () => {
      let query = supabase
        .from('transcript_reviews')
        .select('id, file_name, extracted_insights')
        .eq('status', 'approved');
      if (opportunityId) {
        query = query.eq('opportunity_id', opportunityId);
      } else {
        query = query.eq('final_account_id', accountId);
      }
      const { data, error } = await query;
      if (error) throw error;
      const extracted: ExtractedUseCase[] = [];
      data.forEach(transcript => {
        const insights = transcript.extracted_insights as any;
        const useCasesFromTranscript = insights?.useCases || [];
        useCasesFromTranscript.forEach((uc: string | { description?: string; use_case?: string; useCase?: string; priority?: string }) => {
          const ucText = typeof uc === 'string' ? uc : (uc?.description || uc?.useCase || uc?.use_case || '');
          if (!ucText) return;
          extracted.push({
            useCase: ucText,
            transcriptId: transcript.id,
            transcriptName: transcript.file_name || 'Transcript',
          });
        });
      });
      return extracted;
    },
    enabled: !!accountId,
  });

  // Filter out already-added extracted use cases and compute matches
  const pendingProposalsWithMatches = useMemo(() => {
    if (!extractedUseCases || !useCases) return [];
    const existingNames = new Set(useCases.filter(uc => uc.use_case).map(uc => uc.use_case!.toLowerCase()));
    const filtered = extractedUseCases.filter(e => e.useCase && !existingNames.has(e.useCase.toLowerCase()));
    return filtered.map(proposal => ({
      ...proposal,
      suggestedMatches: useCaseTemplates ? findBestMatches(proposal.useCase, useCaseTemplates, 3) : [],
    }));
  }, [extractedUseCases, useCases, useCaseTemplates]);

  // Apply acceptance filter
  const filteredUseCases = useMemo(() => {
    if (!useCases) return [];
    if (acceptanceFilter === 'all') return useCases;
    if (acceptanceFilter === 'prospect') {
      return useCases.filter(uc => uc.acceptance_status === 'validated' || uc.acceptance_status === 'accepted');
    }
    return useCases.filter(uc => uc.acceptance_status === acceptanceFilter);
  }, [useCases, acceptanceFilter]);

  // Group use cases by business outcome
  const groupedByOutcome = useMemo(() => {
    if (!filteredUseCases) return new Map<string, UseCase[]>();
    const groups = new Map<string, UseCase[]>();
    
    // First, try to resolve business_outcome from template if not on the use case itself
    const enriched = filteredUseCases.map(uc => {
      if (uc.business_outcome) return uc;
      // Try to match by use_case name to a template
      if (useCaseTemplates && uc.use_case) {
        const match = useCaseTemplates.find(t => t.name.toLowerCase() === uc.use_case?.toLowerCase());
        if (match) {
          return { ...uc, business_outcome: match.business_outcome, solution_description: match.solution_description, use_case_template_id: match.id };
        }
      }
      return uc;
    });

    for (const uc of enriched) {
      const outcome = uc.business_outcome || 'Uncategorized';
      const group = groups.get(outcome) || [];
      group.push(uc);
      groups.set(outcome, group);
    }
    return groups;
  }, [filteredUseCases, useCaseTemplates]);

  // Compute suggested matches for unlinked use cases
  const useCasesWithMatches = useMemo(() => {
    if (!filteredUseCases || !useCaseTemplates) return new Map<string, MatchResult[]>();
    const map = new Map<string, MatchResult[]>();
    filteredUseCases.forEach(uc => {
      if ((uc.functional_area === 'General' || uc.functional_area === 'Other' || !uc.functional_area) && uc.use_case) {
        map.set(uc.id, findBestMatches(uc.use_case, useCaseTemplates, 3));
      }
    });
    return map;
  }, [filteredUseCases, useCaseTemplates]);

  // Get module names for a template
  const getModulesForTemplate = (templateId: string): string[] => {
    const moduleIds = templateToModules.get(templateId) || [];
    return moduleIds.map(id => moduleNameMap.get(id) || id).filter(Boolean);
  };

  // Get module names for a use case (from required_module_ids or template)
  const getModulesForUseCase = (uc: UseCase): string[] => {
    if (uc.required_module_ids && uc.required_module_ids.length > 0) {
      return uc.required_module_ids.map(id => moduleNameMap.get(id) || id);
    }
    if (uc.use_case_template_id) {
      return getModulesForTemplate(uc.use_case_template_id);
    }
    // Try to match by name
    if (useCaseTemplates && uc.use_case) {
      const match = useCaseTemplates.find(t => t.name.toLowerCase() === uc.use_case?.toLowerCase());
      if (match) return getModulesForTemplate(match.id);
    }
    return [];
  };

  // Handler to link an existing use case to a template
  const handleLinkExistingToTemplate = async (useCase: UseCase, template: UseCaseTemplate) => {
    setIsLinking(`existing-${useCase.id}-${template.id}`);
    try {
      const moduleIds = templateToModules.get(template.id) || [];
      const response = await gateway
        .from('account_use_cases')
        .update({
          functional_area: template.functional_area_name || template.name,
          use_case: template.name,
          description: `Originally: "${useCase.use_case}"\n\n${template.description || ''}`,
          use_case_template_id: template.id,
          business_outcome: template.business_outcome || null,
          solution_description: template.solution_description || null,
          required_module_ids: moduleIds.length > 0 ? moduleIds : null,
        })
        .eq('id', useCase.id)
        .execute();
      if (response.error) {
        toast.error('Failed to link use case');
      } else {
        toast.success(`Use case linked to "${template.name}"`);
        setExpandedExistingUseCase(null);
        invalidateQueries();
      }
    } finally {
      setIsLinking(null);
    }
  };

  const handleAddUseCase = (area?: string) => {
    setSelectedArea(area);
    setEditingUseCase(undefined);
    setDialogOpen(true);
  };

  const handleDeleteUseCase = async (useCase: UseCase) => {
    if (confirm('Delete this use case?')) {
      const { error } = await supabase
        .from('account_use_cases')
        .delete()
        .eq('id', useCase.id);
      if (error) console.error('Error deleting use case:', error);
      else invalidateQueries();
    }
  };

  const handleLinkToTemplate = async (proposal: ExtractedUseCase & { suggestedMatches: any[] }, template: UseCaseTemplate) => {
    setIsLinking(`${proposal.transcriptId}-${template.id}`);
    try {
      const moduleIds = templateToModules.get(template.id) || [];
      const { error } = await gateway
        .from('account_use_cases')
        .insert({
          account_id: accountId,
          opportunity_id: opportunityId || null,
          functional_area: template.functional_area_name || 'Other',
          use_case: template.name,
          description: `Linked from discovered: "${proposal.useCase}"\n\n${template.description || ''}`,
          status: 'identified',
          priority: 'medium',
          source: 'transcript',
          source_transcript_id: proposal.transcriptId,
          use_case_template_id: template.id,
          business_outcome: template.business_outcome || null,
          solution_description: template.solution_description || null,
          required_module_ids: moduleIds.length > 0 ? moduleIds : null,
        })
        .execute();
      if (error) {
        toast.error('Failed to link use case');
      } else {
        toast.success(`Use case "${template.name}" linked successfully`);
        invalidateQueries();
      }
    } finally {
      setIsLinking(null);
    }
  };

  const handleAddAsCustom = async (proposal: ExtractedUseCase) => {
    setIsLinking(proposal.transcriptId);
    try {
      const { error } = await gateway
        .from('account_use_cases')
        .insert({
          account_id: accountId,
          opportunity_id: opportunityId || null,
          functional_area: 'Other',
          use_case: proposal.useCase,
          description: `Discovered from: ${proposal.transcriptName}`,
          status: 'identified',
          priority: 'medium',
          source: 'transcript',
          source_transcript_id: proposal.transcriptId,
        })
        .execute();
      if (error) {
        toast.error('Failed to add custom use case');
      } else {
        toast.success('Custom use case added successfully');
        invalidateQueries();
      }
    } finally {
      setIsLinking(null);
    }
  };

  // Suggest modules to opportunity
  const handleSuggestModules = async () => {
    if (!opportunityId || !useCases) return;
    // Collect all required module IDs from all use cases
    const allModuleIds = new Set<string>();
    useCases.forEach(uc => {
      const moduleIds = uc.required_module_ids || [];
      moduleIds.forEach(id => allModuleIds.add(id));
      // Also check template mapping
      if (uc.use_case_template_id) {
        const tmplModules = templateToModules.get(uc.use_case_template_id) || [];
        tmplModules.forEach(id => allModuleIds.add(id));
      }
      // Try name match
      if (useCaseTemplates && uc.use_case) {
        const match = useCaseTemplates.find(t => t.name.toLowerCase() === uc.use_case?.toLowerCase());
        if (match) {
          const tmplModules = templateToModules.get(match.id) || [];
          tmplModules.forEach(id => allModuleIds.add(id));
        }
      }
    });

    if (allModuleIds.size === 0) {
      toast.info('No modules identified from use cases');
      return;
    }

    // Fetch current included_module_ids
    const { data: opp } = await supabase
      .from('opportunities')
      .select('included_module_ids')
      .eq('id', opportunityId)
      .single();

    const existing = new Set<string>(opp?.included_module_ids || []);
    const newIds = [...allModuleIds].filter(id => !existing.has(id));

    if (newIds.length === 0) {
      toast.info('All required modules are already included');
      return;
    }

    const merged = [...existing, ...newIds];
    const { error } = await supabase
      .from('opportunities')
      .update({ included_module_ids: merged })
      .eq('id', opportunityId);

    if (error) {
      toast.error('Failed to update included modules');
    } else {
      const names = newIds.map(id => moduleNameMap.get(id) || id).join(', ');
      toast.success(`Added ${newIds.length} module(s): ${names}`);
      queryClient.invalidateQueries({ queryKey: ['opportunity-details'] });
    }
  };

  const invalidateQueries = () => {
    queryClient.invalidateQueries({ queryKey: ['use-cases-panel'] });
    queryClient.invalidateQueries({ queryKey: ['account-use-cases', accountId] });
    queryClient.invalidateQueries({ queryKey: ['themed-use-cases', accountId] });
    queryClient.invalidateQueries({ queryKey: ['opportunity-themed-use-cases', opportunityId] });
  };

  const toggleProposalExpanded = (idx: number) => {
    setExpandedProposals(prev => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const toggleUseCaseDetails = (id: string) => {
    setExpandedUseCaseDetails(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  if (isLoading) {
    return (
      <div className="p-8 text-center text-muted-foreground">
        Loading use cases...
      </div>
    );
  }

  const totalUseCases = filteredUseCases.length;
  const implementedCount = filteredUseCases.filter(uc => uc.status === 'implemented').length;
  const prospectConfirmedCount = useCases?.filter(uc => 
    uc.acceptance_status === 'validated' || uc.acceptance_status === 'accepted'
  ).length || 0;

  const AcceptanceBadge = ({ useCase }: { useCase: UseCase }) => {
    const status = useCase.acceptance_status;
    if (!status) return null;
    const config = ACCEPTANCE_COLORS[status] || ACCEPTANCE_COLORS.proposed;
    const icon = status === 'validated' || status === 'accepted' 
      ? <User className="w-3 h-3 mr-1" /> 
      : <Users className="w-3 h-3 mr-1" />;
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="outline" className={cn("text-xs cursor-help", config.bg, config.text)}>
            {icon}{config.label}
          </Badge>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-xs">
          <p className="font-medium mb-1">{config.label}</p>
          {useCase.mentioned_by_name && <p className="text-xs">Mentioned by: {useCase.mentioned_by_name}</p>}
          {useCase.acceptance_evidence && <p className="text-xs mt-1 italic">"{useCase.acceptance_evidence}"</p>}
        </TooltipContent>
      </Tooltip>
    );
  };

  const ModuleChips = ({ modules: moduleNames }: { modules: string[] }) => {
    if (moduleNames.length === 0) return null;
    return (
      <div className="flex flex-wrap gap-1 mt-1.5">
        {moduleNames.map(name => (
          <Badge key={name} variant="outline" className="text-[10px] px-1.5 py-0 h-4 bg-primary/5 border-primary/20 text-primary">
            <Package className="w-2.5 h-2.5 mr-0.5" />
            {name}
          </Badge>
        ))}
      </div>
    );
  };

  // Render a single use case card
  const UseCaseCard = ({ uc }: { uc: UseCase }) => {
    const suggestedMatches = useCasesWithMatches.get(uc.id) || [];
    const hasMatches = suggestedMatches.length > 0;
    const isExpanded = expandedExistingUseCase === uc.id;
    const isDetailsExpanded = expandedUseCaseDetails.has(uc.id);
    const ucModules = getModulesForUseCase(uc);
    const solutionDesc = uc.solution_description || (useCaseTemplates && uc.use_case 
      ? useCaseTemplates.find(t => t.name.toLowerCase() === uc.use_case?.toLowerCase())?.solution_description 
      : null);

    return (
      <div className={cn("rounded-lg border transition-all overflow-hidden bg-card border-border")}>
        <div 
          className={cn("flex items-center gap-3 p-3 cursor-pointer hover:bg-accent/5")}
          onClick={() => toggleUseCaseDetails(uc.id)}
        >
          {isDetailsExpanded ? (
            <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
          ) : (
            <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
          )}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-sm">{uc.use_case || 'Unnamed'}</span>
              {uc.functional_area && uc.functional_area !== 'Other' && uc.functional_area !== 'General' && (
                <Badge variant="secondary" className="text-[10px]">{uc.functional_area}</Badge>
              )}
              <AcceptanceBadge useCase={uc} />
              {uc.created_at && <NewBadge createdAt={uc.created_at} />}
              <ValidationBadge 
                validationCount={uc.validation_count ?? null}
                lastValidatedAt={uc.last_validated_at ?? null}
                confidenceScore={uc.confidence_score ?? null}
              />
              <SourceTranscriptBadge hasSource={!!uc.source_transcript_id} />
              {uc.status && <span className={cn("w-2 h-2 rounded-full", STATUS_COLORS[uc.status])} />}
              {uc.priority && <span className={cn("w-2 h-2 rounded-full", PRIORITY_COLORS[uc.priority])} />}
              {uc.use_case_template_id && (
                <Badge variant="default" className="text-[10px] bg-green-600 hover:bg-green-600 h-4 px-1.5">
                  <Link2 className="w-2.5 h-2.5 mr-0.5" />Linked
                </Badge>
              )}
            </div>
            {uc.description && !isDetailsExpanded && (
              <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{uc.description}</p>
            )}
            {!isDetailsExpanded && ucModules.length > 0 && <ModuleChips modules={ucModules} />}
          </div>
          <div className="flex items-center gap-1 shrink-0">
            {hasMatches && !uc.use_case_template_id && (
              <Badge variant="outline" className="text-[10px] border-amber-500/50 text-amber-600">
                <Link2 className="w-3 h-3 mr-0.5" />
                {suggestedMatches.length} match{suggestedMatches.length !== 1 ? 'es' : ''}
              </Badge>
            )}
            <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={(e) => { e.stopPropagation(); handleDeleteUseCase(uc); }}>
              Delete
            </Button>
          </div>
        </div>

        {/* Expanded details */}
        {isDetailsExpanded && (
          <div className="border-t border-border bg-muted/20 p-3 space-y-3">
            {uc.description && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Description</p>
                <p className="text-sm text-foreground">{uc.description}</p>
              </div>
            )}
            {solutionDesc && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Solution Approach</p>
                <p className="text-sm text-foreground">{solutionDesc}</p>
              </div>
            )}
            {ucModules.length > 0 && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Required Modules</p>
                <ModuleChips modules={ucModules} />
              </div>
            )}

            {/* Template matching options for unlinked */}
            {hasMatches && !uc.use_case_template_id && (
              <div className="space-y-2 pt-2 border-t border-border">
                <p className="text-xs text-muted-foreground">Link to a template for better categorization:</p>
                {suggestedMatches.map((match, matchIdx) => (
                  <div key={matchIdx} className="flex items-center gap-3 p-2 rounded-md bg-background border border-border hover:border-primary/50 transition-colors">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-medium">{match.template.name}</span>
                        <Badge variant="secondary" className="text-[10px]">{match.template.functional_area_name}</Badge>
                        {match.template.business_outcome && (
                          <Badge variant="outline" className="text-[10px]">{match.template.business_outcome}</Badge>
                        )}
                        <Badge variant="outline" className="text-[10px] text-green-600 border-green-500/50">
                          {Math.round(match.score * 100)}% match
                        </Badge>
                      </div>
                      {match.template.description && (
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{match.template.description}</p>
                      )}
                      <ModuleChips modules={getModulesForTemplate(match.template.id)} />
                    </div>
                    <Button
                      variant="default" size="sm"
                      disabled={isLinking === `existing-${uc.id}-${match.template.id}`}
                      onClick={() => handleLinkExistingToTemplate(uc, match.template)}
                    >
                      <Link2 className="w-4 h-4 mr-1" />
                      {isLinking === `existing-${uc.id}-${match.template.id}` ? 'Linking...' : 'Link'}
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-primary" />
            {linkedOnly ? 'Linked Use Cases' : 'Use Cases'}
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            {totalUseCases} use case{totalUseCases !== 1 ? 's' : ''}
            {!linkedOnly && implementedCount > 0 && ` • ${implementedCount} implemented`}
            {!linkedOnly && prospectConfirmedCount > 0 && ` • ${prospectConfirmedCount} prospect-confirmed`}
          </p>
        </div>
        {!linkedOnly && (
          <div className="flex items-center gap-2">
            
            <Select value={acceptanceFilter} onValueChange={setAcceptanceFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by source" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Use Cases</SelectItem>
                <SelectItem value="prospect">Prospect Confirmed</SelectItem>
                <SelectItem value="validated">Prospect Mentioned</SelectItem>
                <SelectItem value="accepted">Team → Accepted</SelectItem>
                <SelectItem value="proposed">Team Proposed</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={() => handleAddUseCase()}>
              <Plus className="w-4 h-4 mr-1" />
              Add Use Case
            </Button>
          </div>
        )}
      </div>

      {/* Pending Proposals */}
      {!linkedOnly && pendingProposalsWithMatches.length > 0 && (
        <Card className="border-dashed border-2 border-amber-500/30 bg-amber-500/5">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span className="text-sm font-medium text-foreground">
                Discovered from Conversations ({pendingProposalsWithMatches.length})
              </span>
            </div>
            <div className="space-y-3">
              {pendingProposalsWithMatches.map((proposal, idx) => (
                <div key={`proposal-${idx}`} className="rounded-lg bg-background border border-border overflow-hidden">
                  <div 
                    className="flex items-center gap-3 p-3 cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => toggleProposalExpanded(idx)}
                  >
                    {expandedProposals.has(idx) ? (
                      <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{proposal.useCase}</p>
                      <p className="text-xs text-muted-foreground">From: {proposal.transcriptName}</p>
                    </div>
                    {proposal.suggestedMatches.length > 0 ? (
                      <Badge variant="outline" className="text-xs border-amber-500/50 text-amber-600 shrink-0">
                        <Link2 className="w-3 h-3 mr-1" />
                        {proposal.suggestedMatches.length} match{proposal.suggestedMatches.length !== 1 ? 'es' : ''}
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-xs text-muted-foreground shrink-0">No matches</Badge>
                    )}
                    <Button
                      variant="outline" size="sm" className="shrink-0"
                      disabled={isLinking === proposal.transcriptId}
                      onClick={(e) => { e.stopPropagation(); handleAddAsCustom(proposal); }}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      {isLinking === proposal.transcriptId ? 'Adding...' : 'Add as Custom'}
                    </Button>
                  </div>
                  {expandedProposals.has(idx) && (
                    <div className="border-t border-border bg-muted/20 p-3 space-y-2">
                      {proposal.suggestedMatches.length > 0 ? (
                        <>
                          <p className="text-xs text-muted-foreground mb-2">Link to an existing use case template:</p>
                          {proposal.suggestedMatches.map((match, matchIdx) => (
                            <div key={matchIdx} className="flex items-center gap-3 p-2 rounded-md bg-background border border-border hover:border-primary/50 transition-colors">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-sm font-medium">{match.template.name}</span>
                                  <Badge variant="secondary" className="text-xs">{match.template.functional_area_name}</Badge>
                                  {match.template.business_outcome && (
                                    <Badge variant="outline" className="text-xs">{match.template.business_outcome}</Badge>
                                  )}
                                  <Badge variant="outline" className="text-xs text-green-600 border-green-500/50">
                                    {Math.round(match.score * 100)}% match
                                  </Badge>
                                </div>
                                {match.template.description && (
                                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{match.template.description}</p>
                                )}
                                <ModuleChips modules={getModulesForTemplate(match.template.id)} />
                              </div>
                              <Button
                                variant="default" size="sm"
                                disabled={isLinking === `${proposal.transcriptId}-${match.template.id}`}
                                onClick={() => handleLinkToTemplate(proposal, match.template)}
                              >
                                <Link2 className="w-4 h-4 mr-1" />
                                {isLinking === `${proposal.transcriptId}-${match.template.id}` ? 'Linking...' : 'Link'}
                              </Button>
                            </div>
                          ))}
                        </>
                      ) : (
                        <p className="text-xs text-muted-foreground">No matching templates found. Add as a custom use case.</p>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Use Cases Grouped by Business Outcome */}
      {totalUseCases === 0 && pendingProposalsWithMatches.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Lightbulb className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
            <h3 className="font-medium mb-2">No use cases yet</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Use cases will appear here when extracted from conversations or added manually
            </p>
            <Button onClick={() => handleAddUseCase()}>
              <Plus className="w-4 h-4 mr-1" />
              Add First Use Case
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {/* Ordered: Increase Revenue, Cut Costs, Reduce Risk, then any others */}
          {['Increase Revenue', 'Cut Costs', 'Reduce Risk', ...Array.from(groupedByOutcome.keys()).filter(k => !['Increase Revenue', 'Cut Costs', 'Reduce Risk'].includes(k))].map(outcome => {
            const ucs = groupedByOutcome.get(outcome);
            if (!ucs || ucs.length === 0) return null;
            const config = OUTCOME_CONFIG[outcome];
            const OutcomeIcon = config?.icon || Lightbulb;

            return (
              <div key={outcome}>
                <div className={cn(
                  "flex items-center gap-2 mb-2 px-3 py-1.5 rounded-md",
                  config?.bg || 'bg-muted'
                )}>
                  <OutcomeIcon className={cn("w-4 h-4", config?.color || 'text-muted-foreground')} />
                  <span className={cn("text-sm font-semibold", config?.color || 'text-foreground')}>
                    {outcome}
                  </span>
                  <Badge variant="outline" className="text-[10px] ml-auto">{ucs.length}</Badge>
                </div>
                <div className="space-y-1.5">
                  {ucs.map(uc => <UseCaseCard key={uc.id} uc={uc} />)}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <UseCaseDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        accountId={accountId}
        opportunityId={opportunityId}
        functionalArea={selectedArea}
        existingUseCase={editingUseCase as any}
      />
    </div>
  );
}

import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useAllUsers, useUserRole, AppRole } from '@/hooks/useUserRole';
import { useAuth } from '@/contexts/AuthContext';
import { useTeamHierarchy } from '@/hooks/useTeamHierarchy';
import { useInviteTeamMember } from '@/hooks/useInviteTeamMember';
import { useCustomRoles } from '@/hooks/useCustomRoles';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Shield, ShieldCheck, UserX, UserCheck, Mail, Smartphone, Clock, CheckCircle2, XCircle, AlertTriangle, Pencil, Trash2, Send, MoreHorizontal, Users, Plus, ChevronRight, KeyRound, UserPlus, Eye, Network, Search, ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { OrgChart } from '@/components/OrgChart';

// Dynamic color assignment for role badges
const getRoleColor = (roleName: string): string => {
  const colorMap: Record<string, string> = {
    admin: 'bg-[hsl(var(--pendo-pink))]/20 text-[hsl(var(--pendo-pink))] border-[hsl(var(--pendo-pink))]/30',
    manager: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    se: 'bg-green-500/20 text-green-400 border-green-500/30',
    ae: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    product: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    sales_leader: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
    user: 'bg-muted text-muted-foreground',
  };
  return colorMap[roleName] || 'bg-slate-500/20 text-slate-400 border-slate-500/30';
};

export function UserManagementView() {
  const { user, getSessionToken, startImpersonating } = useAuth();
  const { isAdmin } = useUserRole();
  const { data: users, isLoading } = useAllUsers();
  const { hierarchyEntries, addReport, removeReport, isLoading: hierarchyLoading } = useTeamHierarchy();
  const { invite, isLoading: inviteLoading } = useInviteTeamMember();
  const { roles: customRoles, isLoading: rolesLoading } = useCustomRoles();
  const queryClient = useQueryClient();
  const [updating, setUpdating] = useState<string | null>(null);
  const [editingUser, setEditingUser] = useState<any | null>(null);
  const [editFullName, setEditFullName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [deleteConfirmUser, setDeleteConfirmUser] = useState<any | null>(null);
  const [addingHierarchy, setAddingHierarchy] = useState(false);
  const [selectedManager, setSelectedManager] = useState('');
  const [selectedReport, setSelectedReport] = useState('');
  const [selectedRelType, setSelectedRelType] = useState<'solid' | 'dotted'>('solid');
  
  // Search & filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortColumn, setSortColumn] = useState<'name' | 'status' | 'role' | 'joined' | 'lastLogin'>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  
  // Invite user state
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteName, setInviteName] = useState('');

  const handleRoleChange = async (userId: string, newRole: AppRole) => {
    if (!isAdmin) {
      toast.error('Only admins can change roles');
      return;
    }

    setUpdating(userId);
    try {
      // Verify the user has a profile before attempting role change
      const { data: profileCheck } = await gateway
        .from('profiles')
        .select('id, status')
        .eq('id', userId)
        .single()
        .execute();

      if (!profileCheck) {
        throw new Error('User profile not found. The user may need to sign in first.');
      }

      // Allow role assignment to identified users so they have the correct role on first login

      await gateway
        .from('user_roles')
        .delete()
        .eq('user_id', userId)
        .execute();

      const { error } = await gateway
        .from('user_roles')
        .insert({
          user_id: userId,
          role: newRole as any,
          granted_by: user?.id,
        })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      
      toast.success(`Role updated to ${newRole}`);
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
    } catch (error: any) {
      toast.error('Failed to update role: ' + error.message);
    } finally {
      setUpdating(null);
    }
  };

  const handleStatusChange = async (userId: string, newStatus: 'pending' | 'active' | 'suspended') => {
    if (!isAdmin) {
      toast.error('Only admins can change status');
      return;
    }

    setUpdating(userId);
    try {
      const { error } = await gateway
        .from('profiles')
        .update({ status: newStatus })
        .eq('id', userId)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      
      toast.success(`User status updated to ${newStatus}`);
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
    } catch (error: any) {
      toast.error('Failed to update status: ' + error.message);
    } finally {
      setUpdating(null);
    }
  };

  const handleEditUser = (u: any) => {
    setEditingUser(u);
    setEditFullName(u.full_name || '');
    setEditEmail(u.email || '');
  };

  const handleSaveEdit = async () => {
    if (!editingUser) return;
    
    // Validate email
    if (!editEmail || !editEmail.includes('@')) {
      toast.error('Please enter a valid email address');
      return;
    }
    
    setUpdating(editingUser.id);
    try {
      const { error } = await gateway
        .from('profiles')
        .update({ 
          full_name: editFullName || null,
          email: editEmail.trim().toLowerCase()
        })
        .eq('id', editingUser.id)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      
      toast.success('User profile updated');
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      queryClient.invalidateQueries({ queryKey: ['all-active-users'] });
      queryClient.invalidateQueries({ queryKey: ['team-members'] });
      setEditingUser(null);
    } catch (error: any) {
      toast.error('Failed to update user: ' + error.message);
    } finally {
      setUpdating(null);
    }
  };

  const handleDeleteUser = async () => {
    if (!deleteConfirmUser) return;
    
    setUpdating(deleteConfirmUser.id);
    try {
      // Delete user roles first
      await gateway
        .from('user_roles')
        .delete()
        .eq('user_id', deleteConfirmUser.id)
        .execute();

      // Delete profile
      const { error } = await gateway
        .from('profiles')
        .delete()
        .eq('id', deleteConfirmUser.id)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      
      toast.success('User deleted successfully');
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      setDeleteConfirmUser(null);
    } catch (error: any) {
      toast.error('Failed to delete user: ' + error.message);
    } finally {
      setUpdating(null);
    }
  };

  const handleResendVerification = async (email: string) => {
    // NOTE: This app uses custom auth (profiles table), not Supabase Auth.
    // Resending verification would need to go through auth-invite-user again.
    // For now, show an info message directing to re-invite.
    toast.info('To resend an invite, use the "Invite User" button to send a new invitation.');
  };

  const handleResetPassword = async (email: string) => {
    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/auth-forgot-password`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email }),
        }
      );

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to send password reset');
      }
      
      toast.success(`Password reset email sent to ${email}`);
    } catch (error: any) {
      toast.error('Failed to send password reset email: ' + error.message);
    }
  };

  const handleInviteUser = () => {
    if (!inviteEmail || !inviteEmail.includes('@')) {
      toast.error('Please enter a valid email address');
      return;
    }
    
    invite({ email: inviteEmail, name: inviteName || undefined }, {
      onSuccess: () => {
        setInviteDialogOpen(false);
        setInviteEmail('');
        setInviteName('');
      }
    });
  };

  const handleRevokeAccess = async (userId: string) => {
    if (!isAdmin) {
      toast.error('Only admins can revoke access');
      return;
    }

    if (userId === user?.id) {
      toast.error('You cannot revoke your own access');
      return;
    }

    setUpdating(userId);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ status: 'suspended' })
        .eq('id', userId);

      if (error) throw error;
      
      toast.success('User access revoked');
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
    } catch (error: any) {
      toast.error('Failed to revoke access: ' + error.message);
    } finally {
      setUpdating(null);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30"><CheckCircle2 className="w-3 h-3 mr-1" />Active</Badge>;
      case 'suspended':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30"><XCircle className="w-3 h-3 mr-1" />Suspended</Badge>;
      default:
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
    }
  };

  const getRoleBadge = (roles: AppRole[]) => {
    // Find the first matching role from customRoles (prioritize by order in DB)
    for (const customRole of customRoles) {
      if (roles.includes(customRole.name)) {
        return (
          <Badge className={cn('text-xs', getRoleColor(customRole.name))}>
            <Shield className="w-3 h-3 mr-1" />
            {customRole.display_name}
          </Badge>
        );
      }
    }
    return <Badge variant="secondary"><Shield className="w-3 h-3 mr-1" />User</Badge>;
  };

  const getCurrentRole = (roles: AppRole[]): AppRole => {
    // Find the first matching role from customRoles
    for (const customRole of customRoles) {
      if (roles.includes(customRole.name)) {
        return customRole.name;
      }
    }
    return 'user';
  };

  // Get roles for dropdown (exclude 'user' as it's the default)
  const selectableRoles = customRoles.filter(r => r.name !== 'user');

  const handleSortToggle = (column: typeof sortColumn) => {
    if (sortColumn === column) {
      setSortDirection(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ column }: { column: typeof sortColumn }) => {
    if (sortColumn !== column) return <ArrowUpDown className="w-3 h-3 ml-1 opacity-40" />;
    return sortDirection === 'asc' ? <ArrowUp className="w-3 h-3 ml-1" /> : <ArrowDown className="w-3 h-3 ml-1" />;
  };

  const filteredUsers = (users || [])
    .filter(u => {
      if (statusFilter !== 'all' && u.status !== statusFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          u.email.toLowerCase().includes(q) ||
          (u.full_name || '').toLowerCase().includes(q)
        );
      }
      return true;
    })
    .sort((a, b) => {
      const dir = sortDirection === 'asc' ? 1 : -1;
      switch (sortColumn) {
        case 'name':
          return dir * (a.full_name || a.email).localeCompare(b.full_name || b.email);
        case 'status':
          return dir * a.status.localeCompare(b.status);
        case 'role':
          return dir * getCurrentRole(a.roles).localeCompare(getCurrentRole(b.roles));
        case 'joined':
          return dir * (new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
        case 'lastLogin': {
          const aTime = (a as any).last_login_at ? new Date((a as any).last_login_at).getTime() : 0;
          const bTime = (b as any).last_login_at ? new Date((b as any).last_login_at).getTime() : 0;
          return dir * (aTime - bTime);
        }
        default:
          return 0;
      }
    });

  if (!isAdmin) {
    return (
      <div className="p-6">
        <Card className="glass border-border">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <AlertTriangle className="w-12 h-12 text-yellow-500 mb-4" />
            <h3 className="text-lg font-semibold text-foreground">Access Denied</h3>
            <p className="text-muted-foreground text-center mt-2">
              Only administrators can manage users.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="page-heading">User Management</h1>
        <p className="text-muted-foreground">Manage user access, roles, and team structure</p>
      </div>

      <Tabs defaultValue="users" className="space-y-6">
        <TabsList>
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            Users
          </TabsTrigger>
          <TabsTrigger value="hierarchy" className="flex items-center gap-2">
            <Network className="w-4 h-4" />
            Team Hierarchy
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-6">

      <Card className="glass border-border">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
              Registered Users
            </CardTitle>
            <CardDescription>
              New users require admin approval. 2FA is required before they can access the platform.
            </CardDescription>
          </div>
          <Button onClick={() => setInviteDialogOpen(true)} size="sm">
            <UserPlus className="w-4 h-4 mr-2" />
            Invite User
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search & Filter Bar */}
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 h-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36 h-9">
                <SelectValue placeholder="All statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
                <SelectItem value="identified">Identified</SelectItem>
              </SelectContent>
            </Select>
            <span className="text-xs text-muted-foreground whitespace-nowrap">
              {filteredUsers.length} user{filteredUsers.length !== 1 ? 's' : ''}
            </span>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="cursor-pointer select-none" onClick={() => handleSortToggle('name')}>
                    <span className="flex items-center">User<SortIcon column="name" /></span>
                  </TableHead>
                  <TableHead className="cursor-pointer select-none" onClick={() => handleSortToggle('status')}>
                    <span className="flex items-center">Status<SortIcon column="status" /></span>
                  </TableHead>
                  <TableHead className="cursor-pointer select-none" onClick={() => handleSortToggle('role')}>
                    <span className="flex items-center">Role<SortIcon column="role" /></span>
                  </TableHead>
                  <TableHead>2FA</TableHead>
                  <TableHead className="cursor-pointer select-none" onClick={() => handleSortToggle('lastLogin')}>
                    <span className="flex items-center">Last Login<SortIcon column="lastLogin" /></span>
                  </TableHead>
                  <TableHead className="cursor-pointer select-none" onClick={() => handleSortToggle('joined')}>
                    <span className="flex items-center">Joined<SortIcon column="joined" /></span>
                  </TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No users match your search
                    </TableCell>
                  </TableRow>
                ) : null}
                {filteredUsers.map((u) => (
                  <TableRow key={u.id} className={cn(updating === u.id && "opacity-50")}>
                    <TableCell>
                      <div>
                        <p className={cn(
                          "font-medium",
                          u.email.endsWith('@pendo.io') && "text-[hsl(var(--pendo-pink))]"
                        )}>
                          {u.email}
                        </p>
                        {u.full_name && (
                          <p className="text-sm text-muted-foreground">{u.full_name}</p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(u.status)}</TableCell>
                    <TableCell>
                      {u.id !== user?.id ? (
                        <Select
                          value={getCurrentRole(u.roles)}
                          onValueChange={(value) => handleRoleChange(u.id, value as AppRole)}
                          disabled={updating === u.id}
                        >
                          <SelectTrigger className="w-28 h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {selectableRoles.map(role => (
                              <SelectItem key={role.id} value={role.name}>
                                {role.display_name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        getRoleBadge(u.roles)
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "text-xs",
                          u.mfa_enabled 
                            ? "border-green-500/30 text-green-400" 
                            : "border-yellow-500/30 text-yellow-400"
                        )}
                      >
                        <Smartphone className="w-3 h-3 mr-1" />
                        {u.mfa_enabled ? '2FA Enabled' : 'No 2FA'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {(u as any).last_login_at ? (
                        <span title={format(new Date((u as any).last_login_at), 'PPpp')}>
                          {format(new Date((u as any).last_login_at), 'MMM d, h:mm a')}
                        </span>
                      ) : (
                        <span className="text-yellow-500">Never</span>
                      )}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {format(new Date(u.created_at), 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        {u.id !== user?.id ? (
                          <>
                            {/* Send Invite for identified users (captured from meetings but never invited) */}
                            {u.status === 'identified' && (
                              <Button
                                size="sm"
                                onClick={() => invite({ email: u.email, name: u.full_name || undefined })}
                                disabled={updating === u.id || inviteLoading}
                                title="Send login credentials to this user"
                              >
                                <Send className="w-4 h-4 mr-1" />
                                Send Invite
                              </Button>
                            )}

                            {/* Prominent Approve/Reject for pending users */}
                            {u.status === 'pending' && (
                              <>
                                <Button
                                  size="sm"
                                  onClick={() => handleStatusChange(u.id, 'active')}
                                  disabled={updating === u.id}
                                  title="Approve user access (user can set up 2FA after approval)"
                                  className="bg-green-600 hover:bg-green-700 text-white"
                                >
                                  <UserCheck className="w-4 h-4 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setDeleteConfirmUser(u)}
                                  disabled={updating === u.id}
                                  className="text-red-400 border-red-500/30 hover:bg-red-500/10"
                                >
                                  <UserX className="w-4 h-4 mr-1" />
                                  Reject
                                </Button>
                              </>
                            )}

                            {/* Suspend button for active users */}
                            {u.status === 'active' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleRevokeAccess(u.id)}
                                disabled={updating === u.id}
                                className="text-red-400 border-red-500/30 hover:bg-red-500/10"
                                title="Suspend user access"
                              >
                                <UserX className="w-4 h-4" />
                              </Button>
                            )}

                            {/* Reactivate for suspended users */}
                            {u.status === 'suspended' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleStatusChange(u.id, 'active')}
                                disabled={updating === u.id}
                                className="text-green-400 border-green-500/30 hover:bg-green-500/10"
                              >
                                <UserCheck className="w-4 h-4 mr-1" />
                                Reactivate
                              </Button>
                            )}

                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button size="sm" variant="ghost">
                                  <MoreHorizontal className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem 
                                  onClick={() => {
                                    startImpersonating({
                                      id: u.id,
                                      email: u.email,
                                      full_name: u.full_name,
                                      roles: u.roles,
                                    });
                                  }}
                                  className="text-amber-500 focus:text-amber-500"
                                >
                                  <Eye className="w-4 h-4 mr-2" />
                                  Impersonate
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onClick={() => handleEditUser(u)}>
                                  <Pencil className="w-4 h-4 mr-2" />
                                  Edit Profile
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleResetPassword(u.email)}>
                                  <KeyRound className="w-4 h-4 mr-2" />
                                  Reset Password
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem 
                                  onClick={() => setDeleteConfirmUser(u)}
                                  className="text-red-400 focus:text-red-400"
                                >
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Delete User
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </>
                        ) : (
                          <span className="text-xs text-muted-foreground">You</span>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card className="glass border-border">
        <CardHeader>
          <CardTitle>Access Requirements</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-3">
            <Mail className="w-5 h-5 text-[hsl(var(--pendo-pink))] mt-0.5" />
            <div>
              <h4 className="font-medium text-foreground">Pendo Email Required</h4>
              <p className="text-sm text-muted-foreground">Only users with @pendo.io email addresses can register</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Smartphone className="w-5 h-5 text-[hsl(var(--pendo-pink))] mt-0.5" />
            <div>
              <h4 className="font-medium text-foreground">Two-Factor Authentication</h4>
              <p className="text-sm text-muted-foreground">2FA is mandatory for all users before they can be approved</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <UserCheck className="w-5 h-5 text-[hsl(var(--pendo-pink))] mt-0.5" />
            <div>
              <h4 className="font-medium text-foreground">Admin Approval</h4>
              <p className="text-sm text-muted-foreground">New registrations require admin approval to verify user identity</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-[hsl(var(--pendo-pink))] mt-0.5" />
            <div>
              <h4 className="font-medium text-foreground">Admin Privileges</h4>
              <p className="text-sm text-muted-foreground">Admins can edit Functional Areas, Reference Architecture, Technology Library, and manage users</p>
            </div>
          </div>
        </CardContent>
      </Card>
        </TabsContent>

        <TabsContent value="hierarchy" className="space-y-6">
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Network className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
                Organization Chart
              </CardTitle>
              <CardDescription>
                Visual team structure. Click on any user to add direct reports or set their manager.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <OrgChart onAddHierarchy={() => setAddingHierarchy(true)} />
            </CardContent>
          </Card>

          {/* Hierarchy List View */}
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-muted-foreground" />
                All Assignments (List View)
              </CardTitle>
              <CardDescription>
                Flat list of all manager-report relationships for reference.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {hierarchyLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                </div>
              ) : !hierarchyEntries?.length ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No team assignments yet.</p>
                  <p className="text-sm">Use the org chart above to create relationships.</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Manager</TableHead>
                      <TableHead></TableHead>
                      <TableHead>Report</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {hierarchyEntries.map((entry) => {
                      const manager = users?.find(u => u.id === entry.manager_id);
                      const report = users?.find(u => u.id === entry.report_id);
                      return (
                        <TableRow key={entry.id}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{manager?.full_name || manager?.email || 'Unknown'}</p>
                              {manager?.full_name && <p className="text-xs text-muted-foreground">{manager.email}</p>}
                            </div>
                          </TableCell>
                          <TableCell>
                            <ChevronRight className="w-4 h-4 text-muted-foreground" />
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{report?.full_name || report?.email || 'Unknown'}</p>
                              {report?.full_name && <p className="text-xs text-muted-foreground">{report.email}</p>}
                            </div>
                          </TableCell>
                          <TableCell>
                            {entry.relationship_type === 'dotted' ? (
                              <Badge variant="outline" className="text-xs border-dashed">Dotted</Badge>
                            ) : (
                              <Badge variant="secondary" className="text-xs">Solid</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-muted-foreground text-sm">
                            {format(new Date(entry.created_at), 'MMM d, yyyy')}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => removeReport.mutate({ 
                                managerId: entry.manager_id, 
                                reportId: entry.report_id 
                              })}
                              className="text-red-400 hover:text-red-500 hover:bg-red-500/10"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Hierarchy Dialog */}
      <Dialog open={addingHierarchy} onOpenChange={setAddingHierarchy}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Team Assignment</DialogTitle>
            <DialogDescription>
              Assign a user as a direct report to a manager. The report will appear in the manager's Team Dashboard.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Manager</Label>
              <Select value={selectedManager} onValueChange={setSelectedManager}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a manager" />
                </SelectTrigger>
                <SelectContent>
                  {users?.map(u => (
                    <SelectItem key={u.id} value={u.id}>
                      <span className="flex items-center gap-2">
                        {u.full_name || u.email}
                        {u.full_name && <span className="text-muted-foreground">({u.email})</span>}
                        {u.status !== 'active' && (
                          <span className={`text-xs px-1.5 py-0.5 rounded ${
                            u.status === 'pending' ? 'bg-yellow-500/10 text-yellow-600' : 
                            'bg-muted text-muted-foreground'
                          }`}>{u.status}</span>
                        )}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Direct Report</Label>
              <Select value={selectedReport} onValueChange={setSelectedReport}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a report" />
                </SelectTrigger>
                <SelectContent>
                  {users?.filter(u => u.id !== selectedManager).map(u => (
                    <SelectItem key={u.id} value={u.id}>
                      <span className="flex items-center gap-2">
                        {u.full_name || u.email}
                        {u.full_name && <span className="text-muted-foreground">({u.email})</span>}
                        {u.status !== 'active' && (
                          <span className={`text-xs px-1.5 py-0.5 rounded ${
                            u.status === 'pending' ? 'bg-yellow-500/10 text-yellow-600' : 
                            'bg-muted text-muted-foreground'
                          }`}>{u.status}</span>
                        )}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Relationship Type</Label>
              <Select value={selectedRelType} onValueChange={(v) => setSelectedRelType(v as 'solid' | 'dotted')}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="solid">Solid Line (primary manager)</SelectItem>
                  <SelectItem value="dotted">Dotted Line (secondary manager)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setAddingHierarchy(false);
              setSelectedManager('');
              setSelectedReport('');
              setSelectedRelType('solid');
            }}>
              Cancel
            </Button>
            <Button 
              onClick={() => {
                if (selectedManager && selectedReport) {
                  addReport.mutate({ managerId: selectedManager, reportId: selectedReport, relationshipType: selectedRelType });
                  setAddingHierarchy(false);
                  setSelectedManager('');
                  setSelectedReport('');
                  setSelectedRelType('solid');
                }
              }}
              disabled={!selectedManager || !selectedReport || addReport.isPending}
            >
              Add Assignment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User Profile</DialogTitle>
            <DialogDescription>
              Update profile information for this user
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="editEmail">Email Address</Label>
              <Input
                id="editEmail"
                type="email"
                value={editEmail}
                onChange={(e) => setEditEmail(e.target.value)}
                placeholder="Enter email address"
              />
              <p className="text-xs text-muted-foreground">
                Changing the email will affect meeting imports and team matching
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                value={editFullName}
                onChange={(e) => setEditFullName(e.target.value)}
                placeholder="Enter full name"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingUser(null)}>
              Cancel
            </Button>
            <Button onClick={handleSaveEdit} disabled={updating === editingUser?.id}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete User Confirmation */}
      <AlertDialog open={!!deleteConfirmUser} onOpenChange={() => setDeleteConfirmUser(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete User</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {deleteConfirmUser?.email}? This action cannot be undone.
              The user's profile and roles will be permanently removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteUser}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete User
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Invite User Dialog */}
      <Dialog open={inviteDialogOpen} onOpenChange={setInviteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
              Invite New User
            </DialogTitle>
            <DialogDescription>
              Send an invitation email with a temporary password. The user will be required to change their password and set up 2FA on first login.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="inviteEmail">Email Address *</Label>
              <Input
                id="inviteEmail"
                type="email"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                placeholder="user@pendo.io"
              />
              <p className="text-xs text-muted-foreground">
                Only @pendo.io email addresses are allowed
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="inviteName">Full Name (optional)</Label>
              <Input
                id="inviteName"
                value={inviteName}
                onChange={(e) => setInviteName(e.target.value)}
                placeholder="John Doe"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setInviteDialogOpen(false);
              setInviteEmail('');
              setInviteName('');
            }}>
              Cancel
            </Button>
            <Button 
              onClick={handleInviteUser}
              disabled={inviteLoading || !inviteEmail}
            >
              {inviteLoading ? (
                <>
                  <div className="animate-spin w-4 h-4 border-2 border-background border-t-transparent rounded-full mr-2" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send Invitation
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

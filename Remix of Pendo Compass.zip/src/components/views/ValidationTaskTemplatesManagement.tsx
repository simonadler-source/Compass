import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Edit2, Trash2, CheckCircle2, ExternalLink, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { Textarea } from '@/components/ui/textarea';

interface ValidationTaskTemplate {
  id: string;
  module: string;
  sub_module: string | null;
  activity: string;
  default_owner: string | null;
  resources_url: string | null;
  deployment_type_id: string | null;
  sort_order: number | null;
}

export function ValidationTaskTemplatesManagement() {
  const queryClient = useQueryClient();
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState<ValidationTaskTemplate | null>(null);
  const [dialogStep, setDialogStep] = useState<'template' | 'detection'>('template');
  
  // Form states
  const [module, setModule] = useState('');
  const [subModule, setSubModule] = useState('');
  const [activity, setActivity] = useState('');
  const [defaultOwner, setDefaultOwner] = useState('');
  const [resourcesUrl, setResourcesUrl] = useState('');
  const [deploymentTypeId, setDeploymentTypeId] = useState<string>('');
  
  // Detection rule form states
  const [createDetectionRule, setCreateDetectionRule] = useState(false);
  const [detectionRuleName, setDetectionRuleName] = useState('');
  const [detectionTreeId, setDetectionTreeId] = useState('');
  const [triggerPhrases, setTriggerPhrases] = useState('');
  const [newTemplateId, setNewTemplateId] = useState<string | null>(null);
  
  // Fetch deployment types
  const { data: deploymentTypes } = useQuery({
    queryKey: ['deployment-types'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('deployment_types')
        .select('*')
        .order('sort_order');
      if (error) throw error;
      return data;
    },
  });
  
  // Fetch detection rule trees
  const { data: detectionTrees } = useQuery({
    queryKey: ['detection-trees'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('detection_rule_trees')
        .select('id, name')
        .order('name');
      if (error) throw error;
      return data;
    },
  });
  
  // Fetch templates
  const { data: templates, isLoading } = useQuery({
    queryKey: ['validation-task-templates-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('validation_task_templates')
        .select('*')
        .order('module')
        .order('sub_module')
        .order('sort_order');
      if (error) throw error;
      return data as ValidationTaskTemplate[];
    },
  });
  
  // Mutations
  const saveTemplate = useMutation({
    mutationFn: async (data: Partial<ValidationTaskTemplate> & { id?: string }) => {
      if (data.id) {
        const { error } = await gateway
          .from('validation_task_templates')
          .update({
            module: data.module,
            sub_module: data.sub_module,
            activity: data.activity,
            default_owner: data.default_owner,
            resources_url: data.resources_url,
            deployment_type_id: data.deployment_type_id,
          })
          .eq('id', data.id)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        return data.id;
      } else {
        const maxSort = templates?.reduce((max, t) => Math.max(max, t.sort_order || 0), 0) || 0;
        const { data: inserted, error } = await gateway
          .from('validation_task_templates')
          .insert({
            module: data.module,
            sub_module: data.sub_module,
            activity: data.activity,
            default_owner: data.default_owner,
            resources_url: data.resources_url,
            deployment_type_id: data.deployment_type_id,
            sort_order: maxSort + 1,
          })
          .execute();
        if (error) throw new Error(getErrorMessage(error));
        const insertedData = Array.isArray(inserted) ? inserted[0] : inserted;
        return insertedData?.id;
      }
    },
    onSuccess: (templateId) => {
      queryClient.invalidateQueries({ queryKey: ['validation-task-templates-admin'] });
      if (editing) {
        setShowDialog(false);
        resetForm();
        toast.success('Template updated');
      } else if (createDetectionRule) {
        setNewTemplateId(templateId);
        setDetectionRuleName(activity.substring(0, 50) + ' Detection');
        setDialogStep('detection');
        toast.success('Template created - now configure detection rule');
      } else {
        setShowDialog(false);
        resetForm();
        toast.success('Template created');
      }
    },
    onError: (error) => {
      toast.error('Failed to save template: ' + error.message);
    },
  });
  
  const saveDetectionRule = useMutation({
    mutationFn: async (data: {
      templateId: string;
      name: string;
      treeId: string;
      triggerPhrases: string[];
    }) => {
      // Create the detection rule with link to validation task template
      const { error } = await gateway
        .from('detection_rules')
        .insert({
          tree_id: data.treeId,
          name: data.name,
          trigger_phrases: data.triggerPhrases,
          validation_task_template_id: data.templateId,
          is_active: true,
        })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      setShowDialog(false);
      resetForm();
      toast.success('Detection rule created and linked to template');
    },
    onError: (error) => {
      toast.error('Failed to create detection rule: ' + error.message);
    },
  });
  
  const deleteTemplate = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway
        .from('validation_task_templates')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['validation-task-templates-admin'] });
      toast.success('Template deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete template: ' + error.message);
    },
  });
  
  const resetForm = () => {
    setModule('');
    setSubModule('');
    setActivity('');
    setDefaultOwner('');
    setResourcesUrl('');
    setDeploymentTypeId('');
    setEditing(null);
    // Reset detection rule form
    setDialogStep('template');
    setCreateDetectionRule(false);
    setDetectionRuleName('');
    setDetectionTreeId('');
    setTriggerPhrases('');
    setNewTemplateId(null);
  };
  
  const openDialog = (template?: ValidationTaskTemplate) => {
    if (template) {
      setEditing(template);
      setModule(template.module);
      setSubModule(template.sub_module || '');
      setActivity(template.activity);
      setDefaultOwner(template.default_owner || '');
      setResourcesUrl(template.resources_url || '');
      setDeploymentTypeId(template.deployment_type_id || '');
    } else {
      resetForm();
    }
    setShowDialog(true);
  };
  
  const handleSave = () => {
    saveTemplate.mutate({
      id: editing?.id,
      module,
      sub_module: subModule || null,
      activity,
      default_owner: defaultOwner || null,
      resources_url: resourcesUrl || null,
      deployment_type_id: deploymentTypeId || null,
    });
  };
  
  const handleSaveDetectionRule = () => {
    if (!newTemplateId || !detectionTreeId || !triggerPhrases.trim()) {
      toast.error('Please fill in required fields');
      return;
    }
    
    const phrases = triggerPhrases.split('\n').map(p => p.trim()).filter(Boolean);
    if (phrases.length === 0) {
      toast.error('At least one trigger phrase is required');
      return;
    }
    
    saveDetectionRule.mutate({
      templateId: newTemplateId,
      name: detectionRuleName,
      treeId: detectionTreeId,
      triggerPhrases: phrases,
    });
  };
  
  const handleSkipDetectionRule = () => {
    setShowDialog(false);
    resetForm();
    toast.success('Template created without detection rule');
  };
  
  const getDeploymentTypeName = (id: string | null) => {
    if (!id) return 'All';
    return deploymentTypes?.find(dt => dt.id === id)?.name || id;
  };
  
  // Group templates by module
  const groupedTemplates = templates?.reduce((acc, t) => {
    if (!acc[t.module]) acc[t.module] = [];
    acc[t.module].push(t);
    return acc;
  }, {} as Record<string, ValidationTaskTemplate[]>) || {};
  
  const moduleList = Object.keys(groupedTemplates).sort();
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-72" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-[hsl(var(--pendo-pink))]" />
              Validation Task Templates
            </CardTitle>
            <CardDescription>
              Define validation tasks that will be created for opportunities
            </CardDescription>
          </div>
          <Button onClick={() => openDialog()} variant="outline" size="sm" className="gap-2">
            <Plus className="w-4 h-4" />
            Add Template
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {templates?.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <CheckCircle2 className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No validation task templates defined yet.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {moduleList.map(moduleName => (
              <div key={moduleName}>
                <h3 className="font-semibold text-sm text-muted-foreground mb-2">{moduleName}</h3>
                <div className="rounded-lg border border-border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Sub-Module</TableHead>
                        <TableHead>Activity</TableHead>
                        <TableHead>Owner</TableHead>
                        <TableHead>Deployment</TableHead>
                        <TableHead className="w-[100px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {groupedTemplates[moduleName].map(template => (
                        <TableRow key={template.id}>
                          <TableCell className="text-sm">
                            {template.sub_module || '-'}
                          </TableCell>
                          <TableCell className="text-sm">
                            <div className="flex items-center gap-2">
                              {template.activity}
                              {template.resources_url && (
                                <a
                                  href={template.resources_url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-primary hover:underline"
                                >
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {template.default_owner || '-'}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">
                              {getDeploymentTypeName(template.deployment_type_id)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => openDialog(template)}
                                className="h-8 w-8"
                              >
                                <Edit2 className="w-3 h-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  if (confirm('Delete this template?')) {
                                    deleteTemplate.mutate(template.id);
                                  }
                                }}
                                className="h-8 w-8 text-destructive hover:text-destructive"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      
      {/* Template Dialog */}
      <Dialog open={showDialog} onOpenChange={(open) => {
        if (!open) resetForm();
        setShowDialog(open);
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editing ? 'Edit Template' : dialogStep === 'template' ? 'Add Template' : 'Configure Detection Rule'}
            </DialogTitle>
            <DialogDescription>
              {dialogStep === 'template' 
                ? 'Define a validation task that can be assigned to opportunities.'
                : 'Configure a detection rule to auto-activate this task from transcripts.'}
            </DialogDescription>
          </DialogHeader>
          
          {dialogStep === 'template' ? (
            <>
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Module</Label>
                    <Input
                      value={module}
                      onChange={(e) => setModule(e.target.value)}
                      placeholder="e.g., Snippet Deployment"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Sub-Module (optional)</Label>
                    <Input
                      value={subModule}
                      onChange={(e) => setSubModule(e.target.value)}
                      placeholder="e.g., Core Setup"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Activity</Label>
                  <Input
                    value={activity}
                    onChange={(e) => setActivity(e.target.value)}
                    placeholder="e.g., Install snippet on staging environment"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Default Owner (optional)</Label>
                    <Input
                      value={defaultOwner}
                      onChange={(e) => setDefaultOwner(e.target.value)}
                      placeholder="e.g., SC"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Deployment Type</Label>
                    <Select value={deploymentTypeId} onValueChange={setDeploymentTypeId}>
                      <SelectTrigger>
                        <SelectValue placeholder="All deployments" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All deployments</SelectItem>
                        {deploymentTypes?.map(dt => (
                          <SelectItem key={dt.id} value={dt.id}>{dt.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Resources URL (optional)</Label>
                  <Input
                    value={resourcesUrl}
                    onChange={(e) => setResourcesUrl(e.target.value)}
                    placeholder="https://..."
                  />
                </div>
                {!editing && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 border border-border">
                    <input
                      type="checkbox"
                      checked={createDetectionRule}
                      onChange={(e) => setCreateDetectionRule(e.target.checked)}
                      className="rounded border-border"
                      id="create-detection-rule-validation"
                    />
                    <Label htmlFor="create-detection-rule-validation" className="text-sm cursor-pointer flex items-center gap-2">
                      <Zap className="w-4 h-4" />
                      Create detection rule to auto-activate from transcripts
                    </Label>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowDialog(false)}>Cancel</Button>
                <Button 
                  onClick={handleSave} 
                  disabled={!module.trim() || !activity.trim() || saveTemplate.isPending}
                >
                  {saveTemplate.isPending ? 'Saving...' : editing ? 'Save' : createDetectionRule ? 'Next' : 'Save'}
                </Button>
              </DialogFooter>
            </>
          ) : (
            <>
              <div className="space-y-4 py-4">
                <div className="p-3 rounded-lg bg-primary/10 border border-primary/20 text-sm">
                  <span className="font-medium">Task:</span> {activity}
                </div>
                
                <div className="space-y-2">
                  <Label>Detection Rule Name</Label>
                  <Input
                    value={detectionRuleName}
                    onChange={(e) => setDetectionRuleName(e.target.value)}
                    placeholder="e.g., Snippet Install Detection"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Detection Tree *</Label>
                  <Select value={detectionTreeId} onValueChange={setDetectionTreeId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a detection tree..." />
                    </SelectTrigger>
                    <SelectContent>
                      {detectionTrees?.map(tree => (
                        <SelectItem key={tree.id} value={tree.id}>{tree.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Trigger Phrases * (one per line)</Label>
                  <Textarea
                    value={triggerPhrases}
                    onChange={(e) => setTriggerPhrases(e.target.value)}
                    placeholder="snippet is installed&#10;we've deployed the code&#10;staging environment ready"
                    className="min-h-[100px] font-mono text-sm"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={handleSkipDetectionRule}>Skip</Button>
                <Button 
                  onClick={handleSaveDetectionRule} 
                  disabled={!detectionTreeId || !triggerPhrases.trim() || saveDetectionRule.isPending}
                >
                  {saveDetectionRule.isPending ? 'Creating...' : 'Create Rule'}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}

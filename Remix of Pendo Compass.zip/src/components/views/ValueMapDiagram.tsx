import { useMemo, useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { ZoomIn, ZoomOut, Maximize2, Move } from 'lucide-react';
import { useValueMapData } from '@/hooks/useValueMapData';
import { cn } from '@/lib/utils';
import pendoLogo from '@/assets/pendo-logo.png';

interface ValueMapDiagramProps {
  accountId: string;
  opportunityId?: string;
}

const STATUS_COLORS = {
  accepted: { fill: '#10b981', stroke: '#059669', label: 'In Deal' },
  validated: { fill: '#3b82f6', stroke: '#2563eb', label: 'Validated' },
  proposed: { fill: '#f59e0b', stroke: '#d97706', label: 'Proposed' },
  whitespace: { fill: '#94a3b8', stroke: '#64748b', label: 'Whitespace' },
};

function StatusLegend() {
  return (
    <div className="absolute bottom-4 left-4 bg-background/95 backdrop-blur-sm rounded-lg p-3 border shadow-lg z-20">
      <p className="text-xs font-medium text-muted-foreground mb-2">Status Legend</p>
      <div className="flex flex-col gap-1.5">
        {Object.entries(STATUS_COLORS).map(([key, config]) => (
          <div key={key} className="flex items-center gap-2">
            <div className="w-3 h-3 rounded border" style={{ backgroundColor: config.fill, borderColor: config.stroke }} />
            <span className="text-[10px]">{config.label}</span>
          </div>
        ))}
      </div>
      <div className="mt-2 pt-2 border-t">
        <p className="text-[10px] font-medium text-muted-foreground mb-1">Data Flow</p>
        <div className="flex flex-col gap-0.5">
          <div className="flex items-center gap-1.5">
            <div className="w-4 h-0.5 bg-emerald-500 rounded" />
            <span className="text-[10px]">Input to Pendo</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-4 h-0.5 bg-violet-500 rounded" />
            <span className="text-[10px]">Output from Pendo</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// Simple straight horizontal line with label
function DataFlowLine({ 
  x1, y, x2, label, color, labelOffset = 0
}: { 
  x1: number; y: number; x2: number; label: string; color: string; labelOffset?: number;
}) {
  const midX = (x1 + x2) / 2;
  
  return (
    <g>
      {/* Line */}
      <line
        x1={x1}
        y1={y}
        x2={x2 - 6}
        y2={y}
        stroke={color}
        strokeWidth={2}
        markerEnd={`url(#arrow-${color.replace('#', '')})`}
      />
      {/* Arrow dot at start */}
      <circle cx={x1} cy={y} r={3} fill={color} />
      {/* Label */}
      <g transform={`translate(${midX}, ${y + labelOffset - 8})`}>
        <rect
          x={-label.length * 2.8 - 4}
          y={-7}
          width={label.length * 5.6 + 8}
          height={14}
          rx={3}
          fill="hsl(var(--background))"
          stroke={color}
          strokeWidth={1}
        />
        <text
          textAnchor="middle"
          dominantBaseline="middle"
          fill={color}
          fontSize={8}
          fontWeight={600}
        >
          {label}
        </text>
      </g>
    </g>
  );
}

// Data flow labels
const INPUT_LABELS = ['User Data', 'Contacts', 'Events', 'Metrics', 'Tickets', 'Segments', 'Analytics', 'Config'];
const OUTPUT_LABELS = ['Guides', 'Analytics', 'Insights', 'Tooltips', 'Surveys', 'Reports', 'Alerts', 'Tracking'];

export function ValueMapDiagram({ accountId, opportunityId }: ValueMapDiagramProps) {
  const { data, isLoading } = useValueMapData(accountId, opportunityId);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const dragStart = useRef({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0) {
      setIsDragging(true);
      dragStart.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPan({ x: e.clientX - dragStart.current.x, y: e.clientY - dragStart.current.y });
    }
  };

  const handleMouseUp = () => setIsDragging(false);

  const diagramData = useMemo(() => {
    if (!data) return null;

    const { pendoModules, technologies } = data;
    
    // Canvas - wider for horizontal flow
    const canvasWidth = 1200;
    const canvasHeight = 600;
    
    // Row configuration - each row has: left tech, module, right tech at same Y
    const rowHeight = 55;
    const startY = 80;
    const maxRows = 8;
    
    // Column positions
    const leftTechX = 30;
    const leftTechWidth = 120;
    
    const hubX = 280;
    const hubWidth = 360;
    const moduleX = hubX + 80;
    const moduleWidth = 90;
    
    const rightTechX = hubX + hubWidth + 130;
    const rightTechWidth = 120;

    // Split technologies
    const leftTechs = technologies.filter(t => 
      ['ops', 'growth', 'business', 'crm', 'erp'].some(k => 
        (t.layer?.toLowerCase() || '').includes(k) || (t.category?.toLowerCase() || '').includes(k)
      )
    );
    
    const rightTechs = technologies.filter(t => 
      ['host', 'build', 'adopt', 'web', 'mobile', 'frontend'].some(k => 
        (t.layer?.toLowerCase() || '').includes(k) || (t.category?.toLowerCase() || '').includes(k)
      )
    );

    // Fallback: split evenly if no categorization
    const allTechs = technologies;
    const finalLeft = leftTechs.length > 0 ? leftTechs : allTechs.slice(0, Math.ceil(allTechs.length / 2));
    const finalRight = rightTechs.length > 0 ? rightTechs : allTechs.slice(Math.ceil(allTechs.length / 2));

    // Create aligned rows
    const numRows = Math.min(maxRows, Math.max(pendoModules.length, finalLeft.length, finalRight.length));
    
    const rows = Array.from({ length: numRows }, (_, i) => {
      const y = startY + i * rowHeight;
      const leftTech = finalLeft[i] || null;
      const module = pendoModules[i] || null;
      const rightTech = finalRight[i] || null;
      
      return { y, leftTech, module, rightTech, index: i };
    });

    const hubHeight = numRows * rowHeight + 60;

    return {
      canvasWidth,
      canvasHeight,
      hubX,
      hubWidth,
      hubHeight,
      moduleX,
      moduleWidth,
      leftTechX,
      leftTechWidth,
      rightTechX,
      rightTechWidth,
      rows,
      startY,
      rowHeight,
    };
  }, [data]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[600px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!data || data.pendoModules.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[600px] text-muted-foreground">
        <p className="text-lg font-medium mb-2">No Value Map Data</p>
        <p className="text-sm">Add use cases or configure modules to see the diagram.</p>
      </div>
    );
  }

  if (!diagramData) return null;

  const {
    canvasWidth, canvasHeight,
    hubX, hubWidth, hubHeight,
    moduleX, moduleWidth,
    leftTechX, leftTechWidth,
    rightTechX, rightTechWidth,
    rows, startY,
  } = diagramData;

  const nodeHeight = 36;

  return (
    <div className="relative h-[600px] bg-muted/30 rounded-lg border overflow-hidden">
      {/* Controls */}
      <div className="absolute top-3 right-3 z-20 flex items-center gap-1 bg-background/95 backdrop-blur-sm rounded-md p-1 border shadow">
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setZoom(z => Math.max(0.5, z - 0.1))}>
          <ZoomOut className="h-3.5 w-3.5" />
        </Button>
        <span className="text-[10px] w-10 text-center">{Math.round(zoom * 100)}%</span>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setZoom(z => Math.min(1.5, z + 0.1))}>
          <ZoomIn className="h-3.5 w-3.5" />
        </Button>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}>
          <Maximize2 className="h-3.5 w-3.5" />
        </Button>
      </div>

      {/* Stats */}
      <div className="absolute top-3 left-3 z-20 flex items-center gap-2 bg-background/95 backdrop-blur-sm rounded-md px-2.5 py-1.5 border shadow">
        <div className="text-center">
          <p className="text-lg font-bold text-primary leading-none">{data.stats.coveragePercent}%</p>
          <p className="text-[9px] text-muted-foreground">Coverage</p>
        </div>
        <div className="h-6 w-px bg-border" />
        <div className="flex items-center gap-1.5">
          {[
            { color: STATUS_COLORS.accepted.fill, count: data.stats.acceptedCount },
            { color: STATUS_COLORS.validated.fill, count: data.stats.validatedCount },
            { color: STATUS_COLORS.proposed.fill, count: data.stats.proposedCount },
            { color: STATUS_COLORS.whitespace.fill, count: data.stats.whitespaceCount },
          ].map((s, i) => (
            <div key={i} className="flex items-center gap-0.5">
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />
              <span className="text-[10px] font-medium">{s.count}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="absolute bottom-3 right-3 z-20 flex items-center gap-1 text-[10px] text-muted-foreground bg-background/80 px-1.5 py-0.5 rounded">
        <Move className="h-2.5 w-2.5" />
        <span>Drag to pan</span>
      </div>

      <StatusLegend />

      <svg
        ref={svgRef}
        width="100%"
        height="100%"
        viewBox={`0 0 ${canvasWidth} ${canvasHeight}`}
        className={cn('select-none', isDragging ? 'cursor-grabbing' : 'cursor-grab')}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <defs>
          <marker id="arrow-10b981" markerWidth="6" markerHeight="5" refX="5" refY="2.5" orient="auto">
            <polygon points="0 0, 6 2.5, 0 5" fill="#10b981" />
          </marker>
          <marker id="arrow-8b5cf6" markerWidth="6" markerHeight="5" refX="5" refY="2.5" orient="auto">
            <polygon points="0 0, 6 2.5, 0 5" fill="#8b5cf6" />
          </marker>
        </defs>

        <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
          {/* Left zone label */}
          <text x={leftTechX + leftTechWidth / 2} y={startY - 30} textAnchor="middle" fontSize={12} fontWeight={700} fill="hsl(var(--foreground))">
            Back Office Systems
          </text>
          <text x={leftTechX + leftTechWidth / 2} y={startY - 16} textAnchor="middle" fontSize={9} fill="hsl(var(--muted-foreground))">
            Data Sources
          </text>

          {/* Right zone label */}
          <text x={rightTechX + rightTechWidth / 2} y={startY - 30} textAnchor="middle" fontSize={12} fontWeight={700} fill="hsl(var(--foreground))">
            End User Apps
          </text>
          <text x={rightTechX + rightTechWidth / 2} y={startY - 16} textAnchor="middle" fontSize={9} fill="hsl(var(--muted-foreground))">
            Delivery Points
          </text>

          {/* Pendo Hub background */}
          <rect
            x={hubX}
            y={startY - 50}
            width={hubWidth}
            height={hubHeight}
            rx={12}
            fill="hsl(var(--card))"
            stroke="hsl(var(--primary))"
            strokeWidth={2}
            style={{ filter: 'drop-shadow(0 2px 8px rgba(0,0,0,0.06))' }}
          />
          {/* Hub header */}
          <rect x={hubX} y={startY - 50} width={hubWidth} height={40} rx={12} fill="hsl(var(--primary))" />
          <rect x={hubX} y={startY - 22} width={hubWidth} height={12} fill="hsl(var(--primary))" />
          <image href={pendoLogo} x={hubX + hubWidth / 2 - 35} y={startY - 44} width={70} height={22} />

          {/* Draw each row */}
          {rows.map(({ y, leftTech, module, rightTech, index }) => {
            const nodeY = y + 10;
            const centerY = nodeY + nodeHeight / 2;

            return (
              <g key={index}>
                {/* Left tech node */}
                {leftTech && (
                  <g
                    transform={`translate(${leftTechX}, ${nodeY})`}
                    onMouseEnter={() => setHoveredNode(leftTech.id)}
                    onMouseLeave={() => setHoveredNode(null)}
                    style={{ cursor: 'pointer' }}
                  >
                    <rect
                      width={leftTechWidth}
                      height={nodeHeight}
                      rx={6}
                      fill="hsl(var(--card))"
                      stroke={hoveredNode === leftTech.id ? '#10b981' : 'hsl(var(--border))'}
                      strokeWidth={hoveredNode === leftTech.id ? 2 : 1}
                    />
                    <circle cx={leftTechWidth} cy={nodeHeight / 2} r={4} fill="#10b981" />
                    <text x={leftTechWidth / 2} y={nodeHeight / 2 + 1} textAnchor="middle" dominantBaseline="middle" fontSize={10} fontWeight={500} fill="hsl(var(--foreground))">
                      {leftTech.name.length > 14 ? leftTech.name.slice(0, 12) + '...' : leftTech.name}
                    </text>
                  </g>
                )}

                {/* Connection: left tech -> module */}
                {leftTech && module && (
                  <DataFlowLine
                    x1={leftTechX + leftTechWidth + 4}
                    y={centerY}
                    x2={moduleX}
                    label={INPUT_LABELS[index % INPUT_LABELS.length]}
                    color="#10b981"
                    labelOffset={index % 2 === 0 ? -2 : 2}
                  />
                )}

                {/* Module node */}
                {module && (
                  <g
                    transform={`translate(${moduleX}, ${nodeY})`}
                    onMouseEnter={() => setHoveredNode(module.id)}
                    onMouseLeave={() => setHoveredNode(null)}
                    style={{ cursor: 'pointer' }}
                  >
                    <rect
                      width={moduleWidth}
                      height={nodeHeight}
                      rx={6}
                      fill={STATUS_COLORS[module.status].fill}
                      stroke={STATUS_COLORS[module.status].stroke}
                      strokeWidth={hoveredNode === module.id ? 2.5 : 1.5}
                      opacity={module.status === 'whitespace' ? 0.5 : 1}
                    />
                    {/* Input anchor */}
                    <circle cx={0} cy={nodeHeight / 2} r={3} fill={STATUS_COLORS[module.status].stroke} />
                    {/* Output anchor */}
                    <circle cx={moduleWidth} cy={nodeHeight / 2} r={3} fill={STATUS_COLORS[module.status].stroke} />
                    <text x={moduleWidth / 2} y={nodeHeight / 2 + 1} textAnchor="middle" dominantBaseline="middle" fontSize={9} fontWeight={600} fill="white">
                      {module.name}
                    </text>
                  </g>
                )}

                {/* Connection: module -> right tech */}
                {module && rightTech && (
                  <DataFlowLine
                    x1={moduleX + moduleWidth + 4}
                    y={centerY}
                    x2={rightTechX}
                    label={OUTPUT_LABELS[index % OUTPUT_LABELS.length]}
                    color="#8b5cf6"
                    labelOffset={index % 2 === 0 ? 2 : -2}
                  />
                )}

                {/* Right tech node */}
                {rightTech && (
                  <g
                    transform={`translate(${rightTechX}, ${nodeY})`}
                    onMouseEnter={() => setHoveredNode(rightTech.id)}
                    onMouseLeave={() => setHoveredNode(null)}
                    style={{ cursor: 'pointer' }}
                  >
                    <circle cx={0} cy={nodeHeight / 2} r={4} fill="#8b5cf6" />
                    <rect
                      width={rightTechWidth}
                      height={nodeHeight}
                      rx={6}
                      fill="hsl(var(--card))"
                      stroke={hoveredNode === rightTech.id ? '#8b5cf6' : 'hsl(var(--border))'}
                      strokeWidth={hoveredNode === rightTech.id ? 2 : 1}
                    />
                    <text x={rightTechWidth / 2} y={nodeHeight / 2 + 1} textAnchor="middle" dominantBaseline="middle" fontSize={10} fontWeight={500} fill="hsl(var(--foreground))">
                      {rightTech.name.length > 14 ? rightTech.name.slice(0, 12) + '...' : rightTech.name}
                    </text>
                  </g>
                )}
              </g>
            );
          })}

          {/* Hub footer */}
          <text x={hubX + hubWidth / 2} y={startY + hubHeight - 70} textAnchor="middle" fontSize={10} fill="hsl(var(--muted-foreground))">
            Digital Adoption Platform
          </text>
        </g>
      </svg>
    </div>
  );
}

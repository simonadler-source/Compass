import { createContext, useContext, useEffect, useState, useCallback, useRef, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const SESSION_TIMEOUT_MS = 60 * 60 * 1000; // 1 hour in milliseconds
const SESSION_TOKEN_KEY = 'auth_session_token';
const AUTH_REQUEST_TIMEOUT_MS = 15000;

function withTimeout<T>(promise: Promise<T>, ms: number, message: string): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => {
      const id = setTimeout(() => {
        clearTimeout(id);
        reject(new Error(message));
      }, ms);
    }),
  ]);
}

function tryParseEdgeFunctionPayload(message: string): { message?: string; code?: string } | null {
  const start = message.indexOf('{');
  const end = message.lastIndexOf('}');
  if (start === -1 || end === -1 || end <= start) return null;
  const candidate = message.slice(start, end + 1);
  try {
    const parsed = JSON.parse(candidate);
    if (parsed && typeof parsed === 'object') {
      return {
        message: parsed.error ?? parsed.message ?? undefined,
        code: parsed.code ?? undefined,
      };
    }
  } catch {
    // ignore
  }
  return null;
}

type ProfileStatus = 'pending' | 'active' | 'suspended' | null;

export interface CustomUser {
  id: string;
  email: string;
  full_name: string | null;
  mfa_enabled: boolean;
  auth_provider: string;
}

export interface ImpersonatedUser {
  id: string;
  email: string;
  full_name: string | null;
  roles: string[];
}

interface AuthContextType {
  user: CustomUser | null;
  loading: boolean;
  profileStatus: ProfileStatus;
  profileStatusLoading: boolean;
  tempPassword: boolean;
  signIn: (
    email: string,
    password: string,
    totpCode?: string
  ) => Promise<{ requirePasswordChange?: boolean; requireMfa?: boolean }>;
  signOut: () => Promise<void>;
  resetActivityTimer: () => void;
  getSessionToken: () => string | null;
  updateMfaStatus: (enabled: boolean) => void;
  // Impersonation
  impersonatedUser: ImpersonatedUser | null;
  isImpersonating: boolean;
  startImpersonating: (user: ImpersonatedUser) => void;
  stopImpersonating: () => void;
  effectiveUserId: string | null; // The user ID to use for queries (impersonated or real)
  effectiveUserEmail: string | null; // The user email to use for queries (impersonated or real)
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<CustomUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [profileStatus, setProfileStatus] = useState<ProfileStatus>(null);
  const [profileStatusLoading, setProfileStatusLoading] = useState(true);
  const [tempPassword, setTempPassword] = useState(false);
  const [impersonatedUser, setImpersonatedUser] = useState<ImpersonatedUser | null>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastActivityRef = useRef<number>(Date.now());

  // Impersonation functions
  const startImpersonating = useCallback((targetUser: ImpersonatedUser) => {
    setImpersonatedUser(targetUser);
    toast.info(`Now viewing as ${targetUser.email}`);
  }, []);

  const stopImpersonating = useCallback(() => {
    setImpersonatedUser(null);
    toast.info('Stopped impersonating');
  }, []);

  const isImpersonating = impersonatedUser !== null;
  const effectiveUserId = impersonatedUser?.id ?? user?.id ?? null;
  const effectiveUserEmail = impersonatedUser?.email ?? user?.email ?? null;

  const updateMfaStatus = useCallback((enabled: boolean) => {
    setUser(prev => prev ? { ...prev, mfa_enabled: enabled } : null);
  }, []);

  const getSessionToken = useCallback(() => {
    return localStorage.getItem(SESSION_TOKEN_KEY);
  }, []);

  const setSessionToken = useCallback((token: string | null) => {
    if (token) {
      localStorage.setItem(SESSION_TOKEN_KEY, token);
    } else {
      localStorage.removeItem(SESSION_TOKEN_KEY);
    }
  }, []);

  const handleSignOut = useCallback(async (showMessage = true) => {
    try {
      const token = getSessionToken();
      if (token) {
        await supabase.functions.invoke('auth', {
          body: { action: 'logout' },
          headers: { Authorization: `Bearer ${token}` }
        });
      }
      setSessionToken(null);
      setUser(null);
      setProfileStatus(null);
      setTempPassword(false);
      if (showMessage) {
        toast.info('Session expired due to inactivity. Please sign in again.');
      }
    } catch (error) {
      console.error('Sign out error:', error);
    }
  }, [getSessionToken, setSessionToken]);

  const resetActivityTimer = useCallback(() => {
    lastActivityRef.current = Date.now();
    
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    if (user) {
      timeoutRef.current = setTimeout(() => {
        handleSignOut(true);
      }, SESSION_TIMEOUT_MS);
    }
  }, [user, handleSignOut]);

  // Clear invalid session state helper
  const clearSession = useCallback(() => {
    setSessionToken(null);
    setUser(null);
    setProfileStatus(null);
    setTempPassword(false);
  }, [setSessionToken]);

  // Validate existing session on mount
  const validateSession = useCallback(async () => {
    const token = getSessionToken();
    if (!token) {
      setLoading(false);
      setProfileStatusLoading(false);
      return;
    }

    try {
      let data: any = null;
      let error: any = null;
      const MAX_VALIDATE_ATTEMPTS = 3;

      for (let attempt = 0; attempt < MAX_VALIDATE_ATTEMPTS; attempt++) {
        const result = await withTimeout(
          supabase.functions.invoke('auth', {
            body: { action: 'validate-session' },
            headers: { Authorization: `Bearer ${token}` },
          }),
          AUTH_REQUEST_TIMEOUT_MS,
          'Session check timed out. Please refresh and try again.'
        );
        data = result.data;
        error = result.error;

        // Check for transient/503 errors - retry
        const errorMsg = error?.message ?? '';
        const isTransient = errorMsg.includes('503') || errorMsg.includes('service unavailable') ||
          errorMsg.includes('Service Unavailable') || errorMsg.includes('boot') ||
          data?.code === 'SERVICE_UNAVAILABLE';
        if (isTransient && attempt < MAX_VALIDATE_ATTEMPTS - 1) {
          console.warn(`[Auth] Session validation transient error (attempt ${attempt + 1}), retrying...`);
          await new Promise(r => setTimeout(r, (attempt + 1) * 1500));
          continue;
        }
        break;
      }

      // Handle edge function errors (including 401 unauthorized)
      if (error) {
        // 401/invalid session is expected for expired tokens - handle silently
        const errorMsg = error?.message ?? '';
        const is401 = errorMsg.includes('401') || errorMsg.includes('Invalid or expired session') || errorMsg.includes('Unauthorized');
        if (!is401) {
          console.error('Session validation error:', error);
        }
        clearSession();
        setLoading(false);
        setProfileStatusLoading(false);
        return;
      }

      if (!data?.success) {
        // Invalid session response - clear and show login
        clearSession();
      } else {
        const u = data.user;
        setUser({
          id: u.id,
          email: u.email,
          full_name: u.fullName ?? u.full_name ?? null,
          mfa_enabled: Boolean(u.mfaEnabled ?? u.mfa_enabled),
          auth_provider: u.authProvider ?? u.auth_provider ?? 'email',
        });
        setProfileStatus((u.status ?? null) as ProfileStatus);
        setTempPassword(Boolean(u.tempPassword ?? u.temp_password ?? false));
        resetActivityTimer();
      }
    } catch (error: any) {
      // Timeout or network errors - clear session silently for timeout, log others
      const isTimeout = error?.message?.includes('timed out');
      if (!isTimeout) {
        console.error('Session validation error:', error);
      }
      clearSession();
    } finally {
      setLoading(false);
      setProfileStatusLoading(false);
    }
  }, [getSessionToken, clearSession, resetActivityTimer]);

  useEffect(() => {
    // Prevent the built-in auth client from retrying stale refresh tokens forever.
    // This app uses our custom session token (SESSION_TOKEN_KEY) instead.
    try {
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      if (projectId) {
        localStorage.removeItem(`sb-${projectId}-auth-token`);
      }
    } catch {
      // ignore
    }

    // Only validate session once on mount
    validateSession();

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Empty dependency - only run on mount

  // Activity listeners for session timeout
  useEffect(() => {
    if (!user) return;

    const activityEvents = ['mousedown', 'keydown', 'scroll', 'touchstart', 'mousemove'];
    
    const handleActivity = () => {
      const now = Date.now();
      // Throttle activity updates to avoid excessive timer resets
      if (now - lastActivityRef.current > 60000) { // Only reset if >1 min since last activity
        resetActivityTimer();
      }
    };

    activityEvents.forEach(event => {
      window.addEventListener(event, handleActivity, { passive: true });
    });

    return () => {
      activityEvents.forEach(event => {
        window.removeEventListener(event, handleActivity);
      });
    };
  }, [user, resetActivityTimer]);

  const signIn = async (
    email: string,
    password: string,
    totpCode?: string
  ): Promise<{ requirePasswordChange?: boolean; requireMfa?: boolean }> => {
    const normalizedEmail = email.trim().toLowerCase();

    let data: any;
    let error: any;
    
    try {
      const result = await withTimeout(
        supabase.functions.invoke('auth', {
          body: { action: 'login', email: normalizedEmail, password, ...(totpCode ? { totpCode } : {}) },
        }),
        AUTH_REQUEST_TIMEOUT_MS,
        'Login timed out. Please check your network and try again.'
      );
      data = result.data;
      error = result.error;
    } catch (timeoutErr: any) {
      throw new Error(timeoutErr?.message || 'Login timed out. Please try again.');
    }

    if (error) {
      const parsed = typeof error?.message === 'string' ? tryParseEdgeFunctionPayload(error.message) : null;
      if (parsed?.code === 'SERVICE_UNAVAILABLE') {
        throw new Error(parsed.message || 'Service temporarily unavailable. Please try again in a moment.');
      }
      throw new Error(parsed?.message || error.message || 'Login failed');
    }

    // Handle service unavailable (backend timeout)
    if (data?.code === 'SERVICE_UNAVAILABLE') {
      throw new Error(data?.error || 'Service temporarily unavailable. Please try again in a moment.');
    }

    if (data?.requiresMfa) {
      return { requireMfa: true };
    }

    if (!data?.success) {
      throw new Error(data?.error || data?.message || 'Login failed');
    }

    const token = data.session?.token ?? data.token ?? null;
    if (!token) {
      throw new Error('Login succeeded but no session token was returned.');
    }

    setSessionToken(token);

    const u = data.user;
    setUser({
      id: u.id,
      email: u.email,
      full_name: u.fullName ?? u.full_name ?? null,
      mfa_enabled: Boolean(u.mfaEnabled ?? u.mfa_enabled),
      auth_provider: u.authProvider ?? u.auth_provider ?? 'email',
    });
    setProfileStatus((u.status ?? null) as ProfileStatus);
    setTempPassword(Boolean(u.tempPassword ?? u.temp_password ?? false));
    resetActivityTimer();

    return { requirePasswordChange: Boolean(u.tempPassword ?? u.temp_password) };
  };

  const signOut = async () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    const token = getSessionToken();
    if (token) {
      try {
        await supabase.functions.invoke('auth', {
          body: { action: 'logout' },
          headers: { Authorization: `Bearer ${token}` }
        });
      } catch (error) {
        console.error('Logout error:', error);
      }
    }
    
    setSessionToken(null);
    setUser(null);
    setProfileStatus(null);
    setTempPassword(false);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading, 
      profileStatus, 
      profileStatusLoading, 
      tempPassword,
      signIn, 
      signOut, 
      resetActivityTimer,
      getSessionToken,
      updateMfaStatus,
      // Impersonation
      impersonatedUser,
      isImpersonating,
      startImpersonating,
      stopImpersonating,
      effectiveUserId,
      effectiveUserEmail,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

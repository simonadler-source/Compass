import { useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Sparkles,
  Plus,
  Download,
  Loader2,
  ClipboardCopy,
  Trash2,
  Calendar,
  Users,
  FileText,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

import type { MeetingImportController } from "@/features/momentum/import/useMeetingImport";

export function ImportMeetingDialog({ controller }: { controller: MeetingImportController }) {
  const { meeting, accounts, suggestedAccount, isImporting } = controller;

  // Prevent accidental navigation/tab close during import
  useEffect(() => {
    if (!isImporting) return;
    
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = 'Import in progress. Are you sure you want to leave?';
      return e.returnValue;
    };
    
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isImporting]);

  const copyDiagnostics = async () => {
    const payload = {
      meeting: meeting
        ? {
            id: meeting.id,
            title: meeting.title,
            start_time: meeting.start_time,
            status: meeting.status,
            host_email: meeting.host_email,
            host_name: meeting.host_name,
            salesforce_account_id: meeting.salesforce_account_id,
            attendees: meeting.attendees?.length ?? 0,
            transcript_chars: meeting.transcript_content?.length ?? 0,
          }
        : null,
      state: {
        isOpen: controller.isOpen,
        isImporting: controller.isImporting,
        importStage: controller.importStage,
        importProgress: controller.importProgress,
        derivedAccountName: controller.derivedAccountName,
        derivedAccountReason: controller.derivedAccountReason,
        selectedAccountId: controller.selectedAccountId,
        createNewAccount: controller.createNewAccount,
        newAccountName: controller.newAccountName,
        canImport: controller.canImport,
        lastError: controller.lastError,
        matchCandidates: controller.matchCandidates,
      },
      events: controller.events,
    };

    try {
      await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
      toast.success("Diagnostics copied to clipboard");
    } catch {
      toast.error("Could not copy diagnostics (clipboard blocked)");
    }
  };

  const transcriptChars = meeting?.transcript_content?.length ?? 0;

  return (
    <Dialog 
      open={controller.isOpen} 
      onOpenChange={(open) => {
        // Prevent closing during import
        if (isImporting) return;
        if (!open) controller.close();
      }}
    >
      <DialogContent 
        className="max-w-2xl"
        onInteractOutside={(e) => {
          // Prevent closing when clicking outside during import
          if (isImporting) e.preventDefault();
        }}
        onEscapeKeyDown={(e) => {
          // Prevent closing with Escape during import
          if (isImporting) e.preventDefault();
        }}
      >
        <DialogHeader>
          <DialogTitle>Import Meeting: {meeting?.title}</DialogTitle>
        </DialogHeader>

        {/* Step-by-step progress */}
        {(controller.isImporting || controller.importProgress > 0) && (
          <div className="rounded-lg border bg-muted/30 p-3">
            <div className="flex items-center justify-between gap-3">
              <p className="text-sm font-medium text-foreground">
                {controller.importStage || "Working…"}
              </p>
              <span className="text-xs text-muted-foreground">{Math.round(controller.importProgress)}%</span>
            </div>
            <Progress value={controller.importProgress} className="mt-2" />
          </div>
        )}

        {controller.lastError && (
          <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-3">
            <p className="text-sm font-medium">Last error</p>
            <p className="text-xs text-muted-foreground mt-1 break-words">{controller.lastError}</p>
          </div>
        )}

        {/* Basic details first (so it never feels like "nothing happened") */}
        <div className="rounded-lg border bg-card p-3">
          <p className="text-sm font-medium">Meeting details</p>
          <div className="mt-2 grid gap-2 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>
                {meeting ? format(new Date(meeting.start_time), "MMM d, yyyy • h:mm a") : "—"}
              </span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <User className="h-4 w-4" />
              <span>{meeting?.host_name || meeting?.host_email || "Unknown host"}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{meeting?.attendees?.length ?? 0} attendees</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <FileText className="h-4 w-4" />
              <span>
                Transcript: {transcriptChars > 0 ? `${transcriptChars.toLocaleString()} characters` : "missing"}
              </span>
            </div>
          </div>
        </div>

        {/* Diagnostics (click trail) */}
        <div className="rounded-lg border bg-card p-3">
          <div className="flex items-start justify-between gap-3">
            <div className="space-y-1">
              <p className="text-sm font-medium">Diagnostics</p>
              <p className="text-xs text-muted-foreground">
                This panel records every click + backend step so we can see exactly where it stops.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button type="button" variant="outline" size="sm" onClick={copyDiagnostics}>
                <ClipboardCopy className="h-4 w-4 mr-1" />
                Copy
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={controller.clearDiagnostics}
                disabled={controller.isImporting}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Clear
              </Button>
            </div>
          </div>

          <div className="mt-3 grid gap-2">
            <div className="text-xs text-muted-foreground">
              <span className="font-medium text-foreground">derived:</span>{" "}
              {controller.derivedAccountName || "(none)"}
              {controller.derivedAccountReason ? (
                <span className="text-muted-foreground"> — {controller.derivedAccountReason}</span>
              ) : null}
            </div>

            {controller.matchCandidates.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {controller.matchCandidates.map((c) => (
                  <button
                    key={c.account.id}
                    type="button"
                    className="text-left"
                    onClick={() => {
                      controller.setCreateNewAccount(false);
                      controller.setSelectedAccountId(c.account.id);
                      toast.message(`Selected: ${c.account.name}`, { duration: 1200 });
                    }}
                  >
                    <Badge variant="secondary" className="cursor-pointer">
                      {c.account.name}
                      <span className="ml-2 text-xs text-muted-foreground">({c.reason})</span>
                    </Badge>
                  </button>
                ))}
              </div>
            )}

            <ScrollArea className="h-28 rounded-md border bg-muted/20 p-2">
              <div className="space-y-1">
                {controller.events.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No events yet.</p>
                ) : (
                  controller.events
                    .slice(-50)
                    .map((e, idx) => (
                      <div key={`${e.at}-${idx}`} className="text-xs">
                        <span className="text-muted-foreground">{new Date(e.at).toLocaleTimeString()} </span>
                        <span className={e.level === "error" ? "text-destructive" : "text-foreground"}>
                          {e.stage}
                        </span>
                        {e.detail ? <span className="text-muted-foreground"> — {e.detail}</span> : null}
                      </div>
                    ))
                )}
              </div>
            </ScrollArea>
          </div>
        </div>

        <div className="space-y-4">
          {suggestedAccount?.kind === "account" && (
            <div className="flex items-center gap-2 p-3 bg-primary/10 rounded-lg border border-primary/20">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm">
                <strong>Suggested match:</strong> {suggestedAccount.account.name}
                <span className="text-muted-foreground ml-1">({suggestedAccount.reason})</span>
              </span>
            </div>
          )}

          <div>
            <label className="text-sm font-medium">Select Account</label>
            <Select
              value={controller.createNewAccount ? "__new__" : controller.selectedAccountId}
              onValueChange={(val) => {
                if (val === "__new__") {
                  controller.setCreateNewAccount(true);
                  controller.setSelectedAccountId("");
                  if (controller.derivedAccountName) controller.setNewAccountName(controller.derivedAccountName);
                } else {
                  controller.setCreateNewAccount(false);
                  controller.setSelectedAccountId(val);
                }
              }}
            >
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Choose an account..." />
              </SelectTrigger>
              <SelectContent>
                {accounts?.map((account) => (
                  <SelectItem key={account.id} value={account.id}>
                    {account.name}
                    {suggestedAccount?.kind === "account" && suggestedAccount.account.id === account.id && (
                      <span className="ml-2 text-primary">★ Suggested</span>
                    )}
                  </SelectItem>
                ))}
                <SelectSeparator />
                <SelectItem value="__new__" className="text-primary">
                  <span className="flex items-center gap-1">
                    <Plus className="h-3 w-3" />
                    Create new account
                  </span>
                </SelectItem>
              </SelectContent>
            </Select>

            {!controller.canImport && meeting && (
              <p className="text-xs text-muted-foreground mt-1">
                {controller.createNewAccount
                  ? "Enter a new account name to enable Import."
                  : "Select an account (or create one) to enable Import."}
              </p>
            )}
          </div>

          {controller.createNewAccount && (
            <div>
              <label className="text-sm font-medium">New Account Name</label>
              <Input
                className="mt-1"
                placeholder="Enter account name..."
                value={controller.newAccountName}
                onChange={(e) => controller.setNewAccountName(e.target.value)}
              />
            </div>
          )}

          <div>
            <label className="text-sm font-medium">Transcript Preview</label>
            <ScrollArea className="h-48 mt-1 border rounded-md p-3 text-sm">
              {meeting?.transcript_content?.slice(0, 2000) || "No transcript available"}
              {(meeting?.transcript_content?.length || 0) > 2000 && "..."}
            </ScrollArea>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={controller.close} disabled={controller.isImporting}>
              Cancel
            </Button>
            <Button type="button" onClick={controller.runImport} disabled={!controller.canImport}>
              {controller.isImporting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  {controller.createNewAccount ? "Creating & Importing..." : "Importing..."}
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-1" />
                  {controller.createNewAccount ? "Create Account & Import" : "Import & Analyze"}
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

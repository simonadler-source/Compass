import React, { createContext, useContext, useState, useCallback, ReactNode, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { toast } from 'sonner';


import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { cn } from '@/lib/utils';
import type { MomentumMeeting, AccountListItem, SuggestedAccount } from '@/features/momentum/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sparkles,
  Download,
  Loader2,
  ClipboardCopy,
  Trash2,
  Calendar,
  Users,
  FileText,
  User,
} from 'lucide-react';

import {
  importMomentumMeetingSteps,
  revertMeetingToPending,
  MEETING_CORE_SELECT,
  type MomentumMeetingCore,
} from '@/features/momentum/import/importMomentumMeeting';

type ImportEvent = {
  at: string;
  stage: string;
  detail?: string;
  level: 'info' | 'error';
};

type ImportModalContextType = {
  openImport: (meetingId: string) => void;
  closeImport: () => void;
  isOpen: boolean;
  meetingId: string | null;
};

const ImportModalContext = createContext<ImportModalContextType | null>(null);

export function useImportModal() {
  const ctx = useContext(ImportModalContext);
  if (!ctx) throw new Error('useImportModal must be used within ImportModalProvider');
  return ctx;
}

function capitalizeDomain(domain: string) {
  return domain.charAt(0).toUpperCase() + domain.slice(1);
}

function normalizeName(name: string) {
  return name.trim().toLowerCase().replace(/\s+/g, ' ');
}

type AccountMatchCandidate = {
  account: AccountListItem;
  score: number;
  reason: string;
};


function ImportDialog({
  meetingId,
  onClose,
}: {
  meetingId: string;
  onClose: () => void;
}) {
  const queryClient = useQueryClient();

  const [selectedAccountId, setSelectedAccountId] = useState('');
  const [createNewAccount, setCreateNewAccount] = useState(false);
  const [newAccountName, setNewAccountName] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importStage, setImportStage] = useState('Loading meeting…');
  const [events, setEvents] = useState<ImportEvent[]>([]);
  const [lastError, setLastError] = useState<string | null>(null);
  const [didAutoPopulate, setDidAutoPopulate] = useState(false);
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3>(1);
  const [shouldLoadTranscript, setShouldLoadTranscript] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);

  const logEvent = useCallback(
    (stage: string, detail?: string, level: ImportEvent['level'] = 'info') => {
      const evt: ImportEvent = { at: new Date().toISOString(), stage, detail, level };
      setEvents((prev) => [...prev, evt]);
      if (level === 'error') {
        console.error('[importModal]', stage, detail);
      } else {
        console.debug('[importModal]', stage, detail);
      }
    },
    [],
  );

  const clearDiagnostics = () => {
    setEvents([]);
    setLastError(null);
  };

  const transcriptQueryKey = ['momentum-meeting-transcript', meetingId] as const;

  const fetchMeetingCore = async () => {
    logEvent('fetch_meeting', `id=${meetingId}`);
    // Use gateway for automatic decryption of PII fields (title, attendees, host_email, etc.)
    const { data, error } = await gateway
      .from('momentum_meetings')
      .select(MEETING_CORE_SELECT)
      .eq('id', meetingId)
      .single();
    if (error) {
      logEvent('fetch_meeting_error', getErrorMessage(error), 'error');
      throw new Error(getErrorMessage(error));
    }
    logEvent('meeting_loaded', `title=${data.title}`);
    return data as MomentumMeetingCore;
  };

  const fetchTranscript = async () => {
    logEvent('fetch_transcript', `id=${meetingId}`);
    // Use gateway for automatic decryption of transcript_content
    const { data, error } = await gateway
      .from('momentum_meetings')
      .select('transcript_content')
      .eq('id', meetingId)
      .single();
    if (error) {
      logEvent('fetch_transcript_error', getErrorMessage(error), 'error');
      throw new Error(getErrorMessage(error));
    }
    const chars = data.transcript_content?.length ?? 0;
    logEvent('transcript_loaded', `chars=${chars.toLocaleString()}`);
    return (data.transcript_content ?? null) as string | null;
  };

  // Fetch meeting core data by ID (fast: excludes transcript)
  const {
    data: meeting,
    isLoading: loadingMeeting,
    error: meetingError,
  } = useQuery({
    queryKey: ['momentum-meeting', meetingId],
    queryFn: fetchMeetingCore,
    enabled: !!meetingId,
  });

  // Fetch transcript content only when needed
  const {
    data: transcript,
    isLoading: loadingTranscript,
    error: transcriptError,
  } = useQuery({
    queryKey: transcriptQueryKey,
    queryFn: fetchTranscript,
    enabled: !!meetingId && shouldLoadTranscript,
  });

  const ensureTranscript = async () => {
    setShouldLoadTranscript(true);
    return await queryClient.fetchQuery({
      queryKey: transcriptQueryKey,
      queryFn: fetchTranscript,
    });
  };

  // Fetch accounts
  const { data: accounts } = useQuery({
    queryKey: ['accounts-list-full'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('accounts')
        .select('id, name, salesforce_account_id')
        .order('name', { ascending: true })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as AccountListItem[];
    },
  });

  // Live DB lookup by salesforce_account_id — catches accounts not in the local cache
  // First priority: use matched_account_id from the meeting record itself
  const { data: matchedAccount } = useQuery({
    queryKey: ['account-by-id', meeting?.matched_account_id],
    queryFn: async () => {
      const { data } = await gateway
        .from('accounts')
        .select('id, name, salesforce_account_id')
        .eq('id', meeting!.matched_account_id!)
        .maybeSingle();
      return data as AccountListItem | null;
    },
    enabled: !!meeting?.matched_account_id,
  });

  // Second priority: look up by salesforce_account_id if no matched_account_id
  const { data: sfIdAccount } = useQuery({
    queryKey: ['account-by-sfid', meeting?.salesforce_account_id],
    queryFn: async () => {
      const { data } = await gateway
        .from('accounts')
        .select('id, name, salesforce_account_id')
        .eq('salesforce_account_id', meeting!.salesforce_account_id!)
        .maybeSingle();
      return data as AccountListItem | null;
    },
    enabled: !!meeting?.salesforce_account_id && !meeting?.matched_account_id,
  });

  // Derive suggested account
  const suggestedAccount: SuggestedAccount = React.useMemo(() => {
    if (!meeting || !accounts) return null;

    // Highest priority: matched_account_id already set on the meeting record
    if (matchedAccount) {
      return { kind: 'account', account: matchedAccount, reason: 'Already linked account' };
    }

    // Second priority: Salesforce ID match
    if (meeting.salesforce_account_id) {
      const sfMatch = sfIdAccount || accounts.find((a) => a.salesforce_account_id === meeting.salesforce_account_id);
      if (sfMatch) return { kind: 'account', account: sfMatch, reason: 'Salesforce ID match' };
    }

    const externalAttendees = (meeting.attendees || []).filter((a: any) => !a.isInternal);
    const externalDomains = externalAttendees
      .map((a: any) => a.email?.split('@')[1]?.toLowerCase())
      .filter(Boolean);

    for (const account of accounts) {
      const accountNameLower = account.name.toLowerCase();

      if (meeting.title.toLowerCase().includes(accountNameLower)) {
        return { kind: 'account', account, reason: 'Name found in meeting title' };
      }

      for (const domain of externalDomains) {
        const domainBase = domain.split('.')[0];
        if (accountNameLower.includes(domainBase) || domainBase.includes(accountNameLower)) {
          return { kind: 'account', account, reason: `Email domain match (${domain})` };
        }
      }
    }

    if (externalAttendees.length > 0) {
      const firstExternal = externalAttendees[0];
      const domain = firstExternal.email?.split('@')[1]?.split('.')[0];
      if (domain) {
        return {
          kind: 'suggestedName',
          suggestedName: capitalizeDomain(domain),
          reason: 'Based on attendee email',
        };
      }
    }

    return null;
  }, [meeting, accounts, sfIdAccount, matchedAccount]);

  const derivedAccountName = React.useMemo(() => {
    if (!meeting) return null;
    if (suggestedAccount?.kind === 'account') return suggestedAccount.account.name;
    if (suggestedAccount?.kind === 'suggestedName') return suggestedAccount.suggestedName;
    const raw = meeting.title.split('|')[0].split('-')[0].split(':')[0].trim();
    return raw || null;
  }, [meeting, suggestedAccount]);

  const matchCandidates: AccountMatchCandidate[] = React.useMemo(() => {
    if (!meeting || !accounts || !derivedAccountName) return [];
    const needle = normalizeName(derivedAccountName);
    if (!needle) return [];

    // Build a deduplicated account list that includes matched/sfId accounts not in the local cache
    const accountList = [...accounts];
    for (const extra of [matchedAccount, sfIdAccount]) {
      if (extra && !accountList.find(a => a.id === extra.id)) accountList.unshift(extra);
    }

    const scored = accountList
      .map((a) => {
        // Always give matched_account_id and sfId accounts a top score
        if (matchedAccount && a.id === matchedAccount.id) {
          return { account: a, score: 100, reason: 'Already linked account' };
        }
        if (sfIdAccount && a.id === sfIdAccount.id) {
          return { account: a, score: 100, reason: 'Salesforce ID match' };
        }
        const hay = normalizeName(a.name);
        if (!hay) return null;
        if (hay === needle) return { account: a, score: 100, reason: 'Exact name match' };
        if (hay.includes(needle) || needle.includes(hay)) return { account: a, score: 85, reason: 'Partial name match' };
        const firstWord = needle.split(' ')[0];
        if (firstWord.length >= 4 && hay.includes(firstWord)) return { account: a, score: 70, reason: `Contains '${firstWord}'` };
        return null;
      })
      .filter(Boolean) as AccountMatchCandidate[];

    return scored.sort((a, b) => b.score - a.score).slice(0, 5);
  }, [meeting, accounts, derivedAccountName, sfIdAccount, matchedAccount]);

  // Auto-populate when meeting loaded
  // Wait for ALL async lookups to settle before auto-populating or auto-advancing.
  // sfIdAccount is undefined=loading, null=not found, AccountListItem=found
  const sfIdQueryReady =
    (!meeting?.matched_account_id || matchedAccount !== undefined) &&
    (!meeting?.salesforce_account_id || meeting?.matched_account_id || sfIdAccount !== undefined);

  React.useEffect(() => {
    // CRITICAL: do NOT auto-populate until sfId lookup has resolved.
    // Without this guard, the effect fires while sfIdAccount=undefined (loading),
    // falls through to suggestedName, sets createNewAccount=true, and locks didAutoPopulate=true
    // before the real account match arrives.
    if (!meeting || !accounts || didAutoPopulate || !sfIdQueryReady) return;

    if (suggestedAccount?.kind === 'account') {
      setSelectedAccountId(suggestedAccount.account.id);
      setCreateNewAccount(false);
      logEvent('account_preselected', `suggested=${suggestedAccount.account.id}`);
      setDidAutoPopulate(true);
      return;
    }

    if (matchCandidates.length > 0 && matchCandidates[0].score >= 85) {
      setSelectedAccountId(matchCandidates[0].account.id);
      setCreateNewAccount(false);
      logEvent('account_preselected', `candidate=${matchCandidates[0].account.id}`);
      setDidAutoPopulate(true);
      return;
    }

    if (derivedAccountName) {
      setCreateNewAccount(true);
      setNewAccountName(derivedAccountName);
      setSelectedAccountId('');
      logEvent('account_name_suggested', `new='${derivedAccountName}'`);
      setDidAutoPopulate(true);
      return;
    }

    setDidAutoPopulate(true);
  }, [meeting, accounts, didAutoPopulate, sfIdQueryReady, suggestedAccount, matchCandidates, derivedAccountName, logEvent]);

  React.useEffect(() => {
    if (meeting) setImportStage('Ready');
  }, [meeting]);

  React.useEffect(() => {
    if (wizardStep === 3) setShouldLoadTranscript(true);
  }, [wizardStep]);

  const importMutation = useMutation({
    mutationFn: async ({
      meeting,
      transcript,
      accountId,
    }: {
      meeting: MomentumMeetingCore;
      transcript: string;
      accountId: string;
    }) => {
      const { analysis } = await importMomentumMeetingSteps({
        meeting,
        transcript,
        accountId,
        onStage: setImportStage,
        onProgress: setImportProgress,
        log: logEvent,
      });

      return { analysis, meetingId: meeting.id };
    },
    onSuccess: () => {
      setLastError(null);
      setImportStage('Done');
      setImportProgress(100);
      logEvent('success', 'Import completed');
      
      // Close dialog FIRST before invalidating queries to avoid
      // race condition where meeting query refetches during close
      onClose();
      
      // Then show toast and invalidate queries
      toast.success('Meeting imported and analyzed successfully');
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings'], refetchType: 'all' });
      queryClient.invalidateQueries({ queryKey: ['meeting-search-index'], refetchType: 'all' });
      queryClient.invalidateQueries({ queryKey: ['accounts-list-full'] });
    },
    onError: async (error: any, variables) => {
      const msg = error?.message || 'Unknown error';
      setLastError(msg);
      setImportStage('Failed - reverting to pending');
      logEvent('failed', msg, 'error');
      
      // Revert meeting back to pending so user can retry
      if (variables?.meeting?.id) {
        await revertMeetingToPending(variables.meeting.id, logEvent);
        logEvent('step', 'Meeting reverted to pending - you can retry');
      }
      
      toast.error(`Import failed: ${msg}. Meeting returned to pending.`);
      queryClient.invalidateQueries({ queryKey: ['momentum-meetings'], refetchType: 'all' });
      queryClient.invalidateQueries({ queryKey: ['meeting-search-index'], refetchType: 'all' });
    },
  });

  const runImport = async () => {
    logEvent('runImport_clicked');

    if (!meeting) {
      setLastError('No meeting loaded');
      logEvent('validation_error', 'No meeting loaded', 'error');
      toast.error('No meeting loaded');
      return;
    }

    setIsImporting(true);
    setImportStage('Determining account…');
    setImportProgress(4);

    try {
      let accountId = selectedAccountId;

      // PRIORITY 0 (highest): Always check Salesforce Account ID first — this is the most reliable
      // signal we have that a meeting belongs to an existing account. We do this BEFORE checking
      // createNewAccount so that a stale wizard state (e.g. user was shown "Create" before the
      // SF ID lookup resolved) never results in a duplicate-account error.
      if (meeting.salesforce_account_id) {
        // Check local cache first (fast)
        const sfIdMatch = accounts?.find((a) => a.salesforce_account_id === meeting.salesforce_account_id);
        if (sfIdMatch) {
          accountId = sfIdMatch.id;
          logEvent('account_found_by_sf_id_cache', `accountId=${accountId} name='${sfIdMatch.name}'`);
        } else {
          // Live DB lookup — catches accounts not in the 1 000-row cache
          const { data: dbMatch } = await gateway
            .from('accounts')
            .select('id, name')
            .eq('salesforce_account_id', meeting.salesforce_account_id)
            .maybeSingle();
          if (dbMatch) {
            accountId = dbMatch.id;
            logEvent('account_found_by_sf_id_db', `accountId=${accountId} name='${dbMatch.name}'`);
          }
        }
      }

      // PRIORITY 1: Explicitly selected account from the wizard (if SF ID lookup didn't override)
      if (!accountId && selectedAccountId) {
        accountId = selectedAccountId;
        logEvent('account_from_selection', `accountId=${accountId}`);
      }

      // PRIORITY 2: Best name-match candidate (score >= 85)
      const best = matchCandidates[0];
      if (!accountId && !createNewAccount && best && best.score >= 85) {
        accountId = best.account.id;
        logEvent('account_auto_selected', `accountId=${accountId} score=${best.score}`);
      }

      const shouldAutoCreate = !accountId && !createNewAccount && !!derivedAccountName;

      if (shouldAutoCreate) {
        const name = derivedAccountName!.trim();
        setImportStage('Creating account…');
        setImportProgress(12);
        logEvent('step', `Auto-creating account name='${name}'`);

        const exact = matchCandidates.find((c) => c.score === 100);
        if (exact) {
          accountId = exact.account.id;
          logEvent('account_auto_selected', `exactMatch=${accountId}`);
        } else {
          const { data: inserted, error: createError } = await gateway
            .from('accounts')
            .insert({ name, salesforce_account_id: meeting.salesforce_account_id })
            .select('id, name')
            .execute();

          // On duplicate salesforce_account_id, fall back to the existing account
          const isDuplicateKey = createError && (
            getErrorMessage(createError).includes('duplicate key') ||
            getErrorMessage(createError).includes('unique constraint')
          );

          if (createError && !isDuplicateKey) {
            logEvent('db_error', `Create account failed: ${getErrorMessage(createError)}`, 'error');
            throw new Error(getErrorMessage(createError));
          }

          let resolvedAccount = Array.isArray(inserted) ? inserted[0] : inserted;

          // Fallback 1: duplicate sfid — fetch by salesforce_account_id
          if (!resolvedAccount?.id && meeting.salesforce_account_id) {
            logEvent('step', `Duplicate SFDC, fetching by sfid: ${meeting.salesforce_account_id}`);
            const { data: existing } = await gateway
              .from('accounts')
              .select('id, name')
              .eq('salesforce_account_id', meeting.salesforce_account_id)
              .maybeSingle();
            resolvedAccount = existing;
          }

          // Fallback 2: duplicate name — fetch by exact name
          if (!resolvedAccount?.id && isDuplicateKey) {
            logEvent('step', `Duplicate name, fetching by name: '${name}'`);
            const { data: existingByName } = await gateway
              .from('accounts')
              .select('id, name')
              .eq('name', name)
              .maybeSingle();
            resolvedAccount = existingByName;
          }

          if (!resolvedAccount?.id) {
            throw new Error('Account creation failed (no id returned)');
          }

          accountId = resolvedAccount.id;
          logEvent('account_resolved', `accountId=${accountId} name='${resolvedAccount.name}'`);
        }
      }

      // createNewAccount path — user explicitly chose to create a new account in the wizard.
      // We still skip creation if SF ID lookup already resolved an existing account above.
      if (createNewAccount && !accountId) {
        const name = newAccountName.trim();
        if (!name) {
          setLastError('Missing new account name');
          logEvent('validation_error', 'Missing new account name', 'error');
          toast.error('Please enter an account name');
          return;
        }

        setImportStage('Creating account…');
        setImportProgress(12);
        logEvent('step', `Creating account name='${name}'`);

        const { data: inserted, error: createError } = await gateway
          .from('accounts')
          .insert({ name, salesforce_account_id: meeting.salesforce_account_id })
          .select('id, name')
          .execute();

        const isDuplicateKey = createError && (
          getErrorMessage(createError).includes('duplicate key') ||
          getErrorMessage(createError).includes('unique constraint')
        );

        if (createError && !isDuplicateKey) {
          logEvent('db_error', `Create account failed: ${getErrorMessage(createError)}`, 'error');
          throw new Error(getErrorMessage(createError));
        }

        let resolvedAccount = Array.isArray(inserted) ? inserted[0] : inserted;

        // Fallback 1: duplicate sfid
        if (!resolvedAccount?.id && meeting.salesforce_account_id) {
          logEvent('step', `Duplicate SFDC, fetching by sfid: ${meeting.salesforce_account_id}`);
          const { data: existing } = await gateway
            .from('accounts')
            .select('id, name')
            .eq('salesforce_account_id', meeting.salesforce_account_id)
            .maybeSingle();
          resolvedAccount = existing;
        }

        // Fallback 2: duplicate name
        if (!resolvedAccount?.id && isDuplicateKey) {
          logEvent('step', `Duplicate name, fetching by name: '${name}'`);
          const { data: existingByName } = await gateway
            .from('accounts')
            .select('id, name')
            .eq('name', name)
            .maybeSingle();
          resolvedAccount = existingByName;
        }

        if (!resolvedAccount?.id) {
          throw new Error('Account creation failed (no id returned)');
        }

        accountId = resolvedAccount.id;
        logEvent('account_resolved', `accountId=${accountId} name='${resolvedAccount.name}'`);
      }

      if (!accountId) {
        setLastError('No account resolved');
        logEvent('validation_error', 'No account resolved', 'error');
        toast.error('Could not determine an account. Please pick one.');
        return;
      }

      setLastError(null);
      setImportStage('Loading transcript…');
      setImportProgress(14);

      const transcriptValue = await ensureTranscript();
      if (!transcriptValue) {
        logEvent('validation_error', 'No transcript available', 'error');
        throw new Error('No transcript available for this meeting');
      }

      setImportStage('Starting import…');
      setImportProgress(16);

      await importMutation.mutateAsync({ meeting, transcript: transcriptValue, accountId });
    } finally {
      setIsImporting(false);
    }
  };

  const canImport = !!meeting && !isImporting;
  const transcriptChars = transcript?.length ?? 0;

  const copyDiagnostics = async () => {
    const payload = {
      meeting: meeting
        ? {
            id: meeting.id,
            title: meeting.title,
            start_time: meeting.start_time,
            status: meeting.status,
            host_email: meeting.host_email,
            host_name: meeting.host_name,
            salesforce_account_id: meeting.salesforce_account_id,
            attendees: meeting.attendees?.length ?? 0,
            transcript_chars: transcriptChars,
          }
        : null,
      state: {
        isImporting,
        importStage,
        importProgress,
        derivedAccountName,
        selectedAccountId,
        createNewAccount,
        newAccountName,
        canImport,
        lastError,
        matchCandidates,
      },
      events,
    };

    try {
      await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
      toast.success('Diagnostics copied to clipboard');
    } catch {
      toast.error('Could not copy diagnostics (clipboard blocked)');
    }
  };

  const stepTitles = ['Meeting Details', 'Select Account', 'Confirm & Import'];

  // If a definitive account match exists (Salesforce ID or high-confidence name match),
  // skip Step 2 entirely — go straight from Step 1 → Step 3.
  const hasDefinitiveAccountMatch =
    sfIdQueryReady && (
      suggestedAccount?.kind === 'account' ||
      (matchCandidates.length > 0 && matchCandidates[0].score >= 85)
    );

  // Auto-advance to Step 3 from Step 1 or Step 2 once we confirm a definitive match.
  // This handles the race where the user clicks Next before matchedAccount resolves.
  React.useEffect(() => {
    if ((wizardStep === 1 || wizardStep === 2) && hasDefinitiveAccountMatch && meeting && !isImporting) {
      setWizardStep(3);
    }
  }, [wizardStep, hasDefinitiveAccountMatch, meeting, isImporting]);

  const canProceedStep1 = !!meeting;
  const canProceedStep2 = !!(selectedAccountId || (createNewAccount && newAccountName.trim()));

  // Prevent accidental navigation/tab close during import
  useEffect(() => {
    if (!isImporting) return;
    
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = 'Import in progress. Are you sure you want to leave?';
      return e.returnValue;
    };
    
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isImporting]);

  return (
    <Dialog 
      open 
      onOpenChange={(open) => {
        // Prevent closing during import
        if (isImporting) return;
        if (!open) onClose();
      }}
    >
      <DialogContent 
        className="max-w-lg"
        onInteractOutside={(e) => {
          // Prevent closing when clicking outside during import
          if (isImporting) e.preventDefault();
        }}
        onEscapeKeyDown={(e) => {
          // Prevent closing with Escape during import
          if (isImporting) e.preventDefault();
        }}
      >
        <DialogHeader>
          <DialogTitle className="text-lg">
            Import Meeting
          </DialogTitle>
          <p className="text-sm text-muted-foreground truncate">{meeting?.title ?? 'Loading…'}</p>
        </DialogHeader>

        {/* Wizard step indicator */}
        <div className="flex items-center gap-2">
          {[1, 2, 3].map((step) => (
            <div key={step} className="flex items-center gap-2 flex-1">
              <div
                className={cn(
                  'w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold border transition-colors',
                  wizardStep === step
                    ? 'bg-primary text-primary-foreground border-primary'
                    : wizardStep > step
                    ? 'bg-primary/20 text-primary border-primary/40'
                    : 'bg-muted text-muted-foreground border-border'
                )}
              >
                {step}
              </div>
              <span
                className={cn(
                  'text-xs font-medium hidden sm:inline',
                  wizardStep === step ? 'text-foreground' : 'text-muted-foreground'
                )}
              >
                {stepTitles[step - 1]}
              </span>
              {step < 3 && <div className="flex-1 h-px bg-border" />}
            </div>
          ))}
        </div>

        {/* Progress bar when importing */}
        {(isImporting || importProgress > 0) && (
          <div className="rounded-lg border bg-muted/30 p-3">
            <div className="flex items-center justify-between gap-3">
              <p className="text-sm font-medium text-foreground">{importStage || 'Working…'}</p>
              <span className="text-xs text-muted-foreground">{Math.round(importProgress)}%</span>
            </div>
            <Progress value={importProgress} className="mt-2" />
          </div>
        )}

        {lastError && (
          <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-3">
            <p className="text-sm font-medium">Error</p>
            <p className="text-xs text-muted-foreground mt-1 break-words">{lastError}</p>
          </div>
        )}

        {loadingMeeting && (
          <div className="flex items-center justify-center py-8 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin mr-2" />
            <span>Loading meeting…</span>
          </div>
        )}

        {meetingError && (
          <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-3">
            <p className="text-sm font-medium">Couldn’t load this meeting</p>
            <p className="text-xs text-muted-foreground mt-1 break-words">
              {(meetingError as Error).message}
            </p>
          </div>
        )}

        {shouldLoadTranscript && transcriptError && (
          <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-3">
            <p className="text-sm font-medium">Couldn’t load transcript</p>
            <p className="text-xs text-muted-foreground mt-1 break-words">
              {(transcriptError as Error).message}
            </p>
          </div>
        )}

        {/* STEP 1: Meeting Details */}
        {wizardStep === 1 && meeting && (
          <div className="space-y-4">
            <div className="rounded-lg border bg-card p-4">
              <div className="grid gap-3 text-sm">
                <div className="flex items-center gap-3">
                  <Calendar className="h-4 w-4 text-muted-foreground shrink-0" />
                  <span>{format(new Date(meeting.start_time), 'MMMM d, yyyy • h:mm a')}</span>
                </div>
                <div className="flex items-center gap-3">
                  <User className="h-4 w-4 text-muted-foreground shrink-0" />
                  <span>{meeting.host_name || meeting.host_email || 'Unknown host'}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Users className="h-4 w-4 text-muted-foreground shrink-0" />
                  <span>{meeting.attendees?.length ?? 0} attendees</span>
                </div>

                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span className="truncate">
                      {loadingTranscript
                        ? 'Loading transcript…'
                        : transcriptChars > 0
                          ? `${transcriptChars.toLocaleString()} characters`
                          : shouldLoadTranscript
                            ? 'No transcript'
                            : 'Transcript not loaded'}
                    </span>
                  </div>

                  {!shouldLoadTranscript && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setShouldLoadTranscript(true)}
                    >
                      Load preview
                    </Button>
                  )}
                </div>
              </div>
            </div>

            {shouldLoadTranscript && (
              <div>
                <p className="text-sm font-medium mb-2">Transcript Preview</p>
                {loadingTranscript ? (
                  <div className="flex items-center justify-center h-32 border rounded-md text-sm text-muted-foreground bg-muted/20">
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    <span>Loading transcript…</span>
                  </div>
                ) : transcript ? (
                  <ScrollArea className="h-32 border rounded-md p-3 text-sm text-muted-foreground bg-muted/20">
                    {transcript.slice(0, 800)}
                    {transcript.length > 800 && '…'}
                  </ScrollArea>
                ) : (
                  <div className="h-32 border rounded-md p-3 text-sm text-muted-foreground bg-muted/20">
                    No transcript available
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* STEP 2: Select Account */}
        {wizardStep === 2 && meeting && (
          <div className="space-y-4">
            {suggestedAccount?.kind === 'account' && (
              <div className="flex items-center gap-2 p-3 bg-primary/10 rounded-lg border border-primary/20">
                <Sparkles className="h-4 w-4 text-primary shrink-0" />
                <span className="text-sm">
                  <strong>Suggested:</strong> {suggestedAccount.account.name}
                  <span className="text-muted-foreground ml-1">({suggestedAccount.reason})</span>
                </span>
              </div>
            )}

            {matchCandidates.length > 0 && (
              <div>
                <p className="text-sm font-medium mb-2">Possible matches</p>
                <div className="flex flex-wrap gap-2">
                  {matchCandidates.map((c) => (
                    <button
                      key={c.account.id}
                      type="button"
                      onClick={() => {
                        setCreateNewAccount(false);
                        setSelectedAccountId(c.account.id);
                        toast.message(`Selected: ${c.account.name}`, { duration: 1000 });
                      }}
                    >
                      <Badge
                        variant={selectedAccountId === c.account.id ? 'default' : 'secondary'}
                        className="cursor-pointer"
                      >
                        {c.account.name}
                      </Badge>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <label className="text-sm font-medium">Account</label>
              <Select
                value={createNewAccount ? '__new__' : selectedAccountId}
                onValueChange={(val) => {
                  if (val === '__new__') {
                    setCreateNewAccount(true);
                    setSelectedAccountId('');
                    if (derivedAccountName) setNewAccountName(derivedAccountName);
                  } else {
                    setCreateNewAccount(false);
                    setSelectedAccountId(val);
                  }
                }}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Choose an account..." />
                </SelectTrigger>
                <SelectContent>
                  {accounts?.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name}
                      {suggestedAccount?.kind === 'account' && suggestedAccount.account.id === account.id && (
                        <span className="ml-2 text-primary">★</span>
                      )}
                    </SelectItem>
                  ))}
                  <SelectSeparator />
                  <SelectItem value="__new__" className="text-primary">
                    + Create new account
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {createNewAccount && (
              <div>
                <label className="text-sm font-medium">New Account Name</label>
                <Input
                  className="mt-1"
                  placeholder="Enter account name..."
                  value={newAccountName}
                  onChange={(e) => setNewAccountName(e.target.value)}
                  autoFocus
                />
              </div>
            )}
          </div>
        )}

        {/* STEP 3: Confirm */}
        {wizardStep === 3 && meeting && (
          <div className="space-y-4">
            <div className="rounded-lg border bg-card p-4">
              <p className="text-sm font-medium mb-3">Ready to import</p>
              <div className="grid gap-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Meeting</span>
                  <span className="font-medium truncate max-w-[200px]">{meeting.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Account</span>
                  <span className="font-medium">
                    {createNewAccount
                      ? `Create: ${newAccountName}`
                      : accounts?.find((a) => a.id === selectedAccountId)?.name ?? '—'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Transcript</span>
                  <span className="font-medium">
                    {loadingTranscript
                      ? 'Loading…'
                      : transcriptChars > 0
                        ? `${transcriptChars.toLocaleString()} chars`
                        : shouldLoadTranscript
                          ? 'No transcript'
                          : 'Not loaded'}
                  </span>
                </div>
              </div>
            </div>

            <p className="text-xs text-muted-foreground">
              This will save the transcript, run AI analysis, and extract technologies + contacts.
            </p>

            {/* Collapsible diagnostics */}
            <div>
              <button
                type="button"
                className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
                onClick={() => setShowDiagnostics(!showDiagnostics)}
              >
                <ClipboardCopy className="h-3 w-3" />
                {showDiagnostics ? 'Hide diagnostics' : 'Show diagnostics'}
              </button>
              {showDiagnostics && (
                <div className="mt-2 space-y-2">
                  <div className="flex items-center gap-2">
                    <Button type="button" variant="outline" size="sm" onClick={copyDiagnostics}>
                      <ClipboardCopy className="h-3 w-3 mr-1" />
                      Copy
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={clearDiagnostics}>
                      <Trash2 className="h-3 w-3 mr-1" />
                      Clear
                    </Button>
                  </div>
                  <ScrollArea className="h-20 rounded-md border bg-muted/20 p-2">
                    <div className="space-y-1">
                      {events.length === 0 ? (
                        <p className="text-xs text-muted-foreground">No events yet.</p>
                      ) : (
                        events.slice(-30).map((e, idx) => (
                          <div key={`${e.at}-${idx}`} className="text-xs">
                            <span className="text-muted-foreground">{new Date(e.at).toLocaleTimeString()} </span>
                            <span className={e.level === 'error' ? 'text-destructive' : 'text-foreground'}>
                              {e.stage}
                            </span>
                            {e.detail ? <span className="text-muted-foreground"> — {e.detail}</span> : null}
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Footer navigation */}
        {meeting && (
          <div className="flex justify-between pt-2 border-t">
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                if (wizardStep === 1) {
                  onClose();
                } else if (wizardStep === 3 && hasDefinitiveAccountMatch) {
                  // Account was auto-matched — back skips step 2 and returns to step 1
                  setWizardStep(1);
                } else {
                  setWizardStep((s) => (s > 1 ? ((s - 1) as 1 | 2 | 3) : s));
                }
              }}
              disabled={isImporting}
            >
              {wizardStep === 1 ? 'Cancel' : 'Back'}
            </Button>

            {wizardStep < 3 ? (
              <Button
                type="button"
                onClick={() => {
                  if (wizardStep === 1 && hasDefinitiveAccountMatch) {
                    // Skip account selection — account already resolved
                    setWizardStep(3);
                  } else {
                    setWizardStep((s) => (s < 3 ? ((s + 1) as 1 | 2 | 3) : s));
                  }
                }}
                disabled={wizardStep === 1 ? !canProceedStep1 : !canProceedStep2}
              >
                {wizardStep === 1 && hasDefinitiveAccountMatch ? 'Next: Review & Import' : 'Next'}
              </Button>
            ) : (
              <Button type="button" onClick={runImport} disabled={!canImport}>
                {isImporting ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                    Importing…
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4 mr-1" />
                    Import & Analyze
                  </>
                )}
              </Button>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function ImportModalProvider({ children }: { children: ReactNode }) {
  const [meetingId, setMeetingId] = useState<string | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const openImport = useCallback((id: string) => {
    console.debug('[ImportModalProvider] openImport called', id);
    toast.message('Opening import dialog…', { duration: 1200 });
    setMeetingId(id);
    setIsOpen(true);
  }, []);

  const closeImport = useCallback(() => {
    setIsOpen(false);
    setMeetingId(null);
  }, []);

  return (
    <ImportModalContext.Provider value={{ openImport, closeImport, isOpen, meetingId }}>
      {children}
      {isOpen && meetingId && <ImportDialog meetingId={meetingId} onClose={closeImport} />}
    </ImportModalContext.Provider>
  );
}

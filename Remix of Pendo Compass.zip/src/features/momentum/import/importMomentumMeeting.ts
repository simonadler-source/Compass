import { format } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { encryptedInsert, encryptedUpdate, encryptedUpsert } from '@/lib/encryptedDb';
import { saveExtractedTechnologies } from '@/hooks/useSaveExtractedTechnologies';
import { fetchCompetitorsForAnalysis } from '@/hooks/useCompetitorsList';
import { inferActivityType } from '@/hooks/useOpportunityActivities';
import { saveInsightsWithEnrichment, saveNBAsWithDeduplication } from '@/hooks/useInsightEnrichment';
import { PENDO_INTERNAL_ACCOUNT_ID } from '@/hooks/useMeetingTypeSelector';
import type { MomentumMeeting } from '@/features/momentum/types';

export type ImportLogLevel = 'info' | 'error';
export type ImportLogger = (stage: string, detail?: string, level?: ImportLogLevel) => void;

export type MomentumMeetingCore = Omit<MomentumMeeting, 'transcript_content'>;

export const MEETING_CORE_SELECT =
  'id,momentum_id,title,start_time,end_time,host_email,host_name,attendees,salesforce_account_id,salesforce_opportunity_id,status,matched_account_id,imported_at,ignored_at,created_at,opportunity_id';

export function isDirectImportExceptionMeeting(meeting: { title: string }) {
  return /pendo\s+configuration/i.test(meeting.title);
}

function report(log: ImportLogger | undefined, stage: string, detail?: string, level: ImportLogLevel = 'info') {
  log?.(stage, detail, level);
}

function setProgress(
  onStage: ((stage: string) => void) | undefined,
  onProgress: ((progress: number) => void) | undefined,
  stage: string,
  progress: number,
) {
  onStage?.(stage);
  onProgress?.(progress);
}

export async function importMomentumMeetingSteps({
  meeting,
  transcript,
  accountId,
  onStage,
  onProgress,
  log,
}: {
  meeting: MomentumMeetingCore;
  transcript: string;
  accountId: string;
  onStage?: (stage: string) => void;
  onProgress?: (progress: number) => void;
  log?: ImportLogger;
}) {
  if (!transcript) {
    report(log, 'validation_error', 'No transcript available', 'error');
    throw new Error('No transcript available for this meeting');
  }

  // Validate accountId - must be a valid UUID, not empty string
  if (!accountId || accountId.trim() === '') {
    report(log, 'validation_error', 'No account ID provided', 'error');
    throw new Error('No account ID provided - please select or create an account');
  }

  // Detect meeting context (internal vs external) from attendees
  const attendeesRaw: any = meeting.attendees ?? [];
  const attendees: any[] = Array.isArray(attendeesRaw) ? attendeesRaw : [];
  
  // Import context detection utilities
  const { detectMeetingContext, getEvidenceSource, getEvidenceConfidenceWeight } = await import('@/hooks/useMeetingTypeSelector');
  const detectedContext = detectMeetingContext(attendees);
  const meetingContext = detectedContext.context;
  const evidenceSource = getEvidenceSource(meetingContext);
  const evidenceWeight = getEvidenceConfidenceWeight(meetingContext);
  
  report(log, 'step', `Meeting context: ${meetingContext} (${detectedContext.reason}), evidence_source=${evidenceSource}, weight=${evidenceWeight}`);

  // Mark meeting as 'processing' (not 'imported') so we can detect failures
  setProgress(onStage, onProgress, 'Starting import…', 15);
  report(log, 'step', 'Marking meeting as processing');

  const { error: updateError } = await gateway
    .from('momentum_meetings')
    .update({
      status: 'processing',
      matched_account_id: accountId,
      meeting_context: meetingContext,
    })
    .eq('id', meeting.id)
    .execute();

  if (updateError) {
    report(log, 'db_error', `Update momentum_meetings failed: ${getErrorMessage(updateError)}`, 'error');
    throw new Error(getErrorMessage(updateError));
  }

  // attendeesRaw/attendees already declared above for context detection
  
  // Email validation - filter out dates, timestamps, malformed entries
  const isValidEmail = (email: string): boolean => {
    if (!email) return false;
    const trimmed = email.trim();
    // Must contain @ and a dot after @, not look like a date or timestamp
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const datePattern = /^\d{1,2}\/\d{1,2}\/\d{2,4}$/;
    const timePattern = /^\d{1,2}:\d{2}/;
    return emailPattern.test(trimmed) && !datePattern.test(trimmed) && !timePattern.test(trimmed);
  };
  
  // Internal detection: use Momentum's isInternal flag, OR fallback to @pendo.io domain
  const isInternalAttendee = (a: any): boolean => {
    if (a?.isInternal === true) return true;
    const email = String(a?.email || '').toLowerCase().trim();
    return email.endsWith('@pendo.io');
  };
  
  const externalAttendees = attendees.filter((a: any) => {
    const email = String(a?.email || '').trim();
    return !isInternalAttendee(a) && email && isValidEmail(email);
  });
  const internalAttendees = attendees.filter((a: any) => {
    const email = String(a?.email || '').trim();
    return isInternalAttendee(a) && email && isValidEmail(email);
  });

  // Save external attendees as account contacts (batched for speed)
  if (externalAttendees.length > 0) {
    report(log, 'step', `Upserting ${externalAttendees.length} external attendees as contacts`);

    const contactRows = externalAttendees
      .map((attendee: any) => {
        const email = String(attendee.email || '').toLowerCase().trim();
        if (!email) return null;
        const name =
          (typeof attendee.name === 'string' && attendee.name.trim()) || email.split('@')[0] || 'Unknown';
        return { account_id: accountId, name, email, is_internal: false, source: 'momentum' };
      })
      .filter(Boolean);

    if (contactRows.length > 0) {
      // Use encrypted upsert for PII contacts
      for (const row of contactRows) {
        if (row) {
          const { error: contactErr } = await encryptedUpsert('account_contacts', row);
          if (contactErr) {
            report(log, 'db_error', `Upsert account_contacts failed: ${contactErr.message}`, 'error');
            throw contactErr;
          }
        }
      }
    }
  }

  // Save internal attendees as account team members (batched for speed)
  if (internalAttendees.length > 0) {
    report(log, 'step', `Upserting ${internalAttendees.length} internal attendees as account team members`);

    const teamRows = internalAttendees
      .map((attendee: any) => {
        const email = String(attendee.email || '').toLowerCase().trim();
        if (!email) return null;
        return {
          account_id: accountId,
          team_member_email: email,
          role: 'participant',
          added_from_meeting_id: meeting.id,
        };
      })
      .filter(Boolean);

    if (teamRows.length > 0) {
      // Use encrypted upsert for team members
      for (const row of teamRows) {
        if (row) {
          const { error: teamErr } = await encryptedUpsert('account_team_members', row);
          if (teamErr) {
            report(log, 'db_error', `Upsert account_team_members failed: ${teamErr.message}`, 'error');
            // Non-fatal - continue with import
          }
        }
      }
    }
  }

  // Note: We no longer save transcript to account_documents
  // Transcript content is stored once in momentum_meetings table
  // and linked via momentum_meeting_id in transcript_reviews
  setProgress(onStage, onProgress, 'Analyzing transcript (Pass 1 of 4)…', 35);

  const transcriptLen = transcript.length;
  const analysisTranscript = transcriptLen > 120000 ? transcript.slice(0, 120000) : transcript;

  report(
    log,
    'step',
    `Starting streaming analysis (chars=${transcriptLen.toLocaleString()}${analysisTranscript.length !== transcriptLen ? ', truncated' : ''})`,
  );

  // Fetch competitors for smarter SWOT analysis
  const competitors = await fetchCompetitorsForAnalysis();
  
  // Use SSE streaming endpoint for real-time progress
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  
  let analysis: any = null;
  let lastError: string | null = null;
  
  try {
    const response = await fetch(`${supabaseUrl}/functions/v1/analyze-transcript-streaming`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
        'apikey': supabaseKey,
      },
      body: JSON.stringify({ 
        transcript: analysisTranscript, 
        skipEnrichment: true // Use async enrichment
      }),
    });

    if (!response.ok) {
      throw new Error(`Analysis failed: ${response.status}`);
    }

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    
    if (!reader) {
      throw new Error('No response stream');
    }

    // Process SSE stream
    let buffer = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n\n');
      buffer = lines.pop() || '';
      
      for (const chunk of lines) {
        if (!chunk.trim()) continue;
        
        const eventMatch = chunk.match(/^event: (\w+)\ndata: (.+)$/s);
        if (!eventMatch) continue;
        
        const [, eventType, dataStr] = eventMatch;
        try {
          const data = JSON.parse(dataStr);
          
          switch (eventType) {
            case 'progress':
              const passLabel = data.totalPasses > 1 
                ? `(Pass ${data.pass} of ${data.totalPasses})` 
                : '';
              setProgress(onStage, onProgress, `${data.stage} ${passLabel}`, data.progress);
              report(log, 'step', `Progress: ${data.stage} - ${data.progress}%`);
              break;
              
            case 'pass_complete':
              report(log, 'step', `Pass ${data.pass} complete`);
              break;
              
            case 'core_complete':
              analysis = data.result;
              if (data.enrichmentQueued) {
                report(log, 'step', 'Core analysis complete, enrichment queued for background processing');
              }
              break;
              
            case 'error':
              lastError = data.message;
              report(log, 'function_error', `Analysis error: ${data.message}`, 'error');
              break;
              
            case 'done':
              report(log, 'step', 'Analysis stream completed');
              break;
          }
        } catch (parseErr) {
          console.warn('Failed to parse SSE event:', parseErr);
        }
      }
    }
    
  } catch (streamError: any) {
    report(log, 'function_error', `Streaming analysis failed: ${streamError.message}`, 'error');
    
    // Fallback to original non-streaming endpoint
    report(log, 'step', 'Falling back to non-streaming analysis...');
    setProgress(onStage, onProgress, 'Analyzing transcript (fallback)…', 50);
    
    const { data: fallbackAnalysis, error: analysisError } = await supabase.functions.invoke('unified-transcript-analysis', {
      body: { transcript: analysisTranscript, skipEnrichment: true },
    });

    if (analysisError) {
      report(log, 'function_error', `Fallback analysis failed: ${analysisError.message}`, 'error');
      throw analysisError;
    }
    
    analysis = fallbackAnalysis;
  }

  if (!analysis && lastError) {
    throw new Error(lastError);
  }
  
  if (!analysis) {
    throw new Error('No analysis results received');
  }

  setProgress(onStage, onProgress, 'Saving insights (Pass 2 of 4)…', 70);
  report(log, 'step', `Saving extracted data (technologies=${analysis?.technologies?.length ?? 0})`);

  if (analysis?.technologies?.length > 0) {
    const { saved, draftsCreated } = await saveExtractedTechnologies(
      accountId,
      analysis.technologies.map((t: any) => ({
        name: t.name,
        confidence: t.confidence ?? 1,
        context: t.context,
        suggestedLayer: t.layer || t.suggestedLayer || 'adopt',
        category: t.category || 'Other',
      })),
      `Auto-extracted from call: ${meeting.title}`,
    );
    report(log, 'step', `Saved ${saved} technologies, ${draftsCreated} new drafts created`);
  }

  // Transcript review ID will be set after upsert
  
  // Step 1: Find or create the opportunity BEFORE saving the transcript
  // For internal meetings (Pendo Internal account), skip opportunity creation entirely
  const isInternalMeeting = accountId === PENDO_INTERNAL_ACCOUNT_ID;
  let linkedOpportunityId: string | null = null;
  
  const preSalesStage = analysis?.preSalesStageAssessment?.stage || null;
  const salesStage = analysis?.salesStageAssessment?.stage !== undefined 
    ? `stage_${analysis.salesStageAssessment.stage}` 
    : null;

  if (isInternalMeeting) {
    report(log, 'step', 'Internal meeting → skipping opportunity creation/linking');
  } else if (meeting.salesforce_opportunity_id) {
    report(log, 'step', `Looking up opportunity by SF Opportunity ID: ${meeting.salesforce_opportunity_id}`);
    
    // First try exact match on the dedicated salesforce_opportunity_id column
    const { data: exactMatch } = await gateway
      .from('opportunities')
      .select('id, name, salesforce_opportunity_id')
      .eq('account_id', accountId)
      .eq('salesforce_opportunity_id', meeting.salesforce_opportunity_id)
      .limit(1)
      .single();
    
    let existingOpp = exactMatch;
    
    // Fallback: check description for legacy records that might have the ID embedded in text
    if (!existingOpp) {
      const sfIdPattern = `Salesforce Opportunity ID: ${meeting.salesforce_opportunity_id}`;
      
      const { data: existingOpps } = await gateway
        .from('opportunities')
        .select('id, name, description, salesforce_opportunity_id')
        .eq('account_id', accountId)
        .execute();
      
      existingOpp = existingOpps?.find(opp => 
        opp.description?.includes(sfIdPattern) || 
        opp.description?.includes(`SF Opp ID: ${meeting.salesforce_opportunity_id}`) ||
        opp.name?.includes(meeting.salesforce_opportunity_id)
      ) || null;
      
      // If found via description, update the dedicated column for future lookups
      if (existingOpp && !existingOpp.salesforce_opportunity_id) {
        await gateway
          .from('opportunities')
          .update({ salesforce_opportunity_id: meeting.salesforce_opportunity_id })
          .eq('id', existingOpp.id)
          .execute();
        report(log, 'step', `Backfilled salesforce_opportunity_id on existing opportunity`);
      }
    }
    
    if (existingOpp) {
      linkedOpportunityId = existingOpp.id;
      report(log, 'step', `Found existing opportunity: ${existingOpp.name} (${existingOpp.id})`);
      
      // Update stages if AI detected them
      if (preSalesStage || salesStage) {
        const updateData: Record<string, string> = {};
        if (preSalesStage) updateData.pre_sales_stage = preSalesStage;
        if (salesStage) updateData.sales_stage = salesStage;
        
        await gateway
          .from('opportunities')
          .update(updateData)
          .eq('id', existingOpp.id)
          .execute();
        report(log, 'step', `Updated opportunity stages (pre_sales: ${preSalesStage || 'unchanged'})`);
      }
    } else {
      // Create new opportunity with the salesforce_opportunity_id column set
      const oppName =
        meeting.title.replace(/\s*\|\s*/g, ' - ').replace(/Pendo/gi, '').trim() ||
        `Opportunity from ${format(new Date(meeting.start_time), 'MMM d, yyyy')}`;

      const { data: newOpp, error: oppErr } = await gateway.from('opportunities').insert({
        account_id: accountId,
        name: oppName,
        description: `Created from Momentum meeting: ${meeting.title}\n\nSalesforce Opportunity ID: ${meeting.salesforce_opportunity_id}\n\nMeeting Date: ${format(new Date(meeting.start_time), 'MMM d, yyyy')}`,
        stage: 'identified',
        priority: 'medium',
        pre_sales_stage: preSalesStage,
        sales_stage: salesStage,
        salesforce_opportunity_id: meeting.salesforce_opportunity_id, // Set the dedicated column
      }).select('id').single();

      if (oppErr) {
        report(log, 'db_error', `Insert opportunity failed: ${getErrorMessage(oppErr)}`, 'error');
        // Non-fatal - continue without opportunity link
      } else {
        linkedOpportunityId = newOpp?.id || null;
        report(log, 'step', `Created opportunity: ${oppName} (id: ${linkedOpportunityId}, sfdc: ${meeting.salesforce_opportunity_id}, pre_sales: ${preSalesStage || 'N/A'})`);
      }
    }
  }
  
  // ONLY fall back to existing open opportunity when there's NO SF Opportunity ID
  // This prevents incorrectly linking meetings with different SF IDs to the same opportunity
  // Also skip for internal meetings (no opportunity needed)
  if (!isInternalMeeting && !linkedOpportunityId && !meeting.salesforce_opportunity_id) {
    // No SF Opportunity ID - try to link to most recent OPEN opportunity for this account
    // Use neq (not equal) instead of not.is - the 'is' operator only works with null/true/false
    const { data: accountOpportunities } = await gateway
      .from('opportunities')
      .select('id, stage')
      .eq('account_id', accountId)
      .neq('stage', 'closed_won')
      .neq('stage', 'closed_lost')
      .order('created_at', { ascending: false })
      .limit(1)
      .execute();
    
    linkedOpportunityId = accountOpportunities?.[0]?.id || null;
    
    if (linkedOpportunityId) {
      report(log, 'step', `Linked to most recent open opportunity: ${linkedOpportunityId}`);
      
      // Update stages if AI detected them
      if (preSalesStage || salesStage) {
        const updateData: Record<string, string> = {};
        if (preSalesStage) updateData.pre_sales_stage = preSalesStage;
        if (salesStage) updateData.sales_stage = salesStage;
        updateData.last_meeting_at = meeting.start_time;
        
        await gateway
          .from('opportunities')
          .update(updateData)
          .eq('id', linkedOpportunityId)
          .execute();
        report(log, 'step', `Updated opportunity stages and last_meeting_at`);
      }
    } else {
      // No existing open opportunity - auto-create one and flag for compliance review
      report(log, 'step', 'No existing opportunity found - creating new opportunity (pending compliance)');
      
      const oppName =
        meeting.title.replace(/\s*\|\s*/g, ' - ').replace(/Pendo/gi, '').trim() ||
        `Opportunity from ${format(new Date(meeting.start_time), 'MMM d, yyyy')}`;

      // Extract additional context for the opportunity description
      const painPoints = analysis?.insights?.painPoints || [];
      const useCases = analysis?.insights?.useCases || [];
      
      let description = `⚠️ AUTO-CREATED - Pending Compliance Review\n\nCreated from Momentum meeting: ${meeting.title}\nMeeting Date: ${format(new Date(meeting.start_time), 'MMM d, yyyy')}`;
      
      if (painPoints.length > 0) {
        description += `\n\nIdentified Pain Points:\n${painPoints.slice(0, 3).map((p: string) => `• ${p}`).join('\n')}`;
      }
      if (useCases.length > 0) {
        description += `\n\nPotential Use Cases:\n${useCases.slice(0, 3).map((u: string) => `• ${u}`).join('\n')}`;
      }

      const { data: newOpp, error: oppErr } = await gateway.from('opportunities').insert({
        account_id: accountId,
        name: oppName,
        description,
        stage: 'pending_compliance', // Flag as needing review
        priority: 'high', // High priority to ensure it gets reviewed
        pre_sales_stage: preSalesStage || 'Discovery',
        sales_stage: salesStage,
        last_meeting_at: meeting.start_time,
      }).select('id').single();

      if (oppErr) {
        report(log, 'db_error', `Insert opportunity failed: ${getErrorMessage(oppErr)}`, 'error');
        // Non-fatal - continue without opportunity link
      } else {
        linkedOpportunityId = newOpp?.id || null;
        report(log, 'step', `Created opportunity (pending compliance): ${oppName} (id: ${linkedOpportunityId})`);
      }
    }
  }

  // Link meeting attendees to the resolved opportunity (so Opportunity tabs show stakeholders/team)
  // Note: email column is encrypted, so we must fetch all contacts and filter in memory
  if (linkedOpportunityId && externalAttendees.length > 0) {
    const attendeeEmails = new Set(
      externalAttendees
        .map((a: any) => String(a.email || '').toLowerCase().trim())
        .filter(Boolean)
    );

    if (attendeeEmails.size > 0) {
      // Fetch all unlinked contacts for this account (gateway decrypts email)
      const { data: unlinkedContacts } = await gateway
        .from('account_contacts')
        .select('id, email')
        .eq('account_id', accountId)
        .is('opportunity_id', null)
        .execute();

      // Find contacts that match attendee emails
      const contactsToLink = (unlinkedContacts || []).filter(c => 
        c.email && attendeeEmails.has(c.email.toLowerCase().trim())
      );

      // Update each matching contact
      for (const contact of contactsToLink) {
        const { error: linkErr } = await encryptedUpdate('account_contacts', contact.id, {
          opportunity_id: linkedOpportunityId,
        });
        if (linkErr) {
          report(log, 'db_error', `Link contact ${contact.id} to opportunity failed: ${linkErr.message}`, 'error');
        }
      }
      
      if (contactsToLink.length > 0) {
        report(log, 'step', `Linked ${contactsToLink.length} contacts to opportunity ${linkedOpportunityId}`);
      }
    }
  }

  // Also add internal attendees to opportunity_team_members if we have an opportunity
  if (internalAttendees.length > 0 && linkedOpportunityId) {
    report(log, 'step', `Adding ${internalAttendees.length} internal team members to opportunity`);
    
    for (const attendee of internalAttendees) {
      const { error: oppTeamErr } = await gateway.from('opportunity_team_members').upsert(
        {
          opportunity_id: linkedOpportunityId,
          team_member_email: attendee.email.toLowerCase(),
          role: 'participant',
          added_from_meeting_id: meeting.id,
        },
        { onConflict: 'opportunity_id,team_member_email' },
      ).execute();

      if (oppTeamErr) {
        report(log, 'db_error', `Upsert opportunity_team_members failed: ${getErrorMessage(oppTeamErr)}`, 'error');
        // Non-fatal - continue with import
      }
    }

    // Auto-assign Primary SE: if the opportunity has no primary_se_email,
    // check if any internal attendee holds the 'se' role and assign the first match
    try {
      const { data: oppForSE } = await gateway
        .from('opportunities')
        .select('primary_se_email')
        .eq('id', linkedOpportunityId)
        .single();

      if (!oppForSE?.primary_se_email) {
        // Collect internal attendee emails
        const internalEmails = internalAttendees
          .map((a: any) => String(a.email || '').toLowerCase().trim())
          .filter(Boolean);

        if (internalEmails.length > 0) {
          // Find profiles matching internal attendee emails
          const { data: matchingProfiles } = await supabase
            .from('profiles')
            .select('id, email')
            .in('email', internalEmails);

          if (matchingProfiles && matchingProfiles.length > 0) {
            // Check which of these profiles have the 'se' role
            const profileIds = matchingProfiles.map(p => p.id);
            const { data: seRoles } = await supabase
              .from('user_roles')
              .select('user_id')
              .in('user_id', profileIds)
              .eq('role', 'se');

            if (seRoles && seRoles.length > 0) {
              const seUserId = seRoles[0].user_id;
              const seProfile = matchingProfiles.find(p => p.id === seUserId);
              if (seProfile?.email) {
                await gateway
                  .from('opportunities')
                  .update({ primary_se_email: seProfile.email })
                  .eq('id', linkedOpportunityId)
                  .execute();
                report(log, 'step', `Auto-assigned Primary SE from attendees: ${seProfile.email}`);
              }
            }
          }
        }
      }
    } catch (seErr: any) {
      report(log, 'db_error', `SE auto-assignment check failed: ${seErr?.message}`, 'error');
      // Non-fatal
    }
  }

  const transcriptFileName = `momentum_${meeting.momentum_id}`;
  
  // Check if a transcript already exists for this meeting
  const { data: existingTranscript } = await gateway
    .from('transcript_reviews')
    .select('id')
    .eq('file_name', transcriptFileName)
    .maybeSingle();
  
  let transcriptReviewId: string | null = existingTranscript?.id || null;
  
  if (existingTranscript) {
    // Update existing transcript with new analysis
    report(log, 'step', `Updating existing transcript: ${transcriptFileName}`);
    const { error: updateErr } = await gateway
      .from('transcript_reviews')
      .update({
        extracted_technologies: analysis?.technologies ?? null,
        extracted_insights: {
          painPoints: analysis?.insights?.painPoints ?? analysis?.painPoints ?? [],
          useCases: analysis?.insights?.useCases ?? analysis?.useCases ?? [],
          competitorMentions: analysis?.insights?.competitorMentions ?? analysis?.competitorMentions ?? [],
          operationalMetrics: analysis?.operationalMetrics ?? [],
          commercialInsights: analysis?.commercialInsights ?? [],
          nextBestActions: analysis?.nbas ?? analysis?.nextBestActions ?? [],
          people: analysis?.people ?? [],
          detectionRuleMatches: analysis?.detectionRuleMatches ?? [],
          preSalesStageAssessment: analysis?.preSalesStageAssessment,
          salesStageAssessment: analysis?.salesStageAssessment,
          discoveryQuestions: analysis?.discoveryQuestions ?? [],
          meetingPurpose: analysis?.meetingPurpose ?? null,
        },
        call_summary: analysis?.callSummary ?? null,
        opportunity_id: linkedOpportunityId,
        last_analyzed_at: new Date().toISOString(),
        meeting_title: meeting.title,
        meeting_context: meetingContext,
        // Persist AI-classified meeting type + confidence
        ...(analysis?.meetingPurpose ? {
          meeting_type: analysis.meetingPurpose.meetingType,
          meeting_type_confidence: analysis.meetingPurpose.confidence,
        } : {}),
      })
      .eq('id', existingTranscript.id)
      .execute();
    
    if (updateErr) {
      report(log, 'db_error', `Update transcript_reviews failed: ${getErrorMessage(updateErr)}`, 'error');
      throw new Error(getErrorMessage(updateErr));
    }
  } else {
    // Create new transcript (using encrypted insert)
    // We don't store transcript_content here anymore - it lives in momentum_meetings
    // We link via momentum_meeting_id instead
    report(log, 'step', `Creating new transcript: ${transcriptFileName}`);
    const { data: reviewData, error: reviewErr } = await encryptedInsert('transcript_reviews', {
      // transcript_content omitted - content lives in momentum_meetings
      file_name: transcriptFileName,
      meeting_title: meeting.title,
      momentum_meeting_id: meeting.id, // Link to momentum_meetings for transcript content
      status: 'approved',
      final_account_id: accountId,
      opportunity_id: linkedOpportunityId,
      meeting_context: meetingContext,
      last_analyzed_at: new Date().toISOString(),
      extracted_technologies: analysis?.technologies ?? null,
      extracted_insights: {
        painPoints: analysis?.insights?.painPoints ?? analysis?.painPoints ?? [],
        useCases: analysis?.insights?.useCases ?? analysis?.useCases ?? [],
        competitorMentions: analysis?.insights?.competitorMentions ?? analysis?.competitorMentions ?? [],
        operationalMetrics: analysis?.operationalMetrics ?? [],
        commercialInsights: analysis?.commercialInsights ?? [],
        nextBestActions: analysis?.nbas ?? analysis?.nextBestActions ?? [],
        people: analysis?.people ?? [],
        detectionRuleMatches: analysis?.detectionRuleMatches ?? [],
        preSalesStageAssessment: analysis?.preSalesStageAssessment,
        salesStageAssessment: analysis?.salesStageAssessment,
        discoveryQuestions: analysis?.discoveryQuestions ?? [],
        meetingPurpose: analysis?.meetingPurpose ?? null,
      },
      call_summary: analysis?.callSummary ?? null,
      // Persist AI-classified meeting type + confidence
      ...(analysis?.meetingPurpose ? {
        meeting_type: analysis.meetingPurpose.meetingType,
        meeting_type_confidence: analysis.meetingPurpose.confidence,
      } : {}),
    });

    if (reviewErr) {
      report(log, 'db_error', `Insert transcript_reviews failed: ${reviewErr.message}`, 'error');
      throw reviewErr;
    }
    
    transcriptReviewId = (reviewData as any)?.id || null;
  }

  // Save detection rule matches to database and process their side-effects
  const detectionRuleMatches = analysis?.detectionRuleMatches ?? [];
  if (detectionRuleMatches.length > 0 && transcriptReviewId) {
    report(log, 'step', `Processing ${detectionRuleMatches.length} detection rule matches`);
    
    // Use the already-fetched opportunity ID
    
    for (const match of detectionRuleMatches) {
      if (!match.ruleId) continue;
      
      // Save the detection rule match
      const { data: savedMatch, error: matchErr } = await gateway
        .from('detection_rule_matches')
        .insert({
          rule_id: match.ruleId,
          transcript_id: transcriptReviewId,
          opportunity_id: linkedOpportunityId,
          confidence_score: match.confidence || 0.7,
          matched_phrases: match.matchedPhrases || [],
        })
        .select('id')
        .single();
      
      if (matchErr) {
        report(log, 'db_error', `Insert detection_rule_match failed: ${getErrorMessage(matchErr)}`, 'error');
        continue;
      }
      
      const matchId = savedMatch?.id;
      
      // Fetch the rule's unified actions from detection_rule_actions table
      const { data: ruleActions } = await gateway
        .from('detection_rule_actions')
        .select('id, action_type, action_config, target_entity, is_active, legacy_capture_field_id')
        .eq('rule_id', match.ruleId)
        .eq('is_active', true)
        .order('sort_order');
      
      // Process each action based on its type
      for (const action of ruleActions || []) {
        const config = action.action_config as Record<string, any>;
        
        switch (action.action_type) {
          case 'create_task': {
            // Create or update validation task from template if opportunity exists
            if (config.template_id && linkedOpportunityId) {
              const { data: template } = await gateway
                .from('validation_task_templates')
                .select('*')
                .eq('id', config.template_id)
                .single();
              
              if (template) {
                // Check if task already exists for this opportunity + template
                const { data: existingTask } = await gateway
                  .from('opportunity_validation_tasks')
                  .select('id, status')
                  .eq('opportunity_id', linkedOpportunityId)
                  .eq('template_id', template.id)
                  .maybeSingle();
                
                if (!existingTask) {
                  // Create new task
                  const initialStatus = config.auto_update_status || 'not_started';
                  await gateway.from('opportunity_validation_tasks').insert({
                    opportunity_id: linkedOpportunityId,
                    template_id: template.id,
                    module: template.module,
                    sub_module: template.sub_module,
                    activity: template.activity,
                    status: initialStatus,
                    owner: template.default_owner,
                    sort_order: template.sort_order,
                    completed_at: initialStatus === 'completed' ? new Date().toISOString() : null,
                  }).execute();
                  report(log, 'step', `Created validation task: ${template.activity} (status: ${initialStatus})`);
                } else if (config.auto_update_status && existingTask.status !== config.auto_update_status) {
                  // Update existing task status if auto_update_status is configured
                  const updateData: Record<string, any> = { status: config.auto_update_status };
                  if (config.auto_update_status === 'completed') {
                    updateData.completed_at = new Date().toISOString();
                  }
                  await gateway.from('opportunity_validation_tasks')
                    .update(updateData)
                    .eq('id', existingTask.id)
                    .execute();
                  report(log, 'step', `Updated validation task status: ${template.activity} → ${config.auto_update_status}`);
                }
              }
            }
            break;
          }
          
          case 'answer_question': {
            // Auto-populate readiness answers
            if (config.question_id && linkedOpportunityId && config.auto_answer) {
              await encryptedUpsert('opportunity_readiness_answers', {
                opportunity_id: linkedOpportunityId,
                question_id: config.question_id,
                answer: config.auto_answer,
                answer_json: config.auto_answer_json,
                confidence_score: match.confidence || 0.7,
                source: 'detection_rule',
                source_transcript_id: transcriptReviewId,
                notes: `Auto-populated from rule match: ${match.ruleName || match.ruleId}`,
              });
              report(log, 'step', `Auto-answered readiness question from rule: ${match.ruleName}`);
            }
            break;
          }
          
          case 'extract_data': {
            // Save captured insights from AI extraction
            const fieldName = config.field_name;
            const capturedValue = (match as any).capturedFields?.[fieldName];
            if (capturedValue && matchId) {
              await encryptedInsert('account_captured_insights', {
                account_id: accountId,
                opportunity_id: linkedOpportunityId,
                capture_field_id: action.legacy_capture_field_id || action.id,
                rule_match_id: matchId,
                source_transcript_id: transcriptReviewId,
                value: typeof capturedValue === 'string' ? capturedValue : null,
                value_json: typeof capturedValue === 'object' ? capturedValue : null,
                confidence_score: match.confidence || 0.7,
              });
              report(log, 'step', `Captured insight: ${fieldName}`);
            }
            break;
          }
          
          case 'create_nba': {
            // Create NBA from template config
            if (config.action_text) {
              // Calculate due date: use config.due_date, or default based on action type
              let dueDate = config.due_date || null;
              if (!dueDate) {
                const today = new Date();
                const actionType = config.nba_action_type || 'follow_up';
                // Default due dates based on action type
                const dueDateOffsets: Record<string, number> = {
                  follow_up_meeting: 3,       // 3 business days
                  send_content: 2,            // 1-2 business days
                  poc_setup: 10,              // 1-2 weeks
                  technical_deepdive: 7,      // 1 week
                  security_assessment: 14,    // 2-3 weeks
                  architecture_doc: 7,        // 1 week
                  integration_review: 7,      // 1 week
                  internal_discussion: 3,     // 3 business days
                  follow_up: 3,               // default follow-up
                };
                const offsetDays = dueDateOffsets[actionType] || 5;
                today.setDate(today.getDate() + offsetDays);
                dueDate = today.toISOString().split('T')[0];
              }
              
              await encryptedInsert('account_nbas', {
                account_id: accountId,
                opportunity_id: linkedOpportunityId,
                action: config.action_text,
                action_type: config.nba_action_type || 'follow_up',
                priority: config.priority || 'medium',
                status: 'pending',
                source_transcript_id: transcriptReviewId,
                due_date: dueDate,
              });
              report(log, 'step', `Created NBA from rule: ${config.action_text.substring(0, 50)}... (due: ${dueDate})`);
            }
            break;
          }
          
          case 'update_field': {
            // Update account or opportunity field
            // This replaces the legacy signal_field_name functionality
            if (config.field_name && config.field_value) {
              const targetTable = action.target_entity === 'opportunity' ? 'opportunities' : 'accounts';
              const targetId = action.target_entity === 'opportunity' ? linkedOpportunityId : accountId;
              
              if (targetId) {
                await gateway
                  .from(targetTable)
                  .update({ [config.field_name]: config.field_value })
                  .eq('id', targetId)
                  .execute();
                report(log, 'step', `Updated ${targetTable}.${config.field_name}`);
              }
            }
            break;
          }
        }
      }
    }
    
    report(log, 'step', `Processed ${detectionRuleMatches.length} detection rule matches`);
  }

  // Save extracted NBAs to account_nbas table for consistency
  // Note: analyze-transcript returns 'nbas' field, not 'nextBestActions'
  const extractedNBAs = analysis?.nbas ?? analysis?.nextBestActions ?? [];
  if (extractedNBAs.length > 0) {
    report(log, 'step', `Saving ${extractedNBAs.length} extracted NBAs with deduplication`);

    const nbaStats = await saveNBAsWithDeduplication(
      accountId,
      extractedNBAs,
      linkedOpportunityId,
      transcriptReviewId
    );

    report(log, 'step', `NBAs: ${nbaStats.created} new, ${nbaStats.skipped} skipped (duplicates)`);
  }

  // Save extracted metrics to account_metrics table with opportunity linkage
  const extractedMetrics = analysis?.operationalMetrics ?? [];
  if (extractedMetrics.length > 0) {
    report(log, 'step', `Saving ${extractedMetrics.length} extracted metrics to account_metrics`);

    for (const metric of extractedMetrics) {
      const { error: metricErr } = await encryptedUpsert('account_metrics', {
        account_id: accountId,
        opportunity_id: linkedOpportunityId,
        metric_name: metric.metricName,
        metric_value: metric.metricValue,
        metric_numeric_value: metric.metricNumericValue,
        metric_category: metric.metricCategory || 'general',
        confidence_score: metric.confidence,
        needs_review: metric.needsReview ?? false,
        context: metric.context,
        source: 'transcript_analysis',
        source_transcript_id: transcriptReviewId,
      });

      if (metricErr) {
        report(log, 'db_error', `Upsert account_metrics failed: ${metricErr.message}`, 'error');
      }
    }
    report(log, 'step', `Saved ${extractedMetrics.length} metrics`);
  }

  // Save extracted use cases and pain points with enrichment (merge similar items)
  const extractedUseCases = analysis?.insights?.useCases ?? [];
  const extractedPainPoints = analysis?.insights?.painPoints ?? [];
  
  if (extractedUseCases.length > 0 || extractedPainPoints.length > 0) {
    report(log, 'step', `Enriching ${extractedUseCases.length} use cases and ${extractedPainPoints.length} pain points`);

    // Transform to themed format
    const themedUseCases = extractedUseCases.map((uc: any) => {
      if (typeof uc === 'string') {
        return {
          description: uc,
          businessTheme: 'operational_efficiency',
          priority: 'medium' as const,
          confidence: 0.5,
        };
      }
      return {
        description: uc.description || uc.name || uc.useCase || uc,
        businessTheme: uc.businessTheme || 'operational_efficiency',
        priority: uc.priority || 'medium',
        confidence: uc.confidence || 0.5,
      };
    });

    const themedPainPoints = extractedPainPoints.map((pp: any) => {
      if (typeof pp === 'string') {
        return {
          description: pp,
          businessTheme: 'operational_efficiency',
          severity: 'medium' as const,
          confidence: 0.5,
        };
      }
      return {
        description: pp.description || pp,
        businessTheme: pp.businessTheme || 'operational_efficiency',
        severity: pp.severity || 'medium',
        confidence: pp.confidence || 0.5,
      };
    });

    const enrichmentStats = await saveInsightsWithEnrichment(
      accountId,
      themedPainPoints,
      themedUseCases,
      linkedOpportunityId,
      transcriptReviewId
    );

    report(log, 'step', `Use cases: ${enrichmentStats.useCases.created} new, ${enrichmentStats.useCases.merged} merged`);
    report(log, 'step', `Pain points: ${enrichmentStats.painPoints.created} new, ${enrichmentStats.painPoints.merged} merged`);
  }

  // Enrich existing contacts with AI-extracted stakeholder data
  const extractedPeople = analysis?.people ?? [];
  const externalPeople = extractedPeople.filter((p: any) => !p.isInternal);
  
  if (externalPeople.length > 0) {
    report(log, 'step', `Enriching ${externalPeople.length} contacts with AI stakeholder data`);
    
    for (const person of externalPeople) {
      // Try to find matching contact by email first, then by name
      const personEmail = person.email?.toLowerCase().trim();
      const personName = person.name?.trim();
      
      // Use gateway to get decrypted contact data for matching
      const { data: contacts } = await gateway
        .from('account_contacts')
        .select('id, email, name, champion_score, influence_level, sentiment')
        .eq('account_id', accountId)
        .execute();
      
      // Find best match
      const matchedContact = contacts?.find(c => 
        (personEmail && c.email?.toLowerCase() === personEmail) ||
        (personName && c.name?.toLowerCase() === personName.toLowerCase())
      );
      
      if (matchedContact) {
        // Build update object - only update if AI has data and existing is null/lower confidence
        const updates: Record<string, any> = {
          last_assessed_at: new Date().toISOString(),
          assessment_source: 'ai_transcript',
        };
        
        // Link to opportunity if we have one and contact isn't already linked
        if (linkedOpportunityId) {
          updates.opportunity_id = linkedOpportunityId;
        }
        
        // Update role if we have a better one
        if (person.role && person.role !== 'unknown') {
          updates.role = person.role;
        }
        
        // Update stakeholder type if detected
        if (person.stakeholderType && person.stakeholderType !== 'unknown') {
          updates.stakeholder_type = person.stakeholderType;
        }
        
        // Update champion score if higher than existing (or existing is null)
        if (person.championScore != null && (matchedContact.champion_score == null || person.championScore > matchedContact.champion_score)) {
          updates.champion_score = person.championScore;
        }
        
        // Update influence level if higher
        if (person.influenceLevel != null && (matchedContact.influence_level == null || person.influenceLevel > matchedContact.influence_level)) {
          updates.influence_level = person.influenceLevel;
        }
        
        // Update sentiment
        if (person.sentiment != null) {
          updates.sentiment = person.sentiment;
        }
        
        // Store advocacy and info sharing signals
        if (person.advocacySignals?.detected) {
          updates.advocacy_signals = person.advocacySignals;
        }
        if (person.infoSharingSignals?.detected) {
          updates.info_sharing_signals = person.infoSharingSignals;
        }
        
        const { error: contactUpdateErr } = await encryptedUpdate('account_contacts', matchedContact.id, updates);
        
        if (contactUpdateErr) {
          report(log, 'db_error', `Update contact failed: ${contactUpdateErr.message}`, 'error');
        } else {
          report(log, 'step', `Enriched contact: ${matchedContact.name || matchedContact.email}`);
          
          // Create a contact meeting snapshot to track score history over time
          const snapshotData: Record<string, any> = {
            contact_id: matchedContact.id,
            transcript_id: transcriptReviewId,
            opportunity_id: linkedOpportunityId || null,
            meeting_date: meeting.start_time || new Date().toISOString(),
            meeting_type: analysis?.meetingContext?.type || 'meeting',
            sentiment: person.sentiment ?? null,
            influence_level: person.influenceLevel ?? null,
            champion_score: person.championScore ?? null,
            notes: person.advocacySignals?.evidence?.slice(0, 500) || null,
            key_quotes: person.advocacySignals?.quotes?.slice(0, 3) || null,
            concerns_raised: person.infoSharingSignals?.concerns?.slice(0, 3) || null,
          };
          
          const { error: snapshotErr } = await encryptedInsert('contact_meeting_snapshots', snapshotData);
          if (snapshotErr) {
            report(log, 'db_error', `Insert contact snapshot failed: ${snapshotErr.message}`, 'error');
          }
        }
      } else if (personName) {
        // No matching contact found — create a new one from AI-extracted data
        report(log, 'step', `Creating new contact from AI extraction: ${personName}`);
        
        const newContact: Record<string, any> = {
          account_id: accountId,
          name: personName,
          is_internal: false,
          source: 'ai_transcript',
          assessment_source: 'ai_transcript',
          last_assessed_at: new Date().toISOString(),
        };

        if (personEmail) newContact.email = personEmail;
        if (linkedOpportunityId) newContact.opportunity_id = linkedOpportunityId;
        if (person.role && person.role !== 'unknown') newContact.role = person.role;
        if (person.stakeholderType && person.stakeholderType !== 'unknown') newContact.stakeholder_type = person.stakeholderType;
        if (person.championScore != null) newContact.champion_score = person.championScore;
        if (person.influenceLevel != null) newContact.influence_level = person.influenceLevel;
        if (person.sentiment != null) newContact.sentiment = person.sentiment;
        if (person.advocacySignals?.detected) newContact.advocacy_signals = person.advocacySignals;
        if (person.infoSharingSignals?.detected) newContact.info_sharing_signals = person.infoSharingSignals;

        const { error: createErr } = await encryptedInsert('account_contacts', newContact);
        if (createErr) {
          report(log, 'db_error', `Create contact from AI failed: ${createErr.message}`, 'error');
        } else {
          report(log, 'step', `Created new contact: ${personName}`);
        }
      }
    }
  }

  // Detect NBA completions from this transcript
  setProgress(onStage, onProgress, 'Detecting completed actions…', 92);
  report(log, 'step', 'Checking if any pending NBAs were addressed in this call');

  try {
    // Get pending NBAs for this account (use gateway for decrypted data)
    const { data: pendingNBAs } = await gateway
      .from('account_nbas')
      .select('id, action, action_type, notes')
      .eq('account_id', accountId)
      .eq('status', 'pending')
      .execute();

    if (pendingNBAs && pendingNBAs.length > 0) {
      // Get the account name for context
      const { data: accountData } = await supabase
        .from('accounts')
        .select('name')
        .eq('id', accountId)
        .single();

      // Call AI to detect completions
      const { data: completionData, error: completionError } = await supabase.functions.invoke('detect-nba-completion', {
        body: {
          transcript_content: transcript.slice(0, 15000),
          nbas: pendingNBAs,
          account_name: accountData?.name || 'Unknown',
        },
      });

      if (!completionError && completionData?.completions?.length > 0) {
        const completions = completionData.completions;

        // Auto-complete high confidence ones (>= 0.8), flag others as suggestions
        const highConfidence = completions.filter((c: any) => c.confidence >= 0.8);
        const suggestions = completions.filter((c: any) => c.confidence < 0.8 && c.confidence >= 0.5);

        if (highConfidence.length > 0) {
          await gateway
            .from('account_nbas')
            .update({ status: 'completed' })
            .in('id', highConfidence.map((c: any) => c.nba_id))
            .execute();
          report(log, 'step', `Auto-completed ${highConfidence.length} high-confidence NBAs`);
        }

        for (const suggestion of suggestions) {
          await gateway
            .from('account_nbas')
            .update({
              auto_complete_confidence: suggestion.confidence,
              auto_complete_reason: suggestion.reason,
              auto_completed_by_transcript_id: transcriptReviewId,
            })
            .eq('id', suggestion.nba_id)
            .execute();
        }

        if (suggestions.length > 0) {
          report(log, 'step', `Flagged ${suggestions.length} NBAs for review`);
        }
      }
    }
  } catch (nbaErr) {
    // Non-fatal - log but continue
    report(log, 'step', `NBA completion detection failed (non-fatal): ${nbaErr}`);
  }

  // Auto-deduplicate NBAs after analysis to prevent accumulation
  try {
    const { count: pendingCount } = await supabase
      .from('account_nbas')
      .select('id', { count: 'exact', head: true })
      .eq('account_id', accountId)
      .eq('status', 'pending');

    // Only trigger dedup if there are more than 15 pending NBAs
    if (pendingCount && pendingCount > 15) {
      report(log, 'step', `Triggering NBA dedup — ${pendingCount} pending actions is too many`);
      await supabase.functions.invoke('deduplicate-nbas', {
        body: {
          accountId,
          opportunityId: linkedOpportunityId || undefined,
          dryRun: false,
          staleDays: 21,
          autoCompleteStale: true,
          deduplicateNBAs: true,
        },
      });
      report(log, 'step', 'NBA deduplication completed');
    }
  } catch (dedupErr) {
    report(log, 'step', `NBA dedup failed (non-fatal): ${dedupErr}`);
  }

  // Save activity to opportunity_activities for KPI tracking
  if (linkedOpportunityId) {
    setProgress(onStage, onProgress, 'Saving activity…', 85);
    report(log, 'step', 'Saving activity for KPI tracking');

    // Determine activity type - check AI detection first, fallback to local inference
    let activityTypeName: string;
    
    const contentTypeDetection = analysis?.contentTypeDetection;
    if (contentTypeDetection?.contentType === 'email' && contentTypeDetection?.emailType) {
      // Map AI email type to our activity type names
      const emailTypeMap: Record<string, string> = {
        'followup': 'email_followup',
        'proposal': 'email_proposal', 
        'introduction': 'email_introduction',
        'status_update': 'email_status_update',
        'technical': 'email_technical',
        'scheduling': 'email_scheduling',
        'other': 'email_other',
      };
      activityTypeName = emailTypeMap[contentTypeDetection.emailType] || 'email_followup';
      report(log, 'step', `AI detected email type: ${contentTypeDetection.emailType} -> ${activityTypeName}`);
    } else {
      // Use local inference for meetings or when AI didn't detect email
      activityTypeName = inferActivityType(meeting.title, transcript.slice(0, 5000));
      report(log, 'step', `Inferred activity type: ${activityTypeName}`);
    }
    
    // Get the activity type ID
    const { data: activityType } = await supabase
      .from('activity_types')
      .select('id')
      .eq('name', activityTypeName)
      .single();

    if (activityType) {
      // Get AE and SE emails from opportunity
      const { data: oppData } = await supabase
        .from('opportunities')
        .select('owner_email, primary_se_email')
        .eq('id', linkedOpportunityId)
        .single();

      // Calculate overall sentiment from people extracted
      let sentimentScore: number | null = null;
      let sentimentLabel: string | null = null;
      const people = analysis?.people || [];
      const externalPeople = people.filter((p: any) => !p.isInternal && p.sentiment !== null);
      if (externalPeople.length > 0) {
        const avgSentiment = externalPeople.reduce((sum: number, p: any) => sum + (p.sentiment || 50), 0) / externalPeople.length;
        sentimentScore = Math.round(avgSentiment);
        sentimentLabel = sentimentScore >= 70 ? 'positive' : sentimentScore >= 40 ? 'neutral' : 'negative';
      }

      // Use transcript_id for conflict detection - each transcript should have one activity
      const { error: activityErr } = await supabase
        .from('opportunity_activities')
        .upsert({
          opportunity_id: linkedOpportunityId,
          account_id: accountId,
          transcript_id: transcriptReviewId,
          activity_type_id: activityType.id,
          activity_date: meeting.start_time,
          title: meeting.title,
          sentiment_score: sentimentScore,
          sentiment_label: sentimentLabel,
          confidence_score: 0.8,
          detection_source: 'ai',
          ae_email: oppData?.owner_email || null,
          se_email: oppData?.primary_se_email || meeting.host_email || null,
        }, { 
          onConflict: 'transcript_id',
          ignoreDuplicates: false  // Update if transcript already has an activity
        });

      if (activityErr) {
        report(log, 'db_error', `Insert opportunity_activities failed: ${activityErr.message}`, 'error');
        // Non-fatal
      } else {
        report(log, 'step', `Saved activity: ${activityTypeName}`);
      }
    }
  }

  // ===== PASS 3: Strategic Insights Synthesis =====
  setProgress(onStage, onProgress, 'Synthesizing strategic insights (Pass 3 of 4)…', 88);
  report(log, 'step', 'Synthesizing strategic insights for account');
  
  try {
    const { data: synthesisResult, error: synthesisError } = await supabase.functions.invoke('synthesize-account-insights', {
      body: { accountId }
    });
    
    if (synthesisError) {
      report(log, 'function_error', `Strategic synthesis failed: ${synthesisError.message}`, 'error');
      // Non-fatal - continue with import
    } else {
      const themes = synthesisResult?.themes_created || 0;
      const summary = synthesisResult?.summary_created ? 'yes' : 'no';
      report(log, 'step', `Strategic synthesis complete: ${themes} themes, summary=${summary}`);
    }
  } catch (synthesisErr: any) {
    report(log, 'function_error', `Strategic synthesis exception: ${synthesisErr?.message || synthesisErr}`, 'error');
    // Non-fatal - continue
  }

  // ===== PASS 4: Technical Readiness Extraction =====
  if (linkedOpportunityId) {
    setProgress(onStage, onProgress, 'Extracting technical readiness (Pass 4 of 4)…', 92);
    report(log, 'step', 'Extracting technical readiness answers from transcript');
    
    try {
      // Fetch all readiness questions (universal + all deployment types)
      const { data: categories, error: catError } = await supabase
        .from('readiness_template_categories')
        .select('id, name')
        .order('sort_order');
      
      if (catError) {
        report(log, 'db_error', `Fetch readiness categories failed: ${catError.message}`, 'error');
      } else if (categories && categories.length > 0) {
        const categoryIds = categories.map(c => c.id);
        
        const { data: questions, error: qError } = await supabase
          .from('readiness_template_questions')
          .select('id, question, category_id')
          .in('category_id', categoryIds)
          .order('sort_order');
        
        if (qError) {
          report(log, 'db_error', `Fetch readiness questions failed: ${qError.message}`, 'error');
        } else if (questions && questions.length > 0) {
          // Build question list with category names
          const categoryMap = new Map(categories.map(c => [c.id, c.name]));
          const allQuestions = questions.map(q => ({
            id: q.id,
            question: q.question,
            category_name: categoryMap.get(q.category_id) || 'Unknown',
          }));
          
          report(log, 'step', `Analyzing transcript against ${allQuestions.length} readiness questions`);
          
          const { data: readinessResult, error: readinessError } = await supabase.functions.invoke('extract-readiness-answers', {
            body: { 
              transcript: analysisTranscript, 
              opportunityId: linkedOpportunityId, 
              questions: allQuestions 
            },
          });
          
          if (readinessError) {
            report(log, 'function_error', `Readiness extraction failed: ${readinessError.message}`, 'error');
          } else {
            const extractedCount = readinessResult?.extracted_count || 0;
            const deploymentTypes = readinessResult?.detected_deployment_types?.length || 0;
            report(log, 'step', `Readiness extraction complete: ${extractedCount} answers, ${deploymentTypes} deployment types detected`);
          }
        }
      }
    } catch (readinessErr: any) {
      report(log, 'function_error', `Readiness extraction exception: ${readinessErr?.message || readinessErr}`, 'error');
      // Non-fatal - continue
    }
  }

  // ===== PASS 5: Activity Signal Detection & Enrichment =====
  setProgress(onStage, onProgress, 'Detecting activity signals…', 95);
  report(log, 'step', 'Running signal detection and enrichment on transcript');
  
  try {
    // Fire and forget - don't block import completion
    supabase.functions.invoke('enrich-transcript', {
      body: { transcriptReviewId }
    }).then((result) => {
      if (result.error) {
        console.error('[Import] Enrichment failed:', result.error);
      } else {
        console.log('[Import] Enrichment completed for transcript:', transcriptReviewId);
      }
    }).catch(err => {
      console.error('[Import] Enrichment exception:', err);
    });
    
    report(log, 'step', 'Signal detection queued');
  } catch (enrichErr: any) {
    report(log, 'function_error', `Signal detection exception: ${enrichErr?.message || enrichErr}`, 'error');
    // Non-fatal - continue
  }

  // Only mark as 'imported' at the very end after everything succeeds
  setProgress(onStage, onProgress, 'Finalizing…', 98);
  report(log, 'step', 'Marking meeting as imported');

  const { error: finalUpdateError } = await gateway
    .from('momentum_meetings')
    .update({
      status: 'imported',
      imported_at: new Date().toISOString(),
    })
    .eq('id', meeting.id)
    .execute();

  if (finalUpdateError) {
    report(log, 'db_error', `Final status update failed: ${getErrorMessage(finalUpdateError)}`, 'error');
    throw new Error(getErrorMessage(finalUpdateError));
  }

  report(log, 'step', 'Import complete');
  setProgress(onStage, onProgress, 'Complete', 100);

  return { analysis };
}

/**
 * Revert a meeting back to 'pending' status (used on import failure)
 */
export async function revertMeetingToPending(meetingId: string, log?: ImportLogger) {
  report(log, 'step', `Reverting meeting ${meetingId} to pending`);
  const { error } = await gateway
    .from('momentum_meetings')
    .update({ status: 'pending', matched_account_id: null })
    .eq('id', meetingId)
    .execute();
  
  if (error) {
    report(log, 'db_error', `Failed to revert meeting: ${getErrorMessage(error)}`, 'error');
  }
}

export async function directImportMomentumMeetingById(meetingId: string) {
  const { data: meeting, error: meetingError } = await gateway
    .from('momentum_meetings')
    .select(MEETING_CORE_SELECT)
    .eq('id', meetingId)
    .single();

  if (meetingError) throw new Error(getErrorMessage(meetingError));

  const core = meeting as MomentumMeetingCore;

  let accountId = core.matched_account_id ?? null;

  // 1) Salesforce account ID match
  if (!accountId && core.salesforce_account_id) {
    const { data: account } = await gateway
      .from('accounts')
      .select('id')
      .eq('salesforce_account_id', core.salesforce_account_id)
      .maybeSingle();
    accountId = account?.id ?? null;
  }

  // 2) Heuristic match (title + attendee domain)
  if (!accountId) {
    const { data: accounts, error: accountsErr } = await gateway
      .from('accounts')
      .select('id,name,salesforce_account_id')
      .order('name', { ascending: true })
      .execute();

    if (accountsErr) throw new Error(getErrorMessage(accountsErr));

    const titleLower = (core.title || '').toLowerCase();
    const nameHit = accounts?.find((a: any) => titleLower.includes(a.name.toLowerCase()));
    if (nameHit) accountId = nameHit.id;

    if (!accountId) {
      const attendeesRaw: any = core.attendees ?? [];
      const attendees: any[] = Array.isArray(attendeesRaw) ? attendeesRaw : [];
      const externalDomains = attendees
        .filter((a: any) => !a?.isInternal)
        .map((a: any) => (a.email || '').split('@')[1]?.toLowerCase())
        .filter(Boolean) as string[];

      for (const domain of externalDomains) {
        const base = domain.split('.')[0];
        const hit = accounts?.find((a: any) => {
          const n = a.name.toLowerCase();
          return n.includes(base) || base.includes(n);
        });
        if (hit) {
          accountId = hit.id;
          break;
        }
      }

      // 3) If still no match, auto-create an account from the first external domain.
      if (!accountId && externalDomains.length > 0) {
        const base = externalDomains[0].split('.')[0];
        const name = base ? base.charAt(0).toUpperCase() + base.slice(1) : '';

        if (name) {
          const { data: newAccount, error: createErr } = await gateway
            .from('accounts')
            .insert({ name, salesforce_account_id: core.salesforce_account_id })
            .select('id')
            .single();

          if (createErr) throw new Error(getErrorMessage(createErr));
          accountId = newAccount.id;
        }
      }
    }
  }

  if (!accountId) {
    throw new Error('Could not determine an account for this meeting');
  }

  const { data: tData, error: tErr } = await gateway
    .from('momentum_meetings')
    .select('transcript_content')
    .eq('id', meetingId)
    .single();

  if (tErr) throw new Error(getErrorMessage(tErr));
  const transcript = (tData?.transcript_content ?? '') as string;

  if (!transcript) {
    throw new Error('No transcript available for this meeting');
  }

  return await importMomentumMeetingSteps({ meeting: core, transcript, accountId });
}

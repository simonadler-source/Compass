import { useEffect, useMemo, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { toast } from "sonner";

import { gateway, getErrorMessage } from "@/lib/apiGateway";
import type { AccountListItem, MomentumMeeting, SuggestedAccount } from "@/features/momentum/types";
import { importMomentumMeetingSteps, revertMeetingToPending, type ImportLogLevel } from "./importMomentumMeeting";
import { detectMeetingContext, PENDO_INTERNAL_ACCOUNT_ID, PENDO_INTERNAL_ACCOUNT_NAME } from "@/hooks/useMeetingTypeSelector";
type ImportEvent = {
  at: string;
  stage: string;
  detail?: string;
  level: "info" | "error";
};

export type AccountMatchCandidate = {
  account: AccountListItem;
  score: number;
  reason: string;
};

export type MeetingImportController = {
  isOpen: boolean;
  meeting: MomentumMeeting | null;
  accounts: AccountListItem[] | undefined;

  /** Derived name we think the meeting belongs to (used for matching/creation). */
  derivedAccountName: string | null;
  derivedAccountReason: string | null;
  matchCandidates: AccountMatchCandidate[];

  suggestedAccount: SuggestedAccount;

  selectedAccountId: string;
  setSelectedAccountId: (val: string) => void;

  createNewAccount: boolean;
  setCreateNewAccount: (val: boolean) => void;

  newAccountName: string;
  setNewAccountName: (val: string) => void;

  isImporting: boolean;
  importStage: string;
  importProgress: number;

  /** Diagnostics shown in the dialog so it's obvious what happened (even if network calls never start). */
  events: ImportEvent[];
  lastError: string | null;
  clearDiagnostics: () => void;

  canImport: boolean;

  open: (meeting: MomentumMeeting) => void;
  close: () => void;
  runImport: () => Promise<void>;
};

type Args = {
  accounts: AccountListItem[] | undefined;
};

function capitalizeDomain(domain: string) {
  return domain.charAt(0).toUpperCase() + domain.slice(1);
}

function normalizeName(name: string) {
  return name.trim().toLowerCase().replace(/\s+/g, " ");
}

function deriveFromTitle(title: string) {
  const raw = title.split("|")[0].split("-")[0].split(":")[0].trim();
  const cleaned = raw
    .replace(/\b(qbr|intro|discovery|kickoff|sync|standup|weekly|monthly)\b/gi, "")
    .replace(/\s+/g, " ")
    .trim();
  return cleaned || raw;
}

export function useMeetingImport({ accounts }: Args): MeetingImportController {
  const queryClient = useQueryClient();

  const [isOpen, setIsOpen] = useState(false);
  const [meeting, setMeeting] = useState<MomentumMeeting | null>(null);

  const [selectedAccountId, setSelectedAccountId] = useState<string>("");
  const [createNewAccount, setCreateNewAccount] = useState(false);
  const [newAccountName, setNewAccountName] = useState("");

  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState<number>(0);
  const [importStage, setImportStage] = useState<string>("");

  const [events, setEvents] = useState<ImportEvent[]>([]);
  const [lastError, setLastError] = useState<string | null>(null);
  const [didAutoPopulate, setDidAutoPopulate] = useState(false);

  const logEvent = (
    stage: string,
    detail?: string,
    level: ImportEvent["level"] = "info",
  ) => {
    const evt: ImportEvent = { at: new Date().toISOString(), stage, detail, level };
    setEvents((prev) => [...prev, evt]);
    if (level === "error") {
      // eslint-disable-next-line no-console
      console.error("[meetingImport]", stage, detail);
    } else {
      // eslint-disable-next-line no-console
      console.debug("[meetingImport]", stage, detail);
    }
  };

  const clearDiagnostics = () => {
    setEvents([]);
    setLastError(null);
  };

  const suggestedAccount: SuggestedAccount = useMemo(() => {
    if (!meeting || !accounts) return null;

    // Method 1: Match by Salesforce Account ID
    if (meeting.salesforce_account_id) {
      const sfMatch = accounts.find((a) => a.salesforce_account_id === meeting.salesforce_account_id);
      if (sfMatch) return { kind: "account", account: sfMatch, reason: "Salesforce ID match" };
    }

    // Method 2: Match by company name in title or attendee email domains
    const externalAttendees = (meeting.attendees || []).filter((a: any) => !a.isInternal);
    const externalDomains = externalAttendees
      .map((a: any) => a.email?.split("@")[1]?.toLowerCase())
      .filter(Boolean);

    for (const account of accounts) {
      const accountNameLower = account.name.toLowerCase();

      if (meeting.title.toLowerCase().includes(accountNameLower)) {
        return { kind: "account", account, reason: "Name found in meeting title" };
      }

      for (const domain of externalDomains) {
        const domainBase = domain.split(".")[0];
        if (accountNameLower.includes(domainBase) || domainBase.includes(accountNameLower)) {
          return { kind: "account", account, reason: `Email domain match (${domain})` };
        }
      }
    }

    // Method 3: Suggest based on external attendee company name
    if (externalAttendees.length > 0) {
      const firstExternal = externalAttendees[0];
      const domain = firstExternal.email?.split("@")[1]?.split(".")[0];
      if (domain) {
        return {
          kind: "suggestedName",
          suggestedName: capitalizeDomain(domain),
          reason: "Based on attendee email",
        };
      }
    }

    return null;
  }, [meeting, accounts]);

  const derivedAccountName = useMemo(() => {
    if (!meeting) return null;
    if (suggestedAccount?.kind === "account") return suggestedAccount.account.name;
    if (suggestedAccount?.kind === "suggestedName") return suggestedAccount.suggestedName;

    const titleGuess = deriveFromTitle(meeting.title);
    return titleGuess || null;
  }, [meeting, suggestedAccount]);

  const derivedAccountReason = useMemo(() => {
    if (!meeting) return null;
    if (suggestedAccount?.kind === "account") return `Matched existing account (${suggestedAccount.reason})`;
    if (suggestedAccount?.kind === "suggestedName") return suggestedAccount.reason;
    return "Derived from meeting title";
  }, [meeting, suggestedAccount]);

  const matchCandidates: AccountMatchCandidate[] = useMemo(() => {
    if (!meeting || !accounts || !derivedAccountName) return [];

    const needle = normalizeName(derivedAccountName);
    if (!needle) return [];

    const scored = accounts
      .map((a) => {
        const hay = normalizeName(a.name);
        if (!hay) return null;

        if (hay === needle) {
          return { account: a, score: 100, reason: "Exact name match" } satisfies AccountMatchCandidate;
        }
        if (hay.includes(needle) || needle.includes(hay)) {
          return { account: a, score: 85, reason: "Partial name match" } satisfies AccountMatchCandidate;
        }
        const firstWord = needle.split(" ")[0];
        if (firstWord.length >= 4 && hay.includes(firstWord)) {
          return { account: a, score: 70, reason: `Contains '${firstWord}'` } satisfies AccountMatchCandidate;
        }
        return null;
      })
      .filter(Boolean) as AccountMatchCandidate[];

    return scored.sort((a, b) => b.score - a.score).slice(0, 5);
  }, [meeting, accounts, derivedAccountName]);

  // Auto-populate selection when the dialog opens so the primary CTA is actionable.
  useEffect(() => {
    if (!isOpen || !meeting || !accounts) return;
    if (didAutoPopulate) return;

    // Check if this is an all-internal meeting (no external attendees)
    const attendees = meeting.attendees || [];
    const detected = detectMeetingContext(attendees);
    if (detected.context.startsWith('internal_')) {
      // Auto-select the Pendo (Internal) account
      const pendoAccount = accounts.find(a => a.id === PENDO_INTERNAL_ACCOUNT_ID);
      if (pendoAccount) {
        setSelectedAccountId(pendoAccount.id);
        setCreateNewAccount(false);
        logEvent("account_preselected", `internal_meeting → Pendo (Internal) account`);
        setDidAutoPopulate(true);
        return;
      }
    }

    // Prefer explicit suggestedAccount match first
    if (suggestedAccount?.kind === "account") {
      setSelectedAccountId(suggestedAccount.account.id);
      setCreateNewAccount(false);
      logEvent("account_preselected", `suggested=${suggestedAccount.account.id}`);
      setDidAutoPopulate(true);
      return;
    }

    // Next best: top scored candidate (if any)
    if (matchCandidates.length > 0 && matchCandidates[0].score >= 85) {
      setSelectedAccountId(matchCandidates[0].account.id);
      setCreateNewAccount(false);
      logEvent("account_preselected", `candidate=${matchCandidates[0].account.id} score=${matchCandidates[0].score}`);
      setDidAutoPopulate(true);
      return;
    }

    // Else: propose a new account name
    if (derivedAccountName) {
      setCreateNewAccount(true);
      setNewAccountName(derivedAccountName);
      setSelectedAccountId("");
      logEvent("account_name_suggested", `new='${derivedAccountName}'`);
      setDidAutoPopulate(true);
      return;
    }

    setDidAutoPopulate(true);
  }, [isOpen, meeting, accounts, didAutoPopulate, suggestedAccount, matchCandidates, derivedAccountName]);

  const importMutation = useMutation({
    mutationFn: async ({ meeting, accountId }: { meeting: MomentumMeeting; accountId: string }) => {
      if (!meeting.transcript_content) {
        logEvent("validation_error", "No transcript available", "error");
        throw new Error("No transcript available for this meeting");
      }

      // Use the centralized import function with proper step-by-step execution
      const result = await importMomentumMeetingSteps({
        meeting: {
          id: meeting.id,
          momentum_id: meeting.momentum_id,
          title: meeting.title,
          start_time: meeting.start_time,
          end_time: meeting.end_time,
          host_email: meeting.host_email,
          host_name: meeting.host_name,
          attendees: meeting.attendees,
          salesforce_account_id: meeting.salesforce_account_id,
          salesforce_opportunity_id: meeting.salesforce_opportunity_id,
          status: meeting.status,
          matched_account_id: meeting.matched_account_id,
          imported_at: meeting.imported_at,
          ignored_at: meeting.ignored_at,
          created_at: meeting.created_at,
          opportunity_id: meeting.opportunity_id,
        },
        transcript: meeting.transcript_content,
        accountId,
        onStage: setImportStage,
        onProgress: setImportProgress,
        log: (stage: string, detail?: string, level: ImportLogLevel = "info") => {
          logEvent(stage, detail, level);
        },
      });

      return result;
    },
    onSuccess: () => {
      setLastError(null);
      setImportStage("Done");
      setImportProgress(100);
      logEvent("success", "Import completed");

      toast.success("Meeting imported and analyzed successfully");
      queryClient.invalidateQueries({ queryKey: ["momentum-meetings"] });
      queryClient.invalidateQueries({ queryKey: ["accounts-list-full"] });
      close();
    },
    onError: async (error: any, variables) => {
      const msg = error?.message || "Unknown error";
      setLastError(msg);
      setImportStage("Failed");
      setImportProgress(0);
      setIsImporting(false);
      logEvent("failed", msg, "error");
      
      // Revert meeting to pending so user can retry
      if (variables?.meeting?.id) {
        await revertMeetingToPending(variables.meeting.id, logEvent);
      }
      
      toast.error(`Import failed: ${msg}`);
    },
  });

  const open = (m: MomentumMeeting) => {
    clearDiagnostics();
    setDidAutoPopulate(false);
    logEvent("open", `meetingId=${m.id}`);

    setMeeting(m);
    setCreateNewAccount(false);
    setNewAccountName("");
    setImportStage("Ready");
    setImportProgress(0);
    setSelectedAccountId("");
    setIsOpen(true);

    toast.message("Import dialog opened", { duration: 1200 });
  };

  const close = () => {
    logEvent("close");
    setIsOpen(false);
    setMeeting(null);
    setSelectedAccountId("");
    setCreateNewAccount(false);
    setNewAccountName("");
    setImportStage("");
    setImportProgress(0);
    setIsImporting(false);
    setLastError(null);
  };

  const runImport = async () => {
    logEvent("runImport_clicked");

    if (!meeting) {
      setLastError("No meeting selected");
      logEvent("validation_error", "No meeting selected", "error");
      toast.error("No meeting selected");
      return;
    }

    setIsImporting(true);
    setImportStage("Determining account…");
    setImportProgress(4);

    try {
      let accountId = selectedAccountId;

      setImportStage("Matching accounts…");
      setImportProgress(8);
      logEvent("step", `derived='${derivedAccountName ?? "(none)"}'`);

      // PRIORITY 1: Check for existing account by Salesforce Account ID (prevents duplicates)
      if (!accountId && meeting.salesforce_account_id) {
        const { data: existingBySfId } = await gateway
          .from("accounts")
          .select("id, name")
          .eq("salesforce_account_id", meeting.salesforce_account_id)
          .maybeSingle();
        
        if (existingBySfId) {
          accountId = existingBySfId.id;
          logEvent("account_found_by_sf_id", `accountId=${accountId} name='${existingBySfId.name}'`);
        }
      }

      // PRIORITY 2: Use best matching candidate if score >= 85
      const best = matchCandidates[0];
      if (!accountId && !createNewAccount && best && best.score >= 85) {
        accountId = best.account.id;
        logEvent("account_auto_selected", `accountId=${accountId} score=${best.score}`);
      }

      // If no match was selected and we have a derived name, auto-create (only if user hasn't chosen a different path)
      const shouldAutoCreate = !accountId && !createNewAccount && !!derivedAccountName;

      if (shouldAutoCreate) {
        const name = derivedAccountName!.trim();
        setImportStage("Creating account…");
        setImportProgress(12);
        logEvent("step", `Auto-creating account name='${name}'`);

        // guard against creating duplicates when an exact match exists
        const exact = matchCandidates.find((c) => c.score === 100);
        if (exact) {
          accountId = exact.account.id;
          logEvent("account_auto_selected", `exactMatch=${accountId}`);
        } else {
          // Salesforce ID check already happened above, so just create
          const { data: newAccount, error: createError } = await gateway
            .from("accounts")
            .insert({
              name,
              salesforce_account_id: meeting.salesforce_account_id,
            })
            .select()
            .single();

          if (createError) {
            logEvent("db_error", `Create account failed: ${getErrorMessage(createError)}`, "error");
            throw new Error(getErrorMessage(createError));
          }

          accountId = newAccount.id;
          logEvent("account_created", `accountId=${accountId}`);
        }
      }

      if (createNewAccount && !accountId) {
        const name = newAccountName.trim();
        if (!name) {
          setLastError("Missing new account name");
          logEvent("validation_error", "Missing new account name", "error");
          toast.error("Please enter an account name");
          return;
        }

        setImportStage("Creating account…");
        setImportProgress(12);
        logEvent("step", `Creating account name='${name}'`);

        // Salesforce ID check already happened above, so just create
        const { data: newAccount, error: createError } = await gateway
          .from("accounts")
          .insert({
            name,
            salesforce_account_id: meeting.salesforce_account_id,
          })
          .select()
          .single();

        if (createError) {
          logEvent("db_error", `Create account failed: ${getErrorMessage(createError)}`, "error");
          throw new Error(getErrorMessage(createError));
        }

        accountId = newAccount.id;
        logEvent("account_created", `accountId=${accountId}`);
      }

      if (!accountId) {
        setLastError("No account resolved");
        logEvent("validation_error", "No account resolved", "error");
        toast.error("Could not determine an account. Please pick one.");
        return;
      }

      setLastError(null);
      setImportStage("Starting import…");
      setImportProgress(14);

      await importMutation.mutateAsync({ meeting, accountId });
    } finally {
      setIsImporting(false);
    }
  };

  const canImport = !!meeting && !isImporting;

  return {
    isOpen,
    meeting,
    accounts,

    derivedAccountName,
    derivedAccountReason,
    matchCandidates,

    suggestedAccount,

    selectedAccountId,
    setSelectedAccountId,

    createNewAccount,
    setCreateNewAccount,

    newAccountName,
    setNewAccountName,

    isImporting,
    importStage,
    importProgress,

    events,
    lastError,
    clearDiagnostics,

    canImport,

    open,
    close,
    runImport,
  };
}

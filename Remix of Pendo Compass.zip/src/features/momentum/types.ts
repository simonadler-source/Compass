export type MomentumAttendee = {
  name?: string;
  email?: string;
  isInternal?: boolean;
  [key: string]: any;
};

export type MomentumMeeting = {
  id: string;
  momentum_id: string;
  title: string;
  start_time: string;
  end_time: string | null;
  host_email: string | null;
  host_name: string | null;
  attendees: MomentumAttendee[];
  transcript_content: string | null;
  salesforce_account_id: string | null;
  salesforce_opportunity_id: string | null;
  status: string;
  matched_account_id: string | null;
  imported_at: string | null;
  ignored_at: string | null;
  created_at: string;
  opportunity_id: string | null;
};

export type AccountListItem = {
  id: string;
  name: string;
  salesforce_account_id: string | null;
};

export type SuggestedAccount =
  | {
      kind: "account";
      account: AccountListItem;
      reason: string;
    }
  | {
      kind: "suggestedName";
      suggestedName: string;
      reason: string;
    }
  | null;

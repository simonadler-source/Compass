/**
 * Shared transcript analysis utility
 * 
 * Uses the streaming endpoint for real-time progress updates.
 * All transcript analysis in the app should go through this function.
 */

import type {
  AnalyzeTranscriptOptions,
  AnalyzeTranscriptResult,
  AnalysisResult,
  AnalysisProgress,
} from './types';

const MAX_TRANSCRIPT_LENGTH = 120000;

/**
 * Normalize the unified analysis result to the expected AnalysisResult format.
 * Maps pass results from DB-driven pipeline to frontend types.
 */
function normalizeUnifiedResult(rawResult: any): AnalysisResult {
  // The unified endpoint combines all pass results
  // Map from DB pass keys (core_extraction, stage_assessment) to frontend format
  
  return {
    // Core extraction pass
    technologies: rawResult.technologies || [],
    people: rawResult.people || [],
    nbas: rawResult.nbas || [],
    insights: {
      painPoints: rawResult.insights?.painPoints || rawResult.painPoints || [],
      useCases: rawResult.insights?.useCases || rawResult.useCases || [],
      competitorMentions: rawResult.insights?.competitorMentions || rawResult.competitorMentions || [],
    },
    
    // Account matching (if present)
    suggestedAccountId: rawResult.suggestedAccountId,
    suggestedAccountName: rawResult.suggestedAccountName,
    suggestedNewAccountName: rawResult.suggestedNewAccountName,
    accountConfidence: rawResult.accountConfidence || 0,
    accountExists: rawResult.accountExists || false,
    
    // Stage assessment pass
    salesStage: rawResult.salesStageAssessment?.stage,
    salesStageReasoning: rawResult.salesStageAssessment?.reasoning,
    preSalesStage: rawResult.preSalesStageAssessment?.stage,
    preSalesStageReasoning: rawResult.preSalesStageAssessment?.reasoning,
    
    // Commercial insights from stage pass
    commercialInsights: rawResult.commercialInsights || [],
    operationalMetrics: rawResult.operationalMetrics || [],
    
    // Content type detection
    contentType: rawResult.contentTypeDetection,
    
    // Discovery questions (new from stage pass)
    discoveryQuestions: rawResult.discoveryQuestions,
    
    // Enrichment passes data
    detectionMatches: rawResult.detectionMatches,
    readinessAnswers: rawResult.readinessAnswers,
    productMentions: rawResult.productMentions,
    
    // Account synthesis pass
    strategicThemes: rawResult.strategicThemes,
    healthIndicators: rawResult.healthIndicators,
    
    // Enrichment status
    enrichmentQueued: rawResult.enrichmentQueued,
    
    // Meeting purpose
    meetingPurpose: rawResult.meetingPurpose,
    
    // Call summary
    callSummary: rawResult.callSummary,
  };
}

/**
 * Analyze a transcript using the streaming AI endpoint.
 * 
 * @param options - Analysis options including transcript and callbacks
 * @returns Promise with analysis result
 */
export async function analyzeTranscript(
  options: AnalyzeTranscriptOptions
): Promise<AnalyzeTranscriptResult> {
  const {
    transcript,
    transcriptReviewId,
    accountId,
    opportunityId,
    accounts = [],
    competitors = [],
    existingInsights,
    skipEnrichment = false,
    onProgress,
  } = options;

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

  if (!supabaseUrl || !supabaseKey) {
    return {
      success: false,
      analysis: null,
      error: 'Supabase configuration missing',
    };
  }

  // Truncate transcript if needed
  const analysisTranscript = transcript.length > MAX_TRANSCRIPT_LENGTH
    ? transcript.slice(0, MAX_TRANSCRIPT_LENGTH)
    : transcript;

  try {
    // Use unified-transcript-analysis which reads pipeline from DB
    const response = await fetch(`${supabaseUrl}/functions/v1/unified-transcript-analysis`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
        'apikey': supabaseKey,
      },
      body: JSON.stringify({
        transcript: analysisTranscript,
        transcriptReviewId,
        accountId,
        opportunityId,
        accounts,
        competitors,
        existingInsights,
        skipEnrichment,
        streaming: true,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Analysis request failed:', response.status, errorText);
      return {
        success: false,
        analysis: null,
        error: `Analysis failed: ${response.status}`,
      };
    }

    const reader = response.body?.getReader();
    if (!reader) {
      return {
        success: false,
        analysis: null,
        error: 'No response stream',
      };
    }

    // Parse SSE stream
    const decoder = new TextDecoder();
    let buffer = '';
    let analysis: AnalysisResult | null = null;
    let lastError: string | null = null;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n\n');
      buffer = lines.pop() || '';

      for (const chunk of lines) {
        if (!chunk.trim()) continue;

        // Parse SSE format: "event: type\ndata: json"
        const eventMatch = chunk.match(/^event: (\w+)\ndata: (.+)$/s);
        if (!eventMatch) continue;

        const [, eventType, dataStr] = eventMatch;
        
        try {
          const data = JSON.parse(dataStr);

          switch (eventType) {
            case 'progress':
              if (onProgress) {
                onProgress({
                  pass: data.pass,
                  totalPasses: data.totalPasses,
                  stage: data.stage,
                  passKey: data.passKey,
                  progress: data.progress,
                });
              }
              break;

            case 'pass_complete':
              // Track pass results for aggregation
              console.log(`Pass ${data.passKey} complete:`, data.result);
              break;

            case 'complete':
              // Unified analysis complete - normalize result
              analysis = normalizeUnifiedResult(data.result);
              console.log('Analysis complete, pipeline used:', data.pipelineUsed);
              break;

            case 'core_complete':
              // Legacy event - still support for backward compat
              analysis = data.result as AnalysisResult;
              if (data.enrichmentQueued) {
                analysis.enrichmentQueued = true;
              }
              break;

            case 'pass_error':
              console.warn(`Pass ${data.passKey} failed:`, data.error);
              break;

            case 'error':
              lastError = data.error || data.message || 'Unknown error';
              console.error('Stream error:', lastError);
              break;

            case 'done':
              // Stream complete
              break;
          }
        } catch (parseError) {
          console.warn('Failed to parse SSE event:', chunk);
        }
      }
    }

    // Process any remaining buffer
    if (buffer.trim()) {
      const eventMatch = buffer.match(/^event: (\w+)\ndata: (.+)$/s);
      if (eventMatch) {
        const [, eventType, dataStr] = eventMatch;
        try {
          const data = JSON.parse(dataStr);
          if (eventType === 'core_complete') {
            analysis = data.result as AnalysisResult;
          } else if (eventType === 'error') {
            lastError = data.message;
          }
        } catch {
          // Ignore parse errors in final buffer
        }
      }
    }

    if (lastError && !analysis) {
      return {
        success: false,
        analysis: null,
        error: lastError,
      };
    }

    if (!analysis) {
      return {
        success: false,
        analysis: null,
        error: 'No analysis result received',
      };
    }

    // Normalize the result structure - handle both flat and nested insights
    const rawAnalysis = analysis as any;
    const normalizedAnalysis: AnalysisResult = {
      technologies: analysis.technologies || [],
      people: analysis.people || [],
      nbas: analysis.nbas || [],
      insights: {
        painPoints: analysis.insights?.painPoints || rawAnalysis.painPoints || [],
        useCases: analysis.insights?.useCases || rawAnalysis.useCases || [],
        competitorMentions: analysis.insights?.competitorMentions || rawAnalysis.competitorMentions || [],
      },
      suggestedAccountId: analysis.suggestedAccountId,
      suggestedAccountName: analysis.suggestedAccountName,
      suggestedNewAccountName: analysis.suggestedNewAccountName,
      accountConfidence: analysis.accountConfidence || 0,
      accountExists: analysis.accountExists || false,
      salesStage: analysis.salesStage,
      salesStageReasoning: analysis.salesStageReasoning,
      preSalesStage: analysis.preSalesStage,
      preSalesStageReasoning: analysis.preSalesStageReasoning,
      commercialInsights: analysis.commercialInsights || [],
      operationalMetrics: analysis.operationalMetrics || [],
      contentType: analysis.contentType,
      enrichmentQueued: analysis.enrichmentQueued,
      meetingPurpose: rawAnalysis.meetingPurpose || analysis.meetingPurpose,
      callSummary: rawAnalysis.callSummary || analysis.callSummary,
    };

    return {
      success: true,
      analysis: normalizedAnalysis,
    };
  } catch (error) {
    console.error('Analysis error:', error);
    return {
      success: false,
      analysis: null,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

// Re-export types for convenience
export type {
  AnalyzeTranscriptOptions,
  AnalyzeTranscriptResult,
  AnalysisResult,
  AnalysisProgress,
  ExtractedTechnology,
  ExtractedPerson,
  NextBestAction,
  CommercialInsight,
  OperationalMetric,
  TranscriptInsights,
} from './types';

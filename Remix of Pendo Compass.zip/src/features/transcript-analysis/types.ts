// Shared types for transcript analysis

export interface AnalysisProgress {
  pass: number;
  totalPasses: number;
  stage: string;
  passKey?: string;
  progress: number;
}

export interface ExtractedTechnology {
  name: string;
  category?: string;
  context?: string;
  confidence: number;
  suggestedLayer?: string;
  relationshipStatus?: string;
}

export interface ExtractedPerson {
  name: string;
  role?: string;
  email?: string;
  isInternal?: boolean;
  company?: string;
  stakeholderType?: string;
  influenceLevel?: number;
  sentiment?: number;
  championScore?: number;
  advocacySignals?: string[];
  infoSharingSignals?: string[];
}

export interface NextBestAction {
  action: string;
  actionType?: string;
  priority?: string;
  reasoning?: string;
  dueDate?: string;
  deliveryMethod?: string;
}

export interface CommercialInsight {
  type: 'strength' | 'weakness' | 'opportunity' | 'threat';
  description: string;
  confidence?: number;
}

export interface OperationalMetric {
  metricName: string;
  metricValue: string;
  metricNumericValue?: number;
  metricCategory?: string;
  context?: string;
  confidence?: number;
}

export interface ContentTypeDetection {
  type: string;
  subType?: string;
  confidence: number;
}

export interface MeetingPurposeClassification {
  meetingType: string;
  confidence: number;
  reasoning: string;
  secondaryPurposes?: string[];
}

export interface TranscriptInsights {
  painPoints: string[];
  useCases: string[];
  competitorMentions: string[];
}

export interface DetectionMatch {
  ruleId: string;
  ruleName: string;
  confidence: number;
  matchedPhrases?: string[];
  capturedFields?: Record<string, any>;
}

export interface ReadinessAnswer {
  questionId: string;
  answer: string;
  confidence: number;
  source?: string;
}

export interface ProductMention {
  product: string;
  context: string;
  sentiment?: string;
  usageLevel?: string;
}

export interface StrategicTheme {
  themeName: string;
  themeType: 'pain' | 'use_case' | 'priority';
  description: string;
  impactLevel: 'high' | 'medium' | 'low';
  itemCount: number;
  supportingEvidence: string[];
}

export interface CallSummaryAttendee {
  name: string;
  role?: string;
}

export interface CallSummaryNextStep {
  action: string;
  owner?: string;
}

export interface CallSummaryThemeSection {
  title: string;
  content: string;
}

export interface CallSummary {
  quickRecap: string;
  themeSections: CallSummaryThemeSection[];
  nextSteps: CallSummaryNextStep[];
  attendees?: {
    internal?: CallSummaryAttendee[];
    external?: CallSummaryAttendee[];
  };
  durationMinutes?: number;
}

export interface HealthIndicator {
  indicator: string;
  status: 'positive' | 'neutral' | 'negative';
  evidence: string;
}

export interface DiscoveryQuestion {
  question: string;
  category: string;
  functionalArea?: string;
  context?: string;
}

export interface AnalysisResult {
  // Core extraction pass
  technologies: ExtractedTechnology[];
  people: ExtractedPerson[];
  nbas: NextBestAction[];
  insights: TranscriptInsights;
  
  // Account matching
  suggestedAccountId?: string | null;
  suggestedAccountName?: string | null;
  suggestedNewAccountName?: string | null;
  accountConfidence?: number;
  accountExists?: boolean;
  
  // Stage assessment pass
  salesStage?: number;
  salesStageReasoning?: string;
  preSalesStage?: string;
  preSalesStageReasoning?: string;
  
  // Commercial insights from stage pass
  commercialInsights?: CommercialInsight[];
  operationalMetrics?: OperationalMetric[];
  discoveryQuestions?: DiscoveryQuestion[];
  
  // Content type
  contentType?: ContentTypeDetection;
  
  // Enrichment detection pass
  detectionMatches?: DetectionMatch[];
  
  // Enrichment readiness pass  
  readinessAnswers?: ReadinessAnswer[];
  productMentions?: ProductMention[];
  
  // Account synthesis pass
  strategicThemes?: StrategicTheme[];
  healthIndicators?: HealthIndicator[];
  
  // Enrichment status (for async processing)
  enrichmentQueued?: boolean;
  
  // Meeting purpose classification
  meetingPurpose?: MeetingPurposeClassification;

  // Structured call summary
  callSummary?: CallSummary;
}

export interface AnalyzeTranscriptOptions {
  transcript: string;
  transcriptReviewId?: string;
  accountId?: string;
  opportunityId?: string;
  accounts?: Array<{ id: string; name: string; industry?: string }>;
  competitors?: Array<{ id: string; name: string }>;
  existingInsights?: Partial<TranscriptInsights>;
  skipEnrichment?: boolean;
  onProgress?: (progress: AnalysisProgress) => void;
}

export interface AnalyzeTranscriptResult {
  success: boolean;
  analysis: AnalysisResult | null;
  error?: string;
}

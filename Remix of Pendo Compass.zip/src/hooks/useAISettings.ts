import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';

export type AIProvider = 'lovable' | 'gemini';

export function useAISettings() {
  const queryClient = useQueryClient();

  const { data: aiProvider, isLoading } = useQuery({
    queryKey: ['ai-settings', 'ai_provider'],
    queryFn: async () => {
      const result = await gateway.from('ai_settings')
        .select('setting_value')
        .eq('setting_key', 'ai_provider')
        .single()
        .execute();

      if (result.error) {
        console.error('Error fetching AI provider:', result.error);
        return 'lovable' as AIProvider;
      }

      return ((result.data as any)?.setting_value || 'lovable') as AIProvider;
    },
  });

  const updateProvider = useMutation({
    mutationFn: async (provider: AIProvider) => {
      const result = await gateway.from('ai_settings')
        .update({ 
          setting_value: provider,
          updated_at: new Date().toISOString()
        })
        .eq('setting_key', 'ai_provider')
        .execute();

      if (result.error) throw new Error(result.error.message);
      return provider;
    },
    onSuccess: (provider) => {
      queryClient.invalidateQueries({ queryKey: ['ai-settings'] });
      toast.success(`AI provider switched to ${provider === 'lovable' ? 'Lovable AI' : 'Google Gemini'}`);
    },
    onError: (error: any) => {
      toast.error('Failed to update AI provider: ' + error.message);
    },
  });

  return {
    aiProvider: aiProvider || 'lovable',
    isLoading,
    updateProvider: updateProvider.mutate,
    isUpdating: updateProvider.isPending,
  };
}

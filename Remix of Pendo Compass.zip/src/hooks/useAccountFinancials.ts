import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useWhitespaceRevenue } from '@/hooks/useModulePricing';

export interface PipelineByStage {
  stage: string;
  count: number;
  value: number;
  weightedValue: number;
}

export interface AccountFinancials {
  // Current ARR (from closed won opportunities)
  currentArr: number;
  
  // Pipeline - open opportunities (not closed won/lost)
  pipelineTotal: number;
  pipelineWeighted: number;
  pipelineByStage: PipelineByStage[];
  openOppCount: number;
  
  // Whitespace
  whitespaceRevenue: number;
  
  // Combined potential
  totalPotential: number; // currentArr + whitespace
}

export interface AggregateFinancials {
  totalArr: number;
  totalPipeline: number;
  totalWeightedPipeline: number;
  totalWhitespace: number;
  pipelineByStage: PipelineByStage[];
  accountCount: number;
}

// Canonical sales stage labels
// Stage 0 - Qualification, Stage 1 - Discovery, Stage 2 - Solution, Stage 3 - Proof, 
// Stage 4 - Negotiate, Stage 5 - Sales Won, Stage 6 - Closed Won, Closed Lost
const SALES_STAGE_LABELS: Record<string, string> = {
  'stage_0': 'Qualification',
  'stage_1': 'Discovery',
  'stage_2': 'Solution',
  'stage_2.5': 'Solution',
  'stage_3': 'Proof',
  'stage_3.5': 'Proof',
  'stage_4': 'Negotiate',
  'stage_5': 'Sales Won',
  'stage_5_sales_won': 'Sales Won',
  'stage_6': 'Closed Won',
  'stage_6_closed_won': 'Closed Won',
  'closed_lost': 'Closed Lost',
  'closed_won': 'Closed Won',
  'disqualified': 'Disqualified',
  'identified': 'Identified',
  'discovery': 'Discovery',
  'solution': 'Solution',
  'proof': 'Proof',
  'negotiate': 'Negotiate',
  'qualification': 'Qualification',
};

// Convert raw stage value to display label
function getStageLabel(stage: string | null): string {
  if (!stage) return 'Unknown';
  // Check if it's a raw stage value that needs mapping
  if (SALES_STAGE_LABELS[stage]) {
    return SALES_STAGE_LABELS[stage];
  }
  // If it's already a label (like "Discovery"), return as-is
  return stage;
}

// Stage weights for weighted pipeline calculation
const STAGE_WEIGHTS: Record<string, number> = {
  // Canonical sales stages (by label)
  'Qualification': 0.10,
  'Discovery': 0.20,
  'Solution': 0.40,
  'Proof': 0.60,
  'Negotiate': 0.75,
  'Sales Won': 0.90,
  'Closed Won': 1.00,
  'Closed Lost': 0.00,
  'Disqualified': 0.00,
  'Identified': 0.05,
  // Pre-sales stages (fallback)
  'Not Started': 0.10,
  'Demo': 0.30,
  'Proof - Scoping': 0.50,
  'Technical Win': 0.80,
  'Technical Loss': 0.00,
  'Stale / Not Active': 0.05,
  'Unqualified': 0.00,
  // Legacy/raw stage values (direct mapping)
  'stage_0': 0.10,
  'stage_1': 0.20,
  'stage_2': 0.40,
  'stage_3': 0.60,
  'stage_4': 0.75,
  'stage_5': 0.90,
  'stage_5_sales_won': 0.90,
  'stage_6': 1.00,
  'stage_6_closed_won': 1.00,
};

const CLOSED_WON_STAGES = ['Closed Won', 'closed_won', 'Won', 'Closed - Won', 'stage_6', 'stage_6_closed_won', 'Sales Won', 'stage_5_sales_won'];
const CLOSED_LOST_STAGES = ['Closed Lost', 'closed_lost', 'Lost', 'Closed - Lost', 'Technical Loss', 'Unqualified', 'Disqualified'];

function isClosedWon(stage: string | null): boolean {
  if (!stage) return false;
  return CLOSED_WON_STAGES.some(s => s.toLowerCase() === stage.toLowerCase());
}

function isClosedLost(stage: string | null): boolean {
  if (!stage) return false;
  return CLOSED_LOST_STAGES.some(s => s.toLowerCase() === stage.toLowerCase());
}

function isClosed(stage: string | null): boolean {
  return isClosedWon(stage) || isClosedLost(stage);
}

function getStageWeight(stage: string | null): number {
  if (!stage) return 0.2; // Default weight for unknown stages
  // Try exact match first (including raw stage values)
  if (STAGE_WEIGHTS[stage] !== undefined) return STAGE_WEIGHTS[stage];
  // Try the label version
  const label = getStageLabel(stage);
  if (STAGE_WEIGHTS[label] !== undefined) return STAGE_WEIGHTS[label];
  // Try case-insensitive match
  const lower = stage.toLowerCase();
  for (const [key, weight] of Object.entries(STAGE_WEIGHTS)) {
    if (key.toLowerCase() === lower) return weight;
  }
  // Default for unknown open stages
  return 0.25;
}

interface OpportunityData {
  id: string;
  account_id: string;
  value: number | null;
  stage: string | null;
  sales_stage: string | null;
  pre_sales_stage: string | null;
}

export function useAccountFinancials(accountId: string) {
  // Fetch opportunities for this account
  const { data: opportunities, isLoading: isLoadingOpps } = useQuery({
    queryKey: ['account-financials-opps', accountId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('opportunities')
        .select('id, account_id, value, stage, sales_stage, pre_sales_stage')
        .eq('account_id', accountId);
      if (error) throw error;
      return data as OpportunityData[];
    },
    enabled: !!accountId,
  });

  // Fetch account for MAU/employee data
  const { data: account, isLoading: isLoadingAccount } = useQuery({
    queryKey: ['account-financials-account', accountId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('accounts')
        .select('id, mau_count, base_mau_value, employee_count, arr')
        .eq('id', accountId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!accountId,
  });

  // Calculate effective MAU
  const effectiveMau = useMemo(() => {
    if (account?.mau_count && account.mau_count > 0) return account.mau_count;
    if (account?.employee_count && account.employee_count > 0) {
      return Math.round(account.employee_count * 0.2); // 20% estimate
    }
    return null;
  }, [account]);

  // Get whitespace calculation
  const { calculation: whitespaceCalc } = useWhitespaceRevenue(
    accountId,
    effectiveMau,
    account?.base_mau_value ?? null
  );

  // Calculate financials
  const financials = useMemo<AccountFinancials>(() => {
    const result: AccountFinancials = {
      currentArr: 0,
      pipelineTotal: 0,
      pipelineWeighted: 0,
      pipelineByStage: [],
      openOppCount: 0,
      whitespaceRevenue: 0,
      totalPotential: 0,
    };

    if (!opportunities) return result;

    const stageMap = new Map<string, { count: number; value: number; weightedValue: number }>();

    for (const opp of opportunities) {
      const value = opp.value ?? 0;
      // Use sales_stage, fallback to pre_sales_stage, then stage
      const effectiveStage = opp.sales_stage || opp.pre_sales_stage || opp.stage || 'Unknown';

      if (isClosedWon(effectiveStage)) {
        result.currentArr += value;
      } else if (!isClosed(effectiveStage)) {
        // Open opportunity
        result.pipelineTotal += value;
        const weight = getStageWeight(effectiveStage);
        const weighted = value * weight;
        result.pipelineWeighted += weighted;
        result.openOppCount += 1;

        // Group by stage label (not raw value)
        const stageLabel = getStageLabel(effectiveStage);
        const existing = stageMap.get(stageLabel) || { count: 0, value: 0, weightedValue: 0 };
        existing.count += 1;
        existing.value += value;
        existing.weightedValue += weighted;
        stageMap.set(stageLabel, existing);
      }
    }

    // Define stage order for sorting
    const STAGE_ORDER = ['Identified', 'Qualification', 'Discovery', 'Solution', 'Proof', 'Negotiate', 'Sales Won'];
    
    // Convert stageMap to array and sort by stage order
    result.pipelineByStage = Array.from(stageMap.entries())
      .map(([stage, data]) => ({
        stage,
        count: data.count,
        value: data.value,
        weightedValue: data.weightedValue,
      }))
      .sort((a, b) => {
        const orderA = STAGE_ORDER.indexOf(a.stage);
        const orderB = STAGE_ORDER.indexOf(b.stage);
        // If both are in the order list, sort by order
        if (orderA >= 0 && orderB >= 0) return orderA - orderB;
        // If only one is in the list, prioritize it
        if (orderA >= 0) return -1;
        if (orderB >= 0) return 1;
        // Otherwise sort by value
        return b.value - a.value;
      });

    // Whitespace
    if (whitespaceCalc) {
      result.whitespaceRevenue = whitespaceCalc.platformCost + whitespaceCalc.mauCost + whitespaceCalc.totalModuleCost;
    }

    // Total potential = current ARR + whitespace opportunity
    result.totalPotential = result.currentArr + result.whitespaceRevenue;

    return result;
  }, [opportunities, whitespaceCalc]);

  return {
    financials,
    isLoading: isLoadingOpps || isLoadingAccount,
  };
}

// Hook to fetch financials for multiple accounts (for summary header)
export function useAggregateAccountFinancials(accountIds: string[]) {
  // Fetch all opportunities for these accounts
  const { data: opportunities, isLoading: isLoadingOpps } = useQuery({
    queryKey: ['aggregate-financials-opps', accountIds],
    queryFn: async () => {
      if (accountIds.length === 0) return [];
      const { data, error } = await supabase
        .from('opportunities')
        .select('id, account_id, value, stage, sales_stage, pre_sales_stage')
        .in('account_id', accountIds);
      if (error) throw error;
      return data as OpportunityData[];
    },
    enabled: accountIds.length > 0,
  });

  // Fetch all accounts for whitespace data
  const { data: accounts, isLoading: isLoadingAccounts } = useQuery({
    queryKey: ['aggregate-financials-accounts', accountIds],
    queryFn: async () => {
      if (accountIds.length === 0) return [];
      const { data, error } = await supabase
        .from('accounts')
        .select('id, mau_count, base_mau_value, employee_count, arr')
        .in('id', accountIds);
      if (error) throw error;
      return data;
    },
    enabled: accountIds.length > 0,
  });

  // Calculate aggregate financials
  const aggregate = useMemo<AggregateFinancials>(() => {
    const result: AggregateFinancials = {
      totalArr: 0,
      totalPipeline: 0,
      totalWeightedPipeline: 0,
      totalWhitespace: 0,
      pipelineByStage: [],
      accountCount: accountIds.length,
    };

    if (!opportunities) return result;

    const stageMap = new Map<string, { count: number; value: number; weightedValue: number }>();

    for (const opp of opportunities) {
      const value = opp.value ?? 0;
      const effectiveStage = opp.sales_stage || opp.pre_sales_stage || opp.stage || 'Unknown';

      if (isClosedWon(effectiveStage)) {
        result.totalArr += value;
      } else if (!isClosed(effectiveStage)) {
        result.totalPipeline += value;
        const weight = getStageWeight(effectiveStage);
        const weighted = value * weight;
        result.totalWeightedPipeline += weighted;

        // Group by stage label (not raw value)
        const stageLabel = getStageLabel(effectiveStage);
        const existing = stageMap.get(stageLabel) || { count: 0, value: 0, weightedValue: 0 };
        existing.count += 1;
        existing.value += value;
        existing.weightedValue += weighted;
        stageMap.set(stageLabel, existing);
      }
    }

    // Define stage order for sorting
    const STAGE_ORDER = ['Identified', 'Qualification', 'Discovery', 'Solution', 'Proof', 'Negotiate', 'Sales Won'];
    
    result.pipelineByStage = Array.from(stageMap.entries())
      .map(([stage, data]) => ({
        stage,
        count: data.count,
        value: data.value,
        weightedValue: data.weightedValue,
      }))
      .sort((a, b) => {
        const orderA = STAGE_ORDER.indexOf(a.stage);
        const orderB = STAGE_ORDER.indexOf(b.stage);
        if (orderA >= 0 && orderB >= 0) return orderA - orderB;
        if (orderA >= 0) return -1;
        if (orderB >= 0) return 1;
        return b.value - a.value;
      });

    // Note: For aggregate whitespace, we'd need to run whitespace calc per account
    // This is expensive, so we'll use a simpler estimate or skip for now
    // TODO: Could add batch whitespace calculation

    return result;
  }, [opportunities, accounts, accountIds.length]);

  return {
    aggregate,
    isLoading: isLoadingOpps || isLoadingAccounts,
  };
}

// Calculate financials per account from pre-fetched opportunities
export function calculateAccountFinancialsFromOpps(
  accountId: string,
  opportunities: OpportunityData[],
  whitespaceRevenue: number = 0
): AccountFinancials {
  const result: AccountFinancials = {
    currentArr: 0,
    pipelineTotal: 0,
    pipelineWeighted: 0,
    pipelineByStage: [],
    openOppCount: 0,
    whitespaceRevenue,
    totalPotential: 0,
  };

  const accountOpps = opportunities.filter(o => o.account_id === accountId);
  const stageMap = new Map<string, { count: number; value: number; weightedValue: number }>();

  for (const opp of accountOpps) {
    const value = opp.value ?? 0;
    const effectiveStage = opp.sales_stage || opp.pre_sales_stage || opp.stage || 'Unknown';

    if (isClosedWon(effectiveStage)) {
      result.currentArr += value;
    } else if (!isClosed(effectiveStage)) {
      result.pipelineTotal += value;
      const weight = getStageWeight(effectiveStage);
      const weighted = value * weight;
      result.pipelineWeighted += weighted;
      result.openOppCount += 1;

      // Group by stage label (not raw value)
      const stageLabel = getStageLabel(effectiveStage);
      const existing = stageMap.get(stageLabel) || { count: 0, value: 0, weightedValue: 0 };
      existing.count += 1;
      existing.value += value;
      existing.weightedValue += weighted;
      stageMap.set(stageLabel, existing);
    }
  }

  // Define stage order for sorting
  const STAGE_ORDER = ['Identified', 'Qualification', 'Discovery', 'Solution', 'Proof', 'Negotiate', 'Sales Won'];
  
  result.pipelineByStage = Array.from(stageMap.entries())
    .map(([stage, data]) => ({
      stage,
      count: data.count,
      value: data.value,
      weightedValue: data.weightedValue,
    }))
    .sort((a, b) => {
      const orderA = STAGE_ORDER.indexOf(a.stage);
      const orderB = STAGE_ORDER.indexOf(b.stage);
      if (orderA >= 0 && orderB >= 0) return orderA - orderB;
      if (orderA >= 0) return -1;
      if (orderB >= 0) return 1;
      return b.value - a.value;
    });

  result.totalPotential = result.currentArr + result.whitespaceRevenue;

  return result;
}

import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';

export interface MetricHistoryPoint {
  id: string;
  metric_type: string;
  old_value: number | string | null;
  new_value: number | string;
  changed_at: string;
  change_source: string;
}

export interface AccountHealthMetrics {
  engagement: {
    current: number | null;
    status: 'cold' | 'warming' | 'warm' | 'hot' | 'champion' | null;
    trend: 'improving' | 'stable' | 'declining' | 'unknown';
    history: MetricHistoryPoint[];
    source: 'account' | 'synthesis' | null;
  };
  momentum: {
    current: number | null;
    status: 'cold' | 'warming' | 'warm' | 'hot' | 'champion' | null;
    trend: 'improving' | 'stable' | 'declining' | 'unknown';
    history: MetricHistoryPoint[];
    source: 'account' | 'synthesis' | null;
  };
  relationship: {
    current: string | null;
    status: 'cold' | 'warming' | 'warm' | 'hot' | 'champion' | null;
    trend: 'improving' | 'stable' | 'declining' | 'unknown';
    history: MetricHistoryPoint[];
    source: 'account' | 'synthesis' | null;
  };
}

const STATUS_ORDER = ['cold', 'warming', 'warm', 'hot', 'champion'];

// Mapping from synthesized health indicators to numeric scores
// Mapping from synthesized engagement trend to numeric scores
const ENGAGEMENT_LEVEL_SCORES: Record<string, number> = {
  // Legacy format from older synthesis
  'high': 85,
  'moderate': 55,
  'low': 25,
  // New format from enhanced synthesis
  'improving': 80,
  'stable': 55,
  'declining': 25
};

// Mapping from synthesized opportunity momentum to numeric scores
const MOMENTUM_LEVEL_SCORES: Record<string, number> = {
  'accelerating': 85,
  'steady': 55,
  'stalled': 30,
  'declining': 15
};

// Mapping from synthesized relationship health to status labels
const RELATIONSHIP_STATUS_MAP: Record<string, string> = {
  'strong': 'champion',
  'stable': 'warm',
  'at_risk': 'warming',
  'critical': 'cold',
  // Also map overall health indicators
  'healthy': 'hot',
};

function getStatusFromScore(score: number | null): 'cold' | 'warming' | 'warm' | 'hot' | 'champion' | null {
  if (score === null || score === undefined) return null;
  if (score >= 80) return 'champion';
  if (score >= 60) return 'hot';
  if (score >= 40) return 'warm';
  if (score >= 20) return 'warming';
  return 'cold';
}

function calculateTrend(history: MetricHistoryPoint[], metricType: 'score' | 'status'): 'improving' | 'stable' | 'declining' | 'unknown' {
  if (!history || history.length < 2) return 'unknown';
  
  // Sort by date, most recent first
  const sorted = [...history].sort((a, b) => 
    new Date(b.changed_at).getTime() - new Date(a.changed_at).getTime()
  );
  
  if (metricType === 'score') {
    // Compare first (most recent) and last (oldest) values
    const recentRaw = sorted[0].new_value;
    const oldRaw = sorted[sorted.length - 1].new_value;
    
    const recentValue = typeof recentRaw === 'number' 
      ? recentRaw 
      : parseFloat(String(recentRaw));
    const oldValue = typeof oldRaw === 'number'
      ? oldRaw
      : parseFloat(String(oldRaw));
    
    if (isNaN(recentValue) || isNaN(oldValue)) return 'unknown';
    
    const diff = recentValue - oldValue;
    if (diff > 5) return 'improving';
    if (diff < -5) return 'declining';
    return 'stable';
  } else {
    // For status, compare ordinal positions
    const recentStatus = String(sorted[0].new_value);
    const oldStatus = String(sorted[sorted.length - 1].new_value);
    
    const recentIndex = STATUS_ORDER.indexOf(recentStatus);
    const oldIndex = STATUS_ORDER.indexOf(oldStatus);
    
    if (recentIndex === -1 || oldIndex === -1) return 'unknown';
    
    if (recentIndex > oldIndex) return 'improving';
    if (recentIndex < oldIndex) return 'declining';
    return 'stable';
  }
}

interface HealthIndicators {
  // New enhanced fields
  relationshipHealth?: 'strong' | 'stable' | 'at_risk' | 'critical';
  engagementTrend?: 'improving' | 'stable' | 'declining';
  opportunityMomentum?: 'accelerating' | 'steady' | 'stalled' | 'declining';
  overallHealth?: 'healthy' | 'at_risk' | 'critical';
  competitiveThreat?: 'low' | 'medium' | 'high';
  expansionPotential?: 'low' | 'medium' | 'high';
  // Legacy fields for backwards compatibility
  engagementLevel?: 'high' | 'moderate' | 'low' | 'declining';
}

export function useAccountHealthMetrics(accountId: string | null) {
  return useQuery({
    queryKey: ['account-health-metrics', accountId],
    queryFn: async (): Promise<AccountHealthMetrics> => {
      if (!accountId) {
        return getEmptyMetrics();
      }

      // Fetch current account values
      const accountResult = await gateway.from('accounts')
        .select('engagement_score, momentum_score, relationship_status')
        .eq('id', accountId)
        .single()
        .execute();
      
      const account = accountResult.data as { 
        engagement_score: number | null; 
        momentum_score: number | null; 
        relationship_status: string | null;
      } | null;

      // Fetch synthesized health indicators from account_exec_summaries
      const summaryResult = await gateway.from('account_exec_summaries')
        .select('health_indicators')
        .eq('account_id', accountId)
        .maybeSingle()
        .execute();
      
      const healthIndicators = (summaryResult.data?.health_indicators || {}) as HealthIndicators;

      // Fetch metric history for this account
      const historyResult = await gateway.from('account_metric_history')
        .select('*')
        .eq('account_id', accountId)
        .in('metric_type', ['engagement_score', 'momentum_score', 'relationship_status'])
        .order('changed_at', { ascending: true })
        .execute();
      
      const history = (historyResult.data || []) as MetricHistoryPoint[];

      // Group history by metric type
      const engagementHistory = history.filter(h => h.metric_type === 'engagement_score');
      const momentumHistory = history.filter(h => h.metric_type === 'momentum_score');
      const relationshipHistory = history.filter(h => h.metric_type === 'relationship_status');

      // Derive baseline values from synthesis if account scores are null
      let engagementScore = account?.engagement_score ?? null;
      let engagementSource: 'account' | 'synthesis' | null = engagementScore !== null ? 'account' : null;
      if (engagementScore === null) {
        // Try new engagementTrend first, then legacy engagementLevel
        const engagementKey = healthIndicators.engagementTrend || healthIndicators.engagementLevel;
        if (engagementKey) {
          engagementScore = ENGAGEMENT_LEVEL_SCORES[engagementKey] ?? null;
          engagementSource = engagementScore !== null ? 'synthesis' : null;
        }
      }

      let momentumScore = account?.momentum_score ?? null;
      let momentumSource: 'account' | 'synthesis' | null = momentumScore !== null ? 'account' : null;
      if (momentumScore === null && healthIndicators.opportunityMomentum) {
        momentumScore = MOMENTUM_LEVEL_SCORES[healthIndicators.opportunityMomentum] ?? null;
        momentumSource = momentumScore !== null ? 'synthesis' : null;
      }

      let relationshipStatus = account?.relationship_status ?? null;
      let relationshipSource: 'account' | 'synthesis' | null = relationshipStatus !== null ? 'account' : null;
      if (relationshipStatus === null && healthIndicators.relationshipHealth) {
        relationshipStatus = RELATIONSHIP_STATUS_MAP[healthIndicators.relationshipHealth] ?? null;
        relationshipSource = relationshipStatus !== null ? 'synthesis' : null;
      }

      return {
        engagement: {
          current: engagementScore,
          status: getStatusFromScore(engagementScore),
          trend: calculateTrend(engagementHistory, 'score'),
          history: engagementHistory,
          source: engagementSource,
        },
        momentum: {
          current: momentumScore,
          status: getStatusFromScore(momentumScore),
          trend: calculateTrend(momentumHistory, 'score'),
          history: momentumHistory,
          source: momentumSource,
        },
        relationship: {
          current: relationshipStatus,
          status: relationshipStatus as 'cold' | 'warming' | 'warm' | 'hot' | 'champion' | null,
          trend: calculateTrend(relationshipHistory, 'status'),
          history: relationshipHistory,
          source: relationshipSource,
        },
      };
    },
    enabled: !!accountId,
    staleTime: 30000, // 30 seconds
  });
}

export function useOpportunityHealthMetrics(opportunityId: string | null) {
  return useQuery({
    queryKey: ['opportunity-health-metrics', opportunityId],
    queryFn: async (): Promise<AccountHealthMetrics> => {
      if (!opportunityId) {
        return getEmptyMetrics();
      }

      // Fetch current opportunity values
      const oppResult = await gateway.from('opportunities')
        .select('engagement_score, momentum_score, relationship_status')
        .eq('id', opportunityId)
        .single()
        .execute();
      
      const opp = oppResult.data as { 
        engagement_score: number | null; 
        momentum_score: number | null; 
        relationship_status: string | null;
      } | null;

      // Fetch metric history for this opportunity
      const historyResult = await gateway.from('opportunity_metric_history')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .in('metric_type', ['engagement_score', 'momentum_score', 'relationship_status'])
        .order('changed_at', { ascending: true })
        .execute();
      
      const history = (historyResult.data || []) as MetricHistoryPoint[];

      // Group history by metric type
      const engagementHistory = history.filter(h => h.metric_type === 'engagement_score');
      const momentumHistory = history.filter(h => h.metric_type === 'momentum_score');
      const relationshipHistory = history.filter(h => h.metric_type === 'relationship_status');

      return {
        engagement: {
          current: opp?.engagement_score ?? null,
          status: getStatusFromScore(opp?.engagement_score ?? null),
          trend: calculateTrend(engagementHistory, 'score'),
          history: engagementHistory,
          source: opp?.engagement_score !== null ? 'account' : null,
        },
        momentum: {
          current: opp?.momentum_score ?? null,
          status: getStatusFromScore(opp?.momentum_score ?? null),
          trend: calculateTrend(momentumHistory, 'score'),
          history: momentumHistory,
          source: opp?.momentum_score !== null ? 'account' : null,
        },
        relationship: {
          current: opp?.relationship_status ?? null,
          status: opp?.relationship_status as 'cold' | 'warming' | 'warm' | 'hot' | 'champion' | null,
          trend: calculateTrend(relationshipHistory, 'status'),
          history: relationshipHistory,
          source: opp?.relationship_status !== null ? 'account' : null,
        },
      };
    },
    enabled: !!opportunityId,
    staleTime: 30000, // 30 seconds
  });
}

function getEmptyMetrics(): AccountHealthMetrics {
  return {
    engagement: { current: null, status: null, trend: 'unknown', history: [], source: null },
    momentum: { current: null, status: null, trend: 'unknown', history: [], source: null },
    relationship: { current: null, status: null, trend: 'unknown', history: [], source: null },
  };
}

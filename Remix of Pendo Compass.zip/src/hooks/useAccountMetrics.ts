import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface AccountMetric {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  metric_name: string;
  metric_value: string | null;
  metric_numeric_value: number | null;
  metric_category: string;
  source: string;
  source_transcript_id: string | null;
  confidence_score: number;
  needs_review: boolean;
  context: string | null;
  mentioned_by_name: string | null;
  mentioned_by_email: string | null;
  mentioned_by_type: string | null;
  created_at: string;
  updated_at: string;
}

export const METRIC_CATEGORIES = [
  { value: 'support_tickets', label: 'Support Tickets' },
  { value: 'development_velocity', label: 'Development Velocity' },
  { value: 'user_metrics', label: 'User Metrics' },
  { value: 'resource_utilization', label: 'Resource Utilization' },
  { value: 'performance_sla', label: 'Performance/SLAs' },
  { value: 'general', label: 'General' },
] as const;

export function useAccountMetrics(accountId: string | null, opportunityId?: string) {
  return useQuery({
    queryKey: ['account-metrics', accountId, opportunityId],
    queryFn: async () => {
      if (!accountId) return [];

      let query = gateway.from('account_metrics')
        .select('*')
        .eq('account_id', accountId)
        .order('metric_category', { ascending: true });

      if (opportunityId) {
        query = query.eq('opportunity_id', opportunityId);
      }

      const result = await query.execute();
      if (result.error) throw new Error(result.error.message);
      return result.data as AccountMetric[];
    },
    enabled: !!accountId,
  });
}

export function useAccountMetricsNeedingReview(accountId?: string) {
  return useQuery({
    queryKey: ['account-metrics-review', accountId],
    queryFn: async () => {
      let query = gateway.from('account_metrics')
        .select('*, accounts(name)')
        .eq('needs_review', true)
        .order('created_at', { ascending: false });

      if (accountId) {
        query = query.eq('account_id', accountId);
      }

      const result = await query.execute();
      if (result.error) throw new Error(result.error.message);
      return result.data;
    },
  });
}

export function useCreateAccountMetric() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: {
      account_id: string;
      opportunity_id?: string;
      metric_name: string;
      metric_value: string;
      metric_numeric_value?: number;
      metric_category: string;
      source?: string;
      source_transcript_id?: string;
      confidence_score?: number;
      needs_review?: boolean;
      context?: string;
    }) => {
      const result = await gateway.from('account_metrics').insert(data).execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['account-metrics', variables.account_id] });
      toast.success('Metric added');
    },
    onError: (error) => {
      toast.error('Failed to add metric: ' + error.message);
    },
  });
}

export function useUpdateAccountMetric() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      accountId,
      ...data
    }: {
      id: string;
      accountId: string;
      metric_name?: string;
      metric_value?: string;
      metric_numeric_value?: number | null;
      metric_category?: string;
      needs_review?: boolean;
      context?: string;
    }) => {
      const result = await gateway.from('account_metrics')
        .update({ ...data, updated_at: new Date().toISOString() })
        .eq('id', id)
        .execute();
      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['account-metrics', variables.accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-metrics-review'] });
      toast.success('Metric updated');
    },
    onError: (error) => {
      toast.error('Failed to update metric: ' + error.message);
    },
  });
}

export function useDeleteAccountMetric() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId }: { id: string; accountId: string }) => {
      const result = await gateway.from('account_metrics')
        .delete()
        .eq('id', id)
        .execute();

      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['account-metrics', variables.accountId] });
      toast.success('Metric deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete metric: ' + error.message);
    },
  });
}

// Helper to upsert metrics from transcript analysis (merge with existing)
export function useSaveExtractedMetrics() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      accountId,
      opportunityId,
      transcriptId,
      metrics,
    }: {
      accountId: string;
      opportunityId?: string;
      transcriptId?: string;
      metrics: Array<{
        metricName: string;
        metricValue: string;
        metricNumericValue?: number | null;
        metricCategory: string;
        confidence: number;
        needsReview: boolean;
        context: string;
      }>;
    }) => {
      // Check for existing metrics to avoid duplicates
      const existingResult = await gateway.from('account_metrics')
        .select('metric_name, metric_value')
        .eq('account_id', accountId)
        .execute();

      const existingSet = new Set(
        (existingResult.data || []).map((m: any) => `${m.metric_name}::${m.metric_value}`)
      );

      // Filter out duplicates
      const newMetrics = metrics.filter(
        (m) => !existingSet.has(`${m.metricName}::${m.metricValue}`)
      );

      if (newMetrics.length === 0) return { inserted: 0 };

      let insertedCount = 0;
      for (const m of newMetrics) {
        const record = {
          account_id: accountId,
          opportunity_id: opportunityId,
          source_transcript_id: transcriptId,
          metric_name: m.metricName,
          metric_value: m.metricValue,
          metric_numeric_value: m.metricNumericValue,
          metric_category: m.metricCategory,
          confidence_score: m.confidence,
          needs_review: m.needsReview,
          context: m.context,
          source: 'transcript',
        };
        const result = await gateway.from('account_metrics').insert(record).execute();
        if (!result.error) insertedCount++;
      }
      return { inserted: insertedCount };
    },
    onSuccess: (result, variables) => {
      queryClient.invalidateQueries({ queryKey: ['account-metrics', variables.accountId] });
      if (result.inserted > 0) {
        toast.success(`${result.inserted} new metric(s) extracted`);
      }
    },
    onError: (error) => {
      toast.error('Failed to save metrics: ' + error.message);
    },
  });
}

import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';

export interface AccountPainPoint {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  pain_point: string;
  pain_category: string | null;      // New: TYPE of pain
  business_impact: string[] | null;  // New: potential outcomes
  business_theme: string | null;     // Legacy support
  theme_confidence: number | null;
  severity: 'high' | 'medium' | 'low';
  confidence_score: number | null;
  validation_count: number | null;
  last_validated_at: string | null;
  created_at: string;
}

export function useAccountPainPoints(accountId: string | null) {
  return useQuery({
    queryKey: ['account-pain-points', accountId],
    queryFn: async () => {
      if (!accountId) return [];
      
      const result = await gateway.from('account_pain_points')
        .select('*')
        .eq('account_id', accountId)
        .order('severity', { ascending: true })
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      // Sort by confidence_score as secondary sort
      const data = (result.data as AccountPainPoint[]) || [];
      return data.sort((a, b) => {
        if (a.severity !== b.severity) {
          const severityOrder = { high: 0, medium: 1, low: 2 };
          return severityOrder[a.severity] - severityOrder[b.severity];
        }
        return (b.confidence_score || 0) - (a.confidence_score || 0);
      });
    },
    enabled: !!accountId,
  });
}

// Group pain points by pain category (NEW - type of pain)
export function groupPainPointsByCategory(painPoints: AccountPainPoint[]): Record<string, AccountPainPoint[]> {
  const grouped: Record<string, AccountPainPoint[]> = {};
  
  for (const pp of painPoints) {
    const category = pp.pain_category || pp.business_theme || 'uncategorized';
    if (!grouped[category]) {
      grouped[category] = [];
    }
    grouped[category].push(pp);
  }
  
  return grouped;
}

// Legacy: Group pain points by business theme
export function groupPainPointsByTheme(painPoints: AccountPainPoint[]): Record<string, AccountPainPoint[]> {
  const grouped: Record<string, AccountPainPoint[]> = {};
  
  for (const pp of painPoints) {
    const theme = pp.business_theme || 'uncategorized';
    if (!grouped[theme]) {
      grouped[theme] = [];
    }
    grouped[theme].push(pp);
  }
  
  return grouped;
}

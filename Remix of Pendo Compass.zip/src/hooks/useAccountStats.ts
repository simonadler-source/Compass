import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { calculateReadinessScore, ReadinessAnswer } from '@/hooks/useOpportunityReadiness';

export type RAGStatus = 'green' | 'amber' | 'red' | 'unknown';

// Canonical sales stage labels
const SALES_STAGE_LABELS: Record<string, string> = {
  'stage_0': 'Qualification',
  'stage_1': 'Discovery',
  'stage_2': 'Solution',
  'stage_2.5': 'Solution',
  'stage_3': 'Proof',
  'stage_3.5': 'Proof',
  'stage_4': 'Negotiate',
  'stage_5': 'Sales Won',
  'stage_5_sales_won': 'Sales Won',
  'stage_6': 'Closed Won',
  'stage_6_closed_won': 'Closed Won',
  'closed_lost': 'Closed Lost',
  'closed_won': 'Closed Won',
  'disqualified': 'Disqualified',
  'identified': 'Identified',
  'discovery': 'Discovery',
  'solution': 'Solution',
  'proof': 'Proof',
  'negotiate': 'Negotiate',
  'qualification': 'Qualification',
};

// Convert raw stage value to display label
function getStageLabel(stage: string | null): string {
  if (!stage) return 'Unknown';
  if (SALES_STAGE_LABELS[stage]) return SALES_STAGE_LABELS[stage];
  return stage;
}

// Stage weights for weighted pipeline calculation
const STAGE_WEIGHTS: Record<string, number> = {
  // Canonical sales stages (by label)
  'Qualification': 0.10,
  'Discovery': 0.20,
  'Solution': 0.40,
  'Proof': 0.60,
  'Negotiate': 0.75,
  'Sales Won': 0.90,
  'Closed Won': 1.00,
  'Closed Lost': 0.00,
  'Disqualified': 0.00,
  'Identified': 0.05,
  // Pre-sales stages (fallback)
  'Not Started': 0.10,
  'Demo': 0.30,
  'Proof - Scoping': 0.50,
  'Technical Win': 0.80,
  'Technical Loss': 0.00,
  'Stale / Not Active': 0.05,
  'Unqualified': 0.00,
  // Legacy/raw stage values
  'stage_0': 0.10,
  'stage_1': 0.20,
  'stage_2': 0.40,
  'stage_3': 0.60,
  'stage_4': 0.75,
  'stage_5': 0.90,
  'stage_5_sales_won': 0.90,
  'stage_6': 1.00,
  'stage_6_closed_won': 1.00,
};

const CLOSED_WON_STAGES = ['Closed Won', 'closed_won', 'Won', 'Closed - Won', 'stage_6', 'stage_6_closed_won', 'Sales Won', 'stage_5_sales_won'];
const CLOSED_LOST_STAGES = ['Closed Lost', 'closed_lost', 'Lost', 'Closed - Lost', 'Technical Loss', 'Unqualified', 'Disqualified'];

function isClosedWon(stage: string | null): boolean {
  if (!stage) return false;
  return CLOSED_WON_STAGES.some(s => s.toLowerCase() === stage.toLowerCase());
}

function isClosedLost(stage: string | null): boolean {
  if (!stage) return false;
  return CLOSED_LOST_STAGES.some(s => s.toLowerCase() === stage.toLowerCase());
}

function isOpenStage(stage: string | null): boolean {
  if (!stage) return true; // Default to open
  return !isClosedWon(stage) && !isClosedLost(stage);
}

function getStageWeight(stage: string | null): number {
  if (!stage) return 0.2;
  if (STAGE_WEIGHTS[stage] !== undefined) return STAGE_WEIGHTS[stage];
  const label = getStageLabel(stage);
  if (STAGE_WEIGHTS[label] !== undefined) return STAGE_WEIGHTS[label];
  const lower = stage.toLowerCase();
  for (const [key, weight] of Object.entries(STAGE_WEIGHTS)) {
    if (key.toLowerCase() === lower) return weight;
  }
  return 0.25;
}

export interface AccountStats {
  accountId: string;
  openOpportunities: number;
  closedOpportunities: number;
  totalTranscripts: number;
  useCasesCount: number;
  nbasCount: number;
  openNbasCount: number;
  technologiesCount: number;
  functionalAreasCovered: number;
  totalFunctionalAreas: number;
  coveragePercent: number;
  contactsCount: number;
  // Financial metrics
  currentArr: number;           // From closed won opportunities
  totalOpportunityValue: number; // Total pipeline (open opportunities) - "Deal Value"
  pipelineWeighted: number;     // Weighted pipeline
  grossWhitespace: number;      // Full whitespace before subtracting modules in deals
  netWhitespace: number;        // Whitespace minus modules already in opportunities
  includedModuleIds: string[];  // All module IDs included in open opportunities
  whitespaceRevenue: number;    // Legacy field = netWhitespace for backwards compat
  // RAG status fields
  readinessStatus: RAGStatus;
  readinessPercent: number;
  metricsStatus: RAGStatus;
  metricsCount: number;
  economicBuyerStatus: RAGStatus;
  hasEconomicBuyer: boolean;
  // New readiness metrics (averaged across open opportunities)
  technicalReadinessPercent: number;  // Weighted readiness score using new formula
  commercialReadinessPercent: number; // Signal coverage %
}

interface UseCaseTemplateProduct {
  use_case_template_id: string;
  module_pricing_id: string;
}

interface UseCaseTemplate {
  id: string;
  name: string;
  functional_area_id: string;
  business_outcome: string | null;
}

interface ModulePricing {
  id: string;
  module_name: string;
  module_type: string;
  fixed_cost: number;
  per_mau_cost: number;
  mau_percentage: number;
  discount_percentage: number;
  functional_area_id: string | null;
}

export function useAccountStats(accountIds: string[]) {
  // Stabilize the query key by sorting
  const sortedIds = [...accountIds].sort();
  const queryKey = ['account-stats', sortedIds.join(',')];
  
  return useQuery({
    queryKey,
    queryFn: async () => {
      if (sortedIds.length === 0) return {};

      // Fetch opportunities first (needed to filter readiness answers)
      const opportunitiesResult = await gateway
        .from('opportunities')
        .select('id, account_id, stage, sales_stage, pre_sales_stage, value, included_module_ids, readiness_score')
        .in('account_id', accountIds)
        .execute();
      
      const opportunities = opportunitiesResult.data || [];
      const opportunityIds = opportunities.map((o: any) => o.id).filter(Boolean) as string[];

      // Fetch remaining data in parallel using gateway
      const [
        transcriptsResult,
        useCasesResult,
        nbasResult,
        technologiesResult,
        functionalAreasResult,
        contactsResult,
        accountsResult,
        modulePricingResult,
        useCaseTemplatesResult,
        templateProductsResult,
        metricsResult,
        readinessResult,
        readinessCategoriesResult,
        readinessQuestionsResult,
        technologyRepositoryResult,
        pricingSettingsResult,
        detectionRulesResult,
        detectionMatchesResult,
        oppDeploymentTypesResult,
      ] = await Promise.all([
        gateway.from('transcript_reviews').select('final_account_id').in('final_account_id', accountIds).execute(),
        gateway.from('account_use_cases').select('account_id, use_case, functional_area, opportunity_id, status').in('account_id', accountIds).execute(),
        gateway.from('account_nbas').select('account_id, status').in('account_id', accountIds).execute(),
        gateway.from('account_technologies').select('account_id, category, repository_tech_id').in('account_id', accountIds).execute(),
        gateway.from('functional_areas').select('id, name').execute(),
        gateway.from('account_contacts').select('account_id, stakeholder_type, role, champion_score, influence_level').in('account_id', accountIds).eq('is_ignored', false).execute(),
        gateway.from('accounts').select('id, mau_count, base_mau_value').in('id', accountIds).execute(),
        gateway.from('module_pricing').select('*').eq('is_active', true).execute(),
        gateway.from('use_case_templates').select('id, name, functional_area_id, business_outcome').eq('is_active', true).execute(),
        gateway.from('use_case_template_products').select('use_case_template_id, module_pricing_id').execute(),
        gateway.from('account_metrics').select('account_id, metric_category, metric_name').in('account_id', accountIds).execute(),
        // Fetch readiness answers only for these opportunities (fixes 1000 row limit issue)
        opportunityIds.length > 0
          ? gateway.from('opportunity_readiness_answers').select('*').in('opportunity_id', opportunityIds).execute()
          : Promise.resolve({ data: [], error: null }),
        // Readiness template metadata (used to match opportunity-level scoring)
        gateway.from('readiness_template_categories').select('id, deployment_type_id').execute(),
        gateway.from('readiness_template_questions').select('id, category_id, parent_question_id').execute(),
        gateway.from('technology_repository').select('id, name, competing_module_ids').execute(),
        gateway.from('pricing_settings').select('setting_key, setting_value').execute(),
        // Fetch detection rules for signal coverage (commercial readiness)
        gateway.from('detection_rules').select('id').eq('is_active', true).execute(),
        // Fetch detection rule matches for these opportunities
        opportunityIds.length > 0
          ? gateway.from('detection_rule_matches').select('id, rule_id, opportunity_id').in('opportunity_id', opportunityIds).execute()
          : Promise.resolve({ data: [], error: null }),
        // Fetch opportunity deployment types for these opportunities
        opportunityIds.length > 0
          ? gateway.from('opportunity_deployment_types').select('opportunity_id, deployment_type_id').in('opportunity_id', opportunityIds).execute()
          : Promise.resolve({ data: [], error: null }),
      ]);

      const transcripts = transcriptsResult.data || [];
      const useCases = useCasesResult.data || [];
      const nbas = nbasResult.data || [];
      const technologies = technologiesResult.data || [];
      const functionalAreas = functionalAreasResult.data || [];
      const contacts = contactsResult.data || [];
      const accounts = accountsResult.data || [];
      const modulePricing = (modulePricingResult.data || []) as ModulePricing[];
      const useCaseTemplates = (useCaseTemplatesResult.data || []) as UseCaseTemplate[];
      const metrics = metricsResult.data || [];
      const readinessAnswers = (readinessResult.data || []) as { 
        id: string;
        opportunity_id: string; 
        question_id: string; 
        answer: string | null; 
        answer_json: any;
        confidence_score: number | null;
        is_red_flag: boolean;
        manual_flag_status: string | null;
        source: string | null;
      }[];
      const readinessCategories = (readinessCategoriesResult.data || []) as { id: string; deployment_type_id: string | null }[];
      const readinessQuestions = (readinessQuestionsResult.data || []) as { id: string; category_id: string; parent_question_id: string | null }[];
      const allTopLevelQuestionIds = readinessQuestions.filter(q => !q.parent_question_id).map(q => q.id);
      const totalReadinessQuestions = allTopLevelQuestionIds.length || 1;
      const allTopLevelQuestionIdSet = new Set(allTopLevelQuestionIds);
      const templateProducts = (templateProductsResult.data || []) as UseCaseTemplateProduct[];
      const technologyRepository = (technologyRepositoryResult.data || []) as { id: string; name: string; competing_module_ids: string[] | null }[];
      
      // Detection rules for commercial readiness
      const activeDetectionRules = detectionRulesResult.data || [];
      const totalActiveRules = activeDetectionRules.length;
      const detectionMatches = (detectionMatchesResult.data || []) as { id: string; rule_id: string; opportunity_id: string | null }[];

      // Build opportunity deployment types map from parallel fetch
      const oppDeploymentTypesByOppId = new Map<string, string[]>();
      (oppDeploymentTypesResult.data || []).forEach((row: any) => {
        const existing = oppDeploymentTypesByOppId.get(row.opportunity_id) || [];
        existing.push(row.deployment_type_id);
        oppDeploymentTypesByOppId.set(row.opportunity_id, existing);
      });

      // Helper: derive the same "allQuestionIds" list used by OpportunityDetailView for a given opportunity
      const getTopLevelQuestionIdsForOpportunity = (opportunityId: string): string[] => {
        const deploymentTypeIds = oppDeploymentTypesByOppId.get(opportunityId) || [];

        const relevantCategoryIds = deploymentTypeIds.length > 0
          ? readinessCategories
              .filter(c => c.deployment_type_id === null || deploymentTypeIds.includes(c.deployment_type_id))
              .map(c => c.id)
          : readinessCategories.map(c => c.id);

        const relevantCategoryIdSet = new Set(relevantCategoryIds);
        return readinessQuestions
          .filter(q => !q.parent_question_id && relevantCategoryIdSet.has(q.category_id))
          .map(q => q.id);
      };
      
      // Parse global pricing settings
      const pricingSettings = (pricingSettingsResult.data || []) as { setting_key: string; setting_value: number }[];
      const globalListPricePerMau = pricingSettings.find(s => s.setting_key === 'list_price_per_mau')?.setting_value || 0.50;
      const globalPlatformBaseCost = pricingSettings.find(s => s.setting_key === 'platform_base_cost')?.setting_value || 50000;

      const allFunctionalAreas = new Set(functionalAreas.map((fa: any) => fa.name));
      const totalFunctionalAreas = allFunctionalAreas.size;
      
      // Build account lookup for MAU data
      const accountsMap = new Map(accounts.map((a: any) => [a.id, a]));
      
      // Build template-to-products map
      const templateToProducts = new Map<string, string[]>();
      templateProducts.forEach(tp => {
        const existing = templateToProducts.get(tp.use_case_template_id) || [];
        existing.push(tp.module_pricing_id);
        templateToProducts.set(tp.use_case_template_id, existing);
      });
      
      // Build product pricing map
      const productPricingMap = new Map<string, ModulePricing>();
      modulePricing.forEach(mp => productPricingMap.set(mp.id, mp));

      // Build technology repository map for competing module lookups
      const techRepoMap = new Map<string, { id: string; name: string; competing_module_ids: string[] | null }>();
      technologyRepository.forEach(tech => techRepoMap.set(tech.id, tech));

      // Build stats map
      const statsMap: Record<string, AccountStats> = {};

      accountIds.forEach(accountId => {
        // Opportunities - calculate financial metrics
        const accountOpps = opportunities.filter((o: any) => o.account_id === accountId);
        
        let currentArr = 0;
        let totalOpportunityValue = 0; // Pipeline (open)
        let pipelineWeighted = 0;
        let openOppsCount = 0;
        let closedOppsCount = 0;
        
        for (const opp of accountOpps) {
          const value = opp.value ?? 0;
          // Use sales_stage, fallback to pre_sales_stage, then stage
          const effectiveStage = opp.sales_stage || opp.pre_sales_stage || opp.stage;
          
          if (isClosedWon(effectiveStage)) {
            currentArr += value;
            closedOppsCount += 1;
          } else if (isClosedLost(effectiveStage)) {
            closedOppsCount += 1;
          } else {
            // Open opportunity
            totalOpportunityValue += value;
            const weight = getStageWeight(effectiveStage);
            pipelineWeighted += value * weight;
            openOppsCount += 1;
          }
        }

        // Transcripts
        const accountTranscripts = transcripts.filter((t: any) => t.final_account_id === accountId);

        // Use cases - separate into opportunity-linked (covered) and account-level (whitespace candidates)
        const accountUseCases = useCases.filter((uc: any) => uc.account_id === accountId);
        
        // Use cases linked to opportunities are "in pursuit" - not whitespace
        const coveredUseCaseNames = new Set<string>();
        accountUseCases.forEach((uc: any) => {
          if (uc.use_case) {
            coveredUseCaseNames.add(uc.use_case.toLowerCase().trim());
          }
        });

        // NBAs
        const accountNbas = nbas.filter((n: any) => n.account_id === accountId);
        const openNbas = accountNbas.filter((n: any) => n.status !== 'completed' && n.status !== 'dismissed');

        // Technologies and coverage
        const accountTechs = technologies.filter((t: any) => t.account_id === accountId);
        const coveredAreas = new Set(accountTechs.map((t: any) => t.category));
        const functionalAreasCovered = [...coveredAreas].filter(area => allFunctionalAreas.has(area)).length;
        const coveragePercent = totalFunctionalAreas > 0 
          ? Math.round((functionalAreasCovered / totalFunctionalAreas) * 100) 
          : 0;

        // Build set of module IDs that are excluded due to competing technologies
        const competingModuleIdsSet = new Set<string>();
        accountTechs.forEach((tech: any) => {
          if (tech.repository_tech_id) {
            const repoTech = techRepoMap.get(tech.repository_tech_id);
            if (repoTech?.competing_module_ids) {
              repoTech.competing_module_ids.forEach(mid => competingModuleIdsSet.add(mid));
            }
          }
        });

        // Contacts
        const accountContacts = contacts.filter((c: any) => c.account_id === accountId);
        
        // Calculate whitespace revenue using new product-based model
        const accountData = accountsMap.get(accountId) as { mau_count?: number; base_mau_value?: number } | undefined;
        const mauCount = accountData?.mau_count || 0;
        const baseMauValue = accountData?.base_mau_value || 0;
        
        // Collect all included_module_ids from open opportunities (for net whitespace calc)
        const includedModuleIds: string[] = [];
        for (const opp of accountOpps) {
          const effectiveStage = opp.sales_stage || opp.pre_sales_stage || opp.stage;
          // Only collect from open opportunities
          if (!isClosedWon(effectiveStage) && !isClosedLost(effectiveStage)) {
            const moduleIds = (opp as any).included_module_ids;
            if (Array.isArray(moduleIds)) {
              includedModuleIds.push(...moduleIds);
            }
          }
        }
        const includedModuleIdsSet = new Set(includedModuleIds);
        
        let grossWhitespace = 0;
        let netWhitespace = 0;
        
        if (mauCount > 0 && useCaseTemplates.length > 0) {
          // Calculate base MAU value for percentage-based pricing
          // Priority: account-specific base_mau_value > global list price per MAU * MAU * 12 (annual)
          const mauValue = baseMauValue > 0 
            ? baseMauValue 
            : (globalListPricePerMau * mauCount * 12);
          
          // Find uncovered use case templates (whitespace)
          const uncoveredTemplates = useCaseTemplates.filter(template => {
            const templateName = template.name.toLowerCase().trim();
            // Check if any account use case matches this template
            return !Array.from(coveredUseCaseNames).some(ucName => 
              ucName.includes(templateName) || templateName.includes(ucName)
            );
          });
          
          // Calculate whitespace value based on unique products needed for uncovered templates
          const uncoveredProductIds = new Set<string>();
          uncoveredTemplates.forEach(template => {
            const productIds = templateToProducts.get(template.id) || [];
            productIds.forEach(pid => uncoveredProductIds.add(pid));
          });
          
          // Helper to calculate value for a product
          const calcProductValue = (productId: string): number => {
            const product = productPricingMap.get(productId);
            if (!product) return 0;
            const discount = product.discount_percentage || 0;
            
            if (product.module_type === 'module') {
              // Percentage-based pricing
              const baseModuleCost = mauValue * (product.mau_percentage / 100);
              return baseModuleCost * (1 - discount / 100);
            } else if (product.per_mau_cost > 0) {
              // Per-MAU pricing (annual)
              return product.per_mau_cost * mauCount * 12 * (1 - discount / 100);
            } else if (product.fixed_cost > 0) {
              // Fixed cost
              return product.fixed_cost * (1 - discount / 100);
            }
            return 0;
          };
          
          // Sum up the value of uncovered products
          // - Gross: All products from uncovered use cases (excluding those with competing tech)
          // - Net: Gross minus modules already in opportunities
          uncoveredProductIds.forEach(productId => {
            // Skip if account has competing technology for this module
            if (competingModuleIdsSet.has(productId)) {
              return;
            }
            
            const productValue = calcProductValue(productId);
            grossWhitespace += productValue;
            
            // Only add to net whitespace if not already included in an opportunity
            if (!includedModuleIdsSet.has(productId)) {
              netWhitespace += productValue;
            }
          });
        }

        // Calculate RAG statuses
        // Readiness: aggregate across all account opportunities
        const accountOppIds = new Set(accountOpps.map((o: any) => o.id));
        const openOppIds = accountOpps
          .filter((o: any) => {
            const effectiveStage = o.sales_stage || o.pre_sales_stage || o.stage;
            return !isClosedWon(effectiveStage) && !isClosedLost(effectiveStage);
          })
          .map((o: any) => o.id);
        const openOppIdSet = new Set(openOppIds);

        // Readiness Coverage (icon): average % answered across open opportunities
        // Uses top-level question set (same denominator concept as opportunity page, but coverage not weighted score)
        let readinessPercent = 0;
        if (openOppIds.length > 0) {
          let totalCoverage = 0;
          openOppIds.forEach((oppId: string) => {
            const questionIds = getTopLevelQuestionIdsForOpportunity(oppId);
            const denom = questionIds.length || totalReadinessQuestions;
            const questionIdSet = new Set(questionIds);
            const oppAnswered = readinessAnswers
              .filter(r => r.opportunity_id === oppId && (questionIdSet.size === 0 ? allTopLevelQuestionIdSet.has(r.question_id) : questionIdSet.has(r.question_id)))
              .filter(r => r.answer || r.answer_json).length;
            totalCoverage += denom > 0 ? Math.round((oppAnswered / denom) * 100) : 0;
          });
          readinessPercent = Math.round(totalCoverage / openOppIds.length);
        }
        const readinessStatus: RAGStatus = readinessPercent >= 70 
          ? 'green' 
          : readinessPercent >= 40 
            ? 'amber' 
            : readinessPercent > 0 
              ? 'red' 
              : 'unknown';

        // Technical Readiness: Average the stored readiness_score from open opportunities
        let technicalReadinessPercent = 0;
        if (openOppIds.length > 0) {
          const openOppIdSet = new Set(openOppIds);
          const openOppsWithScores = accountOpps.filter(
            (o: any) => openOppIdSet.has(o.id) && typeof o.readiness_score === 'number'
          );
          if (openOppsWithScores.length > 0) {
            const totalScore = openOppsWithScores.reduce(
              (sum: number, o: any) => sum + (o.readiness_score ?? 0),
              0
            );
            technicalReadinessPercent = Math.round(totalScore / openOppsWithScores.length);
          }
        }

        // Commercial Readiness: Signal coverage % (distinct rules matched / total active rules)
        // Filter matches by open opportunities for this account
        let commercialReadinessPercent = 0;
        if (totalActiveRules > 0 && openOppIds.length > 0) {
          const openOppIdSet = new Set(openOppIds);
          const accountMatches = detectionMatches.filter((m: any) => m.opportunity_id && openOppIdSet.has(m.opportunity_id));
          const distinctRulesMatched = new Set(accountMatches.map((m: any) => m.rule_id));
          commercialReadinessPercent = Math.round((distinctRulesMatched.size / totalActiveRules) * 100);
        }

        // Metrics: check if any business metrics captured
        const accountMetrics = metrics.filter((m: any) => m.account_id === accountId);
        const metricsCount = accountMetrics.length;
        const metricsStatus: RAGStatus = metricsCount >= 3 
          ? 'green' 
          : metricsCount >= 1 
            ? 'amber' 
            : 'red';

        // Economic Buyer: check stakeholder types and roles
        const hasEconomicBuyer = accountContacts.some((c: any) => 
          c.stakeholder_type === 'economic_buyer' ||
          c.role?.toLowerCase().includes('economic buyer') ||
          c.role?.toLowerCase().includes('budget') ||
          c.role?.toLowerCase().includes('cfo') ||
          c.role?.toLowerCase().includes('finance') ||
          c.role?.toLowerCase().includes('ceo') ||
          c.role?.toLowerCase().includes('chief')
        );
        const hasStrongChampion = accountContacts.some((c: any) => (c.champion_score || 0) >= 60);
        const economicBuyerStatus: RAGStatus = hasEconomicBuyer 
          ? 'green' 
          : hasStrongChampion 
            ? 'amber' 
            : accountContacts.length > 0 
              ? 'red' 
              : 'unknown';

        statsMap[accountId] = {
          accountId,
          openOpportunities: openOppsCount,
          closedOpportunities: closedOppsCount,
          totalTranscripts: accountTranscripts.length,
          useCasesCount: accountUseCases.length,
          nbasCount: accountNbas.length,
          openNbasCount: openNbas.length,
          technologiesCount: accountTechs.length,
          functionalAreasCovered,
          totalFunctionalAreas,
          coveragePercent,
          contactsCount: accountContacts.length,
          // Financial metrics
          currentArr: Math.round(currentArr),
          totalOpportunityValue: Math.round(totalOpportunityValue),
          pipelineWeighted: Math.round(pipelineWeighted),
          grossWhitespace: Math.round(grossWhitespace),
          netWhitespace: Math.round(netWhitespace),
          includedModuleIds,
          whitespaceRevenue: Math.round(netWhitespace), // Legacy - use net for backwards compat
          // RAG statuses
          readinessStatus,
          readinessPercent,
          metricsStatus,
          metricsCount,
          economicBuyerStatus,
          hasEconomicBuyer,
          // New readiness metrics
          technicalReadinessPercent,
          commercialReadinessPercent,
        };
      });

      return statsMap;
    },
    enabled: sortedIds.length > 0,
    staleTime: 30000, // Cache for 30 seconds to prevent flickering
  });
}

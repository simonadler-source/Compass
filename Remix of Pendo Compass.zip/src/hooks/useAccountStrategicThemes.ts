import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface StrategicTheme {
  id: string;
  account_id: string;
  theme_name: string;
  theme_type: 'pain_theme' | 'initiative';
  description: string;
  supporting_evidence: string[];
  impact_level: 'critical' | 'high' | 'medium' | 'low' | null;
  item_count: number;
  created_at: string;
  updated_at: string;
}

export interface ExecSummary {
  id: string;
  account_id: string;
  summary_narrative: string;
  health_indicators: {
    relationshipHealth?: 'strong' | 'stable' | 'at_risk' | 'critical';
    engagementLevel?: 'high' | 'moderate' | 'low' | 'declining';
    opportunityMomentum?: 'accelerating' | 'steady' | 'stalled' | 'declining';
  };
  key_risks: string[];
  key_opportunities: string[];
  generated_at: string;
}

export function useAccountStrategicThemes(accountId: string | null) {
  return useQuery({
    queryKey: ['account-strategic-themes', accountId],
    queryFn: async () => {
      if (!accountId) return { painThemes: [], initiatives: [] };
      
      // Use gateway for decryption of encrypted fields
      const result = await gateway
        .from('account_strategic_themes')
        .select('*')
        .eq('account_id', accountId)
        .order('impact_level', { ascending: true })
        .execute();
      
      if (result.error) throw new Error(getErrorMessage(result.error));
      
      const themes = (result.data || []) as StrategicTheme[];
      return {
        painThemes: themes.filter(t => t.theme_type === 'pain_theme'),
        initiatives: themes.filter(t => t.theme_type === 'initiative'),
      };
    },
    enabled: !!accountId,
  });
}

export function useAccountExecSummary(accountId: string | null) {
  return useQuery({
    queryKey: ['account-exec-summary', accountId],
    queryFn: async () => {
      if (!accountId) return null;
      
      // Use gateway for decryption of encrypted fields
      const result = await gateway
        .from('account_exec_summaries')
        .select('*')
        .eq('account_id', accountId)
        .maybeSingle()
        .execute();
      
      if (result.error) throw new Error(getErrorMessage(result.error));
      return result.data as ExecSummary | null;
    },
    enabled: !!accountId,
  });
}

export function useSynthesizeAccountInsights() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (accountId: string) => {
      const { data, error } = await supabase.functions.invoke('synthesize-account-insights', {
        body: { accountId }
      });
      
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    },
    onSuccess: (_, accountId) => {
      queryClient.invalidateQueries({ queryKey: ['account-strategic-themes', accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-exec-summary', accountId] });
      toast.success('Strategic insights synthesized');
    },
    onError: (error) => {
      console.error('Synthesis failed:', error);
      toast.error('Failed to synthesize insights: ' + (error as Error).message);
    }
  });
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface AccountUseCase {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  functional_area: string;
  use_case: string;
  description: string | null;
  status: string;
  priority: string | null;
  source: string;
  source_transcript_id: string | null;
  sort_order: number;
  radar_x: number | null;
  radar_y: number | null;
  created_at: string;
  updated_at: string;
  // Speaker attribution fields (optional for backwards compatibility)
  mentioned_by_type?: 'internal' | 'external' | 'unknown' | null;
  mentioned_by_name?: string | null;
  mentioned_by_email?: string | null;
  acceptance_status?: 'validated' | 'proposed' | 'accepted' | null;
  acceptance_evidence?: string | null;
}

export function useAccountUseCases(accountId: string) {
  return useQuery({
    queryKey: ['account-use-cases', accountId],
    queryFn: async () => {
      // Use gateway to get decrypted data and proper access
      const response = await gateway
        .from('account_use_cases')
        .select('*')
        .eq('account_id', accountId)
        .order('sort_order', { ascending: true })
        .order('created_at', { ascending: false })
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as AccountUseCase[];
    },
    enabled: !!accountId,
  });
}

export function useCreateUseCase() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (useCase: Omit<AccountUseCase, 'id' | 'created_at' | 'updated_at'>) => {
      const { data: inserted, error } = await gateway
        .from('account_use_cases')
        .insert(useCase as any)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const data = Array.isArray(inserted) ? inserted[0] : inserted;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', data.account_id] });
      toast.success('Use case added');
    },
    onError: (error) => {
      toast.error('Failed to add use case: ' + error.message);
    },
  });
}

export function useUpdateUseCase() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId, ...updates }: Partial<AccountUseCase> & { id: string; accountId: string }) => {
      const { data: updated, error } = await gateway
        .from('account_use_cases')
        .update(updates as any)
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const data = Array.isArray(updated) ? updated[0] : updated;
      return { ...data, accountId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', data.accountId] });
    },
    onError: (error) => {
      toast.error('Failed to update use case: ' + error.message);
    },
  });
}

export function useDeleteUseCase() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId }: { id: string; accountId: string }) => {
      const { error } = await gateway
        .from('account_use_cases')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return { accountId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', data.accountId] });
      toast.success('Use case removed');
    },
    onError: (error) => {
      toast.error('Failed to delete use case: ' + error.message);
    },
  });
}

export function useReorderUseCases() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ accountId, useCaseIds }: { accountId: string; useCaseIds: string[] }) => {
      // Update sort_order for each use case
      const updates = useCaseIds.map((id, index) => 
        gateway
          .from('account_use_cases')
          .update({ sort_order: index })
          .eq('id', id)
          .execute()
      );
      
      await Promise.all(updates);
      return { accountId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', data.accountId] });
    },
    onError: (error) => {
      toast.error('Failed to reorder use cases: ' + error.message);
    },
  });
}

export function useAcceptProposedUseCase() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId }: { id: string; accountId: string }) => {
      const { data: updated, error } = await gateway
        .from('account_use_cases')
        .update({ 
          source: 'accepted',
          status: 'validated'
        })
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      const data = Array.isArray(updated) ? updated[0] : updated;
      return { ...data, accountId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', data.accountId] });
      toast.success('Use case accepted');
    },
    onError: (error) => {
      toast.error('Failed to accept use case: ' + error.message);
    },
  });
}

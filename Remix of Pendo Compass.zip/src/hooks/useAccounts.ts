import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { Tables, TablesInsert } from '@/integrations/supabase/types';
import { toast } from 'sonner';

export type DbAccount = Tables<'accounts'>;
export type DbOpportunity = Tables<'opportunities'>;
export type DbAccountTechnology = Tables<'account_technologies'>;
export type DbAccountDocument = Tables<'account_documents'>;

export interface AccountWithDetails extends DbAccount {
  opportunities: DbOpportunity[];
  technologies: DbAccountTechnology[];
  documents: DbAccountDocument[];
}

export function useAccounts(searchQuery?: string) {
  return useQuery({
    queryKey: ['accounts', searchQuery],
    queryFn: async () => {
      let query = gateway.from('accounts')
        .select('*')
        .order('updated_at', { ascending: false });

      if (searchQuery) {
        query = query.or(`name.ilike.%${searchQuery}%,industry.ilike.%${searchQuery}%`);
      }

      const result = await query.execute();
      if (result.error) throw new Error(result.error.message);
      return result.data as DbAccount[];
    },
    staleTime: 30 * 1000,
    refetchOnWindowFocus: true,
  });
}

export function useAccountWithDetails(accountId: string | null, includeArchived = false) {
  return useQuery({
    queryKey: ['account', accountId, includeArchived],
    queryFn: async () => {
      if (!accountId) return null;

      // Build opportunities query - filter archived unless explicitly requested
      let oppsQuery = gateway.from('opportunities').select('*').eq('account_id', accountId);
      if (!includeArchived) {
        oppsQuery = oppsQuery.or('is_archived.is.null,is_archived.eq.false');
      }

      const [accountRes, opportunitiesRes, technologiesRes, documentsRes] = await Promise.all([
        gateway.from('accounts').select('*').eq('id', accountId).single().execute(),
        oppsQuery.execute(),
        gateway.from('account_technologies').select('*').eq('account_id', accountId).execute(),
        gateway.from('account_documents').select('*').eq('account_id', accountId).execute(),
      ]);

      if (accountRes.error) throw new Error(accountRes.error.message);

      // Separate active and archived opportunities
      const allOpportunities = opportunitiesRes.data || [];
      const activeOpportunities = allOpportunities.filter((o: any) => !o.is_archived);
      const archivedOpportunities = allOpportunities.filter((o: any) => o.is_archived);

      return {
        ...accountRes.data,
        opportunities: activeOpportunities,
        archivedOpportunities: archivedOpportunities,
        allOpportunities: allOpportunities,
        technologies: technologiesRes.data || [],
        documents: documentsRes.data || [],
      } as AccountWithDetails & { archivedOpportunities: DbOpportunity[]; allOpportunities: DbOpportunity[] };
    },
    enabled: !!accountId,
    staleTime: 30 * 1000,
    refetchOnWindowFocus: true,
  });
}

export function useCreateAccount() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (account: TablesInsert<'accounts'>) => {
      const result = await gateway.from('accounts')
        .insert(account)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['accounts'] });
      toast.success('Account created successfully');
    },
    onError: (error) => {
      toast.error('Failed to create account: ' + error.message);
    },
  });
}

export function useUpdateAccount() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<DbAccount> & { id: string }) => {
      const result = await gateway.from('accounts')
        .update(updates)
        .eq('id', id)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return { ...result.data?.[0], id };
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['accounts'] });
      queryClient.invalidateQueries({ queryKey: ['account', variables.id] });
    },
    onError: (error) => {
      toast.error('Failed to update account: ' + error.message);
    },
  });
}

export function useDeleteAccount() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const result = await gateway.from('accounts').delete().eq('id', id).execute();
      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['accounts'] });
      toast.success('Account deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete account: ' + error.message);
    },
  });
}

// Opportunities
export function useCreateOpportunity() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (opportunity: TablesInsert<'opportunities'>) => {
      const result = await gateway.from('opportunities')
        .insert(opportunity)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data) => {
      if (data?.account_id) {
        queryClient.invalidateQueries({ queryKey: ['account', data.account_id] });
      }
      toast.success('Opportunity created');
    },
    onError: (error) => {
      toast.error('Failed to create opportunity: ' + error.message);
    },
  });
}

export function useUpdateOpportunity() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<DbOpportunity> & { id: string }) => {
      // First get the account_id so we can invalidate the right query
      const { data: existingOpp } = await gateway.from('opportunities')
        .select('account_id')
        .eq('id', id)
        .single()
        .execute();
      
      const result = await gateway.from('opportunities')
        .update(updates)
        .eq('id', id)
        .execute();
      if (result.error) throw new Error(result.error.message);
      
      // Return updated data with account_id preserved
      return { ...result.data?.[0], account_id: existingOpp?.account_id };
    },
    onSuccess: async (data, variables) => {
      // Invalidate account query to refresh opportunity list
      const accountId = data?.account_id;
      if (accountId) {
        queryClient.invalidateQueries({ queryKey: ['account', accountId] });
      }
      
      // Also invalidate accounts list to ensure any opportunity-related data is refreshed
      queryClient.invalidateQueries({ queryKey: ['accounts'] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-full', variables.id] });
      
      // Trigger real-time alert evaluation if stage or readiness-related fields changed
      const triggersAlertCheck = 
        'stage' in variables || 
        'pre_sales_stage' in variables || 
        'readiness_score' in variables;
      
      if (triggersAlertCheck && variables.id) {
        console.log('[Opportunity] Triggering alert evaluation for stage/readiness change');
        try {
          await supabase.functions.invoke('evaluate-opportunity-alerts', {
            body: { opportunityId: variables.id }
          });
        } catch (err) {
          console.error('[Opportunity] Alert evaluation failed:', err);
        }
      }
    },
    onError: (error) => {
      toast.error('Failed to update opportunity: ' + error.message);
    },
  });
}

export function useDeleteOpportunity() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId }: { id: string; accountId: string }) => {
      // Fetch the SF Opportunity ID before deleting so we can prevent auto-recreate.
      const oppRes = await gateway
        .from('opportunities')
        .select('id, account_id, salesforce_opportunity_id')
        .eq('id', id)
        .maybeSingle()
        .execute();
      if (oppRes.error) throw new Error(oppRes.error.message);

      const opp = oppRes.data as any;

      // Record a tombstone (best-effort) so Momentum sync/import won't recreate it.
      if (opp?.account_id) {
        const tombstoneRes = await gateway
          .from('opportunity_deletion_tombstones')
          .insert({
            account_id: opp.account_id,
            opportunity_id: opp.id,
            salesforce_opportunity_id: opp.salesforce_opportunity_id || null,
          })
          .execute();

        // Ignore unique conflicts (already tombstoned)
        if (tombstoneRes.error && tombstoneRes.error.code !== '23505') {
          throw new Error(tombstoneRes.error.message);
        }
      }

      const result = await gateway.from('opportunities').delete().eq('id', id).execute();
      if (result.error) throw new Error(result.error.message);
      return { accountId };
    },
    onSuccess: (data) => {
      if (data?.accountId) {
        queryClient.invalidateQueries({ queryKey: ['account', data.accountId] });
      }
      queryClient.invalidateQueries({ queryKey: ['accounts'] });
      toast.success('Opportunity deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete opportunity: ' + error.message);
    },
  });
}

// Technologies
export function useCreateAccountTechnology() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (tech: TablesInsert<'account_technologies'> & { status?: string }) => {
      const result = await gateway.from('account_technologies')
        .upsert(tech, { onConflict: 'account_id,name' })
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data) => {
      if (data?.account_id) {
        queryClient.invalidateQueries({ queryKey: ['account', data.account_id] });
        queryClient.invalidateQueries({ queryKey: ['account-technologies', data.account_id] });
      }
    },
    onError: (error) => {
      toast.error('Failed to add technology: ' + error.message);
    },
  });
}

export function useDeleteAccountTechnology() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId }: { id: string; accountId: string }) => {
      const result = await gateway.from('account_technologies')
        .delete()
        .eq('id', id)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return { accountId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['account', data.accountId] });
    },
    onError: (error) => {
      toast.error('Failed to remove technology: ' + error.message);
    },
  });
}

export function useUpdateAccountTechnology() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId, ...updates }: Partial<DbAccountTechnology> & { id: string; accountId: string; status?: string }) => {
      const result = await gateway.from('account_technologies')
        .update(updates)
        .eq('id', id)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return { ...result.data?.[0], accountId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['account', data.accountId] });
    },
    onError: (error) => {
      toast.error('Failed to update technology: ' + error.message);
    },
  });
}

// Documents
export function useCreateAccountDocument() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (doc: TablesInsert<'account_documents'>) => {
      const result = await gateway.from('account_documents')
        .insert(doc)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data) => {
      if (data?.account_id) {
        queryClient.invalidateQueries({ queryKey: ['account', data.account_id] });
      }
      toast.success('Document saved');
    },
    onError: (error) => {
      toast.error('Failed to save document: ' + error.message);
    },
  });
}

// Transcript Reviews
export type DbTranscriptReview = Tables<'transcript_reviews'>;

export function useTranscriptReviews(status?: string) {
  return useQuery({
    queryKey: ['transcript-reviews', status],
    queryFn: async () => {
      // Explicitly exclude transcript_content to prevent memory/timeout issues
      // transcript_content should only be fetched on-demand for individual records
      let query = gateway.from('transcript_reviews')
        .select(`
          id, file_name, status, created_at, updated_at,
          suggested_account_id, suggested_account_confidence, final_account_id,
          opportunity_id, meeting_title, meeting_type,
          extracted_insights, extracted_technologies,
          momentum_meeting_id, created_by,
          accounts:suggested_account_id(name)
        `)
        .order('created_at', { ascending: false });

       // Hard safety cap: transcript reviews can grow very large; without pagination
       // this can overload the backend function. We can add pagination later if needed.
       query = query.limit(200);

      if (status) {
        query = query.eq('status', status);
      }

      const result = await query.execute();
      if (result.error) throw new Error(result.error.message);
      return result.data;
    },
  });
}

export function useCreateTranscriptReview() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (review: TablesInsert<'transcript_reviews'>) => {
      const result = await gateway.from('transcript_reviews')
        .insert(review)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews'] });
    },
    onError: (error) => {
      toast.error('Failed to save transcript: ' + error.message);
    },
  });
}

export function useUpdateTranscriptReview() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<DbTranscriptReview> & { id: string }) => {
      const result = await gateway.from('transcript_reviews')
        .update(updates)
        .eq('id', id)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transcript-reviews'] });
    },
    onError: (error) => {
      toast.error('Failed to update review: ' + error.message);
    },
  });
}

// Account Contacts
export type DbAccountContact = Tables<'account_contacts'>;

export function useAccountContacts(accountId: string | null) {
  return useQuery({
    queryKey: ['account-contacts', accountId],
    queryFn: async () => {
      if (!accountId) return [];
      const result = await gateway.from('account_contacts')
        .select('*')
        .eq('account_id', accountId)
        .order('created_at', { ascending: false })
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data as DbAccountContact[];
    },
    enabled: !!accountId,
  });
}

export function useCreateAccountContact() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (contact: TablesInsert<'account_contacts'>) => {
      const result = await gateway.from('account_contacts')
        .insert(contact)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['account-contacts', data?.account_id] });
      queryClient.invalidateQueries({ queryKey: ['account', data?.account_id] });
    },
    onError: (error) => {
      toast.error('Failed to add contact: ' + error.message);
    },
  });
}

// Account NBAs (Next Best Actions)
export type DbAccountNba = Tables<'account_nbas'>;

export function useAccountNbas(accountId?: string | null) {
  return useQuery({
    queryKey: ['account-nbas', accountId],
    queryFn: async () => {
      let query = gateway.from('account_nbas')
        .select('*, accounts:account_id(name)')
        .order('created_at', { ascending: false });
      
      if (accountId) {
        query = query.eq('account_id', accountId);
      }
      
      const result = await query.execute();
      if (result.error) throw new Error(result.error.message);
      return result.data;
    },
    enabled: accountId === undefined || !!accountId,
  });
}

export function useCreateAccountNba() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (nba: TablesInsert<'account_nbas'>) => {
      const result = await gateway.from('account_nbas')
        .insert(nba)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['account-nbas'] });
      queryClient.invalidateQueries({ queryKey: ['account', data?.account_id] });
    },
    onError: (error) => {
      toast.error('Failed to add NBA: ' + error.message);
    },
  });
}

export function useUpdateAccountNba() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<DbAccountNba> & { id: string }) => {
      const result = await gateway.from('account_nbas')
        .update(updates)
        .eq('id', id)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['account-nbas'] });
      queryClient.invalidateQueries({ queryKey: ['account', data?.account_id] });
    },
    onError: (error) => {
      toast.error('Failed to update NBA: ' + error.message);
    },
  });
}

// Customer Stories
export type DbCustomerStory = Tables<'customer_stories'>;

export function useCustomerStories(accountId?: string | null) {
  return useQuery({
    queryKey: ['customer-stories', accountId],
    queryFn: async () => {
      let query = gateway.from('customer_stories')
        .select('*, accounts:account_id(name, industry)')
        .order('created_at', { ascending: false });
      
      if (accountId) {
        query = query.eq('account_id', accountId);
      }
      
      const result = await query.execute();
      if (result.error) throw new Error(result.error.message);
      return result.data;
    },
  });
}

export function useCreateCustomerStory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (story: TablesInsert<'customer_stories'>) => {
      const result = await gateway.from('customer_stories')
        .insert(story)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['customer-stories'] });
      queryClient.invalidateQueries({ queryKey: ['account', data?.account_id] });
      toast.success('Customer story saved');
    },
    onError: (error) => {
      toast.error('Failed to save customer story: ' + error.message);
    },
  });
}

export function useUpdateCustomerStory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<DbCustomerStory> & { id: string }) => {
      const result = await gateway.from('customer_stories')
        .update(updates)
        .eq('id', id)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['customer-stories'] });
      queryClient.invalidateQueries({ queryKey: ['account', data?.account_id] });
    },
    onError: (error) => {
      toast.error('Failed to update customer story: ' + error.message);
    },
  });
}

export function useDeleteCustomerStory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const result = await gateway.from('customer_stories').delete().eq('id', id).execute();
      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customer-stories'] });
      toast.success('Customer story deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete customer story: ' + error.message);
    },
  });
}

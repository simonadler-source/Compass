import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';

export interface ActivitySignalType {
  id: string;
  name: string;
  signalKey: string; // e.g., 'demo', 'nda', 'pricing'
  description: string | null;
}

// Activity Signals tree ID
const ACTIVITY_SIGNALS_TREE_ID = 'f5e4d3c2-b1a0-9876-5432-fedcba098765';

// Map rule names to signal keys for display
function extractSignalKey(name: string, signalFieldName: string | null): string {
  if (signalFieldName) return signalFieldName;
  
  // Fallback: derive from name
  const normalized = name.toLowerCase().replace(' signals', '').replace(' signal', '');
  return normalized.replace(/\s+/g, '_');
}

export function useActivitySignalTypes() {
  return useQuery({
    queryKey: ['activity-signal-types'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('detection_rules')
        .select('id, name, description, signal_field_name')
        .eq('tree_id', ACTIVITY_SIGNALS_TREE_ID)
        .eq('is_active', true)
        .order('sort_order')
        .execute();
      
      if (error) throw error;
      
      return (data || []).map((rule: any) => ({
        id: rule.id,
        name: rule.name.replace(' Signals', '').replace(' Signal', ''),
        signalKey: extractSignalKey(rule.name, rule.signal_field_name),
        description: rule.description,
      })) as ActivitySignalType[];
    },
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });
}

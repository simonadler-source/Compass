import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { startOfWeek, startOfMonth, subWeeks, subMonths, format } from 'date-fns';

// Activity Signal rule tree ID
const ACTIVITY_SIGNAL_TREE_ID = 'f5e4d3c2-b1a0-9876-5432-fedcba098765';

export interface ActivitySignalMatch {
  id: string;
  rule_id: string;
  rule_name: string;
  rule_key: string; // e.g., 'demo', 'nda', 'pricing'
  rule_speaker_context: 'any' | 'internal_only' | 'external_only';
  opportunity_id: string;
  opportunity_name: string;
  salesforce_opportunity_id: string | null;
  account_id: string;
  account_name: string;
  sales_stage: string | null;
  pre_sales_stage: string | null;
  confidence_score: number;
  matched_phrases: string[];
  first_detected_at: string;
  created_at: string;
  transcript_id: string;
  speaker_type: 'internal' | 'external' | 'unknown' | null;
  speaker_name: string | null;
  speaker_email: string | null;
  owner_email: string | null;
  primary_se_email: string | null;
}

export interface DynamicSignalType {
  id: string;
  name: string;
  key: string;
  color: string;
}

export interface SignalCounts {
  byType: Record<string, number>;
  total: number;
}

export interface StageBreakdown {
  stage: string;
  byType: Record<string, number>;
  total: number;
}

export interface WeeklyTrend {
  week: string;
  weekLabel: string;
  byType: Record<string, number>;
  newThisWeek: number;
}

export interface MonthlyTrend {
  month: string;
  monthLabel: string;
  byType: Record<string, number>;
}

export interface NewSignal {
  id: string;
  rule_name: string;
  rule_key: string;
  rule_speaker_context: 'any' | 'internal_only' | 'external_only';
  opportunity_id: string;
  opportunity_name: string;
  salesforce_opportunity_id: string | null;
  account_id: string;
  account_name: string;
  first_detected_at: string;
  matched_phrases: string[];
  speaker_type: 'internal' | 'external' | 'unknown' | null;
  speaker_name: string | null;
  owner_email: string | null;
  primary_se_email: string | null;
}

// Color palette for dynamic signal types
const SIGNAL_COLORS = [
  '#8B5CF6', // Purple
  '#F97316', // Orange
  '#0EA5E9', // Sky blue
  '#10B981', // Emerald
  '#EF4444', // Red
  '#F59E0B', // Amber
  '#EC4899', // Pink
  '#6366F1', // Indigo
  '#14B8A6', // Teal
  '#84CC16', // Lime
];

function extractSignalKey(name: string, signalFieldName: string | null): string {
  if (signalFieldName) return signalFieldName;
  const normalized = name.toLowerCase().replace(' signals', '').replace(' signal', '');
  return normalized.replace(/\s+/g, '_');
}

export function useActivitySignals() {
  return useQuery({
    queryKey: ['activity-signals-dynamic'],
    queryFn: async () => {
      // First fetch active rules from the Activity Signals tree
      const rulesResponse = await gateway
        .from('detection_rules')
        .select('id, name, signal_field_name')
        .eq('tree_id', ACTIVITY_SIGNAL_TREE_ID)
        .eq('is_active', true)
        .order('sort_order')
        .execute();

      if (rulesResponse.error) throw new Error(getErrorMessage(rulesResponse.error));
      const rules = rulesResponse.data || [];

      // Build signal types with colors
      const signalTypes: DynamicSignalType[] = rules.map((rule: any, index: number) => ({
        id: rule.id,
        name: rule.name.replace(' Signals', '').replace(' Signal', ''),
        key: extractSignalKey(rule.name, rule.signal_field_name),
        color: SIGNAL_COLORS[index % SIGNAL_COLORS.length],
      }));

      // Fetch all matches for Activity Signals rules using pagination (avoids 1000/5000 truncation)
      const MATCH_SELECT = `
          id,
          rule_id,
          opportunity_id,
          confidence_score,
          matched_phrases,
          first_detected_at,
          created_at,
          transcript_id,
          speaker_type,
          speaker_name,
          speaker_email,
          detection_rules!inner (
            id,
            name,
            tree_id,
            speaker_context,
            signal_field_name
          ),
          opportunities!inner (
            id,
            name,
            sales_stage,
            pre_sales_stage,
            salesforce_opportunity_id,
            account_id,
            owner_email,
            primary_se_email,
            accounts!inner (
              id,
              name
            )
          )
        `;

      const PAGE_SIZE = 1000;
      const MAX_ROWS_SAFETY = 50000;
      const matches: any[] = [];
      let offset = 0;

      while (true) {
        const pageResponse = await gateway.from('detection_rule_matches')
          .select(MATCH_SELECT)
          .not('opportunity_id', 'is', null)
          .order('first_detected_at', { ascending: false })
          .range(offset, offset + PAGE_SIZE - 1)
          .execute();

        if (pageResponse.error) throw new Error(getErrorMessage(pageResponse.error));

        const page = pageResponse.data || [];
        matches.push(...page);

        if (page.length < PAGE_SIZE) break;

        offset += PAGE_SIZE;
        if (offset >= MAX_ROWS_SAFETY) {
          console.warn(`[ActivitySignals] Reached pagination safety cap at ${MAX_ROWS_SAFETY} rows`);
          break;
        }
      }

      // Filter to only Activity Signals tree rules
      const activityMatches = (matches || []).filter((m: any) => 
        m.detection_rules?.tree_id === ACTIVITY_SIGNAL_TREE_ID
      );

      // Transform to our interface
      const signals: ActivitySignalMatch[] = activityMatches.map((m: any) => ({
        id: m.id,
        rule_id: m.rule_id,
        rule_name: m.detection_rules?.name || 'Unknown',
        rule_key: extractSignalKey(m.detection_rules?.name || '', m.detection_rules?.signal_field_name),
        rule_speaker_context: m.detection_rules?.speaker_context || 'any',
        opportunity_id: m.opportunity_id,
        opportunity_name: m.opportunities?.name || 'Unknown',
        salesforce_opportunity_id: m.opportunities?.salesforce_opportunity_id || null,
        account_id: m.opportunities?.account_id,
        account_name: m.opportunities?.accounts?.name || 'Unknown',
        sales_stage: m.opportunities?.sales_stage,
        pre_sales_stage: m.opportunities?.pre_sales_stage,
        confidence_score: m.confidence_score || 0,
        matched_phrases: m.matched_phrases || [],
        first_detected_at: m.first_detected_at || m.created_at,
        created_at: m.created_at,
        transcript_id: m.transcript_id,
        speaker_type: m.speaker_type,
        speaker_name: m.speaker_name,
        speaker_email: m.speaker_email,
        owner_email: m.opportunities?.owner_email || null,
        primary_se_email: m.opportunities?.primary_se_email || null,
      }));

      return { signals, signalTypes };
    },
  });
}

export function useActivitySignalStats(selectedSignalTypes?: string[], dateRange?: { from: Date; to: Date }) {
  const { data, isLoading, error } = useActivitySignals();
  let allSignals = data?.signals || [];
  const signalTypes = data?.signalTypes || [];

  // Apply date range filter before deduplication
  if (dateRange) {
    const fromTime = dateRange.from.getTime();
    const toTime = dateRange.to.getTime() + 86400000; // include the full "to" day
    allSignals = allSignals.filter(s => {
      const t = new Date(s.first_detected_at).getTime();
      return t >= fromTime && t < toTime;
    });
  }

  // Get unique opportunities per rule (deduplicate by opportunity_id + rule_id)
  const uniqueByOppAndRule = new Map<string, ActivitySignalMatch>();
  allSignals.forEach(s => {
    const key = `${s.opportunity_id}-${s.rule_id}`;
    if (!uniqueByOppAndRule.has(key)) {
      uniqueByOppAndRule.set(key, s);
    }
  });
  let uniqueSignals = Array.from(uniqueByOppAndRule.values());

  // Apply filter if signal types are selected
  if (selectedSignalTypes && selectedSignalTypes.length > 0) {
    uniqueSignals = uniqueSignals.filter(s => selectedSignalTypes.includes(s.rule_id));
  }

  // Current counts by type
  const byType: Record<string, number> = {};
  signalTypes.forEach(st => {
    byType[st.key] = uniqueSignals.filter(s => s.rule_id === st.id).length;
  });

  const counts: SignalCounts = {
    byType,
    total: new Set(uniqueSignals.map(s => s.opportunity_id)).size,
  };

  // Define proper stage order
  const STAGE_ORDER = [
    'Discovery',
    'Demo',
    'Proof - Scoping',
    'Proof',
    'Technical Win',
    'Technical Loss',
  ];

  // Normalize stage names for consistent display
  const normalizeStage = (stage: string | null): string => {
    if (!stage) return 'Unknown';
    const lower = stage.toLowerCase().trim();
    if (lower === 'discovery') return 'Discovery';
    if (lower === 'demo') return 'Demo';
    if (lower === 'proof - scoping' || lower === 'proof-scoping' || lower === 'scoping') return 'Proof - Scoping';
    if (lower === 'proof' || lower === 'evaluation') return 'Proof';
    if (lower === 'technical win' || lower === 'technical-win' || lower === 'win') return 'Technical Win';
    if (lower === 'technical loss' || lower === 'technical-loss' || lower === 'loss') return 'Technical Loss';
    return stage.charAt(0).toUpperCase() + stage.slice(1);
  };

  // Stage breakdown (by pre_sales_stage)
  const stageMap = new Map<string, StageBreakdown>();
  uniqueSignals.forEach(s => {
    const stage = normalizeStage(s.pre_sales_stage);
    if (!stageMap.has(stage)) {
      const initialByType: Record<string, number> = {};
      signalTypes.forEach(st => { initialByType[st.key] = 0; });
      stageMap.set(stage, { stage, byType: initialByType, total: 0 });
    }
    const breakdown = stageMap.get(stage)!;
    const signalType = signalTypes.find(st => st.id === s.rule_id);
    if (signalType) {
      breakdown.byType[signalType.key]++;
    }
    breakdown.total++;
  });

  // Sort by defined order, unknown stages go to end
  const stageBreakdown = Array.from(stageMap.values()).sort((a, b) => {
    const aIndex = STAGE_ORDER.indexOf(a.stage);
    const bIndex = STAGE_ORDER.indexOf(b.stage);
    if (aIndex === -1 && bIndex === -1) return b.total - a.total;
    if (aIndex === -1) return 1;
    if (bIndex === -1) return -1;
    return aIndex - bIndex;
  });

  // For trends, use ALL detections (not deduped) so each week shows its actual volume
  const trendSignals = (selectedSignalTypes && selectedSignalTypes.length > 0)
    ? allSignals.filter(s => selectedSignalTypes.includes(s.rule_id))
    : allSignals;

  // Weekly trends (last 8 weeks)
  const now = new Date();
  const weeklyTrends: WeeklyTrend[] = [];
  for (let i = 7; i >= 0; i--) {
    const weekStart = startOfWeek(subWeeks(now, i));
    const weekEnd = startOfWeek(subWeeks(now, i - 1));
    const weekSignals = trendSignals.filter(s => {
      const detected = new Date(s.first_detected_at);
      return detected >= weekStart && detected < weekEnd;
    });
    
    const weekByType: Record<string, number> = {};
    signalTypes.forEach(st => {
      weekByType[st.key] = weekSignals.filter(s => s.rule_id === st.id).length;
    });

    weeklyTrends.push({
      week: format(weekStart, 'yyyy-MM-dd'),
      weekLabel: format(weekStart, 'MMM d'),
      byType: weekByType,
      newThisWeek: weekSignals.length,
    });
  }

  // Monthly trends (last 6 months)
  const monthlyTrends: MonthlyTrend[] = [];
  for (let i = 5; i >= 0; i--) {
    const monthStart = startOfMonth(subMonths(now, i));
    const monthEnd = startOfMonth(subMonths(now, i - 1));
    const monthSignals = trendSignals.filter(s => {
      const detected = new Date(s.first_detected_at);
      return detected >= monthStart && detected < monthEnd;
    });

    const monthByType: Record<string, number> = {};
    signalTypes.forEach(st => {
      monthByType[st.key] = monthSignals.filter(s => s.rule_id === st.id).length;
    });

    monthlyTrends.push({
      month: format(monthStart, 'yyyy-MM'),
      monthLabel: format(monthStart, 'MMM yyyy'),
      byType: monthByType,
    });
  }

  // New this week
  const thisWeekStart = startOfWeek(now);
  const newThisWeek: NewSignal[] = uniqueSignals
    .filter(s => new Date(s.first_detected_at) >= thisWeekStart)
    .map(s => ({
      id: s.id,
      rule_name: s.rule_name,
      rule_key: s.rule_key,
      rule_speaker_context: s.rule_speaker_context,
      opportunity_id: s.opportunity_id,
      opportunity_name: s.opportunity_name,
      salesforce_opportunity_id: s.salesforce_opportunity_id,
      account_id: s.account_id,
      account_name: s.account_name,
      first_detected_at: s.first_detected_at,
      matched_phrases: s.matched_phrases,
      speaker_type: s.speaker_type,
      speaker_name: s.speaker_name,
      owner_email: s.owner_email,
      primary_se_email: s.primary_se_email,
    }));

  // Week-over-week comparison
  const lastWeekStart = startOfWeek(subWeeks(now, 1));
  const lastWeekEnd = thisWeekStart;
  const lastWeekCount = uniqueSignals.filter(s => {
    const detected = new Date(s.first_detected_at);
    return detected >= lastWeekStart && detected < lastWeekEnd;
  }).length;
  const thisWeekCount = newThisWeek.length;
  const weekOverWeekChange = lastWeekCount > 0 
    ? Math.round(((thisWeekCount - lastWeekCount) / lastWeekCount) * 100)
    : thisWeekCount > 0 ? 100 : 0;

  return {
    signals: uniqueSignals,
    signalTypes,
    counts,
    stageBreakdown,
    weeklyTrends,
    monthlyTrends,
    newThisWeek,
    weekOverWeekChange,
    isLoading,
    error,
  };
}

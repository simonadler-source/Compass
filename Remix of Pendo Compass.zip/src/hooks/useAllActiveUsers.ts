import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';

export interface ActiveUser {
  id: string;
  email: string;
  full_name: string | null;
}

export function useAllActiveUsers() {
  const { data: users, isLoading, error } = useQuery({
    queryKey: ['all-active-users'],
    queryFn: async () => {
      // Include active, pending, and identified users so they can be assigned as owners
      // 'identified' users are internal team members captured from meetings
      const result = await gateway.from('profiles')
        .select('id, email, full_name')
        .in('status', ['active', 'pending', 'identified'])
        .order('full_name', { ascending: true })
        .execute();

      if (result.error) throw new Error(result.error.message);
      return result.data as ActiveUser[];
    },
  });

  return {
    users: users || [],
    isLoading,
    error,
  };
}

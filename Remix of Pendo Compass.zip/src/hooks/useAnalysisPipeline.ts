import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface AnalysisPipeline {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export interface AnalysisPass {
  id: string;
  pipeline_id: string;
  name: string;
  description: string | null;
  pass_key: string;
  sort_order: number;
  status: 'active' | 'inactive' | 'deprecated';
  system_prompt: string;
  output_schema: any;
  timeout_seconds: number;
  max_tokens: number | null;
  is_async: boolean;
  version: number;
  last_edited_by: string | null;
  created_at: string;
  updated_at: string;
  condition_config?: {
    meeting_types?: string[];
  } | null;
}

export interface PassDependency {
  id: string;
  pass_id: string;
  depends_on_pass_id: string;
  dependency_type: 'required' | 'optional' | 'conditional';
  field_mappings: Record<string, string> | null;
  created_at: string;
}

export interface DetectionRulePassLink {
  id: string;
  detection_rule_id: string;
  pass_id: string;
  trigger_behavior: 'include' | 'trigger';
  created_at: string;
  detection_rules?: {
    id: string;
    name: string;
    description: string | null;
    is_active: boolean;
  };
}

export interface PassWithDependencies extends AnalysisPass {
  dependencies: PassDependency[];
  dependents: PassDependency[];
  linked_rules: DetectionRulePassLink[];
}

export function useAnalysisPipelines() {
  return useQuery({
    queryKey: ['analysis-pipelines'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('analysis_pipelines')
        .select('*')
        .order('is_default', { ascending: false });
      
      if (error) throw error;
      return data as AnalysisPipeline[];
    },
  });
}

export function useAnalysisPasses(pipelineId: string | null) {
  return useQuery({
    queryKey: ['analysis-passes', pipelineId],
    queryFn: async () => {
      if (!pipelineId) return [];
      
      const { data, error } = await supabase
        .from('analysis_passes')
        .select('*')
        .eq('pipeline_id', pipelineId)
        .order('sort_order');
      
      if (error) throw error;
      return data as AnalysisPass[];
    },
    enabled: !!pipelineId,
  });
}

export function usePassDependencies(pipelineId: string | null) {
  return useQuery({
    queryKey: ['pass-dependencies', pipelineId],
    queryFn: async () => {
      if (!pipelineId) return [];
      
      // Get all pass IDs for this pipeline first
      const { data: passes } = await supabase
        .from('analysis_passes')
        .select('id')
        .eq('pipeline_id', pipelineId);
      
      if (!passes?.length) return [];
      
      const passIds = passes.map(p => p.id);
      
      const { data, error } = await supabase
        .from('analysis_pass_dependencies')
        .select('*')
        .in('pass_id', passIds);
      
      if (error) throw error;
      return data as PassDependency[];
    },
    enabled: !!pipelineId,
  });
}

export function useDetectionRulePassLinks(pipelineId: string | null) {
  return useQuery({
    queryKey: ['detection-rule-pass-links', pipelineId],
    queryFn: async () => {
      if (!pipelineId) return [];
      
      // Get all pass IDs for this pipeline first
      const { data: passes } = await supabase
        .from('analysis_passes')
        .select('id')
        .eq('pipeline_id', pipelineId);
      
      if (!passes?.length) return [];
      
      const passIds = passes.map(p => p.id);
      
      const { data, error } = await supabase
        .from('detection_rule_pass_links')
        .select(`
          *,
          detection_rules:detection_rule_id (
            id,
            name,
            description,
            is_active
          )
        `)
        .in('pass_id', passIds);
      
      if (error) throw error;
      return data as DetectionRulePassLink[];
    },
    enabled: !!pipelineId,
  });
}

export function useUpdatePass() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      passId,
      updates,
    }: {
      passId: string;
      updates: Partial<Pick<AnalysisPass, 'system_prompt' | 'name' | 'description' | 'timeout_seconds' | 'status' | 'sort_order' | 'condition_config'>>;
    }) => {
      // Fetch current pass (use gateway for consistent auth + error handling)
      const { data: currentPass, error: fetchError } = await gateway
        .from<Pick<AnalysisPass, 'version' | 'system_prompt' | 'output_schema' | 'pipeline_id'>>('analysis_passes')
        .select('version, system_prompt, output_schema, pipeline_id')
        .eq('id', passId)
        .maybeSingle()
        .execute();

      if (fetchError) throw new Error(getErrorMessage(fetchError));
      if (!currentPass) throw new Error('Pass not found (or you do not have access)');

      // If prompt is changing, save version history
      if (updates.system_prompt && updates.system_prompt !== currentPass.system_prompt) {
        const { error: versionErr } = await gateway
          .from('analysis_pass_versions')
          .insert({
            pass_id: passId,
            version_number: currentPass.version,
            system_prompt: currentPass.system_prompt,
            output_schema: currentPass.output_schema,
            change_notes: 'Backup before edit',
          })
          .execute();

        if (versionErr) throw new Error(getErrorMessage(versionErr));
      }

      const nextVersion = updates.system_prompt ? currentPass.version + 1 : currentPass.version;

      const { error: updateErr } = await gateway
        .from('analysis_passes')
        .update({
          ...updates,
          version: nextVersion,
          updated_at: new Date().toISOString(),
        })
        .eq('id', passId)
        .execute();

      if (updateErr) throw new Error(getErrorMessage(updateErr));

      return { pipelineId: currentPass.pipeline_id };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['analysis-passes', data.pipelineId] });
      toast.success('Pass updated successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to update pass: ${error.message}`);
    },
  });
}

export function useReorderPasses() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      pipelineId,
      passOrders 
    }: { 
      pipelineId: string;
      passOrders: { id: string; sort_order: number }[] 
    }) => {
      for (const { id, sort_order } of passOrders) {
        const { error } = await supabase
          .from('analysis_passes')
          .update({ sort_order })
          .eq('id', id);
        
        if (error) throw error;
      }
      
      return { pipelineId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['analysis-passes', data.pipelineId] });
      toast.success('Pass order updated');
    },
    onError: (error: Error) => {
      toast.error(`Failed to reorder passes: ${error.message}`);
    },
  });
}

export function useLinkDetectionRule() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      ruleId, 
      passId,
      triggerBehavior = 'include'
    }: { 
      ruleId: string; 
      passId: string;
      triggerBehavior?: 'include' | 'trigger';
    }) => {
      const { error } = await supabase
        .from('detection_rule_pass_links')
        .upsert({
          detection_rule_id: ruleId,
          pass_id: passId,
          trigger_behavior: triggerBehavior,
        }, { onConflict: 'detection_rule_id,pass_id' });
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-pass-links'] });
      toast.success('Detection rule linked');
    },
    onError: (error: Error) => {
      toast.error(`Failed to link rule: ${error.message}`);
    },
  });
}

export function useUnlinkDetectionRule() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ linkId }: { linkId: string }) => {
      const { error } = await supabase
        .from('detection_rule_pass_links')
        .delete()
        .eq('id', linkId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-pass-links'] });
      toast.success('Detection rule unlinked');
    },
    onError: (error: Error) => {
      toast.error(`Failed to unlink rule: ${error.message}`);
    },
  });
}

export function useCreatePass() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      pipelineId,
      name,
      passKey,
      description,
      systemPrompt,
      isAsync = false,
      timeoutSeconds = 45,
      sortOrder
    }: { 
      pipelineId: string;
      name: string;
      passKey: string;
      description?: string;
      systemPrompt: string;
      isAsync?: boolean;
      timeoutSeconds?: number;
      sortOrder: number;
    }) => {
      const { data, error } = await supabase
        .from('analysis_passes')
        .insert({
          pipeline_id: pipelineId,
          name,
          pass_key: passKey,
          description,
          system_prompt: systemPrompt,
          is_async: isAsync,
          timeout_seconds: timeoutSeconds,
          sort_order: sortOrder,
          status: 'active',
          version: 1,
        })
        .select()
        .single();
      
      if (error) throw error;
      return { pipelineId, pass: data };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['analysis-passes', data.pipelineId] });
      toast.success('Pass created successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to create pass: ${error.message}`);
    },
  });
}

export function useDeletePass() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ passId, pipelineId }: { passId: string; pipelineId: string }) => {
      const { error } = await supabase
        .from('analysis_passes')
        .delete()
        .eq('id', passId);
      
      if (error) throw error;
      return { pipelineId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['analysis-passes', data.pipelineId] });
      toast.success('Pass deleted');
    },
    onError: (error: Error) => {
      toast.error(`Failed to delete pass: ${error.message}`);
    },
  });
}

export function useUpdatePassDependencies() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      passId,
      pipelineId,
      dependencies,
    }: {
      passId: string;
      pipelineId: string;
      dependencies: { depends_on_pass_id: string; dependency_type: string }[];
    }) => {
      // Delete existing dependencies for this pass
      const { error: deleteErr } = await gateway
        .from('analysis_pass_dependencies')
        .delete()
        .eq('pass_id', passId)
        .execute();

      if (deleteErr) throw new Error(getErrorMessage(deleteErr));

      // Insert new dependencies
      if (dependencies.length > 0) {
        const { error: insertErr } = await gateway
          .from('analysis_pass_dependencies')
          .insert(
            dependencies.map((dep) => ({
              pass_id: passId,
              depends_on_pass_id: dep.depends_on_pass_id,
              dependency_type: dep.dependency_type,
            }))
          )
          .execute();

        if (insertErr) throw new Error(getErrorMessage(insertErr));
      }

      return { pipelineId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['pass-dependencies', data.pipelineId] });
      toast.success('Dependencies updated');
    },
    onError: (error: Error) => {
      toast.error(`Failed to update dependencies: ${error.message}`);
    },
  });
}

import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface AnalysisRunLog {
  id: string;
  transcript_id: string;
  pass_key: string;
  pass_name: string | null;
  phase: string;
  status: string;
  started_at: string;
  completed_at: string | null;
  duration_ms: number | null;
  retry_attempt: number;
  max_retries: number;
  error_message: string | null;
  error_category: string | null;
  input_tokens_estimate: number | null;
  output_tokens_estimate: number | null;
  result_summary: any;
  metadata: any;
}

export function useAnalysisRunLogs(transcriptId: string | null) {
  return useQuery({
    queryKey: ['analysis-run-logs', transcriptId],
    queryFn: async () => {
      if (!transcriptId) return [];
      const { data, error } = await supabase
        .from('analysis_run_logs')
        .select('*')
        .eq('transcript_id', transcriptId)
        .order('started_at', { ascending: true });
      if (error) throw error;
      return (data || []) as AnalysisRunLog[];
    },
    enabled: !!transcriptId,
  });
}

export interface PipelineHealthStats {
  totalRuns: number;
  completedRuns: number;
  failedRuns: number;
  avgDurationMs: number;
  successRate: number;
  failuresByPass: Record<string, number>;
  failuresByCategory: Record<string, number>;
  recentFailures: AnalysisRunLog[];
}

export function usePipelineHealthStats(daysBack = 7) {
  return useQuery({
    queryKey: ['pipeline-health-stats', daysBack],
    queryFn: async () => {
      const since = new Date();
      since.setDate(since.getDate() - daysBack);

      const { data, error } = await supabase
        .from('analysis_run_logs')
        .select('*')
        .gte('started_at', since.toISOString())
        .order('started_at', { ascending: false });

      if (error) throw error;
      const logs = (data || []) as AnalysisRunLog[];

      const completed = logs.filter(l => l.status === 'completed');
      const failed = logs.filter(l => l.status === 'failed');
      const durations = completed.filter(l => l.duration_ms).map(l => l.duration_ms!);
      const avgDuration = durations.length > 0 ? durations.reduce((a, b) => a + b, 0) / durations.length : 0;

      const failuresByPass: Record<string, number> = {};
      const failuresByCategory: Record<string, number> = {};
      for (const f of failed) {
        failuresByPass[f.pass_key] = (failuresByPass[f.pass_key] || 0) + 1;
        const cat = f.error_category || 'unknown';
        failuresByCategory[cat] = (failuresByCategory[cat] || 0) + 1;
      }

      return {
        totalRuns: logs.length,
        completedRuns: completed.length,
        failedRuns: failed.length,
        avgDurationMs: Math.round(avgDuration),
        successRate: logs.length > 0 ? Math.round((completed.length / logs.length) * 100) : 100,
        failuresByPass,
        failuresByCategory,
        recentFailures: failed.slice(0, 20),
      } as PipelineHealthStats;
    },
    refetchInterval: 60000,
  });
}

// Get transcripts with failed/incomplete analysis
export function useFlaggedTranscripts(limit = 50) {
  return useQuery({
    queryKey: ['flagged-transcripts', limit],
    queryFn: async () => {
      // Get transcripts that have at least one failed pass and no subsequent successful run
      const { data, error } = await supabase
        .from('analysis_run_logs')
        .select('transcript_id, pass_key, pass_name, status, error_message, error_category, started_at, retry_attempt')
        .eq('status', 'failed')
        .order('started_at', { ascending: false })
        .limit(limit);

      if (error) throw error;
      
      // Group by transcript
      const grouped = new Map<string, typeof data>();
      for (const log of data || []) {
        const existing = grouped.get(log.transcript_id) || [];
        existing.push(log);
        grouped.set(log.transcript_id, existing);
      }

      return Array.from(grouped.entries()).map(([transcriptId, failures]) => ({
        transcriptId,
        failedPasses: failures.length,
        failedPassKeys: [...new Set(failures.map(f => f.pass_key))],
        latestFailure: failures[0],
        failures,
      }));
    },
  });
}

import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AnalyzeDocumentInput {
  opportunityId: string;
  documentContent: string;
  documentName: string;
}

interface AnalyzeResult {
  success: boolean;
  themes_count: number;
  criteria_count: number;
  deliverables_count: number;
  themes: { name: string; criteria_count: number }[];
}

export function useAnalyzeDocumentCriteria() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ opportunityId, documentContent, documentName }: AnalyzeDocumentInput): Promise<AnalyzeResult> => {
      const { data, error } = await supabase.functions.invoke('analyze-document-criteria', {
        body: {
          opportunity_id: opportunityId,
          document_content: documentContent,
          document_name: documentName,
        },
      });

      if (error) throw new Error(error.message || 'Analysis failed');
      if (data?.error) throw new Error(data.error);
      return data as AnalyzeResult;
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['success-criteria', variables.opportunityId] });
      const themeNames = data.themes.map(t => t.name).join(', ');
      toast.success(
        `Generated ${data.criteria_count} criteria across ${data.themes_count} themes (${themeNames}) with ${data.deliverables_count} deliverables`,
        { duration: 8000 }
      );
    },
    onError: (error: Error) => {
      if (error.message.includes('Rate limited')) {
        toast.error('Rate limited — please try again in a moment');
      } else if (error.message.includes('credits')) {
        toast.error('AI credits exhausted. Please add credits in workspace settings.');
      } else {
        toast.error('Document analysis failed: ' + error.message);
      }
    },
  });
}

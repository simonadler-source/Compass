import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface ArchitectureSnapshot {
  functionalAreas: Array<{
    id: string;
    name: string;
    layer: string;
    x: number;
    y: number;
    width: number;
    height: number;
    color: string;
  }>;
  technologies: Array<{
    id: string;
    techId: string;
    name: string;
    functionalArea: string;
    layer: string;
    x: number;
    y: number;
  }>;
  connections: Array<{
    id: string;
    fromTechId: string;
    toTechId: string;
    label?: string;
    fromPort?: string;
    toPort?: string;
  }>;
}

export interface ArchitectureVersion {
  id: string;
  name: string;
  description: string | null;
  snapshot: ArchitectureSnapshot;
  created_at: string;
  created_by: string | null;
  is_current: boolean;
  version_number: number;
}

export function useArchitectureVersions() {
  return useQuery({
    queryKey: ['architecture-versions'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('architecture_versions')
        .select('*')
        .order('created_at', { ascending: false })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return (data || []).map(item => ({
        ...item,
        snapshot: item.snapshot as unknown as ArchitectureSnapshot,
      })) as ArchitectureVersion[];
    },
  });
}

export function useCurrentArchitectureVersion() {
  return useQuery({
    queryKey: ['architecture-versions', 'current'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('architecture_versions')
        .select('*')
        .eq('is_current', true)
        .maybeSingle()
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      if (!data) return null;
      return {
        ...data,
        snapshot: data.snapshot as unknown as ArchitectureSnapshot,
      } as ArchitectureVersion;
    },
  });
}

export function useSaveArchitectureVersion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      name, 
      description, 
      snapshot 
    }: { 
      name: string; 
      description?: string; 
      snapshot: ArchitectureSnapshot;
    }) => {
      // Get the next version number
      const { data: versions } = await gateway
        .from('architecture_versions')
        .select('version_number')
        .order('version_number', { ascending: false })
        .limit(1)
        .execute();

      const nextVersion = (versions?.[0]?.version_number || 0) + 1;

      // Unset current flag on all versions
      await gateway
        .from('architecture_versions')
        .update({ is_current: false })
        .eq('is_current', true)
        .execute();

      // Create new version as current
      const { data, error } = await gateway
        .from('architecture_versions')
        .insert([{
          name,
          description: description || null,
          snapshot: JSON.parse(JSON.stringify(snapshot)),
          version_number: nextVersion,
          is_current: true,
        }])
        .select('*')
        .single()
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['architecture-versions'] });
      toast.success('Architecture version saved');
    },
    onError: (error) => {
      console.error('Failed to save version:', error);
      toast.error('Failed to save architecture version');
    },
  });
}

export function useRestoreArchitectureVersion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (versionId: string) => {
      // Unset current flag on all versions
      await gateway
        .from('architecture_versions')
        .update({ is_current: false })
        .eq('is_current', true)
        .execute();

      // Set the selected version as current
      const { data, error } = await gateway
        .from('architecture_versions')
        .update({ is_current: true })
        .eq('id', versionId)
        .select('*')
        .single()
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return {
        ...data,
        snapshot: data.snapshot as unknown as ArchitectureSnapshot,
      } as ArchitectureVersion;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['architecture-versions'] });
      toast.success(`Restored to version ${data.version_number}: ${data.name}`);
    },
    onError: (error) => {
      console.error('Failed to restore version:', error);
      toast.error('Failed to restore architecture version');
    },
  });
}

export function useDeleteArchitectureVersion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (versionId: string) => {
      const { error } = await gateway
        .from('architecture_versions')
        .delete()
        .eq('id', versionId)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['architecture-versions'] });
      toast.success('Version deleted');
    },
    onError: (error) => {
      console.error('Failed to delete version:', error);
      toast.error('Failed to delete version');
    },
  });
}

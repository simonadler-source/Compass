import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

export type AssignableUserSource = 'account_team_member' | 'opportunity_team_member' | 'stakeholder' | 'opportunity_owner' | 'opportunity_se' | 'account_owner' | 'account_se';

export interface AssignableUser {
  email: string;
  full_name: string | null;
  role: string | null;
  source: AssignableUserSource;
  isExternal?: boolean;
}

/**
 * Returns assignable users for NBA delegation, including:
 * 1. Opportunity owner (AE) and primary SE from opportunity record
 * 2. Account owner and primary SE from account record
 * 3. Account team members (people who attended meetings)
 * 4. Opportunity team members
 * 5. External: Account contacts (stakeholders) across all opportunities
 */
export function useAssignableOpportunityUsers(
  accountId: string | null | undefined,
  opportunityId?: string | null
) {
  return useQuery({
    queryKey: ['assignable-opportunity-users', accountId, opportunityId],
    enabled: !!accountId,
    queryFn: async () => {
      if (!accountId) {
        return { allUsers: [], teamMembers: [], stakeholderUsers: [] };
      }

      // Build unique set of internal team member emails
      const internalEmailsMap = new Map<string, { role: string | null; source: AssignableUserSource }>();

      // Fetch opportunity details if opportunityId provided (to get owner and SE)
      if (opportunityId) {
        const oppResponse = await gateway.from('opportunities')
          .select('owner_email, primary_se_email')
          .eq('id', opportunityId)
          .maybeSingle()
          .execute();
        
        if (oppResponse.data) {
          const opp = oppResponse.data as any;
          if (opp.owner_email) {
            const email = opp.owner_email.toLowerCase().trim();
            internalEmailsMap.set(email, { role: 'Account Executive', source: 'opportunity_owner' });
          }
          if (opp.primary_se_email) {
            const email = opp.primary_se_email.toLowerCase().trim();
            if (!internalEmailsMap.has(email)) {
              internalEmailsMap.set(email, { role: 'Solutions Engineer', source: 'opportunity_se' });
            }
          }
        }
      }

      // Fetch account details (to get owner and SE)
      const accResponse = await gateway.from('accounts')
        .select('owner_id, primary_se_email')
        .eq('id', accountId)
        .maybeSingle()
        .execute();

      // If account has owner_id, get their email from profiles
      if (accResponse.data) {
        const acc = accResponse.data as any;
        if (acc.owner_id) {
          const ownerProfileResponse = await gateway.from('profiles')
            .select('email')
            .eq('id', acc.owner_id)
            .maybeSingle()
            .execute();
          if (ownerProfileResponse.data?.email) {
            const email = ownerProfileResponse.data.email.toLowerCase().trim();
            if (!internalEmailsMap.has(email)) {
              internalEmailsMap.set(email, { role: 'Account Executive', source: 'account_owner' });
            }
          }
        }
        if (acc.primary_se_email) {
          const email = acc.primary_se_email.toLowerCase().trim();
          if (!internalEmailsMap.has(email)) {
            internalEmailsMap.set(email, { role: 'Solutions Engineer', source: 'account_se' });
          }
        }
      }

      // Fetch account team members (internal people who attended meetings for this account)
      const accTeamResponse = await gateway.from('account_team_members')
        .select('team_member_email, role')
        .eq('account_id', accountId)
        .execute();
      if (accTeamResponse.error) throw new Error(getErrorMessage(accTeamResponse.error));
      const accountTeamMembers = accTeamResponse.data || [];

      // Fetch opportunity team members if opportunityId provided
      let opportunityTeamMembers: any[] = [];
      if (opportunityId) {
        const oppTeamResponse = await gateway.from('opportunity_team_members')
          .select('team_member_email, role')
          .eq('opportunity_id', opportunityId)
          .execute();
        if (oppTeamResponse.error) throw new Error(getErrorMessage(oppTeamResponse.error));
        opportunityTeamMembers = oppTeamResponse.data || [];
      }

      // Fetch all opportunity team members for this account (to include all possible internal assignees)
      const allOppTeamResponse = await gateway.from('opportunity_team_members')
        .select('team_member_email, role, opportunity_id')
        .in('opportunity_id', 
          // We need opportunities for this account - fetch them
          (await gateway.from('opportunities')
            .select('id')
            .eq('account_id', accountId)
            .execute()).data?.map((o: any) => o.id) || []
        )
        .execute();
      const allOpportunityTeamMembers = allOppTeamResponse.data || [];

      // Fetch profiles to get names for internal users
      const profilesResponse = await gateway.from('profiles')
        .select('email, full_name')
        .execute();
      const profiles = profilesResponse.data || [];
      const profileNameByEmail = new Map(
        (profiles || []).map((p: any) => [p.email?.toLowerCase(), p.full_name])
      );

      // Fetch team_members table for additional name lookups
      const teamMembersResponse = await gateway.from('team_members')
        .select('member_email, member_name')
        .execute();
      const teamMembersData = teamMembersResponse.data || [];
      const teamMemberNameByEmail = new Map(
        (teamMembersData || []).map((tm: any) => [tm.member_email?.toLowerCase(), tm.member_name])
      );
      
      // Add account team members
      for (const m of accountTeamMembers) {
        const email = m.team_member_email?.toLowerCase().trim();
        if (email && !internalEmailsMap.has(email)) {
          internalEmailsMap.set(email, { role: m.role || null, source: 'account_team_member' });
        }
      }
      
      // Add opportunity team members (current opportunity takes priority for source)
      for (const m of opportunityTeamMembers) {
        const email = m.team_member_email?.toLowerCase().trim();
        if (email && !internalEmailsMap.has(email)) {
          internalEmailsMap.set(email, { role: m.role || null, source: 'opportunity_team_member' });
        }
      }

      // Add all other opportunity team members from account
      for (const m of allOpportunityTeamMembers) {
        const email = m.team_member_email?.toLowerCase().trim();
        if (email && !internalEmailsMap.has(email)) {
          internalEmailsMap.set(email, { role: m.role || null, source: 'opportunity_team_member' });
        }
      }

      // Build team members list with names
      const teamMembers: AssignableUser[] = [...internalEmailsMap.entries()].map(([email, info]) => {
        const fullName = (profileNameByEmail.get(email) || teamMemberNameByEmail.get(email) || null) as string | null;
        return {
          email,
          full_name: fullName,
          role: info.role,
          source: info.source,
          isExternal: false,
        };
      }).sort((a, b) => {
        const aKey = (a.full_name || a.email).toLowerCase();
        const bKey = (b.full_name || b.email).toLowerCase();
        return aKey.localeCompare(bKey);
      });

      // Fetch account contacts/stakeholders (external contacts across all opportunities)
      const contactsResponse = await gateway.from('account_contacts')
        .select('id, name, email, role, opportunity_id, is_internal')
        .eq('account_id', accountId)
        .not('is_ignored', 'is', true)
        .execute();
      if (contactsResponse.error) throw new Error(getErrorMessage(contactsResponse.error));
      const accountContacts = contactsResponse.data || [];

      // Build stakeholder users from account contacts (external contacts only)
      // Use Map to deduplicate by email
      const stakeholderMap = new Map<string, AssignableUser>();
      for (const c of accountContacts) {
        if (c.email && !c.is_internal) {
          const email = c.email.toLowerCase().trim();
          if (!stakeholderMap.has(email)) {
            stakeholderMap.set(email, {
              email: c.email,
              full_name: c.name || null,
              role: c.role || null,
              source: 'stakeholder' as const,
              isExternal: true,
            });
          }
        }
      }

      const stakeholderUsers = [...stakeholderMap.values()].sort((a, b) => {
        const aKey = (a.full_name || a.email).toLowerCase();
        const bKey = (b.full_name || b.email).toLowerCase();
        return aKey.localeCompare(bKey);
      });

      // Combine all users: team members first, then stakeholders (excluding duplicates)
      const teamMemberEmails = new Set(teamMembers.map(t => t.email.toLowerCase()));
      const allUsers = [
        ...teamMembers,
        ...stakeholderUsers.filter(s => !teamMemberEmails.has(s.email.toLowerCase())),
      ];

      // Return with backwards-compatible property names
      return { 
        allUsers, 
        teamMembers,
        seUsers: teamMembers, // backwards compatibility
        aeUsers: teamMembers, // backwards compatibility  
        stakeholderUsers 
      };
    },
  });
}

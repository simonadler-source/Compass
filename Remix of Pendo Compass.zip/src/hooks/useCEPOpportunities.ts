import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { SALES_STAGE_TO_CEP, SIGNAL_TO_CEP_ACTIVITIES, CEP_STAGES, CEPSignalType } from '@/lib/cepConfig';
import { differenceInDays } from 'date-fns';

export interface SignalOccurrence {
  transcriptId: string;
  detectedAt: string;
  speakerName: string | null;
  speakerEmail: string | null;
  matchedPhrases: string[];
  confidenceScore: number | null;
}

export interface CEPSignal {
  id: string;
  ruleId: string;
  type: CEPSignalType;
  ruleName: string;
  detectedAt: string;
  inferredStageStart: number;
  inferredStageEnd: number;
  matchedPhrases: string[];
  speakerType: 'internal' | 'external' | 'unknown' | null;
  speakerName: string | null;
  occurrenceCount: number;
  occurrences: SignalOccurrence[];
}

export interface PreSalesStageMapping {
  stageKey: string;
  stageLabel: string;
  timelinePosition: number;
}

export interface ProductMentionOnTimeline {
  id: string;
  productName: string;
  mentionType: 'owned' | 'complementary' | 'competitive';
  mentionCount: number;
  transcriptDate: string;
}

export interface CEPOpportunity {
  id: string;
  name: string;
  salesforceOpportunityId: string | null;
  accountId: string;
  accountName: string;
  crmStage: number | null;
  salesStage: string | null;
  preSalesStage: string | null;
  preSalesTimelinePosition: number | null;
  inferredStage: number | null;
  stageDiscrepancy: number;
  signals: CEPSignal[];
  signalsByStage: Record<number, CEPSignal[]>;
  lastActivityAt: string | null;
  daysInCurrentStage: number | null;
  missingExitCriteria: string[];
  ownerEmail: string | null;
  primarySeEmail: string | null;
  ownerManagerEmail: string | null;
  seManagerEmail: string | null;
  createdAt: string | null;
  closeDate: string | null;
  firstActivityDate: string | null;
  productMentions: ProductMentionOnTimeline[];
  updatedAt: string | null;
  lastTranscriptAt: string | null;
  isArchived: boolean;
  isClosedWon: boolean;
  isClosedLost: boolean;
  // Evaluation period fields
  primaryEvalQuote: string | null;
  evalStartDate: string | null;
  evalEndDate: string | null;
  evalType: string | null;
}

export interface CEPFilters {
  stageFilter: number[] | null;
  ownerFilter: string[] | null;
  teamEmails: string[] | null; // Filter to only show opportunities for team members
  hasGaps: boolean;
  stuckThresholdDays: number | null;
}

// Activity Signals tree ID - defined at module level for use in queries
const ACTIVITY_SIGNAL_TREE_ID = 'f5e4d3c2-b1a0-9876-5432-fedcba098765';

export function useCEPOpportunities(filters?: CEPFilters) {
  return useQuery({
    queryKey: ['cep-opportunities', filters],
    queryFn: async () => {
      // Fetch opportunities, signals, mappings, and team hierarchy for manager lookup
      // Paginated fetch for opportunities to avoid 1000-row PostgREST limit
      const fetchAllOpportunities = async () => {
        const allOpps: any[] = [];
        const pageSize = 1000;
        const maxPages = 50; // Safety cap: 50,000 opportunities
        
        for (let page = 0; page < maxPages; page++) {
          const from = page * pageSize;
          const to = from + pageSize - 1;
          
          const response = await gateway.from('opportunities')
            .select(`
              id,
              name,
              account_id,
              sales_stage,
              pre_sales_stage,
              salesforce_opportunity_id,
              owner_email,
              primary_se_email,
              last_meeting_at,
              created_at,
              close_date,
              updated_at,
              is_archived,
              primary_eval_quote,
              eval_start_date,
              eval_end_date,
              eval_type,
              accounts!inner (
                id,
                name
              )
            `)
            .order('last_meeting_at', { ascending: false })
            .range(from, to)
            .execute();
          
          if (response.error) throw new Error(getErrorMessage(response.error));
          const data = response.data || [];
          allOpps.push(...data);
          
          // If we got fewer than pageSize, we've fetched everything
          if (data.length < pageSize) break;
        }
        
        return allOpps;
      };

      // Paginated fetch for detection rule matches
      const fetchAllSignals = async () => {
        const allSignals: any[] = [];
        const pageSize = 1000;
        const maxPages = 50;
        
        for (let page = 0; page < maxPages; page++) {
          const from = page * pageSize;
          const to = from + pageSize - 1;
          
          const response = await gateway.from('detection_rule_matches')
            .select(`
              id,
              rule_id,
              opportunity_id,
              matched_phrases,
              first_detected_at,
              speaker_type,
              speaker_name,
              occurrence_count,
              signal_occurrences,
              detection_rules!inner (
                id,
                name,
                tree_id
              )
            `)
            .eq('detection_rules.tree_id', ACTIVITY_SIGNAL_TREE_ID)
            .not('opportunity_id', 'is', null)
            .order('first_detected_at', { ascending: true })
            .range(from, to)
            .execute();
          
          if (response.error) throw new Error(getErrorMessage(response.error));
          const data = response.data || [];
          allSignals.push(...data);
          
          if (data.length < pageSize) break;
        }
        
        return allSignals;
      };

      const [opps, allSignals, preSalesMappingResponse, hierarchyResponse, profilesResponse, productMentionsResponse] = await Promise.all([
        fetchAllOpportunities(),
        fetchAllSignals(),
        gateway.from('pre_sales_stage_mapping')
          .select('stage_key, stage_label, timeline_position')
          .order('sort_order', { ascending: true })
          .execute(),
        gateway.from('team_hierarchy')
          .select('manager_id, report_id')
          .execute(),
        gateway.from('profiles')
          .select('id, email')
          .execute(),
        // Fetch product mentions for all opportunities
        gateway.from('product_mentions')
          .select('id, opportunity_id, product_name, mention_type, mention_count, transcript_date')
          .not('opportunity_id', 'is', null)
          .order('transcript_date', { ascending: true })
          .execute(),
      ]);

      const preSalesMappings = preSalesMappingResponse.data || [];
      const hierarchyData = hierarchyResponse.data || [];
      const profilesData = profilesResponse.data || [];
      const allProductMentions = productMentionsResponse.data || [];

      // Build email to user id map
      const emailToUserId = new Map<string, string>();
      const userIdToEmail = new Map<string, string>();
      profilesData.forEach((p: any) => {
        if (p.email) {
          emailToUserId.set(p.email.toLowerCase(), p.id);
          userIdToEmail.set(p.id, p.email.toLowerCase());
        }
      });

      // Build user id to manager email map
      const userIdToManagerEmail = new Map<string, string>();
      hierarchyData.forEach((h: any) => {
        const managerEmail = userIdToEmail.get(h.manager_id);
        if (managerEmail) {
          userIdToManagerEmail.set(h.report_id, managerEmail);
        }
      });

      // Helper to get manager email for a given user email
      const getManagerEmail = (email: string | null): string | null => {
        if (!email) return null;
        const userId = emailToUserId.get(email.toLowerCase());
        if (!userId) return null;
        return userIdToManagerEmail.get(userId) || null;
      };

      // Build pre-sales stage to timeline position map (case-insensitive)
      const preSalesPositionMap = new Map<string, number>();
      preSalesMappings.forEach((m: any) => {
        // Store both lowercase key and original for case-insensitive matching
        preSalesPositionMap.set(m.stage_key.toLowerCase(), m.timeline_position);
        preSalesPositionMap.set(m.stage_label.toLowerCase(), m.timeline_position);
      });

      // Use module-level ACTIVITY_SIGNAL_TREE_ID constant

      // Group signals by opportunity
      const signalsByOpp = new Map<string, any[]>();
      allSignals.forEach((signal: any) => {
        if (signal.detection_rules?.tree_id !== ACTIVITY_SIGNAL_TREE_ID) return;
        const oppId = signal.opportunity_id;
        if (!signalsByOpp.has(oppId)) {
          signalsByOpp.set(oppId, []);
        }
        signalsByOpp.get(oppId)!.push(signal);
      });

      // Group product mentions by opportunity
      const productMentionsByOpp = new Map<string, ProductMentionOnTimeline[]>();
      allProductMentions.forEach((pm: any) => {
        const oppId = pm.opportunity_id;
        if (!productMentionsByOpp.has(oppId)) {
          productMentionsByOpp.set(oppId, []);
        }
        productMentionsByOpp.get(oppId)!.push({
          id: pm.id,
          productName: pm.product_name,
          mentionType: pm.mention_type,
          mentionCount: pm.mention_count || 1,
          transcriptDate: pm.transcript_date,
        });
      });

      // Process opportunities
      const cepOpportunities: CEPOpportunity[] = opps.map((opp: any) => {
        const salesStage = opp.sales_stage as string | null;
        const crmStage = salesStage ? (SALES_STAGE_TO_CEP[salesStage] ?? null) : null;

        const oppSignals = signalsByOpp.get(opp.id) || [];
        
        // Transform signals and determine inferred stages
        const signals: CEPSignal[] = oppSignals.map((s: any) => {
          const ruleName = s.detection_rules?.name || '';
          const signalConfig = SIGNAL_TO_CEP_ACTIVITIES[ruleName];
          
          // Infer stage range based on signal type
          const inferredStageStart = signalConfig ? signalConfig.stageStart : 0;
          const inferredStageEnd = signalConfig ? signalConfig.stageEnd : 0;
          
          // Parse signal occurrences from JSON
          const rawOccurrences = s.signal_occurrences || [];
          const occurrences: SignalOccurrence[] = Array.isArray(rawOccurrences) 
            ? rawOccurrences.map((o: any) => ({
                transcriptId: o.transcript_id || o.transcriptId || '',
                detectedAt: o.detected_at || o.detectedAt || s.first_detected_at,
                speakerName: o.speaker_name || o.speakerName || null,
                speakerEmail: o.speaker_email || o.speakerEmail || null,
                matchedPhrases: o.matched_phrases || o.matchedPhrases || [],
                confidenceScore: o.confidence_score || o.confidenceScore || null,
              }))
            : [];
          
          // If no occurrences in array, create one from the main record
          if (occurrences.length === 0) {
            occurrences.push({
              transcriptId: s.transcript_id || '',
              detectedAt: s.first_detected_at,
              speakerName: s.speaker_name,
              speakerEmail: s.speaker_email || null,
              matchedPhrases: s.matched_phrases || [],
              confidenceScore: s.confidence_score || null,
            });
          }
          
          return {
            id: s.id,
            ruleId: s.rule_id,
            type: signalConfig?.type || 'demo',
            ruleName,
            detectedAt: s.first_detected_at,
            inferredStageStart,
            inferredStageEnd,
            matchedPhrases: s.matched_phrases || [],
            speakerType: s.speaker_type,
            speakerName: s.speaker_name,
            occurrenceCount: s.occurrence_count || occurrences.length,
            occurrences,
          };
        });

        // Group signals by their stage start (where they first appear on timeline)
        const signalsByStage: Record<number, CEPSignal[]> = {};
        signals.forEach(signal => {
          // Place signal at its starting stage
          const stage = signal.inferredStageStart;
          if (!signalsByStage[stage]) signalsByStage[stage] = [];
          signalsByStage[stage].push(signal);
        });

        // Calculate inferred stage based on highest signal stage end
        let inferredStage: number | null = null;
        if (signals.length > 0) {
          // Find the highest stage end across all signals
          const hasLegal = signals.some(s => s.type === 'legal');
          const hasSecurity = signals.some(s => s.type === 'security');
          const hasEvaluation = signals.some(s => s.type === 'evaluation');
          const hasReverseDemo = signals.some(s => s.type === 'reverse_demo');
          const hasTechnicalDiscovery = signals.some(s => s.type === 'technical_discovery');
          const hasProcessDiscovery = signals.some(s => s.type === 'process_discovery');
          const hasDemo = signals.some(s => s.type === 'demo');

          // Legal/Security = Stage 4, Evaluation = Stage 3, Reverse/Tech/Process Discovery = Stage 2, Demo = Stage 1
          if (hasLegal || hasSecurity) inferredStage = 4;
          else if (hasEvaluation) inferredStage = 3;
          else if (hasReverseDemo || hasTechnicalDiscovery || hasProcessDiscovery) inferredStage = 2;
          else if (hasDemo) inferredStage = 1;
        }

        // Calculate stage discrepancy
        const stageDiscrepancy = (crmStage !== null && inferredStage !== null)
          ? crmStage - inferredStage
          : 0;

        // Calculate days in current stage (using last meeting or created date as proxy)
        const stageDate = opp.last_meeting_at || opp.created_at;
        const daysInCurrentStage = stageDate
          ? differenceInDays(new Date(), new Date(stageDate))
          : null;

        // Determine missing exit criteria based on current stage
        const missingExitCriteria: string[] = [];
        const currentStage = crmStage ?? inferredStage ?? 0;
        const stageConfig = CEP_STAGES[currentStage];
        
        if (stageConfig) {
          // Check if we have signals that indicate exit criteria might be met
          const stageSignalTypes = new Set(signals.map(s => s.type));
          
          // Stage 0-1: Need demo signals
          if (currentStage <= 1 && !stageSignalTypes.has('demo')) {
            missingExitCriteria.push('Pendo Overview / Demo not detected');
          }
          
          // Stage 1-2: Need reverse demo or discovery
          if (currentStage >= 1 && currentStage <= 2 && !stageSignalTypes.has('reverse_demo') && !stageSignalTypes.has('technical_discovery')) {
            missingExitCriteria.push('Reverse demo or technical discovery not detected');
          }
          
          // Stage 2-3: Need evaluation signals
          if (currentStage >= 2 && currentStage <= 3 && !stageSignalTypes.has('evaluation')) {
            missingExitCriteria.push('Evaluation/POC discussion not detected');
          }
          
          // Stage 3-4: Need legal/security signals
          if (currentStage >= 3 && !stageSignalTypes.has('legal') && !stageSignalTypes.has('security')) {
            missingExitCriteria.push('Legal/Security engagement not detected');
          }
        }

        // Map pre-sales stage to timeline position (case-insensitive lookup)
        const preSalesTimelinePosition = opp.pre_sales_stage 
          ? preSalesPositionMap.get(opp.pre_sales_stage.toLowerCase()) ?? null
          : null;

        // Get manager emails for owner and SE
        const ownerManagerEmail = getManagerEmail(opp.owner_email);
        const seManagerEmail = getManagerEmail(opp.primary_se_email);

        // Get product mentions for this opportunity
        const productMentions = productMentionsByOpp.get(opp.id) || [];

        // Calculate first activity date (earliest of created_at, first signal, or first product mention)
        const dates: Date[] = [];
        if (opp.created_at) dates.push(new Date(opp.created_at));
        signals.forEach(s => {
          s.occurrences.forEach(o => {
            if (o.detectedAt) dates.push(new Date(o.detectedAt));
          });
        });
        productMentions.forEach(pm => {
          if (pm.transcriptDate) dates.push(new Date(pm.transcriptDate));
        });
        const firstActivityDate = dates.length > 0 
          ? new Date(Math.min(...dates.map(d => d.getTime()))).toISOString()
          : null;

        // Calculate last transcript date from product mentions (they come from transcripts)
        const transcriptDates = productMentions
          .filter(pm => pm.transcriptDate)
          .map(pm => new Date(pm.transcriptDate).getTime());
        const lastTranscriptAt = transcriptDates.length > 0
          ? new Date(Math.max(...transcriptDates)).toISOString()
          : opp.last_meeting_at || null;

        // Determine closed status from sales_stage
        const salesStageLower = (opp.sales_stage || '').toLowerCase();
        const isClosedWon = salesStageLower.includes('closed_won') || salesStageLower.includes('closed won') || salesStageLower === 'stage_6_closed_won';
        const isClosedLost = salesStageLower.includes('closed_lost') || salesStageLower.includes('closed lost') || salesStageLower === 'stage_7_closed_lost';
        const isArchived = opp.is_archived === true || isClosedWon || isClosedLost;

        return {
          id: opp.id,
          name: opp.name,
          salesforceOpportunityId: opp.salesforce_opportunity_id || null,
          accountId: opp.accounts?.id || opp.account_id,
          accountName: opp.accounts?.name || 'Unknown',
          crmStage,
          salesStage: opp.sales_stage,
          preSalesStage: opp.pre_sales_stage,
          preSalesTimelinePosition,
          inferredStage,
          stageDiscrepancy,
          signals,
          signalsByStage,
          lastActivityAt: opp.last_meeting_at,
          daysInCurrentStage,
          missingExitCriteria,
          ownerEmail: opp.owner_email,
          primarySeEmail: opp.primary_se_email,
          ownerManagerEmail,
          seManagerEmail,
          // New date-based timeline fields
          createdAt: opp.created_at || null,
          closeDate: opp.close_date || null,
          firstActivityDate,
          productMentions,
          updatedAt: opp.updated_at || null,
          lastTranscriptAt,
          isArchived,
          isClosedWon,
          isClosedLost,
          primaryEvalQuote: opp.primary_eval_quote || null,
          evalStartDate: opp.eval_start_date || null,
          evalEndDate: opp.eval_end_date || null,
          evalType: opp.eval_type || null,
        };
      });

      // Apply filters
      let filtered = cepOpportunities;

      // Team filter - show opportunities where owner OR SE is in the team
      if (filters?.teamEmails && filters.teamEmails.length > 0) {
        const teamEmailSet = new Set(filters.teamEmails.map(e => e.toLowerCase()));
        filtered = filtered.filter(opp => {
          const ownerMatch = opp.ownerEmail && teamEmailSet.has(opp.ownerEmail.toLowerCase());
          const seMatch = opp.primarySeEmail && teamEmailSet.has(opp.primarySeEmail.toLowerCase());
          return ownerMatch || seMatch;
        });
      }

      if (filters?.stageFilter && filters.stageFilter.length > 0) {
        filtered = filtered.filter(opp => 
          filters.stageFilter!.includes(opp.crmStage ?? opp.inferredStage ?? 0)
        );
      }

      if (filters?.ownerFilter && filters.ownerFilter.length > 0) {
        filtered = filtered.filter(opp =>
          opp.ownerEmail && filters.ownerFilter!.includes(opp.ownerEmail)
        );
      }

      if (filters?.hasGaps) {
        filtered = filtered.filter(opp =>
          opp.missingExitCriteria.length > 0 || Math.abs(opp.stageDiscrepancy) >= 2
        );
      }

      if (filters?.stuckThresholdDays) {
        filtered = filtered.filter(opp =>
          opp.daysInCurrentStage !== null && opp.daysInCurrentStage >= filters.stuckThresholdDays!
        );
      }

      // Sort by gap severity (discrepancy + missing criteria), then by last activity
      filtered.sort((a, b) => {
        const aScore = Math.abs(a.stageDiscrepancy) + a.missingExitCriteria.length;
        const bScore = Math.abs(b.stageDiscrepancy) + b.missingExitCriteria.length;
        if (aScore !== bScore) return bScore - aScore;
        
        const aDate = a.lastActivityAt ? new Date(a.lastActivityAt).getTime() : 0;
        const bDate = b.lastActivityAt ? new Date(b.lastActivityAt).getTime() : 0;
        return bDate - aDate;
      });

      return filtered;
    },
  });
}

// Get unique owners for filter dropdown
export function useCEPOwners() {
  return useQuery({
    queryKey: ['cep-owners'],
    queryFn: async () => {
      const response = await gateway.from('opportunities')
        .select('owner_email')
        .not('owner_email', 'is', null)
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      
      const owners = new Set<string>();
      (response.data || []).forEach((row: any) => {
        if (row.owner_email) owners.add(row.owner_email);
      });

      return Array.from(owners).sort();
    },
  });
}

// Get unique primary SEs for filter dropdown
export function useCEPPrimarySEs() {
  return useQuery({
    queryKey: ['cep-primary-ses'],
    queryFn: async () => {
      const response = await gateway.from('opportunities')
        .select('primary_se_email')
        .not('primary_se_email', 'is', null)
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      
      const ses = new Set<string>();
      (response.data || []).forEach((row: any) => {
        if (row.primary_se_email) ses.add(row.primary_se_email);
      });

      return Array.from(ses).sort();
    },
  });
}

// Color palette for dynamic signal types
const SIGNAL_COLORS = [
  '#8B5CF6', // Purple
  '#F97316', // Orange
  '#0EA5E9', // Sky blue
  '#10B981', // Emerald
  '#EF4444', // Red
  '#F59E0B', // Amber
  '#EC4899', // Pink
  '#6366F1', // Indigo
  '#14B8A6', // Teal
  '#84CC16', // Lime
];

export interface CEPDynamicSignalType {
  id: string;
  name: string;
  key: string;
  color: string;
}

// Get signal types dynamically from detection rules
export function useCEPSignalTypes() {
  const ACTIVITY_SIGNAL_TREE_ID = 'f5e4d3c2-b1a0-9876-5432-fedcba098765';
  
  return useQuery({
    queryKey: ['cep-signal-types'],
    queryFn: async () => {
      const response = await gateway
        .from('detection_rules')
        .select('id, name, display_name, signal_field_name')
        .eq('tree_id', ACTIVITY_SIGNAL_TREE_ID)
        .eq('is_active', true)
        .order('sort_order')
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      const rules = response.data || [];

      // Build signal types with colors
      const signalTypes: CEPDynamicSignalType[] = rules.map((rule: any, index: number) => {
        // Use display_name if set, otherwise derive from name
        const name = rule.display_name || rule.name.replace(' Signals', '').replace(' Signal', '');
        const key = rule.signal_field_name || name.toLowerCase().replace(/\s+/g, '_');
        return {
          id: rule.id,
          name,
          key,
          color: SIGNAL_COLORS[index % SIGNAL_COLORS.length],
        };
      });

      return signalTypes;
    },
  });
}

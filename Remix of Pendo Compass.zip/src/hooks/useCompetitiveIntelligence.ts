import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface CompetitorScore {
  competitorId: string;
  competitorName: string;
  featureId: string;
  featureName: string;
  categoryName: string;
  score: number;
  rationale: string | null;
}

export interface FeatureComparison {
  featureName: string;
  categoryName: string;
  pendoScore: number;
  competitorName: string;
  competitorScore: number;
  pendoAdvantage: number;
  maturityLevel1: string | null;
  maturityLevel3: string | null;
  maturityLevel5: string | null;
  rationale: string | null;
}

export interface CompetitorOverview {
  id: string;
  name: string;
  totalScore: number;
  isPrimary: boolean;
}

export interface CategoryScore {
  categoryName: string;
  pendoAverage: number;
  competitorAverages: Map<string, number>;
}

// Get all competitors
export function useCompetitors() {
  return useQuery({
    queryKey: ['competitors'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('competitors')
        .select('*')
        .order('total_score', { ascending: false });
      if (error) throw error;
      return data.map((c) => ({
        id: c.id,
        name: c.name,
        totalScore: c.total_score || 0,
        isPrimary: c.is_primary_competitor || false,
      })) as CompetitorOverview[];
    },
  });
}

// Get competitor by name (useful when matching from transcript mentions)
export function useCompetitorByName(name: string | null) {
  return useQuery({
    queryKey: ['competitor', name],
    queryFn: async () => {
      if (!name) return null;
      const { data, error } = await supabase
        .from('competitors')
        .select('*')
        .ilike('name', `%${name}%`)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!name,
  });
}

// Get all scores for a specific competitor
export function useCompetitorScores(competitorId: string | null) {
  return useQuery({
    queryKey: ['competitor-scores', competitorId],
    queryFn: async () => {
      if (!competitorId) return [];
      const { data, error } = await supabase
        .from('competitor_scores')
        .select(`
          *,
          competitors(name),
          competitive_features(
            name,
            maturity_level_1,
            maturity_level_3,
            maturity_level_5,
            competitive_categories(name)
          )
        `)
        .eq('competitor_id', competitorId);
      if (error) throw error;
      
      return data.map((score: any) => ({
        competitorId: score.competitor_id,
        competitorName: score.competitors?.name || 'Unknown',
        featureId: score.feature_id,
        featureName: score.competitive_features?.name || 'Unknown',
        categoryName: score.competitive_features?.competitive_categories?.name || 'Unknown',
        score: score.score,
        rationale: score.rationale,
        maturityLevel1: score.competitive_features?.maturity_level_1,
        maturityLevel3: score.competitive_features?.maturity_level_3,
        maturityLevel5: score.competitive_features?.maturity_level_5,
      })) as CompetitorScore[];
    },
    enabled: !!competitorId,
  });
}

// Get Pendo vs specific competitor comparisons
export function usePendoVsCompetitor(competitorName: string | null) {
  return useQuery({
    queryKey: ['pendo-vs-competitor', competitorName],
    queryFn: async () => {
      if (!competitorName) return [];
      
      const { data: pendoData, error: pendoError } = await supabase
        .from('competitors')
        .select('id')
        .eq('name', 'Pendo')
        .maybeSingle();
      if (pendoError) throw pendoError;
      if (!pendoData) return [];
      
      const { data: compData, error: compError } = await supabase
        .from('competitors')
        .select('id, name')
        .ilike('name', `%${competitorName}%`)
        .maybeSingle();
      if (compError) throw compError;
      if (!compData) return [];
      
      const { data: pendoScores, error: psError } = await supabase
        .from('competitor_scores')
        .select(`
          score,
          rationale,
          feature_id,
          competitive_features(
            name,
            maturity_level_1,
            maturity_level_3,
            maturity_level_5,
            competitive_categories(name)
          )
        `)
        .eq('competitor_id', pendoData.id);
      if (psError) throw psError;
      
      const { data: compScores, error: csError } = await supabase
        .from('competitor_scores')
        .select('score, feature_id, rationale')
        .eq('competitor_id', compData.id);
      if (csError) throw csError;
      
      const compScoreMap = new Map(compScores.map((s: any) => [s.feature_id, { score: s.score, rationale: s.rationale }]));
      
      const comparisons: FeatureComparison[] = pendoScores.map((ps: any) => {
        const compScore = compScoreMap.get(ps.feature_id);
        return {
          featureName: ps.competitive_features?.name || 'Unknown',
          categoryName: ps.competitive_features?.competitive_categories?.name || 'Unknown',
          pendoScore: ps.score,
          competitorName: compData.name,
          competitorScore: compScore?.score || 0,
          pendoAdvantage: ps.score - (compScore?.score || 0),
          maturityLevel1: ps.competitive_features?.maturity_level_1,
          maturityLevel3: ps.competitive_features?.maturity_level_3,
          maturityLevel5: ps.competitive_features?.maturity_level_5,
          rationale: compScore?.rationale || null,
        };
      });
      
      return comparisons.sort((a, b) => b.pendoAdvantage - a.pendoAdvantage);
    },
    enabled: !!competitorName,
  });
}

// Get all feature comparisons for multiple competitors using competitive_scorecard
export function useCompetitiveAnalysis(competitorNames: string[]) {
  return useQuery({
    queryKey: ['competitive-analysis', competitorNames],
    queryFn: async () => {
      if (competitorNames.length === 0) return { strengths: [], threats: [], opportunities: [] };
      
      // Fetch Pendo scores from competitive_scorecard
      const { data: pendoScores } = await supabase
        .from('competitive_scorecard')
        .select('subcategory, category, score')
        .eq('vendor_name', 'Pendo');
      
      if (!pendoScores || pendoScores.length === 0) return { strengths: [], threats: [], opportunities: [] };
      
      // Build Pendo score map by subcategory
      const pendoScoreMap = new Map(pendoScores.map((s: any) => [s.subcategory, { score: s.score, category: s.category }]));
      
      // Fetch rubric data for maturity descriptions
      const { data: rubricData } = await supabase
        .from('competitive_features')
        .select('name, maturity_level_1, maturity_level_3, maturity_level_5, competitive_categories(name)')
        .limit(200);
      
      const rubricMap = new Map((rubricData || []).map((r: any) => [r.name, {
        maturity_level_1: r.maturity_level_1,
        maturity_level_3: r.maturity_level_3,
        maturity_level_5: r.maturity_level_5,
      }]));
      
      // Fetch competitor scores - use OR filter for all competitor names
      const orFilter = competitorNames.map(n => `vendor_name.ilike.%${n}%`).join(',');
      const { data: compScores } = await supabase
        .from('competitive_scorecard')
        .select('vendor_name, subcategory, category, score')
        .or(orFilter);
      
      if (!compScores || compScores.length === 0) return { strengths: [], threats: [], opportunities: [] };
      
      // Group competitor scores by subcategory
      const compScoresBySubcategory = new Map<string, Array<{ vendorName: string; score: number }>>();
      compScores.forEach((s: any) => {
        const arr = compScoresBySubcategory.get(s.subcategory) || [];
        arr.push({ vendorName: s.vendor_name, score: s.score });
        compScoresBySubcategory.set(s.subcategory, arr);
      });
      
      const strengths: FeatureComparison[] = [];
      const threats: FeatureComparison[] = [];
      const opportunities: FeatureComparison[] = [];
      
      pendoScoreMap.forEach((pendoInfo, subcategory) => {
        const compEntries = compScoresBySubcategory.get(subcategory) || [];
        const rubric = rubricMap.get(subcategory);
        
        compEntries.forEach(cs => {
          const advantage = pendoInfo.score - cs.score;
          const comparison: FeatureComparison = {
            featureName: subcategory,
            categoryName: pendoInfo.category,
            pendoScore: pendoInfo.score,
            competitorName: cs.vendorName,
            competitorScore: cs.score,
            pendoAdvantage: advantage,
            maturityLevel1: rubric?.maturity_level_1 || null,
            maturityLevel3: rubric?.maturity_level_3 || null,
            maturityLevel5: rubric?.maturity_level_5 || null,
            rationale: null,
          };
          
          if (advantage >= 2) {
            strengths.push(comparison);
          } else if (advantage <= -2) {
            threats.push(comparison);
          } else if (pendoInfo.score < 5) {
            opportunities.push(comparison);
          }
        });
      });
      
      strengths.sort((a, b) => b.pendoAdvantage - a.pendoAdvantage);
      threats.sort((a, b) => a.pendoAdvantage - b.pendoAdvantage);
      opportunities.sort((a, b) => (5 - a.pendoScore) - (5 - b.pendoScore));
      
      return { strengths, threats, opportunities };
    },
    enabled: competitorNames.length > 0,
  });
}

export function getMaturityDescription(score: number, feature: Pick<FeatureComparison, 'maturityLevel1' | 'maturityLevel3' | 'maturityLevel5'>): string {
  if (score <= 1) return feature.maturityLevel1 || 'Fragmented & Reactive';
  if (score <= 2) return 'Consolidating & Proving';
  if (score <= 3) return feature.maturityLevel3 || 'Scaling & Systematic';
  if (score <= 4) return 'Integrated & Governed';
  return feature.maturityLevel5 || 'Predictive & Strategic';
}

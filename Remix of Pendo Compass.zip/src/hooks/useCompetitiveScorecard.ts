import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway } from '@/lib/apiGateway';

export interface CompetitiveScore {
  id: string;
  vendor_name: string;
  category: string;
  subcategory: string;
  score: number;
  rubric_id: string | null;
  last_validated_at: string | null;
  validated_by: string | null;
}

export interface CompetitiveRubric {
  id: string;
  category: string;
  subcategory: string;
  level_1_description: string | null;
  level_2_description: string | null;
  level_3_description: string | null;
  level_4_description: string | null;
  level_5_description: string | null;
}

export interface CompetitiveSource {
  id: string;
  reference_number: string | null;
  source_name: string;
  source_description: string | null;
  subcategory_alignment: string | null;
  source_url: string | null;
  status: string | null;
  key_takeaways: string | null;
}

export interface VendorComparison {
  subcategory: string;
  category: string;
  pendoScore: number;
  competitorScore: number;
  difference: number;
  rubric: CompetitiveRubric | null;
}

// Fetch all scores for a specific vendor
export function useVendorScores(vendorName: string) {
  return useQuery({
    queryKey: ['competitive-scores', vendorName],
    queryFn: async () => {
      const result = await gateway.from('competitive_scorecard')
        .select('*')
        .eq('vendor_name', vendorName)
        .order('category')
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return (result.data || []) as CompetitiveScore[];
    },
    enabled: !!vendorName,
  });
}

// Fetch all unique vendors from technology_repository (competitors + top-level Pendo baseline)
export function useCompetitorVendors() {
  return useQuery({
    queryKey: ['competitive-vendors'],
    queryFn: async () => {
      // Competitors (all) + Pendo products (only parent-level, not child modules)
      const result = await gateway.from('technology_repository')
        .select('name, is_competitor, is_pendo_product, parent_id')
        .or('is_competitor.eq.true,is_pendo_product.eq.true')
        .order('name')
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      // Include all competitors, but for Pendo products only include the parent (no parent_id)
      return (result.data as any[])
        .filter(d => d.is_competitor || (d.is_pendo_product && !d.parent_id))
        .map(d => d.name);
    },
  });
}

// Fetch rubric definitions
export function useCompetitiveRubric() {
  return useQuery({
    queryKey: ['competitive-rubric'],
    queryFn: async () => {
      const result = await gateway.from('competitive_rubric')
        .select('*')
        .order('category')
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return (result.data || []) as CompetitiveRubric[];
    },
  });
}

// Fetch competitive sources
export function useCompetitiveSources() {
  return useQuery({
    queryKey: ['competitive-sources'],
    queryFn: async () => {
      const result = await gateway.from('competitive_sources')
        .select('*')
        .eq('status', 'Active')
        .order('source_name')
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return (result.data || []) as CompetitiveSource[];
    },
  });
}

// Compare Pendo vs a competitor across all categories
export function useVendorComparison(competitorName: string) {
  return useQuery({
    queryKey: ['vendor-comparison', competitorName],
    queryFn: async () => {
      // Fetch Pendo scores, competitor scores, and rubrics in parallel
      const [pendoRes, compRes, rubricRes] = await Promise.all([
        gateway.from('competitive_scorecard').select('*').eq('vendor_name', 'Pendo').execute(),
        gateway.from('competitive_scorecard').select('*').eq('vendor_name', competitorName).execute(),
        gateway.from('competitive_rubric').select('*').execute(),
      ]);
      
      if (pendoRes.error) throw new Error(pendoRes.error.message);
      if (compRes.error) throw new Error(compRes.error.message);
      if (rubricRes.error) throw new Error(rubricRes.error.message);
      
      const pendoScores = (pendoRes.data || []) as CompetitiveScore[];
      const competitorScores = (compRes.data || []) as CompetitiveScore[];
      const rubrics = (rubricRes.data || []) as CompetitiveRubric[];
      
      const rubricMap = new Map(
        rubrics.map(r => [`${r.category}|${r.subcategory}`, r])
      );
      
      const pendoMap = new Map(
        pendoScores.map(s => [`${s.category}|${s.subcategory}`, s.score])
      );
      
      const comparisons: VendorComparison[] = competitorScores.map(comp => {
        const key = `${comp.category}|${comp.subcategory}`;
        const pendoScore = pendoMap.get(key) || 0;
        
        return {
          category: comp.category,
          subcategory: comp.subcategory,
          pendoScore,
          competitorScore: comp.score,
          difference: pendoScore - comp.score,
          rubric: rubricMap.get(key) as CompetitiveRubric || null,
        };
      });
      
      return comparisons.sort((a, b) => {
        if (a.category !== b.category) return a.category.localeCompare(b.category);
        return a.subcategory.localeCompare(b.subcategory);
      });
    },
    enabled: !!competitorName,
  });
}

// Get Pendo's advantages over a competitor (where Pendo scores higher)
export function usePendoAdvantages(competitorName: string) {
  const { data: comparison } = useVendorComparison(competitorName);
  
  return {
    advantages: comparison?.filter(c => c.difference > 0).sort((a, b) => b.difference - a.difference) || [],
    disadvantages: comparison?.filter(c => c.difference < 0).sort((a, b) => a.difference - b.difference) || [],
    ties: comparison?.filter(c => c.difference === 0) || [],
  };
}

// Import competitive data
export function useImportCompetitiveData() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (csvData: { rubricCsv?: string; scorecardCsv?: string; sourcesCsv?: string }) => {
      const { data, error } = await supabase.functions.invoke('import-competitive-data', {
        body: csvData,
      });
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['competitive-scores'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-vendors'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-rubric'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-sources'] });
      queryClient.invalidateQueries({ queryKey: ['vendor-comparison'] });
      queryClient.invalidateQueries({ queryKey: ['competitive-stats'] });
    },
  });
}

// Get competitive plays for an opportunity based on detected competitors
export function useCompetitivePlays(opportunityId: string, detectedCompetitors: string[]) {
  const { data: rubric } = useCompetitiveRubric();
  
  return useQuery({
    queryKey: ['competitive-plays', opportunityId, detectedCompetitors],
    queryFn: async () => {
      if (!detectedCompetitors.length) return [];
      
      const plays: Array<{
        type: 'landmine' | 'differentiation' | 'objection_handler';
        competitor: string;
        category: string;
        subcategory: string;
        title: string;
        description: string;
        pendoScore: number;
        competitorScore: number;
        talkingPoints: string[];
      }> = [];
      
      // For each detected competitor, find advantages and disadvantages
      for (const competitor of detectedCompetitors) {
        const [pendoRes, compRes] = await Promise.all([
          gateway.from('competitive_scorecard').select('*').eq('vendor_name', 'Pendo').execute(),
          gateway.from('competitive_scorecard').select('*').eq('vendor_name', competitor).execute(),
        ]);
        
        const pendoScores = (pendoRes.data || []) as CompetitiveScore[];
        const compScores = (compRes.data || []) as CompetitiveScore[];
        
        if (!pendoScores.length || !compScores.length) continue;
        
        const pendoMap = new Map(pendoScores.map(s => [`${s.category}|${s.subcategory}`, s.score]));
        
        for (const compScore of compScores) {
          const key = `${compScore.category}|${compScore.subcategory}`;
          const pendoScore = pendoMap.get(key) || 0;
          const diff = pendoScore - compScore.score;
          
          const rubricItem = rubric?.find(r => r.category === compScore.category && r.subcategory === compScore.subcategory);
          
          if (diff >= 1.5) {
            plays.push({
              type: 'differentiation',
              competitor,
              category: compScore.category,
              subcategory: compScore.subcategory,
              title: `Highlight ${compScore.subcategory} Advantage`,
              description: `Pendo scores ${pendoScore} vs ${competitor}'s ${compScore.score} in ${compScore.subcategory}`,
              pendoScore,
              competitorScore: compScore.score,
              talkingPoints: [
                `Pendo's ${compScore.subcategory} capabilities are at level ${Math.round(pendoScore)} maturity`,
                rubricItem?.[`level_${Math.round(pendoScore)}_description` as keyof CompetitiveRubric] as string || '',
              ].filter(Boolean),
            });
          } else if (diff >= 0.5) {
            plays.push({
              type: 'landmine',
              competitor,
              category: compScore.category,
              subcategory: compScore.subcategory,
              title: `Ask About ${compScore.subcategory}`,
              description: `Plant doubt about ${competitor}'s ${compScore.subcategory} capabilities (score: ${compScore.score})`,
              pendoScore,
              competitorScore: compScore.score,
              talkingPoints: [
                `"What has been your experience with ${competitor}'s ${compScore.subcategory}?"`,
                `"Have you evaluated how their ${compScore.subcategory} handles [advanced use case]?"`,
              ],
            });
          } else if (diff <= -1) {
            plays.push({
              type: 'objection_handler',
              competitor,
              category: compScore.category,
              subcategory: compScore.subcategory,
              title: `Handle ${compScore.subcategory} Objection`,
              description: `${competitor} scores higher in ${compScore.subcategory} (${compScore.score} vs ${pendoScore})`,
              pendoScore,
              competitorScore: compScore.score,
              talkingPoints: [
                `Acknowledge the gap but pivot to integrated value`,
                `Highlight roadmap if applicable`,
                `Focus on total cost of ownership and platform cohesion`,
              ],
            });
          }
        }
      }
      
      return plays;
    },
    enabled: !!opportunityId && detectedCompetitors.length > 0,
  });
}
import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

export interface CompetitorForAnalysis {
  id: string;
  name: string;
  isPrimary: boolean;
}

export function useCompetitorsList() {
  return useQuery({
    queryKey: ['competitors-for-analysis'],
    queryFn: async (): Promise<CompetitorForAnalysis[]> => {
      const { data, error } = await gateway.from('competitors')
        .select('id, name, is_primary_competitor')
        .order('total_score', { ascending: false })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      
      return (data || []).map((c: any) => ({
        id: c.id,
        name: c.name,
        isPrimary: c.is_primary_competitor ?? false,
      }));
    },
    staleTime: 1000 * 60 * 10,
  });
}

export async function fetchCompetitorsForAnalysis(): Promise<CompetitorForAnalysis[]> {
  const { data, error } = await gateway.from('competitors')
    .select('id, name, is_primary_competitor')
    .order('total_score', { ascending: false })
    .execute();

  if (error) {
    console.error('Failed to fetch competitors:', getErrorMessage(error));
    return [];
  }
  
  return (data || []).map((c: any) => ({
    id: c.id,
    name: c.name,
    isPrimary: c.is_primary_competitor ?? false,
  }));
}

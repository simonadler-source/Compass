import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { gateway, getErrorMessage } from "@/lib/apiGateway";
import { encryptedUpsert, encryptedBatchInsert } from "@/lib/encryptedDb";

interface ContactMeetingSnapshot {
  id: string;
  contact_id: string;
  transcript_id: string;
  opportunity_id: string | null;
  meeting_date: string;
  meeting_type: string;
  sentiment: number | null;
  influence_level: number | null;
  engagement_score: number | null;
  champion_score: number | null;
  key_quotes: string[] | null;
  topics_discussed: string[] | null;
  concerns_raised: string[] | null;
  action_items: string[] | null;
  notes: string | null;
  meeting_title?: string | null;
  created_at: string;
  updated_at: string;
}

interface AggregatedContactMetrics {
  contactId: string;
  contactName: string;
  contactEmail: string | null;
  contactRole: string | null;
  currentSentiment: number | null;
  currentInfluence: number | null;
  currentEngagement: number | null;
  currentChampionScore: number | null;
  weightedSentiment: number | null;
  weightedInfluence: number | null;
  weightedChampionScore: number | null;
  sentimentTrend: 'improving' | 'stable' | 'declining' | 'unknown';
  engagementTrend: 'improving' | 'stable' | 'declining' | 'unknown';
  totalMeetings: number;
  lastMeetingDate: string | null;
  meetingTypes: Record<string, number>;
  allConcerns: string[];
  allActionItems: string[];
  keyQuotes: string[];
}

const MEETING_TYPE_WEIGHTS: Record<string, number> = {
  discovery: 1.0, demo: 1.0, technical: 1.0, workshop: 1.0,
  executive: 1.2, commercial: 0.6, negotiation: 0.5, contract: 0.5, default: 0.8,
};

function getRecencyWeight(meetingDate: Date, mostRecentDate: Date): number {
  const daysDiff = (mostRecentDate.getTime() - meetingDate.getTime()) / (1000 * 60 * 60 * 24);
  return Math.exp(-daysDiff / 30);
}

function calculateTrend(values: { value: number; date: Date }[]): 'improving' | 'stable' | 'declining' | 'unknown' {
  if (values.length < 2) return 'unknown';
  const sorted = [...values].sort((a, b) => a.date.getTime() - b.date.getTime());
  const n = sorted.length;
  const sumX = sorted.reduce((acc, _, i) => acc + i, 0);
  const sumY = sorted.reduce((acc, v) => acc + v.value, 0);
  const sumXY = sorted.reduce((acc, v, i) => acc + i * v.value, 0);
  const sumX2 = sorted.reduce((acc, _, i) => acc + i * i, 0);
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  if (Math.abs(slope) < 0.1) return 'stable';
  return slope > 0 ? 'improving' : 'declining';
}

export function aggregateContactMetrics(
  snapshots: ContactMeetingSnapshot[],
  contact: { id: string; name: string; email: string | null; role: string | null }
): AggregatedContactMetrics {
  if (snapshots.length === 0) {
    return {
      contactId: contact.id, contactName: contact.name, contactEmail: contact.email,
      contactRole: contact.role, currentSentiment: null, currentInfluence: null,
      currentEngagement: null, currentChampionScore: null, weightedSentiment: null,
      weightedInfluence: null, weightedChampionScore: null, sentimentTrend: 'unknown',
      engagementTrend: 'unknown', totalMeetings: 0, lastMeetingDate: null,
      meetingTypes: {}, allConcerns: [], allActionItems: [], keyQuotes: [],
    };
  }

  const sorted = [...snapshots].sort((a, b) => new Date(b.meeting_date).getTime() - new Date(a.meeting_date).getTime());
  const mostRecent = sorted[0];
  const mostRecentDate = new Date(mostRecent.meeting_date);
  let totalWeight = 0, weightedSentimentSum = 0, weightedInfluenceSum = 0, weightedChampionSum = 0;
  let sentimentCount = 0, influenceCount = 0, championCount = 0;
  const sentimentValues: { value: number; date: Date }[] = [];
  const engagementValues: { value: number; date: Date }[] = [];
  const meetingTypes: Record<string, number> = {};
  const allConcerns: string[] = [], allActionItems: string[] = [], keyQuotes: string[] = [];

  for (const snapshot of sorted) {
    const meetingDate = new Date(snapshot.meeting_date);
    const recencyWeight = getRecencyWeight(meetingDate, mostRecentDate);
    const typeWeight = MEETING_TYPE_WEIGHTS[snapshot.meeting_type] ?? MEETING_TYPE_WEIGHTS.default;
    const combinedWeight = recencyWeight * typeWeight;
    if (snapshot.sentiment !== null) { weightedSentimentSum += snapshot.sentiment * combinedWeight; sentimentCount++; totalWeight += combinedWeight; sentimentValues.push({ value: snapshot.sentiment, date: meetingDate }); }
    if (snapshot.influence_level !== null) { weightedInfluenceSum += snapshot.influence_level * combinedWeight; influenceCount++; }
    if (snapshot.champion_score !== null) { weightedChampionSum += snapshot.champion_score * combinedWeight; championCount++; }
    if (snapshot.engagement_score !== null) { engagementValues.push({ value: snapshot.engagement_score, date: meetingDate }); }
    meetingTypes[snapshot.meeting_type] = (meetingTypes[snapshot.meeting_type] || 0) + 1;
    if (snapshot.concerns_raised) allConcerns.push(...snapshot.concerns_raised);
    if (snapshot.action_items) allActionItems.push(...snapshot.action_items);
    if (snapshot.key_quotes) keyQuotes.push(...snapshot.key_quotes.slice(0, 2));
  }

  return {
    contactId: contact.id, contactName: contact.name, contactEmail: contact.email, contactRole: contact.role,
    currentSentiment: mostRecent.sentiment, currentInfluence: mostRecent.influence_level,
    currentEngagement: mostRecent.engagement_score, currentChampionScore: mostRecent.champion_score,
    weightedSentiment: sentimentCount > 0 ? weightedSentimentSum / totalWeight : null,
    weightedInfluence: influenceCount > 0 ? weightedInfluenceSum / totalWeight : null,
    weightedChampionScore: championCount > 0 ? weightedChampionSum / totalWeight : null,
    sentimentTrend: calculateTrend(sentimentValues), engagementTrend: calculateTrend(engagementValues),
    totalMeetings: snapshots.length, lastMeetingDate: mostRecent.meeting_date, meetingTypes,
    allConcerns: [...new Set(allConcerns)], allActionItems: [...new Set(allActionItems)], keyQuotes: keyQuotes.slice(0, 5),
  };
}

export function useContactSnapshots(contactId: string | undefined) {
  return useQuery({
    queryKey: ['contact-snapshots', contactId],
    queryFn: async () => {
      if (!contactId) return [];
      const { data, error } = await gateway.from('contact_meeting_snapshots').select('*, transcript_reviews:transcript_id(meeting_title)').eq('contact_id', contactId).order('meeting_date', { ascending: false }).execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []).map((d: any) => ({ ...d, meeting_title: d.transcript_reviews?.meeting_title ?? null, transcript_reviews: undefined })) as ContactMeetingSnapshot[];
    },
    enabled: !!contactId,
  });
}

export function useAccountContactSnapshots(accountId: string | undefined) {
  return useQuery({
    queryKey: ['account-contact-snapshots', accountId],
    queryFn: async () => {
      if (!accountId) return [];
      // Get all contacts for this account first
      const { data: contacts, error: contactsError } = await gateway
        .from('account_contacts')
        .select('id')
        .eq('account_id', accountId)
        .execute();
      
      if (contactsError) throw new Error(getErrorMessage(contactsError));
      if (!contacts || contacts.length === 0) return [];
      
      const contactIds = contacts.map(c => c.id);
      
      // Fetch all snapshots for these contacts
      const { data, error } = await gateway
        .from('contact_meeting_snapshots')
        .select('*, transcript_reviews:transcript_id(meeting_title)')
        .in('contact_id', contactIds)
        .order('meeting_date', { ascending: false })
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return (data || []).map((d: any) => ({ ...d, meeting_title: d.transcript_reviews?.meeting_title ?? null, transcript_reviews: undefined })) as ContactMeetingSnapshot[];
    },
    enabled: !!accountId,
  });
}

// Helper to format snapshots for sparkline display
export function getSparklineData(
  snapshots: ContactMeetingSnapshot[],
  contactId: string,
  metric: 'sentiment' | 'influence_level' | 'champion_score'
): { date: string; value: number }[] {
  return snapshots
    .filter(s => s.contact_id === contactId && s[metric] !== null)
    .sort((a, b) => new Date(a.meeting_date).getTime() - new Date(b.meeting_date).getTime())
    .map(s => ({
      date: s.meeting_date,
      value: s[metric] as number,
    }));
}

export function useOpportunityContactSnapshots(opportunityId: string | undefined) {
  return useQuery({
    queryKey: ['opportunity-contact-snapshots', opportunityId],
    queryFn: async () => {
      if (!opportunityId) return [];
      const { data, error } = await gateway.from('contact_meeting_snapshots').select('*, transcript_reviews:transcript_id(meeting_title)').eq('opportunity_id', opportunityId).order('meeting_date', { ascending: false }).execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []).map((d: any) => ({ ...d, meeting_title: d.transcript_reviews?.meeting_title ?? null, transcript_reviews: undefined })) as ContactMeetingSnapshot[];
    },
    enabled: !!opportunityId,
  });
}

export function useAggregatedOpportunityContacts(
  opportunityId: string | undefined,
  contacts: Array<{ id: string; name: string; email: string | null; role: string | null }>
) {
  const { data: snapshots } = useOpportunityContactSnapshots(opportunityId);
  if (!snapshots || contacts.length === 0) return contacts.map(c => aggregateContactMetrics([], c));
  const snapshotsByContact = new Map<string, ContactMeetingSnapshot[]>();
  for (const snapshot of snapshots) {
    const existing = snapshotsByContact.get(snapshot.contact_id) || [];
    existing.push(snapshot);
    snapshotsByContact.set(snapshot.contact_id, existing);
  }
  return contacts.map(contact => aggregateContactMetrics(snapshotsByContact.get(contact.id) || [], contact));
}

export function useCreateContactSnapshot() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (snapshot: Omit<ContactMeetingSnapshot, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await encryptedUpsert('contact_meeting_snapshots', snapshot);
      if (error) throw error;
      return data;
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['contact-snapshots', data?.contact_id] });
      if (data?.opportunity_id) queryClient.invalidateQueries({ queryKey: ['opportunity-contact-snapshots', data.opportunity_id] });
    },
  });
}

export function useBulkCreateContactSnapshots() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (snapshots: Omit<ContactMeetingSnapshot, 'id' | 'created_at' | 'updated_at'>[]) => {
      if (snapshots.length === 0) return [];
      const result = await encryptedBatchInsert('contact_meeting_snapshots', snapshots);
      if (result.failed > 0) console.warn(`Failed to insert ${result.failed} contact snapshots`, result.errors);
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contact-snapshots'] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-contact-snapshots'] });
    },
  });
}

import { useQuery } from "@tanstack/react-query";
import { gateway } from "@/lib/apiGateway";

export function useCreditStatus() {
  const { data: hasCreditIssue = false, refetch } = useQuery({
    queryKey: ["credit-status"],
    queryFn: async () => {
      // Check for any unread credit-related notifications
      // Fetch unread credit_exhausted notifications and filter client-side for expiry
      const result = await gateway.from("system_notifications")
        .select("id, expires_at")
        .eq("type", "credit_exhausted")
        .eq("is_read", false)
        .limit(10)
        .execute();

      if (result.error) throw new Error(result.error.message);
      
      // Filter for non-expired notifications (null expires_at or future date)
      const now = new Date().toISOString();
      const validNotifications = (result.data || []).filter((n: any) => 
        n.expires_at === null || n.expires_at > now
      );
      
      return validNotifications.length > 0;
    },
    refetchInterval: 30000,
  });

  return { hasCreditIssue, refetch };
}

export async function createCreditExhaustedNotification() {
  // Check if there's already an unread notification to avoid duplicates
  const existingResult = await gateway.from("system_notifications")
    .select("id")
    .eq("type", "credit_exhausted")
    .eq("is_read", false)
    .limit(1)
    .execute();

  if (existingResult.data && existingResult.data.length > 0) {
    return; // Already have an active notification
  }

  await gateway.from("system_notifications")
    .insert({
      type: "credit_exhausted",
      title: "AI Credits Exhausted",
      message: "The platform has run out of AI credits. Some features like transcript analysis will not work until credits are added.",
      expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // Expires in 7 days
    })
    .execute();
}

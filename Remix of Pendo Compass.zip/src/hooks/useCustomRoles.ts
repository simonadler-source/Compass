import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface CustomRole {
  id: string;
  name: string;
  display_name: string;
  description: string | null;
  is_system: boolean;
  created_at: string;
  updated_at: string;
}

export function useCustomRoles() {
  const queryClient = useQueryClient();

  const { data: roles, isLoading, error } = useQuery({
    queryKey: ['custom-roles'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('custom_roles')
        .select('*')
        .order('is_system', { ascending: false })
        .order('display_name')
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data as CustomRole[];
    },
  });

  const createRole = useMutation({
    mutationFn: async ({ name, display_name, description }: { 
      name: string; 
      display_name: string; 
      description?: string 
    }) => {
      // Normalize name to lowercase, no spaces
      const normalizedName = name.toLowerCase().replace(/\s+/g, '_');
      
      const { data, error } = await gateway
        .from('custom_roles')
        .insert({ 
          name: normalizedName, 
          display_name, 
          description,
          is_system: false 
        })
        .select('*')
        .single()
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custom-roles'] });
      toast.success('Role created successfully');
    },
    onError: (error: any) => {
      if (error.message?.includes('duplicate')) {
        toast.error('A role with this name already exists');
      } else {
        toast.error('Failed to create role: ' + error.message);
      }
    },
  });

  const updateRole = useMutation({
    mutationFn: async ({ id, display_name, description }: { 
      id: string; 
      display_name: string; 
      description?: string 
    }) => {
      const { data, error } = await gateway
        .from('custom_roles')
        .update({ display_name, description })
        .eq('id', id)
        .select('*')
        .single()
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custom-roles'] });
      toast.success('Role updated successfully');
    },
    onError: (error: any) => {
      toast.error('Failed to update role: ' + error.message);
    },
  });

  const deleteRole = useMutation({
    mutationFn: async (id: string) => {
      // First check if it's a system role
      const role = roles?.find(r => r.id === id);
      if (role?.is_system) {
        throw new Error('Cannot delete system roles');
      }
      
      const { error } = await gateway
        .from('custom_roles')
        .delete()
        .eq('id', id)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custom-roles'] });
      toast.success('Role deleted successfully');
    },
    onError: (error: any) => {
      toast.error('Failed to delete role: ' + error.message);
    },
  });

  const duplicateRole = useMutation({
    mutationFn: async (id: string) => {
      const role = roles?.find(r => r.id === id);
      if (!role) throw new Error('Role not found');
      
      // Generate a unique name for the duplicate
      let baseName = role.name + '_copy';
      let uniqueName = baseName;
      let counter = 1;
      
      // Check if name exists and increment counter
      while (roles?.some(r => r.name === uniqueName)) {
        uniqueName = `${baseName}_${counter}`;
        counter++;
      }
      
      // Create the new role
      const { data: newRole, error } = await gateway
        .from('custom_roles')
        .insert({
          name: uniqueName,
          display_name: `${role.display_name} (Copy)`,
          description: role.description,
          is_system: false
        })
        .select('*')
        .single()
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      
      // Copy page access permissions from original role
      const { data: accessEntries } = await gateway
        .from('page_role_access')
        .select('page_path, page_name')
        .eq('role', role.name)
        .execute();
      
      if (accessEntries && accessEntries.length > 0) {
        const newAccessEntries = accessEntries.map(entry => ({
          page_path: entry.page_path,
          page_name: entry.page_name,
          role: uniqueName
        }));
        
        await gateway
          .from('page_role_access')
          .insert(newAccessEntries)
          .execute();
      }
      
      return newRole;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custom-roles'] });
      queryClient.invalidateQueries({ queryKey: ['page-access'] });
      toast.success('Role duplicated with all access permissions');
    },
    onError: (error: any) => {
      toast.error('Failed to duplicate role: ' + error.message);
    },
  });

  // Get role names for use in page access (backwards compatible)
  const roleNames = roles?.map(r => r.name) || [];

  return {
    roles: roles || [],
    roleNames,
    isLoading,
    error,
    createRole,
    updateRole,
    deleteRole,
    duplicateRole,
  };
}

import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import type { DateRange } from './useProductMentions';

/** 100 buckets → 1 % increments for a continuous-stripe effect */
const BUCKET_COUNT = 100;

/* ── Shared types ────────────────────────────────────── */

export interface BleedDataPoint {
  bucket: number;
  pctStart: number;
  pctEnd: number;
  mentionCount: number;
  opportunityCount: number;
}

export interface ProductBleedRow {
  productName: string;
  mentionType: 'owned' | 'complementary' | 'competitive';
  totalMentions: number;
  buckets: BleedDataPoint[];
}

export interface PersonBleedData {
  personEmail: string;
  personName: string;
  opportunityCount: number;
  totalMentions: number;
  products: ProductBleedRow[];
}

export interface DealCycleBleedResult {
  aggregateProducts: ProductBleedRow[];
  persons: PersonBleedData[];
  allProducts: string[];
  allPersons: { email: string; name: string }[];
  bucketCount: number;
}

/* ── Normalisation helpers ───────────────────────────── */

interface NormalisedMention {
  productName: string;
  mentionType: 'owned' | 'complementary' | 'competitive';
  bucket: number;
  personEmail: string;
  personName: string;
  oppId: string;
  count: number;
}

function normaliseRows(rows: any[]): NormalisedMention[] {
  const now = new Date();
  const out: NormalisedMention[] = [];

  for (const row of rows) {
    const opp = row.opportunities;
    if (!opp) continue;

    const oppCreated = new Date(opp.created_at);
    const oppEnd = opp.close_date ? new Date(opp.close_date) : now;
    const spanMs = oppEnd.getTime() - oppCreated.getTime();
    if (spanMs <= 0) continue;

    const mentionDate = new Date(row.transcript_date);
    let pct = (mentionDate.getTime() - oppCreated.getTime()) / spanMs;
    pct = Math.max(0, Math.min(1, pct));

    const bucket = Math.min(Math.floor(pct * BUCKET_COUNT), BUCKET_COUNT - 1);
    const ownerEmail = (opp.owner_email || '').toLowerCase();
    const personName = ownerEmail
      ? ownerEmail
          .split('@')[0]
          .split('.')
          .map((s: string) => s.charAt(0).toUpperCase() + s.slice(1))
          .join(' ')
      : 'Unknown';

    out.push({
      productName: row.product_name,
      mentionType: row.mention_type as NormalisedMention['mentionType'],
      bucket,
      personEmail: ownerEmail,
      personName,
      oppId: opp.id,
      count: row.mention_count || 1,
    });
  }

  return out;
}

/* ── Bucket builders ─────────────────────────────────── */

type BucketMap = Map<number, { count: number; opps: Set<string> }>;

function makeBuckets(bucketMap: BucketMap): BleedDataPoint[] {
  return Array.from({ length: BUCKET_COUNT }, (_, i) => {
    const d = bucketMap.get(i);
    return {
      bucket: i,
      pctStart: (i / BUCKET_COUNT) * 100,
      pctEnd: ((i + 1) / BUCKET_COUNT) * 100,
      mentionCount: d?.count || 0,
      opportunityCount: d?.opps.size || 0,
    };
  });
}

function aggregateByProduct(mentions: NormalisedMention[]): ProductBleedRow[] {
  const agg = new Map<string, { mentionType: NormalisedMention['mentionType']; buckets: BucketMap; total: number }>();

  for (const m of mentions) {
    if (!agg.has(m.productName)) {
      agg.set(m.productName, { mentionType: m.mentionType, buckets: new Map(), total: 0 });
    }
    const entry = agg.get(m.productName)!;
    entry.total += m.count;
    if (!entry.buckets.has(m.bucket)) entry.buckets.set(m.bucket, { count: 0, opps: new Set() });
    const b = entry.buckets.get(m.bucket)!;
    b.count += m.count;
    b.opps.add(m.oppId);
  }

  return Array.from(agg.entries())
    .map(([name, d]) => ({ productName: name, mentionType: d.mentionType, totalMentions: d.total, buckets: makeBuckets(d.buckets) }))
    .sort((a, b) => b.totalMentions - a.totalMentions);
}

function aggregateByPerson(mentions: NormalisedMention[]): PersonBleedData[] {
  const pMap = new Map<string, { name: string; opps: Set<string>; total: number; products: Map<string, { mentionType: NormalisedMention['mentionType']; buckets: BucketMap; total: number }> }>();

  for (const m of mentions) {
    const key = m.personEmail || 'unknown';
    if (!pMap.has(key)) pMap.set(key, { name: m.personName, opps: new Set(), total: 0, products: new Map() });
    const person = pMap.get(key)!;
    person.opps.add(m.oppId);
    person.total += m.count;

    if (!person.products.has(m.productName)) person.products.set(m.productName, { mentionType: m.mentionType, buckets: new Map(), total: 0 });
    const prod = person.products.get(m.productName)!;
    prod.total += m.count;
    if (!prod.buckets.has(m.bucket)) prod.buckets.set(m.bucket, { count: 0, opps: new Set() });
    const b = prod.buckets.get(m.bucket)!;
    b.count += m.count;
    b.opps.add(m.oppId);
  }

  return Array.from(pMap.entries())
    .map(([email, d]) => ({
      personEmail: email,
      personName: d.name,
      opportunityCount: d.opps.size,
      totalMentions: d.total,
      products: Array.from(d.products.entries())
        .map(([n, pd]) => ({ productName: n, mentionType: pd.mentionType, totalMentions: pd.total, buckets: makeBuckets(pd.buckets) }))
        .sort((a, b) => b.totalMentions - a.totalMentions),
    }))
    .sort((a, b) => b.totalMentions - a.totalMentions);
}

/* ── Hook ─────────────────────────────────────────────── */

export function useDealCycleBleedData(dateRange: DateRange) {
  return useQuery({
    queryKey: ['deal-cycle-bleed', dateRange.from.toISOString(), dateRange.to.toISOString()],
    queryFn: async (): Promise<DealCycleBleedResult> => {
      const response = await gateway
        .from('product_mentions')
        .select(`
          id, product_name, mention_type, transcript_date, opportunity_id, mention_count,
          opportunities!inner( id, created_at, close_date, owner_email, name )
        `)
        .not('opportunity_id', 'is', null)
        .not('transcript_date', 'is', null)
        .gte('transcript_date', dateRange.from.toISOString())
        .lte('transcript_date', dateRange.to.toISOString())
        .order('transcript_date', { ascending: true })
        .limit(1000)
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      const rows = response.data || [];

      if (rows.length === 0) {
        return { aggregateProducts: [], persons: [], allProducts: [], allPersons: [], bucketCount: BUCKET_COUNT };
      }

      const normalised = normaliseRows(rows);
      const aggregateProducts = aggregateByProduct(normalised);
      const persons = aggregateByPerson(normalised);
      const allProducts = Array.from(new Set(normalised.map(m => m.productName))).sort();
      const allPersons = persons.map(p => ({ email: p.personEmail, name: p.personName }));

      return { aggregateProducts, persons, allProducts, allPersons, bucketCount: BUCKET_COUNT };
    },
  });
}

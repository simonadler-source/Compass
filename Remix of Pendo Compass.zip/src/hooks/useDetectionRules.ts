// Detection Rules Hooks
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

export interface DetectionRuleTree {
  id: string;
  name: string;
  description: string | null;
  deployment_type_id: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  deployment_type?: {
    id: string;
    name: string;
  } | null;
}

export interface DetectionRule {
  id: string;
  tree_id: string;
  parent_rule_id: string | null;
  name: string;
  description: string | null;
  trigger_phrases: string[];
  context_qualifiers: string[];
  exclusion_phrases: string[];
  confirmation_patterns: string[];
  detection_intent: 'discussed' | 'implemented' | 'planned' | 'blocked';
  confidence_threshold: number;
  sort_order: number;
  is_active: boolean;
  speaker_context: 'any' | 'internal_only' | 'external_only';
  signal_field_name: string | null;
  signal_field_target: 'account' | 'opportunity' | null;
  created_at: string;
  updated_at: string;
  validation_task_template_id: string | null;
  children?: DetectionRule[];
  validation_task_template?: {
    id: string;
    activity: string;
    module: string;
    sub_module: string | null;
  } | null;
}

export interface DetectionRuleQuestion {
  id: string;
  rule_id: string;
  question_text: string;
  is_required: boolean;
  sort_order: number;
  created_at: string;
}

export interface DetectionRuleNBATemplate {
  id: string;
  rule_id: string;
  action_text: string;
  action_type: string;
  priority: string;
  sort_order: number;
  created_at: string;
}

export interface DetectionRuleReadinessMapping {
  id: string;
  rule_id: string;
  readiness_question_id: string;
  auto_answer: string | null;
  auto_answer_json: any | null;
  created_at: string;
  readiness_question?: {
    id: string;
    question: string;
    field_type: string;
    category?: {
      id: string;
      name: string;
    };
  };
}

export interface DetectionRuleCaptureField {
  id: string;
  rule_id: string;
  field_name: string;
  field_type: string;
  description: string | null;
  extraction_prompt: string | null;
  is_required: boolean;
  sort_order: number;
  created_at: string;
}

// ========================================
// UNIFIED ACTIONS (new system)
// ========================================

export type RuleActionType = 'update_field' | 'extract_data' | 'answer_question' | 'create_task' | 'create_nba';

export interface UpdateFieldConfig {
  field_name: string;
  value_type: 'timestamp' | 'boolean' | 'text';
}

export interface ExtractDataConfig {
  field_name: string;
  field_type: 'text' | 'number' | 'date' | 'boolean' | 'list';
  extraction_prompt?: string;
  description?: string;
  is_required?: boolean;
  track_history?: boolean; // When true, stores each value with transcript link and datetime for historical trending
}

export interface AnswerQuestionConfig {
  question_id: string;
  auto_answer: string | null;
  auto_answer_json?: any;
}

export interface CreateTaskConfig {
  template_id: string;
  auto_update_status?: 'not_started' | 'in_progress' | 'completed' | null; // If set, updates existing task status when rule matches
}

export interface CreateNBAConfig {
  action_text: string;
  priority: 'low' | 'medium' | 'high';
  nba_action_type?: string;
}

export type RuleActionConfig = 
  | UpdateFieldConfig 
  | ExtractDataConfig 
  | AnswerQuestionConfig 
  | CreateTaskConfig 
  | CreateNBAConfig;

export interface DetectionRuleAction {
  id: string;
  rule_id: string;
  action_type: RuleActionType;
  action_config: RuleActionConfig;
  target_entity: 'account' | 'opportunity' | 'contact' | null;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  // Joined data for display
  readiness_question?: {
    id: string;
    question: string;
    field_type: string;
    category?: { id: string; name: string };
  };
  validation_task_template?: {
    id: string;
    activity: string;
    module: string;
    sub_module: string | null;
  };
}

export function useDetectionRuleTrees() {
  return useQuery({
    queryKey: ['detection-rule-trees'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('detection_rule_trees')
        .select(`
          *,
          deployment_type:deployment_types(id, name)
        `)
        .eq('is_active', true)
        .order('name')
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data as DetectionRuleTree[];
    },
  });
}

export function useDetectionRules(treeId: string | null) {
  return useQuery({
    queryKey: ['detection-rules', treeId],
    queryFn: async () => {
      if (!treeId) return [];
      
      const { data, error } = await gateway
        .from('detection_rules')
        .select(`
          *,
          validation_task_template:validation_task_templates(id, activity, module, sub_module)
        `)
        .eq('tree_id', treeId)
        .order('sort_order')
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      
      // Build tree structure
      const rules = data as DetectionRule[];
      const rootRules = rules.filter(r => !r.parent_rule_id);
      
      const buildTree = (parentId: string | null): DetectionRule[] => {
        return rules
          .filter(r => r.parent_rule_id === parentId)
          .map(rule => ({
            ...rule,
            children: buildTree(rule.id),
          }));
      };
      
      return rootRules.map(rule => ({
        ...rule,
        children: buildTree(rule.id),
      }));
    },
    enabled: !!treeId,
  });
}

export function useDetectionRuleDetails(ruleId: string | null) {
  return useQuery({
    queryKey: ['detection-rule-details', ruleId],
    queryFn: async () => {
      if (!ruleId) return null;
      
      const [ruleRes, questionsRes, nbasRes, mappingsRes, captureFieldsRes, actionsRes] = await Promise.all([
        gateway.from('detection_rules').select(`
          *,
          validation_task_template:validation_task_templates(id, activity, module, sub_module)
        `).eq('id', ruleId).single().execute(),
        gateway.from('detection_rule_questions').select('*').eq('rule_id', ruleId).order('sort_order').execute(),
        gateway.from('detection_rule_nba_templates').select('*').eq('rule_id', ruleId).order('sort_order').execute(),
        gateway.from('detection_rule_readiness_mappings').select(`
          *,
          readiness_question:readiness_template_questions(
            id,
            question,
            field_type,
            category:readiness_template_categories(id, name)
          )
        `).eq('rule_id', ruleId).execute(),
        gateway.from('detection_rule_capture_fields').select('*').eq('rule_id', ruleId).order('sort_order').execute(),
        // NEW: Fetch unified actions
        gateway.from('detection_rule_actions').select('*').eq('rule_id', ruleId).eq('is_active', true).order('sort_order').execute(),
      ]);
      
      if (ruleRes.error) throw new Error(getErrorMessage(ruleRes.error));
      
      // Process actions to attach joined data where needed
      const actions = (actionsRes.data || []) as DetectionRuleAction[];
      
      return {
        rule: ruleRes.data as DetectionRule,
        questions: (questionsRes.data || []) as DetectionRuleQuestion[],
        nbaTemplates: (nbasRes.data || []) as DetectionRuleNBATemplate[],
        readinessMappings: (mappingsRes.data || []) as DetectionRuleReadinessMapping[],
        captureFields: (captureFieldsRes.data || []) as DetectionRuleCaptureField[],
        // NEW: Unified actions
        actions,
      };
    },
    enabled: !!ruleId,
  });
}

// Fetch all readiness questions for mapping
export function useReadinessQuestionsForMapping() {
  return useQuery({
    queryKey: ['readiness-questions-for-mapping'],
    queryFn: async () => {
      const { data: categories, error: catError } = await gateway
        .from('readiness_template_categories')
        .select('*, deployment_type:deployment_types(name)')
        .order('sort_order')
        .execute();
      if (catError) throw new Error(getErrorMessage(catError));
      
      const { data: questions, error: qError } = await gateway
        .from('readiness_template_questions')
        .select('*')
        .order('sort_order')
        .execute();
      if (qError) throw new Error(getErrorMessage(qError));
      
      return categories.map((cat: any) => ({
        ...cat,
        questions: questions.filter((q: any) => q.category_id === cat.id),
      }));
    },
  });
}

export function useCreateRuleTree() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: { name: string; description?: string; deployment_type_id?: string }) => {
      const { data: result, error } = await gateway
        .from('detection_rule_trees')
        .insert(data)
        .select('*')
        .single()
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-trees'] });
    },
  });
}

export function useUpdateRuleTree() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ...data }: { id: string; name?: string; description?: string; deployment_type_id?: string | null; is_active?: boolean }) => {
      const { error } = await gateway
        .from('detection_rule_trees')
        .update(data)
        .eq('id', id)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-trees'] });
    },
  });
}

export function useDeleteRuleTree() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway
        .from('detection_rule_trees')
        .delete()
        .eq('id', id)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-trees'] });
    },
  });
}

export function useCreateRule() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: {
      tree_id: string;
      parent_rule_id?: string | null;
      name: string;
      description?: string;
      trigger_phrases: string[];
      context_qualifiers?: string[];
      exclusion_phrases?: string[];
      confirmation_patterns?: string[];
      detection_intent?: 'discussed' | 'implemented' | 'planned' | 'blocked';
      confidence_threshold?: number;
      speaker_context?: 'any' | 'internal_only' | 'external_only';
      signal_field_name?: string | null;
      signal_field_target?: 'account' | 'opportunity' | null;
    }) => {
      const { data: result, error } = await gateway
        .from('detection_rules')
        .insert(data)
        .select('*')
        .single()
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return result;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rules', variables.tree_id] });
    },
  });
}

export function useUpdateRule() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, treeId, ...data }: {
      id: string;
      treeId: string;
      name?: string;
      description?: string;
      trigger_phrases?: string[];
      context_qualifiers?: string[];
      exclusion_phrases?: string[];
      confirmation_patterns?: string[];
      detection_intent?: 'discussed' | 'implemented' | 'planned' | 'blocked';
      confidence_threshold?: number;
      is_active?: boolean;
      speaker_context?: 'any' | 'internal_only' | 'external_only';
      signal_field_name?: string | null;
      signal_field_target?: 'account' | 'opportunity' | null;
      validation_task_template_id?: string | null;
    }) => {
      const { error } = await gateway
        .from('detection_rules')
        .update(data)
        .eq('id', id)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rules', variables.treeId] });
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.id] });
    },
  });
}

export function useValidationTaskTemplates() {
  return useQuery({
    queryKey: ['validation-task-templates'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('validation_task_templates')
        .select('id, activity, module, sub_module')
        .order('module')
        .order('sort_order')
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
  });
}

export function useDeleteRule() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, treeId }: { id: string; treeId: string }) => {
      const { error } = await gateway
        .from('detection_rules')
        .delete()
        .eq('id', id)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rules', variables.treeId] });
    },
  });
}

export function useUpsertRuleQuestion() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: {
      id?: string;
      rule_id: string;
      question_text: string;
      is_required?: boolean;
      sort_order?: number;
    }) => {
      if (data.id) {
        const { error } = await gateway
          .from('detection_rule_questions')
          .update({ question_text: data.question_text, is_required: data.is_required })
          .eq('id', data.id)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      } else {
        const { error } = await gateway
          .from('detection_rule_questions')
          .insert(data)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      }
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.rule_id] });
    },
  });
}

export function useDeleteRuleQuestion() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ruleId }: { id: string; ruleId: string }) => {
      const { error } = await gateway
        .from('detection_rule_questions')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.ruleId] });
    },
  });
}

export function useUpsertRuleNBA() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: {
      id?: string;
      rule_id: string;
      action_text: string;
      action_type?: string;
      priority?: string;
    }) => {
      if (data.id) {
        const { error } = await gateway
          .from('detection_rule_nba_templates')
          .update({ action_text: data.action_text, action_type: data.action_type, priority: data.priority })
          .eq('id', data.id)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      } else {
        const { error } = await gateway
          .from('detection_rule_nba_templates')
          .insert(data)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      }
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.rule_id] });
    },
  });
}

export function useDeleteRuleNBA() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ruleId }: { id: string; ruleId: string }) => {
      const { error } = await gateway
        .from('detection_rule_nba_templates')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.ruleId] });
    },
  });
}

export function useUpsertReadinessMapping() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: {
      id?: string;
      rule_id: string;
      readiness_question_id: string;
      auto_answer?: string | null;
      auto_answer_json?: any;
    }) => {
      if (data.id) {
        const { error } = await gateway
          .from('detection_rule_readiness_mappings')
          .update({
            readiness_question_id: data.readiness_question_id,
            auto_answer: data.auto_answer,
            auto_answer_json: data.auto_answer_json,
          })
          .eq('id', data.id)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      } else {
        const { error } = await gateway
          .from('detection_rule_readiness_mappings')
          .insert(data)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      }
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.rule_id] });
    },
  });
}

export function useDeleteReadinessMapping() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ruleId }: { id: string; ruleId: string }) => {
      const { error } = await gateway
        .from('detection_rule_readiness_mappings')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.ruleId] });
    },
  });
}

// Capture Fields CRUD
export function useUpsertCaptureField() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: {
      id?: string;
      rule_id: string;
      field_name: string;
      field_type?: string;
      description?: string | null;
      extraction_prompt?: string | null;
      is_required?: boolean;
      sort_order?: number;
    }) => {
      if (data.id) {
        const { error } = await gateway
          .from('detection_rule_capture_fields')
          .update({
            field_name: data.field_name,
            field_type: data.field_type,
            description: data.description,
            extraction_prompt: data.extraction_prompt,
            is_required: data.is_required,
          })
          .eq('id', data.id)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      } else {
        const { error } = await gateway
          .from('detection_rule_capture_fields')
          .insert(data)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      }
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.rule_id] });
    },
  });
}

export function useDeleteCaptureField() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ruleId }: { id: string; ruleId: string }) => {
      const { error } = await gateway
        .from('detection_rule_capture_fields')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.ruleId] });
    },
  });
}

// Account Captured Insights
export function useAccountCapturedInsights(accountId: string | null) {
  return useQuery({
    queryKey: ['account-captured-insights', accountId],
    queryFn: async () => {
      if (!accountId) return [];
      
      const { data, error } = await gateway
        .from('account_captured_insights')
        .select(`
          *,
          capture_field:detection_rule_capture_fields(
            id,
            field_name,
            field_type,
            description,
            rule:detection_rules(id, name, tree_id)
          ),
          source_transcript:transcript_reviews(id, file_name, created_at)
        `)
        .eq('account_id', accountId)
        .order('extracted_at', { ascending: false })
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    enabled: !!accountId,
  });
}

// Opportunity Captured Insights - filtered by opportunity_id
export function useOpportunityCapturedInsights(opportunityId: string | null) {
  return useQuery({
    queryKey: ['opportunity-captured-insights', opportunityId],
    queryFn: async () => {
      if (!opportunityId) return [];
      
      const { data, error } = await gateway
        .from('account_captured_insights')
        .select(`
          *,
          capture_field:detection_rule_capture_fields(
            id,
            field_name,
            field_type,
            description,
            rule:detection_rules(id, name, tree_id)
          ),
          source_transcript:transcript_reviews(id, file_name, created_at)
        `)
        .eq('opportunity_id', opportunityId)
        .order('extracted_at', { ascending: false })
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    enabled: !!opportunityId,
  });
}

// ========================================
// UNIFIED ACTIONS CRUD
// ========================================

export function useRuleActions(ruleId: string | null) {
  return useQuery({
    queryKey: ['detection-rule-actions', ruleId],
    queryFn: async () => {
      if (!ruleId) return [];
      
      const { data, error } = await gateway
        .from('detection_rule_actions')
        .select('*')
        .eq('rule_id', ruleId)
        .eq('is_active', true)
        .order('sort_order')
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data as DetectionRuleAction[];
    },
    enabled: !!ruleId,
  });
}

export function useUpsertRuleAction() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: {
      id?: string;
      rule_id: string;
      action_type: RuleActionType;
      action_config: RuleActionConfig;
      target_entity?: 'account' | 'opportunity' | 'contact' | null;
      sort_order?: number;
      is_active?: boolean;
    }) => {
      if (data.id) {
        // Update existing
        const { error } = await gateway
          .from('detection_rule_actions')
          .update({
            action_type: data.action_type,
            action_config: data.action_config,
            target_entity: data.target_entity,
            sort_order: data.sort_order,
            is_active: data.is_active,
          })
          .eq('id', data.id)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      } else {
        // Insert new
        const { error } = await gateway
          .from('detection_rule_actions')
          .insert({
            rule_id: data.rule_id,
            action_type: data.action_type,
            action_config: data.action_config,
            target_entity: data.target_entity || null,
            sort_order: data.sort_order || 0,
            is_active: data.is_active !== false,
          })
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      }
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.rule_id] });
      queryClient.invalidateQueries({ queryKey: ['detection-rule-actions', variables.rule_id] });
    },
  });
}

export function useDeleteRuleAction() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ruleId }: { id: string; ruleId: string }) => {
      const { error } = await gateway
        .from('detection_rule_actions')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['detection-rule-details', variables.ruleId] });
      queryClient.invalidateQueries({ queryKey: ['detection-rule-actions', variables.ruleId] });
    },
  });
}

// Helper functions for action types
export function getActionTypeLabel(type: RuleActionType): string {
  switch (type) {
    case 'update_field': return 'Update Field';
    case 'extract_data': return 'Extract Data';
    case 'answer_question': return 'Answer Question';
    case 'create_task': return 'Create Task';
    case 'create_nba': return 'Create NBA';
    default: return type;
  }
}

export function getActionTypeIcon(type: RuleActionType): string {
  switch (type) {
    case 'update_field': return 'Database';
    case 'extract_data': return 'FileText';
    case 'answer_question': return 'CheckCircle2';
    case 'create_task': return 'ListTodo';
    case 'create_nba': return 'Zap';
    default: return 'Settings';
  }
}

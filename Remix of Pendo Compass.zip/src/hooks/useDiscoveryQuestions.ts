import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface DiscoveryQuestion {
  id: string;
  functional_area_id: string;
  question: string;
  category: string | null;
  sort_order: number | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  functional_areas?: {
    name: string;
  };
}

export function useDiscoveryQuestions(functionalAreaId?: string) {
  return useQuery({
    queryKey: ['discovery-questions', functionalAreaId],
    queryFn: async () => {
      let query = gateway.from('discovery_questions')
        .select('*, functional_areas(name)')
        .order('category', { ascending: true });

      if (functionalAreaId) {
        query = query.eq('functional_area_id', functionalAreaId);
      }

      const result = await query.execute();
      if (result.error) throw new Error(result.error.message);
      return result.data as DiscoveryQuestion[];
    },
  });
}

export function useCreateDiscoveryQuestion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (question: {
      functional_area_id: string;
      question: string;
      category?: string;
      is_active?: boolean;
      sort_order?: number;
    }) => {
      // Check for duplicate questions
      const existingResult = await gateway.from('discovery_questions')
        .select('id')
        .eq('functional_area_id', question.functional_area_id)
        .ilike('question', question.question)
        .maybeSingle()
        .execute();

      if (existingResult.data) {
        console.log('Discovery question already exists, skipping:', question.question);
        return existingResult.data;
      }

      const result = await gateway.from('discovery_questions')
        .insert({
          ...question,
          is_active: question.is_active ?? false, // Default to inactive (draft)
        })
        .execute();

      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['discovery-questions'] });
    },
    onError: (error) => {
      console.error('Failed to create discovery question:', error);
    },
  });
}

export function useUpdateDiscoveryQuestion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<DiscoveryQuestion> & { id: string }) => {
      const result = await gateway.from('discovery_questions')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .execute();

      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['discovery-questions'] });
      toast.success('Discovery question updated');
    },
    onError: (error) => {
      toast.error('Failed to update question: ' + error.message);
    },
  });
}

export function useDeleteDiscoveryQuestion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const result = await gateway.from('discovery_questions')
        .delete()
        .eq('id', id)
        .execute();

      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['discovery-questions'] });
      toast.success('Discovery question deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete question: ' + error.message);
    },
  });
}

// Match functional area name to ID
export function useFunctionalAreaByName() {
  return useQuery({
    queryKey: ['functional-areas-map'],
    queryFn: async () => {
      const result = await gateway.from('functional_areas')
        .select('id, name')
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      // Create a map of lowercase name to ID
      const map = new Map<string, string>();
      (result.data || []).forEach((fa: any) => {
        map.set(fa.name.toLowerCase(), fa.id);
      });
      return map;
    },
  });
}

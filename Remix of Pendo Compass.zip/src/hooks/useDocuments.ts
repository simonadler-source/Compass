 import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
 import { toast } from 'sonner';
 import { gateway } from '@/lib/apiGateway';
 
 export interface Document {
   id: string;
   account_id: string;
   opportunity_id: string | null;
   name: string;
   description: string | null;
   type: string;
   file_url: string | null;
   is_external_url: boolean;
   owner_email: string | null;
   tags: string[];
   version: string;
   status: 'draft' | 'active' | 'archived' | 'expired';
   expiry_date: string | null;
   created_at: string;
   updated_at: string;
 }
 
 export interface CreateDocumentInput {
   account_id: string;
   opportunity_id?: string | null;
   name: string;
   description?: string | null;
   type: string;
   file_url?: string | null;
   is_external_url?: boolean;
   owner_email?: string | null;
   tags?: string[];
   version?: string;
   status?: 'draft' | 'active' | 'archived' | 'expired';
   expiry_date?: string | null;
   content?: string | null;
 }
 
 export interface UpdateDocumentInput {
   id: string;
   name?: string;
   description?: string | null;
   type?: string;
   file_url?: string | null;
   owner_email?: string | null;
   tags?: string[];
   version?: string;
   status?: 'draft' | 'active' | 'archived' | 'expired';
   expiry_date?: string | null;
 }
 
 // Fetch documents for an account (includes all opportunity-level docs for rollup)
 export function useAccountDocuments(accountId: string | null) {
   return useQuery({
     queryKey: ['account-documents', accountId],
     queryFn: async () => {
       if (!accountId) return [];
       
       const result = await gateway.from('account_documents')
         .select('*')
         .eq('account_id', accountId)
         .order('created_at', { ascending: false })
         .execute();
       
       if (result.error) throw new Error(result.error.message);
       return (result.data || []) as Document[];
     },
     enabled: !!accountId,
   });
 }
 
 // Fetch documents for a specific opportunity
 export function useOpportunityDocuments(opportunityId: string | null, accountId: string | null) {
   return useQuery({
     queryKey: ['opportunity-documents', opportunityId, accountId],
     queryFn: async () => {
       if (!opportunityId || !accountId) return { opportunityDocs: [], accountDocs: [] };
       
       // Fetch opportunity-specific documents
       const oppResult = await gateway.from('account_documents')
         .select('*')
         .eq('opportunity_id', opportunityId)
         .order('created_at', { ascending: false })
         .execute();
       
       // Fetch account-level documents (for rollup display)
       const accountResult = await gateway.from('account_documents')
         .select('*')
         .eq('account_id', accountId)
         .is('opportunity_id', null)
         .order('created_at', { ascending: false })
         .execute();
       
       if (oppResult.error) throw new Error(oppResult.error.message);
       if (accountResult.error) throw new Error(accountResult.error.message);
       
       return {
         opportunityDocs: (oppResult.data || []) as Document[],
         accountDocs: (accountResult.data || []) as Document[],
       };
     },
     enabled: !!opportunityId && !!accountId,
   });
 }
 
 // Create a new document
 export function useCreateDocument() {
   const queryClient = useQueryClient();
 
   return useMutation({
     mutationFn: async (doc: CreateDocumentInput) => {
       const result = await gateway.from('account_documents')
         .insert({
           ...doc,
           tags: doc.tags || [],
           version: doc.version || '1.0',
           status: doc.status || 'active',
           is_external_url: doc.is_external_url || false,
         })
         .execute();
       
       if (result.error) throw new Error(result.error.message);
       return result.data?.[0] as Document;
     },
     onSuccess: (data) => {
       if (data?.account_id) {
         queryClient.invalidateQueries({ queryKey: ['account-documents', data.account_id] });
         queryClient.invalidateQueries({ queryKey: ['account', data.account_id] });
       }
       if (data?.opportunity_id) {
         queryClient.invalidateQueries({ queryKey: ['opportunity-documents', data.opportunity_id] });
       }
       toast.success('Document added successfully');
     },
     onError: (error) => {
       toast.error('Failed to add document: ' + error.message);
     },
   });
 }
 
 // Update an existing document
 export function useUpdateDocument() {
   const queryClient = useQueryClient();
 
   return useMutation({
     mutationFn: async ({ id, ...updates }: UpdateDocumentInput) => {
       const result = await gateway.from('account_documents')
         .update(updates)
         .eq('id', id)
         .execute();
       
       if (result.error) throw new Error(result.error.message);
       return result.data?.[0] as Document;
     },
     onSuccess: (data) => {
       queryClient.invalidateQueries({ queryKey: ['account-documents'] });
       queryClient.invalidateQueries({ queryKey: ['opportunity-documents'] });
       toast.success('Document updated');
     },
     onError: (error) => {
       toast.error('Failed to update document: ' + error.message);
     },
   });
 }
 
 // Delete a document
 export function useDeleteDocument() {
   const queryClient = useQueryClient();
 
   return useMutation({
     mutationFn: async (id: string) => {
       const result = await gateway.from('account_documents')
         .delete()
         .eq('id', id)
         .execute();
       
       if (result.error) throw new Error(result.error.message);
       return id;
     },
     onSuccess: () => {
       queryClient.invalidateQueries({ queryKey: ['account-documents'] });
       queryClient.invalidateQueries({ queryKey: ['opportunity-documents'] });
       toast.success('Document deleted');
     },
     onError: (error) => {
       toast.error('Failed to delete document: ' + error.message);
     },
   });
 }
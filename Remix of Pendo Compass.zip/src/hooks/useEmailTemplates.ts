import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface EmailTemplate {
  id: string;
  template_key: string;
  name: string;
  subject: string;
  description: string | null;
  html_template: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  updated_by: string | null;
}

export interface NotificationType {
  id: string;
  type_key: string;
  name: string;
  description: string | null;
  template_id: string | null;
  is_enabled: boolean;
  created_at: string;
  updated_at: string;
}

export interface EmailLogEntry {
  id: string;
  recipient_email: string;
  recipient_user_id: string | null;
  template_key: string;
  subject: string;
  resend_id: string | null;
  status: string;
  created_at: string;
  html_content?: string | null;
}

export function useEmailTemplates() {
  const queryClient = useQueryClient();

  const { data: templates = [], isLoading: templatesLoading } = useQuery({
    queryKey: ['email-templates'],
    queryFn: async () => {
      const result = await gateway.from('email_templates')
        .select('*')
        .order('name', { ascending: true })
        .execute();

      if (result.error) throw new Error(result.error.message);
      return result.data as EmailTemplate[];
    },
  });

  const { data: notificationTypes = [], isLoading: typesLoading } = useQuery({
    queryKey: ['notification-types'],
    queryFn: async () => {
      const result = await gateway.from('notification_types')
        .select('*')
        .order('name', { ascending: true })
        .execute();

      if (result.error) throw new Error(result.error.message);
      return result.data as NotificationType[];
    },
  });

  const updateTemplate = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<EmailTemplate> & { id: string }) => {
      const result = await gateway.from('email_templates')
        .update(updates)
        .eq('id', id)
        .execute();

      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['email-templates'] });
      toast.success('Template updated');
    },
    onError: (error: Error) => {
      toast.error('Failed to update template: ' + error.message);
    },
  });

  const createTemplate = useMutation({
    mutationFn: async (template: Omit<EmailTemplate, 'id' | 'created_at' | 'updated_at' | 'updated_by'>) => {
      const result = await gateway.from('email_templates')
        .insert(template)
        .execute();

      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['email-templates'] });
      toast.success('Template created');
    },
    onError: (error: Error) => {
      toast.error('Failed to create template: ' + error.message);
    },
  });

  const toggleNotificationType = useMutation({
    mutationFn: async ({ id, is_enabled }: { id: string; is_enabled: boolean }) => {
      const result = await gateway.from('notification_types')
        .update({ is_enabled })
        .eq('id', id)
        .execute();

      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notification-types'] });
      toast.success('Notification type updated');
    },
    onError: (error: Error) => {
      toast.error('Failed to update: ' + error.message);
    },
  });

  return {
    templates,
    notificationTypes,
    isLoading: templatesLoading || typesLoading,
    updateTemplate,
    createTemplate,
    toggleNotificationType,
  };
}

export function useEmailLog(limit: number = 50) {
  return useQuery({
    queryKey: ['email-log', limit],
    queryFn: async () => {
      const result = await gateway.from('email_log')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(limit)
        .execute();

      if (result.error) throw new Error(result.error.message);
      return result.data as EmailLogEntry[];
    },
  });
}

import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useAccountStrategicThemes, type StrategicTheme } from './useAccountStrategicThemes';
import { useOpportunityStrategicThemes } from './useOpportunityStrategicThemes';
import { useOpportunityPainPoints } from './useOpportunityPainPoints';
import { useAccountPainPoints, type AccountPainPoint } from './useAccountPainPoints';
import { useOpportunityUseCasesThemed } from './useOpportunityUseCasesThemed';
import { useOpportunityMilestones, useOpportunityValidationTasks, useReadinessTemplates, useOpportunityReadinessAnswers, useOpportunityDeploymentTypes, useReadinessApps, getFlagType, isFlagDisabled, shouldShowSubQuestion, type OpportunityMilestone, type OpportunityValidationTask, type ReadinessQuestion, type ReadinessAnswer } from './useOpportunityReadiness';
import type { ThemedUseCase } from './useThemedUseCases';
import { supabase } from '@/integrations/supabase/client';

export interface SuccessCriterionDeck {
  id: string;
  criterion: string;
  status: string;
  notes: string | null;
  source: string | null;
  deliverables: { id: string; title: string; is_completed: boolean }[];
}

export interface TechnicalRiskDeck {
  id: string;
  risk_description: string;
  severity: string;
  status: string;
  mitigation_plan: string | null;
  owner_email: string | null;
}

export interface ReadinessQuestionDetail {
  questionText: string;
  categoryName: string;
  answer: string | null;
  flagType: 'green' | 'amber' | 'red';
  source: string | null;
}

export interface ReadinessSummary {
  score: number;
  answered: number;
  total: number;
  excluded: number;
  greenCount: number;
  amberCount: number;
  redCount: number;
  aiExtracted: number;
  questions: ReadinessQuestionDetail[];
}

export interface EvaluationDeckData {
  accountName: string;
  opportunityName: string;
  opportunityId: string;
  accountId: string;
  customerSynopsis: string | null;
  painPoints: AccountPainPoint[];
  useCases: ThemedUseCase[];
  strategicChallenges: StrategicTheme[];
  strategicInitiatives: StrategicTheme[];
  opportunityChallenges: any[];
  opportunityInitiatives: any[];
  successCriteria: SuccessCriterionDeck[];
  readiness: ReadinessSummary | null;
  milestones: OpportunityMilestone[];
  validationTasks: OpportunityValidationTask[];
  risks: TechnicalRiskDeck[];
}

export function useEvaluationDeckData(
  opportunityId: string,
  accountId: string,
  accountName: string,
  opportunityName: string,
  enabled: boolean = false
) {
  const { data: accountThemes } = useAccountStrategicThemes(enabled ? accountId : null);
  const { data: oppThemes } = useOpportunityStrategicThemes(enabled ? opportunityId : null);
  const { data: oppPainPoints } = useOpportunityPainPoints(enabled ? opportunityId : null);
  const { data: accountPainPoints } = useAccountPainPoints(enabled ? accountId : null);
  const { data: useCases } = useOpportunityUseCasesThemed(enabled ? opportunityId : null);
  const { data: milestones } = useOpportunityMilestones(enabled ? opportunityId : '');
  const { data: validationTasks } = useOpportunityValidationTasks(enabled ? opportunityId : '');
  const { data: opportunityDeployments } = useOpportunityDeploymentTypes(enabled ? opportunityId : '');
  const { data: readinessApps } = useReadinessApps(enabled ? opportunityId : '');

  // Derive deployment type IDs to filter readiness categories (matches TechnicalReadinessTab)
  const deploymentTypeIds = useMemo(() => 
    (opportunityDeployments || []).map((d: any) => d.deployment_type_id),
    [opportunityDeployments]
  );

  const { data: readinessTemplates } = useReadinessTemplates(enabled ? deploymentTypeIds : []);
  const { data: readinessAnswers } = useOpportunityReadinessAnswers(enabled ? opportunityId : '');

  // Fetch operational metrics for ROI narrative in synopsis
  const { data: operationalMetrics } = useQuery({
    queryKey: ['eval-deck-metrics', accountId],
    queryFn: async () => {
      const { data, error } = await gateway.from('account_metrics')
        .select('metric_name, metric_value, metric_numeric_value, metric_category, context')
        .eq('account_id', accountId)
        .order('confidence_score', { ascending: false })
        .limit(10);
      if (error) return [];
      return data || [];
    },
    enabled,
  });

  // Fall back to account-level pain points if none are opportunity-scoped
  const painPoints = (oppPainPoints && oppPainPoints.length > 0) ? oppPainPoints : (accountPainPoints || []);

  // Derive challenges/initiatives for synopsis generation
  const challenges = oppThemes?.painThemes?.length ? oppThemes.painThemes : accountThemes?.painThemes || [];
  const initiatives = oppThemes?.initiatives?.length ? oppThemes.initiatives : accountThemes?.initiatives || [];
  // Include all use cases for the deck (not just accepted/validated) — they represent evaluation scope
  const filteredUseCases = useCases || [];

  // Generate customer-facing synopsis via AI
  const { data: customerSynopsis } = useQuery({
    queryKey: ['eval-deck-synopsis', opportunityId, accountName],
    queryFn: async () => {
      try {
        const { data, error } = await supabase.functions.invoke('generate-deck-synopsis', {
          body: {
            accountName,
            opportunityName,
            painPoints: (painPoints || []).slice(0, 6),
            useCases: filteredUseCases.slice(0, 6),
            strategicChallenges: challenges.slice(0, 4),
            strategicInitiatives: initiatives.slice(0, 4),
            operationalMetrics: (operationalMetrics || []).slice(0, 8),
          },
        });
        if (error) {
          console.error('Synopsis generation failed:', error);
          return null;
        }
        return (data?.synopsis as string) || null;
      } catch (err) {
        console.error('Synopsis generation error:', err);
        return null;
      }
    },
    enabled: enabled && !!(painPoints || useCases || challenges.length > 0),
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });

  // Success criteria
  const { data: successCriteria } = useQuery({
    queryKey: ['eval-deck-criteria', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway.from('evaluation_success_criteria')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .neq('status', 'rejected')
        .order('created_at', { ascending: true })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      
      const criteria = (data || []) as any[];
      const criterionIds = criteria.map(c => c.id);
      if (criterionIds.length > 0) {
        const { data: deliverables } = await gateway.from('success_criteria_deliverables')
          .select('*')
          .in('criterion_id', criterionIds)
          .order('sort_order', { ascending: true })
          .execute();
        
        return criteria.map(c => ({
          id: c.id,
          criterion: c.criterion,
          status: c.status,
          notes: c.notes,
          source: c.source,
          deliverables: ((deliverables || []) as any[])
            .filter(d => d.criterion_id === c.id)
            .map(d => ({ id: d.id, title: d.title, is_completed: d.is_completed })),
        })) as SuccessCriterionDeck[];
      }
      return criteria.map(c => ({
        id: c.id,
        criterion: c.criterion,
        status: c.status,
        notes: c.notes,
        source: c.source,
        deliverables: [],
      })) as SuccessCriterionDeck[];
    },
    enabled,
  });

  // Technical risks
  const { data: risks } = useQuery({
    queryKey: ['eval-deck-risks', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway.from('evaluation_technical_risks')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('created_at', { ascending: true })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []).map((r: any) => ({
        id: r.id,
        risk_description: r.risk_description,
        severity: r.severity,
        status: r.status,
        mitigation_plan: r.mitigation_plan,
        owner_email: r.owner_email,
      })) as TechnicalRiskDeck[];
    },
    enabled,
  });

  // Compute readiness summary — matches TechnicalReadinessTab logic
  const readiness: ReadinessSummary | null = (() => {
    if (!readinessTemplates || !readinessAnswers) return null;
    // Resolve answers using app-scoped logic (matches TechnicalReadinessTab)
    const primaryAppId = readinessApps?.find((a: any) => a.is_primary)?.id || readinessApps?.[0]?.id || null;
    const answerMap = new Map<string, ReadinessAnswer>();
    // First pass: legacy answers (null app_id)
    readinessAnswers.filter((a: ReadinessAnswer) => !a.app_id).forEach((a: ReadinessAnswer) => answerMap.set(a.question_id, a));
    // Second pass: primary app answers (higher priority)
    if (primaryAppId) {
      readinessAnswers.filter((a: ReadinessAnswer) => a.app_id === primaryAppId).forEach((a: ReadinessAnswer) => answerMap.set(a.question_id, a));
    }
    
    let totalVisible = 0, answered = 0, excluded = 0;
    let greenCount = 0, amberCount = 0, redCount = 0, aiExtracted = 0;
    const questions: ReadinessQuestionDetail[] = [];

    const processQuestion = (q: ReadinessQuestion, categoryName: string, parentAnswer?: ReadinessAnswer) => {
      if (q.trigger_condition && parentAnswer !== undefined) {
        const parentAnswerText = parentAnswer?.answer || null;
        if (!shouldShowSubQuestion(parentAnswerText, q.trigger_condition)) {
          return;
        }
      }

      const answer = answerMap.get(q.id);
      totalVisible++;

      if (isFlagDisabled(answer)) {
        excluded++;
      } else {
        const hasAnswer = answer?.answer || answer?.answer_json;
        if (hasAnswer) answered++;
        const flagType = getFlagType(answer);
        if (flagType === 'green') greenCount++;
        else if (flagType === 'amber') amberCount++;
        else redCount++;
        if (answer?.source === 'ai_extracted') aiExtracted++;

        questions.push({
          questionText: q.question || '',
          categoryName,
          answer: answer?.answer || null,
          flagType: flagType as 'green' | 'amber' | 'red',
          source: answer?.source || null,
        });
      }

      if (q.children) {
        q.children.forEach((child: ReadinessQuestion) => processQuestion(child, categoryName, answer));
      }
    };

    readinessTemplates.forEach((cat: any) => {
      (cat.questions || []).forEach((q: ReadinessQuestion) => processQuestion(q, cat.name || cat.category_name || ''));
    });

    const activeTotal = totalVisible - excluded;
    const weightedDenominator = (redCount * 2) + (amberCount * 1.5) + (greenCount * 1);
    let score = 0;
    if (weightedDenominator > 0) {
      score = Math.round((greenCount * 100 + amberCount * 50) / weightedDenominator);
    }
    score = Math.max(0, Math.min(100, score));

    return { score, answered, total: activeTotal, excluded, greenCount, amberCount, redCount, aiExtracted, questions };
  })();

  const deckData: EvaluationDeckData | null = enabled ? {
    accountName,
    opportunityName,
    opportunityId,
    accountId,
    customerSynopsis: customerSynopsis || null,
    painPoints: painPoints || [],
    useCases: filteredUseCases,
    strategicChallenges: accountThemes?.painThemes || [],
    strategicInitiatives: accountThemes?.initiatives || [],
    opportunityChallenges: oppThemes?.painThemes || [],
    opportunityInitiatives: oppThemes?.initiatives || [],
    successCriteria: successCriteria || [],
    readiness,
    milestones: milestones || [],
    validationTasks: validationTasks || [],
    risks: risks || [],
  } : null;

  const isLoading = enabled && (!accountThemes && !painPoints);

  return { data: deckData, isLoading };
}

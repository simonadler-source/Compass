import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway } from '@/lib/apiGateway';
import { useMemo } from 'react';
import { differenceInDays, parseISO } from 'date-fns';

export type EvalPhase = 'planning' | 'deploying' | 'running' | 'completed';

export interface MilestoneSummary {
  total: number;
  completed: number;
  withScheduledDate: number;
}

export interface EvaluationOpportunity {
  id: string;
  name: string;
  accountName: string;
  accountId: string;
  ownerEmail: string | null;
  primarySeEmail: string | null;
  evalType: string | null;
  evalStartDate: string | null;
  evalEndDate: string | null;
  primaryEvalQuote: string | null;
  readinessScore: number | null;
  value: number | null;
  closeDate: string | null;
  salesStage: string | null;
  preSalesStage: string | null;
  evalPhaseOverride: string | null;
  phase: EvalPhase;
  phaseSource: 'computed' | 'override';
  phaseConflict: boolean; // true if override differs from computed
  computedPhase: EvalPhase;
  daysRemaining: number | null;
  daysElapsed: number | null;
  criteriaCount: number;
  criteriaMetCount: number;
  criteriaAtRiskCount: number;
  useCaseCount: number;
  riskCount: number;
  issueCount: number;
  risks: string[];
  milestoneSummary: MilestoneSummary | null;
  addedViaMilestones: boolean; // true if this opp was only included because of milestones
}

export interface EvalCriterion {
  id: string;
  opportunity_id: string;
  criterion: string;
  metric_name: string | null;
  target_value: string | null;
  current_value: string | null;
  status: string;
  notes: string | null;
  source: string | null;
  created_at: string;
  updated_at: string;
}

export interface EvalTechnicalRisk {
  id: string;
  opportunity_id: string;
  risk_description: string;
  severity: string;
  status: string;
  mitigation_plan: string | null;
  entry_type: string;
  source: string | null;
  created_at: string;
  updated_at: string;
}

// Pre-sales stages at or above Proof - Scoping
const PROOF_SCOPING_AND_ABOVE = [
  'proof - scoping', 'proof', 'technical win', 'technical loss',
];

function computePhase(
  evalQuote: string | null,
  evalStart: string | null,
  evalEnd: string | null,
  preSalesStage: string | null,
  hasEvalSignal: boolean,
  milestoneSummary: MilestoneSummary | null,
): EvalPhase {
  // Completed: has actual end date
  if (evalEnd) {
    const end = parseISO(evalEnd);
    if (end <= new Date()) return 'completed';
  }

  // Running: has quote AND actual start date
  if (evalQuote && evalStart) {
    const start = parseISO(evalStart);
    if (start <= new Date()) return 'running';
  }

  // Deploying: has primary eval quote (but no start date yet, or start in future)
  if (evalQuote) return 'deploying';

  // Infer from milestones: if some milestones are completed → running, if any scheduled → planning
  if (milestoneSummary) {
    if (milestoneSummary.completed > 0) return 'running';
    if (milestoneSummary.withScheduledDate > 0) return 'planning';
  }

  // Planning: detection signals OR pre-sales stage >= Proof - Scoping
  if (hasEvalSignal) return 'planning';
  if (preSalesStage && PROOF_SCOPING_AND_ABOVE.includes(preSalesStage.toLowerCase())) {
    return 'planning';
  }

  return 'planning';
}

function computeRisks(opp: EvaluationOpportunity): string[] {
  const risks: string[] = [];

  if (opp.criteriaCount === 0 && opp.phase !== 'completed') {
    risks.push('Flying blind — no success criteria defined');
  }
  if (opp.criteriaAtRiskCount > 0) {
    risks.push(`${opp.criteriaAtRiskCount} success criteria at risk`);
  }
  if (opp.phase === 'running' && opp.daysRemaining !== null && opp.daysRemaining <= 7) {
    risks.push(`Only ${opp.daysRemaining} days remaining in evaluation`);
  }
  if (opp.phase === 'running' && opp.readinessScore !== null && opp.readinessScore < 40) {
    risks.push(`Low readiness score (${opp.readinessScore}%) during active evaluation`);
  }
  if (opp.phase === 'running' && opp.criteriaCount > 0 && opp.criteriaMetCount === 0) {
    risks.push('No success criteria met yet');
  }
  if (opp.riskCount > 0) {
    risks.push(`${opp.riskCount} open risk${opp.riskCount > 1 ? 's' : ''}`);
  }
  if (opp.issueCount > 0) {
    risks.push(`${opp.issueCount} open issue${opp.issueCount > 1 ? 's' : ''}`);
  }
  return risks;
}

export function useEvaluationRadar(teamEmails: string[]) {
  const selectFields = `
    id, name, account_id, owner_email, primary_se_email,
    eval_type, eval_start_date, eval_end_date, primary_eval_quote,
    readiness_score, value, close_date, is_archived,
    sales_stage, pre_sales_stage, eval_phase_override, eval_radar_dismissed,
    accounts!inner(id, name)
  `;

  // Fetch team-scoped opps
  const { data: teamOpps, isLoading: teamOppsLoading } = useQuery({
    queryKey: ['evaluation-radar-opps-team', teamEmails],
    queryFn: async () => {
      if (teamEmails.length === 0) return [];
      const { data, error } = await gateway
        .from('opportunities')
        .select(selectFields)
        .eq('is_archived', false)
        .or(`owner_email.in.(${teamEmails.join(',')}),primary_se_email.in.(${teamEmails.join(',')})`)
        .limit(500);
      if (error) throw error;
      return data || [];
    },
    enabled: teamEmails.length > 0,
  });

  // Also fetch any opps with manual phase override (not filtered by team —
  // if a manager explicitly adds an opp it should always be visible)
  const { data: overrideOpps, isLoading: overrideOppsLoading } = useQuery({
    queryKey: ['evaluation-radar-opps-overrides'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunities')
        .select(selectFields)
        .eq('is_archived', false)
        .eq('eval_radar_dismissed', false)
        .not('eval_phase_override', 'is', null)
        .limit(200);
      if (error) throw error;
      return data || [];
    },
    enabled: true,
  });

  // Merge both sets, deduplicating by id
  const evalOpportunities = useMemo(() => {
    const map = new Map<string, any>();
    for (const o of (teamOpps || [])) map.set(o.id, o);
    for (const o of (overrideOpps || [])) map.set(o.id, o);
    return Array.from(map.values());
  }, [teamOpps, overrideOpps]);

  const oppsLoading = teamOppsLoading || overrideOppsLoading;

  // Fetch milestone summaries for ALL team opps to know which have milestones
  const allOppIds = useMemo(() => evalOpportunities.map((o: any) => o.id), [evalOpportunities]);

  const { data: milestoneSummaries } = useQuery({
    queryKey: ['eval-milestone-summaries', allOppIds],
    queryFn: async () => {
      if (allOppIds.length === 0) return {} as Record<string, MilestoneSummary>;
      const { data, error } = await supabase
        .from('opportunity_milestones')
        .select('opportunity_id, status, scheduled_date, completed_date')
        .in('opportunity_id', allOppIds);
      if (error) return {} as Record<string, MilestoneSummary>;
      const summaries: Record<string, MilestoneSummary> = {};
      (data || []).forEach(m => {
        if (!summaries[m.opportunity_id]) {
          summaries[m.opportunity_id] = { total: 0, completed: 0, withScheduledDate: 0 };
        }
        summaries[m.opportunity_id].total++;
        if (m.status === 'completed' || m.completed_date) summaries[m.opportunity_id].completed++;
        if (m.scheduled_date) summaries[m.opportunity_id].withScheduledDate++;
      });
      return summaries;
    },
    enabled: allOppIds.length > 0,
  });

  // Filter to only relevant opps (have eval data, proof+ stages, OR milestones with dates)
  // Also exclude dismissed opps
  const relevantOpps = useMemo(() => {
    if (!evalOpportunities) return [];
    return evalOpportunities.filter(o => {
      // Skip dismissed opps
      if (o.eval_radar_dismissed) return false;

      // Original criteria
      if (
        o.eval_type ||
        o.primary_eval_quote ||
        o.eval_start_date ||
        o.eval_end_date ||
        o.eval_phase_override ||
        (o.pre_sales_stage && PROOF_SCOPING_AND_ABOVE.includes(o.pre_sales_stage.toLowerCase()))
      ) return true;

      // New: include if opportunity has milestones with scheduled dates or completed milestones
      const ms = milestoneSummaries?.[o.id];
      if (ms && (ms.withScheduledDate > 0 || ms.completed > 0)) return true;

      return false;
    });
  }, [evalOpportunities, milestoneSummaries]);

  const oppIds = useMemo(() => relevantOpps.map(o => o.id), [relevantOpps]);

  // Fetch criteria, risks, and use case counts in parallel
  const { data: criteria, isLoading: criteriaLoading, refetch: refetchCriteria } = useQuery({
    queryKey: ['evaluation-criteria', oppIds],
    queryFn: async () => {
      if (oppIds.length === 0) return [];
      const { data, error } = await supabase
        .from('evaluation_success_criteria')
        .select('*')
        .in('opportunity_id', oppIds);
      if (error) throw error;
      return (data || []) as EvalCriterion[];
    },
    enabled: oppIds.length > 0,
  });

  const { data: technicalRisks, isLoading: risksLoading, refetch: refetchRisks } = useQuery({
    queryKey: ['evaluation-risks', oppIds],
    queryFn: async () => {
      if (oppIds.length === 0) return [];
      const { data, error } = await supabase
        .from('evaluation_technical_risks')
        .select('*')
        .in('opportunity_id', oppIds);
      if (error) throw error;
      return (data || []) as EvalTechnicalRisk[];
    },
    enabled: oppIds.length > 0,
  });

  const { data: useCaseCounts } = useQuery({
    queryKey: ['eval-use-case-counts', oppIds],
    queryFn: async () => {
      if (oppIds.length === 0) return {};
      const { data, error } = await supabase
        .from('account_use_cases')
        .select('opportunity_id')
        .in('opportunity_id', oppIds);
      if (error) throw error;
      const counts: Record<string, number> = {};
      (data || []).forEach(uc => {
        if (uc.opportunity_id) {
          counts[uc.opportunity_id] = (counts[uc.opportunity_id] || 0) + 1;
        }
      });
      return counts;
    },
    enabled: oppIds.length > 0,
  });

  // Check which opps have eval detection signals (evaluation OR reverse demo)
  const EVAL_SIGNAL_RULE_IDS = [
    'a1111111-1111-1111-1111-111111111111', // Evaluation & POC
    'b2222222-2222-2222-2222-222222222222', // Reverse Demo Signals
  ];
  const { data: evalSignalOpps } = useQuery({
    queryKey: ['eval-signal-opps', oppIds],
    queryFn: async () => {
      if (oppIds.length === 0) return new Set<string>();
      // Check detection_rule_matches for evaluation OR reverse demo signal rules
      const { data, error } = await supabase
        .from('detection_rule_matches')
        .select('opportunity_id')
        .in('rule_id', EVAL_SIGNAL_RULE_IDS)
        .in('opportunity_id', oppIds);
      if (error) return new Set<string>();
      return new Set((data || []).map(d => d.opportunity_id).filter(Boolean) as string[]);
    },
    enabled: oppIds.length > 0,
  });

  // Build evaluations
  const evaluations = useMemo(() => {
    const criteriaByOpp = (criteria || []).reduce((acc, c) => {
      if (!acc[c.opportunity_id]) acc[c.opportunity_id] = [];
      acc[c.opportunity_id].push(c);
      return acc;
    }, {} as Record<string, EvalCriterion[]>);

    const risksByOpp = (technicalRisks || []).reduce((acc, r) => {
      if (!acc[r.opportunity_id]) acc[r.opportunity_id] = [];
      acc[r.opportunity_id].push(r);
      return acc;
    }, {} as Record<string, EvalTechnicalRisk[]>);

    const result: EvaluationOpportunity[] = [];
    for (const opp of relevantOpps) {
      const oppCriteria = criteriaByOpp[opp.id] || [];
      const oppRisks = risksByOpp[opp.id] || [];
      const openItems = oppRisks.filter(r => r.status === 'open' || r.status === 'accepted' || r.status === 'new' || r.status === 'in_review' || r.status === 'awaiting_feedback');
      const openRiskCount = openItems.filter(r => (r.entry_type || 'risk') === 'risk').length;
      const openIssueCount = openItems.filter(r => (r.entry_type || 'risk') === 'issue').length;
      const now = new Date();
      const endDate = opp.eval_end_date ? parseISO(opp.eval_end_date) : null;
      const startDate = opp.eval_start_date ? parseISO(opp.eval_start_date) : null;
      const hasEvalSignal = evalSignalOpps?.has(opp.id) || false;
      const ms = milestoneSummaries?.[opp.id] || null;

      const computedPhase = computePhase(
        opp.primary_eval_quote,
        opp.eval_start_date,
        opp.eval_end_date,
        opp.pre_sales_stage,
        hasEvalSignal,
        ms,
      );

      const override = opp.eval_phase_override as EvalPhase | null;
      const phase = override || computedPhase;
      const phaseConflict = override != null && override !== computedPhase;

      // Determine if this opp was only added because of milestones (not original criteria)
      const hasOriginalCriteria =
        !!opp.eval_type ||
        !!opp.primary_eval_quote ||
        !!opp.eval_start_date ||
        !!opp.eval_end_date ||
        !!opp.eval_phase_override ||
        (opp.pre_sales_stage && PROOF_SCOPING_AND_ABOVE.includes(opp.pre_sales_stage.toLowerCase())) ||
        hasEvalSignal;

      const evalOpp: EvaluationOpportunity = {
        id: opp.id,
        name: opp.name,
        accountName: opp.accounts?.name || 'Unknown',
        accountId: opp.account_id,
        ownerEmail: opp.owner_email,
        primarySeEmail: opp.primary_se_email,
        evalType: opp.eval_type,
        evalStartDate: opp.eval_start_date,
        evalEndDate: opp.eval_end_date,
        primaryEvalQuote: opp.primary_eval_quote,
        readinessScore: opp.readiness_score,
        value: opp.value,
        closeDate: opp.close_date,
        salesStage: opp.sales_stage,
        preSalesStage: opp.pre_sales_stage,
        evalPhaseOverride: opp.eval_phase_override,
        phase,
        phaseSource: override ? 'override' : 'computed',
        phaseConflict,
        computedPhase,
        daysRemaining: endDate ? differenceInDays(endDate, now) : null,
        daysElapsed: startDate ? differenceInDays(now, startDate) : null,
        criteriaCount: oppCriteria.length,
        criteriaMetCount: oppCriteria.filter(c => c.status === 'met').length,
        criteriaAtRiskCount: oppCriteria.filter(c => c.status === 'at_risk' || c.status === 'not_met').length,
        useCaseCount: useCaseCounts?.[opp.id] || 0,
        riskCount: openRiskCount,
        issueCount: openIssueCount,
        risks: [],
        milestoneSummary: ms,
        addedViaMilestones: !hasOriginalCriteria && ms != null,
      };
      evalOpp.risks = computeRisks(evalOpp);
      result.push(evalOpp);
    }

    // Sort by risk count desc within each phase
    return result.sort((a, b) => b.risks.length - a.risks.length);
  }, [relevantOpps, criteria, technicalRisks, useCaseCounts, evalSignalOpps, milestoneSummaries]);

  const byPhase = useMemo(() => {
    const groups: Record<EvalPhase, EvaluationOpportunity[]> = {
      planning: [], deploying: [], running: [], completed: [],
    };
    evaluations.forEach(e => groups[e.phase].push(e));
    return groups;
  }, [evaluations]);

  const stats = useMemo(() => {
    const planning = byPhase.planning.length;
    const deploying = byPhase.deploying.length;
    const running = byPhase.running.length;
    const completed = byPhase.completed.length;
    const atRisk = evaluations.filter(e => e.risks.length > 0 && e.phase !== 'completed').length;
    const flyingBlind = evaluations.filter(e => e.criteriaCount === 0 && e.phase !== 'completed').length;
    return { planning, deploying, running, completed, atRisk, flyingBlind, total: evaluations.length };
  }, [evaluations, byPhase]);

  return {
    evaluations,
    byPhase,
    criteria: criteria || [],
    technicalRisks: technicalRisks || [],
    stats,
    isLoading: oppsLoading || criteriaLoading || risksLoading,
    refetchCriteria,
    refetchRisks,
  };
}

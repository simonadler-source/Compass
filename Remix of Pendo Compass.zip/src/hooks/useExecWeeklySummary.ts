import { useQuery, useMutation } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useTeamMembers } from './useTeamMembers';
import { useMemo } from 'react';
import { subDays, startOfWeek, endOfWeek, format, subWeeks } from 'date-fns';
import { toast } from 'sonner';

export interface WeeklyKPI {
  label: string;
  value: number;
  previousValue: number;
  fourWeekAvg: number;
  unit?: string;
  trend: 'up' | 'down' | 'flat';
  trendIsPositive: boolean;
}

export interface EvalPhaseCounts {
  planning: number;
  deploying: number;
  running: number;
  completed: number;
}

export interface EvalOppSummary {
  id: string;
  name: string;
  accountName: string;
  value: number | null;
  primarySeEmail: string | null;
  phase: string;
}

export interface RiskIssueSummary {
  opportunityId: string;
  opportunityName: string;
  accountId: string;
  accountName: string;
  entryType: string; // 'risk' | 'issue'
  severity: string;
  description: string;
  status: string;
}

export interface DealMovement {
  opportunityId: string;
  opportunityName: string;
  accountName: string;
  oldStage: string | null;
  newStage: string | null;
  value: number | null;
  movedAt: string;
}

export interface StageMovementSummary {
  forwardCount: number;
  closedWon: DealMovement[];
  closedLost: DealMovement[];
  regressions: DealMovement[];
  totalMovements: number;
}

export interface NotableActivity {
  id: string;
  meetingType: string;
  meetingTypeLabel: string;
  meetingDate: string;
  opportunityName: string | null;
  accountName: string | null;
  value: number | null;
  attendeeEmails: string[];
  notes: string | null;
}

export interface OpportunitySituationReport {
  opportunityId: string;
  opportunityName: string;
  accountName: string;
  oneLiner: string;
  nextCriticalAction: string | null;
  generatedAt: string;
}

export interface ReplicablePlay {
  approach: string;
  howToReplicate: string;
  whyItMatters: string;
}

export interface BestCallHighlight {
  seEmail: string;
  overallScore: number;
  meetingDate: string | null;
  opportunityName: string | null;
  accountName: string | null;
  greatnessMoment: string | null;
  whatWorkedWell: string[];
  replicablePlaybook: ReplicablePlay[];
  topDimensions: { name: string; score: number; evidence: string | null }[];
}

export interface TopMeetingOpp {
  id: string;
  name: string;
  accountName: string | null;
  value: number;
}

export interface ExecWeeklySummaryData {
  weekLabel: string;
  weekStart: string;
  weekEnd: string;
  kpis: WeeklyKPI[];
  evalPhaseCounts: EvalPhaseCounts;
  previousEvalPhaseCounts: EvalPhaseCounts;
  evalOppsByPhase: Record<string, EvalOppSummary[]>;
  risksAndIssues: RiskIssueSummary[];
  dealMovements: DealMovement[];
  stageMovementSummary: StageMovementSummary;
  totalRevenueInMotion: number;
  previousRevenueInMotion: number;
  topCoachingImprovers: { name: string; delta: number }[];
  teamSize: number;
  notableActivities: NotableActivity[];
  manualMeetingCount: number;
  situationReports: OpportunitySituationReport[];
  bestCall: BestCallHighlight | null;
  // Meeting-linked pipeline metrics
  meetingLinkedPipelineValue: number;
  meetingLinkedOppCount: number;
  preEvalPipelineValue: number;
  preEvalOppCount: number;
  evalStagePipelineValue: number;
  evalStageOppCount: number;
  topMeetingLinkedOpps: TopMeetingOpp[];
  meetingWoWDelta: number | null; // percentage change WoW, null if no previous data
}

function calcTrend(current: number, previous: number): 'up' | 'down' | 'flat' {
  if (current > previous) return 'up';
  if (current < previous) return 'down';
  return 'flat';
}

export function useExecWeeklySummary(customDateRange?: { from: Date; to: Date }, teamEmailsOverride?: string[]) {
  const { effectiveUserId, effectiveUserEmail } = useAuth();

  // Strict hierarchy only (self + recursive reports), excluding legacy team_members fallback
  const { hierarchyTeamMembers, isLoading: teamLoading } = useTeamMembers();
  const teamHierarchyEmailsWithSelf = useMemo(() => {
    // If override provided, use it directly
    if (teamEmailsOverride && teamEmailsOverride.length > 0) {
      return teamEmailsOverride.map(e => e.toLowerCase());
    }
    const hierarchyEmails = (hierarchyTeamMembers || [])
      .map(m => (m.email || '').toLowerCase())
      .filter(Boolean);

    return effectiveUserEmail
      ? [...new Set([effectiveUserEmail.toLowerCase(), ...hierarchyEmails])]
      : [...new Set(hierarchyEmails)];
  }, [teamEmailsOverride, hierarchyTeamMembers, effectiveUserEmail]);

  const weekDates = useMemo(() => {
    const now = new Date();
    // If custom range provided, use it; otherwise default to current week
    const thisWeekStart = customDateRange?.from || startOfWeek(now, { weekStartsOn: 1 });
    const thisWeekEnd = customDateRange?.to || endOfWeek(now, { weekStartsOn: 1 });
    const rangeDays = Math.max(1, Math.round((thisWeekEnd.getTime() - thisWeekStart.getTime()) / (1000 * 60 * 60 * 24)));
    // "Previous period" is same-length window immediately before
    const lastWeekStart = subDays(thisWeekStart, rangeDays);
    const lastWeekEnd = subDays(thisWeekStart, 1);
    const fourWeeksAgo = subWeeks(thisWeekStart, 4);
    const weekKey = `${format(thisWeekStart, 'yyyy-MM-dd')}_${format(thisWeekEnd, 'yyyy-MM-dd')}`;
    return { thisWeekStart, thisWeekEnd, lastWeekStart, lastWeekEnd, fourWeeksAgo, weekKey };
  }, [customDateRange?.from?.getTime(), customDateRange?.to?.getTime()]);

  const { thisWeekStart, thisWeekEnd, lastWeekStart, lastWeekEnd, fourWeeksAgo } = weekDates;

  const { data: summaryData, isLoading: dataLoading } = useQuery({
    queryKey: ['exec-weekly-summary', teamHierarchyEmailsWithSelf, weekDates.weekKey],
    queryFn: async () => {
      if (teamHierarchyEmailsWithSelf.length === 0) return null;

      const teamEmailSet = new Set(teamHierarchyEmailsWithSelf.map(e => e.toLowerCase()));

      const emailFilters = teamHierarchyEmailsWithSelf
        .map(email => `owner_email.eq.${email},primary_se_email.eq.${email}`)
        .join(',');

      const normalizeEmail = (value: unknown): string =>
        typeof value === 'string' ? value.toLowerCase().trim() : '';

      const getAttendeeEmails = (attendees: unknown): string[] => {
        if (!Array.isArray(attendees)) return [];
        return attendees
          .map((attendee: any) => {
            if (typeof attendee === 'string') return normalizeEmail(attendee);
            return normalizeEmail(attendee?.email || attendee?.attendee_email || attendee?.address);
          })
          .filter(Boolean);
      };

      // ──────────────────────────────────────────────
      // 1. MEETINGS ATTENDED + TEAM OPP CONTEXT
      // ──────────────────────────────────────────────
      const [
        teamOppAssignments,
        teamOppsByEmail,
        thisWeekMeetings,
        lastWeekMeetings,
        fourWeekMeetings,
        thisWeekManual,
        lastWeekManual,
      ] = await Promise.all([
        gateway.from('opportunity_team_members')
          .select('opportunity_id')
          .in('team_member_email', teamHierarchyEmailsWithSelf)
          .execute(),
        gateway.from('opportunities')
          .select('id, salesforce_opportunity_id')
          .eq('is_archived', false)
          .or(emailFilters)
          .execute(),
        gateway.from('momentum_meetings')
          .select('id, host_email, attendees, start_time, end_time, opportunity_id, salesforce_opportunity_id')
          .gte('start_time', thisWeekStart.toISOString())
          .lte('start_time', thisWeekEnd.toISOString())
          .eq('status', 'imported')
          .limit(1000)
          .execute(),
        gateway.from('momentum_meetings')
          .select('id, host_email, attendees, start_time, end_time, opportunity_id, salesforce_opportunity_id')
          .gte('start_time', lastWeekStart.toISOString())
          .lte('start_time', lastWeekEnd.toISOString())
          .eq('status', 'imported')
          .limit(1000)
          .execute(),
        gateway.from('momentum_meetings')
          .select('id, host_email, attendees, start_time, end_time, opportunity_id, salesforce_opportunity_id')
          .gte('start_time', fourWeeksAgo.toISOString())
          .lt('start_time', thisWeekStart.toISOString())
          .eq('status', 'imported')
          .limit(2000)
          .execute(),
        gateway.from('momentum_meetings')
          .select('id, host_email, attendees, start_time, notes, is_highlighted, manual_meeting_type, opportunity_id, matched_account_id, meeting_context, opportunities:opportunity_id(id, name, value, accounts:account_id(id, name)), accounts:matched_account_id(id, name)')
          .eq('meeting_context', 'manual')
          .gte('start_time', thisWeekStart.toISOString())
          .lte('start_time', thisWeekEnd.toISOString())
          .execute(),
        gateway.from('momentum_meetings')
          .select('id, host_email, attendees, start_time')
          .eq('meeting_context', 'manual')
          .gte('start_time', lastWeekStart.toISOString())
          .lte('start_time', lastWeekEnd.toISOString())
          .execute(),
      ]);

      const assignedOppIds = [...new Set((teamOppAssignments.data || []).map((row: any) => row.opportunity_id).filter(Boolean))];
      const teamOppsByAssignment = assignedOppIds.length > 0
        ? await gateway.from('opportunities')
            .select('id, salesforce_opportunity_id')
            .eq('is_archived', false)
            .in('id', assignedOppIds)
            .execute()
        : { data: [] as any[] };

      const teamOppIdSet = new Set<string>();
      const teamOppBySalesforceId = new Map<string, string>();
      for (const opp of [...(teamOppsByEmail.data || []), ...(teamOppsByAssignment.data || [])]) {
        if (!opp?.id) continue;
        teamOppIdSet.add(opp.id);
        const sfId = typeof opp.salesforce_opportunity_id === 'string' ? opp.salesforce_opportunity_id.trim() : '';
        if (sfId) teamOppBySalesforceId.set(sfId, opp.id);
      }

      const resolveTeamOppIdFromMeeting = (meeting: any): string | null => {
        if (meeting?.opportunity_id && teamOppIdSet.has(meeting.opportunity_id)) return meeting.opportunity_id;
        const sfId = typeof meeting?.salesforce_opportunity_id === 'string' ? meeting.salesforce_opportunity_id.trim() : '';
        return sfId ? teamOppBySalesforceId.get(sfId) || null : null;
      };

      const hasTeamAttendance = (meeting: any): boolean => {
        const host = normalizeEmail(meeting?.host_email);
        if (host && teamEmailSet.has(host)) return true;
        return getAttendeeEmails(meeting?.attendees).some(email => teamEmailSet.has(email));
      };

      const countUniqueTeamMeetings = (meetings: any[]): number => {
        const ids = new Set<string>();
        for (const meeting of meetings) {
          if (!meeting?.id) continue;
          if (hasTeamAttendance(meeting) || resolveTeamOppIdFromMeeting(meeting)) ids.add(meeting.id);
        }
        return ids.size;
      };

      const thisWeekMeetingRows = thisWeekMeetings.data || [];
      const thisWeekTeamMeetingIds = new Set<string>();
      const meetingLinkedOppIds = new Set<string>();

      for (const meeting of thisWeekMeetingRows) {
        if (!meeting?.id) continue;
        const linkedOppId = resolveTeamOppIdFromMeeting(meeting);
        if (linkedOppId) meetingLinkedOppIds.add(linkedOppId);
        if (hasTeamAttendance(meeting) || linkedOppId) thisWeekTeamMeetingIds.add(meeting.id);
      }

      const thisWeekMeetingIds = thisWeekMeetingRows.map((meeting: any) => meeting.id).filter(Boolean);
      if (thisWeekMeetingIds.length > 0) {
        for (let i = 0; i < thisWeekMeetingIds.length; i += 100) {
          const chunk = thisWeekMeetingIds.slice(i, i + 100);
          const { data: trData } = await supabase
            .from('transcript_reviews')
            .select('opportunity_id, momentum_meeting_id')
            .in('momentum_meeting_id', chunk)
            .not('opportunity_id', 'is', null);

          for (const tr of (trData || [])) {
            if (!tr?.opportunity_id || !tr?.momentum_meeting_id) continue;
            if (teamOppIdSet.has(tr.opportunity_id)) {
              thisWeekTeamMeetingIds.add(tr.momentum_meeting_id);
              meetingLinkedOppIds.add(tr.opportunity_id);
            }
          }
        }
      }

      const thisWeekMeetingCount = thisWeekTeamMeetingIds.size;
      const lastWeekMeetingCount = countUniqueTeamMeetings(lastWeekMeetings.data || []);
      const fourWeekMeetingAvg = Math.round(countUniqueTeamMeetings(fourWeekMeetings.data || []) / 4);

      // ── MANUAL MEETINGS (unrecorded onsites, etc.) ──
      const MEETING_TYPE_LABELS: Record<string, string> = {
        client_onsite: 'Client Onsite',
        executive_briefing: 'Executive Briefing',
        workshop_offsite: 'Workshop / Offsite',
        conference_meeting: 'Conference Meeting',
        internal_strategy: 'Internal Strategy Session',
        unrecorded_call: 'Unrecorded Call',
        other: 'Other',
      };
      const HIGHLIGHTED_TYPES = new Set(['client_onsite', 'executive_briefing', 'workshop_offsite', 'conference_meeting']);

      const teamUserIdSet = new Set<string>([
        effectiveUserId,
        ...(hierarchyTeamMembers || []).map(member => member.user_id),
      ].filter(Boolean) as string[]);

      const isTeamManualMeeting = (meeting: any): boolean => {
        const hostEmail = normalizeEmail(meeting?.host_email);
        if (hostEmail && teamEmailSet.has(hostEmail)) return true;
        const attendeeEmails = getAttendeeEmails(meeting?.attendees);
        return attendeeEmails.some((email: string) => teamEmailSet.has(email));
      };

      const thisWeekTeamManual = (thisWeekManual.data || []).filter(isTeamManualMeeting);
      const lastWeekTeamManual = (lastWeekManual.data || []).filter(isTeamManualMeeting);

      const thisWeekManualCount = thisWeekTeamManual.length;
      const lastWeekManualCount = lastWeekTeamManual.length;

      const notableActivities: NotableActivity[] = thisWeekTeamManual
        .filter((meeting: any) => meeting.manual_meeting_type === 'client_onsite')
        .map((meeting: any) => ({
          id: meeting.id,
          meetingType: meeting.manual_meeting_type || 'other',
          meetingTypeLabel: MEETING_TYPE_LABELS[meeting.manual_meeting_type] || meeting.manual_meeting_type || 'Other',
          meetingDate: meeting.start_time,
          opportunityName: meeting.opportunities?.name || null,
          accountName: (meeting.opportunities?.accounts as any)?.name || (meeting.accounts as any)?.name || null,
          value: meeting.opportunities?.value || null,
          attendeeEmails: getAttendeeEmails(meeting.attendees),
          notes: meeting.notes,
        }));

      const totalThisWeekMeetings = thisWeekMeetingCount + thisWeekManualCount;
      const totalLastWeekMeetings = lastWeekMeetingCount + lastWeekManualCount;

      // ──────────────────────────────────────────────
      // 1b. MEETING-LINKED PIPELINE
      // ──────────────────────────────────────────────
      const PRE_EVAL_STAGES = ['discovery', 'demo'];
      const EVAL_AND_ABOVE_STAGES = ['proof - scoping', 'proof', 'technical win'];

      // Build sibling account map: accounts sharing the same 15-char SFDC ID prefix
      // This lets manual meetings on a truncated-SFDC-ID account resolve to opportunities on the full-SFDC-ID account
      const manualAccountIds = [...new Set(thisWeekTeamManual
        .filter((m: any) => m.matched_account_id && !m.opportunity_id)
        .map((m: any) => m.matched_account_id))];

      const siblingAccountMap = new Map<string, string[]>(); // accountId -> [siblingAccountIds]
      if (manualAccountIds.length > 0) {
        const { data: accountsWithSfid } = await supabase
          .from('accounts')
          .select('id, salesforce_account_id')
          .not('salesforce_account_id', 'is', null);

        const sfidPrefixMap = new Map<string, string[]>(); // 15-char prefix -> [accountIds]
        for (const acc of (accountsWithSfid || [])) {
          if (!acc.salesforce_account_id) continue;
          const prefix = acc.salesforce_account_id.toUpperCase().slice(0, 15);
          if (!sfidPrefixMap.has(prefix)) sfidPrefixMap.set(prefix, []);
          sfidPrefixMap.get(prefix)!.push(acc.id);
        }
        for (const group of sfidPrefixMap.values()) {
          if (group.length > 1) {
            for (const id of group) {
              siblingAccountMap.set(id, group.filter(g => g !== id));
            }
          }
        }
      }

      for (const meeting of thisWeekTeamManual) {
        if (meeting?.opportunity_id && teamOppIdSet.has(meeting.opportunity_id)) {
          meetingLinkedOppIds.add(meeting.opportunity_id);
        }
      }

      // For account-only manual meetings, try to resolve to opportunities on the same or sibling account
      if (manualAccountIds.length > 0) {
        const allRelatedAccountIds: string[] = [...new Set<string>([
          ...manualAccountIds as string[],
          ...(manualAccountIds as string[]).flatMap((id: string) => siblingAccountMap.get(id) || []),
        ])];
        const { data: relatedOpps } = await supabase
          .from('opportunities')
          .select('id, account_id')
          .in('account_id', allRelatedAccountIds as string[])
          .eq('is_archived', false);

        const oppsByAccountId = new Map<string, string[]>();
        for (const opp of (relatedOpps || [])) {
          if (!oppsByAccountId.has(opp.account_id)) oppsByAccountId.set(opp.account_id, []);
          oppsByAccountId.get(opp.account_id)!.push(opp.id);
        }

        for (const meeting of thisWeekTeamManual) {
          if (meeting?.opportunity_id || !meeting?.matched_account_id) continue;
          // Check own account and siblings for opportunities
          const accountsToCheck = [meeting.matched_account_id, ...(siblingAccountMap.get(meeting.matched_account_id) || [])];
          for (const accId of accountsToCheck) {
            const oppIds = oppsByAccountId.get(accId) || [];
            for (const oppId of oppIds) {
              meetingLinkedOppIds.add(oppId);
            }
            if (oppIds.length > 0) break;
          }
        }
      }

      const meetingOppIdsArray = Array.from(meetingLinkedOppIds);
      let meetingLinkedPipelineValue = 0;
      let meetingLinkedOppCount = 0;
      let preEvalPipelineValue = 0;
      let preEvalOppCount = 0;
      let evalStagePipelineValue = 0;
      let evalStageOppCount = 0;

      let topMeetingLinkedOpps: TopMeetingOpp[] = [];

      if (meetingOppIdsArray.length > 0) {
        const meetingOppsResult = await gateway.from('opportunities')
          .select('id, name, value, pre_sales_stage, is_archived, accounts(name)')
          .in('id', meetingOppIdsArray)
          .eq('is_archived', false)
          .execute();

        const resolvedMeetingOpps = meetingOppsResult.data || [];
        meetingLinkedOppCount = resolvedMeetingOpps.length;

        for (const opp of resolvedMeetingOpps) {
          const oppValue = opp.value || 0;
          meetingLinkedPipelineValue += oppValue;

          const preSalesLower = (opp.pre_sales_stage || '').toLowerCase();
          if (PRE_EVAL_STAGES.includes(preSalesLower)) {
            preEvalPipelineValue += oppValue;
            preEvalOppCount++;
          } else if (EVAL_AND_ABOVE_STAGES.includes(preSalesLower)) {
            evalStagePipelineValue += oppValue;
            evalStageOppCount++;
          }
        }

        // Top 5 opps by revenue
        topMeetingLinkedOpps = resolvedMeetingOpps
          .filter((o: any) => (o.value || 0) > 0)
          .sort((a: any, b: any) => (b.value || 0) - (a.value || 0))
          .slice(0, 5)
          .map((o: any) => ({
            id: o.id,
            name: o.name || 'Unnamed',
            accountName: (o as any).accounts?.name || null,
            value: o.value || 0,
          }));
      }

      // WoW meeting delta
      const meetingWoWDelta = totalLastWeekMeetings > 0
        ? Math.round(((totalThisWeekMeetings - totalLastWeekMeetings) / totalLastWeekMeetings) * 100)
        : totalThisWeekMeetings > 0 ? 100 : null;

      // ──────────────────────────────────────────────
      // 2. COACHING SCORE (already 0–5 scale, no conversion needed)
      //    Same source as SECoachingTab: se_coaching_scores filtered by team emails
      // ──────────────────────────────────────────────
      const bestCallFields = 'se_email, overall_score, created_at, meeting_date, opportunity_id, account_id, greatness_moment, what_worked_well, questioning_score, questioning_evidence, pov_challenge_score, pov_challenge_evidence, value_anchoring_score, value_anchoring_evidence, differentiation_score, differentiation_evidence, storytelling_proof_score, storytelling_proof_evidence, pain_quantification_score, pain_quantification_evidence, strategy_rigor_score, strategy_rigor_evidence, reverse_demo_score, reverse_demo_evidence, ownership_control_score, ownership_control_evidence, technical_competency_score, technical_competency_evidence, objection_handling_score, objection_handling_evidence, champion_arming_score, champion_arming_evidence';
      const [thisWeekCoaching, lastWeekCoaching, fourWeekCoaching] = await Promise.all([
        gateway.from('se_coaching_scores')
          .select(bestCallFields)
          .gte('created_at', thisWeekStart.toISOString())
          .lte('created_at', thisWeekEnd.toISOString())
          .in('se_email', teamHierarchyEmailsWithSelf)
          .execute(),
        gateway.from('se_coaching_scores')
          .select('se_email, overall_score, created_at')
          .gte('created_at', lastWeekStart.toISOString())
          .lte('created_at', lastWeekEnd.toISOString())
          .in('se_email', teamHierarchyEmailsWithSelf)
          .execute(),
        gateway.from('se_coaching_scores')
          .select('se_email, overall_score, created_at')
          .gte('created_at', fourWeeksAgo.toISOString())
          .lt('created_at', thisWeekStart.toISOString())
          .in('se_email', teamHierarchyEmailsWithSelf)
          .execute(),
      ]);

      // Scores are already on a 0–5 scale; just round to 1dp
      // Filter out scores <= 1.0 which are fallback/error values from failed analyses
      const roundTo1dp = (v: number) => Math.round(v * 10) / 10;

      const avgScore = (items: any[]) => {
        const scores = items?.filter((i: any) => i.overall_score != null && i.overall_score > 1.0).map((i: any) => i.overall_score) || [];
        if (scores.length === 0) return 0;
        return roundTo1dp(scores.reduce((a: number, b: number) => a + b, 0) / scores.length);
      };

      const thisWeekAvgCoaching = avgScore(thisWeekCoaching.data || []);
      const lastWeekAvgCoaching = avgScore(lastWeekCoaching.data || []);
      const fourWeekAvgCoaching = avgScore(fourWeekCoaching.data || []);

      // Coaching improvers: per-SE average this week vs last week
      // Filter out error-floor scores (<=1.0) consistent with avgScore logic
      const seScoresThisWeek = new Map<string, number[]>();
      const seScoresLastWeek = new Map<string, number[]>();
      (thisWeekCoaching.data || []).forEach((s: any) => {
        if (s.overall_score != null && s.overall_score > 1.0 && s.se_email && teamEmailSet.has(s.se_email.toLowerCase())) {
          const key = s.se_email.toLowerCase();
          if (!seScoresThisWeek.has(key)) seScoresThisWeek.set(key, []);
          seScoresThisWeek.get(key)!.push(s.overall_score);
        }
      });
      (lastWeekCoaching.data || []).forEach((s: any) => {
        if (s.overall_score != null && s.overall_score > 1.0 && s.se_email && teamEmailSet.has(s.se_email.toLowerCase())) {
          const key = s.se_email.toLowerCase();
          if (!seScoresLastWeek.has(key)) seScoresLastWeek.set(key, []);
          seScoresLastWeek.get(key)!.push(s.overall_score);
        }
      });

      const improvers: { name: string; delta: number }[] = [];
      seScoresThisWeek.forEach((scores, email) => {
        const thisAvg = scores.reduce((a, b) => a + b, 0) / scores.length;
        const lastScores = seScoresLastWeek.get(email);
        if (lastScores?.length) {
          const lastAvg = lastScores.reduce((a, b) => a + b, 0) / lastScores.length;
          const delta = roundTo1dp(thisAvg - lastAvg);
          if (delta > 0) improvers.push({ name: email, delta });
        }
      });
      improvers.sort((a, b) => b.delta - a.delta);

      // ── BEST CALL OF THE PERIOD ──
      const DIMENSION_KEYS = [
        { key: 'questioning', label: 'Questioning (Discovery Quality)' },
        { key: 'pov_challenge', label: 'POV & Challenge (Executive Framing)' },
        { key: 'value_anchoring', label: 'Value Anchoring (PBO Clarity)' },
        { key: 'differentiation', label: 'Differentiation' },
        { key: 'storytelling_proof', label: 'Storytelling & Proof (Use Case Alignment)' },
        { key: 'pain_quantification', label: 'Pain Quantification (Negative Consequence)' },
        { key: 'strategy_rigor', label: 'Strategy & Rigor (Account Context)' },
        { key: 'reverse_demo', label: 'Reverse Demo' },
        { key: 'ownership_control', label: 'Ownership & Control (Story Flow)' },
        { key: 'technical_competency', label: 'Technical Competency (Confidence & Delivery)' },
        { key: 'objection_handling', label: 'Objection Handling' },
        { key: 'champion_arming', label: 'Champion Arming' },
      ];

      let bestCall: BestCallHighlight | null = null;
      const validCoachingRows = (thisWeekCoaching.data || []).filter((s: any) => s.overall_score != null && s.overall_score > 1.0);
      if (validCoachingRows.length > 0) {
        const best = validCoachingRows.reduce((top: any, curr: any) =>
          (curr.overall_score > top.overall_score) ? curr : top
        );

        let bestOppName: string | null = null;
        let bestAccountName: string | null = null;
        if (best.opportunity_id) {
          const oppResult = await gateway.from('opportunities')
            .select('name, accounts(name)')
            .eq('id', best.opportunity_id)
            .maybeSingle()
            .execute();
          if (oppResult.data) {
            bestOppName = oppResult.data.name;
            bestAccountName = (oppResult.data as any).accounts?.name || null;
          }
        } else if (best.account_id) {
          const accResult = await gateway.from('accounts')
            .select('name')
            .eq('id', best.account_id)
            .maybeSingle()
            .execute();
          bestAccountName = accResult.data?.name || null;
        }

        const conciseEvidence = (raw: unknown): string | null => {
          if (typeof raw !== 'string') return null;
          const cleaned = raw
            .replace(/\[[^\]]+\]:\s*/g, '')
            .replace(/\s+/g, ' ')
            .trim();
          if (!cleaned) return null;
          // Take enough sentences to reach at least 80 chars, up to 200 max
          const sentences = cleaned.split(/(?<=[.!?])\s+/);
          let result = '';
          for (const s of sentences) {
            if (result.length >= 80) break;
            result += (result ? ' ' : '') + s;
          }
          if (!result) result = cleaned;
          return result.length > 200 ? `${result.slice(0, 199).trimEnd()}…` : result;
        };

        const topDimsDetailed = DIMENSION_KEYS
          .map(d => ({
            key: d.key,
            name: d.label,
            score: best[`${d.key}_score`] as number || 0,
            evidence: conciseEvidence(best[`${d.key}_evidence`]),
          }))
          .filter(d => d.score >= 4.0)
          .sort((a, b) => b.score - a.score)
          .slice(0, 4);

        const topDims = topDimsDetailed.map(({ name, score, evidence }) => ({ name, score, evidence }));

        const wwwRaw = best.what_worked_well;
        const whatWorkedWell: string[] = Array.isArray(wwwRaw)
          ? wwwRaw
              .map((item: any) => {
                if (typeof item === 'string') return item;
                return item?.explanation || item?.point || item?.description || item?.snippet || '';
              })
              .filter(Boolean)
              .map((text: string) => text.replace(/\s+/g, ' ').trim())
              .slice(0, 4)
          : [];

        const dimensionPlaybooks: Record<string, { steps: string[]; why: string }> = {
          questioning: { steps: ['Start with 2 diagnostic questions', 'Mirror back the customer constraint', 'Confirm success metric before solutioning'], why: 'Deep discovery uncovers the real problem — without it, solutions feel generic and lose urgency.' },
          pov_challenge: { steps: ['State executive problem in one line', 'Quantify downside of status quo', 'Frame a clear decision path'], why: 'Executives fund problems, not features — a sharp challenge creates urgency and executive sponsorship.' },
          value_anchoring: { steps: ['Set current-state baseline', 'Attach value to one business metric', 'Validate metric owner and timeline'], why: 'Tying value to a measurable outcome gives the champion internal ammunition to justify the investment.' },
          storytelling_proof: { steps: ['Use a similar customer story', 'Show before/after business outcome', 'Connect proof back to this account'], why: 'Social proof reduces perceived risk and makes the outcome feel achievable for the buyer.' },
          technical_competency: { steps: ['Clarify architecture boundaries', 'Address risk/compliance concerns directly', 'Confirm understanding and agreement'], why: 'Technical credibility builds trust — without it, evaluators escalate concerns that stall deals.' },
          objection_handling: { steps: ['Acknowledge objection neutrally', 'Isolate the root concern', 'Respond with proof and confirm resolution'], why: 'Unresolved objections become silent deal-killers — structured handling converts blockers into confidence.' },
          differentiation: { steps: ['Identify competitor weakness in context', 'Contrast with your unique capability', 'Validate with a proof point'], why: 'Clear differentiation stops feature-by-feature comparisons and reframes the evaluation criteria in your favour.' },
          pain_quantification: { steps: ['Ask for the cost of the current problem', 'Quantify in time, money, or risk', 'Reflect the number back to the buyer'], why: 'Quantified pain creates urgency — abstract problems get deprioritised, measured ones get funded.' },
          strategy_rigor: { steps: ['Map the account landscape before the call', 'Align talking points to known priorities', 'Reference prior commitments'], why: 'Preparation signals respect for the buyer\'s time and ensures every interaction moves the deal forward.' },
          ownership_control: { steps: ['Set the agenda and confirm outcomes upfront', 'Manage time and redirect tangents', 'Lock in next steps before ending'], why: 'Controlling the flow prevents drift — calls without clear next steps rarely convert to pipeline progress.' },
          champion_arming: { steps: ['Equip the champion with internal talking points', 'Provide shareable proof assets', 'Align on internal meeting strategy'], why: 'Your champion sells when you\'re not in the room — arming them well multiplies your influence.' },
          reverse_demo: { steps: ['Ask the customer to show their current workflow', 'Identify friction points live', 'Connect gaps to your solution'], why: 'Seeing the customer\'s reality reveals pain they can\'t articulate and makes your demo hyper-relevant.' },
        };

        const defaultPlaybook = { steps: ['Set context and desired outcome', 'Use a proof point tied to customer priorities', 'Confirm next action and owner'], why: 'A structured approach ensures consistency and lets managers coach to a repeatable standard.' };

        const compact = (value: string, max = 110): string =>
          value.length > max ? `${value.slice(0, max - 1).trimEnd()}…` : value;

        const replicablePlaybookFromDims: ReplicablePlay[] = topDimsDetailed.map((dim) => {
          const pb = dimensionPlaybooks[dim.key] || defaultPlaybook;
          const cueSource = whatWorkedWell.find((point) => point.toLowerCase().includes(dim.name.split(' ')[0].toLowerCase()))
            || dim.evidence
            || 'Debrief this structure in weekly call reviews.';

          return {
            approach: dim.name,
            howToReplicate: `Process: ${pb.steps.join(' → ')}. Coach cue: ${compact(cueSource)}`,
            whyItMatters: pb.why,
          };
        });

        const fallbackPlaybook: ReplicablePlay[] = whatWorkedWell.map((point) => ({
          approach: 'Coachable Talk Track',
          howToReplicate: `Process: Set context → Anchor value → Confirm next step. Coach cue: ${compact(point)}`,
          whyItMatters: defaultPlaybook.why,
        }));

        const replicablePlaybook = (replicablePlaybookFromDims.length > 0 ? replicablePlaybookFromDims : fallbackPlaybook).slice(0, 4);

        bestCall = {
          seEmail: best.se_email,
          overallScore: roundTo1dp(best.overall_score),
          meetingDate: best.meeting_date,
          opportunityName: bestOppName,
          accountName: bestAccountName,
          greatnessMoment: best.greatness_moment,
          whatWorkedWell: whatWorkedWell.slice(0, 4),
          replicablePlaybook,
          topDimensions: topDims,
        };
      }

      // ──────────────────────────────────────────────
      // 3. EVAL ACTIVITY
      //    Counts actual eval activities on team opps:
      //    - Milestone status/date changes
      //    - Validation task status/date changes or completions
      //    - NBA status changes or completions on team opps
      //    - Stage changes on team opps
      // ──────────────────────────────────────────────

      // Fetch team opportunities for filtering
      const teamOpps = await gateway.from('opportunities')
        .select('id, name, value, accounts(name)')
        .eq('is_archived', false)
        .or(emailFilters)
        .execute();
      
      const teamOppIds = new Set((teamOpps.data || []).map((o: any) => o.id));
      const oppMap = new Map((teamOpps.data || []).map((o: any) => [o.id, o]));
      const teamOppIdsArray = Array.from(teamOppIds);

      // Fetch AI situation reports for team opportunities
      const oppSummariesResult = teamOppIdsArray.length > 0
        ? await gateway.from('opportunity_summaries')
            .select('opportunity_id, one_liner, next_critical_action, generated_at')
            .in('opportunity_id', teamOppIdsArray.slice(0, 200))
            .execute()
        : { data: [] };

      const situationReports: OpportunitySituationReport[] = (oppSummariesResult.data || []).map((s: any) => {
        const opp = oppMap.get(s.opportunity_id) as any;
        return {
          opportunityId: s.opportunity_id,
          opportunityName: opp?.name || 'Unknown',
          accountName: opp?.accounts?.name || 'Unknown',
          oneLiner: s.one_liner,
          nextCriticalAction: s.next_critical_action,
          generatedAt: s.generated_at,
        };
      });

      // Fetch all eval activity sources in parallel
      const [
        thisWeekStageChanges, lastWeekStageChanges,
        thisWeekMilestoneChanges, lastWeekMilestoneChanges,
        thisWeekValidationChanges, lastWeekValidationChanges,
        thisWeekNBAChanges, lastWeekNBAChanges,
      ] = await Promise.all([
        // Stage changes
        gateway.from('opportunity_stage_history')
          .select('opportunity_id, old_value, new_value, changed_at, stage_type')
          .gte('changed_at', thisWeekStart.toISOString())
          .lte('changed_at', thisWeekEnd.toISOString())
          .execute(),
        gateway.from('opportunity_stage_history')
          .select('opportunity_id')
          .gte('changed_at', lastWeekStart.toISOString())
          .lte('changed_at', lastWeekEnd.toISOString())
          .execute(),
        // Milestone changes (status or date changes)
        gateway.from('milestone_history')
          .select('opportunity_id')
          .gte('changed_at', thisWeekStart.toISOString())
          .lte('changed_at', thisWeekEnd.toISOString())
          .execute(),
        gateway.from('milestone_history')
          .select('opportunity_id')
          .gte('changed_at', lastWeekStart.toISOString())
          .lte('changed_at', lastWeekEnd.toISOString())
          .execute(),
        // Validation task changes (status or date changes, completions)
        gateway.from('validation_task_history')
          .select('opportunity_id')
          .gte('changed_at', thisWeekStart.toISOString())
          .lte('changed_at', thisWeekEnd.toISOString())
          .execute(),
        gateway.from('validation_task_history')
          .select('opportunity_id')
          .gte('changed_at', lastWeekStart.toISOString())
          .lte('changed_at', lastWeekEnd.toISOString())
          .execute(),
        // NBA status changes/completions on team opps
        gateway.from('nba_completion_history')
          .select('opportunity_id')
          .gte('changed_at', thisWeekStart.toISOString())
          .lte('changed_at', thisWeekEnd.toISOString())
          .execute(),
        gateway.from('nba_completion_history')
          .select('opportunity_id')
          .gte('changed_at', lastWeekStart.toISOString())
          .lte('changed_at', lastWeekEnd.toISOString())
          .execute(),
      ]);

      // Count all eval activities on team opps (total events, not unique opps)
      const countTeamActivities = (...sources: any[]): number => {
        return sources.reduce((total, source) => {
          return total + (source.data || []).filter((r: any) => 
            r.opportunity_id && teamOppIds.has(r.opportunity_id)
          ).length;
        }, 0);
      };

      const thisWeekEvalActivity = countTeamActivities(
        thisWeekStageChanges, thisWeekMilestoneChanges, 
        thisWeekValidationChanges, thisWeekNBAChanges
      );
      const lastWeekEvalActivity = countTeamActivities(
        lastWeekStageChanges, lastWeekMilestoneChanges,
        lastWeekValidationChanges, lastWeekNBAChanges
      );

      // Build deal movements from stage changes (for the deal movements card)
      const dealMovements: DealMovement[] = (thisWeekStageChanges.data || [])
        .filter((h: any) => teamOppIds.has(h.opportunity_id))
        .map((h: any) => {
          const opp = oppMap.get(h.opportunity_id) as any;
          return {
            opportunityId: h.opportunity_id,
            opportunityName: opp?.name || 'Unknown',
            accountName: (opp?.accounts as any)?.name || 'Unknown',
            oldStage: h.old_value,
            newStage: h.new_value,
            value: opp?.value as number | null,
            movedAt: h.changed_at,
          };
        });

      // ── Categorise stage movements ──
      const TERMINAL_WON = ['closed_won', 'stage_5_sales_won', 'stage_6_closed_won'];
      const TERMINAL_LOST = ['closed_lost', 'stage_7_closed_lost', 'disqualified', 'closed_shifted', 'closed_cancelled_shift', 'CRM_DISQUALIFIED', 'CRM_OTHER'];
      const STAGE_ORDER_LIST = ['Discovery', 'Demo', 'Proof - Scoping', 'Proof', 'Technical Win'];

      const stageIndex = (s: string | null): number => {
        if (!s) return -1;
        const idx = STAGE_ORDER_LIST.findIndex(st => st.toLowerCase() === s.toLowerCase());
        return idx;
      };

      const closedWonMap = new Map<string, DealMovement>();
      const closedLostMap = new Map<string, DealMovement>();
      const regressionMap = new Map<string, DealMovement>();
      let forwardCount = 0;
      const seenForward = new Set<string>();

      for (const dm of dealMovements) {
        const newLower = (dm.newStage || '').toLowerCase();
        const oldLower = (dm.oldStage || '').toLowerCase();
        // Skip deduplicated deals: old stage was already terminal (merge artifact)
        const oldWasTerminal = [...TERMINAL_WON, ...TERMINAL_LOST].some(t => t.toLowerCase() === oldLower);
        if (TERMINAL_WON.some(t => t.toLowerCase() === newLower) && !oldWasTerminal) {
          closedWonMap.set(dm.opportunityId, dm);
        } else if (TERMINAL_LOST.some(t => t.toLowerCase() === newLower) && !oldWasTerminal) {
          closedLostMap.set(dm.opportunityId, dm);
        } else {
          const oldIdx = stageIndex(dm.oldStage);
          const newIdx = stageIndex(dm.newStage);
          if (oldIdx >= 0 && newIdx >= 0 && newIdx < oldIdx) {
            regressionMap.set(dm.opportunityId, dm);
          } else if (!seenForward.has(dm.opportunityId)) {
            seenForward.add(dm.opportunityId);
            forwardCount++;
          }
        }
      }

      const stageMovementSummary: StageMovementSummary = {
        forwardCount,
        closedWon: Array.from(closedWonMap.values()),
        closedLost: Array.from(closedLostMap.values()),
        regressions: Array.from(regressionMap.values()),
        totalMovements: dealMovements.length,
      };
      // 4. ACTIONS COMPLETED (scoped to team via assigned_to)
      // ──────────────────────────────────────────────
      const [thisWeekNBAs, lastWeekNBAs] = await Promise.all([
        gateway.from('account_nbas')
          .select('id')
          .gte('completed_at', thisWeekStart.toISOString())
          .lte('completed_at', thisWeekEnd.toISOString())
          .eq('status', 'completed')
          .in('assigned_to', teamHierarchyEmailsWithSelf)
          .execute(),
        gateway.from('account_nbas')
          .select('id')
          .gte('completed_at', lastWeekStart.toISOString())
          .lte('completed_at', lastWeekEnd.toISOString())
          .eq('status', 'completed')
          .in('assigned_to', teamHierarchyEmailsWithSelf)
          .execute(),
      ]);

      // ──────────────────────────────────────────────
      // 5. EVAL PHASE DISTRIBUTION (revenue in motion)
      //    Mirror the Evaluation Radar logic exactly:
      //    - Include team opps + any opp with eval_phase_override
      //    - Use same computePhase: evalEnd→completed, evalQuote+evalStart→running,
      //      evalQuote→deploying, milestones→running/planning, signals/stages→planning
      //    - Exclude dismissed opps
      // ──────────────────────────────────────────────
      const PROOF_SCOPING_AND_ABOVE = [
        'proof - scoping', 'proof', 'technical win', 'technical loss',
        'pending_compliance',
      ];

      const evalFields = `id, name, value, sales_stage, pre_sales_stage, is_archived,
        eval_phase_override, eval_radar_dismissed, eval_type, eval_start_date, eval_end_date,
        primary_eval_quote, owner_email, primary_se_email`;

      // Fetch team opps + override opps in parallel (same as Eval Radar)
      const [teamEvalOpps, overrideEvalOpps] = await Promise.all([
        gateway.from('opportunities')
          .select(evalFields)
          .eq('is_archived', false)
          .or(emailFilters)
          .limit(500)
          .execute(),
        gateway.from('opportunities')
          .select(evalFields)
          .eq('is_archived', false)
          .not('eval_phase_override', 'is', null)
          .limit(200)
          .execute(),
      ]);

      // Merge & deduplicate
      const evalOppMap = new Map<string, any>();
      for (const o of (teamEvalOpps.data || [])) evalOppMap.set(o.id, o);
      for (const o of (overrideEvalOpps.data || [])) evalOppMap.set(o.id, o);
      const allEvalOpps = Array.from(evalOppMap.values());

      // Fetch milestones for these opps
      const evalOppIds = allEvalOpps.map((o: any) => o.id);
      const milestones = evalOppIds.length > 0
        ? await gateway.from('opportunity_milestones')
            .select('opportunity_id, status, scheduled_date, completed_date')
            .in('opportunity_id', evalOppIds)
            .execute()
        : { data: [] };

      const milestoneSummaries: Record<string, { completed: number; withScheduledDate: number }> = {};
      (milestones.data || []).forEach((m: any) => {
        if (!milestoneSummaries[m.opportunity_id]) {
          milestoneSummaries[m.opportunity_id] = { completed: 0, withScheduledDate: 0 };
        }
        if (m.status === 'completed' || m.completed_date) milestoneSummaries[m.opportunity_id].completed++;
        if (m.scheduled_date) milestoneSummaries[m.opportunity_id].withScheduledDate++;
      });

      // Check for detection signals
      const EVAL_SIGNAL_RULE_IDS = [
        'a1111111-1111-1111-1111-111111111111',
        'b2222222-2222-2222-2222-222222222222',
      ];
      const signalMatches = evalOppIds.length > 0
        ? await gateway.from('detection_rule_matches')
            .select('opportunity_id')
            .in('opportunity_id', evalOppIds)
            .in('rule_id', EVAL_SIGNAL_RULE_IDS)
            .execute()
        : { data: [] };
      const oppsWithSignals = new Set((signalMatches.data || []).map((s: any) => s.opportunity_id));

      // Phase computation — same as useEvaluationRadar.computePhase
      const computeEvalPhase = (opp: any): string | null => {
        if (opp.eval_radar_dismissed) return null;

        // Override takes precedence
        if (opp.eval_phase_override) return opp.eval_phase_override;

        const ms = milestoneSummaries[opp.id];

        // Completed: has actual end date in the past
        if (opp.eval_end_date) {
          const end = new Date(opp.eval_end_date);
          if (end <= new Date()) return 'completed';
        }
        // Running: has quote AND actual start date in the past
        if (opp.primary_eval_quote && opp.eval_start_date) {
          const start = new Date(opp.eval_start_date);
          if (start <= new Date()) return 'running';
        }
        // Deploying: has primary eval quote
        if (opp.primary_eval_quote) return 'deploying';

        // Milestones
        if (ms) {
          if (ms.completed > 0) return 'running';
          if (ms.withScheduledDate > 0) return 'planning';
        }
        // Detection signals or pre-sales stage
        if (oppsWithSignals.has(opp.id)) return 'planning';
        if (opp.pre_sales_stage && PROOF_SCOPING_AND_ABOVE.includes(opp.pre_sales_stage.toLowerCase())) {
          return 'planning';
        }

        return null; // Not relevant for eval radar
      };

      // Filter to relevant opps (same criteria as Eval Radar)
      // NOTE: Detection signals are NOT used for relevance — only for phase computation.
      // The Eval Radar filters to relevant opps BEFORE fetching signals, so signals
      // only affect the phase of already-relevant opps, not whether an opp is included.
      const isRelevant = (opp: any): boolean => {
        if (opp.eval_radar_dismissed) return false;
        if (opp.eval_type || opp.primary_eval_quote || opp.eval_start_date || opp.eval_end_date || opp.eval_phase_override) return true;
        if (opp.pre_sales_stage && PROOF_SCOPING_AND_ABOVE.includes(opp.pre_sales_stage.toLowerCase())) return true;
        const ms = milestoneSummaries[opp.id];
        if (ms && (ms.withScheduledDate > 0 || ms.completed > 0)) return true;
        return false;
      };

      const evalCounts: EvalPhaseCounts = { planning: 0, deploying: 0, running: 0, completed: 0 };
      const evalOppsByPhase: Record<string, EvalOppSummary[]> = { planning: [], deploying: [], running: [], completed: [] };
      let revenueInMotion = 0;
      const relevantEvalOppIds: string[] = [];

      allEvalOpps.filter(isRelevant).forEach((opp: any) => {
        const phase = computeEvalPhase(opp);
        if (phase && phase in evalCounts) {
          evalCounts[phase as keyof EvalPhaseCounts]++;
          revenueInMotion += opp.value || 0;
          evalOppsByPhase[phase].push({
            id: opp.id,
            name: opp.name,
            accountName: '', // will resolve below
            value: opp.value,
            primarySeEmail: opp.primary_se_email,
            phase,
          });
          relevantEvalOppIds.push(opp.id);
        }
      });

      // Resolve account names for eval opps (fetch from team opps or re-fetch)
      // We already have oppMap from teamOpps; also fetch accounts for eval opps
      const evalAccountNames = new Map<string, string>();
      const evalAccountIds = new Map<string, string>();
      const evalOppsWithAccounts = await gateway.from('opportunities')
        .select('id, account_id, accounts(name)')
        .in('id', relevantEvalOppIds.length > 0 ? relevantEvalOppIds : ['__none__'])
        .execute();
      (evalOppsWithAccounts.data || []).forEach((o: any) => {
        evalAccountNames.set(o.id, o.accounts?.name || 'Unknown');
        evalAccountIds.set(o.id, o.account_id || '');
      });
      // Fill account names
      Object.values(evalOppsByPhase).forEach(opps => {
        opps.forEach(opp => { opp.accountName = evalAccountNames.get(opp.id) || 'Unknown'; });
      });

      // ──────────────────────────────────────────────
      // 6. RISKS & ISSUES on eval opps
      // ──────────────────────────────────────────────
      const risksAndIssues: RiskIssueSummary[] = [];
      if (relevantEvalOppIds.length > 0) {
        const risksResult = await gateway.from('evaluation_technical_risks')
          .select('id, opportunity_id, risk_description, severity, status, entry_type')
          .in('opportunity_id', relevantEvalOppIds)
          .in('status', ['open', 'new', 'in_review', 'awaiting_feedback', 'accepted'])
          .execute();
        (risksResult.data || []).forEach((r: any) => {
          risksAndIssues.push({
            opportunityId: r.opportunity_id,
            opportunityName: evalOppsByPhase.planning.concat(evalOppsByPhase.deploying, evalOppsByPhase.running, evalOppsByPhase.completed)
              .find(o => o.id === r.opportunity_id)?.name || 'Unknown',
            accountId: evalAccountIds.get(r.opportunity_id) || '',
            accountName: evalAccountNames.get(r.opportunity_id) || 'Unknown',
            entryType: r.entry_type || 'risk',
            severity: r.severity || 'medium',
            description: r.risk_description,
            status: r.status,
          });
        });
      }

      // ──────────────────────────────────────────────
      // BUILD KPIs
      // ──────────────────────────────────────────────
      const kpis: WeeklyKPI[] = [
        {
          label: 'Meetings Attended',
          value: totalThisWeekMeetings,
          previousValue: totalLastWeekMeetings,
          fourWeekAvg: fourWeekMeetingAvg,
          trend: calcTrend(totalThisWeekMeetings, totalLastWeekMeetings),
          trendIsPositive: totalThisWeekMeetings >= totalLastWeekMeetings,
        },
        {
          label: 'Avg Coaching Score',
          value: thisWeekAvgCoaching,
          previousValue: lastWeekAvgCoaching,
          fourWeekAvg: fourWeekAvgCoaching,
          unit: '/5',
          trend: calcTrend(thisWeekAvgCoaching, lastWeekAvgCoaching),
          trendIsPositive: thisWeekAvgCoaching >= lastWeekAvgCoaching,
        },
        {
          label: 'Eval Activity',
          value: thisWeekEvalActivity,
          previousValue: lastWeekEvalActivity,
          fourWeekAvg: 0,
          trend: calcTrend(thisWeekEvalActivity, lastWeekEvalActivity),
          trendIsPositive: true,
        },
        {
          label: 'Actions Completed',
          value: thisWeekNBAs.data?.length || 0,
          previousValue: lastWeekNBAs.data?.length || 0,
          fourWeekAvg: 0,
          trend: calcTrend(thisWeekNBAs.data?.length || 0, lastWeekNBAs.data?.length || 0),
          trendIsPositive: (thisWeekNBAs.data?.length || 0) >= (lastWeekNBAs.data?.length || 0),
        },
      ];

      return {
        weekLabel: `${format(thisWeekStart, 'MMM d')} – ${format(thisWeekEnd, 'MMM d, yyyy')}`,
        weekStart: thisWeekStart.toISOString(),
        weekEnd: thisWeekEnd.toISOString(),
        kpis,
        evalPhaseCounts: evalCounts,
        previousEvalPhaseCounts: { planning: 0, deploying: 0, running: 0, completed: 0 },
        evalOppsByPhase,
        risksAndIssues,
        dealMovements,
        stageMovementSummary,
        totalRevenueInMotion: revenueInMotion,
        previousRevenueInMotion: 0,
        topCoachingImprovers: improvers.slice(0, 3),
        teamSize: teamHierarchyEmailsWithSelf.length,
        notableActivities,
        manualMeetingCount: thisWeekManualCount,
        situationReports,
        bestCall,
        meetingLinkedPipelineValue,
        meetingLinkedOppCount,
        preEvalPipelineValue,
        preEvalOppCount,
        evalStagePipelineValue,
        evalStageOppCount,
        topMeetingLinkedOpps,
        meetingWoWDelta,
      } as ExecWeeklySummaryData;
    },
    enabled: teamHierarchyEmailsWithSelf.length > 0,
    staleTime: 5 * 60 * 1000,
  });

  const sendEmail = useMutation({
    mutationFn: async (recipientEmail: string) => {
      const { data, error } = await supabase.functions.invoke('send-exec-summary', {
        body: { recipientEmail, summaryData: summaryData },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success('Executive summary sent!');
    },
    onError: (error: Error) => {
      toast.error('Failed to send summary: ' + error.message);
    },
  });

  return {
    summaryData,
    isLoading: teamLoading || (teamHierarchyEmailsWithSelf.length > 0 && dataLoading),
    sendEmail,
  };
}

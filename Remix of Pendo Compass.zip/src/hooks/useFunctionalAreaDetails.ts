import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface DiscoveryQuestion {
  id: string;
  functional_area_id: string;
  question: string;
  category: string;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface UseCaseTemplate {
  id: string;
  functional_area_id: string;
  name: string;
  description: string | null;
  example_outcomes: string | null;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Discovery Questions hooks
export function useDiscoveryQuestions(functionalAreaId?: string) {
  return useQuery({
    queryKey: ['discovery-questions', functionalAreaId],
    queryFn: async () => {
      let query = gateway
        .from('discovery_questions')
        .select('*')
        .order('sort_order');

      if (functionalAreaId) {
        query = query.eq('functional_area_id', functionalAreaId);
      }

      const { data, error } = await query.execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as DiscoveryQuestion[];
    },
  });
}

export function useCreateDiscoveryQuestion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (question: Omit<DiscoveryQuestion, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await gateway
        .from('discovery_questions')
        .insert(question)
        .select('*')
        .single()
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['discovery-questions'] });
      toast.success('Discovery question added');
    },
    onError: (error) => {
      toast.error('Failed to add question: ' + error.message);
    },
  });
}

export function useUpdateDiscoveryQuestion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<DiscoveryQuestion> & { id: string }) => {
      const { data, error } = await gateway
        .from('discovery_questions')
        .update(updates)
        .eq('id', id)
        .select('*')
        .single()
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['discovery-questions'] });
      toast.success('Question updated');
    },
    onError: (error) => {
      toast.error('Failed to update question: ' + error.message);
    },
  });
}

export function useDeleteDiscoveryQuestion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway
        .from('discovery_questions')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['discovery-questions'] });
      toast.success('Question deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete question: ' + error.message);
    },
  });
}

// Use Case Template hooks
export function useUseCaseTemplates(functionalAreaId?: string) {
  return useQuery({
    queryKey: ['use-case-templates', functionalAreaId],
    queryFn: async () => {
      let query = gateway
        .from('use_case_templates')
        .select('*')
        .order('sort_order');

      if (functionalAreaId) {
        query = query.eq('functional_area_id', functionalAreaId);
      }

      const { data, error } = await query.execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as UseCaseTemplate[];
    },
  });
}

export function useCreateUseCaseTemplate() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (template: Omit<UseCaseTemplate, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await gateway
        .from('use_case_templates')
        .insert(template)
        .select('*')
        .single()
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['use-case-templates'] });
      toast.success('Use case template added');
    },
    onError: (error) => {
      toast.error('Failed to add template: ' + error.message);
    },
  });
}

export function useUpdateUseCaseTemplate() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<UseCaseTemplate> & { id: string }) => {
      const { data, error } = await gateway
        .from('use_case_templates')
        .update(updates)
        .eq('id', id)
        .select('*')
        .single()
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['use-case-templates'] });
      toast.success('Template updated');
    },
    onError: (error) => {
      toast.error('Failed to update template: ' + error.message);
    },
  });
}

export function useDeleteUseCaseTemplate() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway
        .from('use_case_templates')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['use-case-templates'] });
      toast.success('Template deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete template: ' + error.message);
    },
  });
}

import { useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway } from '@/lib/apiGateway';
import { useAuth } from '@/contexts/AuthContext';
import { differenceInDays, parseISO } from 'date-fns';
import { toast } from 'sonner';

export type DeliveryMethod = 'email' | 'meeting' | 'internal';
export type NBAStatus = 'pending' | 'completed' | 'snoozed';

export type NBAOwner = 'prospect' | 'sales_rep' | 'sales_engineer';

export interface SubTaskNBA {
  id: string;
  action: string;
  type: string;
  priority: 'high' | 'medium' | 'low';
  status: NBAStatus;
  owner?: NBAOwner;
  notes?: string;
  dueDate?: string;
  order: number;
  autoCompleteConfidence?: number;
  autoCompleteReason?: string;
  opportunityId?: string | null;
}

export interface PriorityFactor {
  label: string;
  contribution: number;
  description: string;
}

export interface GroupedNBA {
  id: string; // parent NBA id or synthetic group id
  accountId: string;
  accountName: string;
  opportunityId?: string | null;
  opportunityName?: string | null;
  deliveryMethod: DeliveryMethod;
  title: string;
  subTasks: SubTaskNBA[];
  totalSubTasks: number;
  completedSubTasks: number;
  priority: 'high' | 'medium' | 'low';
  priorityScore: number;
  priorityReasoning: string[];
  priorityFactors: PriorityFactor[];
  stage: string;
  isOwned: boolean;
  isDirectlyAssigned: boolean; // true if user is explicitly assigned to any subtask
  functionalArea?: string;
  closeDate?: string;
}

// Infer delivery method from action type and content
function inferDeliveryMethod(actionType: string, action: string): DeliveryMethod {
  const lowerAction = action.toLowerCase();
  
  // Email-appropriate actions - external communication via email
  if (
    actionType === 'followup' ||
    lowerAction.includes('send') ||
    lowerAction.includes('share') ||
    lowerAction.includes('follow up') ||
    lowerAction.includes('follow-up') ||
    lowerAction.includes('document') ||
    lowerAction.includes('proposal') ||
    lowerAction.includes('email') ||
    lowerAction.includes('reach out') ||
    lowerAction.includes('provide') ||
    lowerAction.includes('deliver')
  ) {
    return 'email';
  }
  
  // Meeting-appropriate actions - requires synchronous discussion
  if (
    actionType === 'discovery' ||
    actionType === 'discovery_nba' ||
    lowerAction.includes('discuss') ||
    lowerAction.includes('demo') ||
    lowerAction.includes('explore') ||
    lowerAction.includes('review with') ||
    lowerAction.includes('ask about') ||
    lowerAction.includes('understand') ||
    lowerAction.includes('schedule') ||
    lowerAction.includes('present') ||
    lowerAction.includes('call') ||
    lowerAction.includes('meet')
  ) {
    return 'meeting';
  }
  
  // Internal tasks - no customer interaction needed
  if (
    lowerAction.includes('prepare') ||
    lowerAction.includes('research') ||
    lowerAction.includes('analyze') ||
    lowerAction.includes('create') ||
    lowerAction.includes('build') ||
    lowerAction.includes('update internal') ||
    lowerAction.includes('coordinate')
  ) {
    return 'internal';
  }
  
  // Default: if it involves customer action, it's external (email)
  if (
    lowerAction.includes('customer') ||
    lowerAction.includes('client') ||
    lowerAction.includes('prospect')
  ) {
    return 'email';
  }
  
  return 'internal';
}

// Determine dominant delivery method from a list of NBAs
function getDominantDeliveryMethod(nbas: Array<{ action_type: string; action: string; delivery_method?: string | null }>): DeliveryMethod {
  const methods = nbas.map(nba => 
    (nba.delivery_method as DeliveryMethod) || inferDeliveryMethod(nba.action_type, nba.action)
  );
  
  // If any require external communication (email/meeting), that takes precedence over internal
  if (methods.includes('meeting')) return 'meeting';
  if (methods.includes('email')) return 'email';
  return 'internal';
}

// Calculate priority score with reasoning and factors
function calculatePriorityScoreWithReasoning(params: {
  closeDate: string | null;
  stage: string | null;
  value: number | null;
  subTaskPriorities: Array<'high' | 'medium' | 'low'>;
}): { score: number; reasoning: string[]; factors: PriorityFactor[] } {
  const { closeDate, stage, value, subTaskPriorities } = params;
  let score = 0;
  const reasoning: string[] = [];
  const factors: PriorityFactor[] = [];
  
  const stageWeights: Record<string, number> = {
    closing: 100,
    proposal: 75,
    evaluation: 50,
    discovery: 25,
    customer: 10,
  };

  // Sub-task priority contribution (highest priority among sub-tasks)
  const highCount = subTaskPriorities.filter(p => p === 'high').length;
  const mediumCount = subTaskPriorities.filter(p => p === 'medium').length;
  const lowCount = subTaskPriorities.filter(p => p === 'low').length;
  
  if (highCount > 0) {
    const contribution = 50 + (highCount * 10);
    score += contribution;
    reasoning.push(`${highCount} high priority task${highCount > 1 ? 's' : ''}`);
    factors.push({
      label: 'High Priority Tasks',
      contribution,
      description: `${highCount} task${highCount > 1 ? 's' : ''} marked as high priority`,
    });
  } else if (mediumCount > 0) {
    const contribution = 25 + (mediumCount * 5);
    score += contribution;
    reasoning.push(`${mediumCount} medium priority task${mediumCount > 1 ? 's' : ''}`);
    factors.push({
      label: 'Medium Priority Tasks',
      contribution,
      description: `${mediumCount} task${mediumCount > 1 ? 's' : ''} marked as medium priority`,
    });
  } else if (lowCount > 0) {
    factors.push({
      label: 'Task Priorities',
      contribution: 0,
      description: `${lowCount} low priority task${lowCount > 1 ? 's' : ''}`,
    });
  }

  // Close date contribution
  if (closeDate) {
    const daysUntilClose = differenceInDays(parseISO(closeDate), new Date());
    let contribution = 0;
    let description = '';
    
    if (daysUntilClose <= 7) {
      contribution = 100;
      description = 'Opportunity closes within 7 days';
      reasoning.push('Closes within 7 days');
    } else if (daysUntilClose <= 14) {
      contribution = 80;
      description = 'Opportunity closes within 2 weeks';
      reasoning.push('Closes within 2 weeks');
    } else if (daysUntilClose <= 30) {
      contribution = 60;
      description = 'Opportunity closes within 30 days';
      reasoning.push('Closes within 30 days');
    } else if (daysUntilClose <= 60) {
      contribution = 40;
      description = 'Opportunity closes within 60 days';
      reasoning.push('Closes within 60 days');
    } else if (daysUntilClose <= 90) {
      contribution = 20;
      description = 'Opportunity closes within 90 days';
      reasoning.push('Closes within 90 days');
    } else {
      contribution = 10;
      description = 'Opportunity closes in 90+ days';
    }
    
    score += contribution;
    factors.push({
      label: 'Close Date Urgency',
      contribution,
      description,
    });
  }

  // Stage contribution
  const stageScore = stageWeights[stage || 'discovery'] || 25;
  score += stageScore;
  const stageLabel = stage ? stage.charAt(0).toUpperCase() + stage.slice(1) : 'Discovery';
  factors.push({
    label: 'Account Stage',
    contribution: stageScore,
    description: `${stageLabel} stage accounts get priority`,
  });
  if (stageScore >= 50) {
    reasoning.push(`${stageLabel} stage`);
  }

  // Value contribution
  if (value && value > 0) {
    const valueScore = Math.min(100, Math.log10(value) * 20);
    score += valueScore;
    const formattedValue = value >= 1000000 
      ? `$${(value / 1000000).toFixed(1)}M`
      : value >= 1000 
        ? `$${(value / 1000).toFixed(0)}K`
        : `$${value}`;
    factors.push({
      label: 'Account Value',
      contribution: Math.round(valueScore),
      description: `${formattedValue} ARR/opportunity value`,
    });
    if (value >= 50000) {
      reasoning.push(`${formattedValue} opportunity`);
    }
  }

  return { score, reasoning, factors };
}

function determinePriority(score: number): 'high' | 'medium' | 'low' {
  if (score >= 200) return 'high';
  if (score >= 100) return 'medium';
  return 'low';
}

export function useGroupedNBAs(showOnlyMine: boolean = true, teamEmails?: string[]) {
  const { effectiveUserId, effectiveUserEmail } = useAuth();
  const queryClient = useQueryClient();

  // Get user email for ownership checks (use effective user for impersonation)
  const userEmail = effectiveUserEmail;
  const userId = effectiveUserId;

  // Fetch user's account team memberships
  const { data: myAccountTeams } = useQuery({
    queryKey: ['my-account-teams', userEmail],
    queryFn: async () => {
      if (!userEmail) return new Set<string>();
      const result = await gateway.from('account_team_members')
        .select('account_id')
        .ilike('team_member_email', userEmail)
        .execute();
      if (result.error) return new Set<string>();
      return new Set((result.data || []).map((r: any) => r.account_id));
    },
    enabled: !!userEmail && showOnlyMine,
  });

  // Fetch user's opportunity team memberships
  const { data: myOpportunityTeams } = useQuery({
    queryKey: ['my-opportunity-teams', userEmail],
    queryFn: async () => {
      if (!userEmail) return new Set<string>();
      const result = await gateway.from('opportunity_team_members')
        .select('opportunity_id')
        .ilike('team_member_email', userEmail)
        .execute();
      if (result.error) return new Set<string>();
      return new Set((result.data || []).map((r: any) => r.opportunity_id));
    },
    enabled: !!userEmail && showOnlyMine,
  });

  // Fetch all account NBAs with parent-child relationships
  const { data: rawNBAs, isLoading } = useQuery({
    queryKey: ['grouped-account-nbas'],
    queryFn: async () => {
      const result = await gateway.from('account_nbas')
        .select(`
          *,
          accounts(name, stage, owner_id, arr, primary_se_email),
          opportunities(id, name, owner_email, primary_se_email),
          parent:parent_nba_id(id, action)
        `)
        .order('created_at', { ascending: false })
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data;
    },
  });
  
  // Build team email set for team filtering (lowercase for comparison)
  const teamEmailSet = useMemo(() => {
    if (!teamEmails) return null;
    return new Set(teamEmails.map(e => e.toLowerCase()));
  }, [teamEmails]);

  // Group NBAs by account + delivery method
  const groupedNBAs = useMemo(() => {
    if (!rawNBAs) return [];

    // Separate parent NBAs and orphan NBAs
    const parentNBAs = rawNBAs.filter(nba => !nba.parent_nba_id);
    const childNBAs = rawNBAs.filter(nba => nba.parent_nba_id);

    // Create a map of parent_id -> children
    const childrenByParent = new Map<string, typeof rawNBAs>();
    childNBAs.forEach(child => {
      const existing = childrenByParent.get(child.parent_nba_id!) || [];
      existing.push(child);
      childrenByParent.set(child.parent_nba_id!, existing);
    });

    // Group orphan NBAs by account + delivery method
    const groupKey = (nba: any) => {
      const deliveryMethod = nba.delivery_method || inferDeliveryMethod(nba.action_type, nba.action);
      return `${nba.account_id}-${deliveryMethod}`;
    };

    const orphanGroups = new Map<string, typeof rawNBAs>();
    parentNBAs.filter(nba => !childrenByParent.has(nba.id)).forEach(nba => {
      const key = groupKey(nba);
      const existing = orphanGroups.get(key) || [];
      existing.push(nba);
      orphanGroups.set(key, existing);
    });

    const groups: GroupedNBA[] = [];

    // Process explicit parent-child groups
    parentNBAs.filter(nba => childrenByParent.has(nba.id)).forEach(parent => {
      const children = childrenByParent.get(parent.id) || [];
      const allItems = [parent, ...children];
      
      // Check ownership: account owner, primary SE, team member, or assigned to any of the NBAs
      const accountOwnerId = parent.accounts?.owner_id;
      const accountSeEmail = parent.accounts?.primary_se_email;
      const oppOwnerEmail = parent.opportunities?.owner_email;
      const oppSeEmail = parent.opportunities?.primary_se_email;
      const isAccountOwner = userId === accountOwnerId;
      const isAccountSE = userEmail && accountSeEmail && userEmail.toLowerCase() === accountSeEmail.toLowerCase();
      const isOpportunitySE = userEmail && oppSeEmail && userEmail.toLowerCase() === oppSeEmail.toLowerCase();
      const isOpportunityOwner = userEmail && oppOwnerEmail && userEmail.toLowerCase() === oppOwnerEmail.toLowerCase();
      // Check team membership tables
      const isOnAccountTeam = myAccountTeams?.has(parent.account_id) || false;
      const isOnOpportunityTeam = parent.opportunity_id ? (myOpportunityTeams?.has(parent.opportunity_id) || false) : false;
      // Only consider PENDING items for direct assignment check - completed items shouldn't drive visibility
      const pendingItems = allItems.filter(item => item.status !== 'completed');
      const isDirectlyAssigned = pendingItems.some(item => 
        item.assigned_to && userEmail && item.assigned_to.toLowerCase() === userEmail.toLowerCase()
      );
      // For opportunity-linked NBAs, require opportunity-level involvement
      // Account team membership alone shouldn't grant visibility to specific opportunity NBAs
      const hasOpportunity = !!parent.opportunity_id;
      const isOwned = hasOpportunity
        ? (isOpportunitySE || isOpportunityOwner || isOnOpportunityTeam || isDirectlyAssigned || isAccountOwner)
        : (isAccountOwner || isAccountSE || isOnAccountTeam || isDirectlyAssigned);
      const relevantSeEmail = hasOpportunity ? oppSeEmail : accountSeEmail;
      const relevantOwnerEmail = hasOpportunity ? oppOwnerEmail : null;
      
      const isTeamOwned = teamEmailSet ? (
        (relevantSeEmail && teamEmailSet.has(relevantSeEmail.toLowerCase())) ||
        (relevantOwnerEmail && teamEmailSet.has(relevantOwnerEmail.toLowerCase())) ||
        allItems.some(item => item.assigned_to && teamEmailSet.has(item.assigned_to.toLowerCase()))
      ) : true;

      // Filter: if showOnlyMine, check ownership; if team filter active, check team membership
      if (showOnlyMine && !isOwned) return;
      if (teamEmailSet && !isTeamOwned) return;

      const completedCount = allItems.filter(item => item.status === 'completed').length;
      
      // Get sub-task priorities for combined scoring
      const subTaskPriorities = allItems.map(item => (item.priority || 'medium') as 'high' | 'medium' | 'low');
      
      // Delivery method should consider all sub-tasks, not just parent
      const groupDeliveryMethod = getDominantDeliveryMethod(allItems);
      
      const { score: priorityScore, reasoning: priorityReasoning, factors: priorityFactors } = calculatePriorityScoreWithReasoning({
        closeDate: null,
        stage: parent.accounts?.stage,
        value: parent.accounts?.arr,
        subTaskPriorities,
      });

      // Get the primary opportunity from the group (use parent's opportunity if set, otherwise first child's)
      const primaryOpportunity = parent.opportunities || allItems.find(item => item.opportunity_id)?.opportunities;
      const primaryOpportunityId = parent.opportunity_id || allItems.find(item => item.opportunity_id)?.opportunity_id;

      groups.push({
        id: parent.id,
        accountId: parent.account_id,
        accountName: parent.accounts?.name || 'Unknown',
        opportunityId: primaryOpportunityId,
        opportunityName: primaryOpportunity?.name,
        deliveryMethod: groupDeliveryMethod,
        title: parent.action,
        subTasks: allItems.map((item, idx) => {
          // Determine owner: explicit assignment → opportunity SE → account SE → generic role
          const defaultOwner = oppSeEmail || accountSeEmail || 'sales_engineer';
          return {
            id: item.id,
            action: item.action,
            type: item.action_type,
            priority: (item.priority || 'medium') as 'high' | 'medium' | 'low',
            status: (item.status || 'pending') as NBAStatus,
            owner: (item.assigned_to || defaultOwner) as NBAOwner,
            notes: item.notes,
            dueDate: item.due_date,
            order: item.sub_task_order || idx,
            autoCompleteConfidence: item.auto_complete_confidence,
            autoCompleteReason: item.auto_complete_reason,
            opportunityId: item.opportunity_id,
          };
        }).sort((a, b) => a.order - b.order),
        totalSubTasks: allItems.length,
        completedSubTasks: completedCount,
        priority: determinePriority(priorityScore),
        priorityScore,
        priorityReasoning,
        priorityFactors,
        stage: parent.accounts?.stage || 'discovery',
        isOwned,
        isDirectlyAssigned,
      });
    });

    // Process orphan groups (synthetic groupings)
    orphanGroups.forEach((nbas, key) => {
      if (nbas.length === 0) return;

      const first = nbas[0];
      
      // Check ownership: account owner, primary SE, opportunity SE/owner, team member, or assigned to any of the NBAs
      const accountOwnerId = first.accounts?.owner_id;
      const accountSeEmail = first.accounts?.primary_se_email;
      const oppOwnerEmail = nbas.find(n => n.opportunities?.owner_email)?.opportunities?.owner_email;
      const oppSeEmail = nbas.find(n => n.opportunities?.primary_se_email)?.opportunities?.primary_se_email;
      const oppId = nbas.find(n => n.opportunity_id)?.opportunity_id;
      const isAccountOwner = userId === accountOwnerId;
      const isAccountSE = userEmail && accountSeEmail && userEmail.toLowerCase() === accountSeEmail.toLowerCase();
      const isOpportunitySE = userEmail && oppSeEmail && userEmail.toLowerCase() === oppSeEmail.toLowerCase();
      const isOpportunityOwner = userEmail && oppOwnerEmail && userEmail.toLowerCase() === oppOwnerEmail.toLowerCase();
      // Check team membership tables
      const isOnAccountTeam = myAccountTeams?.has(first.account_id) || false;
      const isOnOpportunityTeam = oppId ? (myOpportunityTeams?.has(oppId) || false) : false;
      // Only consider PENDING NBAs for direct assignment check - completed items shouldn't drive visibility
      const pendingNbas = nbas.filter(nba => nba.status !== 'completed');
      const isDirectlyAssigned = pendingNbas.some(nba => 
        nba.assigned_to && userEmail && nba.assigned_to.toLowerCase() === userEmail.toLowerCase()
      );
      // For opportunity-linked NBAs, require opportunity-level involvement
      // Account team membership alone shouldn't grant visibility to specific opportunity NBAs
      const hasOpportunity = nbas.some(n => n.opportunity_id);
      const isOwned = hasOpportunity
        ? (isOpportunitySE || isOpportunityOwner || isOnOpportunityTeam || isDirectlyAssigned || isAccountOwner)
        : (isAccountOwner || isAccountSE || isOnAccountTeam || isDirectlyAssigned);
      const relevantSeEmail = hasOpportunity ? oppSeEmail : accountSeEmail;
      const relevantOwnerEmail = hasOpportunity ? oppOwnerEmail : null;
      
      const isTeamOwned = teamEmailSet ? (
        (relevantSeEmail && teamEmailSet.has(relevantSeEmail.toLowerCase())) ||
        (relevantOwnerEmail && teamEmailSet.has(relevantOwnerEmail.toLowerCase())) ||
        nbas.some(nba => nba.assigned_to && teamEmailSet.has(nba.assigned_to.toLowerCase()))
      ) : true;

      // Filter: if showOnlyMine, check ownership; if team filter active, check team membership
      if (showOnlyMine && !isOwned) return;
      if (teamEmailSet && !isTeamOwned) return;

      const completedCount = nbas.filter(nba => nba.status === 'completed').length;
      const pendingCount = nbas.filter(nba => nba.status !== 'completed').length;
      
      // Skip if all completed
      if (pendingCount === 0) return;

      // Get sub-task priorities for combined scoring
      const subTaskPriorities = nbas.map(n => (n.priority || 'medium') as 'high' | 'medium' | 'low');
      
      // Delivery method should consider all NBAs in the group
      const groupDeliveryMethod = getDominantDeliveryMethod(nbas);
      
      const { score: priorityScore, reasoning: priorityReasoning, factors: priorityFactors } = calculatePriorityScoreWithReasoning({
        closeDate: null,
        stage: first.accounts?.stage,
        value: first.accounts?.arr,
        subTaskPriorities,
      });

      const deliveryLabel = {
        email: 'Email Actions',
        meeting: 'Meeting Topics',
        internal: 'Internal Tasks',
      }[groupDeliveryMethod];

      // Get the primary opportunity from the group
      const primaryOpportunity = nbas.find(nba => nba.opportunity_id)?.opportunities;
      const primaryOpportunityId = nbas.find(nba => nba.opportunity_id)?.opportunity_id;

      groups.push({
        id: `group-${key}`,
        accountId: first.account_id,
        accountName: first.accounts?.name || 'Unknown',
        opportunityId: primaryOpportunityId,
        opportunityName: primaryOpportunity?.name,
        deliveryMethod: groupDeliveryMethod,
        title: `${first.accounts?.name}: ${deliveryLabel}`,
        subTasks: nbas.map((nba, idx) => {
          // Determine owner: explicit assignment → opportunity SE → account SE → generic role
          const nbaOppSeEmail = nba.opportunities?.primary_se_email;
          const defaultOwner = nbaOppSeEmail || oppSeEmail || accountSeEmail || 'sales_engineer';
          return {
            id: nba.id,
            action: nba.action,
            type: nba.action_type,
            priority: (nba.priority || 'medium') as 'high' | 'medium' | 'low',
            status: (nba.status || 'pending') as NBAStatus,
            owner: (nba.assigned_to || defaultOwner) as NBAOwner,
            notes: nba.notes,
            dueDate: nba.due_date,
            order: nba.sub_task_order || idx,
            autoCompleteConfidence: nba.auto_complete_confidence,
            autoCompleteReason: nba.auto_complete_reason,
            opportunityId: nba.opportunity_id,
          };
        }).sort((a, b) => a.order - b.order),
        totalSubTasks: nbas.length,
        completedSubTasks: completedCount,
        priority: determinePriority(priorityScore),
        priorityScore,
        priorityReasoning,
        priorityFactors,
        stage: first.accounts?.stage || 'discovery',
        isOwned,
        isDirectlyAssigned,
      });
    });

    // Sort by priority score
    return groups.sort((a, b) => b.priorityScore - a.priorityScore);
  }, [rawNBAs, userId, userEmail, showOnlyMine, teamEmailSet, myAccountTeams, myOpportunityTeams]);

  // Mutation to complete a single sub-task
  const completeSubTask = useMutation({
    mutationFn: async (nbaId: string) => {
      const result = await gateway.from('account_nbas')
        .update({ status: 'completed' })
        .eq('id', nbaId)
        .execute();
      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Task marked as complete');
    },
  });

  // Mutation to complete all sub-tasks in a group
  const completeGroup = useMutation({
    mutationFn: async (subTaskIds: string[]) => {
      const result = await gateway.from('account_nbas')
        .update({ status: 'completed' })
        .in('id', subTaskIds)
        .execute();
      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('All tasks marked as complete');
    },
  });

  // Mutation to update NBA delivery method
  const updateDeliveryMethod = useMutation({
    mutationFn: async ({ nbaId, deliveryMethod }: { nbaId: string; deliveryMethod: DeliveryMethod }) => {
      const result = await gateway.from('account_nbas')
        .update({ delivery_method: deliveryMethod })
        .eq('id', nbaId)
        .execute();
      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
    },
  });

  // Mutation to update NBA due date with logging
  const updateDueDate = useMutation({
    mutationFn: async ({ 
      nbaId, 
      newDueDate, 
      previousDueDate,
      changeReason 
    }: { 
      nbaId: string; 
      newDueDate: Date;
      previousDueDate: Date | null;
      changeReason?: string;
    }) => {
      // Determine change type
      let changeType = 'manual';
      let daysChanged = 0;
      
      if (!previousDueDate) {
        changeType = 'initial';
      } else {
        daysChanged = differenceInDays(newDueDate, previousDueDate);
        changeType = daysChanged > 0 ? 'postponed' : 'advanced';
      }

      // Update the NBA due date
      const updateResult = await gateway.from('account_nbas')
        .update({ due_date: newDueDate.toISOString() })
        .eq('id', nbaId)
        .execute();
      if (updateResult.error) throw new Error(updateResult.error.message);

      // Log the change
      const logResult = await gateway.from('nba_due_date_changes')
        .insert({
          nba_id: nbaId,
          previous_due_date: previousDueDate?.toISOString() || null,
          new_due_date: newDueDate.toISOString(),
          change_type: changeType,
          days_changed: daysChanged,
          changed_by: userId || null,
          changed_by_email: userEmail || null,
          change_reason: changeReason || null,
        })
        .execute();
      if (logResult.error) console.error('Failed to log due date change:', logResult.error);

      return { changeType, daysChanged };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      if (data.changeType === 'postponed') {
        toast.info(`Due date postponed by ${data.daysChanged} day${data.daysChanged !== 1 ? 's' : ''}`);
      } else if (data.changeType === 'advanced') {
        toast.success(`Due date moved up by ${Math.abs(data.daysChanged)} day${Math.abs(data.daysChanged) !== 1 ? 's' : ''}`);
      } else {
        toast.success('Due date set');
      }
    },
    onError: (error) => {
      toast.error('Failed to update due date');
      console.error('Due date update error:', error);
    },
  });

  // Group by priority
  const groupedByPriority = useMemo(() => ({
    high: groupedNBAs.filter(g => g.priority === 'high'),
    medium: groupedNBAs.filter(g => g.priority === 'medium'),
    low: groupedNBAs.filter(g => g.priority === 'low'),
  }), [groupedNBAs]);

  // Separate directly assigned from other owned NBAs (for "My NBAs" view)
  const directlyAssigned = useMemo(() => 
    groupedNBAs.filter(g => g.isDirectlyAssigned), 
    [groupedNBAs]
  );
  
  const otherOnMyAccounts = useMemo(() => 
    groupedNBAs.filter(g => g.isOwned && !g.isDirectlyAssigned), 
    [groupedNBAs]
  );

  // Group directly assigned by priority
  const directlyAssignedByPriority = useMemo(() => ({
    high: directlyAssigned.filter(g => g.priority === 'high'),
    medium: directlyAssigned.filter(g => g.priority === 'medium'),
    low: directlyAssigned.filter(g => g.priority === 'low'),
  }), [directlyAssigned]);

  // Group other on my accounts by priority
  const otherOnMyAccountsByPriority = useMemo(() => ({
    high: otherOnMyAccounts.filter(g => g.priority === 'high'),
    medium: otherOnMyAccounts.filter(g => g.priority === 'medium'),
    low: otherOnMyAccounts.filter(g => g.priority === 'low'),
  }), [otherOnMyAccounts]);

  return {
    groupedNBAs,
    groupedByPriority,
    directlyAssigned,
    otherOnMyAccounts,
    directlyAssignedByPriority,
    otherOnMyAccountsByPriority,
    isLoading,
    completeSubTask,
    completeGroup,
    updateDeliveryMethod,
    updateDueDate,
  };
}

// Hook to detect NBA completions from a new transcript
export function useDetectNBACompletions() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      transcriptContent, 
      accountId, 
      accountName 
    }: { 
      transcriptContent: string; 
      accountId: string; 
      accountName: string;
    }) => {
      // Get pending NBAs for this account
      const pendingResult = await gateway.from('account_nbas')
        .select('id, action, action_type, notes')
        .eq('account_id', accountId)
        .eq('status', 'pending')
        .execute();
      
      if (pendingResult.error) throw new Error(pendingResult.error.message);
      const pendingNBAs = pendingResult.data;
      if (!pendingNBAs || pendingNBAs.length === 0) return { completions: [] };

      // Call edge function to analyze transcript
      const { data, error } = await supabase.functions.invoke('detect-nba-completion', {
        body: {
          transcript_content: transcriptContent,
          nbas: pendingNBAs,
          account_name: accountName,
        },
      });

      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      if (data?.completions?.length > 0) {
        toast.success(`Detected ${data.completions.length} potentially completed actions`);
        queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      }
    },
    onError: (error) => {
      console.error('Failed to detect NBA completions:', error);
      // Don't show error toast - this is a background optimization
    },
  });
}

// Hook to apply auto-completion suggestions
export function useApplyAutoCompletions() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (completions: Array<{ 
      nba_id: string; 
      confidence: number; 
      reason: string;
      transcript_id?: string;
    }>) => {
      // Only auto-apply high confidence completions, mark others as suggestions
      const highConfidence = completions.filter(c => c.confidence >= 0.8);
      const suggestions = completions.filter(c => c.confidence < 0.8);

      // Auto-complete high confidence
      if (highConfidence.length > 0) {
        const result = await gateway.from('account_nbas')
          .update({ status: 'completed' })
          .in('id', highConfidence.map(c => c.nba_id))
          .execute();
        if (result.error) throw new Error(result.error.message);
      }

      // Add confidence scores to suggestions
      for (const suggestion of suggestions) {
        const result = await gateway.from('account_nbas')
          .update({
            auto_complete_confidence: suggestion.confidence,
            auto_complete_reason: suggestion.reason,
            auto_completed_by_transcript_id: suggestion.transcript_id,
          })
          .eq('id', suggestion.nba_id)
          .execute();
        if (result.error) console.error('Failed to update suggestion:', result.error);
      }

      return { autoCompleted: highConfidence.length, suggested: suggestions.length };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      if (data.autoCompleted > 0) {
        toast.success(`Auto-completed ${data.autoCompleted} high-confidence actions`);
      }
      if (data.suggested > 0) {
        toast.info(`${data.suggested} actions flagged for review`);
      }
    },
  });
}
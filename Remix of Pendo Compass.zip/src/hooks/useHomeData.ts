import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { differenceInDays, parseISO, startOfWeek, subDays } from 'date-fns';

export interface HomeAccount {
  id: string;
  name: string;
  stage: string | null;
  relationship_status: string | null;
  arr: number | null;
  engagement_score: number | null;
  momentum_score: number | null;
  opportunityCount: number;
  openNBACount: number;
}

export interface HomeOpportunity {
  id: string;
  name: string;
  account_id: string;
  account_name: string;
  sales_stage: string | null;
  pre_sales_stage: string | null;
  close_date: string | null;
  value: number | null;
  engagement_score: number | null;
  momentum_score: number | null;
  last_activity_at: string | null;
  is_stalled: boolean;
  days_since_activity: number | null;
  readiness_score: number | null;
  is_archived: boolean;
}

export interface HomeNBA {
  id: string;
  action: string;
  action_type: string;
  priority: 'high' | 'medium' | 'low';
  status: string;
  due_date: string | null;
  account_id: string;
  account_name: string;
  opportunity_id: string | null;
  opportunity_name: string | null;
  is_overdue: boolean;
  assigned_to: string | null;
}

export interface HomeSignal {
  id: string;
  rule_name: string;
  rule_key: string;
  opportunity_id: string;
  opportunity_name: string;
  account_name: string;
  first_detected_at: string;
  matched_phrases: string[];
  speaker_type: string | null;
}

export interface HomeStageChange {
  id: string;
  opportunity_id: string;
  opportunity_name: string;
  account_name: string;
  stage_type: 'sales_stage' | 'pre_sales_stage';
  old_value: string | null;
  new_value: string | null;
  changed_at: string;
}

export interface HomeSentimentChange {
  id: string;
  contact_id: string;
  contact_name: string;
  account_name: string;
  opportunity_name: string | null;
  old_sentiment: number | null;
  new_sentiment: number | null;
  changed_at: string;
  change_direction: 'up' | 'down';
}

export interface HomeKPIs {
  openNBAs: number;
  overdueNBAs: number;
  stalledOpportunities: number;
  newSignalsThisWeek: number;
  activeOpportunities: number;
  sentimentChanges: number;
}

export interface HomeEvent {
  id: string;
  type: 'nba_due' | 'signal_detected' | 'stage_change' | 'sentiment_change' | 'stalled' | 'nba_completed';
  timestamp: string;
  title: string;
  description: string;
  account_name: string;
  opportunity_name?: string | null;
  opportunity_id?: string;
  account_id?: string;
  priority?: 'high' | 'medium' | 'low';
  metadata?: Record<string, any>;
}

const ACTIVITY_SIGNAL_TREE_ID = 'f5e4d3c2-b1a0-9876-5432-fedcba098765';
const STALLED_THRESHOLD_DAYS = 14;

export function useHomeData(timeRangeDays: number = 30) {
  const { effectiveUserId, effectiveUserEmail } = useAuth();
  const { isAdmin, isManager } = useUserRole();
  const userEmail = effectiveUserEmail?.toLowerCase();
  const userId = effectiveUserId;

  // Fetch team membership for the user
  const teamMembershipQuery = useQuery({
    queryKey: ['home-team-membership', userEmail],
    queryFn: async () => {
      if (!userEmail) return { opportunityIds: [], accountIds: [] };
      
      // Get opportunity team memberships (fetch all and filter in memory due to encrypted fields)
      const oppTeamResult = await gateway.from('opportunity_team_members')
        .select('opportunity_id, team_member_email')
        .limit(1000)
        .execute();
      
      // Get account team memberships  
      const acctTeamResult = await gateway.from('account_team_members')
        .select('team_member_email, account_id')
        .limit(1000)
        .execute();
      
      // Filter opportunity memberships in memory (handles encrypted/decrypted fields)
      const opportunityIds = (oppTeamResult.data || [])
        .filter((t: any) => t.team_member_email?.toLowerCase() === userEmail)
        .map((t: any) => t.opportunity_id);
      
      const accountIds = (acctTeamResult.data || [])
        .filter((t: any) => t.team_member_email?.toLowerCase() === userEmail)
        .map((t: any) => t.account_id);
      
      return { opportunityIds, accountIds };
    },
    enabled: !!userEmail,
  });

  // Fetch accounts where user is owner, primary SE, or team member
  const accountsQuery = useQuery({
    queryKey: ['home-accounts', userId, userEmail, isAdmin, isManager, teamMembershipQuery.data],
    queryFn: async () => {
      if (!userId && !userEmail) return [];
      
      const result = await gateway.from('accounts')
        .select('id, name, stage, relationship_status, arr, engagement_score, momentum_score, owner_id, primary_se_email')
        .limit(500)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      // Filter to user's accounts (or all for admin/manager)
      const teamAccountIds = teamMembershipQuery.data?.accountIds || [];
      const filtered = (result.data || []).filter((a: any) => {
        if (isAdmin || isManager) return true;
        return a.owner_id === userId || 
          (userEmail && a.primary_se_email?.toLowerCase() === userEmail) ||
          teamAccountIds.includes(a.id);
      });
      
      return filtered as HomeAccount[];
    },
    enabled: !!(userId || userEmail) && !teamMembershipQuery.isLoading,
  });

  // Fetch opportunities where user is owner, SE, or team member
  const opportunitiesQuery = useQuery({
    queryKey: ['home-opportunities', userId, userEmail, isAdmin, isManager, teamMembershipQuery.data],
    queryFn: async () => {
      if (!userId && !userEmail) return [];
      
      const result = await gateway.from('opportunities')
        .select(`
          id, name, account_id, sales_stage, pre_sales_stage, close_date, value,
          engagement_score, momentum_score, updated_at, readiness_score, is_archived,
          owner_email, primary_se_email,
          accounts!inner(name)
        `)
        .eq('is_archived', false)
        .limit(1000)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      const now = new Date();
      const teamOppIds = teamMembershipQuery.data?.opportunityIds || [];
      const teamAccountIds = teamMembershipQuery.data?.accountIds || [];
      
      // Filter to user's opportunities (or all for admin/manager)
      const filtered = (result.data || []).filter((o: any) => {
        if (isAdmin || isManager) return true;
        return (userEmail && o.owner_email?.toLowerCase() === userEmail) ||
          (userEmail && o.primary_se_email?.toLowerCase() === userEmail) ||
          teamOppIds.includes(o.id) ||
          teamAccountIds.includes(o.account_id);
      });
      
      return filtered.map((o: any) => {
        const lastActivity = o.updated_at ? parseISO(o.updated_at) : null;
        const daysSinceActivity = lastActivity ? differenceInDays(now, lastActivity) : null;
        
        return {
          id: o.id,
          name: o.name,
          account_id: o.account_id,
          account_name: o.accounts?.name || 'Unknown',
          sales_stage: o.sales_stage,
          pre_sales_stage: o.pre_sales_stage,
          close_date: o.close_date,
          value: o.value,
          engagement_score: o.engagement_score,
          momentum_score: o.momentum_score,
          last_activity_at: o.updated_at,
          is_stalled: daysSinceActivity !== null && daysSinceActivity > STALLED_THRESHOLD_DAYS,
          days_since_activity: daysSinceActivity,
          readiness_score: o.readiness_score,
          is_archived: o.is_archived,
        } as HomeOpportunity;
      });
    },
    enabled: !!(userId || userEmail) && !teamMembershipQuery.isLoading,
  });

  // Fetch NBAs for user's accounts/opportunities
  const nbasQuery = useQuery({
    queryKey: ['home-nbas', userId, userEmail, isAdmin, isManager, teamMembershipQuery.data],
    queryFn: async () => {
      if (!userId && !userEmail) return [];
      
      const result = await gateway.from('account_nbas')
        .select(`
          id, action, action_type, priority, status, due_date, account_id, opportunity_id, assigned_to,
          accounts!inner(name, owner_id, primary_se_email),
          opportunities(name, owner_email, primary_se_email)
        `)
        .in('status', ['pending', 'snoozed'])
        .limit(500)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      const now = new Date();
      const teamOppIds = teamMembershipQuery.data?.opportunityIds || [];
      const teamAccountIds = teamMembershipQuery.data?.accountIds || [];
      
      // Filter to user's NBAs (or all for admin/manager)
      const filtered = (result.data || []).filter((n: any) => {
        if (isAdmin || isManager) return true;
        const isAccountOwner = n.accounts?.owner_id === userId;
        const isAccountSE = userEmail && n.accounts?.primary_se_email?.toLowerCase() === userEmail;
        const isOppOwner = userEmail && n.opportunities?.owner_email?.toLowerCase() === userEmail;
        const isOppSE = userEmail && n.opportunities?.primary_se_email?.toLowerCase() === userEmail;
        const isAssigned = userEmail && n.assigned_to?.toLowerCase() === userEmail;
        const isTeamMemberOpp = n.opportunity_id && teamOppIds.includes(n.opportunity_id);
        const isTeamMemberAcct = teamAccountIds.includes(n.account_id);
        return isAccountOwner || isAccountSE || isOppOwner || isOppSE || isAssigned || isTeamMemberOpp || isTeamMemberAcct;
      });
      
      return filtered.map((n: any) => ({
        id: n.id,
        action: n.action,
        action_type: n.action_type,
        priority: n.priority || 'medium',
        status: n.status,
        due_date: n.due_date,
        account_id: n.account_id,
        account_name: n.accounts?.name || 'Unknown',
        opportunity_id: n.opportunity_id,
        opportunity_name: n.opportunities?.name,
        is_overdue: n.due_date ? parseISO(n.due_date) < now : false,
        assigned_to: n.assigned_to,
      } as HomeNBA));
    },
    enabled: !!(userId || userEmail) && !teamMembershipQuery.isLoading,
  });

  // Fetch recent signals
  const signalsQuery = useQuery({
    queryKey: ['home-signals', timeRangeDays],
    queryFn: async () => {
      const cutoffDate = subDays(new Date(), timeRangeDays).toISOString();
      
      const result = await gateway.from('detection_rule_matches')
        .select(`
          id, rule_id, opportunity_id, first_detected_at, matched_phrases, speaker_type,
          detection_rules!inner(name, tree_id, signal_field_name),
          opportunities!inner(name, account_id, owner_email, primary_se_email, accounts!inner(name))
        `)
        .gte('first_detected_at', cutoffDate)
        .order('first_detected_at', { ascending: false })
        .limit(200)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      // Filter to Activity Signals tree
      const filtered = (result.data || []).filter((s: any) => 
        s.detection_rules?.tree_id === ACTIVITY_SIGNAL_TREE_ID
      );
      
      return filtered.map((s: any) => ({
        id: s.id,
        rule_name: s.detection_rules?.name?.replace(' Signals', '').replace(' Signal', '') || 'Unknown',
        rule_key: s.detection_rules?.signal_field_name || s.detection_rules?.name?.toLowerCase().replace(/\s+/g, '_') || 'unknown',
        opportunity_id: s.opportunity_id,
        opportunity_name: s.opportunities?.name || 'Unknown',
        account_name: s.opportunities?.accounts?.name || 'Unknown',
        first_detected_at: s.first_detected_at,
        matched_phrases: s.matched_phrases || [],
        speaker_type: s.speaker_type,
      } as HomeSignal));
    },
  });

  // Fetch recent stage changes
  const stageChangesQuery = useQuery({
    queryKey: ['home-stage-changes', timeRangeDays],
    queryFn: async () => {
      const cutoffDate = subDays(new Date(), timeRangeDays).toISOString();
      
      const result = await gateway.from('opportunity_stage_history')
        .select(`
          id, opportunity_id, stage_type, old_value, new_value, changed_at,
          opportunities!inner(name, account_id, accounts!inner(name))
        `)
        .gte('changed_at', cutoffDate)
        .order('changed_at', { ascending: false })
        .limit(100)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      return (result.data || []).map((s: any) => ({
        id: s.id,
        opportunity_id: s.opportunity_id,
        opportunity_name: s.opportunities?.name || 'Unknown',
        account_name: s.opportunities?.accounts?.name || 'Unknown',
        stage_type: s.stage_type,
        old_value: s.old_value,
        new_value: s.new_value,
        changed_at: s.changed_at,
      } as HomeStageChange));
    },
  });

  // Fetch recent sentiment changes
  const sentimentChangesQuery = useQuery({
    queryKey: ['home-sentiment-changes', timeRangeDays],
    queryFn: async () => {
      const cutoffDate = subDays(new Date(), timeRangeDays).toISOString();
      
      const result = await gateway.from('stakeholder_history')
        .select(`
          id, contact_id, account_id, opportunity_id, old_value, new_value, changed_at, metric_type,
          account_contacts!inner(name_encrypted, accounts!inner(name)),
          opportunities(name)
        `)
        .eq('metric_type', 'sentiment')
        .gte('changed_at', cutoffDate)
        .order('changed_at', { ascending: false })
        .limit(50)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      return (result.data || [])
        .filter((s: any) => s.old_value !== s.new_value)
        .map((s: any) => {
          const oldVal = typeof s.old_value === 'number' ? s.old_value : null;
          const newVal = typeof s.new_value === 'number' ? s.new_value : null;
          return {
            id: s.id,
            contact_id: s.contact_id,
            contact_name: 'Stakeholder', // Encrypted, placeholder
            account_name: s.account_contacts?.accounts?.name || 'Unknown',
            opportunity_name: s.opportunities?.name,
            old_sentiment: oldVal,
            new_sentiment: newVal,
            changed_at: s.changed_at,
            change_direction: (newVal && oldVal && newVal > oldVal) ? 'up' : 'down',
          } as HomeSentimentChange;
        });
    },
  });

  // Compute KPIs
  const kpis: HomeKPIs = {
    openNBAs: nbasQuery.data?.filter(n => n.status === 'pending').length || 0,
    overdueNBAs: nbasQuery.data?.filter(n => n.is_overdue).length || 0,
    stalledOpportunities: opportunitiesQuery.data?.filter(o => o.is_stalled).length || 0,
    newSignalsThisWeek: signalsQuery.data?.filter(s => 
      new Date(s.first_detected_at) >= startOfWeek(new Date())
    ).length || 0,
    activeOpportunities: opportunitiesQuery.data?.length || 0,
    sentimentChanges: sentimentChangesQuery.data?.length || 0,
  };

  // Build unified event feed
  const events: HomeEvent[] = [];

  // Add overdue/upcoming NBAs
  nbasQuery.data?.forEach(nba => {
    if (nba.is_overdue) {
      events.push({
        id: `nba-overdue-${nba.id}`,
        type: 'nba_due',
        timestamp: nba.due_date || new Date().toISOString(),
        title: 'Overdue Action',
        description: nba.action,
        account_name: nba.account_name,
        opportunity_name: nba.opportunity_name,
        opportunity_id: nba.opportunity_id || undefined,
        account_id: nba.account_id,
        priority: nba.priority,
        metadata: { nba_id: nba.id },
      });
    }
  });

  // Add signals
  signalsQuery.data?.forEach(signal => {
    events.push({
      id: `signal-${signal.id}`,
      type: 'signal_detected',
      timestamp: signal.first_detected_at,
      title: `${signal.rule_name} Signal`,
      description: signal.matched_phrases?.[0] || 'Signal detected',
      account_name: signal.account_name,
      opportunity_name: signal.opportunity_name,
      opportunity_id: signal.opportunity_id,
    });
  });

  // Add stage changes
  stageChangesQuery.data?.forEach(change => {
    events.push({
      id: `stage-${change.id}`,
      type: 'stage_change',
      timestamp: change.changed_at,
      title: `Stage Change: ${change.old_value || 'None'} → ${change.new_value}`,
      description: `${change.stage_type === 'sales_stage' ? 'Sales' : 'Pre-Sales'} stage updated`,
      account_name: change.account_name,
      opportunity_name: change.opportunity_name,
      opportunity_id: change.opportunity_id,
    });
  });

  // Add sentiment changes
  sentimentChangesQuery.data?.forEach(change => {
    events.push({
      id: `sentiment-${change.id}`,
      type: 'sentiment_change',
      timestamp: change.changed_at,
      title: `Sentiment ${change.change_direction === 'up' ? 'Improved' : 'Declined'}`,
      description: `${change.contact_name} sentiment changed`,
      account_name: change.account_name,
      opportunity_name: change.opportunity_name,
    });
  });

  // Add stalled opportunities
  opportunitiesQuery.data?.filter(o => o.is_stalled).forEach(opp => {
    events.push({
      id: `stalled-${opp.id}`,
      type: 'stalled',
      timestamp: opp.last_activity_at || new Date().toISOString(),
      title: 'Opportunity Stalled',
      description: `No activity for ${opp.days_since_activity} days`,
      account_name: opp.account_name,
      opportunity_name: opp.name,
      opportunity_id: opp.id,
      account_id: opp.account_id,
      priority: 'high',
    });
  });

  // Sort events by timestamp (most recent first)
  events.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const isLoading = 
    teamMembershipQuery.isLoading ||
    accountsQuery.isLoading || 
    opportunitiesQuery.isLoading || 
    nbasQuery.isLoading || 
    signalsQuery.isLoading ||
    stageChangesQuery.isLoading ||
    sentimentChangesQuery.isLoading;

  return {
    accounts: accountsQuery.data || [],
    opportunities: opportunitiesQuery.data || [],
    nbas: nbasQuery.data || [],
    signals: signalsQuery.data || [],
    stageChanges: stageChangesQuery.data || [],
    sentimentChanges: sentimentChangesQuery.data || [],
    kpis,
    events,
    isLoading,
    isManager: isAdmin || isManager,
  };
}

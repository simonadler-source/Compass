import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface SiblingOpportunity {
  id: string;
  name: string;
  useCaseCount: number;
  successCriteriaCount: number;
  readinessAppCount: number;
  milestoneCount: number;
  validationTaskCount: number;
  riskCount: number;
}

export type ImportCategory = 
  | 'use_cases' 
  | 'success_criteria' 
  | 'technical_readiness' 
  | 'timeline' 
  | 'validation_tasks' 
  | 'risks';

// Fetch sibling opportunities with counts of importable data
export function useSiblingOpportunities(accountId: string, excludeOpportunityId: string) {
  return useQuery({
    queryKey: ['sibling-opportunities', accountId, excludeOpportunityId],
    queryFn: async () => {
      // Get all opportunities for this account (excluding current)
      const { data: opportunities, error: oppError } = await gateway
        .from('opportunities')
        .select('id, name')
        .eq('account_id', accountId)
        .eq('is_archived', false)
        .neq('id', excludeOpportunityId)
        .execute();
      
      if (oppError) throw new Error(getErrorMessage(oppError));
      if (!opportunities || opportunities.length === 0) return [];

      const oppIds = opportunities.map((o: any) => o.id);

      // Fetch counts for each data type in parallel
      const [useCases, successCriteria, readinessApps, milestones, validationTasks, risks] = await Promise.all([
        gateway.from('account_use_cases').select('opportunity_id').in('opportunity_id', oppIds).execute(),
        gateway.from('evaluation_success_criteria').select('opportunity_id').in('opportunity_id', oppIds).execute(),
        gateway.from('opportunity_readiness_apps').select('opportunity_id').in('opportunity_id', oppIds).execute(),
        gateway.from('opportunity_milestones').select('opportunity_id').in('opportunity_id', oppIds).execute(),
        gateway.from('opportunity_validation_tasks').select('opportunity_id').in('opportunity_id', oppIds).execute(),
        gateway.from('evaluation_technical_risks').select('opportunity_id').in('opportunity_id', oppIds).execute(),
      ]);

      // Build count maps
      const countByOpp = (data: any[] | null, oppId: string) => 
        (data || []).filter((d: any) => d.opportunity_id === oppId).length;

      return opportunities.map((opp: any): SiblingOpportunity => ({
        id: opp.id,
        name: opp.name,
        useCaseCount: countByOpp(useCases.data, opp.id),
        successCriteriaCount: countByOpp(successCriteria.data, opp.id),
        readinessAppCount: countByOpp(readinessApps.data, opp.id),
        milestoneCount: countByOpp(milestones.data, opp.id),
        validationTaskCount: countByOpp(validationTasks.data, opp.id),
        riskCount: countByOpp(risks.data, opp.id),
      })).filter((o: SiblingOpportunity) => 
        // Only show opportunities with at least some data
        o.useCaseCount > 0 || o.successCriteriaCount > 0 || o.readinessAppCount > 0 || 
        o.milestoneCount > 0 || o.validationTaskCount > 0 || o.riskCount > 0
      );
    },
    enabled: !!accountId && !!excludeOpportunityId,
  });
}

// Import selected data categories from a source opportunity
export function useImportFromOpportunity() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      sourceOpportunityId,
      targetOpportunityId,
      targetAccountId,
      categories,
    }: {
      sourceOpportunityId: string;
      targetOpportunityId: string;
      targetAccountId: string;
      categories: ImportCategory[];
    }) => {
      const results: Record<string, number> = {};

      // Import Use Cases
      if (categories.includes('use_cases')) {
        const { data: useCases } = await gateway
          .from('account_use_cases')
          .select('*')
          .eq('opportunity_id', sourceOpportunityId)
          .execute();

        if (useCases && useCases.length > 0) {
          const copies = useCases.map((uc: any) => ({
            account_id: targetAccountId,
            opportunity_id: targetOpportunityId,
            functional_area: uc.functional_area,
            use_case: uc.use_case,
            description: uc.description,
            status: uc.status || 'identified',
            priority: uc.priority,
            source: 'imported',
            sort_order: uc.sort_order,
            radar_x: uc.radar_x,
            radar_y: uc.radar_y,
            business_theme: uc.business_theme,
            business_outcome: uc.business_outcome,
            solution_description: uc.solution_description,
          }));

          const { error } = await gateway.from('account_use_cases').insert(copies).execute();
          if (error) throw new Error(getErrorMessage(error));
          results.use_cases = copies.length;
        }
      }

      // Import Success Criteria
      if (categories.includes('success_criteria')) {
        const { data: criteria } = await gateway
          .from('evaluation_success_criteria')
          .select('*')
          .eq('opportunity_id', sourceOpportunityId)
          .execute();

        if (criteria && criteria.length > 0) {
          for (const crit of criteria) {
            // Insert criterion
            const { data: newCrit, error: critError } = await gateway
              .from('evaluation_success_criteria')
              .insert({
                opportunity_id: targetOpportunityId,
                criterion: crit.criterion,
                metric_name: crit.metric_name,
                target_value: crit.target_value,
                status: 'new',
                notes: crit.notes,
                source: 'imported',
              })
              .select('id')
              .single()
              .execute();
            if (critError) throw new Error(getErrorMessage(critError));

            // Copy deliverables if any
            if (newCrit) {
              const { data: deliverables } = await gateway
                .from('success_criteria_deliverables')
                .select('*')
                .eq('criterion_id', crit.id)
                .execute();

              if (deliverables && deliverables.length > 0) {
                const delivCopies = deliverables.map((d: any) => ({
                  criterion_id: (newCrit as any).id,
                  title: d.title,
                  is_completed: false,
                  sort_order: d.sort_order,
                }));
                await gateway.from('success_criteria_deliverables').insert(delivCopies).execute();
              }
            }
          }
          results.success_criteria = criteria.length;
        }
      }

      // Import Technical Readiness (apps + answers)
      if (categories.includes('technical_readiness')) {
        const { data: apps } = await gateway
          .from('opportunity_readiness_apps')
          .select('*')
          .eq('opportunity_id', sourceOpportunityId)
          .execute();

        if (apps && apps.length > 0) {
          let importedCount = 0;
          for (const app of apps) {
            // Get current max sort_order
            const { data: existing } = await gateway
              .from('opportunity_readiness_apps')
              .select('sort_order')
              .eq('opportunity_id', targetOpportunityId)
              .order('sort_order', { ascending: false })
              .limit(1)
              .execute();

            const nextOrder = existing && existing.length > 0 ? (existing[0] as any).sort_order + 1 : 0;

            const { data: newApp, error: appError } = await gateway
              .from('opportunity_readiness_apps')
              .insert({
                opportunity_id: targetOpportunityId,
                app_name: (app as any).app_name,
                is_primary: nextOrder === 0,
                sort_order: nextOrder,
              })
              .select('id')
              .single()
              .execute();
            if (appError) throw new Error(getErrorMessage(appError));

            // Copy answers
            const { data: answers } = await gateway
              .from('opportunity_readiness_answers')
              .select('*')
              .eq('opportunity_id', sourceOpportunityId)
              .eq('app_id', (app as any).id)
              .execute();

            if (answers && answers.length > 0 && newApp) {
              const answerCopies = answers.map((a: any) => ({
                opportunity_id: targetOpportunityId,
                question_id: a.question_id,
                app_id: (newApp as any).id,
                answer: a.answer,
                answer_json: a.answer_json,
                confidence_score: a.confidence_score,
                source: 'imported',
                notes: a.notes,
                is_red_flag: a.is_red_flag,
                manual_flag_status: a.manual_flag_status,
              }));
              await gateway
                .from('opportunity_readiness_answers')
                .upsert(answerCopies, { onConflict: 'opportunity_id,question_id,app_id' })
                .execute();
            }
            importedCount++;
          }
          results.technical_readiness = importedCount;
        }
      }

      // Import Timeline (milestones)
      if (categories.includes('timeline')) {
        const { data: milestones } = await gateway
          .from('opportunity_milestones')
          .select('*')
          .eq('opportunity_id', sourceOpportunityId)
          .execute();

        if (milestones && milestones.length > 0) {
          const copies = milestones.map((m: any) => ({
            opportunity_id: targetOpportunityId,
            template_id: m.template_id,
            name: m.name,
            phase: m.phase,
            status: 'not_scheduled',
            sort_order: m.sort_order,
            owner_email: m.owner_email,
            notes: m.notes,
          }));

          const { error } = await gateway.from('opportunity_milestones').insert(copies).execute();
          if (error) throw new Error(getErrorMessage(error));
          results.timeline = copies.length;
        }
      }

      // Import Validation Tasks
      if (categories.includes('validation_tasks')) {
        const { data: tasks } = await gateway
          .from('opportunity_validation_tasks')
          .select('*')
          .eq('opportunity_id', sourceOpportunityId)
          .execute();

        if (tasks && tasks.length > 0) {
          const copies = tasks.map((t: any) => ({
            opportunity_id: targetOpportunityId,
            activity: t.activity || t.task_name || 'Untitled Task',
            template_id: t.template_id,
            module: t.module,
            sub_module: t.sub_module,
            task_name: t.task_name,
            description: t.description,
            status: 'not_started',
            sort_order: t.sort_order,
            deployment_type_id: t.deployment_type_id,
          }));

          const { error } = await gateway.from('opportunity_validation_tasks').insert(copies).execute();
          if (error) throw new Error(getErrorMessage(error));
          results.validation_tasks = copies.length;
        }
      }

      // Import Risks & Issues
      if (categories.includes('risks')) {
        const { data: risks } = await gateway
          .from('evaluation_technical_risks')
          .select('*')
          .eq('opportunity_id', sourceOpportunityId)
          .execute();

        if (risks && risks.length > 0) {
          const copies = risks.map((r: any) => ({
            opportunity_id: targetOpportunityId,
            risk_description: r.risk_description,
            severity: r.severity,
            status: 'new',
            mitigation_plan: r.mitigation_plan,
            owner_email: r.owner_email,
            source: 'imported',
          }));

          const { error } = await gateway.from('evaluation_technical_risks').insert(copies).execute();
          if (error) throw new Error(getErrorMessage(error));
          results.risks = copies.length;
        }
      }

      return results;
    },
    onSuccess: (results, { targetOpportunityId, targetAccountId }) => {
      // Invalidate all relevant queries
      queryClient.invalidateQueries({ queryKey: ['opportunity-use-cases', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', targetAccountId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-success-criteria', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['eval-deck-criteria', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['readiness-apps', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-milestones', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-validation-tasks', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['technical-risks', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['eval-deck-risks', targetOpportunityId] });

      const imported = Object.entries(results)
        .filter(([_, count]) => count > 0)
        .map(([key, count]) => `${count} ${key.replace(/_/g, ' ')}`)
        .join(', ');

      toast.success(`Imported: ${imported || 'nothing to import'}`);
    },
    onError: (error) => {
      toast.error('Import failed: ' + (error instanceof Error ? error.message : 'Unknown error'));
    },
  });
}

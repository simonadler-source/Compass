import { supabase } from '@/integrations/supabase/client';
import { encryptedInsert, encryptedUpdate } from '@/lib/encryptedDb';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

// Pain category labels - describes TYPE of pain
export const painCategoryLabels: Record<string, string> = {
  vendor_relationship: 'Vendor Relationship',
  technical_limitations: 'Technical Limitations',
  operational_friction: 'Operational Friction',
  resource_constraints: 'Resource Constraints',
  strategic_misalignment: 'Strategic Misalignment',
};

export const painCategoryColors: Record<string, string> = {
  vendor_relationship: 'hsl(25, 80%, 50%)',     // Orange - frustration
  technical_limitations: 'hsl(199, 89%, 48%)',  // Blue - technical
  operational_friction: 'hsl(45, 80%, 45%)',    // Yellow - process
  resource_constraints: 'hsl(0, 70%, 45%)',     // Red - constraints
  strategic_misalignment: 'hsl(262, 80%, 50%)', // Purple - strategic
};

export const painCategoryIcons: Record<string, string> = {
  vendor_relationship: 'HeartHandshake',
  technical_limitations: 'CircuitBoard',
  operational_friction: 'Settings',
  resource_constraints: 'Users',
  strategic_misalignment: 'Compass',
};

// Business impact labels - potential outcomes
export const businessImpactLabels: Record<string, string> = {
  revenue_enablement: 'Revenue Enablement',
  cost_reduction: 'Cost Reduction',
  risk_mitigation: 'Risk Mitigation',
  efficiency_gains: 'Efficiency Gains',
};

export const businessImpactColors: Record<string, string> = {
  revenue_enablement: 'hsl(142, 70%, 45%)',
  cost_reduction: 'hsl(45, 80%, 45%)',
  risk_mitigation: 'hsl(0, 70%, 45%)',
  efficiency_gains: 'hsl(199, 89%, 48%)',
};

// Legacy support - keep business theme labels for backwards compatibility
export const businessThemeLabels: Record<string, string> = {
  operational_efficiency: 'Operational Efficiency',
  customer_experience: 'Customer Experience',
  revenue_growth: 'Revenue Growth',
  cost_reduction: 'Cost Reduction',
  compliance_risk: 'Compliance & Risk',
  digital_transformation: 'Digital Transformation',
  data_insights: 'Data & Insights',
  team_productivity: 'Team Productivity',
};

export const businessThemeColors: Record<string, string> = {
  operational_efficiency: 'hsl(199, 89%, 48%)',
  customer_experience: 'hsl(142, 70%, 45%)',
  revenue_growth: 'hsl(45, 80%, 45%)',
  cost_reduction: 'hsl(25, 80%, 50%)',
  compliance_risk: 'hsl(0, 70%, 45%)',
  digital_transformation: 'hsl(262, 80%, 50%)',
  data_insights: 'hsl(280, 65%, 55%)',
  team_productivity: 'hsl(180, 60%, 45%)',
};

interface ThemedPainPoint {
  description: string;
  businessTheme: string;
  severity: 'high' | 'medium' | 'low';
  confidence: number;
}

interface ThemedUseCase {
  description: string;
  businessTheme: string;
  priority: 'high' | 'medium' | 'low';
  confidence: number;
}

// Calculate similarity between two strings (simple Jaccard similarity)
function calculateSimilarity(str1: string, str2: string): number {
  const words1 = new Set(str1.toLowerCase().split(/\s+/).filter(w => w.length > 3));
  const words2 = new Set(str2.toLowerCase().split(/\s+/).filter(w => w.length > 3));
  
  const intersection = new Set([...words1].filter(x => words2.has(x)));
  const union = new Set([...words1, ...words2]);
  
  return union.size > 0 ? intersection.size / union.size : 0;
}

// Find similar existing use cases
async function findSimilarUseCases(
  accountId: string,
  newUseCase: string,
  threshold = 0.4
): Promise<{ id: string; use_case: string; similarity: number; confidence_score: number | null }[]> {
  const { data: existingUseCases } = await supabase
    .from('account_use_cases')
    .select('id, use_case, confidence_score')
    .eq('account_id', accountId);

  if (!existingUseCases) return [];

  return existingUseCases
    .map(uc => ({
      ...uc,
      similarity: calculateSimilarity(newUseCase, uc.use_case),
    }))
    .filter(uc => uc.similarity >= threshold)
    .sort((a, b) => b.similarity - a.similarity);
}

// Find similar existing pain points
async function findSimilarPainPoints(
  accountId: string,
  newPainPoint: string,
  threshold = 0.4
): Promise<{ id: string; pain_point: string; similarity: number; confidence_score: number | null }[]> {
  const { data: existingPainPoints } = await supabase
    .from('account_pain_points')
    .select('id, pain_point, confidence_score')
    .eq('account_id', accountId);

  if (!existingPainPoints) return [];

  return existingPainPoints
    .map(pp => ({
      ...pp,
      similarity: calculateSimilarity(newPainPoint, pp.pain_point),
    }))
    .filter(pp => pp.similarity >= threshold)
    .sort((a, b) => b.similarity - a.similarity);
}

// Save use case with enrichment (merge or create)
export async function saveUseCaseWithEnrichment(
  accountId: string,
  useCase: ThemedUseCase,
  opportunityId?: string | null,
  transcriptId?: string | null
): Promise<{ action: 'created' | 'merged' | 'updated'; id: string }> {
  // Find similar existing use cases
  const similar = await findSimilarUseCases(accountId, useCase.description);
  
  if (similar.length > 0 && similar[0].similarity >= 0.6) {
    // High similarity - merge/update existing
    const existing = similar[0];
    const newConfidence = Math.min(
      1.0,
      (existing.confidence_score || 0.5) + (useCase.confidence * 0.2)
    );
    
    // First get current validation count
    const { data: currentData } = await supabase
      .from('account_use_cases')
      .select('validation_count')
      .eq('id', existing.id)
      .single();
    
    const newValidationCount = ((currentData?.validation_count as number) || 0) + 1;
    
    const { error } = await supabase
      .from('account_use_cases')
      .update({
        confidence_score: newConfidence,
        validation_count: newValidationCount,
        last_validated_at: new Date().toISOString(),
        business_theme: useCase.businessTheme,
        theme_confidence: useCase.confidence,
        priority: useCase.priority,
      })
      .eq('id', existing.id);
    
    if (error) console.error('Failed to update use case:', error);
    return { action: 'merged', id: existing.id };
    
  } else {
    // New use case - create via encrypted insert
    const { data, error } = await encryptedInsert('account_use_cases', {
      account_id: accountId,
      opportunity_id: opportunityId,
      use_case: useCase.description,
      functional_area: 'General',
      business_theme: useCase.businessTheme,
      theme_confidence: useCase.confidence,
      confidence_score: useCase.confidence,
      priority: useCase.priority,
      status: 'identified',
      source: 'transcript_analysis',
      source_transcript_id: transcriptId,
    });
    
    if (error) {
      console.error('Failed to create use case:', error);
      // Try upsert if it already exists
      const { data: upsertData } = await supabase
        .from('account_use_cases')
        .upsert({
          account_id: accountId,
          use_case: useCase.description,
          functional_area: 'General',
          business_theme: useCase.businessTheme,
          theme_confidence: useCase.confidence,
          confidence_score: useCase.confidence,
          priority: useCase.priority,
        }, { onConflict: 'account_id,use_case' })
        .select('id')
        .single();
      return { action: 'updated', id: upsertData?.id || '' };
    }
    return { action: 'created', id: (data as unknown as { id: string })?.id || '' };
  }
}

// Save pain point with enrichment (merge or create)
export async function savePainPointWithEnrichment(
  accountId: string,
  painPoint: ThemedPainPoint,
  opportunityId?: string | null,
  transcriptId?: string | null
): Promise<{ action: 'created' | 'merged' | 'updated'; id: string }> {
  // Find similar existing pain points
  const similar = await findSimilarPainPoints(accountId, painPoint.description);
  
  if (similar.length > 0 && similar[0].similarity >= 0.6) {
    // High similarity - merge/update existing
    const existing = similar[0];
    const newConfidence = Math.min(
      1.0,
      (existing.confidence_score || 0.5) + (painPoint.confidence * 0.2)
    );
    
    // First get current validation count
    const { data: currentData } = await supabase
      .from('account_pain_points')
      .select('validation_count')
      .eq('id', existing.id)
      .single();
    
    const newValidationCount = ((currentData?.validation_count as number) || 0) + 1;
    
    const { error } = await encryptedUpdate('account_pain_points', existing.id, {
      confidence_score: newConfidence,
      validation_count: newValidationCount,
      last_validated_at: new Date().toISOString(),
      business_theme: painPoint.businessTheme,
      theme_confidence: painPoint.confidence,
      severity: painPoint.severity,
    });
    
    if (error) console.error('Failed to update pain point:', error);
    return { action: 'merged', id: existing.id };
    
  } else {
    // New pain point - create via encrypted insert
    const { data, error } = await encryptedInsert('account_pain_points', {
      account_id: accountId,
      opportunity_id: opportunityId,
      pain_point: painPoint.description,
      business_theme: painPoint.businessTheme,
      theme_confidence: painPoint.confidence,
      confidence_score: painPoint.confidence,
      severity: painPoint.severity,
      source: 'transcript_analysis',
      source_transcript_id: transcriptId,
    });
    
    if (error) {
      console.error('Failed to create pain point:', error);
      return { action: 'updated', id: '' };
    }
    return { action: 'created', id: (data as unknown as { id: string })?.id || '' };
  }
}

// Batch save with enrichment stats
export async function saveInsightsWithEnrichment(
  accountId: string,
  painPoints: ThemedPainPoint[],
  useCases: ThemedUseCase[],
  opportunityId?: string | null,
  transcriptId?: string | null
): Promise<{
  painPoints: { created: number; merged: number; updated: number };
  useCases: { created: number; merged: number; updated: number };
}> {
  const stats = {
    painPoints: { created: 0, merged: 0, updated: 0 },
    useCases: { created: 0, merged: 0, updated: 0 },
  };

  // Process pain points
  for (const pp of painPoints) {
    const result = await savePainPointWithEnrichment(
      accountId,
      pp,
      opportunityId,
      transcriptId
    );
    stats.painPoints[result.action]++;
  }

  // Process use cases
  for (const uc of useCases) {
    const result = await saveUseCaseWithEnrichment(
      accountId,
      uc,
      opportunityId,
      transcriptId
    );
    stats.useCases[result.action]++;
  }

  return stats;
}

// NBA deduplication types
export interface NBAInput {
  action: string;
  actionType?: string;
  ownerEmail?: string;
  ownerName?: string;
  ownerType?: string;
  priority?: string;
  deliveryMethod?: string;
  reasoning?: string;
  dueDate?: string;
}

// Default due date offsets by action type (in days)
const DUE_DATE_OFFSETS: Record<string, number> = {
  follow_up_meeting: 3,       // 3 business days
  send_content: 2,            // 1-2 business days
  poc_setup: 10,              // 1-2 weeks
  technical_deepdive: 7,      // 1 week
  security_assessment: 14,    // 2-3 weeks
  architecture_doc: 7,        // 1 week
  integration_review: 7,      // 1 week
  api_exploration: 5,         // ~1 week
  performance_benchmark: 10,  // 1-2 weeks
  internal_discussion: 3,     // 3 business days
  follow_up: 3,               // default follow-up
};

// Calculate fallback due date based on action type
function calculateFallbackDueDate(actionType?: string): string {
  const today = new Date();
  const offsetDays = DUE_DATE_OFFSETS[actionType || 'follow_up'] || 5;
  today.setDate(today.getDate() + offsetDays);
  return today.toISOString().split('T')[0];
}

// Key action verbs that indicate the core intent of an NBA
const ACTION_VERBS = [
  'send', 'schedule', 'align', 'follow', 'consolidate', 'hold', 'conduct',
  'engage', 'prepare', 'create', 'book', 'set', 'organize', 'arrange',
  'discuss', 'review', 'share', 'provide', 'get', 'bring', 'invite'
];

// Extract key semantic elements from an action string
function extractSemanticElements(action: string): { 
  verb: string | null; 
  entities: Set<string>;
  keywords: Set<string>;
} {
  const normalized = action.toLowerCase().trim();
  const words = normalized.split(/\s+/);
  
  // Find the main action verb
  const verb = words.find(w => ACTION_VERBS.some(v => w.startsWith(v))) || null;
  
  // Extract potential named entities (capitalized words in original, names, roles)
  const entityPattern = /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g;
  const entities = new Set<string>();
  const matches = action.match(entityPattern) || [];
  matches.forEach(m => {
    const lower = m.toLowerCase();
    // Skip common words that happen to be capitalized
    if (!['the', 'and', 'for', 'with', 'after', 'before', 'next', 'internal', 'meeting'].includes(lower)) {
      entities.add(lower);
    }
  });
  
  // Extract key nouns/keywords (longer meaningful words)
  const stopWords = new Set(['the', 'and', 'for', 'with', 'after', 'before', 'their', 'from', 'about', 'into', 'that', 'this', 'will', 'should', 'could', 'would', 'have', 'been', 'being', 'next', 'steps', 'based', 'across', 'including', 'understand']);
  const keywords = new Set(
    words
      .map(w => w.replace(/[^\w]/g, ''))
      .filter(w => w.length > 3 && !stopWords.has(w))
  );
  
  return { verb, entities, keywords };
}

// Calculate similarity between two strings for NBA deduplication
function calculateNBASimilarity(str1: string, str2: string): number {
  // Normalize strings for comparison
  const normalize = (s: string) => s.toLowerCase().trim().replace(/[^\w\s]/g, '');
  const n1 = normalize(str1);
  const n2 = normalize(str2);
  
  // Exact match
  if (n1 === n2) return 1.0;
  
  // Extract semantic elements
  const sem1 = extractSemanticElements(str1);
  const sem2 = extractSemanticElements(str2);
  
  // Check for same action verb - strong indicator of similarity
  const sameVerb = sem1.verb && sem2.verb && sem1.verb === sem2.verb;
  
  // Check for shared entities (names, roles)
  const sharedEntities = [...sem1.entities].filter(e => sem2.entities.has(e));
  const entityOverlap = sharedEntities.length > 0;
  
  // Use Jaccard similarity on keywords
  const intersection = new Set([...sem1.keywords].filter(x => sem2.keywords.has(x)));
  const union = new Set([...sem1.keywords, ...sem2.keywords]);
  const jaccardSimilarity = union.size > 0 ? intersection.size / union.size : 0;
  
  // Boost similarity if same verb or shared entities
  let finalScore = jaccardSimilarity;
  if (sameVerb) finalScore = Math.max(finalScore, 0.4) + 0.2;
  if (entityOverlap) finalScore += 0.15;
  
  // Cap at 1.0
  return Math.min(finalScore, 1.0);
}

// Find similar existing NBAs
async function findSimilarNBAs(
  accountId: string,
  opportunityId: string | null | undefined,
  newAction: string,
  threshold = 0.45 // Lower threshold to catch more semantic duplicates
): Promise<{ id: string; action: string; similarity: number; status: string | null }[]> {
  // Look across the entire account, not just the opportunity
  // This catches duplicates that were created for different opportunities
  const { data: existingNBAs } = await gateway
    .from('account_nbas')
    .select('id, action, status')
    .eq('account_id', accountId)
    .execute();

  if (!existingNBAs) return [];

  return existingNBAs
    .filter(nba => nba.action != null)
    .map(nba => ({
      ...nba,
      similarity: calculateNBASimilarity(newAction, nba.action!),
    }))
    .filter(nba => nba.similarity >= threshold)
    .sort((a, b) => b.similarity - a.similarity);
}

// Save NBA with deduplication (skip if similar exists)
export async function saveNBAWithDeduplication(
  accountId: string,
  nba: NBAInput,
  opportunityId?: string | null,
  transcriptId?: string | null
): Promise<{ action: 'created' | 'skipped'; id: string; reason?: string }> {
  // Find similar existing NBAs (threshold is now 0.45 to catch more semantic duplicates)
  const similar = await findSimilarNBAs(accountId, opportunityId, nba.action, 0.45);
  
  if (similar.length > 0 && similar[0].similarity >= 0.45) {
    // Similarity found - skip to avoid duplicate
    console.log(`Skipping duplicate NBA: "${nba.action}" matches "${similar[0].action}" (${Math.round(similar[0].similarity * 100)}%)`);
    return { 
      action: 'skipped', 
      id: similar[0].id,
      reason: `Similar NBA exists: "${similar[0].action}" (${Math.round(similar[0].similarity * 100)}% match)`
    };
  }
  
  // New NBA - create via encrypted insert
  // Use AI-provided due date, or calculate fallback based on action type
  const finalDueDate = nba.dueDate || calculateFallbackDueDate(nba.actionType);
  
  const { data, error } = await encryptedInsert('account_nbas', {
    account_id: accountId,
    opportunity_id: opportunityId,
    action: nba.action,
    action_type: nba.actionType || 'follow_up',
    assigned_to: nba.ownerEmail || nba.ownerName || nba.ownerType || 'sales_engineer',
    priority: nba.priority || 'medium',
    delivery_method: nba.deliveryMethod || 'email',
    notes: nba.ownerName ? `Owner: ${nba.ownerName}. ${nba.reasoning || ''}`.trim() : (nba.reasoning || null),
    source_transcript_id: transcriptId,
    status: 'pending',
    due_date: finalDueDate,
  });
  
  if (error) {
    console.error('Failed to create NBA:', error);
    return { action: 'skipped', id: '', reason: error.message };
  }
  
  return { action: 'created', id: (data as unknown as { id: string })?.id || '' };
}

// Batch save NBAs with deduplication
export async function saveNBAsWithDeduplication(
  accountId: string,
  nbas: NBAInput[],
  opportunityId?: string | null,
  transcriptId?: string | null
): Promise<{ created: number; skipped: number }> {
  const stats = { created: 0, skipped: 0 };
  
  for (const nba of nbas) {
    const result = await saveNBAWithDeduplication(
      accountId,
      nba,
      opportunityId,
      transcriptId
    );
    stats[result.action]++;
  }
  
  return stats;
}

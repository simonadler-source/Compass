import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface InsightSnapshot {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  source_transcript_id: string | null;
  insight_type: string;
  data_cleartext: Record<string, any>;
  data_encrypted: string | null;
  encryption_iv: string | null;
  field_encryption_map: Record<string, boolean>;
  version_number: number;
  previous_snapshot_id: string | null;
  change_source: string;
  change_reason: string | null;
  captured_at: string;
  valid_from: string;
  valid_to: string | null;
  created_at: string;
}

export interface TrendMetric {
  id: string;
  account_id: string | null;
  metric_date: string;
  insight_type: string;
  category_counts: Record<string, number>;
  severity_distribution: Record<string, number>;
  priority_distribution: Record<string, number>;
  theme_counts: Record<string, number>;
  avg_confidence: number | null;
  total_count: number;
  new_count: number;
  resolved_count: number;
}

// Fetch current (active) insights for an account
export function useAccountInsights(accountId: string | null, insightType?: string) {
  return useQuery({
    queryKey: ['account-insights', accountId, insightType],
    queryFn: async () => {
      if (!accountId) return [];
      
      let query = supabase
        .from('account_insight_snapshots')
        .select('*')
        .eq('account_id', accountId)
        .is('valid_to', null)
        .order('captured_at', { ascending: false });
      
      if (insightType) {
        query = query.eq('insight_type', insightType);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data as InsightSnapshot[];
    },
    enabled: !!accountId,
  });
}

// Fetch insight history (all versions) for trending
export function useInsightHistory(
  accountId: string | null, 
  insightType: string,
  fromDate?: Date,
  toDate?: Date
) {
  return useQuery({
    queryKey: ['insight-history', accountId, insightType, fromDate?.toISOString(), toDate?.toISOString()],
    queryFn: async () => {
      if (!accountId) return [];
      
      let query = supabase
        .from('account_insight_snapshots')
        .select('*')
        .eq('account_id', accountId)
        .eq('insight_type', insightType)
        .order('valid_from', { ascending: true });
      
      if (fromDate) {
        query = query.gte('valid_from', fromDate.toISOString());
      }
      if (toDate) {
        query = query.lte('valid_from', toDate.toISOString());
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data as InsightSnapshot[];
    },
    enabled: !!accountId,
  });
}

// Fetch trend metrics for an account or portfolio
export function useInsightTrends(
  accountId: string | null, // null for portfolio-wide
  insightType: string,
  fromDate: Date,
  toDate: Date
) {
  return useQuery({
    queryKey: ['insight-trends', accountId, insightType, fromDate.toISOString(), toDate.toISOString()],
    queryFn: async () => {
      let query = supabase
        .from('insight_trend_metrics')
        .select('*')
        .eq('insight_type', insightType)
        .gte('metric_date', fromDate.toISOString().split('T')[0])
        .lte('metric_date', toDate.toISOString().split('T')[0])
        .order('metric_date', { ascending: true });
      
      if (accountId) {
        query = query.eq('account_id', accountId);
      } else {
        query = query.is('account_id', null);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data as TrendMetric[];
    },
  });
}

// Aggregate current insights by category for an account
export function useInsightAggregates(accountId: string | null, insightType: string) {
  return useQuery({
    queryKey: ['insight-aggregates', accountId, insightType],
    queryFn: async () => {
      if (!accountId) return null;
      
      const { data, error } = await supabase
        .from('account_insight_snapshots')
        .select('data_cleartext')
        .eq('account_id', accountId)
        .eq('insight_type', insightType)
        .is('valid_to', null);
      
      if (error) throw error;
      
      // Aggregate in memory
      const aggregates = {
        total: data.length,
        byCategory: {} as Record<string, number>,
        bySeverity: {} as Record<string, number>,
        byPriority: {} as Record<string, number>,
        byTheme: {} as Record<string, number>,
        avgConfidence: 0,
      };
      
      let confidenceSum = 0;
      let confidenceCount = 0;
      
      for (const row of data) {
        const d = row.data_cleartext as Record<string, any>;
        
        // Category (painCategory or businessTheme)
        const cat = d.painCategory || d.category;
        if (cat) {
          aggregates.byCategory[cat] = (aggregates.byCategory[cat] || 0) + 1;
        }
        
        // Severity
        if (d.severity) {
          aggregates.bySeverity[d.severity] = (aggregates.bySeverity[d.severity] || 0) + 1;
        }
        
        // Priority
        if (d.priority) {
          aggregates.byPriority[d.priority] = (aggregates.byPriority[d.priority] || 0) + 1;
        }
        
        // Theme
        if (d.businessTheme) {
          aggregates.byTheme[d.businessTheme] = (aggregates.byTheme[d.businessTheme] || 0) + 1;
        }
        
        // Confidence
        if (typeof d.confidence === 'number') {
          confidenceSum += d.confidence;
          confidenceCount++;
        }
      }
      
      if (confidenceCount > 0) {
        aggregates.avgConfidence = confidenceSum / confidenceCount;
      }
      
      return aggregates;
    },
    enabled: !!accountId,
  });
}

// Decrypt an insight's encrypted data
export function useDecryptInsight() {
  return useMutation({
    mutationFn: async ({ snapshotId }: { snapshotId: string }) => {
      const { data, error } = await supabase.functions.invoke('decrypt-pii', {
        body: { 
          table: 'account_insight_snapshots',
          id: snapshotId,
          field: 'data_encrypted'
        }
      });
      
      if (error) throw error;
      return data as { decrypted: Record<string, any> };
    },
  });
}

// Create a new version of an insight (for manual edits)
export function useUpdateInsight() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      previousSnapshotId,
      accountId,
      opportunityId,
      insightType,
      dataCleartext,
      dataEncrypted,
      encryptionIv,
      fieldEncryptionMap,
      changeReason,
    }: {
      previousSnapshotId: string;
      accountId: string;
      opportunityId?: string;
      insightType: string;
      dataCleartext: Record<string, any>;
      dataEncrypted?: string;
      encryptionIv?: string;
      fieldEncryptionMap: Record<string, boolean>;
      changeReason?: string;
    }) => {
      // Get current version number
      const { data: current, error: fetchError } = await supabase
        .from('account_insight_snapshots')
        .select('version_number, source_transcript_id')
        .eq('id', previousSnapshotId)
        .single();
      
      if (fetchError) throw fetchError;
      
      // Insert new version (trigger will close the previous one)
      const { data: inserted, error } = await gateway
        .from('account_insight_snapshots')
        .insert({
          account_id: accountId,
          opportunity_id: opportunityId,
          source_transcript_id: current.source_transcript_id,
          insight_type: insightType,
          data_cleartext: dataCleartext,
          data_encrypted: dataEncrypted,
          encryption_iv: encryptionIv,
          field_encryption_map: fieldEncryptionMap,
          version_number: current.version_number + 1,
          previous_snapshot_id: previousSnapshotId,
          change_source: 'manual_edit',
          change_reason: changeReason,
        })
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      const data = Array.isArray(inserted) ? inserted[0] : inserted;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['account-insights', data.account_id] });
      toast.success('Insight updated');
    },
    onError: (error: Error) => {
      toast.error(`Failed to update insight: ${error.message}`);
    },
  });
}

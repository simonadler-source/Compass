import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

interface InviteResponse {
  success: boolean;
  message?: string;
  error?: string;
  existing?: boolean;
}

export const useInviteTeamMember = () => {
  const queryClient = useQueryClient();
  const { getSessionToken } = useAuth();

  const inviteMutation = useMutation({
    mutationFn: async ({ email, name }: { email: string; name?: string }): Promise<InviteResponse> => {
      const token = getSessionToken();
      if (!token) {
        throw new Error("Not authenticated");
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/auth`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
            "apikey": import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          },
          body: JSON.stringify({ action: 'invite-user', email, name }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to send invite");
      }

      if (!data.success && !data.existing) {
        throw new Error(data.error || "Failed to send invite");
      }

      return data;
    },
    onSuccess: (data, variables) => {
      if (data.existing) {
        toast.info(`${variables.email} already has an account`);
      } else {
        toast.success(`Invitation sent to ${variables.email}`);
      }
      queryClient.invalidateQueries({ queryKey: ["team-members"] });
      queryClient.invalidateQueries({ queryKey: ["all-users"] });
    },
    onError: (error: Error, variables) => {
      toast.error(`Failed to invite ${variables.email}: ${error.message}`);
    },
  });

  const inviteMultiple = async (members: Array<{ email: string; name?: string }>) => {
    const results = await Promise.allSettled(
      members.map((member) => inviteMutation.mutateAsync(member))
    );

    const successful = results.filter((r) => r.status === "fulfilled").length;
    const failed = results.filter((r) => r.status === "rejected").length;

    if (successful > 0 && failed === 0) {
      toast.success(`All ${successful} invitations sent successfully`);
    } else if (successful > 0 && failed > 0) {
      toast.warning(`${successful} invites sent, ${failed} failed`);
    }

    return results;
  };

  return {
    invite: inviteMutation.mutate,
    inviteAsync: inviteMutation.mutateAsync,
    inviteMultiple,
    isLoading: inviteMutation.isPending,
  };
};

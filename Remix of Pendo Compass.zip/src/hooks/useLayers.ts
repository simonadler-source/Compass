import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface Layer {
  id: string;
  name: string;
  label: string;
  subtitle: string | null;
  color: string;
  bg_color: string;
  line_color: string;
  height: number;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export function useLayers() {
  return useQuery({
    queryKey: ['layers'],
    queryFn: async () => {
      const result = await gateway.from('layers')
        .select('*')
        .order('sort_order', { ascending: true })
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data as Layer[];
    },
  });
}

export function useCreateLayer() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (layer: {
      name: string;
      label: string;
      subtitle?: string;
      color?: string;
      bg_color?: string;
      line_color?: string;
      height?: number;
      sort_order?: number;
    }) => {
      const result = await gateway.from('layers')
        .insert(layer)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['layers'] });
      toast.success('Layer created');
    },
    onError: (error) => {
      console.error('Failed to create layer:', error);
      toast.error('Failed to create layer');
    },
  });
}

export function useUpdateLayer() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ...updates }: {
      id: string;
      name?: string;
      label?: string;
      subtitle?: string | null;
      color?: string;
      bg_color?: string;
      line_color?: string;
      height?: number;
      sort_order?: number;
    }) => {
      const result = await gateway.from('layers')
        .update(updates)
        .eq('id', id)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['layers'] });
    },
    onError: (error) => {
      console.error('Failed to update layer:', error);
      toast.error('Failed to update layer');
    },
  });
}

export function useDeleteLayer() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      const result = await gateway.from('layers')
        .delete()
        .eq('id', id)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['layers'] });
      toast.success('Layer deleted');
    },
    onError: (error) => {
      console.error('Failed to delete layer:', error);
      toast.error('Failed to delete layer');
    },
  });
}

export function useReorderLayers() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (layers: { id: string; sort_order: number }[]) => {
      // Process updates sequentially through the gateway
      for (const { id, sort_order } of layers) {
        const result = await gateway.from('layers')
          .update({ sort_order })
          .eq('id', id)
          .execute();
        
        if (result.error) throw new Error(result.error.message);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['layers'] });
    },
    onError: (error) => {
      console.error('Failed to reorder layers:', error);
      toast.error('Failed to reorder layers');
    },
  });
}

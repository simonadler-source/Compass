import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useTeamMembers } from './useTeamMembers';
import { useAuth } from '@/contexts/AuthContext';
import { useMemo } from 'react';

interface CoachingNBA {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  action: string | null;
  notes: string | null;
  priority: string | null;
  created_at: string;
  accounts: { id: string; name: string };
  opportunities: { id: string; name: string; owner_email: string | null; primary_se_email: string | null; value: number | null; close_date: string | null } | null;
}

export interface OpportunityAlert {
  id: string;
  opportunityId: string;
  opportunityName: string;
  accountId: string;
  accountName: string;
  ownerEmail: string | null;
  ownerName: string | null;
  primarySeEmail: string | null;
  primarySeName: string | null;
  teamMemberEmails?: string[];
  alertType: string;
  alertLevel: 'critical' | 'warning' | 'info';
  alertMessage: string;
  ruleName: string;
  ruleId: string;
  isSystemRule: boolean;
  triggeredAt: string;
  stage: string | null;
  value: number | null;
  closeDate: string | null;
}

interface OpportunityWithDetails {
  id: string;
  name: string;
  account_id: string;
  stage: string | null;
  sales_stage: string | null;
  pre_sales_stage: string | null;
  readiness_score: number | null;
  detection_signal_fields: Record<string, { detected_at: string; transcript_id?: string; confidence_score?: number }> | null;
  value: number | null;
  close_date: string | null;
  owner_email: string | null;
  primary_se_email: string | null;
  last_meeting_at: string | null;
  stage_changed_at: string | null;
  created_at: string;
  team_member_emails?: string[];
  accounts: {
    id: string;
    name: string;
    owner_id: string | null;
    primary_se_email?: string | null;
  };
}

export function useManagerDashboard() {
  const { teamEmails, teamEmailsWithSelf, teamMembers, hierarchyTeamMembers, isLoading: teamLoading } = useTeamMembers();


  // First, fetch all opportunity IDs where team members are assigned via opportunity_team_members
  const { data: teamOpportunityIds } = useQuery({
    queryKey: ['manager-team-opportunity-ids', teamEmailsWithSelf],
    queryFn: async () => {
      if (teamEmailsWithSelf.length === 0) return [];

      const { data, error } = await gateway
        .from('opportunity_team_members')
        .select('opportunity_id')
        .in('team_member_email', teamEmailsWithSelf)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      
      return [...new Set((data || []).map((d: any) => d.opportunity_id))];
    },
    enabled: teamEmailsWithSelf.length > 0,
  });

  const { data: allOpportunities, isLoading: oppsLoading } = useQuery({
    queryKey: ['manager-all-opportunities', teamEmailsWithSelf, teamOpportunityIds],
    queryFn: async () => {
      if (teamEmailsWithSelf.length === 0) return [];

      // Build OR filter for owner_email and primary_se_email matching any team member
      const emailFilters = teamEmailsWithSelf
        .map(email => `owner_email.eq.${email},primary_se_email.eq.${email}`)
        .join(',');

      let query = gateway
        .from('opportunities')
        .select(`
          id, name, account_id, stage, sales_stage, pre_sales_stage, readiness_score,
          detection_signal_fields, value, close_date, owner_email, primary_se_email,
          last_meeting_at, stage_changed_at, created_at, is_archived,
          accounts!inner(id, name, owner_id, primary_se_email)
        `)
        // Exclude archived/closed opportunities from dashboard
        .eq('is_archived', false);

      // Include opportunities where:
      // 1. Owner or SE is in the team (priority)
      // 2. OR opportunity is in the team member assignments (fallback)
      if (teamOpportunityIds && teamOpportunityIds.length > 0) {
        // Combine both filters: assigned OR in team members table
        query = query.or(`${emailFilters},id.in.(${teamOpportunityIds.join(',')})`);
      } else {
        // Just use email filters if no team assignments yet
        query = query.or(emailFilters);
      }

      const { data, error } = await query
        .order('close_date', { ascending: true })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      
      return data as unknown as OpportunityWithDetails[];
    },
    enabled: teamEmailsWithSelf.length > 0 && teamOpportunityIds !== undefined,
  });

  // Fetch opportunity_team_members to identify additional assignments
  // Only fetch for opportunities we already have (from teamOpportunityIds) to avoid pagination limits
  const { data: oppTeamAssignments } = useQuery({
    queryKey: ['manager-opp-team-members', teamOpportunityIds],
    queryFn: async () => {
      if (!teamOpportunityIds?.length) return [];

      // Fetch team members only for opportunities we care about (avoids default 1000 row limit)
      const { data, error } = await gateway
        .from('opportunity_team_members')
        .select('opportunity_id, team_member_email')
        .in('opportunity_id', teamOpportunityIds)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      
      return data || [];
    },
    enabled: (teamOpportunityIds?.length || 0) > 0,
  });

  // Filter opportunities to only include those where a team member is involved
  const opportunities = useMemo<OpportunityWithDetails[]>(() => {
    if (!allOpportunities?.length) return [];
    if (teamEmailsWithSelf.length === 0) return [];
    
    

    const teamEmailSet = new Set(teamEmailsWithSelf.map(e => e.toLowerCase().trim()));
    
    // Build a map of opportunity -> team member emails from opportunity_team_members
    const oppTeamMap = new Map<string, string[]>();
    for (const assignment of (oppTeamAssignments || [])) {
      const oppId = assignment.opportunity_id;
      if (!oppTeamMap.has(oppId)) oppTeamMap.set(oppId, []);
      if (assignment.team_member_email) {
        oppTeamMap.get(oppId)!.push(assignment.team_member_email.toLowerCase().trim());
      }
    }

    const filtered = allOpportunities.filter(opp => {
      // Check if owner_email is a team member
      const ownerMatch = opp.owner_email && teamEmailSet.has(opp.owner_email.toLowerCase().trim());
      
      // Check if primary_se_email is a team member
      const seMatch = opp.primary_se_email && teamEmailSet.has(opp.primary_se_email.toLowerCase().trim());
      
      // Check if any opportunity_team_member is in our team
      const oppTeamEmails = oppTeamMap.get(opp.id) || [];
      const teamMemberMatch = oppTeamEmails.some(email => teamEmailSet.has(email));
      
      // Check if account owner or SE is a team member (need to look up by ID)
      // For account owner_id, we'd need to map user IDs to emails - skip for now, use account SE
      const accountSeMatch = opp.accounts?.primary_se_email && 
        teamEmailSet.has(opp.accounts.primary_se_email.toLowerCase().trim());

      return ownerMatch || seMatch || teamMemberMatch || accountSeMatch;
    }).map(opp => ({
      ...opp,
      team_member_emails: oppTeamMap.get(opp.id) || [],
    }));
    
    
    return filtered;
  }, [allOpportunities, oppTeamAssignments, teamEmailsWithSelf, teamOpportunityIds]);

  // Fetch alert history from the rule evaluation engine
  // This shows alerts from both system rules AND personal rules owned by the current user
  const { effectiveUserId } = useAuth();
  
  const { data: alertHistory } = useQuery({
    queryKey: ['manager-alert-history', opportunities?.map(o => o.id), effectiveUserId],
    queryFn: async () => {
      if (!opportunities?.length) return [];
      
      const oppIds = opportunities.map(o => o.id);
      const { data, error } = await gateway
        .from('opportunity_alert_history')
        .select(`
          id, rule_id, opportunity_id, triggered_at, trigger_data, 
          is_from_system_rule, rule_owner_id,
          opportunity_alert_rules!inner(name, description, rule_type)
        `)
        .in('opportunity_id', oppIds)
        .order('triggered_at', { ascending: false })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: !!opportunities?.length,
  });

  // Fetch AI coaching alerts (NBAs with action_type = 'coaching')
  const { data: coachingNBAs } = useQuery({
    queryKey: ['manager-coaching-alerts', opportunities?.map(o => o.id)],
    queryFn: async () => {
      if (!opportunities?.length) return [];
      
      const oppIds = opportunities.map(o => o.id);
      const accountIds = [...new Set(opportunities.map(o => o.account_id))];
      
      const { data, error } = await gateway
        .from('account_nbas')
        .select(`
          id, account_id, opportunity_id, action, notes, priority, created_at,
          accounts!inner(id, name),
          opportunities(id, name, owner_email, primary_se_email, value, close_date)
        `)
        .eq('action_type', 'coaching')
        .eq('status', 'pending')
        .in('account_id', accountIds)
        .order('created_at', { ascending: false })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      
      // Filter to only include NBAs for opportunities in our team's view
      const oppIdSet = new Set(oppIds);
      return (data || []).filter((nba: any) => 
        nba.opportunity_id ? oppIdSet.has(nba.opportunity_id) : true
      ) as CoachingNBA[];
    },
    enabled: !!opportunities?.length,
  });

  // Transform alert history AND coaching NBAs into OpportunityAlert format
  const alerts = useMemo<OpportunityAlert[]>(() => {
    const result: OpportunityAlert[] = [];

    // Process regular alert history
    if (opportunities?.length && alertHistory?.length) {
      // Filter alerts: show system rules + rules owned by this user (direct reports only)
      const filteredHistory = alertHistory.filter((h: any) => 
        h.is_from_system_rule === true || h.rule_owner_id === effectiveUserId
      );

      // Deduplicate - only show most recent alert per rule/opportunity combo
      const uniqueAlerts = new Map<string, any>();
      for (const h of filteredHistory) {
        const key = `${h.rule_id}-${h.opportunity_id}`;
        if (!uniqueAlerts.has(key)) {
          uniqueAlerts.set(key, h);
        }
      }

      for (const h of uniqueAlerts.values()) {
        const opp = opportunities.find(o => o.id === h.opportunity_id);
        if (!opp) continue;

        const rule = h.opportunity_alert_rules as any;
        const triggerData = h.trigger_data as any;
        
        // Get team members assigned to this opportunity
        const oppTeamEmails = opp.team_member_emails || [];
        
        // Get AE name
        const aeTeamMember = opp.owner_email 
          ? teamMembers?.find(t => t.member_email.toLowerCase() === opp.owner_email?.toLowerCase())
          : null;
        const ownerName = aeTeamMember?.member_name || opp.owner_email || null;
        
        // Get SE name
        const seTeamMember = opp.primary_se_email 
          ? teamMembers?.find(t => t.member_email.toLowerCase() === opp.primary_se_email?.toLowerCase())
          : null;
        const primarySeName = seTeamMember?.member_name || opp.primary_se_email || null;

        // Determine alert level from trigger data or rule type
        let alertLevel: 'critical' | 'warning' | 'info' = 'warning';
        if (triggerData?.severity === 'critical' || rule?.rule_type === 'readiness_below_threshold') {
          alertLevel = 'critical';
        } else if (triggerData?.severity === 'info') {
          alertLevel = 'info';
        }

        result.push({
          id: h.id,
          opportunityId: opp.id,
          opportunityName: opp.name,
          accountId: opp.account_id,
          accountName: opp.accounts?.name || 'Unknown',
          ownerEmail: opp.owner_email,
          ownerName,
          primarySeEmail: opp.primary_se_email,
          primarySeName,
          teamMemberEmails: oppTeamEmails,
          alertType: rule?.rule_type || 'unknown',
          alertLevel,
          alertMessage: triggerData?.reason || rule?.description || rule?.name || 'Alert triggered',
          ruleName: rule?.name || 'Unknown Rule',
          ruleId: h.rule_id,
          isSystemRule: h.is_from_system_rule === true,
          triggeredAt: h.triggered_at,
          stage: opp.stage,
          value: opp.value,
          closeDate: opp.close_date,
        });
      }
    }

    // Add AI coaching alerts from NBAs
    if (coachingNBAs?.length && opportunities?.length) {
      for (const nba of coachingNBAs) {
        // Find the opportunity details (either from nba.opportunities or from our loaded opportunities)
        const opp = nba.opportunity_id 
          ? (nba.opportunities || opportunities.find(o => o.id === nba.opportunity_id))
          : null;
        
        const ownerEmail = opp?.owner_email || null;
        const primarySeEmail = opp?.primary_se_email || null;
        
        // Get team member names
        const aeTeamMember = ownerEmail 
          ? teamMembers?.find(t => t.member_email.toLowerCase() === ownerEmail?.toLowerCase())
          : null;
        const seTeamMember = primarySeEmail 
          ? teamMembers?.find(t => t.member_email.toLowerCase() === primarySeEmail?.toLowerCase())
          : null;

        // Extract coaching type from notes (e.g., "AI Coaching: Missing Executive Sponsor (no_executive_sponsor)")
        const coachingTypeMatch = nba.notes?.match(/\(([^)]+)\)$/);
        const coachingType = coachingTypeMatch?.[1] || 'ai_coaching';

        // Determine alert level based on priority
        let alertLevel: 'critical' | 'warning' | 'info' = 'info';
        if (nba.priority === 'high') {
          alertLevel = 'warning';
        } else if (nba.priority === 'critical') {
          alertLevel = 'critical';
        }

        result.push({
          id: `coaching-${nba.id}`,
          opportunityId: nba.opportunity_id || '',
          opportunityName: (opp as any)?.name || 'Account-level',
          accountId: nba.account_id,
          accountName: nba.accounts?.name || 'Unknown',
          ownerEmail,
          ownerName: aeTeamMember?.member_name || ownerEmail,
          primarySeEmail,
          primarySeName: seTeamMember?.member_name || primarySeEmail,
          teamMemberEmails: [],
          alertType: coachingType,
          alertLevel,
          alertMessage: nba.action || 'AI coaching recommendation',
          ruleName: 'AI Coaching',
          ruleId: `coaching-${coachingType}`,
          isSystemRule: true,
          triggeredAt: nba.created_at,
          stage: null,
          value: (opp as any)?.value || null,
          closeDate: (opp as any)?.close_date || null,
        });
      }
    }

    // Sort by triggered_at (most recent first)
    return result.sort((a, b) => {
      const levelOrder = { critical: 0, warning: 1, info: 2 };
      if (levelOrder[a.alertLevel] !== levelOrder[b.alertLevel]) {
        return levelOrder[a.alertLevel] - levelOrder[b.alertLevel];
      }
      return new Date(b.triggeredAt).getTime() - new Date(a.triggeredAt).getTime();
    });
  }, [opportunities, alertHistory, coachingNBAs, teamMembers, effectiveUserId]);

  // Summary stats - use hierarchyTeamMembers for accurate team count
  const stats = useMemo(() => {
    const critical = alerts.filter(a => a.alertLevel === 'critical').length;
    const warning = alerts.filter(a => a.alertLevel === 'warning').length;
    const totalValue = opportunities?.reduce((sum, o) => sum + (o.value || 0), 0) || 0;
    const activeOpps = opportunities?.filter(o => 
      o.stage !== 'closed_won' && o.stage !== 'closed_lost'
    ).length || 0;

    // Team member count includes everyone in the hierarchy branch (including self)
    const teamCount = hierarchyTeamMembers?.length || teamEmailsWithSelf.length || 0;

    return {
      totalOpportunities: opportunities?.length || 0,
      activeOpportunities: activeOpps,
      criticalAlerts: critical,
      warningAlerts: warning,
      totalPipelineValue: totalValue,
      teamMemberCount: teamCount,
    };
  }, [opportunities, alerts, hierarchyTeamMembers, teamEmailsWithSelf]);

  // Group alerts by team member (an alert can appear for multiple team members)
  // Include owner, SE, and opportunity team members
  const alertsByOwner = useMemo(() => {
    const grouped: Record<string, OpportunityAlert[]> = {};
    const teamEmailSet = new Set(teamEmailsWithSelf.map(e => e.toLowerCase().trim()));
    
    for (const alert of alerts) {
      // Collect all emails associated with this opportunity that are in our team
      const associatedEmails: string[] = [];
      
      if (alert.ownerEmail && teamEmailSet.has(alert.ownerEmail.toLowerCase().trim())) {
        associatedEmails.push(alert.ownerEmail.toLowerCase().trim());
      }
      if (alert.primarySeEmail && teamEmailSet.has(alert.primarySeEmail.toLowerCase().trim())) {
        associatedEmails.push(alert.primarySeEmail.toLowerCase().trim());
      }
      for (const email of (alert.teamMemberEmails || [])) {
        if (teamEmailSet.has(email.toLowerCase().trim())) {
          associatedEmails.push(email.toLowerCase().trim());
        }
      }
      
      // Dedupe emails and group
      const uniqueEmails = [...new Set(associatedEmails)];
      if (uniqueEmails.length === 0) uniqueEmails.push('unassigned');
      
      for (const email of uniqueEmails) {
        if (!grouped[email]) grouped[email] = [];
        // Avoid duplicating the same alert for the same team member
        if (!grouped[email].some(a => a.id === alert.id)) {
          grouped[email].push(alert);
        }
      }
    }
    return grouped;
  }, [alerts, teamEmailsWithSelf]);

  return {
    alerts,
    alertsByOwner,
    opportunities,
    stats,
    teamMembers,
    hierarchyTeamMembers,
    teamEmailsWithSelf,
    isLoading: teamLoading || oppsLoading,
  };
}

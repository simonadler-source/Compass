import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export interface ManualMeeting {
  id: string;
  opportunity_id: string | null;
  matched_account_id: string | null;
  manual_meeting_type: string;
  start_time: string;
  attendees: { email: string }[] | null;
  notes: string | null;
  is_highlighted: boolean;
  title: string | null;
  host_email: string | null;
  created_at: string;
  // Joined relations
  opportunities?: any;
  accounts?: any;
}

export interface ManualMeetingInput {
  opportunity_id?: string | null;
  account_id?: string | null;
  meeting_type: string;
  meeting_date: string;
  attendee_emails: string[];
  notes?: string | null;
  is_highlighted?: boolean;
}

export const MANUAL_MEETING_TYPES = [
  { value: 'client_onsite', label: 'Client Onsite', highlighted: true },
  { value: 'executive_briefing', label: 'Executive Briefing', highlighted: true },
  { value: 'workshop_offsite', label: 'Workshop / Offsite', highlighted: true },
  { value: 'conference_meeting', label: 'Conference Meeting', highlighted: true },
  { value: 'internal_strategy', label: 'Internal Strategy Session', highlighted: false },
  { value: 'unrecorded_call', label: 'Unrecorded Call', highlighted: false },
  { value: 'other', label: 'Other', highlighted: false },
] as const;

const MEETING_TYPE_LABELS: Record<string, string> = {
  client_onsite: 'Client Onsite',
  executive_briefing: 'Executive Briefing',
  workshop_offsite: 'Workshop / Offsite',
  conference_meeting: 'Conference Meeting',
  internal_strategy: 'Internal Strategy Session',
  unrecorded_call: 'Unrecorded Call',
  other: 'Other Meeting',
};

function attendeeEmailsToJson(emails: string[]): { email: string }[] {
  return emails.map(e => ({ email: e.toLowerCase().trim() }));
}

function jsonToAttendeeEmails(attendees: any): string[] {
  if (!Array.isArray(attendees)) return [];
  return attendees
    .map((a: any) => typeof a === 'string' ? a : a?.email || a?.address || '')
    .filter(Boolean)
    .map((e: string) => e.toLowerCase().trim());
}

export function useManualMeetings(dateRange?: { from: Date; to: Date }) {
  return useQuery({
    queryKey: ['manual-meetings', dateRange?.from?.toISOString(), dateRange?.to?.toISOString()],
    queryFn: async () => {
      let query = gateway.from('momentum_meetings')
        .select('*, opportunities:opportunity_id(id, name, value, accounts:account_id(id, name)), accounts:matched_account_id(id, name)')
        .eq('meeting_context', 'manual');
      
      if (dateRange) {
        query = query
          .gte('start_time', dateRange.from.toISOString())
          .lte('start_time', dateRange.to.toISOString());
      }
      
      const result = await query.order('start_time', { ascending: false }).execute();
      if (result.error) throw new Error(getErrorMessage(result.error));
      
      // Map to a compatible shape for consumers
      return (result.data || []).map((m: any) => ({
        ...m,
        meeting_date: m.start_time,
        meeting_type: m.manual_meeting_type || 'other',
        account_id: m.matched_account_id,
        attendee_emails: jsonToAttendeeEmails(m.attendees),
      }));
    },
    enabled: true,
  });
}

export function useTeamManualMeetings(teamEmails: string[]) {
  return useQuery({
    queryKey: ['team-manual-meetings', teamEmails],
    queryFn: async () => {
      if (teamEmails.length === 0) return [];
      
      const result = await gateway.from('momentum_meetings')
        .select('*, opportunities:opportunity_id(id, name, value, accounts:account_id(id, name)), accounts:matched_account_id(id, name)')
        .eq('meeting_context', 'manual')
        .order('start_time', { ascending: false })
        .limit(200)
        .execute();
      
      if (result.error) throw new Error(getErrorMessage(result.error));
      
      // Filter to meetings where at least one attendee is on the team
      const teamEmailSet = new Set(teamEmails.map(e => e.toLowerCase().trim()));
      return (result.data || [])
        .filter((m: any) => {
          const emails = jsonToAttendeeEmails(m.attendees);
          return emails.some(email => teamEmailSet.has(email));
        })
        .map((m: any) => ({
          ...m,
          meeting_date: m.start_time,
          meeting_type: m.manual_meeting_type || 'other',
          account_id: m.matched_account_id,
          attendee_emails: jsonToAttendeeEmails(m.attendees),
        }));
    },
    enabled: teamEmails.length > 0,
  });
}

export function useAddManualMeeting() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (input: ManualMeetingInput) => {
      if (!user?.id) throw new Error('Not authenticated');
      
      const isHighlighted = input.is_highlighted ?? 
        MANUAL_MEETING_TYPES.find(t => t.value === input.meeting_type)?.highlighted ?? true;

      const title = MEETING_TYPE_LABELS[input.meeting_type] || input.meeting_type;
      const attendeesJson = attendeeEmailsToJson(input.attendee_emails);

      const result = await gateway.from('momentum_meetings')
        .insert({
          momentum_id: `manual_${crypto.randomUUID()}`,
          start_time: input.meeting_date,
          end_time: new Date(new Date(input.meeting_date).getTime() + 60 * 60 * 1000).toISOString(),
          title,
          host_email: input.attendee_emails[0] || null,
          attendees: attendeesJson as any,
          status: 'imported',
          meeting_context: 'manual',
          manual_meeting_type: input.meeting_type,
          is_highlighted: isHighlighted,
          notes: input.notes || null,
          matched_account_id: input.account_id || null,
          opportunity_id: input.opportunity_id || null,
        })
        .select()
        .execute();
      
      if (result.error) throw new Error(getErrorMessage(result.error));
      return result.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['manual-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['team-manual-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['exec-weekly-summary'] });
      queryClient.invalidateQueries({ queryKey: ['weekly-activity-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['team-member-meetings'] });
      toast.success('Meeting added successfully');
    },
    onError: (error: Error) => {
      toast.error('Failed to add meeting: ' + error.message);
    },
  });
}

export function useUpdateManualMeeting() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<ManualMeetingInput> & { id: string }) => {
      const updateData: any = {};
      
      if (updates.meeting_type !== undefined) {
        updateData.manual_meeting_type = updates.meeting_type;
        updateData.title = MEETING_TYPE_LABELS[updates.meeting_type] || updates.meeting_type;
      }
      if (updates.meeting_date !== undefined) {
        updateData.start_time = updates.meeting_date;
        updateData.end_time = new Date(new Date(updates.meeting_date).getTime() + 60 * 60 * 1000).toISOString();
      }
      if (updates.notes !== undefined) updateData.notes = updates.notes;
      if (updates.attendee_emails !== undefined) {
        updateData.attendees = attendeeEmailsToJson(updates.attendee_emails) as any;
        updateData.host_email = updates.attendee_emails[0] || null;
      }
      if (updates.opportunity_id !== undefined) updateData.opportunity_id = updates.opportunity_id;
      if (updates.account_id !== undefined) updateData.matched_account_id = updates.account_id;
      if (updates.is_highlighted !== undefined) updateData.is_highlighted = updates.is_highlighted;

      const result = await gateway.from('momentum_meetings')
        .update(updateData)
        .eq('id', id)
        .select()
        .execute();
      if (result.error) throw new Error(getErrorMessage(result.error));
      return result.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['manual-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['team-manual-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['exec-weekly-summary'] });
      queryClient.invalidateQueries({ queryKey: ['weekly-activity-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['team-member-meetings'] });
      toast.success('Meeting updated');
    },
    onError: (error: Error) => {
      toast.error('Failed to update meeting: ' + error.message);
    },
  });
}

export function useDeleteManualMeeting() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (meetingId: string) => {
      const result = await gateway.from('momentum_meetings')
        .delete()
        .eq('id', meetingId)
        .eq('meeting_context', 'manual')
        .execute();
      if (result.error) throw new Error(getErrorMessage(result.error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['manual-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['team-manual-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['exec-weekly-summary'] });
      queryClient.invalidateQueries({ queryKey: ['weekly-activity-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['team-member-meetings'] });
      toast.success('Meeting removed');
    },
  });
}

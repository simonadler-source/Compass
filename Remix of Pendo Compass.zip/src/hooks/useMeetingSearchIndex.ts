import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface MeetingSearchResult {
  meeting_id: string;
  title: string | null;
  host_name: string | null;
  host_email: string | null;
  attendee_names: string[];
  attendee_emails: string[];
  internal_attendee_count: number;
  external_attendee_count: number;
  start_time: string;
  end_time: string | null;
  status: string | null;
  matched_account_id: string | null;
  salesforce_account_id: string | null;
  salesforce_opportunity_id: string | null;
}

interface SearchFilters {
  searchQuery?: string;
  attendeeFilter?: string;
  dateFrom?: Date;
  dateTo?: Date;
  myMeetingsOnly?: boolean;
  userEmail?: string;
  statuses?: string[];
}

/**
 * Hook to search meetings using server-side ephemeral search
 * Decrypts data in-memory on the server, no persistent plaintext storage
 */
export function useMeetingSearchIndex(filters: SearchFilters, enabled = true) {
  return useQuery({
    queryKey: ['meeting-search', filters],
    queryFn: async () => {
      // Retry up to 3 times for transient Cloudflare/infrastructure errors
      let lastError: Error | null = null;
      for (let attempt = 0; attempt < 3; attempt++) {
        const { data, error } = await supabase.functions.invoke('search-meetings', {
          body: {
            searchQuery: filters.searchQuery || undefined,
            attendeeFilter: filters.attendeeFilter || undefined,
            dateFrom: filters.dateFrom?.toISOString(),
            dateTo: filters.dateTo?.toISOString(),
            myMeetingsOnly: filters.myMeetingsOnly,
            userEmail: filters.userEmail,
            statuses: filters.statuses,
            limit: 1000,
          },
        });

        if (error) {
          const errorStr = String(error?.message || error);
          // Retry on Cloudflare 500 / HTML responses / transient errors
          if (errorStr.includes('500') || errorStr.includes('<!DOCTYPE') || errorStr.includes('Internal server error')) {
            lastError = new Error(`Search temporarily unavailable (attempt ${attempt + 1}/3)`);
            console.warn(`[meeting-search] Transient error, retrying (${attempt + 1}/3)...`);
            await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
            continue;
          }
          console.error('Search failed:', error);
          throw error;
        }

        if (data?.error) {
          const errMsg = String(data.error);
          if (errMsg.includes('<!DOCTYPE') || errMsg.includes('Internal server error')) {
            lastError = new Error(`Search temporarily unavailable (attempt ${attempt + 1}/3)`);
            console.warn(`[meeting-search] HTML error in response, retrying (${attempt + 1}/3)...`);
            await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
            continue;
          }
          throw new Error(data.error);
        }

        return data?.results as MeetingSearchResult[] || [];
      }

      throw lastError || new Error('Search failed after retries');
    },
    enabled,
    staleTime: 30000,
    retry: 1, // react-query level retry on top of our manual retries
  });
}

/**
 * Get meeting IDs from search results for filtering
 */
export function getMeetingIdsFromSearch(results: MeetingSearchResult[] | undefined): Set<string> {
  if (!results) return new Set();
  return new Set(results.map(r => r.meeting_id));
}
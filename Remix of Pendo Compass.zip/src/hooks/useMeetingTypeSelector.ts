import { useMutation, useQueryClient } from "@tanstack/react-query";
import { gateway } from "@/lib/apiGateway";

// ── Pendo Internal Account ──────────────────────────────────────────────

/** Well-known account ID for all-internal meetings (no external attendees). */
export const PENDO_INTERNAL_ACCOUNT_ID = 'faf15e54-783e-475b-a9b5-3685bb10f678';
export const PENDO_INTERNAL_ACCOUNT_NAME = 'Pendo (Internal)';

// ── Meeting Context (internal vs external) ──────────────────────────────

export const MEETING_CONTEXTS = [
  { value: 'external', label: 'External / Prospect', description: 'Customer or prospect-facing call' },
  { value: 'internal_win_loss', label: 'Win/Loss Review', description: 'Post-deal retrospective analyzing competitive outcomes' },
  { value: 'internal_strategy', label: 'Competitive Strategy', description: 'Internal strategy session on positioning and battlecards' },
  { value: 'internal_positioning', label: 'Product Positioning', description: 'Positioning Pendo vs. competitors for segments or use cases' },
  { value: 'internal_debrief', label: 'SE Debrief / Coaching', description: 'Internal debrief on competitive dynamics from demos or POCs' },
] as const;

export type MeetingContext = typeof MEETING_CONTEXTS[number]['value'];

export function isInternalContext(context: MeetingContext | string): boolean {
  return context.startsWith('internal_');
}

/**
 * Auto-detect meeting context from attendees.
 * If ALL valid attendees have @pendo.io emails → internal.
 */
export function detectMeetingContext(attendees: any[]): { context: MeetingContext; reason: string } {
  const validAttendees = (attendees || []).filter((a: any) => {
    const email = String(a?.email || '').trim();
    return email.includes('@') && email.includes('.');
  });

  if (validAttendees.length === 0) {
    return { context: 'external', reason: 'No valid attendees found' };
  }

  const allInternal = validAttendees.every((a: any) => {
    const email = String(a?.email || '').toLowerCase().trim();
    return email.endsWith('@pendo.io') || a?.isInternal === true;
  });

  if (allInternal) {
    return { context: 'internal_strategy', reason: 'All attendees are @pendo.io (internal)' };
  }

  return { context: 'external', reason: 'External attendees present' };
}

/**
 * Returns the default evidence confidence weight for a meeting context.
 * Internal intel is second-degree and may be biased, so it gets a lower weight.
 */
export function getEvidenceConfidenceWeight(context: MeetingContext | string): number {
  if (context === 'external') return 1.0;
  if (context === 'internal_win_loss') return 0.8; // Win/loss reviews are relatively reliable
  return 0.6; // Other internal discussions may be more subjective
}

export function getEvidenceSource(context: MeetingContext | string): string {
  return isInternalContext(context) ? 'internal' : 'field';
}

// ── Meeting Type (call purpose) ─────────────────────────────────────────

export const MEETING_TYPES = [
  { value: 'discovery', label: 'Discovery', description: 'Initial qualification and needs finding' },
  { value: 'demo', label: 'Demo', description: 'Product demonstration or walkthrough' },
  { value: 'technical', label: 'Technical Deep Dive', description: 'Technical requirements and architecture' },
  { value: 'evaluation_workshop', label: 'Evaluation Workshop', description: 'Hands-on POC or evaluation session' },
  { value: 'workshop', label: 'Workshop', description: 'Hands-on working session (non-evaluation)' },
  { value: 'dry_run', label: 'Dry Run', description: 'Practice demo or presentation rehearsal' },
  { value: 'executive', label: 'Executive Briefing', description: 'C-level or senior leadership meeting' },
  { value: 'commercial', label: 'Commercial Discussion', description: 'Pricing and commercial terms' },
  { value: 'negotiation', label: 'Negotiation', description: 'Contract terms negotiation' },
  { value: 'contract', label: 'Contract Review', description: 'Legal and contract review' },
  { value: 'check_in', label: 'Check-in', description: 'Regular status update' },
  { value: 'training', label: 'Training', description: 'User training session' },
  { value: 'onboarding', label: 'Onboarding', description: 'Customer onboarding and setup' },
  { value: 'qbr', label: 'QBR', description: 'Quarterly business review' },
] as const;

export type MeetingType = typeof MEETING_TYPES[number]['value'];

export function useUpdateTranscriptMeetingType() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ transcriptId, meetingType }: { transcriptId: string; meetingType: MeetingType }) => {
      const result = await gateway.from('transcript_reviews')
        .update({ meeting_type: meetingType })
        .eq('id', transcriptId)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['transcripts'] });
      if (data?.id) {
        queryClient.invalidateQueries({ queryKey: ['transcript', data.id] });
      }
    },
  });
}

export function useUpdateTranscriptMeetingContext() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ transcriptId, meetingContext }: { transcriptId: string; meetingContext: MeetingContext }) => {
      const result = await gateway.from('transcript_reviews')
        .update({ meeting_context: meetingContext })
        .eq('id', transcriptId)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['transcripts'] });
      if (data?.id) {
        queryClient.invalidateQueries({ queryKey: ['transcript', data.id] });
      }
    },
  });
}

// Infer meeting type from title/content
export function inferMeetingType(title: string, content?: string): { type: MeetingType; confidence: number } {
  const lowerTitle = title.toLowerCase();
  const lowerContent = content?.toLowerCase() || '';
  const combined = `${lowerTitle} ${lowerContent}`;
  
  // Check for specific keywords - ordered by specificity
  if (combined.includes('dry run') || combined.includes('rehearsal') || combined.includes('practice run')) {
    return { type: 'dry_run', confidence: 0.7 };
  }
  
  if (combined.includes('qbr') || combined.includes('quarterly business review')) {
    return { type: 'qbr', confidence: 0.75 };
  }
  
  if (combined.includes('pricing') || combined.includes('contract') || combined.includes('commercial') || combined.includes('proposal')) {
    if (combined.includes('negotiat')) return { type: 'negotiation', confidence: 0.6 };
    if (combined.includes('legal') || combined.includes('redline')) return { type: 'contract', confidence: 0.6 };
    return { type: 'commercial', confidence: 0.55 };
  }
  
  if (combined.includes('executive') || combined.includes('ceo') || combined.includes('cto') || combined.includes('cfo') || combined.includes('c-level')) {
    return { type: 'executive', confidence: 0.6 };
  }
  
  if (combined.includes('evaluation') || combined.includes('poc review') || combined.includes('proof of concept')) {
    return { type: 'evaluation_workshop', confidence: 0.6 };
  }
  
  if (combined.includes('demo') || combined.includes('demonstration') || combined.includes('walkthrough')) {
    return { type: 'demo', confidence: 0.5 };
  }
  
  if (combined.includes('technical') || combined.includes('architecture') || combined.includes('integration') || combined.includes('api')) {
    return { type: 'technical', confidence: 0.5 };
  }
  
  if (combined.includes('workshop') || combined.includes('hands-on') || combined.includes('poc')) {
    return { type: 'workshop', confidence: 0.5 };
  }
  
  if (combined.includes('onboarding')) {
    return { type: 'onboarding', confidence: 0.6 };
  }
  
  if (combined.includes('training')) {
    return { type: 'training', confidence: 0.6 };
  }
  
  if (combined.includes('check-in') || combined.includes('status') || combined.includes('weekly') || combined.includes('sync')) {
    return { type: 'check_in', confidence: 0.45 };
  }
  
  // Default to discovery with low confidence
  return { type: 'discovery', confidence: 0.3 };
}

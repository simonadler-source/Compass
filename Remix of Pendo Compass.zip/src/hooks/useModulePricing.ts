import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

export type ModuleType = 'platform' | 'mau' | 'module';

export interface ModulePricing {
  id: string;
  functional_area_id: string | null;
  module_name: string;
  description: string | null;
  module_type: ModuleType;
  fixed_cost: number;
  per_mau_cost: number;
  mau_percentage: number;
  discount_percentage: number;
  discount_reason: string | null;
  is_base_module: boolean;
  is_active: boolean;
  sort_order: number;
}

export interface UseCaseTemplateProduct {
  use_case_template_id: string;
  module_pricing_id: string;
}

export interface UseCaseTemplate {
  id: string;
  name: string;
  functional_area_id: string;
  business_outcome: string | null;
  description: string | null;
}

export interface WhitespaceRevenue {
  functionalArea: string;
  functionalAreaId: string;
  moduleName: string;
  potentialRevenue: number;
  useCaseCount: number;
  coverageGap: number;
  moduleType: ModuleType;
  discount: number;
  uncoveredUseCases: string[];
}

export interface RevenueCalculation {
  platformCost: number;
  mauCost: number;
  totalModuleCost: number;
  totalBeforeDiscount: number;
  totalWithDiscount: number;
  byArea: WhitespaceRevenue[];
  byProduct: WhitespaceRevenue[];
  mauCount: number;
  baseMauValue: number;
  uncoveredTemplates: UseCaseTemplate[];
  coveredTemplates: UseCaseTemplate[];
}

export function useModulePricing() {
  return useQuery({
    queryKey: ['module-pricing'],
    queryFn: async () => {
      const response = await gateway.from<ModulePricing>('module_pricing')
        .select('*')
        .eq('is_active', true)
        .order('sort_order')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as ModulePricing[];
    },
  });
}

export function useUseCaseTemplateProducts() {
  return useQuery({
    queryKey: ['use-case-template-products'],
    queryFn: async () => {
      const response = await gateway.from('use_case_template_products')
        .select('use_case_template_id, module_pricing_id')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as UseCaseTemplateProduct[];
    },
  });
}

export function useWhitespaceRevenue(
  accountId: string,
  mauCount: number | null,
  baseMauValue: number | null
) {
  const { data: pricing } = useModulePricing();
  const { data: templateProducts } = useUseCaseTemplateProducts();
  
  // Fetch global pricing settings
  const { data: pricingSettings } = useQuery({
    queryKey: ['pricing-settings'],
    queryFn: async () => {
      const response = await gateway.from('pricing_settings')
        .select('setting_key, setting_value')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      const settings: Record<string, number> = {};
      (response.data || []).forEach((s: { setting_key: string; setting_value: string }) => {
        settings[s.setting_key] = parseFloat(s.setting_value) || 0;
      });
      return settings;
    },
  });
  
  // Fetch functional areas
  const { data: functionalAreas } = useQuery({
    queryKey: ['functional-areas'],
    queryFn: async () => {
      const response = await gateway.from('functional_areas')
        .select('id, name, layer')
        .order('sort_order')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as { id: string; name: string; layer: string }[];
    },
  });

  // Fetch use case templates with new fields
  const { data: useCaseTemplates } = useQuery({
    queryKey: ['use-case-templates-full'],
    queryFn: async () => {
      const response = await gateway.from('use_case_templates')
        .select('id, name, functional_area_id, business_outcome, description')
        .eq('is_active', true)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as UseCaseTemplate[];
    },
  });

  // Fetch account use cases
  const { data: accountUseCases } = useQuery({
    queryKey: ['account-use-cases', accountId],
    queryFn: async () => {
      const response = await gateway.from('account_use_cases')
        .select('id, use_case, functional_area, opportunity_id, status')
        .eq('account_id', accountId)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as { id: string; use_case: string; functional_area: string; opportunity_id: string | null; status: string }[];
    },
    enabled: !!accountId,
  });

  // Fetch account technologies for competing module exclusion
  const { data: accountTechnologies } = useQuery({
    queryKey: ['account-technologies-for-whitespace', accountId],
    queryFn: async () => {
      const response = await gateway.from('account_technologies')
        .select('id, repository_tech_id')
        .eq('account_id', accountId)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as { id: string; repository_tech_id: string | null }[];
    },
    enabled: !!accountId,
  });

  // Fetch technology repository for competing module mappings
  const { data: technologyRepository } = useQuery({
    queryKey: ['technology-repository-competing'],
    queryFn: async () => {
      const response = await gateway.from('technology_repository')
        .select('id, competing_module_ids')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as { id: string; competing_module_ids: string[] | null }[];
    },
  });

  // Build set of module IDs excluded due to competing technologies
  const competingModuleIds = useMemo(() => {
    if (!accountTechnologies || !technologyRepository) return new Set<string>();
    
    const techRepoMap = new Map(technologyRepository.map(t => [t.id, t]));
    const excluded = new Set<string>();
    
    accountTechnologies.forEach(tech => {
      if (tech.repository_tech_id) {
        const repoTech = techRepoMap.get(tech.repository_tech_id);
        if (repoTech?.competing_module_ids) {
          repoTech.competing_module_ids.forEach(mid => excluded.add(mid));
        }
      }
    });
    
    return excluded;
  }, [accountTechnologies, technologyRepository]);

  // Calculate effective base MAU value from pricing settings if not set on account
  const effectiveBaseMauValue = useMemo(() => {
    // If account has explicit base_mau_value, use it
    if (baseMauValue && baseMauValue > 0) return baseMauValue;
    
    // Otherwise calculate from global pricing settings
    if (pricingSettings && mauCount) {
      const listPricePerMau = pricingSettings.list_price_per_mau || 0;
      const platformBaseCost = pricingSettings.platform_base_cost || 0;
      // Annual MAU value = (per MAU rate × MAU count × 12 months) + platform base
      return (listPricePerMau * mauCount * 12) + platformBaseCost;
    }
    
    return 0;
  }, [baseMauValue, pricingSettings, mauCount]);

  // Calculate whitespace revenue
  const calculation: RevenueCalculation | null = 
    pricing && functionalAreas && useCaseTemplates && accountUseCases && templateProducts && mauCount && pricingSettings
      ? calculateWhitespaceRevenue(
          pricing,
          functionalAreas,
          useCaseTemplates,
          accountUseCases,
          templateProducts,
          mauCount,
          effectiveBaseMauValue,
          competingModuleIds,
          pricingSettings
        )
      : null;

  return {
    calculation,
    isLoading: !pricing || !functionalAreas || !useCaseTemplates || !templateProducts || !pricingSettings,
    pricing,
  };
}

function calculateWhitespaceRevenue(
  pricing: ModulePricing[],
  functionalAreas: { id: string; name: string; layer: string }[],
  useCaseTemplates: UseCaseTemplate[],
  accountUseCases: { id: string; use_case: string; functional_area: string; opportunity_id: string | null; status: string }[],
  templateProducts: UseCaseTemplateProduct[],
  mauCount: number,
  baseMauValue: number,
  competingModuleIds: Set<string> = new Set(),
  pricingSettings: Record<string, number> = {}
): RevenueCalculation {
  const byArea: WhitespaceRevenue[] = [];
  const byProduct: WhitespaceRevenue[] = [];
  
  // Get platform base cost from pricing settings
  const platformBaseCost = pricingSettings.platform_base_cost || 0;
  const listPricePerMau = pricingSettings.list_price_per_mau || 0;
  
  // Calculate platform cost from settings (annual fixed cost)
  const platformFixedCost = platformBaseCost;
  
  // Calculate MAU cost from global pricing settings (per MAU × MAU count × 12 months)
  const totalMauCost = listPricePerMau * mauCount * 12;

  // Calculate MAU base value for percentage-based modules
  // This is the total platform value that modules are priced as a percentage of
  const mauValue = baseMauValue > 0 ? baseMauValue : (platformFixedCost + totalMauCost);

  // Build template-to-products map
  const templateToProducts = new Map<string, string[]>();
  templateProducts.forEach(tp => {
    const existing = templateToProducts.get(tp.use_case_template_id) || [];
    existing.push(tp.module_pricing_id);
    templateToProducts.set(tp.use_case_template_id, existing);
  });
  
  // Build product pricing map
  const productPricingMap = new Map<string, ModulePricing>();
  pricing.forEach(mp => productPricingMap.set(mp.id, mp));

  // Get all account use case names for matching
  const coveredUseCaseNames = new Set<string>();
  accountUseCases.forEach(uc => {
    if (uc.use_case) {
      coveredUseCaseNames.add(uc.use_case.toLowerCase().trim());
    }
  });

  // Categorize templates as covered or uncovered
  const coveredTemplates: UseCaseTemplate[] = [];
  const uncoveredTemplates: UseCaseTemplate[] = [];
  
  useCaseTemplates.forEach(template => {
    const templateName = template.name.toLowerCase().trim();
    const isCovered = Array.from(coveredUseCaseNames).some(ucName => 
      ucName.includes(templateName) || templateName.includes(ucName)
    );
    
    if (isCovered) {
      coveredTemplates.push(template);
    } else {
      uncoveredTemplates.push(template);
    }
  });

  // Calculate whitespace by product
  const productToUncoveredTemplates = new Map<string, string[]>();
  
  uncoveredTemplates.forEach(template => {
    const productIds = templateToProducts.get(template.id) || [];
    productIds.forEach(productId => {
      const existing = productToUncoveredTemplates.get(productId) || [];
      existing.push(template.name);
      productToUncoveredTemplates.set(productId, existing);
    });
  });

  // Calculate revenue per product
  let totalModuleCost = 0;
  
  productToUncoveredTemplates.forEach((templateNames, productId) => {
    // Skip products that compete with technologies the account already has
    if (competingModuleIds.has(productId)) return;
    
    const product = productPricingMap.get(productId);
    if (!product) return;
    
    const discount = product.discount_percentage || 0;
    let productRevenue = 0;
    
    if (product.module_type === 'module') {
      // Percentage-based pricing
      const baseModuleCost = mauValue * (product.mau_percentage / 100);
      productRevenue = baseModuleCost * (1 - discount / 100);
    } else if (product.per_mau_cost > 0) {
      // Per-MAU pricing (annual)
      productRevenue = product.per_mau_cost * mauCount * 12 * (1 - discount / 100);
    } else if (product.fixed_cost > 0) {
      // Fixed cost
      productRevenue = product.fixed_cost * (1 - discount / 100);
    }
    
    totalModuleCost += productRevenue;
    
    byProduct.push({
      functionalArea: '',
      functionalAreaId: product.functional_area_id || '',
      moduleName: product.module_name,
      potentialRevenue: Math.round(productRevenue),
      useCaseCount: templateNames.length,
      coverageGap: 100, // Full product value since it's uncovered
      moduleType: product.module_type as ModuleType,
      discount,
      uncoveredUseCases: templateNames,
    });
  });

  // Sort by potential revenue descending
  byProduct.sort((a, b) => b.potentialRevenue - a.potentialRevenue);

  // Also calculate by functional area for backwards compatibility
  const areaMap = new Map<string, { covered: number; uncovered: number; revenue: number }>();
  
  functionalAreas.forEach(area => {
    const areaTemplates = useCaseTemplates.filter(t => t.functional_area_id === area.id);
    const covered = areaTemplates.filter(t => coveredTemplates.includes(t)).length;
    const uncovered = areaTemplates.filter(t => uncoveredTemplates.includes(t)).length;
    
    // Calculate revenue for this area
    let areaRevenue = 0;
    areaTemplates.filter(t => uncoveredTemplates.includes(t)).forEach(template => {
      const productIds = templateToProducts.get(template.id) || [];
      productIds.forEach(productId => {
        const product = productPricingMap.get(productId);
        if (product && product.module_type === 'module') {
          const discount = product.discount_percentage || 0;
          const baseModuleCost = mauValue * (product.mau_percentage / 100);
          // Divide by total products for this template to avoid double-counting
          areaRevenue += (baseModuleCost * (1 - discount / 100)) / productIds.length;
        }
      });
    });
    
    if (areaTemplates.length > 0) {
      areaMap.set(area.id, { covered, uncovered, revenue: areaRevenue });
      
      byArea.push({
        functionalArea: area.name,
        functionalAreaId: area.id,
        moduleName: area.name,
        potentialRevenue: Math.round(areaRevenue),
        useCaseCount: covered + uncovered,
        coverageGap: areaTemplates.length > 0 ? Math.round((uncovered / areaTemplates.length) * 100) : 0,
        moduleType: 'module',
        discount: 0,
        uncoveredUseCases: areaTemplates.filter(t => uncoveredTemplates.includes(t)).map(t => t.name),
      });
    }
  });

  byArea.sort((a, b) => b.potentialRevenue - a.potentialRevenue);

  const totalBeforeDiscount = platformFixedCost + totalMauCost + totalModuleCost;

  return {
    platformCost: Math.round(platformFixedCost),
    mauCost: Math.round(totalMauCost),
    totalModuleCost: Math.round(totalModuleCost),
    totalBeforeDiscount: Math.round(totalBeforeDiscount),
    totalWithDiscount: Math.round(totalBeforeDiscount),
    byArea,
    byProduct,
    mauCount,
    baseMauValue: mauValue,
    uncoveredTemplates,
    coveredTemplates,
  };
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export interface NotificationPreferences {
  id: string;
  user_id: string;
  email_enabled: boolean;
  frequency: 'realtime' | 'daily' | 'weekly';
  digest_time: string;
  digest_day: number;
  quiet_hours_start: string | null;
  quiet_hours_end: string | null;
  notify_alerts: boolean; // Renamed from notify_sentiment_changes - includes all triggered alerts
  notify_new_actions: boolean;
  notify_overdue_reminders: boolean;
  created_at: string;
  updated_at: string;
}

const DEFAULT_PREFERENCES: Partial<NotificationPreferences> = {
  email_enabled: true,
  frequency: 'daily',
  digest_time: '08:00:00',
  digest_day: 1,
  quiet_hours_start: null,
  quiet_hours_end: null,
  notify_alerts: true,
  notify_new_actions: true,
  notify_overdue_reminders: true,
};

export function useNotificationPreferences() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: preferences, isLoading } = useQuery({
    queryKey: ['notification-preferences', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;

      const result = await gateway.from('notification_preferences')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle()
        .execute();

      if (result.error) {
        throw new Error(result.error.message);
      }

      return result.data as NotificationPreferences | null;
    },
    enabled: !!user?.id,
  });

  const savePreferences = useMutation({
    mutationFn: async (prefs: Partial<NotificationPreferences>) => {
      if (!user?.id) throw new Error('Not authenticated');

      console.log('[NotificationPreferences] Saving preferences for user:', user.id);
      console.log('[NotificationPreferences] Existing record id:', preferences?.id);

      if (preferences?.id) {
        // Update existing
        console.log('[NotificationPreferences] Updating existing record');
        const result = await gateway.from('notification_preferences')
          .update(prefs)
          .eq('id', preferences.id)
          .execute();

        if (result.error) {
          console.error('[NotificationPreferences] Update failed:', result.error);
          throw new Error(result.error.message);
        }
      } else {
        // Insert new
        console.log('[NotificationPreferences] Inserting new record');
        const insertData = { ...DEFAULT_PREFERENCES, ...prefs, user_id: user.id };
        console.log('[NotificationPreferences] Insert data:', insertData);
        
        const result = await gateway.from('notification_preferences')
          .insert(insertData)
          .execute();

        if (result.error) {
          console.error('[NotificationPreferences] Insert failed:', result.error);
          throw new Error(result.error.message);
        }
        console.log('[NotificationPreferences] Insert successful');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notification-preferences'] });
      toast.success('Notification preferences saved');
    },
    onError: (error: Error) => {
      console.error('[NotificationPreferences] Save error:', error);
      toast.error('Failed to save preferences: ' + error.message);
    },
  });

  return {
    preferences: preferences || DEFAULT_PREFERENCES as NotificationPreferences,
    isLoading,
    savePreferences,
  };
}

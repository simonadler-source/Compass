import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { gateway } from "@/lib/apiGateway";

interface SystemNotification {
  id: string;
  type: string;
  title: string;
  message: string | null;
  data: Record<string, any> | null;
  is_read: boolean;
  created_at: string;
  expires_at: string | null;
}

export function useNotifications() {
  const queryClient = useQueryClient();

  const { data: notifications = [], isLoading, refetch } = useQuery({
    queryKey: ["system-notifications"],
    queryFn: async () => {
      // Fetch all notifications and filter client-side for expiry
      // Gateway doesn't support .or() method
      const result = await gateway.from("system_notifications")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50)
        .execute();

      if (result.error) throw new Error(result.error.message);
      
      // Filter for non-expired notifications (null expires_at or future date)
      const now = new Date().toISOString();
      const validNotifications = (result.data || []).filter((n: any) => 
        n.expires_at === null || n.expires_at > now
      );
      
      return validNotifications as SystemNotification[];
    },
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  const markAsRead = useMutation({
    mutationFn: async (notificationId: string) => {
      const result = await gateway.from("system_notifications")
        .update({ is_read: true })
        .eq("id", notificationId)
        .execute();

      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["system-notifications"] });
    },
  });

  const markAllAsRead = useMutation({
    mutationFn: async () => {
      const unreadIds = notifications.filter((n) => !n.is_read).map((n) => n.id);
      if (unreadIds.length === 0) return;

      const result = await gateway.from("system_notifications")
        .update({ is_read: true })
        .in("id", unreadIds)
        .execute();

      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["system-notifications"] });
    },
  });

  return {
    notifications,
    unreadCount,
    isLoading,
    refetch,
    markAsRead: markAsRead.mutate,
    markAllAsRead: markAllAsRead.mutate,
  };
}

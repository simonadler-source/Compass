import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useMemo } from 'react';
import { subDays, formatDistanceToNow } from 'date-fns';

export interface PrepOpportunity {
  id: string;
  name: string;
  accountName: string;
  value: number | null;
  closeDate: string | null;
  salesStage: string | null;
  preSalesStage: string | null;
  readinessScore: number | null;
  lastMeetingAt: string | null;
  stageChangedAt: string | null;
  createdAt: string;
  signals: Record<string, any> | null;
  status: 'progressing' | 'stalled' | 'at_risk' | 'eval_ready' | 'healthy';
  statusReason: string;
}

export interface PrepCoachingItem {
  id: string;
  action: string;
  notes: string | null;
  opportunityName: string;
  accountName: string | null;
  priority: string | null;
}

export interface CoachingDimensionSummary {
  dimension: string;
  label: string;
  avgScore: number;
  scores: number[];
  trend: 'improving' | 'declining' | 'stable';
}

export interface CoachingCallInsight {
  transcriptId: string;
  meetingType: string;
  overallScore: number;
  date: string;
  accountId: string | null;
  accountName: string | null;
  greatnessMoment: string | null;
  opportunityGap: string | null;
  actionableNextStep: string | null;
  whatWorkedWell: any[] | null;
  whatDidntWork: any[] | null;
  coachingGuidance: any[] | null;
  weakestDimensions: { dimension: string; score: number }[];
}

export interface CoachingAccountGroup {
  accountId: string;
  accountName: string;
  calls: CoachingCallInsight[];
  avgScore: number;
  trend: 'improving' | 'declining' | 'stable';
}

export interface HolisticCoachingData {
  dimensionSummaries: CoachingDimensionSummary[];
  callInsights: CoachingCallInsight[];
  accountGroups: CoachingAccountGroup[];
  overallAvg: number;
  overallTrend: 'improving' | 'declining' | 'stable';
  topStrengths: string[];
  topGaps: string[];
  recurringGuidance: string[];
}

export interface PrepAccomplishment {
  type: 'nba_completed' | 'transcript_processed' | 'eval_started';
  description: string;
  date: string;
}

export interface PrepEvalOpportunity {
  id: string;
  name: string;
  accountName: string;
  evalStartDate: string | null;
  evalEndDate: string | null;
  evalType: string | null;
  evalPhase: string | null;
  milestones: {
    total: number;
    completed: number;
    inProgress: number;
    phases: Record<string, { total: number; completed: number }>;
    nextUpcoming: { name: string; date: string } | null;
  };
  risks: { id: string; description: string; severity: string; status: string; entryType: string }[];
}

export interface OneOnOnePrepData {
  memberEmail: string;
  memberName: string | null;
  opportunities: PrepOpportunity[];
  accomplishments: PrepAccomplishment[];
  coachingItems: PrepCoachingItem[];
  evalOpportunities: PrepEvalOpportunity[];
  summary: {
    totalOpps: number;
    totalPipeline: number;
    stalledCount: number;
    progressingCount: number;
    evalReadyCount: number;
    atRiskCount: number;
    nbasCompletedCount: number;
    meetingsLast14d: number;
  };
}

export function useOneOnOnePrep(memberEmail: string | null, enabled: boolean = false) {
  // Fetch opportunities for this team member
  const { data: opportunities, isLoading: oppsLoading } = useQuery({
    queryKey: ['one-on-one-opps', memberEmail],
    queryFn: async () => {
      if (!memberEmail) return [];
      const { data, error } = await gateway
        .from('opportunities')
        .select(`
          id, name, account_id, value, close_date, sales_stage, pre_sales_stage,
          readiness_score, last_meeting_at, stage_changed_at, created_at, is_archived,
          detection_signal_fields, eval_start_date, eval_end_date, eval_type, eval_phase_override,
          accounts!inner(id, name)
        `)
        .eq('is_archived', false)
        .or(`owner_email.eq.${memberEmail},primary_se_email.eq.${memberEmail}`)
        .order('value', { ascending: false })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: !!memberEmail && enabled,
  });

  // Also check opportunity_team_members for additional assignments
  const { data: teamMemberOpps } = useQuery({
    queryKey: ['one-on-one-team-opps', memberEmail],
    queryFn: async () => {
      if (!memberEmail) return [];
      const { data, error } = await gateway
        .from('opportunity_team_members')
        .select('opportunity_id')
        .eq('team_member_email', memberEmail)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []).map((d: any) => d.opportunity_id);
    },
    enabled: !!memberEmail && enabled,
  });

  // Fetch additional opps from team membership
  const additionalOppIds = useMemo(() => {
    if (!teamMemberOpps || !opportunities) return [];
    const existingIds = new Set(opportunities.map((o: any) => o.id));
    return teamMemberOpps.filter((id: string) => !existingIds.has(id));
  }, [teamMemberOpps, opportunities]);

  const { data: additionalOpps } = useQuery({
    queryKey: ['one-on-one-additional-opps', additionalOppIds],
    queryFn: async () => {
      if (!additionalOppIds.length) return [];
      const { data, error } = await gateway
        .from('opportunities')
        .select(`
          id, name, account_id, value, close_date, sales_stage, pre_sales_stage,
          readiness_score, last_meeting_at, stage_changed_at, created_at, is_archived,
          detection_signal_fields, eval_start_date, eval_end_date, eval_type, eval_phase_override,
          accounts!inner(id, name)
        `)
        .eq('is_archived', false)
        .in('id', additionalOppIds)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: additionalOppIds.length > 0,
  });

  // Fetch recently completed NBAs (last 14 days)
  const fourteenDaysAgo = subDays(new Date(), 14).toISOString();

  const { data: completedNBAs } = useQuery({
    queryKey: ['one-on-one-nbas', memberEmail],
    queryFn: async () => {
      if (!memberEmail) return [];
      const { data, error } = await gateway
        .from('account_nbas')
        .select(`
          id, action, completed_at, status, opportunity_id,
          opportunities(name)
        `)
        .eq('assigned_to', memberEmail)
        .eq('status', 'completed')
        .gte('completed_at', fourteenDaysAgo)
        .order('completed_at', { ascending: false })
        .limit(20)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: !!memberEmail && enabled,
  });

  // Fetch coaching NBAs
  const { data: coachingNBAs } = useQuery({
    queryKey: ['one-on-one-coaching', memberEmail],
    queryFn: async () => {
      if (!memberEmail || !opportunities?.length) return [];
      const oppIds = [...(opportunities || []), ...(additionalOpps || [])].map((o: any) => o.id);
      if (!oppIds.length) return [];
      
      const { data, error } = await gateway
        .from('account_nbas')
        .select(`
          id, action, priority, notes, opportunity_id, account_id,
          opportunities(name),
          accounts(name)
        `)
        .eq('action_type', 'coaching')
        .eq('status', 'pending')
        .in('opportunity_id', oppIds)
        .order('created_at', { ascending: false })
        .limit(10)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: !!memberEmail && enabled && (opportunities?.length || 0) > 0,
  });

  // Fetch recent meetings count
  const { data: recentMeetings } = useQuery({
    queryKey: ['one-on-one-meetings', memberEmail],
    queryFn: async () => {
      if (!memberEmail) return [];
      // Query meetings where the team member was the host
      // Note: attendees is encrypted JSONB, so we can only reliably filter by host_email
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select('id')
        .eq('host_email', memberEmail)
        .gte('start_time', fourteenDaysAgo)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: !!memberEmail && enabled,
  });

  // Fetch SE coaching scores with full dimension data
  const { data: coachingScores } = useQuery({
    queryKey: ['one-on-one-coaching-scores', memberEmail],
    queryFn: async () => {
      if (!memberEmail) return [];
      const { data, error } = await gateway
        .from('se_coaching_scores')
        .select(`
          id, transcript_id, overall_score, meeting_type, created_at,
          account_id,
          accounts(name),
          questioning_score, storytelling_proof_score, objection_handling_score,
          pain_quantification_score, champion_arming_score, differentiation_score,
          pov_challenge_score, ownership_control_score, reverse_demo_score,
          strategy_rigor_score, technical_competency_score, value_anchoring_score,
          talk_ratio_score,
          greatness_moment, opportunity_gap, actionable_next_step,
          what_worked_well, what_didnt_work, coaching_guidance
        `)
        .eq('se_email', memberEmail)
        .order('created_at', { ascending: false })
        .limit(10)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: !!memberEmail && enabled,
  });

  // Fetch eval milestones for all opps
  const allOppIds = useMemo(() => {
    return [...(opportunities || []), ...(additionalOpps || [])].map((o: any) => o.id);
  }, [opportunities, additionalOpps]);

  const { data: evalMilestones } = useQuery({
    queryKey: ['one-on-one-eval-milestones', allOppIds],
    queryFn: async () => {
      if (!allOppIds.length) return [];
      const { data, error } = await gateway
        .from('opportunity_milestones')
        .select('id, opportunity_id, name, phase, status, scheduled_date, completed_date, sort_order')
        .in('opportunity_id', allOppIds)
        .order('sort_order', { ascending: true })
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: allOppIds.length > 0 && enabled,
  });

  // Fetch risks/issues for all opps
  const { data: evalRisks } = useQuery({
    queryKey: ['one-on-one-eval-risks', allOppIds],
    queryFn: async () => {
      if (!allOppIds.length) return [];
      const { data, error } = await gateway
        .from('evaluation_technical_risks')
        .select('id, opportunity_id, risk_description, severity, status, entry_type')
        .in('opportunity_id', allOppIds)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: allOppIds.length > 0 && enabled,
  });

  const prepData = useMemo<OneOnOnePrepData | null>(() => {
    if (!memberEmail) return null;

    const allOpps = [...(opportunities || []), ...(additionalOpps || [])];
    const now = new Date();
    const fourteenDaysAgoDate = subDays(now, 14);
    const sixtyDaysFromNow = subDays(now, -60);

    const mappedOpps: PrepOpportunity[] = allOpps.map((opp: any) => {
      const lastMeeting = opp.last_meeting_at ? new Date(opp.last_meeting_at) : null;
      const stageChanged = opp.stage_changed_at ? new Date(opp.stage_changed_at) : null;
      const closeDate = opp.close_date ? new Date(opp.close_date) : null;
      const daysSinceActivity = lastMeeting
        ? Math.floor((now.getTime() - lastMeeting.getTime()) / (1000 * 60 * 60 * 24))
        : 999;
      
      const hasEvalSignal = opp.detection_signal_fields?.evaluation_poc;
      const hasLowReadiness = (opp.readiness_score ?? 0) < 50;
      const closingSoon = closeDate && closeDate <= sixtyDaysFromNow;

      let status: PrepOpportunity['status'] = 'healthy';
      let statusReason = 'On track';

      if (daysSinceActivity > 14 && !stageChanged) {
        status = 'stalled';
        statusReason = `No activity for ${daysSinceActivity} days`;
      } else if (daysSinceActivity > 14 && stageChanged && (now.getTime() - stageChanged.getTime()) > 14 * 24 * 60 * 60 * 1000) {
        status = 'stalled';
        statusReason = `Stage unchanged for ${Math.floor((now.getTime() - stageChanged.getTime()) / (1000 * 60 * 60 * 24))} days`;
      } else if (hasLowReadiness && closingSoon) {
        status = 'at_risk';
        statusReason = `Low readiness (${opp.readiness_score}%) with close date approaching`;
      } else if (hasEvalSignal) {
        status = 'eval_ready';
        statusReason = 'Evaluation/POC signal detected';
      } else if (daysSinceActivity <= 7) {
        status = 'progressing';
        statusReason = lastMeeting ? `Last meeting ${formatDistanceToNow(lastMeeting, { addSuffix: true })}` : 'Recently active';
      }

      return {
        id: opp.id,
        name: opp.name,
        accountName: opp.accounts?.name || 'Unknown',
        value: opp.value,
        closeDate: opp.close_date,
        salesStage: opp.sales_stage,
        preSalesStage: opp.pre_sales_stage,
        readinessScore: opp.readiness_score,
        lastMeetingAt: opp.last_meeting_at,
        stageChangedAt: opp.stage_changed_at,
        createdAt: opp.created_at,
        signals: opp.detection_signal_fields,
        status,
        statusReason,
      };
    });

    // Sort: at_risk first, then stalled, then eval_ready, then progressing, then healthy
    const statusOrder = { at_risk: 0, stalled: 1, eval_ready: 2, progressing: 3, healthy: 4 };
    mappedOpps.sort((a, b) => statusOrder[a.status] - statusOrder[b.status]);

    const accomplishments: PrepAccomplishment[] = (completedNBAs || []).map((nba: any) => ({
      type: 'nba_completed' as const,
      description: `Completed: ${nba.action || 'Action item'}${nba.opportunities?.name ? ` (${nba.opportunities.name})` : ''}`,
      date: nba.completed_at,
    }));

    const coachingItems: PrepCoachingItem[] = (coachingNBAs || []).map((nba: any) => ({
      id: nba.id,
      action: nba.action || 'Coaching recommendation',
      notes: nba.notes || null,
      opportunityName: nba.opportunities?.name || 'Account-level',
      accountName: nba.accounts?.name || null,
      priority: nba.priority,
    }));

    // Build eval opportunities synopsis
    const evalOpportunities: PrepEvalOpportunity[] = allOpps
      .filter((opp: any) => opp.eval_start_date || opp.eval_end_date || opp.eval_type || opp.eval_phase_override)
      .map((opp: any) => {
        const oppMilestones = (evalMilestones || []).filter((m: any) => m.opportunity_id === opp.id);
        const oppRisks = (evalRisks || []).filter((r: any) => r.opportunity_id === opp.id);

        const completed = oppMilestones.filter((m: any) => m.status === 'completed').length;
        const inProgress = oppMilestones.filter((m: any) => m.status === 'in_progress').length;

        // Group milestones by phase
        const phases: Record<string, { total: number; completed: number }> = {};
        oppMilestones.forEach((m: any) => {
          if (!phases[m.phase]) phases[m.phase] = { total: 0, completed: 0 };
          phases[m.phase].total++;
          if (m.status === 'completed') phases[m.phase].completed++;
        });

        // Find next upcoming milestone
        const upcoming = oppMilestones
          .filter((m: any) => m.scheduled_date && m.status !== 'completed' && m.status !== 'skipped')
          .sort((a: any, b: any) => new Date(a.scheduled_date).getTime() - new Date(b.scheduled_date).getTime());
        const nextUpcoming = upcoming.length > 0
          ? { name: upcoming[0].name || 'Untitled', date: upcoming[0].scheduled_date }
          : null;

        return {
          id: opp.id,
          name: opp.name,
          accountName: opp.accounts?.name || 'Unknown',
          evalStartDate: opp.eval_start_date,
          evalEndDate: opp.eval_end_date,
          evalType: opp.eval_type,
          evalPhase: opp.eval_phase_override,
          milestones: {
            total: oppMilestones.length,
            completed,
            inProgress,
            phases,
            nextUpcoming,
          },
          risks: oppRisks.map((r: any) => ({
            id: r.id,
            description: r.risk_description,
            severity: r.severity,
            status: r.status,
            entryType: r.entry_type,
          })),
        };
      });

    return {
      memberEmail,
      memberName: null,
      opportunities: mappedOpps,
      accomplishments,
      coachingItems,
      evalOpportunities,
      summary: {
        totalOpps: mappedOpps.length,
        totalPipeline: mappedOpps.reduce((sum, o) => sum + (o.value || 0), 0),
        stalledCount: mappedOpps.filter(o => o.status === 'stalled').length,
        progressingCount: mappedOpps.filter(o => o.status === 'progressing').length,
        evalReadyCount: mappedOpps.filter(o => o.status === 'eval_ready').length,
        atRiskCount: mappedOpps.filter(o => o.status === 'at_risk').length,
        nbasCompletedCount: (completedNBAs || []).length,
        meetingsLast14d: (recentMeetings || []).length,
      },
    };
  }, [memberEmail, opportunities, additionalOpps, completedNBAs, coachingNBAs, recentMeetings, evalMilestones, evalRisks]);

  // Compute holistic coaching data
  const holisticCoaching = useMemo<HolisticCoachingData | null>(() => {
    const scores = coachingScores || [];
    if (!scores.length) return null;

    const DIMENSIONS = [
      { key: 'questioning_score', label: 'Questioning' },
      { key: 'storytelling_proof_score', label: 'Storytelling & Proof' },
      { key: 'objection_handling_score', label: 'Objection Handling' },
      { key: 'pain_quantification_score', label: 'Pain Quantification' },
      { key: 'champion_arming_score', label: 'Champion Arming' },
      { key: 'differentiation_score', label: 'Differentiation' },
      { key: 'pov_challenge_score', label: 'POV Challenge' },
      { key: 'ownership_control_score', label: 'Ownership & Control' },
      { key: 'reverse_demo_score', label: 'Reverse Demo' },
      { key: 'strategy_rigor_score', label: 'Strategy Rigor' },
      { key: 'technical_competency_score', label: 'Technical Competency' },
      { key: 'value_anchoring_score', label: 'Value Anchoring' },
      { key: 'talk_ratio_score', label: 'Talk Ratio' },
    ];

    // Calculate dimension summaries
    const dimensionSummaries: CoachingDimensionSummary[] = DIMENSIONS
      .map(dim => {
        const dimScores = scores
          .map((s: any) => s[dim.key])
          .filter((v: any) => v != null && v > 0) as number[];
        if (!dimScores.length) return null;
        
        const avg = dimScores.reduce((a, b) => a + b, 0) / dimScores.length;
        
        // Trend: compare first half vs second half
        let trend: 'improving' | 'declining' | 'stable' = 'stable';
        if (dimScores.length >= 3) {
          // scores are newest-first, so reverse for chronological
          const chrono = [...dimScores].reverse();
          const mid = Math.floor(chrono.length / 2);
          const firstHalf = chrono.slice(0, mid).reduce((a, b) => a + b, 0) / mid;
          const secondHalf = chrono.slice(mid).reduce((a, b) => a + b, 0) / (chrono.length - mid);
          if (secondHalf - firstHalf >= 0.5) trend = 'improving';
          else if (firstHalf - secondHalf >= 0.5) trend = 'declining';
        }

        return {
          dimension: dim.key,
          label: dim.label,
          avgScore: Math.round(avg * 10) / 10,
          scores: dimScores,
          trend,
        };
      })
      .filter(Boolean) as CoachingDimensionSummary[];

    // Sort by avgScore ascending (weakest first)
    dimensionSummaries.sort((a, b) => a.avgScore - b.avgScore);

    // Build per-call insights
    const callInsights: CoachingCallInsight[] = scores.map((s: any) => {
      const dimEntries = DIMENSIONS
        .filter(d => s[d.key] != null && s[d.key] > 0)
        .map(d => ({ dimension: d.label, score: s[d.key] as number }))
        .sort((a, b) => a.score - b.score);

      return {
        transcriptId: s.transcript_id,
        meetingType: s.meeting_type,
        overallScore: s.overall_score,
        date: s.created_at,
        accountId: s.account_id || null,
        accountName: s.accounts?.name || null,
        greatnessMoment: s.greatness_moment,
        opportunityGap: s.opportunity_gap,
        actionableNextStep: s.actionable_next_step,
        whatWorkedWell: s.what_worked_well,
        whatDidntWork: s.what_didnt_work,
        coachingGuidance: s.coaching_guidance,
        weakestDimensions: dimEntries.slice(0, 3),
      };
    });

    // Overall average and trend
    const overallScores = scores.map((s: any) => s.overall_score).filter((v: any) => v != null);
    const overallAvg = overallScores.length 
      ? Math.round((overallScores.reduce((a: number, b: number) => a + b, 0) / overallScores.length) * 10) / 10
      : 0;

    let overallTrend: 'improving' | 'declining' | 'stable' = 'stable';
    if (overallScores.length >= 3) {
      const chrono = [...overallScores].reverse();
      const mid = Math.floor(chrono.length / 2);
      const first = chrono.slice(0, mid).reduce((a: number, b: number) => a + b, 0) / mid;
      const second = chrono.slice(mid).reduce((a: number, b: number) => a + b, 0) / (chrono.length - mid);
      if (second - first >= 0.3) overallTrend = 'improving';
      else if (first - second >= 0.3) overallTrend = 'declining';
    }

    // Top strengths and gaps
    const topStrengths = dimensionSummaries.filter(d => d.avgScore >= 3.5).slice(-3).reverse().map(d => d.label);
    const topGaps = dimensionSummaries.filter(d => d.avgScore < 3).slice(0, 3).map(d => d.label);

    // Recurring guidance patterns (dedupe by technique name)
    const allGuidance: string[] = [];
    scores.forEach((s: any) => {
      if (Array.isArray(s.coaching_guidance)) {
        s.coaching_guidance.forEach((g: any) => {
          if (g?.technique && !allGuidance.includes(g.technique)) {
            allGuidance.push(g.technique);
          }
        });
      }
    });

    // Group calls by account
    const accountMap = new Map<string, CoachingCallInsight[]>();
    callInsights.forEach(c => {
      const key = c.accountId || 'unknown';
      if (!accountMap.has(key)) accountMap.set(key, []);
      accountMap.get(key)!.push(c);
    });

    const accountGroups: CoachingAccountGroup[] = Array.from(accountMap.entries()).map(([accId, calls]) => {
      const accScores = calls.map(c => c.overallScore).filter(v => v != null);
      const avg = accScores.length ? Math.round((accScores.reduce((a, b) => a + b, 0) / accScores.length) * 10) / 10 : 0;
      let trend: 'improving' | 'declining' | 'stable' = 'stable';
      if (accScores.length >= 2) {
        const chrono = [...accScores].reverse();
        const mid = Math.floor(chrono.length / 2);
        const first = chrono.slice(0, mid).reduce((a, b) => a + b, 0) / mid;
        const second = chrono.slice(mid).reduce((a, b) => a + b, 0) / (chrono.length - mid);
        if (second - first >= 0.3) trend = 'improving';
        else if (first - second >= 0.3) trend = 'declining';
      }
      return {
        accountId: accId,
        accountName: calls[0]?.accountName || 'Unknown Account',
        calls: calls.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
        avgScore: avg,
        trend,
      };
    }).sort((a, b) => a.avgScore - b.avgScore); // weakest accounts first

    return {
      dimensionSummaries,
      callInsights,
      accountGroups,
      overallAvg,
      overallTrend,
      topStrengths,
      topGaps,
      recurringGuidance: allGuidance.slice(0, 5),
    };
  }, [coachingScores]);

  return {
    prepData,
    coachingScores: coachingScores || [],
    holisticCoaching,
    isLoading: oppsLoading,
  };
}

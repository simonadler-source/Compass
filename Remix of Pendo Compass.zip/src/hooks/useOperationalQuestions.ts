import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface OperationalQuestion {
  id: string;
  question: string;
  category: string;
  sub_category: string | null;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export const OPERATIONAL_CATEGORIES = [
  { value: 'support_tickets', label: 'Support Tickets' },
  { value: 'development_velocity', label: 'Development Velocity' },
  { value: 'user_metrics', label: 'User Metrics' },
  { value: 'resource_utilization', label: 'Resource Utilization' },
  { value: 'performance_sla', label: 'Performance/SLAs' },
  { value: 'general', label: 'General' },
] as const;

export function useOperationalQuestions(category?: string) {
  return useQuery({
    queryKey: ['operational-questions', category],
    queryFn: async () => {
      let query = gateway.from('operational_questions')
        .select('*')
        .order('category', { ascending: true });

      if (category) {
        query = query.eq('category', category);
      }

      const result = await query.execute();
      if (result.error) throw new Error(result.error.message);
      return result.data as OperationalQuestion[];
    },
  });
}

export function useCreateOperationalQuestion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: {
      question: string;
      category: string;
      sub_category?: string;
    }) => {
      const result = await gateway.from('operational_questions')
        .insert(data)
        .execute();

      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['operational-questions'] });
      toast.success('Question created');
    },
    onError: (error) => {
      toast.error('Failed to create question: ' + error.message);
    },
  });
}

export function useUpdateOperationalQuestion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      ...data
    }: {
      id: string;
      question?: string;
      category?: string;
      sub_category?: string;
      is_active?: boolean;
    }) => {
      const result = await gateway.from('operational_questions')
        .update({ ...data, updated_at: new Date().toISOString() })
        .eq('id', id)
        .execute();

      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['operational-questions'] });
      toast.success('Question updated');
    },
    onError: (error) => {
      toast.error('Failed to update question: ' + error.message);
    },
  });
}

export function useDeleteOperationalQuestion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const result = await gateway.from('operational_questions')
        .delete()
        .eq('id', id)
        .execute();

      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['operational-questions'] });
      toast.success('Question deleted');
    },
    onError: (error) => {
      toast.error('Failed to delete question: ' + error.message);
    },
  });
}

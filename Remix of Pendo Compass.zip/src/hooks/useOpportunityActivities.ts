import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { gateway, getErrorMessage } from "@/lib/apiGateway";

export interface ActivityType {
  id: string; name: string; label: string; icon: string; color: string;
  description: string | null; sort_order: number; is_minor: boolean;
}

export interface OpportunityActivity {
  id: string; opportunity_id: string; account_id: string; transcript_id: string | null;
  activity_type_id: string; activity_date: string; title: string | null;
  sentiment_score: number | null; sentiment_label: string | null; confidence_score: number | null;
  detection_source: string; ae_email: string | null; se_email: string | null;
  notes: string | null; created_at: string; activity_type?: ActivityType;
}

export function useActivityTypes() {
  return useQuery({
    queryKey: ['activity-types'],
    queryFn: async () => {
      const { data, error } = await gateway.from('activity_types').select('*').eq('is_active', true).order('sort_order').execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as ActivityType[];
    },
    staleTime: 1000 * 60 * 30,
  });
}

export function useOpportunityActivities(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-activities', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway.from('opportunity_activities').select(`*, activity_type:activity_types(*)`).eq('opportunity_id', opportunityId).order('activity_date', { ascending: true }).execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as OpportunityActivity[];
    },
    enabled: !!opportunityId,
  });
}

export function useAccountActivities(accountId: string) {
  return useQuery({
    queryKey: ['account-activities', accountId],
    queryFn: async () => {
      const { data, error } = await gateway.from('opportunity_activities').select(`*, activity_type:activity_types(*), opportunity:opportunities(id, name)`).eq('account_id', accountId).order('activity_date', { ascending: true }).execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as (OpportunityActivity & { opportunity: { id: string; name: string } })[];
    },
    enabled: !!accountId,
  });
}

export function useActivityKPIs(filters: { aeEmail?: string | null; seEmail?: string | null; accountId?: string | null; dateFrom?: string | null; dateTo?: string | null; }) {
  return useQuery({
    queryKey: ['activity-kpis', filters],
    queryFn: async () => {
      let query = gateway.from('opportunity_activities').select(`id, activity_type_id, activity_date, ae_email, se_email, account_id, opportunity_id, activity_type:activity_types(name, label, icon, color)`);
      if (filters.aeEmail) query = query.eq('ae_email', filters.aeEmail);
      if (filters.seEmail) query = query.eq('se_email', filters.seEmail);
      if (filters.accountId) query = query.eq('account_id', filters.accountId);
      if (filters.dateFrom) query = query.gte('activity_date', filters.dateFrom);
      if (filters.dateTo) query = query.lte('activity_date', filters.dateTo);
      const { data, error } = await query.execute();
      if (error) throw new Error(getErrorMessage(error));
      const byType: Record<string, { count: number; label: string; icon: string; color: string }> = {};
      for (const activity of data || []) {
        const typeName = (activity.activity_type as any)?.name || 'unknown';
        if (!byType[typeName]) byType[typeName] = { count: 0, label: (activity.activity_type as any)?.label || typeName, icon: (activity.activity_type as any)?.icon || 'circle', color: (activity.activity_type as any)?.color || '#6366f1' };
        byType[typeName].count++;
      }
      return { totalActivities: data?.length || 0, byType, activities: data || [] };
    },
  });
}

export function useCreateActivity() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (activity: Omit<OpportunityActivity, 'id' | 'created_at' | 'activity_type'>) => {
      const { data, error } = await gateway.from('opportunity_activities').insert(activity).single().execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-activities', data.opportunity_id] });
      queryClient.invalidateQueries({ queryKey: ['account-activities', data.account_id] });
      queryClient.invalidateQueries({ queryKey: ['activity-kpis'] });
    },
  });
}

export function mapMeetingTypeToActivity(meetingType: string): string {
  const mapping: Record<string, string> = { 'discovery': 'discovery', 'demo': 'demo', 'technical': 'technical', 'workshop': 'workshop', 'executive': 'executive_playback', 'commercial': 'commercial', 'check_in': 'check_in', 'training': 'training', 'negotiation': 'commercial', 'contract': 'commercial', 'email_followup': 'email_followup', 'email_proposal': 'email_proposal', 'email_introduction': 'email_introduction', 'email_status_update': 'email_status_update', 'email_technical': 'email_technical', 'email_scheduling': 'email_scheduling', 'email_other': 'email_other' };
  return mapping[meetingType] || 'discovery';
}

export function detectContentType(content: string): 'email' | 'meeting' {
  const emailPatterns = [/^from:\s*/im, /^to:\s*/im, /^subject:\s*/im, /^cc:\s*/im, /^bcc:\s*/im, /^sent:\s*/im, /^date:\s*\w+,?\s+\w+\s+\d+/im, /^on\s+\w+,?\s+\w+\s+\d+.*wrote:/im, /^[-]+\s*original\s+message\s*[-]+/im, /^[-]+\s*forwarded\s+message\s*[-]+/im, /^begin\s+forwarded\s+message/im, /^reply\s+to:/im, />+\s*on\s+\w+.*wrote:/im];
  const matchCount = emailPatterns.filter(pattern => pattern.test(content)).length;
  if (matchCount >= 2) return 'email';
  const lines = content.split('\n').filter(l => l.trim());
  const hasGreeting = /^(hi|hello|hey|dear|good\s+(morning|afternoon|evening))[,\s]/im.test(content);
  const hasSignoff = /(^(best|regards|thanks|cheers|sincerely)[,\s]|^(best\s+regards|kind\s+regards|thanks\s+and\s+regards)[,\s])/im.test(content);
  const avgLineLength = lines.reduce((sum, l) => sum + l.length, 0) / lines.length;
  if (hasGreeting && hasSignoff && avgLineLength < 120) return 'email';
  if (matchCount >= 1 && (hasGreeting || hasSignoff)) return 'email';
  return 'meeting';
}

export function inferEmailType(subject: string, content: string): string {
  const combined = `${subject} ${content}`.toLowerCase();
  if (combined.includes('introduction') || combined.includes('intro call') || combined.includes('nice to meet') || combined.includes('introducing')) return 'email_introduction';
  if (combined.includes('proposal') || combined.includes('quote') || combined.includes('pricing') || combined.includes('offer')) return 'email_proposal';
  if (combined.includes('status update') || combined.includes('progress update') || combined.includes('weekly update') || combined.includes('summary of')) return 'email_status_update';
  if (combined.includes('technical') || combined.includes('api') || combined.includes('integration') || combined.includes('implementation')) return 'email_technical';
  if (combined.includes('schedule') || combined.includes('calendar') || combined.includes('meeting invite') || combined.includes('availability')) return 'email_scheduling';
  if (combined.includes('follow up') || combined.includes('following up') || combined.includes('as discussed') || combined.includes('per our conversation')) return 'email_followup';
  return 'email_followup';
}

export function inferActivityType(title: string, content?: string): string {
  const lowerTitle = title.toLowerCase();
  const lowerContent = content?.toLowerCase() || '';
  const combined = `${lowerTitle} ${lowerContent}`;
  if (content && detectContentType(content) === 'email') return inferEmailType(title, content);
  if (combined.includes('reverse demo') || combined.includes('reverse-demo')) return 'reverse_demo';
  if (combined.includes('dry run') || combined.includes('dry-run') || combined.includes('practice')) return 'dry_run';
  if (combined.includes('playback') || combined.includes('executive summary') || combined.includes('ebr') || combined.includes('qbr')) return 'executive_playback';
  if (combined.includes('evaluation') || combined.includes('trial') || combined.includes('poc') || combined.includes('proof of concept')) return 'evaluation';
  if (combined.includes('scoping') || combined.includes('scope') || combined.includes('requirements')) return 'scoping';
  if (combined.includes('workshop') || combined.includes('hands-on') || combined.includes('working session')) return 'workshop';
  if (combined.includes('demo') || combined.includes('demonstration') || combined.includes('walkthrough')) return 'demo';
  if (combined.includes('pricing') || combined.includes('commercial') || combined.includes('contract') || combined.includes('negotiation')) return 'commercial';
  if (combined.includes('technical') || combined.includes('integration') || combined.includes('api')) return 'technical';
  if (combined.includes('training') || combined.includes('onboarding') || combined.includes('enablement')) return 'training';
  if (combined.includes('check-in') || combined.includes('status') || combined.includes('sync') || combined.includes('weekly')) return 'check_in';
  return 'discovery';
}

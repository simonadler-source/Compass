import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import type { RuleConditions } from '@/components/alert-rules/types';

export type RuleType = 
  | 'readiness_below_threshold'
  | 'unanswered_questions_count'
  | 'stale_readiness'
  | 'stalled_stage'
  | 'missing_stakeholders'
  | 'no_recent_meetings'
  | 'milestone_overdue'
  | 'security_incomplete'
  | 'missing_signal'
  | 'no_metrics'
  | 'no_pain_points'
  | 'no_use_cases'
  | 'custom'
  | 'advanced'; // New type for condition builder rules

export type AssignedToType = 'primary_se' | 'opportunity_owner' | 'account_owner' | 'rule_creator' | 'team_manager';
export type NbaPriority = 'low' | 'medium' | 'high' | 'critical';
export type NbaDeliveryMethod = 'email' | 'meeting' | 'internal';

export interface ThresholdConfig {
  minScore?: number;
  maxDays?: number;
  maxUnanswered?: number;
  category?: string;
  requiredRoles?: string[];
  signalFieldName?: string; // For missing_signal rule type
  signalDisplayName?: string; // Human-readable signal name
  minCount?: number; // For metrics/pain points/use cases count checks
  customCondition?: string;
  // New: Advanced condition builder configuration
  conditions?: RuleConditions;
  [key: string]: unknown; // Index signature for Json compatibility
}

export interface OpportunityAlertRule {
  id: string;
  name: string;
  description: string | null;
  rule_type: RuleType;
  threshold_config: ThresholdConfig;
  nba_action_text: string;
  nba_priority: NbaPriority;
  nba_delivery_method: NbaDeliveryMethod;
  assigned_to_type: AssignedToType;
  cooldown_days: number;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
  // Ownership fields
  owner_id: string | null;
  is_system_rule: boolean;
  copied_from_rule_id: string | null;
}

export interface AlertHistory {
  id: string;
  rule_id: string;
  opportunity_id: string;
  triggered_at: string;
  nba_id: string | null;
  trigger_data: Record<string, unknown> | null;
}

export interface AvailableSignal {
  id: string;
  name: string;
  signal_field_name: string;
}

export const RULE_TYPE_LABELS: Record<RuleType, string> = {
  readiness_below_threshold: 'Readiness Score Below Threshold',
  unanswered_questions_count: 'Too Many Unanswered Questions',
  stale_readiness: 'Stale Technical Readiness',
  stalled_stage: 'Stalled Opportunity Stage',
  missing_stakeholders: 'Missing Key Stakeholders',
  no_recent_meetings: 'No Recent Meetings',
  milestone_overdue: 'Milestone Overdue',
  security_incomplete: 'Security Review Incomplete',
  missing_signal: 'Missing Detection Signal',
  no_metrics: 'No Metrics Captured',
  no_pain_points: 'No Pain Points Identified',
  no_use_cases: 'No Use Cases Identified',
  custom: 'Custom Rule',
  advanced: 'Advanced Conditions',
};

export const RULE_TYPE_DESCRIPTIONS: Record<RuleType, string> = {
  readiness_below_threshold: 'Triggers when the technical readiness score drops below a specified percentage',
  unanswered_questions_count: 'Triggers when too many questions in a category remain unanswered',
  stale_readiness: 'Triggers when there are no readiness updates for a specified number of days',
  stalled_stage: 'Triggers when an opportunity stays in the same stage for too long',
  missing_stakeholders: 'Triggers when required stakeholder roles are not identified',
  no_recent_meetings: 'Triggers when there are no customer meetings for a specified period',
  milestone_overdue: 'Triggers when a milestone date has passed',
  security_incomplete: 'Triggers when security-related questions are incomplete',
  missing_signal: 'Triggers when a specific detection signal has not been captured (e.g., Legal, NDA, Pricing)',
  no_metrics: 'Triggers when no business metrics have been captured for the opportunity',
  no_pain_points: 'Triggers when no pain points have been identified for the opportunity',
  no_use_cases: 'Triggers when no use cases have been identified for the opportunity',
  custom: 'Custom rule with flexible conditions',
  advanced: 'Configure multiple conditions with AND/OR logic and grouping for complex trigger scenarios',
};

// Fetch available signals from detection_rules that have signal_field_name
const ACTIVITY_SIGNALS_TREE_ID = 'f5e4d3c2-b1a0-9876-5432-fedcba098765';

export function useAvailableSignals() {
  return useQuery({
    queryKey: ['available-signals-for-alerts'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('detection_rules')
        .select('id, name, signal_field_name')
        .eq('tree_id', ACTIVITY_SIGNALS_TREE_ID)
        .eq('is_active', true)
        .not('signal_field_name', 'is', null)
        .order('name')
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as AvailableSignal[];
    },
  });
}

export function useOpportunityAlertRules(options?: { systemOnly?: boolean; userOnly?: boolean; userId?: string }) {
  return useQuery({
    queryKey: ['opportunity-alert-rules', options?.systemOnly, options?.userOnly, options?.userId],
    queryFn: async () => {
      let q = gateway
        .from('opportunity_alert_rules')
        .select('*')
        .order('is_system_rule', { ascending: false }) // System rules first
        .order('sort_order', { ascending: true });

      if (options?.systemOnly) {
        q = q.eq('is_system_rule', true);
      } else if (options?.userOnly && options?.userId) {
        q = q.eq('is_system_rule', false).eq('owner_id', options.userId);
      }

      const { data, error } = await q.execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as OpportunityAlertRule[];
    },
  });
}

// Separate hook for fetching user's own rules
export function useMyAlertRules(userId?: string) {
  return useQuery({
    queryKey: ['my-alert-rules', userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await gateway
        .from('opportunity_alert_rules')
        .select('*')
        .eq('owner_id', userId)
        .eq('is_system_rule', false)
        .order('sort_order', { ascending: true })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as OpportunityAlertRule[];
    },
    enabled: !!userId,
  });
}

export function useCreateAlertRule() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (rule: Omit<OpportunityAlertRule, 'id' | 'created_at' | 'updated_at'>) => {
      const result = await gateway
        .from('opportunity_alert_rules')
        .insert({
          name: rule.name,
          description: rule.description,
          rule_type: rule.rule_type,
          threshold_config: rule.threshold_config,
          nba_action_text: rule.nba_action_text,
          nba_priority: rule.nba_priority,
          nba_delivery_method: rule.nba_delivery_method,
          assigned_to_type: rule.assigned_to_type,
          cooldown_days: rule.cooldown_days,
          is_active: rule.is_active,
          sort_order: rule.sort_order,
          owner_id: rule.owner_id,
          is_system_rule: rule.is_system_rule ?? true,
          copied_from_rule_id: rule.copied_from_rule_id,
        })
        .execute();

      if (result.error) throw new Error(getErrorMessage(result.error));

      const inserted = Array.isArray(result.data) ? result.data[0] : result.data;
      return inserted as OpportunityAlertRule;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-alert-rules'] });
      queryClient.invalidateQueries({ queryKey: ['my-alert-rules'] });
    },
  });
}

// Copy a system rule to user's personal rules
export function useCopyRuleToUser() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ rule, userId, newName }: { rule: OpportunityAlertRule; userId: string; newName?: string }) => {
      const result = await gateway
        .from('opportunity_alert_rules')
        .insert({
          name: newName || `${rule.name} (My Copy)`,
          description: rule.description,
          rule_type: rule.rule_type,
          threshold_config: rule.threshold_config,
          nba_action_text: rule.nba_action_text,
          nba_priority: rule.nba_priority,
          nba_delivery_method: rule.nba_delivery_method,
          assigned_to_type: rule.assigned_to_type,
          cooldown_days: rule.cooldown_days,
          is_active: true,
          sort_order: 999, // Will be sorted after existing rules
          owner_id: userId,
          is_system_rule: false,
          copied_from_rule_id: rule.id,
        })
        .execute();

      if (result.error) throw new Error(getErrorMessage(result.error));

      const inserted = Array.isArray(result.data) ? result.data[0] : result.data;
      return inserted as OpportunityAlertRule;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-alert-rules'] });
      queryClient.invalidateQueries({ queryKey: ['my-alert-rules'] });
    },
  });
}

export function useUpdateAlertRule() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<OpportunityAlertRule> & { id: string }) => {
      const result = await gateway
        .from('opportunity_alert_rules')
        .update(updates as any)
        .eq('id', id)
        .execute();

      if (result.error) throw new Error(getErrorMessage(result.error));

      const updated = Array.isArray(result.data) ? result.data[0] : result.data;
      return updated as OpportunityAlertRule;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-alert-rules'] });
    },
  });
}

export function useDeleteAlertRule() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      const result = await gateway
        .from('opportunity_alert_rules')
        .delete()
        .eq('id', id)
        .execute();

      if (result.error) throw new Error(getErrorMessage(result.error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-alert-rules'] });
    },
  });
}

export function useToggleAlertRule() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const result = await gateway
        .from('opportunity_alert_rules')
        .update({ is_active })
        .eq('id', id)
        .execute();

      if (result.error) throw new Error(getErrorMessage(result.error));

      const updated = Array.isArray(result.data) ? result.data[0] : result.data;
      return updated as OpportunityAlertRule;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-alert-rules'] });
    },
  });
}

export function useAlertHistory(opportunityId?: string) {
  return useQuery({
    queryKey: ['alert-history', opportunityId],
    queryFn: async () => {
      let q = gateway
        .from('opportunity_alert_history')
        .select('*')
        .order('triggered_at', { ascending: false })
        .limit(100);

      if (opportunityId) {
        q = q.eq('opportunity_id', opportunityId);
      }

      const { data, error } = await q.execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as AlertHistory[];
    },
    enabled: true,
  });
}

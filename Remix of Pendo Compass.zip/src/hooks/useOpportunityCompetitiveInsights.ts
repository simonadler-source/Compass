import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

export interface CompetitiveInsight {
  id: string;
  opportunityId: string;
  accountId: string;
  transcriptId: string | null;
  competitorId: string | null;
  competitorName: string;
  mentionContext: string | null;
  mentionType: 'evaluation' | 'incumbent' | 'risk' | 'replacement_target' | 'comparison';
  speakerType: 'internal' | 'external' | 'unknown';
  speakerName: string | null;
  sentiment: 'positive' | 'neutral' | 'negative' | 'mixed';
  featureDiscussed: string | null;
  pendoPosition: 'stronger' | 'weaker' | 'equal' | 'unknown' | null;
  comparisonNotes: string | null;
  isObjection: boolean;
  objectionType: string | null;
  objectionSeverity: 'high' | 'medium' | 'low' | null;
  objectionText: string | null;
  winSignal: boolean;
  lossSignal: boolean;
  signalIndicator: string | null;
  confidenceScore: number;
  detectedAt: string;
}

export interface CompetitivePlaySuggestion {
  id: string;
  opportunityId: string;
  competitorId: string | null;
  competitorName: string | null;
  playType: 'landmine' | 'differentiation' | 'objection_handler' | 'feature_highlight' | 'case_study';
  playStrategy: 'attack' | 'defend';
  playTitle: string;
  playDescription: string | null;
  talkingPoints: string[];
  linkedUseCaseIds: string[];
  relevanceScore: number;
  triggeredBy: string | null;
  highlightFeatureIds: string[];
  status: 'suggested' | 'accepted' | 'dismissed' | 'executed';
  createdAt: string;
}

export interface ThreatAssessment {
  threatLevel: 'high' | 'medium' | 'low' | 'none';
  threatScore: number;
  competitorCount: number;
  objectionCount: number;
  highSeverityObjections: number;
  winSignals: number;
  lossSignals: number;
}

// Fetch competitive insights for an opportunity
export function useOpportunityCompetitiveInsights(opportunityId: string | null) {
  return useQuery({
    queryKey: ['opportunity-competitive-insights', opportunityId],
    queryFn: async () => {
      if (!opportunityId) return [];
      
      const { data, error } = await gateway
        .from('opportunity_competitive_insights')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('detected_at', { ascending: false })
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      
      return (data || []).map((row: any) => ({
        id: row.id,
        opportunityId: row.opportunity_id,
        accountId: row.account_id,
        transcriptId: row.transcript_id,
        competitorId: row.competitor_id,
        competitorName: row.competitor_name,
        mentionContext: row.mention_context,
        mentionType: row.mention_type,
        speakerType: row.speaker_type,
        speakerName: row.speaker_name,
        sentiment: row.sentiment,
        featureDiscussed: row.feature_discussed,
        pendoPosition: row.pendo_position,
        comparisonNotes: row.comparison_notes,
        isObjection: row.is_objection,
        objectionType: row.objection_type,
        objectionSeverity: row.objection_severity,
        objectionText: row.objection_text,
        winSignal: row.win_signal,
        lossSignal: row.loss_signal,
        signalIndicator: row.signal_indicator,
        confidenceScore: row.confidence_score,
        detectedAt: row.detected_at,
      })) as CompetitiveInsight[];
    },
    enabled: !!opportunityId,
  });
}

// Fetch competitive plays for an opportunity (from competitive_plays table)
export function useCompetitivePlaySuggestions(opportunityId: string | null) {
  return useQuery({
    queryKey: ['competitive-play-suggestions', opportunityId],
    queryFn: async () => {
      if (!opportunityId) return [];
      
      const { data, error } = await gateway
        .from('competitive_plays')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('confidence_score', { ascending: false })
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      
      return (data || []).map((row: any) => ({
        id: row.id,
        opportunityId: row.opportunity_id,
        competitorId: row.competitor_id,
        competitorName: row.competitor_name || null,
        playType: row.play_type,
        playStrategy: row.play_strategy || 'attack',
        playTitle: row.play_title,
        playDescription: row.play_description,
        talkingPoints: row.talking_points || [],
        linkedUseCaseIds: row.linked_use_case_ids || [],
        relevanceScore: row.confidence_score || 0,
        triggeredBy: row.source_transcript_id,
        highlightFeatureIds: row.relevant_categories || [],
        status: row.status,
        createdAt: row.created_at,
      })) as CompetitivePlaySuggestion[];
    },
    enabled: !!opportunityId,
  });
}

// Compute threat assessment from insights + all known competitors
export function useOpportunityThreatAssessment(opportunityId: string | null, allCompetitorNames?: string[]) {
  const { data: insights } = useOpportunityCompetitiveInsights(opportunityId);
  
  return useQuery({
    queryKey: ['opportunity-threat-assessment', opportunityId, insights?.length, allCompetitorNames?.length],
    queryFn: async (): Promise<ThreatAssessment> => {
      // Merge competitors from insights AND from external sources (product_mentions, transcripts)
      const insightCompetitors = new Set((insights || []).map(i => i.competitorName));
      const allCompetitors = new Set([...insightCompetitors, ...(allCompetitorNames || [])]);
      
      if (allCompetitors.size === 0) {
        return {
          threatLevel: 'none',
          threatScore: 0,
          competitorCount: 0,
          objectionCount: 0,
          highSeverityObjections: 0,
          winSignals: 0,
          lossSignals: 0,
        };
      }
      
      const objections = (insights || []).filter(i => i.isObjection);
      const highSeverityObjections = objections.filter(o => o.objectionSeverity === 'high');
      const winSignals = (insights || []).filter(i => i.winSignal).length;
      const lossSignals = (insights || []).filter(i => i.lossSignal).length;
      
      // Calculate threat score (0-100) based on ALL competitors
      let threatScore = 0;
      threatScore += Math.min(allCompetitors.size * 15, 30);
      threatScore += Math.min(objections.length * 10, 25);
      threatScore += highSeverityObjections.length * 15;
      threatScore += lossSignals * 10;
      threatScore -= winSignals * 5;
      threatScore = Math.max(0, Math.min(100, threatScore));
      
      let threatLevel: 'high' | 'medium' | 'low' | 'none' = 'none';
      if (threatScore >= 60) threatLevel = 'high';
      else if (threatScore >= 30) threatLevel = 'medium';
      else if (threatScore > 0) threatLevel = 'low';
      
      return {
        threatLevel,
        threatScore,
        competitorCount: allCompetitors.size,
        objectionCount: objections.length,
        highSeverityObjections: highSeverityObjections.length,
        winSignals,
        lossSignals,
      };
    },
    enabled: !!opportunityId && (!!insights || (allCompetitorNames && allCompetitorNames.length > 0)),
  });
}

// Update play status
export function useUpdatePlaySuggestionStatus() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ playId, status }: { playId: string; status: CompetitivePlaySuggestion['status'] }) => {
      const updateData: Record<string, any> = { status };
      if (status === 'executed') updateData.used_at = new Date().toISOString();
      if (status === 'dismissed') updateData.dismissed_at = new Date().toISOString();
      
      const { error } = await gateway
        .from('competitive_plays')
        .update(updateData)
        .eq('id', playId)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['competitive-play-suggestions'] });
    },
  });
}

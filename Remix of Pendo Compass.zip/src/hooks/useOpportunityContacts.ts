import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface OpportunityContact {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  name: string;
  role: string | null;
  email: string | null;
  phone: string | null;
  influence_level: number | null;
  sentiment: number | null;
  champion_score: number | null;
  notes: string | null;
  source: string | null;
  is_ignored: boolean | null;
  is_internal: boolean | null;
  created_at: string;
  updated_at: string;
}

// Fetch contacts for a specific opportunity
export function useOpportunityContacts(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-contacts', opportunityId],
    queryFn: async () => {
      const result = await gateway.from('account_contacts')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('name', { ascending: true })
        .execute();

      if (result.error) throw new Error(result.error.message);
      return result.data as OpportunityContact[];
    },
    enabled: !!opportunityId,
  });
}

// Fetch aggregated contacts across all opportunities for an account
export function useAggregatedAccountContacts(accountId: string) {
  return useQuery({
    queryKey: ['aggregated-account-contacts', accountId],
    queryFn: async () => {
      // Get all contacts for this account
      const contactsResult = await gateway.from('account_contacts')
        .select('*')
        .eq('account_id', accountId)
        .order('name', { ascending: true })
        .execute();

      if (contactsResult.error) throw new Error(contactsResult.error.message);

      // Get opportunities for labeling
      const oppsResult = await gateway.from('opportunities')
        .select('id, name')
        .eq('account_id', accountId)
        .execute();

      if (oppsResult.error) throw new Error(oppsResult.error.message);

      const oppMap = new Map((oppsResult.data as any[])?.map(o => [o.id, o.name]) || []);

      return (contactsResult.data || []).map((contact: any) => ({
        ...contact,
        opportunity_name: contact.opportunity_id ? oppMap.get(contact.opportunity_id) || 'Unknown' : 'Account Level',
      }));
    },
    enabled: !!accountId,
  });
}

export function useCreateOpportunityContact() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (contact: {
      account_id: string;
      opportunity_id: string;
      name: string;
      role?: string | null;
      email?: string | null;
      phone?: string | null;
      notes?: string | null;
      source?: string | null;
    }) => {
      const result = await gateway.from('account_contacts')
        .insert({
          ...contact,
          is_ignored: false,
          is_internal: false,
        })
        .execute();
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-contacts', data?.opportunity_id] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-contacts', data?.account_id] });
      queryClient.invalidateQueries({ queryKey: ['account-contacts-team', data?.account_id] });
      toast.success('Contact added');
    },
    onError: (error) => {
      toast.error('Failed to add contact: ' + error.message);
    },
  });
}

export function useUpdateOpportunityContact() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      id, 
      accountId, 
      opportunityId, 
      ...updates 
    }: Partial<OpportunityContact> & { 
      id: string; 
      accountId: string; 
      opportunityId: string;
    }) => {
      const result = await gateway.from('account_contacts')
        .update(updates)
        .eq('id', id)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return { ...result.data?.[0], accountId, opportunityId };
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-contacts', data?.opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-contacts', data?.accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-contacts-team', data?.accountId] });
    },
    onError: (error) => {
      toast.error('Failed to update contact: ' + error.message);
    },
  });
}

import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

export interface OpportunityInsight {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  capture_field_id: string;
  value: string | null;
  value_json: any;
  confidence_score: number | null;
  extracted_at: string;
  source_transcript_id: string | null;
  rule_match_id: string | null;
}

// Fetch insights for a specific opportunity
export function useOpportunityInsights(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-insights', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_captured_insights')
        .select(`
          *,
          detection_rule_capture_fields (
            field_name,
            field_type,
            description,
            detection_rules (
              name
            )
          )
        `)
        .eq('opportunity_id', opportunityId)
        .order('extracted_at', { ascending: false })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    enabled: !!opportunityId,
  });
}

// Fetch aggregated insights across all opportunities for an account
export function useAggregatedAccountInsights(accountId: string) {
  return useQuery({
    queryKey: ['aggregated-account-insights', accountId],
    queryFn: async () => {
      // Get all insights for this account
      const { data: insights, error: insightsError } = await gateway
        .from('account_captured_insights')
        .select(`
          *,
          detection_rule_capture_fields (
            field_name,
            field_type,
            description,
            detection_rules (
              name
            )
          )
        `)
        .eq('account_id', accountId)
        .order('extracted_at', { ascending: false })
        .execute();

      if (insightsError) throw new Error(getErrorMessage(insightsError));

      // Get opportunities for labeling
      const { data: opportunities, error: oppsError } = await gateway
        .from('opportunities')
        .select('id, name')
        .eq('account_id', accountId)
        .execute();

      if (oppsError) throw new Error(getErrorMessage(oppsError));

      const oppMap = new Map(opportunities?.map((o: any) => [o.id, o.name]) || []);

      return (insights || []).map((insight: any) => ({
        ...insight,
        opportunity_name: insight.opportunity_id ? oppMap.get(insight.opportunity_id) || 'Unknown' : 'Account Level',
      }));
    },
    enabled: !!accountId,
  });
}

// Fetch transcript-based insights for an opportunity
export function useOpportunityTranscriptInsights(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-transcript-insights', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('transcript_reviews')
        .select('id, file_name, meeting_title, extracted_insights, extracted_technologies, created_at')
        .eq('opportunity_id', opportunityId)
        .eq('status', 'approved')
        .order('created_at', { ascending: false })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    enabled: !!opportunityId,
  });
}

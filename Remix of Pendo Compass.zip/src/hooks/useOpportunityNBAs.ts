import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';
import { encryptedInsert, encryptedUpdate } from '@/lib/encryptedDb';

export interface OpportunityNBA {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  action: string;
  action_type: string;
  priority: string | null;
  status: string | null;
  notes: string | null;
  due_date: string | null;
  delivery_method: string | null;
  assigned_to: string | null;
  created_at: string;
  completed_at: string | null;
  auto_complete_confidence: number | null;
  auto_complete_reason: string | null;
  auto_completed_by_transcript_id: string | null;
  source_transcript_id: string | null;
}

// Fetch NBAs for a specific opportunity
export function useOpportunityNBAs(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-nbas', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_nbas')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('created_at', { ascending: false })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data as OpportunityNBA[];
    },
    enabled: !!opportunityId,
  });
}

// Fetch aggregated NBAs across all opportunities for an account
export function useAggregatedAccountNBAs(accountId: string) {
  return useQuery({
    queryKey: ['aggregated-account-nbas', accountId],
    queryFn: async () => {
      // Get all NBAs for this account
      const { data: nbas, error: nbasError } = await gateway
        .from('account_nbas')
        .select('*')
        .eq('account_id', accountId)
        .order('created_at', { ascending: false })
        .execute();

      if (nbasError) throw new Error(getErrorMessage(nbasError));

      // Get opportunities for labeling
      const { data: opportunities, error: oppsError } = await gateway
        .from('opportunities')
        .select('id, name')
        .eq('account_id', accountId)
        .execute();

      if (oppsError) throw new Error(getErrorMessage(oppsError));

      const oppMap = new Map(opportunities?.map((o: any) => [o.id, o.name]) || []);

      return (nbas || []).map((nba: any) => ({
        ...nba,
        opportunity_name: nba.opportunity_id ? oppMap.get(nba.opportunity_id) || 'Unknown' : 'Account Level',
      }));
    },
    enabled: !!accountId,
  });
}

// Default due date offsets by action type (in days)
const DUE_DATE_OFFSETS: Record<string, number> = {
  follow_up_meeting: 3,
  send_content: 2,
  poc_setup: 10,
  technical_deepdive: 7,
  security_assessment: 14,
  architecture_doc: 7,
  integration_review: 7,
  api_exploration: 5,
  performance_benchmark: 10,
  internal_discussion: 3,
  follow_up: 3,
};

// Calculate fallback due date based on action type
function calculateFallbackDueDate(actionType?: string): string {
  const today = new Date();
  const offsetDays = DUE_DATE_OFFSETS[actionType || 'follow_up'] || 5;
  today.setDate(today.getDate() + offsetDays);
  return today.toISOString().split('T')[0];
}

export function useCreateOpportunityNBA() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (nba: {
      account_id: string;
      opportunity_id: string;
      action: string;
      action_type: string;
      priority: string;
      delivery_method?: string;
      notes?: string;
      assigned_to?: string;
      due_date?: string;
    }) => {
      // Use provided due date or calculate fallback based on action type
      const finalDueDate = nba.due_date || calculateFallbackDueDate(nba.action_type);
      
      const { data, error } = await encryptedInsert('account_nbas', {
        ...nba,
        status: 'pending',
        due_date: finalDueDate,
      });
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', data.opportunity_id] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-nbas', data.account_id] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', data.account_id] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Action added');
    },
    onError: (error) => {
      toast.error('Failed to add action: ' + error.message);
    },
  });
}

export function useUpdateOpportunityNBAOwner() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId, opportunityId, assignedTo }: { id: string; accountId: string; opportunityId: string; assignedTo: string | null }) => {
      const { error } = await encryptedUpdate('account_nbas', id, { assigned_to: assignedTo });
      if (error) throw error;
      return { accountId, opportunityId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', data.opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-nbas', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Owner updated');
    },
  });
}

export function useUpdateOpportunityNBADueDate() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId, opportunityId, dueDate }: { id: string; accountId: string; opportunityId: string | null; dueDate: string | null }) => {
      const { error } = await encryptedUpdate('account_nbas', id, { due_date: dueDate });
      if (error) throw error;
      return { accountId, opportunityId };
    },
    onSuccess: (data) => {
      if (data.opportunityId) {
        queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', data.opportunityId] });
      }
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-nbas', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Due date updated');
    },
  });
}

export function useCompleteOpportunityNBA() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId, opportunityId }: { id: string; accountId: string; opportunityId: string }) => {
      const { error } = await encryptedUpdate('account_nbas', id, { status: 'completed' });
      if (error) throw error;
      return { accountId, opportunityId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', data.opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-nbas', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Action completed');
    },
  });
}

export function useReopenOpportunityNBA() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId, opportunityId }: { id: string; accountId: string; opportunityId: string }) => {
      const { error } = await encryptedUpdate('account_nbas', id, { status: 'pending' });
      if (error) throw error;
      return { accountId, opportunityId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', data.opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-nbas', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Action reopened');
    },
  });
}

export function useCancelOpportunityNBA() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId, opportunityId }: { id: string; accountId: string; opportunityId: string | null }) => {
      const { error } = await encryptedUpdate('account_nbas', id, { 
        status: 'cancelled',
        completed_at: new Date().toISOString()
      });
      if (error) throw error;
      return { accountId, opportunityId };
    },
    onSuccess: (data) => {
      if (data.opportunityId) {
        queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', data.opportunityId] });
      }
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-nbas', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['grouped-account-nbas'] });
      toast.success('Action cancelled');
    },
  });
}

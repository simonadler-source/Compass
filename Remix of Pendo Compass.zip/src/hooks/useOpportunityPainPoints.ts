import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { AccountPainPoint } from './useAccountPainPoints';

export function useOpportunityPainPoints(opportunityId: string | null) {
  return useQuery({
    queryKey: ['opportunity-pain-points', opportunityId],
    queryFn: async () => {
      if (!opportunityId) return [];
      
      const result = await gateway.from('account_pain_points')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('severity', { ascending: true })
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      // Sort by confidence_score as secondary sort
      const data = (result.data as AccountPainPoint[]) || [];
      return data.sort((a, b) => {
        const severityOrder: Record<string, number> = { high: 0, medium: 1, low: 2 };
        if (a.severity !== b.severity) {
          return severityOrder[a.severity] - severityOrder[b.severity];
        }
        return (b.confidence_score || 0) - (a.confidence_score || 0);
      });
    },
    enabled: !!opportunityId,
  });
}

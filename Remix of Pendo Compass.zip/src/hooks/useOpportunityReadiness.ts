import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { encryptedUpsert, encryptedInsert, encryptedUpdate } from '@/lib/encryptedDb';

// Types
export interface DeploymentType {
  id: string;
  name: string;
  description: string | null;
  sort_order: number;
}

export interface ReadinessCategory {
  id: string;
  deployment_type_id: string | null;
  name: string;
  description: string | null;
  sort_order: number;
  is_app_scoped: boolean;
}

export interface RedFlagCondition {
  type: 'equals' | 'contains' | 'not_equals' | 'not_contains' | 'boolean';
  value: string | boolean;
  description: string;
}

export interface SubQuestionTrigger {
  type: 'any' | 'equals' | 'contains' | 'not_equals';
  value?: string;
}

export interface ReadinessQuestion {
  id: string;
  category_id: string;
  question: string;
  field_type: string;
  options: any;
  placeholder: string | null;
  help_text: string | null;
  discovery_prompts: string[] | null;
  is_required: boolean;
  sort_order: number;
  red_flag_condition: RedFlagCondition | null;
  parent_question_id: string | null;
  trigger_condition: SubQuestionTrigger | null;
  children?: ReadinessQuestion[];
}

export interface ReadinessApp {
  id: string;
  opportunity_id: string;
  app_name: string;
  is_primary: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface ReadinessAnswer {
  id: string;
  opportunity_id: string;
  question_id: string;
  app_id: string | null; // null = global question, set = app-scoped answer
  answer: string | null;
  answer_json: any;
  confidence_score: number | null;
  source: string;
  source_transcript_id: string | null;
  notes: string | null;
  is_red_flag: boolean; // Legacy - now used as "is_flag_disabled" (user toggled off)
  last_confirmed_at: string | null;
  last_confirmed_transcript_id: string | null;
  manual_flag_status: FlagType | null; // Manual override: null uses auto-calculation
}

// Flag types based on confidence score
export type FlagType = 'green' | 'amber' | 'red' | 'none';

// Determine flag type based on confidence score OR manual override
// DEFAULT behavior: RED unless overridden by AI or user
// IMPORTANT: This logic must match the DB trigger (recalculate_opportunity_readiness_score)
export function getFlagType(answer: ReadinessAnswer | undefined): FlagType {
  // No answer record at all = red (default to needing attention)
  if (!answer) return 'red';
  
  // 1. If manual override is set, use it (highest priority - matches trigger)
  if (answer.manual_flag_status && answer.manual_flag_status !== 'none') {
    return answer.manual_flag_status;
  }
  
  // 2. If AI extracted with confidence score, use confidence-based coloring
  if (answer.confidence_score !== null && answer.confidence_score !== undefined) {
    const confidence = answer.confidence_score;
    if (confidence >= 85) return 'green';
    if (confidence >= 60) return 'amber';
    return 'red';
  }
  
  // 3. Check for content - no answer means red
  // Note: If data is encrypted, answer field should be decrypted by gateway
  // If no content, return red
  if (!answer.answer && !answer.answer_json) return 'red';
  
  // 4. Has content but no manual flag or confidence score = red (needs validation)
  // This ensures all fields require attention until validated
  return 'red';
}

// Check if flag has a manual override set
export function hasManualFlagOverride(answer: ReadinessAnswer | undefined): boolean {
  return !!answer?.manual_flag_status && answer.manual_flag_status !== 'none';
}

// Check if flag is disabled by user (using legacy is_red_flag field as "is_flag_disabled")
export function isFlagDisabled(answer: ReadinessAnswer | undefined): boolean {
  return answer?.is_red_flag ?? false;
}

// Legacy function - kept for compatibility but now uses confidence-based approach
export function checkRedFlag(answer: string | null, condition: RedFlagCondition | null): boolean {
  // Deprecated - confidence-based flags are now used instead
  return false;
}

// Check if a sub-question should be visible based on parent answer
export function shouldShowSubQuestion(parentAnswer: string | null, trigger: SubQuestionTrigger): boolean {
  if (trigger.type === 'any') return !!parentAnswer;
  if (!parentAnswer) return false;
  
  // Ensure trigger.value is a string before calling string methods
  const triggerValue = typeof trigger.value === 'string' ? trigger.value : '';
  if (!triggerValue) return false;
  
  const normalizedAnswer = parentAnswer.toLowerCase().trim();
  const normalizedValue = triggerValue.toLowerCase().trim();
  
  switch (trigger.type) {
    case 'equals':
      return normalizedAnswer === normalizedValue;
    case 'contains':
      return normalizedAnswer.includes(normalizedValue);
    case 'not_equals':
      return normalizedAnswer !== normalizedValue;
    default:
      return false;
  }
}

export interface MilestoneTemplate {
  id: string;
  phase: string;
  name: string;
  description: string | null;
  default_participants: string | null;
  sort_order: number;
}

export interface OpportunityMilestone {
  id: string;
  opportunity_id: string;
  template_id: string | null;
  phase: string;
  name: string;
  description: string | null;
  required_participants: string | null;
  scheduled_date: string | null;
  completed_date: string | null;
  status: string;
  notes: string | null;
  sort_order: number;
  assigned_to: string | null;
}

export interface ValidationTaskTemplate {
  id: string;
  module: string;
  sub_module: string | null;
  activity: string;
  default_owner: string | null;
  resources_url: string | null;
  deployment_type_id: string | null;
  sort_order: number;
}

export interface OpportunityValidationTask {
  id: string;
  opportunity_id: string;
  template_id: string | null;
  module: string;
  sub_module: string | null;
  activity: string;
  owner: string | null;
  status: string;
  notes: string | null;
  completed_at: string | null;
  sort_order: number;
  linked_success_criteria_ids: string[] | null;
}

// Fetch deployment types
export function useDeploymentTypes() {
  return useQuery({
    queryKey: ['deployment-types'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('deployment_types')
        .select('*')
        .order('sort_order')
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as DeploymentType[];
    },
  });
}

// Fetch opportunity deployment types
export function useOpportunityDeploymentTypes(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-deployment-types', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunity_deployment_types')
        .select('*, deployment_types(*)')
        .eq('opportunity_id', opportunityId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    enabled: !!opportunityId,
  });
}

// Toggle deployment type for opportunity
export function useToggleOpportunityDeploymentType() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ opportunityId, deploymentTypeId, enabled }: { 
      opportunityId: string; 
      deploymentTypeId: string; 
      enabled: boolean 
    }) => {
      if (enabled) {
        const { error } = await gateway
          .from('opportunity_deployment_types')
          .insert({ opportunity_id: opportunityId, deployment_type_id: deploymentTypeId })
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      } else {
        const { error } = await gateway
          .from('opportunity_deployment_types')
          .delete()
          .eq('opportunity_id', opportunityId)
          .eq('deployment_type_id', deploymentTypeId)
          .execute();
        if (error) throw new Error(getErrorMessage(error));
      }
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-deployment-types', opportunityId] });
    },
  });
}

// Fetch readiness categories with questions
// When deploymentTypeIds is empty, fetch ALL categories (both universal and deployment-specific)
export function useReadinessTemplates(deploymentTypeIds: string[]) {
  return useQuery({
    queryKey: ['readiness-templates', deploymentTypeIds],
    queryFn: async () => {
      let categoriesQuery = gateway
        .from('readiness_template_categories')
        .select('*')
        .order('sort_order');
      
      // If specific deployment types selected, filter to those + universal (null deployment_type_id)
      // If no deployment types selected, fetch all categories
      if (deploymentTypeIds.length > 0) {
        categoriesQuery = categoriesQuery.or(
          `deployment_type_id.is.null,deployment_type_id.in.(${deploymentTypeIds.join(',')})`
        );
      }
      
      const { data: categories, error: catError } = await categoriesQuery.execute();
      if (catError) throw new Error(getErrorMessage(catError));
      if (!categories || categories.length === 0) return [];
      
      const categoryIds = categories.map((c: any) => c.id);
      
      const { data: questions, error: qError } = await gateway
        .from('readiness_template_questions')
        .select('*')
        .in('category_id', categoryIds)
        .order('sort_order')
        .execute();
      if (qError) throw new Error(getErrorMessage(qError));
      
      // Build hierarchical question structure using parent_question_id
      const allQuestions = (questions || []).map((q: any) => ({
        ...q,
        red_flag_condition: q.red_flag_condition as unknown as RedFlagCondition | null,
        discovery_prompts: q.discovery_prompts as string[] | null,
        trigger_condition: q.trigger_condition as SubQuestionTrigger | null,
        children: [] as ReadinessQuestion[],
      }));
      
      // Create a map for quick lookup
      const questionMap = new Map<string, ReadinessQuestion>();
      allQuestions.forEach((q: ReadinessQuestion) => questionMap.set(q.id, q));
      
      // Build parent-child relationships
      const topLevelQuestions: ReadinessQuestion[] = [];
      allQuestions.forEach((q: ReadinessQuestion) => {
        if (q.parent_question_id) {
          const parent = questionMap.get(q.parent_question_id);
          if (parent) {
            parent.children = parent.children || [];
            parent.children.push(q);
          }
        } else {
          topLevelQuestions.push(q);
        }
      });
      
      return categories.map((cat: any) => ({
        ...cat,
        questions: topLevelQuestions.filter((q: ReadinessQuestion) => q.category_id === cat.id),
      })) as (ReadinessCategory & { questions: ReadinessQuestion[] })[];
    },
  });
}

// Fetch opportunity readiness answers
export function useOpportunityReadinessAnswers(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-readiness-answers', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunity_readiness_answers')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as ReadinessAnswer[];
    },
    enabled: !!opportunityId,
  });
}

// Upsert readiness answer
export function useUpsertReadinessAnswer() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      opportunityId, 
      questionId, 
      appId,
      answer, 
      answerJson,
      source = 'manual',
      confidenceScore,
      sourceTranscriptId,
      notes,
      isRedFlag,
      confirmAnswer,
    }: { 
      opportunityId: string; 
      questionId: string; 
      appId?: string | null;
      answer?: string | null;
      answerJson?: any;
      source?: string;
      confidenceScore?: number | null;
      sourceTranscriptId?: string | null;
      notes?: string | null;
      isRedFlag?: boolean;
      confirmAnswer?: boolean;
    }) => {
      const updates: any = {
        opportunity_id: opportunityId,
        question_id: questionId,
        answer: answer ?? null,
        answer_json: answerJson ?? null,
        source,
        confidence_score: confidenceScore ?? null,
        source_transcript_id: sourceTranscriptId ?? null,
        notes: notes ?? null,
        is_red_flag: isRedFlag ?? false,
      };
      if (appId !== undefined) {
        updates.app_id = appId ?? null;
      }
      
      // If confirming the answer, set confirmation timestamp
      if (confirmAnswer) {
        updates.last_confirmed_at = new Date().toISOString();
        if (sourceTranscriptId) {
          updates.last_confirmed_transcript_id = sourceTranscriptId;
        }
      }
      
      const { error } = await encryptedUpsert('opportunity_readiness_answers', updates);
      if (error) throw error;
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
    },
  });
}

// Update only notes for a readiness answer
export function useUpdateReadinessNotes() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ opportunityId, questionId, notes }: { opportunityId: string; questionId: string; notes: string | null }) => {
      const { error } = await supabase
        .from('opportunity_readiness_answers')
        .update({ notes: notes || null })
        .eq('opportunity_id', opportunityId)
        .eq('question_id', questionId);
      if (error) throw error;
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
    },
  });
}

// Confirm an AI-extracted answer
export function useConfirmReadinessAnswer() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      opportunityId, 
      questionId, 
    }: { 
      opportunityId: string; 
      questionId: string; 
    }) => {
      // Get existing answer
      const { data: existing } = await gateway
        .from('opportunity_readiness_answers')
        .select('id, source_transcript_id')
        .eq('opportunity_id', opportunityId)
        .eq('question_id', questionId)
        .maybeSingle()
        .execute();
      
      if (!existing) throw new Error('Answer not found');
      
      const { error } = await gateway
        .from('opportunity_readiness_answers')
        .update({
          last_confirmed_at: new Date().toISOString(),
          last_confirmed_transcript_id: existing.source_transcript_id,
        })
        .eq('id', existing.id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
    },
  });
}

// Unlock (remove confirmation from) a readiness answer
export function useUnlockReadinessAnswer() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      opportunityId, 
      questionId,
    }: { 
      opportunityId: string; 
      questionId: string;
    }) => {
      // Get existing answer
      const { data: existing } = await gateway
        .from('opportunity_readiness_answers')
        .select('id')
        .eq('opportunity_id', opportunityId)
        .eq('question_id', questionId)
        .maybeSingle()
        .execute();
      
      if (!existing) throw new Error('Answer not found');
      
      const { error } = await gateway
        .from('opportunity_readiness_answers')
        .update({
          last_confirmed_at: null,
          last_confirmed_transcript_id: null,
        })
        .eq('id', existing.id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
    },
  });
}

// Toggle red flag on a readiness answer
export function useToggleReadinessRedFlag() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      opportunityId, 
      questionId, 
      isRedFlag 
    }: { 
      opportunityId: string; 
      questionId: string; 
      isRedFlag: boolean;
    }) => {
      // First check if answer exists
      const { data: existing } = await gateway
        .from('opportunity_readiness_answers')
        .select('id')
        .eq('opportunity_id', opportunityId)
        .eq('question_id', questionId)
        .maybeSingle()
        .execute();
      
      if (existing) {
        // Update existing answer
        const { error } = await encryptedUpdate('opportunity_readiness_answers', existing.id, { is_red_flag: isRedFlag });
        if (error) throw error;
      } else {
        // Create new answer with just the flag
        const { error } = await encryptedInsert('opportunity_readiness_answers', {
          opportunity_id: opportunityId,
          question_id: questionId,
          is_red_flag: isRedFlag,
          source: 'manual',
        });
        if (error) throw error;
      }
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
    },
  });
}

// Set manual flag status for a readiness answer
export function useSetManualFlagStatus() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      opportunityId, 
      questionId, 
      flagStatus 
    }: { 
      opportunityId: string; 
      questionId: string; 
      flagStatus: FlagType | null; // null clears the override
    }) => {
      // First check if answer exists
      const { data: existing } = await gateway
        .from('opportunity_readiness_answers')
        .select('id')
        .eq('opportunity_id', opportunityId)
        .eq('question_id', questionId)
        .maybeSingle()
        .execute();
      
      const updateValue = flagStatus === 'none' ? null : flagStatus;
      
      if (existing) {
        // Update existing answer
        const { error } = await encryptedUpdate('opportunity_readiness_answers', existing.id, { 
          manual_flag_status: updateValue 
        });
        if (error) throw error;
      } else {
        // Create new answer with just the flag status
        const { error } = await encryptedInsert('opportunity_readiness_answers', {
          opportunity_id: opportunityId,
          question_id: questionId,
          manual_flag_status: updateValue,
          source: 'manual',
        });
        if (error) throw error;
      }
    },
    // Optimistic update for immediate UI feedback
    onMutate: async ({ opportunityId, questionId, flagStatus }) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
      
      // Snapshot the previous value
      const previousAnswers = queryClient.getQueryData<ReadinessAnswer[]>(['opportunity-readiness-answers', opportunityId]);
      
      // Optimistically update to the new value
      const updateValue = flagStatus === 'none' ? null : flagStatus;
      queryClient.setQueryData<ReadinessAnswer[]>(['opportunity-readiness-answers', opportunityId], (old) => {
        // If no existing cache, create one with just this entry
        if (!old) {
          return [{
            id: `temp-${questionId}`,
            opportunity_id: opportunityId,
            question_id: questionId,
            answer: null,
            answer_json: null,
            confidence_score: null,
            source: 'manual',
            source_transcript_id: null,
            notes: null,
            is_red_flag: false,
            last_confirmed_at: null,
            last_confirmed_transcript_id: null,
            manual_flag_status: updateValue,
          } as ReadinessAnswer];
        }
        
        const existingIndex = old.findIndex(a => a.question_id === questionId);
        if (existingIndex >= 0) {
          // Update existing
          const updated = [...old];
          updated[existingIndex] = { ...updated[existingIndex], manual_flag_status: updateValue };
          return updated;
        } else {
          // Add new optimistic entry
          return [...old, {
            id: `temp-${questionId}`,
            opportunity_id: opportunityId,
            question_id: questionId,
            answer: null,
            answer_json: null,
            confidence_score: null,
            source: 'manual',
            source_transcript_id: null,
            notes: null,
            is_red_flag: false,
            last_confirmed_at: null,
            last_confirmed_transcript_id: null,
            manual_flag_status: updateValue,
          } as ReadinessAnswer];
        }
      });
      
      return { previousAnswers };
    },
    onError: (err, { opportunityId }, context) => {
      // Roll back to the previous value on error
      if (context?.previousAnswers) {
        queryClient.setQueryData(['opportunity-readiness-answers', opportunityId], context.previousAnswers);
      }
    },
    onSettled: (_, __, { opportunityId }) => {
      // Always refetch after error or success to ensure consistency
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
    },
  });
}

// ========== Readiness Apps (per-opportunity application tracking) ==========

// Fetch readiness apps for an opportunity
export function useReadinessApps(opportunityId: string) {
  return useQuery({
    queryKey: ['readiness-apps', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunity_readiness_apps')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('sort_order')
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as ReadinessApp[];
    },
    enabled: !!opportunityId,
  });
}

// Create a new readiness app
export function useCreateReadinessApp() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ opportunityId, appName, isPrimary = false }: { 
      opportunityId: string; 
      appName: string; 
      isPrimary?: boolean;
    }) => {
      // Get current max sort_order
      const { data: existing } = await gateway
        .from('opportunity_readiness_apps')
        .select('sort_order')
        .eq('opportunity_id', opportunityId)
        .order('sort_order', { ascending: false })
        .limit(1)
        .execute();
      
      const nextOrder = existing && existing.length > 0 ? (existing[0] as any).sort_order + 1 : 0;
      
      const { data, error } = await gateway
        .from('opportunity_readiness_apps')
        .insert({
          opportunity_id: opportunityId,
          app_name: appName,
          is_primary: isPrimary,
          sort_order: nextOrder,
        })
        .select()
        .single()
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      
      // If this is the first/primary app, migrate existing null app_id answers to it
      if (isPrimary && data) {
        const appData = data as ReadinessApp;
        await gateway
          .from('opportunity_readiness_answers')
          .update({ app_id: appData.id })
          .eq('opportunity_id', opportunityId)
          .is('app_id', null)
          .execute();
      }
      
      return data as ReadinessApp;
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['readiness-apps', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
    },
  });
}

// Update a readiness app
export function useUpdateReadinessApp() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ appId, appName, opportunityId }: { 
      appId: string; 
      appName: string; 
      opportunityId: string;
    }) => {
      const { error } = await gateway
        .from('opportunity_readiness_apps')
        .update({ app_name: appName })
        .eq('id', appId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['readiness-apps', opportunityId] });
    },
  });
}

// Delete a readiness app (cascades answers)
export function useDeleteReadinessApp() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ appId, opportunityId }: { appId: string; opportunityId: string }) => {
      const { error } = await gateway
        .from('opportunity_readiness_apps')
        .delete()
        .eq('id', appId)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['readiness-apps', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
    },
  });
}

// Fetch readiness apps from other opportunities in the same account
export function useAccountOpportunityApps(accountId: string, excludeOpportunityId: string) {
  return useQuery({
    queryKey: ['account-opportunity-apps', accountId, excludeOpportunityId],
    queryFn: async () => {
      // First get all opportunities for this account (excluding current)
      const { data: opportunities, error: oppError } = await gateway
        .from('opportunities')
        .select('id, name')
        .eq('account_id', accountId)
        .neq('id', excludeOpportunityId)
        .execute();
      if (oppError) throw new Error(getErrorMessage(oppError));
      if (!opportunities || opportunities.length === 0) return [];

      // Then get apps for all those opportunities
      const oppIds = opportunities.map((o: any) => o.id);
      const { data: apps, error: appsError } = await gateway
        .from('opportunity_readiness_apps')
        .select('*')
        .in('opportunity_id', oppIds)
        .order('sort_order')
        .execute();
      if (appsError) throw new Error(getErrorMessage(appsError));

      // Enrich apps with opportunity name
      return (apps || []).map((app: any) => ({
        ...app,
        opportunity_name: opportunities.find((o: any) => o.id === app.opportunity_id)?.name || 'Unknown',
      })) as (ReadinessApp & { opportunity_name: string })[];
    },
    enabled: !!accountId && !!excludeOpportunityId,
  });
}

// Import apps from another opportunity (copies app + answers)
export function useImportAppsFromOpportunity() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      targetOpportunityId, 
      sourceApps 
    }: { 
      targetOpportunityId: string; 
      sourceApps: { appId: string; appName: string; sourceOpportunityId: string }[];
    }) => {
      const importedApps: ReadinessApp[] = [];

      for (const sourceApp of sourceApps) {
        // Get current max sort_order in target opportunity
        const { data: existing } = await gateway
          .from('opportunity_readiness_apps')
          .select('sort_order')
          .eq('opportunity_id', targetOpportunityId)
          .order('sort_order', { ascending: false })
          .limit(1)
          .execute();

        const nextOrder = existing && existing.length > 0 ? (existing[0] as any).sort_order + 1 : 0;

        // Create the app in target opportunity
        const { data: newApp, error: createError } = await gateway
          .from('opportunity_readiness_apps')
          .insert({
            opportunity_id: targetOpportunityId,
            app_name: sourceApp.appName,
            is_primary: nextOrder === 0, // First imported app becomes primary
            sort_order: nextOrder,
          })
          .select()
          .single()
          .execute();
        if (createError) throw new Error(getErrorMessage(createError));
        if (!newApp) continue;

        importedApps.push(newApp as ReadinessApp);

        // Copy answers from source app to new app
        const { data: sourceAnswers, error: fetchError } = await gateway
          .from('opportunity_readiness_answers')
          .select('*')
          .eq('opportunity_id', sourceApp.sourceOpportunityId)
          .eq('app_id', sourceApp.appId)
          .execute();
        if (fetchError) throw new Error(getErrorMessage(fetchError));

        if (sourceAnswers && sourceAnswers.length > 0) {
          const copies = (sourceAnswers as any[]).map(a => ({
            opportunity_id: targetOpportunityId,
            question_id: a.question_id,
            app_id: (newApp as ReadinessApp).id,
            answer: a.answer,
            answer_json: a.answer_json,
            confidence_score: a.confidence_score,
            source: 'imported',
            source_transcript_id: null,
            notes: a.notes,
            is_red_flag: a.is_red_flag,
            manual_flag_status: a.manual_flag_status,
          }));

          const { error: insertError } = await gateway
            .from('opportunity_readiness_answers')
            .upsert(copies, { onConflict: 'opportunity_id,question_id,app_id' })
            .execute();
          if (insertError) throw new Error(getErrorMessage(insertError));
        }
      }

      return importedApps;
    },
    onSuccess: (_, { targetOpportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['readiness-apps', targetOpportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', targetOpportunityId] });
    },
  });
}

// Copy answers from one app to another
export function useCopyAppAnswers() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ opportunityId, sourceAppId, targetAppId }: { 
      opportunityId: string; 
      sourceAppId: string; 
      targetAppId: string;
    }) => {
      // Get source answers
      const { data: sourceAnswers, error: fetchError } = await gateway
        .from('opportunity_readiness_answers')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .eq('app_id', sourceAppId)
        .execute();
      if (fetchError) throw new Error(getErrorMessage(fetchError));
      
      if (!sourceAnswers || sourceAnswers.length === 0) return;
      
      // Insert copies for target app
      const copies = (sourceAnswers as any[]).map(a => ({
        opportunity_id: opportunityId,
        question_id: a.question_id,
        app_id: targetAppId,
        answer: a.answer,
        answer_json: a.answer_json,
        confidence_score: a.confidence_score,
        source: 'copied',
        source_transcript_id: a.source_transcript_id,
        notes: a.notes,
        is_red_flag: a.is_red_flag,
        manual_flag_status: a.manual_flag_status,
      }));
      
      const { error: insertError } = await gateway
        .from('opportunity_readiness_answers')
        .upsert(copies, { onConflict: 'opportunity_id,question_id,app_id' })
        .execute();
      if (insertError) throw new Error(getErrorMessage(insertError));
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
    },
  });
}

// Fetch milestone templates
export function useMilestoneTemplates() {
  return useQuery({
    queryKey: ['milestone-templates'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('milestone_templates')
        .select('*')
        .order('sort_order')
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as MilestoneTemplate[];
    },
  });
}

// Fetch opportunity milestones
export function useOpportunityMilestones(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-milestones', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunity_milestones')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('sort_order')
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as OpportunityMilestone[];
    },
    enabled: !!opportunityId,
  });
}

// Initialize milestones from templates
export function useInitializeMilestones() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ opportunityId, templates }: { 
      opportunityId: string; 
      templates: MilestoneTemplate[] 
    }) => {
      const milestones = templates.map(t => ({
        opportunity_id: opportunityId,
        template_id: t.id,
        phase: t.phase,
        name: t.name,
        description: t.description,
        required_participants: t.default_participants,
        status: 'not_scheduled',
        sort_order: t.sort_order,
      }));
      
      const { error } = await gateway
        .from('opportunity_milestones')
        .insert(milestones)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-milestones', opportunityId] });
    },
  });
}

// Update milestone
export function useUpdateMilestone() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      id, 
      opportunityId,
      scheduledDate, 
      completedDate, 
      status, 
      notes,
      assignedTo
    }: { 
      id: string;
      opportunityId: string;
      scheduledDate?: string | null;
      completedDate?: string | null;
      status?: string;
      notes?: string | null;
      assignedTo?: string | null;
    }) => {
      const updates: any = {};
      if (scheduledDate !== undefined) updates.scheduled_date = scheduledDate;
      if (completedDate !== undefined) updates.completed_date = completedDate;
      if (status !== undefined) updates.status = status;
      if (notes !== undefined) updates.notes = notes;
      if (assignedTo !== undefined) updates.assigned_to = assignedTo;
      
      const { error } = await gateway
        .from('opportunity_milestones')
        .update(updates)
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-milestones', opportunityId] });
    },
  });
}

// Fetch validation task templates
export function useValidationTaskTemplates(deploymentTypeIds: string[]) {
  return useQuery({
    queryKey: ['validation-task-templates', deploymentTypeIds],
    queryFn: async () => {
      // Get tasks for selected deployment types OR universal tasks (null deployment_type_id)
      const { data, error } = await gateway
        .from('validation_task_templates')
        .select('*')
        .or(`deployment_type_id.is.null,deployment_type_id.in.(${deploymentTypeIds.join(',')})`)
        .order('sort_order')
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as ValidationTaskTemplate[];
    },
    enabled: deploymentTypeIds.length > 0,
  });
}

// Fetch opportunity validation tasks
export function useOpportunityValidationTasks(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-validation-tasks', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunity_validation_tasks')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('sort_order')
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as OpportunityValidationTask[];
    },
    enabled: !!opportunityId,
  });
}

// Initialize validation tasks from templates
export function useInitializeValidationTasks() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ opportunityId, templates }: { 
      opportunityId: string; 
      templates: ValidationTaskTemplate[] 
    }) => {
      const tasks = templates.map(t => ({
        opportunity_id: opportunityId,
        template_id: t.id,
        module: t.module,
        sub_module: t.sub_module,
        activity: t.activity,
        owner: t.default_owner,
        status: 'not_started',
        sort_order: t.sort_order,
      }));
      
      const { error } = await gateway
        .from('opportunity_validation_tasks')
        .insert(tasks)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-validation-tasks', opportunityId] });
    },
  });
}

// Update validation task
export function useUpdateValidationTask() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      id, 
      opportunityId,
      status, 
      notes,
      owner,
      activity,
      module,
      sub_module,
      linked_success_criteria_ids,
    }: { 
      id: string;
      opportunityId: string;
      status?: string;
      notes?: string | null;
      owner?: string | null;
      activity?: string;
      module?: string;
      sub_module?: string | null;
      linked_success_criteria_ids?: string[] | null;
    }) => {
      const updates: any = { updated_at: new Date().toISOString() };
      if (status !== undefined) {
        updates.status = status;
        if (status === 'completed') {
          updates.completed_at = new Date().toISOString();
        } else {
          updates.completed_at = null;
        }
      }
      if (notes !== undefined) updates.notes = notes;
      if (owner !== undefined) updates.owner = owner;
      if (activity !== undefined) updates.activity = activity;
      if (module !== undefined) updates.module = module;
      if (sub_module !== undefined) updates.sub_module = sub_module;
      if (linked_success_criteria_ids !== undefined) updates.linked_success_criteria_ids = linked_success_criteria_ids;
      
      const { error } = await gateway
        .from('opportunity_validation_tasks')
        .update(updates)
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      
      return { id, opportunityId, status, notes, owner, activity, module, sub_module, linked_success_criteria_ids };
    },
    onMutate: async ({ id, opportunityId, status, notes, owner, activity, module, sub_module, linked_success_criteria_ids }) => {
      await queryClient.cancelQueries({ queryKey: ['opportunity-validation-tasks', opportunityId] });
      const previousTasks = queryClient.getQueryData(['opportunity-validation-tasks', opportunityId]);
      
      queryClient.setQueryData(['opportunity-validation-tasks', opportunityId], (old: any[] | undefined) => {
        if (!old) return old;
        return old.map(task => {
          if (task.id !== id) return task;
          const updated = { ...task };
          if (status !== undefined) {
            updated.status = status;
            updated.completed_at = status === 'completed' ? new Date().toISOString() : null;
          }
          if (notes !== undefined) updated.notes = notes;
          if (owner !== undefined) updated.owner = owner;
          if (activity !== undefined) updated.activity = activity;
          if (module !== undefined) updated.module = module;
          if (sub_module !== undefined) updated.sub_module = sub_module;
          if (linked_success_criteria_ids !== undefined) updated.linked_success_criteria_ids = linked_success_criteria_ids;
          return updated;
        });
      });
      
      return { previousTasks };
    },
    onError: (err, { opportunityId }, context) => {
      if (context?.previousTasks) {
        queryClient.setQueryData(['opportunity-validation-tasks', opportunityId], context.previousTasks);
      }
    },
    onSettled: (_, __, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-validation-tasks', opportunityId] });
    },
  });
}

// Delete validation task
export function useDeleteValidationTask() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, opportunityId }: { id: string; opportunityId: string }) => {
      const { error } = await gateway
        .from('opportunity_validation_tasks')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return { id, opportunityId };
    },
    onMutate: async ({ id, opportunityId }) => {
      await queryClient.cancelQueries({ queryKey: ['opportunity-validation-tasks', opportunityId] });
      const previousTasks = queryClient.getQueryData(['opportunity-validation-tasks', opportunityId]);
      queryClient.setQueryData(['opportunity-validation-tasks', opportunityId], (old: any[] | undefined) => {
        if (!old) return old;
        return old.filter(task => task.id !== id);
      });
      return { previousTasks };
    },
    onError: (err, { opportunityId }, context) => {
      if (context?.previousTasks) {
        queryClient.setQueryData(['opportunity-validation-tasks', opportunityId], context.previousTasks);
      }
    },
    onSettled: (_, __, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-validation-tasks', opportunityId] });
    },
  });
}

// Fetch pending readiness changes for review
export interface PendingReadinessChange {
  id: string;
  opportunity_id: string;
  question_id: string;
  old_answer: { answer: string | null; confidence: number | null };
  new_answer: { answer: string; confidence: number; context?: string };
  old_score: number | null;
  new_score: number;
  changed_at: string;
  change_source: string;
  source_transcript_id: string | null;
}

export function usePendingReadinessChanges(opportunityId: string) {
  return useQuery({
    queryKey: ['pending-readiness-changes', opportunityId],
    queryFn: async () => {
      // Get questions that have confirmed answers
      const { data: confirmedAnswers } = await gateway
        .from('opportunity_readiness_answers')
        .select('question_id')
        .eq('opportunity_id', opportunityId)
        .not('last_confirmed_at', 'is', null)
        .execute();
      
      if (!confirmedAnswers?.length) return [];
      
      const confirmedQuestionIds = confirmedAnswers.map((a: any) => a.question_id);
      
      // Get history entries for those confirmed questions (these are pending reviews)
      const { data, error } = await gateway
        .from('technical_readiness_history')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .in('question_id', confirmedQuestionIds)
        .order('changed_at', { ascending: false })
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data as PendingReadinessChange[];
    },
    enabled: !!opportunityId,
  });
}

// Accept a pending readiness change
export function useAcceptReadinessChange() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      historyId, 
      opportunityId, 
      questionId 
    }: { 
      historyId: string; 
      opportunityId: string; 
      questionId: string;
    }) => {
      // Get the pending change
      const { data: change, error: fetchError } = await gateway
        .from('technical_readiness_history')
        .select('new_answer, new_score, source_transcript_id')
        .eq('id', historyId)
        .single()
        .execute();
      
      if (fetchError) throw new Error(getErrorMessage(fetchError));
      
      const newAnswer = (change as any).new_answer as { answer: string; confidence: number };
      
      // First get the answer record id
      const { data: existingAnswer } = await gateway
        .from('opportunity_readiness_answers')
        .select('id')
        .eq('opportunity_id', opportunityId)
        .eq('question_id', questionId)
        .single()
        .execute();
      
      if (!existingAnswer) throw new Error('Answer not found');
      
      // Update the answer and confirm it
      await encryptedUpdate('opportunity_readiness_answers', (existingAnswer as any).id, {
        answer: newAnswer.answer,
        confidence_score: newAnswer.confidence,
        source_transcript_id: (change as any).source_transcript_id,
        last_confirmed_at: new Date().toISOString(),
        last_confirmed_transcript_id: (change as any).source_transcript_id,
      });
      
      // Delete the history entry
      await gateway
        .from('technical_readiness_history')
        .delete()
        .eq('id', historyId)
        .execute();
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['pending-readiness-changes', opportunityId] });
    },
  });
}

// Reject a pending readiness change
export function useRejectReadinessChange() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ historyId }: { historyId: string }) => {
      // Just delete the history entry - keep the existing confirmed answer
      const { error } = await gateway
        .from('technical_readiness_history')
        .delete()
        .eq('id', historyId)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-readiness-changes'] });
    },
  });
}

// Calculate readiness score for an opportunity (weighted by flag type)
// Now counts ALL questions with default red for unanswered, excludes disabled
export interface ReadinessScoreResult {
  answered: number;
  total: number;
  activeTotal: number; // Total minus disabled
  percentage: number; // Weighted readiness score (0-100, higher = better)
  gaps: number;
  greenCount: number;
  amberCount: number;
  redCount: number;
  disabledCount: number;
}

export function calculateReadinessScore(
  answers: ReadinessAnswer[],
  totalQuestions: number,
  questionIds?: string[] // Optional: pass all question IDs to count unanswered as red
): ReadinessScoreResult {
  // Build answer map for quick lookup
  const answerMap = new Map<string, ReadinessAnswer>();
  answers.forEach(a => answerMap.set(a.question_id, a));
  
  let answered = 0;
  let greenCount = 0;
  let amberCount = 0;
  let redCount = 0;
  let disabledCount = 0;
  
  // If we have question IDs, iterate through all of them
  if (questionIds && questionIds.length > 0) {
    questionIds.forEach(qId => {
      const answer = answerMap.get(qId);
      
      // Check if disabled (marked as not relevant)
      if (isFlagDisabled(answer)) {
        disabledCount++;
        return;
      }
      
      // Count as answered if has content
      const hasAnswer = answer?.answer || answer?.answer_json;
      if (hasAnswer) answered++;
      
      // Get flag type (defaults to red for unanswered)
      const flagType = getFlagType(answer);
      if (flagType === 'green') greenCount++;
      else if (flagType === 'amber') amberCount++;
      else redCount++; // Default to red
    });
  } else {
    // Legacy fallback: only count answered questions
    const answeredList = answers.filter(a => a.answer || a.answer_json);
    answeredList.forEach(a => {
      if (isFlagDisabled(a)) {
        disabledCount++;
        return;
      }
      answered++;
      const flagType = getFlagType(a);
      if (flagType === 'green') greenCount++;
      else if (flagType === 'amber') amberCount++;
      else if (flagType === 'red') redCount++;
    });
    
    // Count unanswered as red
    const unansweredCount = totalQuestions - answered - disabledCount;
    redCount += unansweredCount;
  }
  
  const activeTotal = totalQuestions - disabledCount;
  const gaps = activeTotal - answered;
  
  // Calculate weighted score based on ALL active questions
  // Red flags are 2x importance, amber 1.5x, green 1x (baseline)
  // This weights the denominator to penalize more heavily for unresolved critical items
  // Formula: (green * 100 + amber * 50) / (red * 2 + amber * 1.5 + green * 1)
  const weightedDenominator = (redCount * 2) + (amberCount * 1.5) + (greenCount * 1);
  let percentage = 0;
  if (weightedDenominator > 0) {
    // Numerator: green gets full credit (100 pts), amber gets half credit (50 pts), red gets 0
    // Divide by weighted denominator to scale appropriately
    percentage = Math.round((greenCount * 100 + amberCount * 50) / weightedDenominator);
  }
  
  return { 
    answered, 
    total: totalQuestions, 
    activeTotal,
    percentage: Math.max(0, Math.min(100, percentage)), 
    gaps, 
    greenCount, 
    amberCount, 
    redCount, 
    disabledCount 
  };
}

// Extract readiness answers from transcript using AI
export interface DetectedDeploymentType {
  type: 'snippet' | 'extension' | 'mobile' | 'adopt';
  confidence: number;
  reasoning: string;
}

export function useExtractReadinessFromTranscript() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      transcript, 
      opportunityId, 
      questions 
    }: { 
      transcript: string; 
      opportunityId: string; 
      questions: { id: string; question: string; category_name: string }[];
    }) => {
      if (!transcript || !transcript.trim()) {
        throw new Error('Transcript content is empty');
      }

      const { data, error } = await supabase.functions.invoke('extract-readiness-answers', {
        body: { transcript, opportunityId, questions },
      });
      
      if (error) throw error;
      return data as {
        success: boolean;
        detected_deployment_types: DetectedDeploymentType[];
        extracted_count: number;
        extracted_answers: { question_id: string; answer: string; confidence: number; context: string }[];
        unanswered_count: number;
        unanswered_question_ids: string[];
      };
    },
    onSuccess: (_, { opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-readiness-answers', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-deployment-types', opportunityId] });
    },
  });
}

// Create a summary NBA for red/amber flag items that need SE review
export interface ReadinessFlagItem {
  questionId: string;
  questionText: string;
  answer: string;
  flagType: 'red' | 'amber';
  confidenceScore: number | null;
  categoryName: string;
}

export function useCreateReadinessReviewNBA() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ 
      accountId,
      opportunityId,
      flagItems,
      seEmail,
    }: { 
      accountId: string;
      opportunityId: string;
      flagItems: ReadinessFlagItem[];
      seEmail?: string | null;
    }) => {
      if (flagItems.length === 0) {
        throw new Error('No flag items to review');
      }
      
      const redCount = flagItems.filter(i => i.flagType === 'red').length;
      const amberCount = flagItems.filter(i => i.flagType === 'amber').length;
      
      // Build action text
      const action = `Review Technical Readiness: ${redCount} red flag${redCount !== 1 ? 's' : ''}, ${amberCount} amber flag${amberCount !== 1 ? 's' : ''} require validation`;
      
      // Build detailed notes with list of items
      const notes = flagItems.map(item => {
        const icon = item.flagType === 'red' ? '🔴' : '🟡';
        const confidence = item.confidenceScore ? `(${Math.round(item.confidenceScore)}% confidence)` : '';
        return `${icon} [${item.categoryName}] ${item.questionText}\n   Answer: "${item.answer}" ${confidence}`;
      }).join('\n\n');
      
      // Determine priority based on flag counts
      const priority = redCount >= 3 ? 'high' : redCount >= 1 ? 'medium' : 'low';
      
      // Create the NBA using encrypted insert
      const { error } = await encryptedInsert('account_nbas', {
        account_id: accountId,
        opportunity_id: opportunityId,
        action,
        action_type: 'technical',
        priority,
        status: 'pending',
        assigned_to: seEmail || 'sales_engineer',
        notes,
        delivery_method: 'in_app',
      });
      
      if (error) throw error;
      
      return { success: true, redCount, amberCount };
    },
    onSuccess: (_, { accountId, opportunityId }) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-nbas', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['account-nbas', accountId] });
    },
  });
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface SEUpdate {
  id: string;
  opportunity_id: string;
  updated_by: string;
  weekly_update: string | null;
  potential_risks: string | null;
  created_at: string;
  updated_at: string;
}

export function useOpportunitySEUpdate(opportunityId: string | undefined) {
  return useQuery({
    queryKey: ['opportunity-se-update', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('opportunity_se_updates')
        .select('*')
        .eq('opportunity_id', opportunityId!)
        .limit(1)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data as SEUpdate[])?.[0] || null;
    },
    enabled: !!opportunityId,
  });
}

export function useOpportunitySEUpdates(opportunityIds: string[]) {
  return useQuery({
    queryKey: ['opportunity-se-updates', opportunityIds],
    queryFn: async () => {
      if (opportunityIds.length === 0) return [];
      const { data, error } = await gateway
        .from('opportunity_se_updates')
        .select('*')
        .in('opportunity_id', opportunityIds)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return (data as SEUpdate[]) || [];
    },
    enabled: opportunityIds.length > 0,
  });
}

export function useUpsertSEUpdate() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: {
      opportunity_id: string;
      updated_by: string;
      weekly_update?: string | null;
      potential_risks?: string | null;
    }) => {
      // Upsert using the unique index on opportunity_id
      const { data, error } = await gateway
        .from('opportunity_se_updates')
        .upsert(
          {
            opportunity_id: params.opportunity_id,
            updated_by: params.updated_by,
            weekly_update: params.weekly_update,
            potential_risks: params.potential_risks,
          },
          { onConflict: 'opportunity_id' }
        )
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-se-update', variables.opportunity_id] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-se-updates'] });
      toast.success('Update saved');
    },
    onError: (error) => {
      toast.error(`Failed to save update: ${error.message}`);
    },
  });
}

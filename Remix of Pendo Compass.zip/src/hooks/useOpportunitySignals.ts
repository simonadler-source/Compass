import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

// Activity Signal rule tree ID
const ACTIVITY_SIGNAL_TREE_ID = 'f5e4d3c2-b1a0-9876-5432-fedcba098765';

export interface OpportunitySignal {
  id: string;
  ruleId: string;
  ruleName: string;
  ruleKey: string;
  speakerContext: 'any' | 'internal_only' | 'external_only';
  confidenceScore: number;
  matchedPhrases: string[];
  detectedAt: string;
  transcriptId: string | null;
  speakerType: 'internal' | 'external' | 'unknown' | null;
  speakerName: string | null;
  speakerEmail: string | null;
}

export interface SignalType {
  id: string;
  name: string;
  key: string;
  color: string;
}

// Color palette for dynamic signal types
const SIGNAL_COLORS = [
  '#8B5CF6', // Purple
  '#F97316', // Orange
  '#0EA5E9', // Sky blue
  '#10B981', // Emerald
  '#EF4444', // Red
  '#F59E0B', // Amber
  '#EC4899', // Pink
  '#6366F1', // Indigo
  '#14B8A6', // Teal
  '#84CC16', // Lime
];

function extractSignalKey(name: string, signalFieldName: string | null): string {
  if (signalFieldName) return signalFieldName;
  const normalized = name.toLowerCase().replace(' signals', '').replace(' signal', '');
  return normalized.replace(/\s+/g, '_');
}

export function useOpportunitySignals(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-signals', opportunityId],
    queryFn: async () => {
      // First fetch active rules from the Activity Signals tree
      const rulesResponse = await gateway
        .from('detection_rules')
        .select('id, name, signal_field_name')
        .eq('tree_id', ACTIVITY_SIGNAL_TREE_ID)
        .eq('is_active', true)
        .order('sort_order')
        .execute();

      if (rulesResponse.error) throw new Error(getErrorMessage(rulesResponse.error));
      const rules = rulesResponse.data || [];
      
      // Build a Set of rule IDs for fast lookup
      const activityRuleIds = new Set(rules.map((r: any) => r.id));

      // Build signal types with colors
      const signalTypes: SignalType[] = rules.map((rule: any, index: number) => ({
        id: rule.id,
        name: rule.name.replace(' Signals', '').replace(' Signal', ''),
        key: extractSignalKey(rule.name, rule.signal_field_name),
        color: SIGNAL_COLORS[index % SIGNAL_COLORS.length],
      }));

      // Fetch ALL matches for this opportunity - simpler query without nested join
      const matchesResponse = await gateway
        .from('detection_rule_matches')
        .select(`
          id,
          rule_id,
          confidence_score,
          matched_phrases,
          first_detected_at,
          created_at,
          transcript_id,
          speaker_type,
          speaker_name,
          speaker_email
        `)
        .eq('opportunity_id', opportunityId)
        .order('first_detected_at', { ascending: false })
        .execute();

      if (matchesResponse.error) throw new Error(getErrorMessage(matchesResponse.error));

      // Filter to only Activity Signals tree rules using the pre-fetched rule IDs
      const activityMatches = (matchesResponse.data || []).filter((m: any) =>
        activityRuleIds.has(m.rule_id)
      );

      // Transform to our interface - get rule details from the rules array
      const signals: OpportunitySignal[] = activityMatches.map((m: any) => {
        const rule = rules.find((r: any) => r.id === m.rule_id);
        return {
          id: m.id,
          ruleId: m.rule_id,
          ruleName: (rule?.name || 'Unknown').replace(' Signals', '').replace(' Signal', ''),
          ruleKey: extractSignalKey(rule?.name || '', rule?.signal_field_name),
          speakerContext: 'any',
          confidenceScore: m.confidence_score || 0,
          matchedPhrases: m.matched_phrases || [],
          detectedAt: m.first_detected_at || m.created_at,
          transcriptId: m.transcript_id,
          speakerType: m.speaker_type,
          speakerName: m.speaker_name,
          speakerEmail: m.speaker_email,
        };
      });

      // Deduplicate by rule (keep first detection per rule)
      const uniqueByRule = new Map<string, OpportunitySignal>();
      signals.forEach((s) => {
        if (!uniqueByRule.has(s.ruleId)) {
          uniqueByRule.set(s.ruleId, s);
        }
      });

      return {
        signals: Array.from(uniqueByRule.values()),
        allSignals: signals,
        signalTypes,
      };
    },
    enabled: !!opportunityId,
  });
}

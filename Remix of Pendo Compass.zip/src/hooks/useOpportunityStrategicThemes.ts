import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';

export interface OpportunityStrategicTheme {
  id: string;
  account_id: string;
  theme_name: string;
  theme_type: 'pain_theme' | 'initiative';
  description: string;
  supporting_evidence: string[];
  impact_level: 'critical' | 'high' | 'medium' | 'low' | null;
  item_count: number;
  linked_opportunity_ids: string[] | null;
  created_at: string;
  updated_at: string;
}

export function useOpportunityStrategicThemes(opportunityId: string | null) {
  return useQuery({
    queryKey: ['opportunity-strategic-themes', opportunityId],
    queryFn: async () => {
      if (!opportunityId) return { painThemes: [], initiatives: [] };
      
      // Fetch themes that are linked to this opportunity
      const result = await gateway.from('account_strategic_themes')
        .select('*')
        .contains('linked_opportunity_ids', [opportunityId])
        .order('impact_level', { ascending: true })
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      const themes = (result.data || []) as OpportunityStrategicTheme[];
      return {
        painThemes: themes.filter(t => t.theme_type === 'pain_theme'),
        initiatives: themes.filter(t => t.theme_type === 'initiative'),
      };
    },
    enabled: !!opportunityId,
  });
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface OpportunityUseCase {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  functional_area: string;
  use_case: string;
  description: string | null;
  status: string;
  priority: string | null;
  source: string;
  source_transcript_id: string | null;
  sort_order: number;
  radar_x: number | null;
  radar_y: number | null;
  created_at: string;
  updated_at: string;
}

// Fetch use cases for a specific opportunity
export function useOpportunityUseCases(opportunityId: string) {
  return useQuery({
    queryKey: ['opportunity-use-cases', opportunityId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_use_cases')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('sort_order')
        .order('created_at')
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data as OpportunityUseCase[];
    },
    enabled: !!opportunityId,
  });
}

// Fetch aggregated use cases across all opportunities for an account
export function useAggregatedAccountUseCases(accountId: string) {
  return useQuery({
    queryKey: ['aggregated-account-use-cases', accountId],
    queryFn: async () => {
      // Get all use cases for this account with opportunity info
      const { data: useCases, error: useCasesError } = await gateway
        .from('account_use_cases')
        .select('*')
        .eq('account_id', accountId)
        .order('sort_order')
        .order('created_at')
        .execute();

      if (useCasesError) throw new Error(getErrorMessage(useCasesError));

      // Get opportunities for labeling
      const { data: opportunities, error: oppsError } = await gateway
        .from('opportunities')
        .select('id, name')
        .eq('account_id', accountId)
        .execute();

      if (oppsError) throw new Error(getErrorMessage(oppsError));

      const oppMap = new Map(opportunities?.map((o: any) => [o.id, o.name]) || []);

      return (useCases || []).map((uc: any) => ({
        ...uc,
        opportunity_name: uc.opportunity_id ? oppMap.get(uc.opportunity_id) || 'Unknown' : 'Account Level',
      }));
    },
    enabled: !!accountId,
  });
}

export function useCreateOpportunityUseCase() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (useCase: {
      account_id: string;
      opportunity_id: string;
      functional_area: string;
      use_case: string;
      description?: string | null;
      status?: string;
      priority?: string | null;
      source?: string;
      source_transcript_id?: string | null;
      sort_order?: number;
      radar_x?: number | null;
      radar_y?: number | null;
    }) => {
      const { data, error } = await gateway
        .from('account_use_cases')
        .insert({
          ...useCase,
          status: useCase.status || 'identified',
          source: useCase.source || 'manual',
          sort_order: useCase.sort_order || 0,
        })
        .select('*')
        .single()
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-use-cases', data.opportunity_id] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-use-cases', data.account_id] });
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', data.account_id] });
      toast.success('Use case added');
    },
    onError: (error) => {
      toast.error('Failed to add use case: ' + error.message);
    },
  });
}

export function useUpdateOpportunityUseCase() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      id, 
      accountId, 
      opportunityId, 
      ...updates 
    }: Partial<OpportunityUseCase> & { 
      id: string; 
      accountId: string; 
      opportunityId: string;
    }) => {
      const { data, error } = await gateway
        .from('account_use_cases')
        .update(updates)
        .eq('id', id)
        .select('*')
        .single()
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return { ...data, accountId, opportunityId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-use-cases', data.opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-use-cases', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', data.accountId] });
    },
    onError: (error) => {
      toast.error('Failed to update use case: ' + error.message);
    },
  });
}

export function useDeleteOpportunityUseCase() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, accountId, opportunityId }: { id: string; accountId: string; opportunityId: string }) => {
      const { error } = await gateway
        .from('account_use_cases')
        .delete()
        .eq('id', id)
        .execute();
      if (error) throw new Error(getErrorMessage(error));
      return { accountId, opportunityId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-use-cases', data.opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-use-cases', data.accountId] });
      queryClient.invalidateQueries({ queryKey: ['account-use-cases', data.accountId] });
      toast.success('Use case removed');
    },
    onError: (error) => {
      toast.error('Failed to delete use case: ' + error.message);
    },
  });
}

import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { ThemedUseCase } from './useThemedUseCases';

export function useOpportunityUseCasesThemed(opportunityId: string | null) {
  return useQuery({
    queryKey: ['opportunity-themed-use-cases', opportunityId],
    queryFn: async () => {
      if (!opportunityId) return [];
      
      const result = await gateway.from('account_use_cases')
        .select('*')
        .eq('opportunity_id', opportunityId)
        .order('priority', { ascending: true })
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      // Sort by confidence_score as secondary sort
      const data = (result.data as ThemedUseCase[]) || [];
      return data.sort((a, b) => {
        const priorityOrder: Record<string, number> = { high: 0, medium: 1, low: 2 };
        const aPriority = priorityOrder[a.priority || 'low'] ?? 2;
        const bPriority = priorityOrder[b.priority || 'low'] ?? 2;
        if (aPriority !== bPriority) return aPriority - bPriority;
        return (b.confidence_score || 0) - (a.confidence_score || 0);
      });
    },
    enabled: !!opportunityId,
  });
}

import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway } from '@/lib/apiGateway';
import { useAuth } from '@/contexts/AuthContext';

export interface OrgNode {
  id: string;
  email: string;
  full_name: string | null;
  children: OrgNode[];
  dottedChildren: OrgNode[];
  depth: number;
}

interface HierarchyRow {
  manager_id: string;
  report_id: string;
  relationship_type: string;
}

interface ProfileRow {
  id: string;
  email: string;
  full_name: string | null;
}

/**
 * Builds a hierarchical org tree from team_hierarchy data.
 * Returns all root managers (those who are not reports of anyone)
 * and recursive children underneath.
 */
export function useOrgTree() {
  const { effectiveUserId } = useAuth();

  // Fetch all hierarchy entries
  const { data: hierarchy, isLoading: hierLoading } = useQuery({
    queryKey: ['org-tree-hierarchy'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('team_hierarchy')
        .select('manager_id, report_id, relationship_type')
        .execute();
      if (error) throw new Error(error.message);
      return (data || []) as HierarchyRow[];
    },
    staleTime: 5 * 60 * 1000,
  });

  // Collect all unique user IDs
  const allUserIds = hierarchy
    ? [...new Set([...hierarchy.map(h => h.manager_id), ...hierarchy.map(h => h.report_id)])]
    : [];

  // Fetch profiles for all those users
  const { data: profiles, isLoading: profilesLoading } = useQuery({
    queryKey: ['org-tree-profiles', allUserIds],
    queryFn: async () => {
      if (!allUserIds.length) return [];
      const { data, error } = await gateway
        .from('profiles')
        .select('id, email, full_name')
        .in('id', allUserIds)
        .execute();
      if (error) throw new Error(error.message);
      return (data || []) as ProfileRow[];
    },
    enabled: allUserIds.length > 0,
    staleTime: 5 * 60 * 1000,
  });

  // Determine if current user is a manager (has direct reports in hierarchy)
  const isManager = hierarchy
    ? hierarchy.some(h => h.manager_id === effectiveUserId)
    : false;

  // Build tree
  const { roots, nodeMap } = buildTree(hierarchy || [], profiles || []);

  // Find current user's node to determine their default team
  const currentUserManagerNode = findManagerOf(effectiveUserId || '', hierarchy || []);

  return {
    roots,
    nodeMap,
    isManager,
    currentUserId: effectiveUserId,
    isLoading: hierLoading || profilesLoading,
  };
}

function buildTree(hierarchy: HierarchyRow[], profiles: ProfileRow[]): {
  roots: OrgNode[];
  nodeMap: Map<string, OrgNode>;
} {
  const profileMap = new Map(profiles.map(p => [p.id, p]));
  const nodeMap = new Map<string, OrgNode>();

  const getOrCreate = (id: string): OrgNode => {
    if (nodeMap.has(id)) return nodeMap.get(id)!;
    const profile = profileMap.get(id);
    const node: OrgNode = {
      id,
      email: profile?.email || '',
      full_name: profile?.full_name || profile?.email || id,
      children: [],
      dottedChildren: [],
      depth: 0,
    };
    nodeMap.set(id, node);
    return node;
  };

  // Set of all report IDs that have a solid-line manager (not roots)
  const solidReportIds = new Set(hierarchy.filter(h => h.relationship_type !== 'dotted').map(h => h.report_id));

  // Build parent-child relationships
  for (const h of hierarchy) {
    const parent = getOrCreate(h.manager_id);
    const child = getOrCreate(h.report_id);
    if (h.relationship_type === 'dotted') {
      if (!parent.dottedChildren.find(c => c.id === child.id)) {
        parent.dottedChildren.push(child);
      }
    } else {
      if (!parent.children.find(c => c.id === child.id)) {
        parent.children.push(child);
      }
    }
  }

  // Roots are managers who are not reports of anyone
  const managerIds = new Set(hierarchy.map(h => h.manager_id));
  const rootIds = [...managerIds].filter(id => !solidReportIds.has(id));

  // If no roots found but we have data, use all managers
  const roots = rootIds.length > 0
    ? rootIds.map(id => getOrCreate(id))
    : [];

  // Set depths
  function setDepth(node: OrgNode, depth: number) {
    node.depth = depth;
    node.children.forEach(c => setDepth(c, depth + 1));
    node.dottedChildren.forEach(c => setDepth(c, depth + 1));
  }
  roots.forEach(r => setDepth(r, 0));

  // Sort children alphabetically
  function sortChildren(node: OrgNode) {
    node.children.sort((a, b) => (a.full_name || '').localeCompare(b.full_name || ''));
    node.dottedChildren.sort((a, b) => (a.full_name || '').localeCompare(b.full_name || ''));
    node.children.forEach(sortChildren);
    node.dottedChildren.forEach(sortChildren);
  }
  roots.forEach(sortChildren);

  return { roots, nodeMap };
}

function findManagerOf(userId: string, hierarchy: HierarchyRow[]): string | null {
  const entry = hierarchy.find(h => h.report_id === userId && h.relationship_type !== 'dotted');
  return entry?.manager_id || null;
}

/**
 * Collects all emails in a subtree rooted at a given node (including the node itself and dotted-line reports).
 */
export function collectSubtreeEmails(node: OrgNode): string[] {
  const emails: string[] = [node.email.toLowerCase()];
  for (const child of node.children) {
    emails.push(...collectSubtreeEmails(child));
  }
  for (const child of node.dottedChildren) {
    emails.push(...collectSubtreeEmails(child));
  }
  return [...new Set(emails.filter(Boolean))];
}

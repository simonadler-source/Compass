import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { useCustomRoles } from './useCustomRoles';

// Keep AppRole for backwards compatibility but it will work with any role name
export type AppRole = string;

export interface PageAccess {
  id: string;
  page_path: string;
  page_name: string;
  role: AppRole;
  created_at: string;
  updated_at: string;
}

export const ALL_PAGES = [
  // Main pages
  { path: '/accounts', name: 'Accounts', isParent: true },
  { path: '/nba', name: 'Next Best Actions' },
  { path: '/manager', name: 'Team Dashboard', isParent: true },
  { path: '/activity-signals', name: 'Activity Signals' },
  { path: '/product-analytics', name: 'Product Analytics' },
  { path: '/momentum', name: 'Momentum Meetings' },
  { path: '/transcripts', name: 'AI Discovery' },
  { path: '/customer-stories', name: 'Customer Stories' },
  
  // Account Detail tabs
  { path: '/accounts/details', name: 'Accounts → Details', parent: '/accounts' },
  { path: '/accounts/insights', name: 'Accounts → Insights', parent: '/accounts' },
  { path: '/accounts/use-cases', name: 'Accounts → Use Cases', parent: '/accounts' },
  { path: '/accounts/architecture', name: 'Accounts → Architecture', parent: '/accounts' },
  { path: '/accounts/radar', name: 'Accounts → Priority Radar', parent: '/accounts' },
  { path: '/accounts/nbas', name: 'Accounts → Actions', parent: '/accounts' },
  { path: '/accounts/opportunities', name: 'Accounts → Opportunities', parent: '/accounts' },
  { path: '/accounts/story', name: 'Accounts → Story', parent: '/accounts' },
  { path: '/accounts/transcripts', name: 'Accounts → Transcripts', parent: '/accounts' },
  { path: '/accounts/stakeholders', name: 'Accounts → Stakeholder Map', parent: '/accounts' },
  { path: '/accounts/team', name: 'Accounts → Team', parent: '/accounts' },
  { path: '/accounts/documents', name: 'Accounts → Documents', parent: '/accounts' },
  
  // Opportunity tabs (nested under account opportunities)
  { path: '/accounts/opportunities/overview', name: 'Opportunity → Overview', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/readiness', name: 'Opportunity → Readiness', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/validation', name: 'Opportunity → Validation', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/milestones', name: 'Opportunity → Milestones', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/use-cases', name: 'Opportunity → Use Cases', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/nbas', name: 'Opportunity → Actions', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/insights', name: 'Opportunity → Insights', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/transcripts', name: 'Opportunity → Transcripts', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/stakeholders', name: 'Opportunity → Stakeholders', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/team', name: 'Opportunity → Team', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/radar', name: 'Opportunity → Priority Radar', parent: '/accounts/opportunities' },
  { path: '/accounts/opportunities/activity', name: 'Opportunity → Activity', parent: '/accounts/opportunities' },
  
  // Team Dashboard tabs
  { path: '/manager/accounts', name: 'Team Dashboard → By Account', parent: '/manager' },
  { path: '/manager/opportunities', name: 'Team Dashboard → By Opportunity', parent: '/manager' },
  { path: '/manager/team', name: 'Team Dashboard → By Team Member', parent: '/manager' },
  { path: '/manager/alerts', name: 'Team Dashboard → All Alerts', parent: '/manager' },
  { path: '/manager/manage', name: 'Team Dashboard → Manage Team', parent: '/manager' },
  { path: '/manager/coaching', name: 'Team Dashboard → Coaching', parent: '/manager' },
  
  // Configuration section (collapsible menu in sidebar)
  { path: '/configuration', name: 'Configuration', isParent: true },
  { path: '/functional-areas', name: 'Configuration → Functional Areas', parent: '/configuration' },
  { path: '/reference-architecture', name: 'Configuration → Reference Architecture', parent: '/configuration' },
  { path: '/technology-library', name: 'Configuration → Technology Library', parent: '/configuration' },
  { path: '/integrations', name: 'Configuration → Integrations', parent: '/configuration' },
  { path: '/detection-rules', name: 'Configuration → Detection Rules', parent: '/configuration' },
  { path: '/readiness-questions', name: 'Configuration → Readiness Questions', parent: '/configuration' },
  { path: '/validation-tasks', name: 'Configuration → Validation Tasks', parent: '/configuration' },
  { path: '/alert-rules', name: 'Configuration → Alert Rules', parent: '/configuration', isParent: true },
  { path: '/alert-rules/system', name: 'Alert Rules → System Rules', parent: '/alert-rules' },
  { path: '/alert-rules/personal', name: 'Alert Rules → Personal Rules', parent: '/alert-rules' },
  
  // Settings and its tabs
  { path: '/settings', name: 'Settings', isParent: true },
  { path: '/settings/account', name: 'Settings → Account', parent: '/settings' },
  { path: '/settings/users', name: 'Settings → User Management', parent: '/settings' },
  { path: '/settings/page-access', name: 'Settings → Page Access', parent: '/settings' },
  { path: '/settings/ai-provider', name: 'Settings → AI Provider', parent: '/settings' },
  { path: '/settings/prompts', name: 'Settings → AI Prompts', parent: '/settings' },
];

// This now dynamically uses custom roles - kept for backwards compatibility
export const ALL_ROLES: AppRole[] = ['admin', 'manager', 'se', 'ae', 'product'];

export function usePageAccess() {
  const queryClient = useQueryClient();

  const { data: pageAccess, isLoading } = useQuery({
    queryKey: ['page-access'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('page_role_access')
        .select('*')
        .order('page_path')
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data as PageAccess[];
    },
  });

  const addAccess = useMutation({
    mutationFn: async ({ pagePath, pageName, role }: { pagePath: string; pageName: string; role: AppRole }) => {
      const { error } = await gateway
        .from('page_role_access')
        .insert({ 
          page_path: pagePath, 
          page_name: pageName, 
          role: role as any 
        })
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['page-access'] });
      toast.success('Access granted');
    },
    onError: (error: any) => {
      toast.error('Failed to add access: ' + error.message);
    },
  });

  const removeAccess = useMutation({
    mutationFn: async ({ pagePath, role }: { pagePath: string; role: AppRole }) => {
      const { error } = await gateway
        .from('page_role_access')
        .delete()
        .eq('page_path', pagePath)
        .eq('role', role as any)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['page-access'] });
      toast.success('Access removed');
    },
    onError: (error: any) => {
      toast.error('Failed to remove access: ' + error.message);
    },
  });

  // Check if a role has access to a specific page
  const hasPageAccess = (pagePath: string, role: AppRole): boolean => {
    if (!pageAccess) return true; // Default to allowing access while loading
    return pageAccess.some(pa => pa.page_path === pagePath && pa.role === role);
  };

  // Get all roles that have access to a page
  const getRolesForPage = (pagePath: string): AppRole[] => {
    if (!pageAccess) return [];
    return pageAccess
      .filter(pa => pa.page_path === pagePath)
      .map(pa => pa.role as AppRole);
  };

  // Get all pages a role has access to
  const getPagesForRole = (role: AppRole): string[] => {
    if (!pageAccess) return [];
    return pageAccess
      .filter(pa => pa.role === role)
      .map(pa => pa.page_path);
  };

  return {
    pageAccess: pageAccess || [],
    isLoading,
    addAccess,
    removeAccess,
    hasPageAccess,
    getRolesForPage,
    getPagesForRole,
  };
}

// Hook to check if current user can access a page
export function useCanAccessPage(pagePath: string) {
  const { user } = useAuth();

  const { data: canAccess, isLoading } = useQuery({
    queryKey: ['can-access-page', user?.id, pagePath],
    queryFn: async () => {
      if (!user?.id) return false;
      
      const { data, error } = await supabase
        .rpc('can_access_page', { 
          _user_id: user.id, 
          _page_path: pagePath 
        });
      
      if (error) {
        console.error('Error checking page access:', error);
        return true; // Default to allowing access on error
      }
      return data;
    },
    enabled: !!user?.id,
  });

  return { canAccess: canAccess ?? true, isLoading };
}

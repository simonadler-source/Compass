import { useState, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage, GatewayQuery } from '@/lib/apiGateway';

export type PageSize = 25 | 50 | 100;

interface PaginatedMeetingsResult<T> {
  data: T[];
  isLoading: boolean;
  isFetchingMore: boolean;
  hasMore: boolean;
  loadMore: () => void;
  reset: () => void;
  pageSize: PageSize;
  setPageSize: (size: PageSize) => void;
  totalLoaded: number;
}

interface UsePaginatedMeetingsOptions {
  queryKey: string[];
  select: string;
  filters?: { column: string; operator: string; value: any }[];
  orFilter?: string;
  orderBy: { column: string; ascending: boolean };
  initialPageSize?: PageSize;
  enabled?: boolean;
}

function applyFilters<T>(query: GatewayQuery<T>, filters: { column: string; operator: string; value: any }[]): GatewayQuery<T> {
  for (const filter of filters) {
    if (filter.operator === 'eq') {
      query = query.eq(filter.column, filter.value);
    } else if (filter.operator === 'is') {
      query = query.is(filter.column, filter.value as null | boolean);
    } else if (filter.operator === 'not.is') {
      query = query.not(filter.column, 'is', filter.value);
    }
  }
  return query;
}

export function usePaginatedMeetings<T>({
  queryKey,
  select,
  filters = [],
  orFilter,
  orderBy,
  initialPageSize = 50,
  enabled = true,
}: UsePaginatedMeetingsOptions): PaginatedMeetingsResult<T> {
  const [pageSize, setPageSize] = useState<PageSize>(initialPageSize);
  const [allData, setAllData] = useState<T[]>([]);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [isFetchingMore, setIsFetchingMore] = useState(false);

  // Initial fetch
  const { isLoading, refetch } = useQuery({
    queryKey: [...queryKey, pageSize],
    queryFn: async () => {
      let query = gateway.from('momentum_meetings').select(select);

      // Apply filters
      query = applyFilters(query, filters);

      // Apply OR filter
      if (orFilter) {
        query = query.or(orFilter);
      }

      // Apply ordering and limit
      query = query
        .order(orderBy.column, { ascending: orderBy.ascending })
        .limit(pageSize);

      const { data, error } = await query.execute();
      if (error) throw new Error(getErrorMessage(error));
      
      const result = (data || []) as T[];
      setAllData(result);
      setOffset(result.length);
      setHasMore(result.length >= pageSize);
      
      return result;
    },
    enabled,
  });

  const loadMore = useCallback(async () => {
    if (!hasMore || isFetchingMore) return;
    
    setIsFetchingMore(true);
    try {
      let query = gateway.from('momentum_meetings').select(select);

      // Apply filters
      query = applyFilters(query, filters);

      // Apply OR filter
      if (orFilter) {
        query = query.or(orFilter);
      }

      // Apply ordering and range for next page
      query = query
        .order(orderBy.column, { ascending: orderBy.ascending })
        .offset(offset)
        .limit(pageSize);

      const { data, error } = await query.execute();
      if (error) throw new Error(getErrorMessage(error));
      
      const newData = (data || []) as T[];
      setAllData(prev => [...prev, ...newData]);
      setOffset(prev => prev + newData.length);
      setHasMore(newData.length >= pageSize);
    } finally {
      setIsFetchingMore(false);
    }
  }, [hasMore, isFetchingMore, select, filters, orFilter, orderBy, offset, pageSize]);

  const reset = useCallback(() => {
    setAllData([]);
    setOffset(0);
    setHasMore(true);
    refetch();
  }, [refetch]);

  const handleSetPageSize = useCallback((size: PageSize) => {
    setPageSize(size);
    setAllData([]);
    setOffset(0);
    setHasMore(true);
  }, []);

  return {
    data: allData,
    isLoading,
    isFetchingMore,
    hasMore,
    loadMore,
    reset,
    pageSize,
    setPageSize: handleSetPageSize,
    totalLoaded: allData.length,
  };
}

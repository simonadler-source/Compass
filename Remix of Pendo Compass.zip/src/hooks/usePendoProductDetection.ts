import { useQuery } from "@tanstack/react-query";
import { gateway, getErrorMessage } from "@/lib/apiGateway";
import { startOfDay, endOfDay, format } from "date-fns";
import type { DateRange } from "./useProductMentions";

// The tree ID for Pendo Products Detection rules
const PENDO_PRODUCTS_TREE_ID = "b0000001-0001-4000-8000-000000000001";

export interface PendoProductMatch {
  rule_id: string;
  rule_name: string;
  match_count: number;
  total_mentions: number;
  avg_confidence: number;
  transcripts_count: number;
  last_detected: string | null;
  interest_levels: {
    high: number;
    medium: number;
    low: number;
    none: number;
  };
  speaker_breakdown: {
    internal: number;
    customer: number;
    both: number;
  };
}

export interface PendoProductRecentMatch {
  id: string;
  rule_name: string;
  rule_id: string;
  transcript_id: string;
  opportunity_id: string | null;
  account_id: string | null;
  account_name: string | null;
  meeting_title: string | null;
  meeting_date: string | null;
  confidence_score: number | null;
  matched_phrases: string[];
  speaker_type: string | null;
  speaker_name: string | null;
  interest_level: string | null;
  use_case_context: string | null;
  mention_count: number | null;
  context_quotes: any[] | null;
  related_products: string[];
  created_at: string;
}

// Get Pendo product detection stats aggregated by product
export function usePendoProductDetectionStats(dateRange: DateRange) {
  return useQuery({
    queryKey: ["pendo-product-detection-stats", dateRange.from.toISOString(), dateRange.to.toISOString()],
    queryFn: async () => {
      // First get all rules in the Pendo Products tree
      const rulesResponse = await gateway
        .from("detection_rules")
        .select("id, name")
        .eq("tree_id", PENDO_PRODUCTS_TREE_ID)
        .eq("is_active", true)
        .execute();

      if (rulesResponse.error) throw new Error(getErrorMessage(rulesResponse.error));
      const rules = rulesResponse.data || [];

      if (rules.length === 0) {
        return [];
      }

      const ruleIds = rules.map((r) => r.id);
      const ruleNameMap = new Map(rules.map((r) => [r.id, r.name]));

      // Get matches within date range
      const matchesResponse = await gateway
        .from("detection_rule_matches")
        .select(
          `
          id,
          rule_id,
          transcript_id,
          confidence_score,
          matched_phrases,
          occurrence_count,
          first_detected_at,
          speaker_type,
          transcript_reviews!inner(created_at)
        `,
        )
        .in("rule_id", ruleIds)
        .gte("transcript_reviews.created_at", startOfDay(dateRange.from).toISOString())
        .lte("transcript_reviews.created_at", endOfDay(dateRange.to).toISOString())
        .execute();

      if (matchesResponse.error) throw new Error(getErrorMessage(matchesResponse.error));
      const matches = matchesResponse.data || [];

      // Get captured insights for these matches
      const matchIds = matches.map((m) => m.id);
      let capturedInsights: any[] = [];

      if (matchIds.length > 0) {
        const insightsResponse = await gateway
          .from("account_captured_insights")
          .select("rule_match_id, capture_field_id, value, value_json, detection_rule_capture_fields(field_name)")
          .in("rule_match_id", matchIds)
          .execute();

        if (!insightsResponse.error) {
          capturedInsights = insightsResponse.data || [];
        }
      }

      // Build insights map by match_id
      const insightsMap = new Map<string, Record<string, any>>();
      capturedInsights.forEach((insight: any) => {
        if (!insight.rule_match_id) return;
        const fieldName = insight.detection_rule_capture_fields?.field_name;
        if (!fieldName) return;

        const existing = insightsMap.get(insight.rule_match_id) || {};
        existing[fieldName] = insight.value_json || insight.value;
        insightsMap.set(insight.rule_match_id, existing);
      });

      // Aggregate by rule
      const statsMap = new Map<string, PendoProductMatch>();

      matches.forEach((match: any) => {
        const ruleId = String(match.rule_id);
        const matchId = String(match.id);
        const ruleName = ruleNameMap.get(ruleId) || "Unknown";
        const insights = insightsMap.get(matchId) || {};

        const existing = statsMap.get(ruleId);

        if (existing) {
          existing.match_count += 1;
          existing.total_mentions += match.occurrence_count || 1;
          existing.transcripts_count += 1;
          existing.avg_confidence =
            (existing.avg_confidence * (existing.match_count - 1) + (match.confidence_score || 0)) /
            existing.match_count;

          if (
            match.first_detected_at &&
            (!existing.last_detected || match.first_detected_at > existing.last_detected)
          ) {
            existing.last_detected = match.first_detected_at as string;
          }

          // Interest level from captured insights
          const interest = insights.interest_level?.toLowerCase() || "none";
          if (interest === "high") existing.interest_levels.high++;
          else if (interest === "medium") existing.interest_levels.medium++;
          else if (interest === "low") existing.interest_levels.low++;
          else existing.interest_levels.none++;

          // Speaker breakdown
          const speaker = insights.speaker_type?.toLowerCase() || match.speaker_type || "both";
          if (speaker.includes("internal")) existing.speaker_breakdown.internal++;
          else if (speaker.includes("customer")) existing.speaker_breakdown.customer++;
          else existing.speaker_breakdown.both++;
        } else {
          const interest = (insights.interest_level || "none").toLowerCase();
          const speaker = (insights.speaker_type || match.speaker_type || "both").toLowerCase();

          statsMap.set(ruleId, {
            rule_id: ruleId,
            rule_name: String(ruleName),
            match_count: 1,
            total_mentions: match.occurrence_count || 1,
            avg_confidence: match.confidence_score || 0,
            transcripts_count: 1,
            last_detected: match.first_detected_at as string | null,
            interest_levels: {
              high: interest === "high" ? 1 : 0,
              medium: interest === "medium" ? 1 : 0,
              low: interest === "low" ? 1 : 0,
              none: !["high", "medium", "low"].includes(interest) ? 1 : 0,
            },
            speaker_breakdown: {
              internal: speaker.includes("internal") ? 1 : 0,
              customer: speaker.includes("customer") ? 1 : 0,
              both: !speaker.includes("internal") && !speaker.includes("customer") ? 1 : 0,
            },
          });
        }
      });

      // Add rules with zero matches
      rules.forEach((rule) => {
        if (!statsMap.has(rule.id)) {
          statsMap.set(rule.id, {
            rule_id: rule.id,
            rule_name: rule.name,
            match_count: 0,
            total_mentions: 0,
            avg_confidence: 0,
            transcripts_count: 0,
            last_detected: null,
            interest_levels: { high: 0, medium: 0, low: 0, none: 0 },
            speaker_breakdown: { internal: 0, customer: 0, both: 0 },
          });
        }
      });

      return Array.from(statsMap.values()).sort((a, b) => b.total_mentions - a.total_mentions);
    },
  });
}

// Get recent Pendo product detection matches with details
export function usePendoProductRecentMatches(dateRange: DateRange, limit = 20) {
  return useQuery({
    queryKey: ["pendo-product-recent-matches", dateRange.from.toISOString(), dateRange.to.toISOString(), limit],
    queryFn: async () => {
      // Get rules in the tree
      const rulesResponse = await gateway
        .from("detection_rules")
        .select("id, name")
        .eq("tree_id", PENDO_PRODUCTS_TREE_ID)
        .eq("is_active", true)
        .execute();

      if (rulesResponse.error) throw new Error(getErrorMessage(rulesResponse.error));
      const rules = rulesResponse.data || [];

      if (rules.length === 0) return [];

      const ruleIds = rules.map((r) => r.id);
      const ruleNameMap = new Map(rules.map((r) => [r.id, r.name]));

      // Get recent matches with transcript info
      const matchesResponse = await gateway
        .from("detection_rule_matches")
        .select(
          `
          id,
          rule_id,
          transcript_id,
          opportunity_id,
          confidence_score,
          matched_phrases,
          occurrence_count,
          speaker_type,
          speaker_name,
          created_at,
          transcript_reviews!detection_rule_matches_transcript_id_fkey(
            meeting_title,
            created_at,
            final_account_id
          )
        `,
        )
        .in("rule_id", ruleIds)
        .order("created_at", { ascending: false })
        .limit(limit)
        .execute();

      // Get account names separately to avoid ambiguous relationship
      const accountIds = [
        ...new Set(
          (matchesResponse.data || []).map((m: any) => m.transcript_reviews?.final_account_id).filter(Boolean),
        ),
      ];

      let accountNameMap = new Map<string, string>();
      if (accountIds.length > 0) {
        const accountsResponse = await gateway.from("accounts").select("id, name").in("id", accountIds).execute();

        if (!accountsResponse.error && accountsResponse.data) {
          accountsResponse.data.forEach((a: any) => {
            accountNameMap.set(a.id, a.name);
          });
        }
      }

      if (matchesResponse.error) throw new Error(getErrorMessage(matchesResponse.error));
      const matches = matchesResponse.data || [];

      // Get captured insights for context
      const matchIds = matches.map((m) => m.id);
      let capturedInsights: any[] = [];

      if (matchIds.length > 0) {
        const insightsResponse = await gateway
          .from("account_captured_insights")
          .select("rule_match_id, value, value_json, detection_rule_capture_fields(field_name)")
          .in("rule_match_id", matchIds)
          .execute();

        if (!insightsResponse.error) {
          capturedInsights = insightsResponse.data || [];
        }
      }

      // Build insights map
      const insightsMap = new Map<string, Record<string, any>>();
      capturedInsights.forEach((insight: any) => {
        if (!insight.rule_match_id) return;
        const fieldName = insight.detection_rule_capture_fields?.field_name;
        if (!fieldName) return;

        const existing = insightsMap.get(insight.rule_match_id) || {};
        existing[fieldName] = insight.value_json || insight.value;
        insightsMap.set(insight.rule_match_id, existing);
      });

      // Find related products mentioned in the same transcript
      const transcriptProductsMap = new Map<string, Set<string>>();
      matches.forEach((m: any) => {
        const tid = String(m.transcript_id);
        if (!transcriptProductsMap.has(tid)) {
          transcriptProductsMap.set(tid, new Set());
        }
        const ruleName = ruleNameMap.get(String(m.rule_id));
        transcriptProductsMap.get(tid)!.add(ruleName ? String(ruleName) : "Unknown");
      });

      return matches.map((match: any): PendoProductRecentMatch => {
        const insights = insightsMap.get(match.id) || {};
        const thisProductName = ruleNameMap.get(String(match.rule_id)) || "Unknown";
        const relatedProducts = Array.from(transcriptProductsMap.get(String(match.transcript_id)) || []).filter(
          (p) => p !== thisProductName,
        );

        return {
          id: String(match.id),
          rule_name: String(thisProductName),
          rule_id: String(match.rule_id),
          transcript_id: String(match.transcript_id),
          opportunity_id: match.opportunity_id,
          account_id: match.transcript_reviews?.final_account_id || null,
          account_name: accountNameMap.get(match.transcript_reviews?.final_account_id) || null,
          meeting_title: match.transcript_reviews?.meeting_title || null,
          meeting_date: match.transcript_reviews?.created_at || null,
          confidence_score: match.confidence_score,
          matched_phrases: match.matched_phrases || [],
          speaker_type: insights.speaker_type || match.speaker_type,
          speaker_name: insights.speaker_name || match.speaker_name || null,
          interest_level: insights.interest_level,
          use_case_context: insights.use_case_context || null,
          mention_count: insights.mention_count || match.occurrence_count,
          context_quotes: insights.context_quotes,
          related_products: relatedProducts,
          created_at: match.created_at,
        };
      });
    },
  });
}

// Get summary totals for the header cards
export function usePendoProductDetectionSummary(dateRange: DateRange) {
  return useQuery({
    queryKey: ["pendo-product-detection-summary", dateRange.from.toISOString(), dateRange.to.toISOString()],
    queryFn: async () => {
      // Get rules in the tree
      const rulesResponse = await gateway
        .from("detection_rules")
        .select("id")
        .eq("tree_id", PENDO_PRODUCTS_TREE_ID)
        .eq("is_active", true)
        .execute();

      if (rulesResponse.error) throw new Error(getErrorMessage(rulesResponse.error));
      const rules = rulesResponse.data || [];

      if (rules.length === 0) {
        return { totalProducts: 0, totalMentions: 0, totalTranscripts: 0, productsWithMentions: 0 };
      }

      const ruleIds = rules.map((r) => r.id);

      // Count matches
      const matchesResponse = await gateway
        .from("detection_rule_matches")
        .select(
          `
          id,
          rule_id,
          transcript_id,
          occurrence_count,
          transcript_reviews!inner(created_at)
        `,
        )
        .in("rule_id", ruleIds)
        .gte("transcript_reviews.created_at", startOfDay(dateRange.from).toISOString())
        .lte("transcript_reviews.created_at", endOfDay(dateRange.to).toISOString())
        .execute();

      if (matchesResponse.error) throw new Error(getErrorMessage(matchesResponse.error));
      const matches = matchesResponse.data || [];

      const uniqueRules = new Set(matches.map((m: any) => m.rule_id));
      const uniqueTranscripts = new Set(matches.map((m: any) => m.transcript_id));
      const totalMentions = matches.reduce((sum: number, m: any) => sum + (m.occurrence_count || 1), 0);

      return {
        totalProducts: rules.length,
        totalMentions,
        totalTranscripts: uniqueTranscripts.size,
        productsWithMentions: uniqueRules.size,
      };
    },
  });
}

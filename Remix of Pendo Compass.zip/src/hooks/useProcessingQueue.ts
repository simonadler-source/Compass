import { useQuery } from "@tanstack/react-query";
import { gateway, getErrorMessage } from "@/lib/apiGateway";
import { supabase } from "@/integrations/supabase/client";

export interface QueuedMeeting {
  id: string;
  momentum_id: string;
  title: string | null;
  start_time: string;
  status: string;
  matched_account_id: string | null;
  salesforce_account_id: string | null;
  created_at: string;
  host_name: string | null;
  attendees: any[];
}

export interface TranscriptQueueItem {
  id: string;
  opportunity_id: string | null;
  final_account_id: string | null;
  enrichment_status: string | null;
  status: string;
  created_at: string;
  last_enriched_hash: string | null;
  file_name: string | null;
  account_name?: string;
  meeting_title?: string | null;
  meeting_start_time?: string | null;
}

export interface ProcessingQueueStats {
  meetingsPending: number;
  meetingsQueued: number;
  meetingsProcessing: number;
  transcriptsPendingEnrichment: number;
  transcriptsInProgress: number;
  transcriptsTotalStuck: number;
}

export function useProcessingQueue() {
  // Fetch meetings in queued/processing status
  const { data: queuedMeetings, isLoading: loadingMeetings, refetch: refetchMeetings } = useQuery({
    queryKey: ['processing-queue', 'meetings'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select('id, momentum_id, title, start_time, status, matched_account_id, salesforce_account_id, created_at, host_name, attendees')
        .in('status', ['queued', 'processing'])
        .order('created_at', { ascending: true })
        .limit(200)
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return (data || []) as QueuedMeeting[];
    },
    refetchInterval: 10000,
  });

  // Fetch pending meetings exact count (discovered but not yet queued for import)
  const { data: pendingMeetingsExactCount, isLoading: loadingPending, refetch: refetchPending } = useQuery({
    queryKey: ['processing-queue', 'pending-exact-count'],
    queryFn: async () => {
      const res = await gateway
        .from('momentum_meetings')
        .select('id')
        .eq('status', 'pending')
        .countOnly()
        .execute();
      
      if (res.error) throw new Error(getErrorMessage(res.error));
      return (res.data as any)?.count || 0;
    },
    refetchInterval: 30000,
  });

  // Fetch total count of stuck transcripts (pending + in_progress enrichment)
  const { data: stuckCount, refetch: refetchStuckCount } = useQuery({
    queryKey: ['processing-queue', 'stuck-count'],
    queryFn: async () => {
      // Count pending
      const { count: pendingCount } = await supabase
        .from('transcript_reviews')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'approved')
        .in('enrichment_status', ['pending', 'in_progress']);
      
      // Also count those with null enrichment_status and no last_enriched_hash (legacy)
      const { count: nullCount } = await supabase
        .from('transcript_reviews')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'approved')
        .is('enrichment_status', null)
        .is('last_enriched_hash', null);

      return {
        enrichmentStuck: pendingCount || 0,
        legacyPending: nullCount || 0,
        total: (pendingCount || 0) + (nullCount || 0),
      };
    },
    refetchInterval: 30000,
  });

  // Fetch transcripts pending enrichment - use enrichment_status and higher limit
  const { data: pendingTranscripts, isLoading: loadingTranscripts, refetch: refetchTranscripts } = useQuery({
    queryKey: ['processing-queue', 'transcripts'],
    queryFn: async () => {
      // Fetch transcripts with enrichment_status pending or in_progress
      const { data: enrichmentPending, error: err1 } = await gateway
        .from('transcript_reviews')
        .select('id, opportunity_id, final_account_id, status, created_at, last_enriched_hash, file_name, meeting_title, momentum_meeting_id, enrichment_status')
        .eq('status', 'approved')
        .in('enrichment_status', ['pending', 'in_progress'])
        .order('created_at', { ascending: true })
        .limit(500)
        .execute();
      
      if (err1) throw new Error(getErrorMessage(err1));

      // Also fetch legacy ones (null enrichment_status, no hash)
      const { data: legacyPending, error: err2 } = await gateway
        .from('transcript_reviews')
        .select('id, opportunity_id, final_account_id, status, created_at, last_enriched_hash, file_name, meeting_title, momentum_meeting_id, enrichment_status')
        .eq('status', 'approved')
        .is('enrichment_status', null)
        .is('last_enriched_hash', null)
        .order('created_at', { ascending: true })
        .limit(500)
        .execute();

      if (err2) throw new Error(getErrorMessage(err2));

      const allTranscripts = [...(enrichmentPending || []), ...(legacyPending || [])] as any[];
      
      // Deduplicate by id
      const seen = new Set<string>();
      const transcripts = allTranscripts.filter(t => {
        if (seen.has(t.id)) return false;
        seen.add(t.id);
        return true;
      });
      
      // For transcripts missing meeting_title, try fetching from momentum_meetings
      const needsLookup = transcripts.filter(t => !t.meeting_title && t.momentum_meeting_id);
      const meetingIds = needsLookup.map(t => t.momentum_meeting_id) as string[];
      
      let meetingMap: Record<string, { title: string | null; start_time: string | null }> = {};
      if (meetingIds.length > 0) {
        const { data: meetings } = await gateway
          .from('momentum_meetings')
          .select('id, title, start_time')
          .in('id', meetingIds)
          .execute();
        
        if (meetings) {
          for (const m of meetings as any[]) {
            meetingMap[m.id] = { title: m.title, start_time: m.start_time };
          }
        }
      }
      
      return transcripts.map(t => ({
        ...t,
        meeting_title: t.meeting_title || meetingMap[t.momentum_meeting_id]?.title || null,
        meeting_start_time: meetingMap[t.momentum_meeting_id]?.start_time || null,
      })) as TranscriptQueueItem[];
    },
    refetchInterval: 15000,
  });

  // Calculate stats
  const stats: ProcessingQueueStats = {
    meetingsPending: pendingMeetingsExactCount || 0,
    meetingsQueued: queuedMeetings?.filter(m => m.status === 'queued').length || 0,
    meetingsProcessing: queuedMeetings?.filter(m => m.status === 'processing').length || 0,
    transcriptsPendingEnrichment: pendingTranscripts?.filter(t => t.enrichment_status === 'pending' || !t.enrichment_status).length || 0,
    transcriptsInProgress: pendingTranscripts?.filter(t => t.enrichment_status === 'in_progress').length || 0,
    transcriptsTotalStuck: stuckCount?.total || pendingTranscripts?.length || 0,
  };

  const refetchAll = () => {
    refetchMeetings();
    refetchTranscripts();
    refetchPending();
    refetchStuckCount();
  };

  return {
    queuedMeetings: queuedMeetings || [],
    pendingTranscripts: pendingTranscripts || [],
    pendingMeetings: [],
    stats,
    isLoading: loadingMeetings || loadingTranscripts || loadingPending,
    refetch: refetchAll,
  };
}

import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { startOfDay, endOfDay } from 'date-fns';
import type { DateRange } from './useProductMentions';

// The tree ID for Pendo Products Detection rules
const PENDO_PRODUCTS_TREE_ID = 'b0000001-0001-4000-8000-000000000001';

export interface ProductMentionBubble {
  id: string;
  personEmail: string;
  personName: string;
  personId: string | null;
  managerId: string | null;
  managerEmail: string | null;
  managerName: string | null;
  productName: string;
  productRuleId: string;
  detectedAt: string;
  confidenceScore: number;
  interestLevel: string | null;
  speakerType: string | null;
  meetingTitle: string | null;
  transcriptId: string;
  accountId: string | null;
  accountName: string | null;
  contextQuotes: string[];
  matchedPhrases: string[];
}

export interface ManagerOption {
  id: string;
  email: string;
  name: string;
  reportCount: number;
}

export interface ProductMentionBubblesResult {
  bubbles: ProductMentionBubble[];
  products: { id: string; name: string }[];
  managers: ManagerOption[];
  persons: { id: string; email: string; name: string; managerId: string | null }[];
}

// Product colors for consistent visualization
export const PRODUCT_COLORS = [
  'hsl(262 83% 58%)', // purple
  'hsl(199 89% 48%)', // sky blue
  'hsl(142 71% 45%)', // green
  'hsl(25 95% 53%)',  // orange
  'hsl(340 75% 55%)', // pink
  'hsl(47 96% 53%)',  // yellow
  'hsl(172 66% 50%)', // teal
  'hsl(292 84% 60%)', // magenta
  'hsl(221 83% 53%)', // blue
  'hsl(0 84% 60%)',   // red
  'hsl(38 92% 50%)',  // amber
  'hsl(150 60% 40%)', // emerald
  'hsl(280 65% 60%)', // violet
  'hsl(200 98% 39%)', // cyan
  'hsl(60 85% 48%)',  // lime
];

export function useProductMentionBubbles(dateRange: DateRange) {
  return useQuery({
    queryKey: ['product-mention-bubbles', dateRange.from.toISOString(), dateRange.to.toISOString()],
    queryFn: async (): Promise<ProductMentionBubblesResult> => {
      // Fetch all required data in parallel
      const [rulesResponse, hierarchyResponse, profilesResponse, teamMembersResponse] = await Promise.all([
        gateway.from('detection_rules')
          .select('id, name')
          .eq('tree_id', PENDO_PRODUCTS_TREE_ID)
          .eq('is_active', true)
          .execute(),
        gateway.from('team_hierarchy')
          .select('manager_id, report_id')
          .execute(),
        gateway.from('profiles')
          .select('id, email, full_name')
          .execute(),
        gateway.from('team_members')
          .select('id, member_email, member_name')
          .execute(),
      ]);

      if (rulesResponse.error) throw new Error(getErrorMessage(rulesResponse.error));
      const rules = rulesResponse.data || [];
      
      if (rules.length === 0) {
        return { bubbles: [], products: [], managers: [], persons: [] };
      }

      const ruleIds = rules.map((r: any) => r.id as string);
      const ruleNameMap = new Map<string, string>(rules.map((r: any) => [r.id as string, r.name as string]));
      const products = rules.map((r: any) => ({ id: r.id as string, name: r.name as string }));

      // Build profile maps
      const profiles = profilesResponse.data || [];
      const emailToProfile = new Map<string, { id: string; name: string }>();
      const idToProfile = new Map<string, { email: string; name: string }>();
      profiles.forEach((p: any) => {
        if (p.email) {
          emailToProfile.set(p.email.toLowerCase(), { id: p.id, name: p.full_name || p.email });
          idToProfile.set(p.id, { email: p.email.toLowerCase(), name: p.full_name || p.email });
        }
      });

      // Build team members map
      const teamMembers = teamMembersResponse.data || [];
      const teamMemberEmails = new Set(teamMembers.map((t: any) => t.member_email?.toLowerCase()).filter(Boolean));

      // Build hierarchy maps
      const hierarchyData = hierarchyResponse.data || [];
      const reportToManager = new Map<string, string>();
      const managerToReports = new Map<string, Set<string>>();
      hierarchyData.forEach((h: any) => {
        reportToManager.set(h.report_id, h.manager_id);
        if (!managerToReports.has(h.manager_id)) {
          managerToReports.set(h.manager_id, new Set());
        }
        managerToReports.get(h.manager_id)!.add(h.report_id);
      });

      // Build managers list
      const managers: ManagerOption[] = [];
      managerToReports.forEach((reports, managerId) => {
        const profile = idToProfile.get(managerId);
        if (profile) {
          managers.push({
            id: managerId,
            email: profile.email,
            name: profile.name,
            reportCount: reports.size,
          });
        }
      });
      managers.sort((a, b) => b.reportCount - a.reportCount);

      // Build persons list (internal only)
      const persons = profiles
        .filter((p: any) => p.email && teamMemberEmails.has(p.email.toLowerCase()))
        .map((p: any) => ({
          id: p.id,
          email: p.email.toLowerCase(),
          name: p.full_name || p.email,
          managerId: reportToManager.get(p.id) || null,
        }));

      // Fetch matches with transcript info
      const matchesResponse = await gateway.from('detection_rule_matches')
        .select(`
          id,
          rule_id,
          transcript_id,
          confidence_score,
          occurrence_count,
          first_detected_at,
          speaker_type,
          speaker_name,
          speaker_email,
          matched_phrases,
          transcript_reviews!inner(
            id,
            meeting_title,
            created_at,
            final_account_id
          )
        `)
        .in('rule_id', ruleIds)
        .gte('transcript_reviews.created_at', startOfDay(dateRange.from).toISOString())
        .lte('transcript_reviews.created_at', endOfDay(dateRange.to).toISOString())
        .order('first_detected_at', { ascending: true })
        .execute();

      if (matchesResponse.error) throw new Error(getErrorMessage(matchesResponse.error));
      const matches = matchesResponse.data || [];

      // Get account names
      const accountIds = [...new Set(matches.map((m: any) => m.transcript_reviews?.final_account_id).filter(Boolean))];
      const accountNameMap = new Map<string, string>();
      if (accountIds.length > 0) {
        const accountsResponse = await gateway.from('accounts')
          .select('id, name')
          .in('id', accountIds)
          .execute();
        if (!accountsResponse.error && accountsResponse.data) {
          accountsResponse.data.forEach((a: any) => {
            accountNameMap.set(a.id, a.name);
          });
        }
      }

      // Get captured insights for interest levels and context
      const matchIds = matches.map((m: any) => m.id);
      const insightsMap = new Map<string, Record<string, any>>();
      
      if (matchIds.length > 0) {
        const insightsResponse = await gateway.from('account_captured_insights')
          .select('rule_match_id, value, value_json, detection_rule_capture_fields(field_name)')
          .in('rule_match_id', matchIds)
          .execute();
        
        if (!insightsResponse.error && insightsResponse.data) {
          insightsResponse.data.forEach((insight: any) => {
            if (!insight.rule_match_id) return;
            const fieldName = insight.detection_rule_capture_fields?.field_name;
            if (!fieldName) return;
            
            const existing = insightsMap.get(insight.rule_match_id) || {};
            existing[fieldName] = insight.value_json || insight.value;
            insightsMap.set(insight.rule_match_id, existing);
          });
        }
      }

      // Transform matches to bubbles
      const bubbles: ProductMentionBubble[] = [];
      
      matches.forEach((match: any) => {
        const speakerEmail = (match.speaker_email || '').toLowerCase();
        const speakerName = match.speaker_name || speakerEmail || 'Unknown';
        const isInternal = teamMemberEmails.has(speakerEmail) || match.speaker_type === 'internal';
        
        // Only include internal speakers
        if (!isInternal) return;
        
        const productName = ruleNameMap.get(match.rule_id) || 'Unknown';
        const insights = insightsMap.get(match.id) || {};
        const profile = emailToProfile.get(speakerEmail);
        const managerId = profile ? reportToManager.get(profile.id) || null : null;
        const managerProfile = managerId ? idToProfile.get(managerId) : null;
        
        // Parse context quotes
        let contextQuotes: string[] = [];
        if (insights.context_quotes) {
          if (Array.isArray(insights.context_quotes)) {
            contextQuotes = insights.context_quotes.map((q: any) => 
              typeof q === 'string' ? q : q?.quote || q?.text || ''
            ).filter(Boolean);
          }
        }
        
        bubbles.push({
          id: match.id,
          personEmail: speakerEmail,
          personName: speakerName,
          personId: profile?.id || null,
          managerId,
          managerEmail: managerProfile?.email || null,
          managerName: managerProfile?.name || null,
          productName,
          productRuleId: match.rule_id,
          detectedAt: match.first_detected_at || match.transcript_reviews?.created_at,
          confidenceScore: match.confidence_score || 0,
          interestLevel: insights.interest_level || null,
          speakerType: match.speaker_type,
          meetingTitle: match.transcript_reviews?.meeting_title || null,
          transcriptId: match.transcript_id,
          accountId: match.transcript_reviews?.final_account_id || null,
          accountName: accountNameMap.get(match.transcript_reviews?.final_account_id) || null,
          contextQuotes,
          matchedPhrases: match.matched_phrases || [],
        });
      });

      return {
        bubbles,
        products,
        managers,
        persons,
      };
    },
  });
}

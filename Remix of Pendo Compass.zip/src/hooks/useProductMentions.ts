import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { startOfDay, endOfDay, format, subDays, differenceInDays, startOfWeek, startOfMonth } from 'date-fns';

export interface ProductMention {
  id: string;
  transcript_id: string;
  account_id: string | null;
  opportunity_id: string | null;
  technology_id: string | null;
  product_name: string;
  mention_type: 'owned' | 'complementary' | 'competitive';
  sentiment_score: number | null;
  sentiment_label: 'positive' | 'neutral' | 'negative' | 'mixed' | null;
  context_snippet: string | null;
  mention_count: number;
  confidence_score: number | null;
  integration_context: string | null;
  transcript_date: string | null;
  created_at: string;
}

export interface ProductMentionWithDetails extends ProductMention {
  accounts?: { name: string } | null;
  transcript_reviews?: { meeting_title: string | null } | null;
}

export interface DateRange {
  from: Date;
  to: Date;
}

export type PeriodGrouping = 'daily' | 'weekly' | 'monthly';

export interface MentionTrend {
  date: string;
  owned: number;
  complementary: number;
  competitive: number;
  total: number;
  calls?: number;
}

export interface ProductStats {
  product_name: string;
  mention_type: 'owned' | 'complementary' | 'competitive';
  total_mentions: number;
  avg_sentiment: number | null;
  positive_count: number;
  neutral_count: number;
  negative_count: number;
  mixed_count: number;
}

export interface SentimentExcerpt {
  id: string;
  product_name: string;
  context_snippet: string | null;
  sentiment_label: string | null;
  mention_count?: number;
  transcript_date: string | null;
  transcript_id: string;
  account_id: string | null;
  account_name: string | null;
}

// Auto-pick best grouping based on date range
export function autoGrouping(dateRange: DateRange): PeriodGrouping {
  const days = differenceInDays(dateRange.to, dateRange.from);
  if (days <= 30) return 'daily';
  if (days <= 90) return 'weekly';
  return 'monthly';
}

// Group daily trend data into weekly or monthly buckets
export function groupTrendsByPeriod(trends: MentionTrend[], period: PeriodGrouping): MentionTrend[] {
  if (period === 'daily') return trends;

  const bucketMap = new Map<string, MentionTrend>();

  trends.forEach((t) => {
    const d = new Date(t.date);
    let bucketKey: string;
    if (period === 'weekly') {
      const weekStart = startOfWeek(d, { weekStartsOn: 1 });
      bucketKey = format(weekStart, 'yyyy-MM-dd');
    } else {
      const monthStart = startOfMonth(d);
      bucketKey = format(monthStart, 'yyyy-MM-dd');
    }

    const existing = bucketMap.get(bucketKey);
    if (existing) {
      existing.owned += t.owned;
      existing.competitive += t.competitive;
      existing.complementary += t.complementary;
      existing.total += t.total;
      existing.calls = (existing.calls || 0) + (t.calls || 0);
    } else {
      bucketMap.set(bucketKey, {
        date: bucketKey,
        owned: t.owned,
        competitive: t.competitive,
        complementary: t.complementary,
        total: t.total,
        calls: t.calls || 0,
      });
    }
  });

  return Array.from(bucketMap.values()).sort((a, b) => a.date.localeCompare(b.date));
}

// Session token key must match AuthContext
const SESSION_TOKEN_KEY = 'auth_session_token';

function getSessionToken(): string | null {
  return localStorage.getItem(SESSION_TOKEN_KEY);
}

// Helper to call the product-analytics-aggregate edge function
async function callProductAnalyticsAggregate(type: 'trends' | 'stats', dateRange: DateRange, meetingContext?: string) {
  const sessionToken = getSessionToken();
  if (!sessionToken) throw new Error('Not authenticated');

  const { data, error } = await supabase.functions.invoke('product-analytics-aggregate', {
    body: {
      type,
      from: startOfDay(dateRange.from).toISOString(),
      to: endOfDay(dateRange.to).toISOString(),
      meetingContext: meetingContext || null,
    },
    headers: {
      'x-session-token': sessionToken,
    },
  });

  if (error) throw new Error(error.message || 'Failed to fetch product analytics');
  if (data?.error) throw new Error(data.error);
  return data?.data;
}

// Fetch all product mentions within a date range (still uses gateway for detail views)
export function useProductMentions(dateRange: DateRange) {
  return useQuery({
    queryKey: ['product-mentions', dateRange.from.toISOString(), dateRange.to.toISOString()],
    queryFn: async () => {
      const response = await gateway.from('product_mentions')
        .select(`
          *,
          accounts(name),
          transcript_reviews(meeting_title)
        `)
        .gte('transcript_date', startOfDay(dateRange.from).toISOString())
        .lte('transcript_date', endOfDay(dateRange.to).toISOString())
        .order('transcript_date', { ascending: false })
        .limit(500)
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as ProductMentionWithDetails[];
    },
  });
}

// Aggregate mentions by product - now uses server-side aggregation
export function useProductMentionStats(dateRange: DateRange, meetingContext?: string) {
  return useQuery({
    queryKey: ['product-mention-stats', dateRange.from.toISOString(), dateRange.to.toISOString(), meetingContext],
    queryFn: async () => {
      const rows = await callProductAnalyticsAggregate('stats', dateRange, meetingContext);
      if (!rows) return [];

      return (rows as any[]).map((row) => ({
        product_name: row.product_name,
        mention_type: row.mention_type as 'owned' | 'complementary' | 'competitive',
        total_mentions: Number(row.total_mentions),
        avg_sentiment: row.avg_sentiment != null ? Number(row.avg_sentiment) : null,
        positive_count: Number(row.positive_count || 0),
        neutral_count: Number(row.neutral_count || 0),
        negative_count: Number(row.negative_count || 0),
        mixed_count: Number(row.mixed_count || 0),
      })) as ProductStats[];
    },
  });
}

// Get mention trends over time - now uses server-side aggregation
export function useProductMentionTrends(dateRange: DateRange, meetingContext?: string) {
  return useQuery({
    queryKey: ['product-mention-trends', dateRange.from.toISOString(), dateRange.to.toISOString(), meetingContext],
    queryFn: async () => {
      const rows = await callProductAnalyticsAggregate('trends', dateRange, meetingContext);
      if (!rows) return [];

      // Pivot from (date, mention_type, count) to { date, owned, complementary, competitive, total }
      const trendsMap = new Map<string, MentionTrend>();

      (rows as any[]).forEach((row: any) => {
        const date = row.mention_date;
        const existing = trendsMap.get(date);
        const count = Number(row.total_count || 0);

        if (existing) {
          existing.total += count;
          if (row.mention_type === 'owned') existing.owned += count;
          else if (row.mention_type === 'complementary') existing.complementary += count;
          else if (row.mention_type === 'competitive') existing.competitive += count;
        } else {
          trendsMap.set(date, {
            date,
            owned: row.mention_type === 'owned' ? count : 0,
            complementary: row.mention_type === 'complementary' ? count : 0,
            competitive: row.mention_type === 'competitive' ? count : 0,
            total: count,
          });
        }
      });

      // Fill in missing dates
      const result: MentionTrend[] = [];
      let currentDate = new Date(dateRange.from);
      while (currentDate <= dateRange.to) {
        const dateStr = format(currentDate, 'yyyy-MM-dd');
        result.push(trendsMap.get(dateStr) || {
          date: dateStr,
          owned: 0,
          complementary: 0,
          competitive: 0,
          total: 0,
        });
        currentDate = new Date(currentDate.getTime() + 24 * 60 * 60 * 1000);
      }

      return result;
    },
  });
}
// Daily call volume from momentum_meetings via RPC
export function useCallVolumeTrends(dateRange: DateRange, meetingContext?: string) {
  return useQuery({
    queryKey: ['call-volume-trends', dateRange.from.toISOString(), dateRange.to.toISOString(), meetingContext],
    queryFn: async () => {
      const { data, error } = await supabase.rpc('get_daily_call_counts', {
        p_from: startOfDay(dateRange.from).toISOString(),
        p_to: endOfDay(dateRange.to).toISOString(),
        p_meeting_context: meetingContext || null,
      });
      if (error) throw new Error(error.message);
      return (data as any[] || []).map((row: any) => ({
        date: row.call_date,
        count: Number(row.call_count),
      }));
    },
  });
}


export function useSelectedProductTrends(productName: string | null, dateRange: DateRange) {
  return useQuery({
    queryKey: ['product-trends-single', productName, dateRange.from.toISOString(), dateRange.to.toISOString()],
    queryFn: async () => {
      if (!productName) return [];

      // Look up technology_id from detection rules
      const ruleRes = await gateway.from('detection_rules')
        .select('technology_id')
        .eq('name', productName)
        .in('tree_id', [
          'b0000001-0001-4000-8000-000000000001',
          'c0000001-0001-4000-8000-000000000001',
        ])
        .eq('is_active', true)
        .not('technology_id', 'is', null)
        .limit(1)
        .execute();

      const technologyId = ruleRes.data?.[0]?.technology_id;
      if (!technologyId) return [];

      const response = await gateway.from('product_mentions')
        .select('transcript_date, mention_count')
        .eq('technology_id', technologyId)
        .gte('transcript_date', startOfDay(dateRange.from).toISOString())
        .lte('transcript_date', endOfDay(dateRange.to).toISOString())
        .order('transcript_date', { ascending: true })
        .limit(5000)
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));

      // Aggregate by date
      const byDate = new Map<string, number>();
      for (const row of (response.data || []) as any[]) {
        if (!row.transcript_date) continue;
        const dateStr = format(new Date(row.transcript_date), 'yyyy-MM-dd');
        byDate.set(dateStr, (byDate.get(dateStr) || 0) + (row.mention_count || 1));
      }

      // Fill all dates in range
      const result: { date: string; count: number }[] = [];
      let currentDate = new Date(dateRange.from);
      while (currentDate <= dateRange.to) {
        const dateStr = format(currentDate, 'yyyy-MM-dd');
        result.push({ date: dateStr, count: byDate.get(dateStr) || 0 });
        currentDate = new Date(currentDate.getTime() + 24 * 60 * 60 * 1000);
      }
      return result;
    },
    enabled: !!productName,
  });
}

// Group single-product daily trend into period buckets
export function groupSingleProductTrends(
  data: { date: string; count: number }[],
  period: PeriodGrouping
): { date: string; count: number }[] {
  if (period === 'daily') return data;
  const bucketMap = new Map<string, number>();
  for (const d of data) {
    const dt = new Date(d.date);
    let key: string;
    if (period === 'weekly') {
      key = format(startOfWeek(dt, { weekStartsOn: 1 }), 'yyyy-MM-dd');
    } else {
      key = format(startOfMonth(dt), 'yyyy-MM-dd');
    }
    bucketMap.set(key, (bucketMap.get(key) || 0) + d.count);
  }
  return Array.from(bucketMap.entries())
    .map(([date, count]) => ({ date, count }))
    .sort((a, b) => a.date.localeCompare(b.date));
}

// Get Pendo products from technology_repository (is_customer = true)
export function usePendoProducts() {
  return useQuery({
    queryKey: ['pendo-products'],
    queryFn: async () => {
      const response = await gateway.from('technology_repository')
        .select('id, name, functional_area, description')
        .eq('is_customer', true)
        .order('name')
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data;
    },
  });
}

// Get top mentioned products with context snippets
export function useTopProductMentions(dateRange: DateRange, mentionType?: 'owned' | 'complementary' | 'competitive', limit = 10) {
  return useQuery({
    queryKey: ['top-product-mentions', dateRange.from.toISOString(), dateRange.to.toISOString(), mentionType, limit],
    queryFn: async () => {
      let query = gateway.from('product_mentions')
        .select(`
          id,
          product_name,
          mention_type,
          context_snippet,
          sentiment_label,
          transcript_date,
          transcript_id,
          account_id,
          accounts(name),
          transcript_reviews(id, meeting_title, final_account_id)
        `)
        .gte('transcript_date', startOfDay(dateRange.from).toISOString())
        .lte('transcript_date', endOfDay(dateRange.to).toISOString())
        .order('transcript_date', { ascending: false })
        .limit(limit * 5); // Get more to filter

      if (mentionType) {
        query = query.eq('mention_type', mentionType);
      }

      const response = await query.execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data;
    },
  });
}

// Fetch suppressed product mentions
export function useSuppressedProductMentions() {
  return useQuery({
    queryKey: ['suppressed-product-mentions'],
    queryFn: async () => {
      const response = await gateway.from('suppressed_product_mentions')
        .select('*')
        .order('created_at', { ascending: false })
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as Array<{
        id: string;
        product_name: string;
        mention_type: string | null;
        reason: string | null;
        created_at: string;
      }>;
    },
  });
}

// Suppress a product mention
export function useSuppressProductMention() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: { productName: string; mentionType?: string; reason?: string }) => {
      const response = await gateway.from('suppressed_product_mentions')
        .insert({
          product_name: params.productName,
          mention_type: params.mentionType || null,
          reason: params.reason || null,
        })
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data;
    },
    onSuccess: () => {
      // Invalidate all product mention queries
      queryClient.invalidateQueries({ queryKey: ['product-mention-stats'] });
      queryClient.invalidateQueries({ queryKey: ['product-mention-trends'] });
      queryClient.invalidateQueries({ queryKey: ['suppressed-product-mentions'] });
    },
  });
}

// Unsuppress a product mention
export function useUnsuppressProductMention() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const response = await gateway.from('suppressed_product_mentions')
        .delete()
        .eq('id', id)
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['product-mention-stats'] });
      queryClient.invalidateQueries({ queryKey: ['product-mention-trends'] });
      queryClient.invalidateQueries({ queryKey: ['suppressed-product-mentions'] });
    },
  });
}

// Previous period stats for comparison
export function usePreviousPeriodStats(dateRange: DateRange, meetingContext?: string) {
  const days = differenceInDays(dateRange.to, dateRange.from);
  const prevRange: DateRange = {
    from: subDays(dateRange.from, days),
    to: subDays(dateRange.from, 1),
  };

  return useQuery({
    queryKey: ['product-mention-stats-prev', prevRange.from.toISOString(), prevRange.to.toISOString(), meetingContext],
    queryFn: async () => {
      const rows = await callProductAnalyticsAggregate('stats', prevRange, meetingContext);
      if (!rows) return { owned: 0, competitive: 0, total: 0 };

      let owned = 0;
      let competitive = 0;
      (rows as any[]).forEach((row) => {
        const count = Number(row.total_mentions || 0);
        if (row.mention_type === 'owned') owned += count;
        else if (row.mention_type === 'competitive') competitive += count;
      });

      return { owned, competitive, total: owned + competitive };
    },
  });
}

// Product excerpts for the product detail panel
// Looks up technology_id from detection_rules by canonical name, then queries by technology_id
export function useProductExcerpts(productName: string, dateRange: DateRange) {
  return useQuery({
    queryKey: ['product-excerpts', productName, dateRange.from.toISOString(), dateRange.to.toISOString()],
    queryFn: async () => {
      // First, find the technology_id for this canonical detection rule name
      const ruleRes = await gateway.from('detection_rules')
        .select('technology_id')
        .eq('name', productName)
        .in('tree_id', [
          'b0000001-0001-4000-8000-000000000001',
          'c0000001-0001-4000-8000-000000000001',
        ])
        .eq('is_active', true)
        .not('technology_id', 'is', null)
        .limit(1)
        .execute();

      const technologyId = ruleRes.data?.[0]?.technology_id;

      let query = gateway.from('product_mentions')
        .select(`
          id,
          product_name,
          context_snippet,
          sentiment_label,
          mention_count,
          transcript_date,
          transcript_id,
          account_id,
          accounts(name)
        `)
        .gte('transcript_date', startOfDay(dateRange.from).toISOString())
        .lte('transcript_date', endOfDay(dateRange.to).toISOString())
        .order('transcript_date', { ascending: false })
        .limit(100);

      // Prefer technology_id match; fall back to product_name for unlinked data
      if (technologyId) {
        query = query.eq('technology_id', technologyId);
      } else {
        query = query.eq('product_name', productName);
      }

      const response = await query.execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []).map((row: any) => ({
        id: row.id,
        product_name: row.product_name,
        context_snippet: row.context_snippet,
        sentiment_label: row.sentiment_label,
        mention_count: row.mention_count || 1,
        transcript_date: row.transcript_date,
        transcript_id: row.transcript_id,
        account_id: row.account_id,
        account_name: row.accounts?.name || null,
      })) as SentimentExcerpt[];
    },
    enabled: !!productName,
  });
}

// Sentiment excerpts for the detail panel
export function useSentimentExcerpts(sentimentLabel: string, dateRange: DateRange) {
  return useQuery({
    queryKey: ['sentiment-excerpts', sentimentLabel, dateRange.from.toISOString(), dateRange.to.toISOString()],
    queryFn: async () => {
      const response = await gateway.from('product_mentions')
        .select(`
          id,
          product_name,
          context_snippet,
          sentiment_label,
          transcript_date,
          transcript_id,
          account_id,
          accounts(name)
        `)
        .eq('sentiment_label', sentimentLabel)
        .gte('transcript_date', startOfDay(dateRange.from).toISOString())
        .lte('transcript_date', endOfDay(dateRange.to).toISOString())
        .not('context_snippet', 'is', null)
        .order('transcript_date', { ascending: false })
        .limit(50)
        .execute();

      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []).map((row: any) => ({
        id: row.id,
        product_name: row.product_name,
        context_snippet: row.context_snippet,
        sentiment_label: row.sentiment_label,
        transcript_date: row.transcript_date,
        transcript_id: row.transcript_id,
        account_id: row.account_id,
        account_name: row.accounts?.name || null,
      })) as SentimentExcerpt[];
    },
    enabled: !!sentimentLabel,
  });
}

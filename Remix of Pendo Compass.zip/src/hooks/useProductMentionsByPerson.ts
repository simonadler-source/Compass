import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { startOfDay, endOfDay, format, eachWeekOfInterval, eachMonthOfInterval, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from 'date-fns';
import type { DateRange } from './useProductMentions';

// The tree ID for Pendo Products Detection rules
const PENDO_PRODUCTS_TREE_ID = 'b0000001-0001-4000-8000-000000000001';

export interface PersonProductMention {
  personEmail: string;
  personName: string;
  isInternal: boolean;
  managerId: string | null;
  managerEmail: string | null;
  managerName: string | null;
  products: {
    productName: string;
    ruleId: string;
    mentionCount: number;
    lastMentionedAt: string | null;
    confidenceSum: number;
    interestLevels: { high: number; medium: number; low: number };
  }[];
  totalMentions: number;
  uniqueProducts: number;
  avgConfidence: number;
  enablementScore: number; // Composite score: breadth × frequency × confidence
  mentionsByPeriod: Record<string, number>; // For timeline visualization
}

export interface TeamNode {
  id: string;
  email: string;
  name: string;
  directReports: TeamNode[];
  personData: PersonProductMention | null;
  teamTotalMentions: number;
  teamAvgEnablement: number;
}

export interface ProductMentionsByPersonResult {
  persons: PersonProductMention[];
  teamHierarchy: TeamNode[];
  products: string[];
  periodLabels: string[];
  teamAverageEnablement: number;
}

export function useProductMentionsByPerson(dateRange: DateRange, granularity: 'week' | 'month' = 'week') {
  return useQuery({
    queryKey: ['product-mentions-by-person', dateRange.from.toISOString(), dateRange.to.toISOString(), granularity],
    queryFn: async (): Promise<ProductMentionsByPersonResult> => {
      // Fetch all required data in parallel
      const [rulesResponse, hierarchyResponse, profilesResponse, teamMembersResponse] = await Promise.all([
        gateway.from('detection_rules')
          .select('id, name')
          .eq('tree_id', PENDO_PRODUCTS_TREE_ID)
          .eq('is_active', true)
          .execute(),
        gateway.from('team_hierarchy')
          .select('manager_id, report_id')
          .execute(),
        gateway.from('profiles')
          .select('id, email, full_name')
          .execute(),
        gateway.from('team_members')
          .select('id, member_email, member_name')
          .execute(),
      ]);

      if (rulesResponse.error) throw new Error(getErrorMessage(rulesResponse.error));
      const rules = rulesResponse.data || [];
      
      if (rules.length === 0) {
        return { persons: [], teamHierarchy: [], products: [], periodLabels: [], teamAverageEnablement: 0 };
      }

      const ruleIds = rules.map((r: any) => r.id as string);
      const ruleNameMap = new Map<string, string>(rules.map((r: any) => [r.id as string, r.name as string]));
      const productNames = Array.from(new Set(rules.map((r: any) => r.name as string))).sort();

      // Build profile maps
      const profiles = profilesResponse.data || [];
      const emailToProfile = new Map<string, { id: string; name: string }>();
      const idToProfile = new Map<string, { email: string; name: string }>();
      profiles.forEach((p: any) => {
        if (p.email) {
          emailToProfile.set(p.email.toLowerCase(), { id: p.id, name: p.full_name || p.email });
          idToProfile.set(p.id, { email: p.email.toLowerCase(), name: p.full_name || p.email });
        }
      });

      // Build team members map
      const teamMembers = teamMembersResponse.data || [];
      const teamMemberEmails = new Set(teamMembers.map((t: any) => t.member_email?.toLowerCase()).filter(Boolean));

      // Build hierarchy maps
      const hierarchyData = hierarchyResponse.data || [];
      const reportToManager = new Map<string, string>();
      const managerToReports = new Map<string, Set<string>>();
      hierarchyData.forEach((h: any) => {
        reportToManager.set(h.report_id, h.manager_id);
        if (!managerToReports.has(h.manager_id)) {
          managerToReports.set(h.manager_id, new Set());
        }
        managerToReports.get(h.manager_id)!.add(h.report_id);
      });

      // Fetch matches with speaker info
      const matchesResponse = await gateway.from('detection_rule_matches')
        .select(`
          id,
          rule_id,
          transcript_id,
          confidence_score,
          occurrence_count,
          first_detected_at,
          speaker_type,
          speaker_name,
          speaker_email,
          transcript_reviews!inner(created_at)
        `)
        .in('rule_id', ruleIds)
        .gte('transcript_reviews.created_at', startOfDay(dateRange.from).toISOString())
        .lte('transcript_reviews.created_at', endOfDay(dateRange.to).toISOString())
        .execute();

      if (matchesResponse.error) throw new Error(getErrorMessage(matchesResponse.error));
      const matches = matchesResponse.data || [];

      // Get captured insights for interest levels
      const matchIds = matches.map(m => m.id);
      let capturedInsights: any[] = [];
      
      if (matchIds.length > 0) {
        const insightsResponse = await gateway.from('account_captured_insights')
          .select('rule_match_id, value, value_json, detection_rule_capture_fields(field_name)')
          .in('rule_match_id', matchIds)
          .execute();
        
        if (!insightsResponse.error) {
          capturedInsights = insightsResponse.data || [];
        }
      }

      // Build insights map
      const insightsMap = new Map<string, Record<string, any>>();
      capturedInsights.forEach((insight: any) => {
        if (!insight.rule_match_id) return;
        const fieldName = insight.detection_rule_capture_fields?.field_name;
        if (!fieldName) return;
        
        const existing = insightsMap.get(insight.rule_match_id) || {};
        existing[fieldName] = insight.value_json || insight.value;
        insightsMap.set(insight.rule_match_id, existing);
      });

      // Calculate period labels
      const periodLabels: string[] = [];
      const periods = granularity === 'week' 
        ? eachWeekOfInterval({ start: dateRange.from, end: dateRange.to })
        : eachMonthOfInterval({ start: dateRange.from, end: dateRange.to });
      
      periods.forEach(periodStart => {
        const label = granularity === 'week'
          ? format(periodStart, 'MMM d')
          : format(periodStart, 'MMM yyyy');
        periodLabels.push(label);
      });

      // Aggregate by person
      const personMap = new Map<string, {
        email: string;
        name: string;
        isInternal: boolean;
        products: Map<string, {
          ruleId: string;
          mentionCount: number;
          lastMentionedAt: string | null;
          confidenceSum: number;
          interestLevels: { high: number; medium: number; low: number };
        }>;
        mentionsByPeriod: Map<string, number>;
      }>();

      matches.forEach((match: any) => {
        const speakerEmail = (match.speaker_email || '').toLowerCase();
        const speakerName = match.speaker_name || speakerEmail || 'Unknown';
        const isInternal = teamMemberEmails.has(speakerEmail) || match.speaker_type === 'internal';
        
        if (!speakerEmail && !speakerName) return; // Skip if no speaker info
        
        const personKey = speakerEmail || speakerName.toLowerCase();
        
        if (!personMap.has(personKey)) {
          personMap.set(personKey, {
            email: speakerEmail,
            name: speakerName,
            isInternal,
            products: new Map(),
            mentionsByPeriod: new Map(),
          });
        }
        
        const person = personMap.get(personKey)!;
        const productName = ruleNameMap.get(match.rule_id) || 'Unknown';
        const insights = insightsMap.get(match.id) || {};
        const interestLevel = (insights.interest_level || '').toLowerCase();
        
        // Update product stats
        if (!person.products.has(productName)) {
          person.products.set(productName, {
            ruleId: match.rule_id,
            mentionCount: 0,
            lastMentionedAt: null,
            confidenceSum: 0,
            interestLevels: { high: 0, medium: 0, low: 0 },
          });
        }
        
        const productStats = person.products.get(productName)!;
        productStats.mentionCount += match.occurrence_count || 1;
        productStats.confidenceSum += match.confidence_score || 0;
        
        if (match.first_detected_at && (!productStats.lastMentionedAt || match.first_detected_at > productStats.lastMentionedAt)) {
          productStats.lastMentionedAt = match.first_detected_at;
        }
        
        if (interestLevel === 'high') productStats.interestLevels.high++;
        else if (interestLevel === 'medium') productStats.interestLevels.medium++;
        else if (interestLevel === 'low') productStats.interestLevels.low++;
        
        // Update period stats
        const matchDate = new Date(match.transcript_reviews?.created_at || match.first_detected_at);
        const periodStart = granularity === 'week'
          ? startOfWeek(matchDate)
          : startOfMonth(matchDate);
        const periodLabel = granularity === 'week'
          ? format(periodStart, 'MMM d')
          : format(periodStart, 'MMM yyyy');
        
        const currentCount = person.mentionsByPeriod.get(periodLabel) || 0;
        person.mentionsByPeriod.set(periodLabel, currentCount + (match.occurrence_count || 1));
      });

      // Calculate enablement scores and build final person list
      const persons: PersonProductMention[] = [];
      
      personMap.forEach((data, key) => {
        const products = Array.from(data.products.entries()).map(([name, stats]) => ({
          productName: name,
          ruleId: stats.ruleId,
          mentionCount: stats.mentionCount,
          lastMentionedAt: stats.lastMentionedAt,
          confidenceSum: stats.confidenceSum,
          interestLevels: stats.interestLevels,
        }));
        
        const totalMentions = products.reduce((sum, p) => sum + p.mentionCount, 0);
        const uniqueProducts = products.length;
        const avgConfidence = totalMentions > 0
          ? products.reduce((sum, p) => sum + p.confidenceSum, 0) / totalMentions
          : 0;
        
        // Enablement score: breadth (unique products / total products) × frequency × avg confidence
        const breadthScore = productNames.length > 0 ? uniqueProducts / productNames.length : 0;
        const frequencyScore = Math.min(totalMentions / 10, 1); // Cap at 10 mentions = 100%
        const confidenceScore = avgConfidence / 100;
        const enablementScore = Math.round((breadthScore * 0.4 + frequencyScore * 0.35 + confidenceScore * 0.25) * 100);
        
        // Get manager info
        const profile = emailToProfile.get(data.email);
        const managerId = profile ? reportToManager.get(profile.id) || null : null;
        const managerProfile = managerId ? idToProfile.get(managerId) : null;
        
        // Convert mentionsByPeriod to object with all period labels
        const mentionsByPeriod: Record<string, number> = {};
        periodLabels.forEach(label => {
          mentionsByPeriod[label] = data.mentionsByPeriod.get(label) || 0;
        });
        
        persons.push({
          personEmail: data.email,
          personName: data.name,
          isInternal: data.isInternal,
          managerId,
          managerEmail: managerProfile?.email || null,
          managerName: managerProfile?.name || null,
          products,
          totalMentions,
          uniqueProducts,
          avgConfidence,
          enablementScore,
          mentionsByPeriod,
        });
      });

      // Sort by enablement score descending
      persons.sort((a, b) => b.enablementScore - a.enablementScore);

      // Build team hierarchy (only internal users)
      const buildTeamNode = (userId: string): TeamNode | null => {
        const profile = idToProfile.get(userId);
        if (!profile) return null;
        
        const personData = persons.find(p => p.personEmail === profile.email) || null;
        const directReportIds = managerToReports.get(userId) || new Set();
        const directReports = Array.from(directReportIds)
          .map(id => typeof id === 'string' ? buildTeamNode(id) : null)
          .filter((n): n is TeamNode => n !== null);
        
        // Calculate team totals
        const teamMembers = [personData, ...directReports.flatMap(r => getAllPersonData(r))].filter(Boolean);
        const teamTotalMentions = teamMembers.reduce((sum, p) => sum + (p?.totalMentions || 0), 0);
        const teamAvgEnablement = teamMembers.length > 0
          ? Math.round(teamMembers.reduce((sum, p) => sum + (p?.enablementScore || 0), 0) / teamMembers.length)
          : 0;
        
        return {
          id: userId,
          email: profile.email,
          name: profile.name,
          directReports,
          personData,
          teamTotalMentions,
          teamAvgEnablement,
        };
      };
      
      const getAllPersonData = (node: TeamNode): (PersonProductMention | null)[] => {
        return [node.personData, ...node.directReports.flatMap(r => getAllPersonData(r))];
      };
      
      // Find root managers (users with no manager)
      const allReportIds = new Set(hierarchyData.map((h: any) => h.report_id as string));
      const rootManagerIds = [...new Set(hierarchyData.map((h: any) => h.manager_id as string))]
        .filter((id): id is string => typeof id === 'string' && !allReportIds.has(id));
      
      const teamHierarchy = rootManagerIds
        .map(id => buildTeamNode(id))
        .filter((n): n is TeamNode => n !== null);
      
      // Calculate team average
      const internalPersons = persons.filter(p => p.isInternal);
      const teamAverageEnablement = internalPersons.length > 0
        ? Math.round(internalPersons.reduce((sum, p) => sum + p.enablementScore, 0) / internalPersons.length)
        : 0;

      return {
        persons,
        teamHierarchy,
        products: productNames as string[],
        periodLabels,
        teamAverageEnablement,
      };
    },
  });
}

import { useState, useEffect, useCallback, useRef } from 'react';

export interface RecentItem {
  id: string;
  type: 'account' | 'opportunity';
  name: string;
  path: string;
  viewedAt: number;
}

const STORAGE_KEY = 'compass-recent-items';
const MAX_ITEMS = 10;

function loadFromStorage(): RecentItem[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored) as RecentItem[];
      // Filter out items older than 7 days
      const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
      return parsed.filter(item => item.viewedAt > sevenDaysAgo);
    }
  } catch (e) {
    console.error('Failed to load recent items:', e);
  }
  return [];
}

function saveToStorage(items: RecentItem[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch (e) {
    console.error('Failed to save recent items:', e);
  }
}

export function useRecentItems() {
  // Initialize with localStorage value synchronously
  const [recentItems, setRecentItems] = useState<RecentItem[]>(() => loadFromStorage());
  const isInitialized = useRef(false);

  // Only save after initial load
  useEffect(() => {
    if (isInitialized.current) {
      saveToStorage(recentItems);
    } else {
      isInitialized.current = true;
    }
  }, [recentItems]);

  const addRecentItem = useCallback((item: Omit<RecentItem, 'viewedAt'>) => {
    setRecentItems(prev => {
      // Remove existing entry for this item if present
      const filtered = prev.filter(
        existing => !(existing.id === item.id && existing.type === item.type)
      );
      
      // Add new item at the beginning
      const newItem: RecentItem = {
        ...item,
        viewedAt: Date.now(),
      };
      
      // Keep only MAX_ITEMS
      return [newItem, ...filtered].slice(0, MAX_ITEMS);
    });
  }, []);

  const clearRecentItems = useCallback(() => {
    setRecentItems([]);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  return {
    recentItems,
    addRecentItem,
    clearRecentItems,
  };
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface ReferenceTechnology {
  id: string; name: string; category: string; layer: string;
  description: string | null; integration_type: string | null;
  created_at: string; updated_at: string;
}

export function useReferenceTechnologies() {
  return useQuery({
    queryKey: ['reference-technologies'],
    queryFn: async () => {
      const { data, error } = await gateway.from('reference_technologies').select('*').order('layer').order('integration_type').order('name').execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as ReferenceTechnology[];
    },
  });
}

export function useCreateReferenceTechnology() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (tech: Omit<ReferenceTechnology, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await gateway.from('reference_technologies').insert(tech).single().execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['reference-technologies'] }); toast.success('Technology added to reference architecture'); },
    onError: (error) => { toast.error('Failed to add technology: ' + error.message); },
  });
}

export function useUpdateReferenceTechnology() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<ReferenceTechnology> & { id: string }) => {
      const { data, error } = await gateway.from('reference_technologies').update(updates).eq('id', id).single().execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['reference-technologies'] }); },
    onError: (error) => { toast.error('Failed to update technology: ' + error.message); },
  });
}

export function useDeleteReferenceTechnology() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway.from('reference_technologies').delete().eq('id', id).execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['reference-technologies'] }); toast.success('Technology removed from reference architecture'); },
    onError: (error) => { toast.error('Failed to delete technology: ' + error.message); },
  });
}

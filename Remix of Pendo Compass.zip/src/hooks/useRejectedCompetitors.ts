import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface RejectedCompetitorMention {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  competitor_name: string;
  transcript_id: string | null;
  rejected_at: string;
  rejected_by: string | null;
}

/**
 * Fetches all rejected competitor mentions for an opportunity.
 */
export function useRejectedCompetitors(opportunityId?: string | null, accountId?: string | null) {
  return useQuery({
    queryKey: ['rejected-competitors', opportunityId ?? `account-${accountId}`],
    queryFn: async () => {
      let query = gateway
        .from('rejected_competitor_mentions')
        .select('*');
      
      if (opportunityId) {
        query = query.eq('opportunity_id', opportunityId);
      } else if (accountId) {
        query = query.eq('account_id', accountId).is('opportunity_id', null);
      }
      
      const result = await query.execute();
      if (result.error) throw new Error(result.error.message);
      return (result.data || []) as RejectedCompetitorMention[];
    },
    enabled: !!(opportunityId || accountId),
  });
}

/**
 * Rejects a competitor mention from the insights.
 */
export function useRejectCompetitor() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({
      accountId,
      opportunityId,
      competitorName,
      transcriptId,
    }: {
      accountId: string;
      opportunityId?: string | null;
      competitorName: string;
      transcriptId?: string | null;
    }) => {
      const result = await gateway
        .from('rejected_competitor_mentions')
        .insert({
          account_id: accountId,
          opportunity_id: opportunityId || null,
          competitor_name: competitorName,
          transcript_id: transcriptId || null,
        })
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data;
    },
    onSuccess: (_, variables) => {
      const key = variables.opportunityId ?? `account-${variables.accountId}`;
      queryClient.invalidateQueries({ queryKey: ['rejected-competitors', key] });
      if (variables.opportunityId) {
        queryClient.invalidateQueries({ queryKey: ['opportunity-transcript-insights', variables.opportunityId] });
      }
      queryClient.invalidateQueries({ queryKey: ['account-manual-competitors', variables.accountId] });
      toast.success(`Rejected "${variables.competitorName}" from insights`);
    },
    onError: (error) => {
      toast.error('Failed to reject competitor: ' + (error as Error).message);
    },
  });
}

/**
 * Unrejects a competitor, allowing it to appear again.
 */
export function useUnrejectCompetitor() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({
      opportunityId,
      rejectionId,
    }: {
      opportunityId: string;
      rejectionId: string;
    }) => {
      const result = await gateway
        .from('rejected_competitor_mentions')
        .delete()
        .eq('id', rejectionId)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['rejected-competitors', variables.opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['opportunity-transcript-insights', variables.opportunityId] });
      toast.success('Competitor restored');
    },
    onError: (error) => {
      toast.error('Failed to restore competitor: ' + (error as Error).message);
    },
  });
}

/**
 * Check if a competitor is rejected for this opportunity.
 */
export function isCompetitorRejected(
  rejections: RejectedCompetitorMention[],
  competitorName: string
): boolean {
  return rejections.some(r => 
    r.competitor_name?.toLowerCase() === competitorName?.toLowerCase()
  );
}

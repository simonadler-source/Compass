import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface RejectedTechnologyDetection {
  id: string;
  account_id: string;
  transcript_id: string;
  repository_tech_id: string | null;
  detected_name: string | null;
  rejected_at: string;
  rejected_by: string | null;
}

/**
 * Fetches all rejected technology detections for an account.
 * These are per-transcript rejections that prevent specific techs from being suggested
 * when re-analyzing that particular transcript.
 */
export function useRejectedTechnologyDetections(accountId: string) {
  return useQuery({
    queryKey: ['rejected-technology-detections', accountId],
    queryFn: async () => {
      const result = await gateway
        .from('rejected_technology_detections')
        .select('*')
        .eq('account_id', accountId)
        .execute();
      if (result.error) throw new Error(result.error.message);
      return (result.data || []) as RejectedTechnologyDetection[];
    },
    enabled: !!accountId,
  });
}

/**
 * Rejects a technology suggestion for a specific transcript.
 * This prevents the tech from being suggested again when re-analyzing that transcript.
 */
export function useRejectTechnologyDetection() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({
      accountId,
      transcriptId,
      repositoryTechId,
      detectedName,
    }: {
      accountId: string;
      transcriptId: string;
      repositoryTechId?: string | null;
      detectedName: string;
    }) => {
      const result = await gateway
        .from('rejected_technology_detections')
        .insert({
          account_id: accountId,
          transcript_id: transcriptId,
          repository_tech_id: repositoryTechId || null,
          detected_name: detectedName,
        })
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['rejected-technology-detections', variables.accountId] });
      toast.success(`Rejected "${variables.detectedName}" from this transcript`);
    },
    onError: (error) => {
      toast.error('Failed to reject technology: ' + (error as Error).message);
    },
  });
}

/**
 * Removes a rejection, allowing the technology to be suggested again.
 */
export function useUnrejectTechnologyDetection() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({
      accountId,
      rejectionId,
    }: {
      accountId: string;
      rejectionId: string;
    }) => {
      const result = await gateway
        .from('rejected_technology_detections')
        .delete()
        .eq('id', rejectionId)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['rejected-technology-detections', variables.accountId] });
      toast.success('Technology rejection removed');
    },
    onError: (error) => {
      toast.error('Failed to remove rejection: ' + (error as Error).message);
    },
  });
}

/**
 * Check if a technology is rejected for a specific transcript.
 */
export function isTechRejectedForTranscript(
  rejections: RejectedTechnologyDetection[],
  transcriptId: string,
  repositoryTechId: string | null,
  detectedName: string
): boolean {
  return rejections.some(r => 
    r.transcript_id === transcriptId && (
      (repositoryTechId && r.repository_tech_id === repositoryTechId) ||
      (!repositoryTechId && r.detected_name?.toLowerCase() === detectedName.toLowerCase())
    )
  );
}

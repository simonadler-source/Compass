import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { from, deleteFrom } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface SECoachingScore {
  id: string;
  transcript_id: string;
  opportunity_id: string | null;
  account_id: string | null;
  se_email: string;
  meeting_type: string;
  se_talk_ratio: number | null;
  target_talk_ratio_min: number | null;
  target_talk_ratio_max: number | null;
  talk_ratio_score: number | null;
  avg_words_per_minute: number | null;
  pause_for_impact_count: number;
  rushed_speech_detected: boolean;
  prospect_sentiment: string | null;
  pov_challenge_score: number | null;
  pov_challenge_evidence: string | null;
  ownership_control_score: number | null;
  ownership_control_evidence: string | null;
  storytelling_proof_score: number | null;
  storytelling_proof_evidence: string | null;
  reverse_demo_score: number | null;
  reverse_demo_evidence: string | null;
  champion_arming_score: number | null;
  champion_arming_evidence: string | null;
  objection_handling_score: number | null;
  objection_handling_evidence: string | null;
  pain_quantification_score: number | null;
  pain_quantification_evidence: string | null;
  questioning_score: number | null;
  questioning_evidence: string | null;
  differentiation_score: number | null;
  differentiation_evidence: string | null;
  strategy_rigor_score: number | null;
  strategy_rigor_evidence: string | null;
  technical_competency_score: number | null;
  technical_competency_evidence: string | null;
  value_anchoring_score: number | null;
  value_anchoring_evidence: string | null;
  energy_inspiration_score: number | null;
  energy_inspiration_evidence: string | null;
  energy_delivery_breakdown: {
    pitch_variation_score: number;
    pitch_variation_evidence: string;
    value_word_emphasis_score: number;
    value_word_emphasis_evidence: string;
    pace_variation_score: number;
    pace_variation_evidence: string;
    vocal_warmth_score: number;
    vocal_warmth_evidence: string;
    verbal_highlighters_score: number;
    verbal_highlighters_evidence: string;
  } | null;
  weights_used: Record<string, number>;
  overall_score: number | null;
  greatness_moment: string | null;
  opportunity_gap: string | null;
  improvement_example: string | null;
  actionable_next_step: string | null;
  what_worked_well: Array<{ snippet: string; explanation: string }> | null;
  what_didnt_work: Array<{ snippet: string; explanation: string }> | null;
  coaching_guidance: Array<{ pattern_observed: string; technique: string; expected_impact: string }> | null;
  analysis_model: string | null;
  analyzed_at: string;
  created_at: string;
  // Enriched client-side
  opportunity_name?: string | null;
  meeting_date?: string | null;
}

// Fetch coaching score for a specific transcript
export function useTranscriptCoachingScore(transcriptId: string | null) {
  return useQuery({
    queryKey: ['se-coaching-score', transcriptId],
    queryFn: async () => {
      if (!transcriptId) return null;
      const result = await from<SECoachingScore>('se_coaching_scores')
        .select('*')
        .eq('transcript_id', transcriptId)
        .limit(1)
        .execute();
      return result.data?.[0] || null;
    },
    enabled: !!transcriptId,
  });
}

// Fetch all coaching scores for a team (for manager dashboard)
export function useTeamCoachingScores(seEmails: string[], days: number = 90) {
  return useQuery({
    queryKey: ['se-coaching-scores-team', seEmails, days],
    queryFn: async () => {
      if (!seEmails.length) return [];
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - days);
      
      const result = await from<SECoachingScore>('se_coaching_scores')
        .select('*')
        .in('se_email', seEmails)
        .gte('analyzed_at', cutoff.toISOString())
        .order('analyzed_at', { ascending: false })
        .limit(500)
        .execute();
      const scores = (result.data || []) as SECoachingScore[];

      // Enrich with opportunity names
      const oppIds = [...new Set(scores.map(s => s.opportunity_id).filter(Boolean))] as string[];
      if (oppIds.length > 0) {
        const { data: opps } = await supabase
          .from('opportunities')
          .select('id, name')
          .in('id', oppIds);
        const oppMap = new Map((opps || []).map(o => [o.id, o.name]));
        for (const s of scores) {
          s.opportunity_name = s.opportunity_id ? oppMap.get(s.opportunity_id) ?? null : null;
        }
      }

      // Enrich with actual meeting dates from momentum_meetings via transcript_reviews
      const transcriptIds = [...new Set(scores.map(s => s.transcript_id))];
      if (transcriptIds.length > 0) {
        const { data: transcripts } = await supabase
          .from('transcript_reviews')
          .select('id, momentum_meeting_id, file_name')
          .in('id', transcriptIds);

        // Extract momentum identifiers from file_name (could be UUID or numeric momentum_id)
        const momentumKeyByTranscript = new Map<string, string>();
        const uuidMeetingIds = new Set<string>();
        const numericMomentumIds = new Set<string>();
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

        (transcripts || []).forEach((t: any) => {
          // First try the direct FK column
          if (t.momentum_meeting_id) {
            momentumKeyByTranscript.set(t.id, `uuid:${t.momentum_meeting_id}`);
            uuidMeetingIds.add(t.momentum_meeting_id);
            return;
          }
          // Then try extracting from file_name
          if (t.file_name?.startsWith('momentum_')) {
            const extracted = t.file_name.replace('momentum_', '');
            if (uuidRegex.test(extracted)) {
              momentumKeyByTranscript.set(t.id, `uuid:${extracted}`);
              uuidMeetingIds.add(extracted);
            } else {
              momentumKeyByTranscript.set(t.id, `mid:${extracted}`);
              numericMomentumIds.add(extracted);
            }
          }
        });

        // Fetch meetings by UUID id and/or numeric momentum_id
        const meetingStartMap = new Map<string, string>();

        if (uuidMeetingIds.size > 0) {
          const { data: meetings } = await supabase
            .from('momentum_meetings')
            .select('id, start_time')
            .in('id', [...uuidMeetingIds]);
          (meetings || []).forEach((m: any) => meetingStartMap.set(`uuid:${m.id}`, m.start_time));
        }

        if (numericMomentumIds.size > 0) {
          const { data: meetings } = await supabase
            .from('momentum_meetings')
            .select('momentum_id, start_time')
            .in('momentum_id', [...numericMomentumIds].map(Number) as any);
          (meetings || []).forEach((m: any) => meetingStartMap.set(`mid:${m.momentum_id}`, m.start_time));
        }

        for (const s of scores) {
          const key = momentumKeyByTranscript.get(s.transcript_id);
          s.meeting_date = key ? meetingStartMap.get(key) ?? null : null;
        }
      }

      return scores;
    },
    enabled: seEmails.length > 0,
  });
}

// Delete a coaching score record
export function useDeleteCoachingScore() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (scoreId: string) => {
      const result = await deleteFrom('se_coaching_scores', [
        { column: 'id', operator: 'eq', value: scoreId }
      ]);
      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['se-coaching-score'] });
      queryClient.invalidateQueries({ queryKey: ['se-coaching-scores-team'] });
      toast.success('Coaching record deleted');
    },
    onError: (error: Error) => {
      toast.error(`Failed to delete: ${error.message}`);
    },
  });
}

// Trigger coaching analysis for a transcript
export function useRunCoachingAnalysis() {
  const queryClient = useQueryClient();

  // Poll for coaching result after triggering analysis (handles connection-closed race)
  const pollForResult = async (transcriptId: string, maxAttempts = 8) => {
    for (let i = 0; i < maxAttempts; i++) {
      await new Promise(r => setTimeout(r, 3000));
      const result = await from<SECoachingScore>('se_coaching_scores')
        .select('id, overall_score')
        .eq('transcript_id', transcriptId)
        .limit(1)
        .execute();
      if (result.data && Array.isArray(result.data) && (result.data as any[]).length > 0) {
        queryClient.invalidateQueries({ queryKey: ['coached-transcript-ids'] });
        queryClient.invalidateQueries({ queryKey: ['se-coaching-score', transcriptId] });
        queryClient.invalidateQueries({ queryKey: ['se-coaching-scores-team'] });
        return (result.data as any[])[0];
      }
    }
    return null;
  };

  return useMutation({
    mutationFn: async ({ transcriptId, meetingType, seEmail }: { transcriptId: string; meetingType?: string; seEmail?: string }) => {
      // Use fetch directly with extended timeout (90s) since coaching analysis can take 30-40s
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const session = (await supabase.auth.getSession()).data.session;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 90000);
      
      try {
        const response = await fetch(`${supabaseUrl}/functions/v1/analyze-se-coaching`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session?.access_token || ''}`,
            'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          },
          body: JSON.stringify({ transcriptId, meetingType, seEmail }),
          signal: controller.signal,
        });
        clearTimeout(timeoutId);
        
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'Analysis failed');
        if (data?.error) throw new Error(data.error);
        return { ...data, transcriptId };
      } catch (err: unknown) {
        clearTimeout(timeoutId);
        // AbortError or connection-closed: function likely completed server-side
        // Start polling to detect when the record appears
        const isConnectionError = 
          (err instanceof DOMException && err.name === 'AbortError') ||
          (err instanceof TypeError && /failed to fetch|connection/i.test((err as Error).message));
        if (isConnectionError) {
          pollForResult(transcriptId).then(found => {
            if (found) {
              toast.success(`Coaching analysis complete: ${(found as any).overall_score}/5`);
            } else {
              toast.info('Coaching analysis is finishing in the background. Check back shortly.');
            }
          });
          return { overall_score: null, timeout: true, transcriptId };
        }
        throw err;
      }
    },
    onSuccess: (data, variables) => {
      const transcriptId = data?.transcriptId || variables.transcriptId;
      queryClient.invalidateQueries({ queryKey: ['se-coaching-score', transcriptId] });
      queryClient.invalidateQueries({ queryKey: ['se-coaching-scores-team'] });
      // Invalidate all coached-transcript-ids queries (partial key match covers all opportunityIds)
      queryClient.invalidateQueries({ queryKey: ['coached-transcript-ids'] });
      queryClient.refetchQueries({ queryKey: ['coached-transcript-ids'] });
      if (data?.timeout) {
        // Silent — polling will show the toast when result is ready
      } else {
        toast.success(`Coaching analysis complete: ${data.overall_score}/5`);
      }
    },
    onError: (error: Error) => {
      // "No SE email" is a normal condition (not all opps have an SE assigned) — don't alarm the user
      if (/no se email/i.test(error.message)) {
        console.info('[SE Coaching] Skipped — no SE email assigned to this opportunity');
        return;
      }
      toast.error(`Coaching analysis failed: ${error.message}`);
    },
  });
}

// Aggregate stats for a single SE
export function aggregateSEStats(scores: SECoachingScore[]) {
  if (!scores.length) return null;
  
  const avgScore = scores.reduce((sum, s) => sum + (s.overall_score || 0), 0) / scores.length;
  const avgTalkRatio = scores.reduce((sum, s) => sum + (s.se_talk_ratio || 0), 0) / scores.length;
  const meetingCount = scores.length;
  
  // Average by dimension
  const dimensions = [
    'pov_challenge_score', 'ownership_control_score', 'storytelling_proof_score',
    'reverse_demo_score', 'champion_arming_score', 'objection_handling_score',
    'pain_quantification_score', 'questioning_score', 'differentiation_score', 'strategy_rigor_score',
    'technical_competency_score', 'value_anchoring_score', 'energy_inspiration_score',
  ] as const;
  
  const dimensionAvgs: Record<string, number | null> = {};
  for (const dim of dimensions) {
    const vals = scores.map(s => s[dim]).filter((v): v is number => v != null);
    dimensionAvgs[dim] = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  }

  // Trend: compare first half vs second half of scores (sorted newest first)
  const dimensionTrends: Record<string, 'improving' | 'declining' | 'stable' | null> = {};
  if (scores.length >= 2) {
    const mid = Math.floor(scores.length / 2);
    const recent = scores.slice(0, mid); // newer
    const older = scores.slice(mid);     // older
    for (const dim of dimensions) {
      const recentVals = recent.map(s => s[dim]).filter((v): v is number => v != null);
      const olderVals = older.map(s => s[dim]).filter((v): v is number => v != null);
      if (recentVals.length && olderVals.length) {
        const recentAvg = recentVals.reduce((a, b) => a + b, 0) / recentVals.length;
        const olderAvg = olderVals.reduce((a, b) => a + b, 0) / olderVals.length;
        const diff = recentAvg - olderAvg;
        dimensionTrends[dim] = diff > 0.3 ? 'improving' : diff < -0.3 ? 'declining' : 'stable';
      } else {
        dimensionTrends[dim] = null;
      }
    }
  }

  // Overall trend
  let overallTrend: 'improving' | 'declining' | 'stable' | null = null;
  if (scores.length >= 2) {
    const mid = Math.floor(scores.length / 2);
    const recentAvg = scores.slice(0, mid).reduce((s, sc) => s + (sc.overall_score || 0), 0) / mid;
    const olderAvg = scores.slice(mid).reduce((s, sc) => s + (sc.overall_score || 0), 0) / (scores.length - mid);
    const diff = recentAvg - olderAvg;
    overallTrend = diff > 0.3 ? 'improving' : diff < -0.3 ? 'declining' : 'stable';
  }
  
  return {
    avgScore: Math.round(avgScore * 10) / 10,
    avgTalkRatio: Math.round(avgTalkRatio),
    meetingCount,
    dimensionAvgs,
    dimensionTrends,
    overallTrend,
    recentScores: scores.slice(0, 20),
  };
}

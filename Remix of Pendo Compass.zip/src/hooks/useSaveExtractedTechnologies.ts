import { gateway } from '@/lib/apiGateway';
import { TechnologyRelationshipStatus } from '@/types/technology';

interface ExtractedTech {
  name: string;
  confidence: number;
  context?: string;
  suggestedLayer?: string;
  category?: string;
  relationshipStatus?: TechnologyRelationshipStatus;
  needsReview?: boolean;
}

// Default functional area mapping by layer for coverage tracking
const defaultFunctionalAreaByLayer: Record<string, string> = {
  host: 'Host Application',
  build: 'Analytics & Insights',
  adopt: 'Digital Adoption & In-App Guides',
  growth: 'CRM',
  ops: 'Executive Dashboards & BI',
  operations: 'Executive Dashboards & BI',
};

/**
 * Normalize a technology name the same way the DB trigger does:
 * lowercase + remove spaces, hyphens, underscores.
 */
function normalizeTechName(name: string): string {
  return name.toLowerCase().replace(/[\s\-_]+/g, '');
}

/**
 * Looks up an existing technology_repository entry by normalised name or synonym.
 * Returns the matching row's id, or null if not found.
 */
async function findExistingRepoTech(
  normalizedName: string,
  rawName: string
): Promise<{ id: string; synonyms: string[] } | null> {
  // 1. Primary lookup: match on the stored generated normalized_name column
  const byNormalized = await gateway
    .from('technology_repository')
    .select('id, synonyms')
    .eq('normalized_name', normalizedName)
    .limit(1)
    .execute();

  if (byNormalized.data && byNormalized.data.length > 0) {
    return { id: byNormalized.data[0].id, synonyms: byNormalized.data[0].synonyms || [] };
  }

  // 2. Fallback: exact case-insensitive match (catches edge cases the generator might miss)
  const byIlike = await gateway
    .from('technology_repository')
    .select('id, synonyms')
    .ilike('name', rawName)
    .limit(1)
    .execute();

  if (byIlike.data && byIlike.data.length > 0) {
    return { id: byIlike.data[0].id, synonyms: byIlike.data[0].synonyms || [] };
  }

  return null;
}

/**
 * Appends rawName as a synonym on an existing repo entry if it isn't already
 * recorded (either as the canonical name or an existing synonym).
 */
async function addSynonymIfNew(
  repoId: string,
  rawName: string,
  existingSynonyms: string[],
  canonicalName?: string
): Promise<void> {
  const normalizedRaw = normalizeTechName(rawName);
  const alreadyKnown =
    (canonicalName && normalizeTechName(canonicalName) === normalizedRaw) ||
    existingSynonyms.some((s) => normalizeTechName(s) === normalizedRaw);

  if (alreadyKnown) return;

  await gateway
    .from('technology_repository')
    .update({ synonyms: [...existingSynonyms, rawName] })
    .eq('id', repoId)
    .execute();
}

/**
 * Saves extracted technologies to both technology_repository (as draft if new)
 * and account_technologies (linked to repository).
 * Uses normalized-name + synonym deduplication to prevent duplicates.
 */
export async function saveExtractedTechnologies(
  accountId: string,
  technologies: ExtractedTech[],
  sourceNote?: string
): Promise<{ saved: number; draftsCreated: number; updated: number }> {
  let saved = 0;
  let draftsCreated = 0;
  let updated = 0;

  for (const tech of technologies) {
    // Skip low confidence
    if (tech.confidence < 0.7) continue;

    const techName = tech.name.trim();
    if (!techName) continue;

    const normalizedName = normalizeTechName(techName);

    // Determine functional area from layer or default
    const layer = tech.suggestedLayer || 'adopt';
    const category =
      tech.category && tech.category !== 'Other' && tech.category !== 'Extracted'
        ? tech.category
        : defaultFunctionalAreaByLayer[layer] || 'Digital Adoption & In-App Guides';
    const relationshipStatus = tech.relationshipStatus || 'mentioned';
    const needsReview = tech.needsReview ?? tech.confidence < 0.8;

    // ── 1. Resolve / create repository entry ─────────────────────────────────
    let repositoryTechId: string | null = null;

    const existing = await findExistingRepoTech(normalizedName, techName);

    if (existing) {
      repositoryTechId = existing.id;
      // Record this variant as a synonym so future lookups find it immediately
      await addSynonymIfNew(existing.id, techName, existing.synonyms);
    } else {
      // Create a draft entry
      const newRepoResult = await gateway
        .from('technology_repository')
        .insert({
          name: techName,
          layer,
          functional_area: category,
          status: 'draft',
          description: `Auto-extracted from transcript. ${tech.context || ''}`.trim(),
        })
        .execute();

      if (newRepoResult.error) {
        // Structured duplicate signal from the updated trigger: "TECH_DUPLICATE:<uuid>"
        const dupMatch = newRepoResult.error.message?.match(/TECH_DUPLICATE:([0-9a-f-]{36})/i);
        if (dupMatch) {
          repositoryTechId = dupMatch[1];
          // Fetch existing synonyms so we can append without overwriting
          const synResult = await gateway
            .from('technology_repository')
            .select('synonyms, name')
            .eq('id', repositoryTechId)
            .limit(1)
            .execute();
          const row = synResult.data?.[0];
          if (row) {
            await addSynonymIfNew(repositoryTechId, techName, row.synonyms || [], row.name);
          }
        } else {
          console.error('Failed to create draft technology:', newRepoResult.error.message);
        }
      } else if (newRepoResult.data && newRepoResult.data.length > 0) {
        repositoryTechId = newRepoResult.data[0].id;
        draftsCreated++;
      }
    }

    // ── 2. Resolve / update account_technologies entry ───────────────────────
    const existingAccountTechResult = await gateway
      .from('account_technologies')
      .select('id, relationship_status, extraction_confidence')
      .eq('account_id', accountId)
      .ilike('name', techName)
      .execute();

    const existingAccountTech = existingAccountTechResult.data?.[0];

    if (existingAccountTech) {
      // Only upgrade relationship status, never downgrade
      const statusPriority: Record<string, number> = {
        neutral: 0,
        mentioned: 1,
        experience: 2,
        considering: 3,
        evaluating: 4,
        in_use: 5,
        replaced: 5,
      };

      const currentPriority = statusPriority[existingAccountTech.relationship_status] ?? 0;
      const newPriority = statusPriority[relationshipStatus] ?? 0;

      if (newPriority > currentPriority) {
        const updateResult = await gateway
          .from('account_technologies')
          .update({
            relationship_status: relationshipStatus,
            extraction_confidence: tech.confidence,
            needs_review: needsReview,
            context: tech.context || null,
            repository_tech_id: repositoryTechId || existingAccountTech.id,
          })
          .eq('id', existingAccountTech.id)
          .execute();

        if (!updateResult.error) updated++;
      }
    } else {
      const insertResult = await gateway
        .from('account_technologies')
        .insert({
          account_id: accountId,
          name: techName,
          layer,
          category,
          status: 'current',
          notes: sourceNote || null,
          repository_tech_id: repositoryTechId,
          relationship_status: relationshipStatus,
          extraction_confidence: tech.confidence,
          needs_review: needsReview,
          context: tech.context || null,
        })
        .execute();

      if (insertResult.error) {
        console.error('Failed to save account technology:', insertResult.error.message);
      } else {
        saved++;
      }
    }
  }

  return { saved, draftsCreated, updated };
}

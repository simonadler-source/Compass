import { useMutation } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';

interface ProductMentionInput {
  transcript_id: string;
  account_id: string | null;
  opportunity_id?: string | null;
  product_name: string;
  mention_type: 'owned' | 'complementary' | 'competitive';
  sentiment_score: number | null;
  sentiment_label: 'positive' | 'neutral' | 'negative' | 'mixed' | null;
  context_snippet: string | null;
  mention_count: number;
  confidence_score: number | null;
  integration_context: string | null;
  transcript_date: string | null;
}

export function useSaveProductMentions() {
  return useMutation({
    mutationFn: async (mentions: ProductMentionInput[]) => {
      if (!mentions.length) return [];

      const result = await gateway.from('product_mentions')
        .insert(mentions)
        .execute();

      if (result.error) {
        console.error('Failed to save product mentions:', result.error);
        throw new Error(result.error.message);
      }

      return result.data;
    },
  });
}

// Helper to transform extracted product mentions from AI analysis to database format
export function transformProductMentions(
  extractedMentions: Array<{
    productName: string;
    mentionType: 'owned' | 'complementary' | 'competitive';
    sentimentScore?: number | null;
    sentimentLabel: 'positive' | 'neutral' | 'negative' | 'mixed';
    contextSnippet: string;
    mentionCount: number;
    confidence: number;
    integrationContext?: string | null;
  }>,
  transcriptId: string,
  accountId: string | null,
  opportunityId?: string | null,
  transcriptDate?: string | null
): ProductMentionInput[] {
  return extractedMentions.map(mention => ({
    transcript_id: transcriptId,
    account_id: accountId,
    opportunity_id: opportunityId || null,
    product_name: mention.productName,
    mention_type: mention.mentionType,
    sentiment_score: mention.sentimentScore ?? null,
    sentiment_label: mention.sentimentLabel,
    context_snippet: mention.contextSnippet,
    mention_count: mention.mentionCount,
    confidence_score: mention.confidence,
    integration_context: mention.integrationContext ?? null,
    transcript_date: transcriptDate || new Date().toISOString(),
  }));
}

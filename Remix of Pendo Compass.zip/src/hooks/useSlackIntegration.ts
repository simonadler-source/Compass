import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface SlackChannel {
  id: string;
  name: string;
  purpose: 'competitive' | 'account' | 'opportunity' | 'general';
  linked_account_id?: string;
  linked_opportunity_id?: string;
  last_sync_at?: string;
  last_sync_status?: 'success' | 'error' | 'syncing';
  last_sync_signals?: number;
}

export function useSlackIntegration() {
  const queryClient = useQueryClient();

  const { data: dataIntegrations } = useQuery({
    queryKey: ['data-integrations'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('data_integrations')
        .select('*')
        .order('created_at', { ascending: true });
      if (error) throw error;
      return data || [];
    },
  });

  const slackIntegration = dataIntegrations?.find((i: any) => i.provider === 'slack');
  const isSlackEnabled = !!(slackIntegration?.is_enabled);

  const channels: SlackChannel[] = (slackIntegration?.config as any)?.channels || [];

  const getLinkedChannels = (opts: { accountId?: string; opportunityId?: string }) => {
    return channels.filter(ch => {
      if (opts.opportunityId) return ch.linked_opportunity_id === opts.opportunityId;
      if (opts.accountId) return ch.linked_account_id === opts.accountId && ch.purpose === 'account';
      return false;
    });
  };

  const addChannel = async (channel: SlackChannel) => {
    const existing = slackIntegration;
    const currentChannels: SlackChannel[] = (existing?.config as any)?.channels || [];
    if (currentChannels.some(c => c.id === channel.id)) {
      toast.error('Channel already added');
      return;
    }
    const updatedChannels = [...currentChannels, channel];
    try {
      if (existing?.id) {
        const { error } = await supabase.from('data_integrations').update({
          config: { ...(existing.config as any || {}), channels: updatedChannels },
          is_enabled: true,
          polling_interval_minutes: existing.polling_interval_minutes ?? 240,
        }).eq('id', existing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('data_integrations').insert([{
          provider: 'slack',
          display_name: 'Slack',
          is_enabled: true,
          polling_interval_minutes: 240,
          config: { channels: updatedChannels } as any,
        }]);
        if (error) throw error;
      }
      queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
      toast.success(`Linked #${channel.name}`);
    } catch (err: any) {
      toast.error('Failed to link channel: ' + (err.message || 'Unknown error'));
    }
  };

  const removeChannel = async (channelId: string) => {
    if (!slackIntegration?.id) return;
    const currentChannels: SlackChannel[] = (slackIntegration.config as any)?.channels || [];
    const updatedChannels = currentChannels.filter(c => c.id !== channelId);
    const { error } = await supabase.from('data_integrations').update({
      config: { ...(slackIntegration.config as any || {}), channels: updatedChannels },
    }).eq('id', slackIntegration.id);
    if (error) {
      toast.error('Failed to unlink channel: ' + error.message);
      return;
    }
    queryClient.invalidateQueries({ queryKey: ['data-integrations'] });
    toast.success('Channel unlinked');
  };

  return { isSlackEnabled, channels, getLinkedChannels, addChannel, removeChannel };
}

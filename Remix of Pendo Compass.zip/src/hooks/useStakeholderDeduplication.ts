import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface Contact {
  id: string;
  name: string;
  role: string | null;
  email: string | null;
}

export interface DuplicateGroup {
  primary: Contact;
  duplicates: Contact[];
  confidence: 'high' | 'medium' | 'low';
  matchReason: string;
}

// Levenshtein distance for fuzzy name matching
function levenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];
  const aLen = a.length;
  const bLen = b.length;
  
  if (aLen === 0) return bLen;
  if (bLen === 0) return aLen;

  for (let i = 0; i <= bLen; i++) matrix[i] = [i];
  for (let j = 0; j <= aLen; j++) matrix[0][j] = j;

  for (let i = 1; i <= bLen; i++) {
    for (let j = 1; j <= aLen; j++) {
      const cost = a[j - 1] === b[i - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost
      );
    }
  }
  return matrix[bLen][aLen];
}

function normalizeString(s: string): string {
  return s.toLowerCase().trim().replace(/[^a-z0-9]/g, '');
}

// Extract significant words from a name for word-based matching
function extractWords(s: string): string[] {
  return s.toLowerCase().trim()
    .replace(/[^a-z0-9\s]/g, '')
    .split(/\s+/)
    .filter(w => w.length > 2); // Filter out short words
}

// Check if two names share significant words
function shareSignificantWords(name1: string, name2: string): { shared: number; total: number } {
  const words1 = new Set(extractWords(name1));
  const words2 = new Set(extractWords(name2));
  const allWords = new Set([...words1, ...words2]);
  const sharedWords = [...words1].filter(w => words2.has(w));
  return { shared: sharedWords.length, total: allWords.size };
}

// Detect potential duplicates in a list of contacts
export function detectDuplicates(contacts: Contact[]): DuplicateGroup[] {
  const groups: DuplicateGroup[] = [];
  const processed = new Set<string>();

  for (const contact of contacts) {
    if (processed.has(contact.id)) continue;
    
    const duplicates: Contact[] = [];
    let highestConfidence: 'high' | 'medium' | 'low' = 'low';
    let matchReason = '';
    
    processed.add(contact.id);
    
    for (const other of contacts) {
      if (processed.has(other.id)) continue;
      
      // 1. Exact email match - HIGH confidence
      if (contact.email && other.email && 
          contact.email.toLowerCase() === other.email.toLowerCase()) {
        duplicates.push(other);
        processed.add(other.id);
        highestConfidence = 'high';
        matchReason = 'Same email address';
        continue;
      }
      
      const name1 = normalizeString(contact.name || '');
      const name2 = normalizeString(other.name || '');
      
      if (!name1 || !name2) continue;
      
      // 2. Exact name match - HIGH confidence
      if (name1 === name2) {
        duplicates.push(other);
        processed.add(other.id);
        if (highestConfidence !== 'high') {
          highestConfidence = 'high';
          matchReason = 'Exact name match';
        }
        continue;
      }
      
      // 3. One name is prefix of other (e.g., "Ruba" vs "Ruba Zarour") - MEDIUM-HIGH confidence
      if (name1.startsWith(name2) || name2.startsWith(name1)) {
        const shorterLen = Math.min(name1.length, name2.length);
        // Only if the shorter name is reasonable length (not just "J" matching "John")
        if (shorterLen >= 4) {
          duplicates.push(other);
          processed.add(other.id);
          if (highestConfidence === 'low') {
            highestConfidence = 'medium';
            matchReason = 'Partial name match';
          }
        continue;
        }
      }
      
      // 4. Word-based matching (e.g., "Francisco Partners" vs "Francisco Partner Consultants")
      const wordMatch = shareSignificantWords(contact.name || '', other.name || '');
      if (wordMatch.shared >= 2 && wordMatch.shared / wordMatch.total >= 0.5) {
        // At least 2 shared words and 50%+ overlap - MEDIUM confidence
        duplicates.push(other);
        processed.add(other.id);
        if (highestConfidence === 'low') {
          highestConfidence = 'medium';
          matchReason = 'Shared key words';
        }
        continue;
      }
      
      // 5. Levenshtein similarity - confidence depends on similarity
      const distance = levenshteinDistance(name1, name2);
      const maxLen = Math.max(name1.length, name2.length);
      const similarity = 1 - (distance / maxLen);
      
      if (similarity >= 0.9) {
        // Very high similarity (e.g., typos) - HIGH confidence
        duplicates.push(other);
        processed.add(other.id);
        if (highestConfidence !== 'high') {
          highestConfidence = 'high';
          matchReason = 'Very similar names (likely typo)';
        }
      } else if (similarity >= 0.75) {
        // Good similarity - MEDIUM confidence
        duplicates.push(other);
        processed.add(other.id);
        if (highestConfidence === 'low') {
          highestConfidence = 'medium';
          matchReason = 'Similar names';
        }
      }
    }
    
    if (duplicates.length > 0) {
      groups.push({
        primary: contact,
        duplicates,
        confidence: highestConfidence,
        matchReason,
      });
    }
  }
  
  return groups;
}

// Select the best record from a group (most complete data)
export function selectBestRecord(contacts: Contact[]): Contact {
  return [...contacts].sort((a, b) => {
    let scoreA = 0, scoreB = 0;
    
    // Core identity: email is most important
    if (a.email && a.email.trim()) scoreA += 20;
    if (b.email && b.email.trim()) scoreB += 20;
    
    // Name completeness (longer = more complete, likely full name)
    if (a.name) scoreA += Math.min(a.name.length * 2, 30);
    if (b.name) scoreB += Math.min(b.name.length * 2, 30);
    
    // Role/title (important context)
    if (a.role && a.role.trim()) scoreA += 15;
    if (b.role && b.role.trim()) scoreB += 15;
    
    return scoreB - scoreA;
  })[0];
}

// Hook for triggering deduplication
export function useStakeholderDeduplication(accountId: string, opportunityId: string) {
  const queryClient = useQueryClient();

  // Auto-merge high-confidence duplicates
  const autoMerge = useMutation({
    mutationFn: async (groups: DuplicateGroup[]) => {
      const highConfidenceGroups = groups.filter(g => g.confidence === 'high');
      
      if (highConfidenceGroups.length === 0) {
        return { merged: 0, groups: [] };
      }

      const results = [];
      
      for (const group of highConfidenceGroups) {
        const allContacts = [group.primary, ...group.duplicates];
        const contactIds = allContacts.map(c => c.id);
        
        const { data, error } = await supabase.functions.invoke('deduplicate-contacts', {
          body: {
            account_id: accountId,
            contact_ids: contactIds,
            dry_run: false,
          },
        });
        
        if (error) throw error;
        results.push(data);
      }
      
      return { merged: highConfidenceGroups.length, results };
    },
    onSuccess: (data) => {
      if (data.merged > 0) {
        queryClient.invalidateQueries({ queryKey: ['opportunity-stakeholders', opportunityId] });
        queryClient.invalidateQueries({ queryKey: ['aggregated-account-contacts', accountId] });
        toast.success(`Auto-merged ${data.merged} duplicate group${data.merged > 1 ? 's' : ''}`);
      }
    },
    onError: (error) => {
      console.error('Auto-merge failed:', error);
      // Silent failure - don't block UI
    },
  });

  // Manual merge specific contacts
  const manualMerge = useMutation({
    mutationFn: async (contactIds: string[]) => {
      if (contactIds.length < 2) throw new Error('Select at least 2 contacts to merge');
      
      const { data, error } = await supabase.functions.invoke('deduplicate-contacts', {
        body: {
          account_id: accountId,
          contact_ids: contactIds,
          dry_run: false,
        },
      });
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['opportunity-stakeholders', opportunityId] });
      queryClient.invalidateQueries({ queryKey: ['aggregated-account-contacts', accountId] });
      toast.success('Contacts merged successfully');
    },
    onError: (error) => {
      toast.error('Failed to merge contacts: ' + (error as Error).message);
    },
  });

  return {
    detectDuplicates,
    autoMerge,
    manualMerge,
  };
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface SuppressedTechnology {
  id: string;
  account_id: string;
  technology_name: string;
  suppressed_by: string | null;
  suppressed_at: string;
  reason: string | null;
}

export function useSuppressedTechnologies(accountId: string) {
  return useQuery({
    queryKey: ['suppressed-technologies', accountId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('suppressed_extracted_technologies' as any)
        .select('*')
        .eq('account_id', accountId);
      if (error) throw error;
      return (data || []) as unknown as SuppressedTechnology[];
    },
    enabled: !!accountId,
  });
}

export function useSuppressTechnology() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ accountId, technologyName, reason }: { accountId: string; technologyName: string; reason?: string }) => {
      const { data, error } = await supabase
        .from('suppressed_extracted_technologies' as any)
        .insert({
          account_id: accountId,
          technology_name: technologyName,
          reason: reason || null,
        })
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['suppressed-technologies', variables.accountId] });
      toast.success(`"${variables.technologyName}" will no longer appear in extracted technologies`);
    },
    onError: (error) => {
      toast.error('Failed to suppress technology: ' + (error as Error).message);
    },
  });
}

export function useUnsuppressTechnology() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ accountId, technologyName }: { accountId: string; technologyName: string }) => {
      const { error } = await supabase
        .from('suppressed_extracted_technologies' as any)
        .delete()
        .eq('account_id', accountId)
        .eq('technology_name', technologyName);
      if (error) throw error;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['suppressed-technologies', variables.accountId] });
      toast.success(`"${variables.technologyName}" will now appear when detected`);
    },
    onError: (error) => {
      toast.error('Failed to unsuppress technology: ' + (error as Error).message);
    },
  });
}

import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

// Hook to check if user can access a specific tab within a page
export function useTabAccess(basePath: string, tabPath: string) {
  const { user } = useAuth();
  const fullPath = `${basePath}/${tabPath}`;

  const { data: canAccess, isLoading } = useQuery({
    queryKey: ['can-access-tab', user?.id, fullPath],
    queryFn: async () => {
      if (!user?.id) return false;
      
      const { data, error } = await supabase
        .rpc('can_access_page', { 
          _user_id: user.id, 
          _page_path: fullPath 
        });
      
      if (error) {
        console.error('Error checking tab access:', error);
        return true; // Default to allowing access on error
      }
      return data;
    },
    enabled: !!user?.id,
  });

  return { canAccess: canAccess ?? true, isLoading };
}

// Hook to check multiple tabs at once for a page
export function useMultipleTabAccess(basePath: string, tabs: string[]) {
  const { user } = useAuth();

  const { data: tabAccess, isLoading } = useQuery({
    queryKey: ['can-access-tabs', user?.id, basePath, tabs],
    queryFn: async () => {
      if (!user?.id) return {} as Record<string, boolean>;
      
      const results: Record<string, boolean> = {};
      
      // Check access for each tab
      await Promise.all(
        tabs.map(async (tab) => {
          const fullPath = `${basePath}/${tab}`;
          const { data, error } = await supabase
            .rpc('can_access_page', { 
              _user_id: user.id, 
              _page_path: fullPath 
            });
          
          if (error) {
            console.error(`Error checking access for ${fullPath}:`, error);
            results[tab] = true; // Default to allowing on error
          } else {
            results[tab] = data;
          }
        })
      );
      
      return results;
    },
    enabled: !!user?.id && tabs.length > 0,
  });

  return { 
    tabAccess: tabAccess ?? tabs.reduce((acc, tab) => ({ ...acc, [tab]: true }), {}), 
    isLoading,
    canAccessTab: (tab: string) => tabAccess?.[tab] ?? true
  };
}

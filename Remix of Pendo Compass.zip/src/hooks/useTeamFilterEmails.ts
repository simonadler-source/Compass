import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

interface TeamLeader {
  id: string;
  email: string;
  name: string;
}

/** Fetches all users who manage at least one report */
export function useTeamLeaders() {
  return useQuery<TeamLeader[]>({
    queryKey: ['team-leaders-for-filter'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('team_hierarchy')
        .select('manager_id')
        .execute();

      if (error) throw new Error(getErrorMessage(error));

      const managerIds = [...new Set((data || []).map((d: any) => d.manager_id))];
      if (managerIds.length === 0) return [];

      const { data: profiles, error: pErr } = await gateway
        .from('profiles')
        .select('id, email, full_name')
        .in('id', managerIds)
        .execute();

      if (pErr) throw new Error(getErrorMessage(pErr));

      return (profiles || []).map((p: any) => ({
        id: p.id,
        email: (p.email || '').toLowerCase(),
        name: p.full_name || p.email,
      }));
    },
    staleTime: 5 * 60 * 1000,
  });
}

/** Given a leader user-id, returns the lowercase emails of all their reports (+ the leader) */
export function useTeamMemberEmails(leaderId: string | undefined) {
  return useQuery<string[]>({
    queryKey: ['team-member-emails', leaderId],
    queryFn: async () => {
      if (!leaderId) return [];

      const { data: teamIds, error } = await supabase
        .rpc('get_team_members', { _manager_id: leaderId });

      if (error) throw error;

      const ids = (teamIds || []).map((t: any) => t.user_id);
      ids.push(leaderId); // include the leader

      const { data: profiles, error: pErr } = await gateway
        .from('profiles')
        .select('id, email')
        .in('id', ids)
        .execute();

      if (pErr) throw new Error(getErrorMessage(pErr));

      return (profiles || [])
        .map((p: any) => (p.email || '').toLowerCase())
        .filter(Boolean);
    },
    enabled: !!leaderId,
    staleTime: 5 * 60 * 1000,
  });
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export type RelationshipType = 'solid' | 'dotted';

interface TeamHierarchyEntry {
  id: string;
  manager_id: string;
  report_id: string;
  relationship_type: RelationshipType;
  created_at: string;
  created_by: string | null;
}

interface UserWithHierarchy {
  id: string;
  email: string;
  full_name: string | null;
  manager?: {
    id: string;
    email: string;
    full_name: string | null;
  } | null;
  directReports?: Array<{
    id: string;
    email: string;
    full_name: string | null;
  }>;
}

export function useTeamHierarchy() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Fetch all hierarchy entries (for admin view)
  const { data: hierarchyEntries, isLoading: entriesLoading } = useQuery({
    queryKey: ['team-hierarchy'],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('team_hierarchy')
        .select('*')
        .order('created_at', { ascending: false })
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data as TeamHierarchyEntry[];
    },
  });

  // Fetch my team members (full hierarchy - using database function)
  const { data: myTeamIds, isLoading: teamLoading } = useQuery({
    queryKey: ['my-team-hierarchy', user?.id],
    queryFn: async () => {
      if (!user) return [];

      const { data, error } = await supabase
        .rpc('get_team_members', { _manager_id: user.id });

      if (error) throw error;
      return data as Array<{ user_id: string; depth: number }>;
    },
    enabled: !!user,
  });

  // Fetch direct reports only (for display purposes)
  const { data: directReports, isLoading: directReportsLoading } = useQuery({
    queryKey: ['direct-reports', user?.id],
    queryFn: async () => {
      if (!user) return [];

      const { data, error } = await gateway
        .from('team_hierarchy')
        .select('report_id')
        .eq('manager_id', user.id)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data.map((d: any) => d.report_id);
    },
    enabled: !!user,
  });

  // Add a report to a manager (solid or dotted line)
  const addReport = useMutation({
    mutationFn: async ({ managerId, reportId, relationshipType = 'solid' }: { managerId: string; reportId: string; relationshipType?: RelationshipType }) => {
      if (!user) throw new Error('Not authenticated');

      if (relationshipType === 'solid') {
        // Remove any existing solid-line manager (a person can only have one solid-line manager)
        await gateway
          .from('team_hierarchy')
          .delete()
          .eq('report_id', reportId)
          .eq('relationship_type', 'solid')
          .execute();
      }

      const { data, error } = await gateway
        .from('team_hierarchy')
        .insert({
          manager_id: managerId,
          report_id: reportId,
          relationship_type: relationshipType,
          created_by: user.id,
        })
        .select('*')
        .single()
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['team-hierarchy'] });
      queryClient.invalidateQueries({ queryKey: ['my-team-hierarchy'] });
      queryClient.invalidateQueries({ queryKey: ['direct-reports'] });
      queryClient.invalidateQueries({ queryKey: ['org-tree-hierarchy'] });
      queryClient.invalidateQueries({ queryKey: ['my-team-members'] });
      toast.success('Team member assigned');
    },
    onError: (error: any) => {
      if (error.message?.includes('23505')) {
        toast.error('This assignment already exists');
      } else if (error.message?.includes('no_self_assignment')) {
        toast.error('Cannot assign a user to themselves');
      } else {
        toast.error('Failed to assign team member: ' + error.message);
      }
    },
  });

  // Remove a report from a manager
  const removeReport = useMutation({
    mutationFn: async ({ managerId, reportId }: { managerId: string; reportId: string }) => {
      const { error } = await gateway
        .from('team_hierarchy')
        .delete()
        .eq('manager_id', managerId)
        .eq('report_id', reportId)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['team-hierarchy'] });
      queryClient.invalidateQueries({ queryKey: ['my-team-hierarchy'] });
      queryClient.invalidateQueries({ queryKey: ['direct-reports'] });
      toast.success('Team assignment removed');
    },
    onError: (error: any) => {
      toast.error('Failed to remove assignment: ' + error.message);
    },
  });

  // Get all team member user IDs (including self for dashboard)
  const teamUserIds = myTeamIds?.map(t => t.user_id) || [];
  const teamWithSelf = user ? [user.id, ...teamUserIds] : teamUserIds;

  return {
    hierarchyEntries,
    myTeamIds,
    directReports,
    teamUserIds,
    teamWithSelf,
    isLoading: entriesLoading || teamLoading || directReportsLoading,
    addReport,
    removeReport,
  };
}

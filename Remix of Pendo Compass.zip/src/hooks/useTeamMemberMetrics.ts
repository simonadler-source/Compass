import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useTeamMembers } from './useTeamMembers';
import { useMemo } from 'react';
import { subDays, differenceInMinutes, startOfWeek, endOfWeek } from 'date-fns';

export interface TeamMemberMetrics {
  email: string;
  name: string | null;
  userId: string | null;
  depth: number;
  // Deal coverage
  accountCount: number;
  opportunityCount: number;
  pipelineValue: number;
  // Meeting activity
  meetingCount30d: number;
  meetingCount60d: number;
  meetingCount90d: number;
  totalMeetingMinutes30d: number;
  totalMeetingMinutes60d: number;
  totalMeetingMinutes90d: number;
  avgMeetingDuration: number;
  hoursPerWeek: number;
  hoursPerMonth: number;
  // Engagement quality
  transcriptsProcessed: number;
  nbasCreated: number;
  nbasCompleted: number;
  readinessAverage: number;
}

interface TimeRange {
  label: string;
  days: number;
  isWeek?: boolean;
  weekOffset?: number;
}

export const TIME_RANGES: TimeRange[] = [
  { label: 'This Week', days: 7, isWeek: true, weekOffset: 0 },
  { label: 'Last Week', days: 7, isWeek: true, weekOffset: -1 },
  { label: '30 days', days: 30 },
  { label: '60 days', days: 60 },
  { label: '90 days', days: 90 },
];

export type RangeKey = 'this_week' | 'last_week' | '30' | '60' | '90';

export function getDateRangeForKey(key: RangeKey): { start: Date; end: Date; label: string } {
  const now = new Date();
  switch (key) {
    case 'this_week': {
      const start = startOfWeek(now, { weekStartsOn: 1 });
      const end = endOfWeek(now, { weekStartsOn: 1 });
      return { start, end, label: 'This Week' };
    }
    case 'last_week': {
      const lastWeekDate = subDays(now, 7);
      const start = startOfWeek(lastWeekDate, { weekStartsOn: 1 });
      const end = endOfWeek(lastWeekDate, { weekStartsOn: 1 });
      return { start, end, label: 'Last Week' };
    }
    default: {
      const days = parseInt(key);
      return { start: subDays(now, days), end: now, label: `${days} days` };
    }
  }
}

const normalizePersonName = (value?: string | null) =>
  (value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();

const extractAssignedNameFromNotes = (notes?: string | null) => {
  if (!notes) return null;
  const match = notes.match(/(?:^|\n)\s*Assigned:\s*(.+?)\s*(?:\n|$)/i);
  return match?.[1]?.trim() || null;
};

const meetingMatchesMember = (meeting: any, memberEmail: string, memberName?: string | null) => {
  const normalizedEmail = memberEmail.toLowerCase().trim();
  const normalizedMemberName = normalizePersonName(memberName);
  const emailAlias = normalizePersonName(normalizedEmail.split('@')[0]?.replace(/[._-]+/g, ' '));
  const candidateNames = new Set<string>([normalizedMemberName, emailAlias].filter(Boolean) as string[]);

  const isHost = meeting.host_email?.toLowerCase() === normalizedEmail;
  const isAttendeeByEmail = Array.isArray(meeting.attendees) &&
    (meeting.attendees as Array<{ email?: string }>).some(a => a.email?.toLowerCase() === normalizedEmail);
  if (isHost || isAttendeeByEmail) return true;

  if (candidateNames.size === 0) return false;

  const hostName = normalizePersonName(meeting.host_name);
  if (hostName && candidateNames.has(hostName)) return true;

  const isAttendeeByName = Array.isArray(meeting.attendees) &&
    (meeting.attendees as Array<{ name?: string }>).some(a => {
      const attendeeName = normalizePersonName(a.name);
      return attendeeName && candidateNames.has(attendeeName);
    });
  if (isAttendeeByName) return true;

  const assignedFromNotes = normalizePersonName(extractAssignedNameFromNotes(meeting.notes));
  return !!assignedFromNotes && candidateNames.has(assignedFromNotes);
};

export function useTeamMemberMetrics(rangeKey: RangeKey = 'this_week') {
  const { hierarchyTeamMembers, isLoading: teamLoading } = useTeamMembers();

  // Get all team member emails for queries
  const teamEmails = useMemo(() => {
    return hierarchyTeamMembers?.map(m => m.email.toLowerCase()) || [];
  }, [hierarchyTeamMembers]);

  // Compute date range early so queries can use it
  const { start: rangeStart, end: rangeEnd } = useMemo(() => getDateRangeForKey(rangeKey), [rangeKey]);
  const rangeStartISO = useMemo(() => rangeStart.toISOString(), [rangeStart]);
  const rangeEndISO = useMemo(() => rangeEnd.toISOString(), [rangeEnd]);

  // Note: team_member_email is encrypted (NULL in DB), so we fetch all and filter in memory
  const { data: accountAssignments, isLoading: accountsLoading } = useQuery({
    queryKey: ['team-member-accounts', teamEmails],
    queryFn: async () => {
      if (!teamEmails.length) return [];

      // Fetch all account_team_members and filter in memory after decryption
      const { data, error } = await gateway
        .from('account_team_members')
        .select('team_member_email, account_id')
        .execute();

      if (error) throw new Error(getErrorMessage(error));

      // Filter to only include team members we're interested in
      const teamEmailSet = new Set(teamEmails.map(e => e.toLowerCase().trim()));
      return (data || []).filter((d: any) =>
        d.team_member_email && teamEmailSet.has(d.team_member_email.toLowerCase().trim())
      );
    },
    enabled: teamEmails.length > 0,
  });

  // Fetch opportunity team assignments with opportunity details
  // Note: team_member_email is encrypted (NULL in DB), so we fetch all and filter in memory
  const { data: opportunityAssignments, isLoading: oppsLoading } = useQuery({
    queryKey: ['team-member-opportunities', teamEmails],
    queryFn: async () => {
      if (!teamEmails.length) return [];

      // Fetch all opportunity_team_members and filter in memory after decryption
      const { data, error } = await gateway
        .from('opportunity_team_members')
        .select(`
          team_member_email,
          opportunity_id,
          opportunities!inner(id, value, stage)
        `)
        .execute();

      if (error) throw new Error(getErrorMessage(error));

      // Filter to only include team members we're interested in
      const teamEmailSet = new Set(teamEmails.map(e => e.toLowerCase().trim()));
      return (data || []).filter((d: any) =>
        d.team_member_email && teamEmailSet.has(d.team_member_email.toLowerCase().trim())
      );
    },
    enabled: teamEmails.length > 0,
  });

  // Fetch meetings scoped to the selected date range — let the DB do the heavy lifting
  const { data: meetings, isLoading: meetingsLoading } = useQuery({
    queryKey: ['team-member-meetings', teamEmails, rangeStartISO, rangeEndISO],
    queryFn: async () => {
      if (!teamEmails.length) return [];

      const { data, error } = await gateway
        .from('momentum_meetings')
        .select('id, momentum_id, host_email, host_name, start_time, end_time, attendees, notes, status, matched_account_id, opportunity_id')
        .gte('start_time', rangeStartISO)
        .lte('start_time', rangeEndISO)
        .eq('status', 'imported')
        .order('start_time', { ascending: false })
        .limit(5000)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: teamEmails.length > 0,
  });

  // Fetch transcripts scoped to the selected date range
  const { data: transcripts, isLoading: transcriptsLoading } = useQuery({
    queryKey: ['team-member-transcripts', rangeStartISO, rangeEndISO],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('transcript_reviews')
        .select('id, created_by, final_account_id, created_at, status, file_name')
        .gte('created_at', rangeStartISO)
        .lte('created_at', rangeEndISO)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: teamEmails.length > 0,
  });

  // Fetch NBAs scoped to the selected date range
  const { data: nbas, isLoading: nbasLoading } = useQuery({
    queryKey: ['team-member-nbas', teamEmails, rangeStartISO, rangeEndISO],
    queryFn: async () => {
      if (!teamEmails.length) return [];

      const { data, error } = await gateway
        .from('account_nbas')
        .select('id, assigned_to, status, created_at, account_id')
        .in('assigned_to', teamEmails)
        .gte('created_at', rangeStartISO)
        .lte('created_at', rangeEndISO)
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: teamEmails.length > 0,
  });

  // Fetch readiness answers for opportunities
  const { data: readinessData, isLoading: readinessLoading } = useQuery({
    queryKey: ['team-member-readiness', teamEmails],
    queryFn: async () => {
      if (!opportunityAssignments?.length) return { answers: [], totalQuestions: 0 };

      const oppIds = [...new Set(opportunityAssignments.map((o: any) => o.opportunity_id))];

      const [answersRes, questionsRes] = await Promise.all([
        gateway
          .from('opportunity_readiness_answers')
          .select('opportunity_id, answer')
          .in('opportunity_id', oppIds)
          .execute(),
        gateway
          .from('readiness_template_questions')
          .select('id')
          .execute(),
      ]);

      if (answersRes.error) throw new Error(getErrorMessage(answersRes.error));

      return {
        answers: answersRes.data || [],
        totalQuestions: questionsRes.data?.length || 1,
      };
    },
    enabled: (opportunityAssignments?.length || 0) > 0,
  });

  // Calculate metrics per team member — meetings already scoped by DB query, just filter by person
  const metrics = useMemo<TeamMemberMetrics[]>(() => {
    if (!hierarchyTeamMembers?.length) return [];

    const now = new Date();

    return hierarchyTeamMembers.map(member => {
      const email = member.email.toLowerCase();

      // Deal coverage (assignment-based for pipeline/readiness)
      const memberAccounts = accountAssignments?.filter((a: any) =>
        a.team_member_email.toLowerCase() === email
      ) || [];
      const memberOpps = opportunityAssignments?.filter((o: any) =>
        o.team_member_email.toLowerCase() === email
      ) || [];
      const pipelineValue = memberOpps.reduce((sum: number, o: any) => {
        const opp = o.opportunities as unknown as { value: number | null; stage: string | null };
        if (opp?.stage !== 'closed_won' && opp?.stage !== 'closed_lost') {
          return sum + (opp?.value || 0);
        }
        return sum;
      }, 0);

      // Meeting activity - meetings already date-filtered by query, just filter by person
      const memberMeetings = meetings?.filter((m: any) =>
        meetingMatchesMember(m, email, member.full_name)
      ) || [];

      // Activity-scoped coverage (must match weekly heatmap breakdown)
      const activeAccountIds = new Set<string>();
      const activeOpportunityIds = new Set<string>();
      memberMeetings.forEach((m: any) => {
        if (m.matched_account_id) activeAccountIds.add(m.matched_account_id);
        if (m.opportunity_id) activeOpportunityIds.add(m.opportunity_id);
      });

      const calculateMinutes = (meetingList: typeof memberMeetings) => {
        return meetingList.reduce((sum: number, m: any) => {
          if (m.end_time && m.start_time) {
            const minutes = differenceInMinutes(new Date(m.end_time), new Date(m.start_time));
            return sum + Math.max(0, minutes);
          }
          return sum + 45;
        }, 0);
      };

      const selectedMinutes = calculateMinutes(memberMeetings);
      const totalMeetingCount = memberMeetings.length;

      // Hours this week (for the hoursPerWeek column)
      const weekStart = startOfWeek(now, { weekStartsOn: 1 });
      const meetingsThisWeek = memberMeetings.filter((m: any) => new Date(m.start_time) >= weekStart);
      const hoursThisWeek = calculateMinutes(meetingsThisWeek) / 60;

      // Hours per month
      const rangeDays = Math.max(1, Math.round((rangeEnd.getTime() - rangeStart.getTime()) / (1000 * 60 * 60 * 24)));
      const monthsInRange = Math.max(rangeDays / 30, 0.25);
      const hoursPerMonth = (selectedMinutes / 60) / monthsInRange;

      // Engagement quality
      const memberMeetingIds = new Set<string>();
      memberMeetings.forEach((m: any) => {
        if (m.id) memberMeetingIds.add(m.id);
        if (m.momentum_id) memberMeetingIds.add(m.momentum_id);
      });

      const meetingsWithTranscripts = new Set<string>();
      (transcripts || []).forEach((t: any) => {
        const fn = t.file_name;
        if (!fn || !fn.startsWith('momentum_')) return;
        const meetingId = fn.slice('momentum_'.length);
        if (memberMeetingIds.has(meetingId)) meetingsWithTranscripts.add(meetingId);
      });
      const memberNbas = nbas?.filter((n: any) => n.assigned_to?.toLowerCase() === email) || [];
      const completedNbas = memberNbas.filter((n: any) => n.status === 'completed');

      // Readiness average
      const memberOppIds = new Set(memberOpps.map((o: any) => o.opportunity_id));
      const memberReadiness = readinessData?.answers.filter((a: any) =>
        memberOppIds.has(a.opportunity_id) && a.answer
      ) || [];
      const totalQuestions = readinessData?.totalQuestions || 1;
      const answeredPerOpp = memberOppIds.size > 0
        ? memberReadiness.length / memberOppIds.size
        : 0;
      const readinessAverage = Math.round((answeredPerOpp / totalQuestions) * 100);

      return {
        email,
        name: member.full_name,
        userId: member.user_id,
        depth: member.depth,
        accountCount: activeAccountIds.size,
        opportunityCount: activeOpportunityIds.size,
        pipelineValue,
        meetingCount30d: totalMeetingCount,
        meetingCount60d: totalMeetingCount,
        meetingCount90d: totalMeetingCount,
        totalMeetingMinutes30d: selectedMinutes,
        totalMeetingMinutes60d: selectedMinutes,
        totalMeetingMinutes90d: selectedMinutes,
        avgMeetingDuration: totalMeetingCount > 0
          ? Math.round(selectedMinutes / totalMeetingCount)
          : 0,
        hoursPerWeek: Math.round(hoursThisWeek * 10) / 10,
        hoursPerMonth: Math.round(hoursPerMonth * 10) / 10,
        transcriptsProcessed: meetingsWithTranscripts.size,
        nbasCreated: memberNbas.length,
        nbasCompleted: completedNbas.length,
        readinessAverage,
      };
    });
  }, [
    hierarchyTeamMembers,
    accountAssignments,
    opportunityAssignments,
    meetings,
    transcripts,
    nbas,
    readinessData,
    rangeKey,
    rangeStart,
    rangeEnd,
  ]);

  // Calculate team totals
  const teamTotals = useMemo(() => {
    if (!metrics.length) return null;

    const teamEmailSet = new Set(teamEmails);
    const teamNameSet = new Set(
      (hierarchyTeamMembers || [])
        .map(m => normalizePersonName(m.full_name || m.email.split('@')[0]?.replace(/[._-]+/g, ' ')))
        .filter(Boolean) as string[]
    );

    const uniqueMeetingIds = new Set<string>();
    (meetings || []).forEach((m: any) => {
      const isTeamHostEmail = m.host_email && teamEmailSet.has(m.host_email.toLowerCase());
      const isTeamAttendeeEmail = Array.isArray(m.attendees) &&
        (m.attendees as Array<{ email?: string }>).some(a => a.email && teamEmailSet.has(a.email.toLowerCase()));

      const hostName = normalizePersonName(m.host_name);
      const assignedName = normalizePersonName(extractAssignedNameFromNotes(m.notes));
      const isTeamHostName = !!hostName && teamNameSet.has(hostName);
      const isTeamAssignedName = !!assignedName && teamNameSet.has(assignedName);
      const isTeamAttendeeName = Array.isArray(m.attendees) &&
        (m.attendees as Array<{ name?: string }>).some(a => {
          const attendeeName = normalizePersonName(a.name);
          return attendeeName && teamNameSet.has(attendeeName);
        });

      if (isTeamHostEmail || isTeamAttendeeEmail || isTeamHostName || isTeamAssignedName || isTeamAttendeeName) {
        uniqueMeetingIds.add(m.id);
      }
    });

    return {
      totalAccounts: metrics.reduce((sum, m) => sum + m.accountCount, 0),
      totalOpportunities: metrics.reduce((sum, m) => sum + m.opportunityCount, 0),
      totalPipeline: metrics.reduce((sum, m) => sum + m.pipelineValue, 0),
      totalMeetings: uniqueMeetingIds.size,
      avgHoursPerWeek: metrics.length > 0
        ? Math.round((metrics.reduce((sum, m) => sum + m.hoursPerWeek, 0) / metrics.length) * 10) / 10
        : 0,
      totalTranscripts: metrics.reduce((sum, m) => sum + m.transcriptsProcessed, 0),
      totalNbas: metrics.reduce((sum, m) => sum + m.nbasCreated, 0),
      avgReadiness: metrics.length > 0
        ? Math.round(metrics.reduce((sum, m) => sum + m.readinessAverage, 0) / metrics.length)
        : 0,
    };
  }, [metrics, meetings, teamEmails, hierarchyTeamMembers]);

  const isLoading = teamLoading ||
    (teamEmails.length > 0 && (accountsLoading || oppsLoading || meetingsLoading || nbasLoading || transcriptsLoading)) ||
    ((opportunityAssignments?.length || 0) > 0 && readinessLoading);

  return {
    metrics,
    teamTotals,
    isLoading,
  };
}

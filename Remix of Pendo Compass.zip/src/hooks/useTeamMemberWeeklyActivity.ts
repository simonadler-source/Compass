import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useMemo } from 'react';
import { startOfWeek, endOfWeek, format, eachDayOfInterval, parseISO, differenceInMinutes } from 'date-fns';

export interface DayActivity {
  date: Date;
  dayName: string;
  meetings: {
    id: string;
    title: string;
    startTime: Date;
    durationMinutes: number;
    accountName?: string;
    hasTranscript: boolean;
    transcriptAnalyzed: boolean;
    isManual?: boolean;
    meetingType?: string;
  }[];
  nbas: {
    id: string;
    action: string;
    status: string;
    accountName?: string;
  }[];
  meetingMinutes: number;
  nbaCount: number;
  nbaCompletedCount: number;
}

export interface WeeklyActivity {
  days: DayActivity[];
  totalMeetingMinutes: number;
  totalMeetings: number;
  totalNbas: number;
  totalNbasCompleted: number;
  activeOpportunitiesCount: number;
  activeAccounts: { id: string; name: string }[];
}

const normalizePersonName = (value?: string | null) =>
  (value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();

const extractAssignedNameFromNotes = (notes?: string | null) => {
  if (!notes) return null;
  const match = notes.match(/(?:^|\n)\s*Assigned:\s*(.+?)\s*(?:\n|$)/i);
  return match?.[1]?.trim() || null;
};

const meetingMatchesMember = (meeting: any, memberEmail: string, memberName?: string | null) => {
  const normalizedEmail = memberEmail.toLowerCase().trim();
  const normalizedMemberName = normalizePersonName(memberName);
  const emailAlias = normalizePersonName(normalizedEmail.split('@')[0]?.replace(/[._-]+/g, ' '));
  const candidateNames = new Set<string>(
    [normalizedMemberName, emailAlias].filter(Boolean) as string[]
  );

  const isHost = meeting.host_email?.toLowerCase() === normalizedEmail;
  const isAttendeeByEmail = Array.isArray(meeting.attendees) &&
    (meeting.attendees as Array<{ email?: string }>).some(
      a => a.email?.toLowerCase() === normalizedEmail
    );

  if (isHost || isAttendeeByEmail) return true;
  if (candidateNames.size === 0) return false;

  const hostName = normalizePersonName(meeting.host_name);
  if (hostName && candidateNames.has(hostName)) return true;

  const isAttendeeByName = Array.isArray(meeting.attendees) &&
    (meeting.attendees as Array<{ name?: string }>).some(a => {
      const attendeeName = normalizePersonName(a.name);
      return attendeeName && candidateNames.has(attendeeName);
    });
  if (isAttendeeByName) return true;

  const assignedFromNotes = normalizePersonName(extractAssignedNameFromNotes(meeting.notes));
  return !!assignedFromNotes && candidateNames.has(assignedFromNotes);
};

export function useTeamMemberWeeklyActivity(
  memberEmail: string,
  enabled: boolean = true,
  weekOffset: number = 0,
  memberName?: string | null,
) {
  const now = new Date();
  const baseDate = new Date(now);
  baseDate.setDate(baseDate.getDate() + weekOffset * 7);
  const weekStart = startOfWeek(baseDate, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(baseDate, { weekStartsOn: 1 });

  // Fetch ALL meetings (both recorded and manual) from momentum_meetings
  const { data: meetings, isLoading: meetingsLoading } = useQuery({
    queryKey: ['weekly-activity-meetings', memberEmail, format(weekStart, 'yyyy-MM-dd')],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('momentum_meetings')
        .select(`
          id,
          title,
          start_time,
          end_time,
          host_email,
          host_name,
          attendees,
          notes,
          matched_account_id,
          opportunity_id,
          meeting_context,
          manual_meeting_type,
          accounts:matched_account_id (name),
          transcript_reviews!transcript_reviews_momentum_meeting_id_fkey (id, status)
        `)
        .gte('start_time', weekStart.toISOString())
        .lte('start_time', weekEnd.toISOString())
        .eq('status', 'imported')
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: enabled && !!memberEmail,
  });

  // Fetch NBAs for this week
  const { data: nbas, isLoading: nbasLoading } = useQuery({
    queryKey: ['weekly-activity-nbas', memberEmail, format(weekStart, 'yyyy-MM-dd')],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('account_nbas')
        .select(`
          id,
          action,
          status,
          created_at,
          updated_at,
          due_date,
          account_id,
          accounts:account_id (name)
        `)
        .eq('assigned_to', memberEmail.toLowerCase())
        .or(
          `and(created_at.gte.${weekStart.toISOString()},created_at.lte.${weekEnd.toISOString()}),and(updated_at.gte.${weekStart.toISOString()},updated_at.lte.${weekEnd.toISOString()}),and(due_date.gte.${format(weekStart, 'yyyy-MM-dd')},due_date.lte.${format(weekEnd, 'yyyy-MM-dd')})`
        )
        .execute();

      if (error) throw new Error(getErrorMessage(error));
      return data || [];
    },
    enabled: enabled && !!memberEmail,
  });

  const weeklyActivity = useMemo<WeeklyActivity>(() => {
    const email = memberEmail.toLowerCase();
    const daysOfWeek = eachDayOfInterval({ start: weekStart, end: weekEnd });

    // Filter meetings where member is host/attendee by email, or by imported manual assigned name fallback.
    const memberMeetings = (meetings || []).filter((m: any) =>
      meetingMatchesMember(m, email, memberName)
    );

    const days: DayActivity[] = daysOfWeek.map(day => {
      const dayStr = format(day, 'yyyy-MM-dd');

      const dayMeetings = memberMeetings.filter((m: any) =>
        format(parseISO(m.start_time), 'yyyy-MM-dd') === dayStr
      );

      const dayNbas = (nbas || []).filter((n: any) => {
        const createdDate = n.created_at ? format(parseISO(n.created_at), 'yyyy-MM-dd') : null;
        const updatedDate = n.updated_at ? format(parseISO(n.updated_at), 'yyyy-MM-dd') : null;
        const dueDate = n.due_date ? format(parseISO(n.due_date), 'yyyy-MM-dd') : null;
        return createdDate === dayStr || updatedDate === dayStr || dueDate === dayStr;
      });

      const meetingMinutes = dayMeetings.reduce((sum: number, m: any) => {
        if (m.end_time && m.start_time) {
          const minutes = differenceInMinutes(parseISO(m.end_time), parseISO(m.start_time));
          return sum + Math.max(0, minutes);
        }
        return sum + 45;
      }, 0);

      return {
        date: day,
        dayName: format(day, 'EEE'),
        meetings: dayMeetings.map((m: any) => {
          const transcripts = Array.isArray(m.transcript_reviews) ? m.transcript_reviews : [];
          const isManual = m.meeting_context === 'manual';
          return {
            id: m.id,
            title: m.title,
            startTime: parseISO(m.start_time),
            durationMinutes: m.end_time && m.start_time
              ? Math.max(0, differenceInMinutes(parseISO(m.end_time), parseISO(m.start_time)))
              : 45,
            accountName: (m.accounts as { name: string } | null)?.name,
            hasTranscript: !isManual && transcripts.length > 0,
            transcriptAnalyzed: !isManual && transcripts.some((t: any) => t.status === 'analyzed'),
            isManual,
            meetingType: m.manual_meeting_type,
          };
        }),
        nbas: dayNbas.map((n: any) => ({
          id: n.id,
          action: n.action,
          status: n.status || 'pending',
          accountName: (n.accounts as { name: string } | null)?.name,
        })),
        meetingMinutes,
        nbaCount: dayNbas.length,
        nbaCompletedCount: dayNbas.filter((n: any) => n.status === 'completed').length,
      };
    });

    const activeAccounts = new Map<string, string>();
    const activeOpportunities = new Set<string>();

    memberMeetings.forEach((m: any) => {
      const accId = m.matched_account_id;
      const accName = (m.accounts as { name: string } | null)?.name;
      if (accId && accName) activeAccounts.set(accId, accName);
      if (m.opportunity_id) activeOpportunities.add(m.opportunity_id);
    });

    return {
      days,
      totalMeetingMinutes: days.reduce((sum, d) => sum + d.meetingMinutes, 0),
      totalMeetings: days.reduce((sum, d) => sum + d.meetings.length, 0),
      totalNbas: days.reduce((sum, d) => sum + d.nbaCount, 0),
      totalNbasCompleted: days.reduce((sum, d) => sum + d.nbaCompletedCount, 0),
      activeOpportunitiesCount: activeOpportunities.size,
      activeAccounts: Array.from(activeAccounts, ([id, name]) => ({ id, name })),
    };
  }, [meetings, nbas, memberEmail, memberName, weekStart, weekEnd]);

  return {
    weeklyActivity,
    isLoading: meetingsLoading || nbasLoading,
    weekStart,
    weekEnd,
  };
}

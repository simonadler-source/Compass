import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { gateway } from '@/lib/apiGateway';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface TeamMember {
  id: string;
  manager_id: string;
  member_email: string;
  member_name: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface HierarchyTeamMember {
  user_id: string;
  depth: number;
  email: string;
  full_name: string | null;
}

export function useTeamMembers() {
  const { effectiveUserId, effectiveUserEmail } = useAuth();
  const queryClient = useQueryClient();

  // Legacy team_members table - still used for backward compatibility
  const { data: legacyTeamMembers, isLoading: legacyLoading } = useQuery({
    queryKey: ['team-members', effectiveUserId],
    queryFn: async () => {
      if (!effectiveUserId) return [];
      
      const result = await gateway.from('team_members')
        .select('*')
        .eq('manager_id', effectiveUserId)
        .eq('is_active', true)
        .order('member_name', { ascending: true })
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data as TeamMember[];
    },
    enabled: !!effectiveUserId,
  });

  // New hierarchy-based team members - uses get_team_members to include direct reports downward only
  // Note: RPC calls still use supabase directly as they're not simple CRUD
  const { data: hierarchyTeamIds, isLoading: hierarchyIdsLoading } = useQuery({
    queryKey: ['my-team-members', effectiveUserId],
    queryFn: async () => {
      if (!effectiveUserId) return [];

      // Use get_team_members which returns only direct reports recursively (not peers or managers)
      const { data, error } = await supabase
        .rpc('get_team_members', { _manager_id: effectiveUserId });

      if (error) throw error;
      return data as Array<{ user_id: string; depth: number }>;
    },
    enabled: !!effectiveUserId,
  });

  // Fetch profile data for hierarchy team members
  const { data: hierarchyTeamMembers, isLoading: hierarchyProfilesLoading } = useQuery({
    queryKey: ['hierarchy-team-profiles', hierarchyTeamIds],
    queryFn: async () => {
      if (!hierarchyTeamIds?.length) return [];

      const userIds = hierarchyTeamIds.map(t => t.user_id);
      const result = await gateway.from('profiles')
        .select('id, email, full_name')
        .in('id', userIds)
        .execute();

      if (result.error) throw new Error(result.error.message);
      
      // Merge with depth info
      return (result.data || []).map((profile: any) => {
        const hierarchyInfo = hierarchyTeamIds.find(t => t.user_id === profile.id);
        return {
          user_id: profile.id,
          email: profile.email,
          full_name: profile.full_name,
          depth: hierarchyInfo?.depth || 1,
        } as HierarchyTeamMember;
      });
    },
    enabled: (hierarchyTeamIds?.length || 0) > 0,
  });

  // Only count hierarchyLoading if the query is actually enabled
  const hierarchyLoading = hierarchyIdsLoading || 
    ((hierarchyTeamIds?.length || 0) > 0 && hierarchyProfilesLoading);

  // Legacy mutations for backward compatibility (use actual user, not impersonated)
  const { user } = useAuth();
  
  const addMember = useMutation({
    mutationFn: async ({ email, name }: { email: string; name?: string }) => {
      if (!user) throw new Error('Not authenticated');
      
      const result = await gateway.from('team_members')
        .insert({
          manager_id: user.id,
          member_email: email.toLowerCase().trim(),
          member_name: name || null,
        })
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      return result.data?.[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['team-members'] });
      toast.success('Team member added');
    },
    onError: (error: any) => {
      if (error.message?.includes('23505')) {
        toast.error('Team member already exists');
      } else {
        toast.error('Failed to add team member');
      }
    },
  });

  const removeMember = useMutation({
    mutationFn: async (memberId: string) => {
      const result = await gateway.from('team_members')
        .update({ is_active: false })
        .eq('id', memberId)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['team-members'] });
      toast.success('Team member removed');
    },
    onError: () => {
      toast.error('Failed to remove team member');
    },
  });

  const updateMember = useMutation({
    mutationFn: async ({ id, name }: { id: string; name: string }) => {
      const result = await gateway.from('team_members')
        .update({ member_name: name })
        .eq('id', id)
        .execute();
      
      if (result.error) throw new Error(result.error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['team-members'] });
    },
  });

  // Combine legacy and hierarchy team emails
  const legacyEmails = legacyTeamMembers?.map(m => m.member_email.toLowerCase()) || [];
  const hierarchyEmails = hierarchyTeamMembers?.map(m => m.email.toLowerCase()) || [];
  const teamEmails = [...new Set([...legacyEmails, ...hierarchyEmails])];

  // Combined team members (prefer hierarchy but include legacy)
  const teamMembers = legacyTeamMembers || [];

  // Include self in team emails for dashboard (use effective user email for impersonation)
  const teamEmailsWithSelf = effectiveUserEmail 
    ? [...new Set([effectiveUserEmail.toLowerCase(), ...teamEmails])]
    : teamEmails;

  return {
    teamMembers,
    hierarchyTeamMembers,
    teamEmails,
    teamEmailsWithSelf,
    isLoading: legacyLoading || hierarchyIdsLoading || hierarchyLoading,
    error: null,
    addMember,
    removeMember,
    updateMember,
  };
}

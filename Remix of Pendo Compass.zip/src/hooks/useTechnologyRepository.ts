import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { toast } from 'sonner';

export interface TechnologyRepoItem {
  id: string; name: string; description: string | null; logo_url: string | null;
  website_url: string | null; functional_area: string; layer: string;
  capabilities: string[] | null; is_competitor: boolean; competitor_overlap: string | null;
  competitor_id: string | null; status: string; created_at: string; updated_at: string;
  parent_company: string | null; is_customer: boolean; customer_notes: string | null;
  technology_type: 'vendor' | 'category' | 'concept'; parent_category_id: string | null;
  aliases: string[] | null;
  competing_module_ids: string[] | null; // Module pricing IDs this technology competes with
  detection_rule_id: string | null; // Linked detection rule (forward link)
  create_detection_rule: boolean; // Opt-in toggle for auto rule creation
}

export interface TechnologyRelationship {
  id: string; technology_id: string; related_technology_id: string;
  relationship_type: 'alternative' | 'competitor' | 'acquired_by' | 'integrates_with';
  notes: string | null; created_at: string;
}

export interface FunctionalArea {
  id: string; name: string; description: string | null; layer: string;
  default_width: number; default_height: number; color: string;
  sort_order: number; created_at: string;
}

export function useTechnologyRepository(searchQuery?: string, includeStatus?: 'all' | 'approved' | 'draft', techType?: 'all' | 'vendor' | 'category' | 'concept') {
  return useQuery({
    queryKey: ['technology-repository', searchQuery, includeStatus, techType],
    queryFn: async () => {
      let query = gateway.from<TechnologyRepoItem[]>('technology_repository').select('*').order('technology_type').order('functional_area').order('name');
      if (includeStatus && includeStatus !== 'all') query = query.eq('status', includeStatus);
      if (techType && techType !== 'all') query = query.eq('technology_type', techType);
      if (searchQuery) query = query.or(`name.ilike.%${searchQuery}%,functional_area.ilike.%${searchQuery}%,capabilities.cs.{${searchQuery}},aliases.cs.{${searchQuery}}`);
      const { data, error } = await query.execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as TechnologyRepoItem[];
    },
  });
}

export function useTechnologyRelationships(technologyId?: string) {
  return useQuery({
    queryKey: ['technology-relationships', technologyId],
    queryFn: async () => {
      let query = gateway.from('technology_relationships').select(`*, related_tech:technology_repository!technology_relationships_related_technology_id_fkey(id, name, logo_url)`);
      if (technologyId) query = query.or(`technology_id.eq.${technologyId},related_technology_id.eq.${technologyId}`);
      const { data, error } = await query.execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    enabled: !!technologyId,
  });
}

export function useAddTechnologyRelationship() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (relationship: Omit<TechnologyRelationship, 'id' | 'created_at'>) => {
      const { data, error } = await gateway.from('technology_relationships').insert(relationship).single().execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['technology-relationships'] }); toast.success('Relationship added'); },
    onError: (error) => { toast.error('Failed to add relationship: ' + error.message); },
  });
}

export function useRemoveTechnologyRelationship() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway.from('technology_relationships').delete().eq('id', id).execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['technology-relationships'] }); toast.success('Relationship removed'); },
    onError: (error) => { toast.error('Failed to remove relationship: ' + error.message); },
  });
}

export function useTechnologyCategories() {
  return useQuery({
    queryKey: ['technology-categories'],
    queryFn: async () => {
      const { data, error } = await gateway.from('technology_repository').select('id, name').eq('technology_type', 'category').order('name').execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
  });
}

export function useCreateDraftTechnology() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (name: string, functionalArea?: string) => {
      const { data: existing } = await gateway.from('technology_repository').select('id').ilike('name', name).maybeSingle().execute();
      if (existing) return existing;
      const { data, error } = await gateway.from('technology_repository').insert({ name, functional_area: functionalArea || 'Other', layer: 'adopt', status: 'draft', is_competitor: false }).single().execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['technology-repository'] }); },
  });
}

export function useGetOrCreateTechnology() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ name, functionalArea }: { name: string; functionalArea?: string }) => {
      const { data: existing } = await gateway.from('technology_repository').select('*').ilike('name', name).maybeSingle().execute();
      if (existing) return existing as TechnologyRepoItem;
      const { data, error } = await gateway.from('technology_repository').insert({ name, functional_area: functionalArea || 'Other', layer: 'adopt', status: 'draft', is_competitor: false }).single().execute();
      if (error) throw new Error(getErrorMessage(error));
      toast.success(`Added "${name}" as draft technology`);
      return data as TechnologyRepoItem;
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['technology-repository'] }); },
  });
}

export function useFunctionalAreas() {
  return useQuery({
    queryKey: ['functional-areas'],
    queryFn: async () => {
      const { data, error } = await gateway.from('functional_areas').select('*').order('layer').order('sort_order').execute();
      if (error) throw new Error(getErrorMessage(error));
      return data as FunctionalArea[];
    },
  });
}

export function useCreateFunctionalArea() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (area: Omit<FunctionalArea, 'id' | 'created_at'>) => {
      const { data, error } = await gateway.from('functional_areas').insert(area).single().execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['functional-areas'] }); toast.success('Functional area created'); },
    onError: (error) => { toast.error('Failed to create functional area: ' + error.message); },
  });
}

export function useUpdateFunctionalArea() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<FunctionalArea> & { id: string }) => {
      const { data, error } = await gateway.from('functional_areas').update(updates).eq('id', id).single().execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['functional-areas'] }); toast.success('Functional area updated'); },
    onError: (error) => { toast.error('Failed to update functional area: ' + error.message); },
  });
}

export function useDeleteFunctionalArea() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await gateway.from('functional_areas').delete().eq('id', id).execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['functional-areas'] }); toast.success('Functional area deleted'); },
    onError: (error) => { toast.error('Failed to delete functional area: ' + error.message); },
  });
}

export function useCreateRepositoryTechnology() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (tech: Omit<TechnologyRepoItem, 'id' | 'created_at' | 'updated_at' | 'detection_rule_id'>) => {
      const { data: existing } = await gateway.from('technology_repository').select('id, name, functional_area').ilike('name', tech.name).maybeSingle().execute();
      if (existing) {
        const existingAreas = existing.functional_area?.split(',').map((a: string) => a.trim().toLowerCase()) || [];
        const newAreas = tech.functional_area?.split(',').map(a => a.trim().toLowerCase()) || [];
        const overlappingAreas = newAreas.filter(a => existingAreas.includes(a));
        if (overlappingAreas.length > 0) throw new Error(`"${tech.name}" already exists in ${overlappingAreas.join(', ')}`);
        throw new Error(`"${tech.name}" already exists in the technology library`);
      }
      const { data, error } = await gateway.from('technology_repository').insert(tech).single().execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['technology-repository'] }); toast.success('Technology added to repository'); },
    onError: (error) => { toast.error(error.message); },
  });
}

export function useUpdateRepositoryTechnology() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<TechnologyRepoItem> & { id: string }) => {
      const { data, error } = await gateway.from('technology_repository').update(updates).eq('id', id).single().execute();
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['technology-repository'] }); },
    onError: (error) => { toast.error('Failed to update technology: ' + error.message); },
  });
}

export function useDeleteRepositoryTechnology() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      // First, unlink any account_technologies that reference this technology
      const { error: unlinkError } = await gateway.from('account_technologies')
        .update({ repository_tech_id: null })
        .eq('repository_tech_id', id)
        .execute();
      if (unlinkError) throw new Error(getErrorMessage(unlinkError));
      
      // Also remove any technology relationships
      const { error: relError1 } = await gateway.from('technology_relationships')
        .delete()
        .eq('technology_id', id)
        .execute();
      if (relError1) throw new Error(getErrorMessage(relError1));
      
      const { error: relError2 } = await gateway.from('technology_relationships')
        .delete()
        .eq('related_technology_id', id)
        .execute();
      if (relError2) throw new Error(getErrorMessage(relError2));
      
      // Now delete the technology from repository
      const { error } = await gateway.from('technology_repository').delete().eq('id', id).execute();
      if (error) throw new Error(getErrorMessage(error));
    },
    onSuccess: () => { 
      queryClient.invalidateQueries({ queryKey: ['technology-repository'] }); 
      queryClient.invalidateQueries({ queryKey: ['technology-relationships'] });
      toast.success('Technology removed from repository'); 
    },
    onError: (error) => { toast.error('Failed to delete technology: ' + error.message); },
  });
}

import { useQuery } from '@tanstack/react-query';
import { gateway } from '@/lib/apiGateway';

export interface ThemedUseCase {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  use_case: string;
  functional_area: string;
  business_theme: string | null;
  theme_confidence: number | null;
  priority: string | null;
  status: string;
  confidence_score: number | null;
  validation_count: number | null;
  last_validated_at: string | null;
  created_at: string;
}

export function useThemedUseCases(accountId: string | null) {
  return useQuery({
    queryKey: ['themed-use-cases', accountId],
    queryFn: async () => {
      if (!accountId) return [];
      
      const result = await gateway.from('account_use_cases')
        .select('*')
        .eq('account_id', accountId)
        .order('priority', { ascending: true })
        .execute();
      
      if (result.error) throw new Error(result.error.message);
      
      // Sort by confidence_score as secondary sort
      const data = (result.data as ThemedUseCase[]) || [];
      return data.sort((a, b) => {
        const priorityOrder: Record<string, number> = { high: 0, medium: 1, low: 2 };
        const aPriority = priorityOrder[a.priority || 'low'] ?? 2;
        const bPriority = priorityOrder[b.priority || 'low'] ?? 2;
        if (aPriority !== bPriority) return aPriority - bPriority;
        return (b.confidence_score || 0) - (a.confidence_score || 0);
      });
    },
    enabled: !!accountId,
  });
}

// Group use cases by business theme
export function groupUseCasesByTheme(useCases: ThemedUseCase[]): Record<string, ThemedUseCase[]> {
  const grouped: Record<string, ThemedUseCase[]> = {};
  
  for (const uc of useCases) {
    const theme = uc.business_theme || 'uncategorized';
    if (!grouped[theme]) {
      grouped[theme] = [];
    }
    grouped[theme].push(uc);
  }
  
  return grouped;
}

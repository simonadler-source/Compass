import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

export interface TreeTriageConfig {
  tree_id: string;
  name: string;
  description: string | null;
  triage_enabled: boolean;
  triage_keywords: string[];
  triage_prompt: string | null;
  triage_context_field: string | null;
}

export function useTreeTriageConfig(treeId: string | null) {
  return useQuery({
    queryKey: ['tree-triage-config', treeId],
    queryFn: async () => {
      const { data, error } = await gateway
        .from('detection_tree_config')
        .select('*')
        .eq('tree_id', treeId!)
        .maybeSingle()
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data as TreeTriageConfig | null;
    },
    enabled: !!treeId,
  });
}

export function useUpsertTreeTriageConfig() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (config: {
      tree_id: string;
      name: string;
      description?: string | null;
      triage_enabled: boolean;
      triage_keywords: string[];
      triage_prompt: string | null;
      triage_context_field: string | null;
    }) => {
      const { data, error } = await gateway
        .from('detection_tree_config')
        .upsert({
          tree_id: config.tree_id,
          name: config.name,
          description: config.description || null,
          triage_enabled: config.triage_enabled,
          triage_keywords: config.triage_keywords,
          triage_prompt: config.triage_prompt,
          triage_context_field: config.triage_context_field,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'tree_id' })
        .select()
        .single()
        .execute();
      
      if (error) throw new Error(getErrorMessage(error));
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['tree-triage-config', variables.tree_id] });
    },
  });
}

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useAuth } from '@/contexts/AuthContext';
import { useEffect, useState } from 'react';

// Now supports any role name (flexible roles system)
export type AppRole = string;

export interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  email_verified: boolean;
  mfa_enabled: boolean;
  status: 'pending' | 'active' | 'suspended' | 'identified';
  job_function: 'se' | 'ae' | 'manager' | null;
  created_at: string;
  updated_at: string;
  last_login_at: string | null;
  roles: AppRole[];
}

export function useUserRole() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [isCreatingProfile, setIsCreatingProfile] = useState(false);

  const { data: profile, isLoading: profileLoading, refetch: refetchProfile } = useQuery({
    queryKey: ['user-profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const response = await gateway.from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle()
        .execute();
      
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data;
    },
    enabled: !!user?.id,
    retry: 2, // Retry on transient failures
    retryDelay: (attemptIndex) => Math.min(1000 * (attemptIndex + 1), 3000),
  });

  // Create profile if it doesn't exist (runs once after initial query)
  useEffect(() => {
    const createProfile = async () => {
      if (!user?.id || !user?.email || profile !== null || profileLoading || isCreatingProfile) {
        return;
      }

      setIsCreatingProfile(true);
      try {
        // Check if any profiles exist (first user becomes admin)
        const countResponse = await gateway.from('profiles')
          .select('*')
          .limit(1)
          .execute();
        
        const isFirstUser = !countResponse.data || countResponse.data.length === 0;
        
        // Create profile
        const { error: profileError } = await gateway.insert('profiles', {
          id: user.id,
          email: user.email,
          email_verified: true, // Email is verified through our custom flow
          mfa_enabled: user.mfa_enabled || false,
          status: isFirstUser ? 'active' : 'pending',
        });
        
        if (profileError) {
          console.error('Failed to create profile:', profileError);
          return;
        }
        
        // If first user, also create admin role
        if (isFirstUser) {
          await gateway.insert('user_roles', {
            user_id: user.id,
            role: 'admin',
          });
        }
        
        // Refetch profile and roles
        queryClient.invalidateQueries({ queryKey: ['user-profile', user.id] });
        queryClient.invalidateQueries({ queryKey: ['user-roles', user.id] });
        refetchProfile();
      } catch (error) {
        console.error('Error creating profile:', error);
      } finally {
        setIsCreatingProfile(false);
      }
    };

    // Only try to create if profile query completed and returned null
    if (!profileLoading && profile === null && user?.id) {
      createProfile();
    }
  }, [user?.id, user?.email, profile, profileLoading, isCreatingProfile, queryClient, refetchProfile]);

  const { data: roles, isLoading: rolesLoading } = useQuery({
    queryKey: ['user-roles', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const response = await gateway.from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .execute();
      
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data?.map((r: any) => r.role as AppRole) || [];
    },
    enabled: !!user?.id,
    retry: 2, // Retry on transient failures
    retryDelay: (attemptIndex) => Math.min(1000 * (attemptIndex + 1), 3000),
  });

  const isAdmin = roles?.includes('admin') ?? false;
  const isManager = roles?.includes('manager') || isAdmin;
  const isSE = roles?.includes('se') ?? false;
  const isAE = roles?.includes('ae') ?? false;
  const isProduct = roles?.includes('product') ?? false;
  const isActive = profile?.status === 'active';
  const isEmailVerified = profile?.email_verified ?? false;
  const isMfaEnabled = profile?.mfa_enabled ?? false;

  return {
    profile,
    roles: roles || [],
    isAdmin,
    isManager,
    isSE,
    isAE,
    isProduct,
    isActive,
    isEmailVerified,
    isMfaEnabled,
    isLoading: profileLoading || rolesLoading || isCreatingProfile,
  };
}

export function useAllUsers() {
  return useQuery({
    queryKey: ['all-users'],
    queryFn: async () => {
      // Fetch all profiles
      const profilesResponse = await gateway.from('profiles')
        .select('*')
        .order('created_at', { ascending: false })
        .execute();
      
      if (profilesResponse.error) throw new Error(getErrorMessage(profilesResponse.error));
      const profiles = profilesResponse.data || [];

      // Fetch all roles
      const rolesResponse = await gateway.from('user_roles')
        .select('user_id, role')
        .execute();
      
      if (rolesResponse.error) throw new Error(getErrorMessage(rolesResponse.error));
      const allRoles = rolesResponse.data || [];

      // Combine profiles with roles
      const usersWithRoles: UserProfile[] = (profiles || []).map((profile: any) => ({
        ...profile,
        status: profile.status as 'pending' | 'active' | 'suspended' | 'identified',
        job_function: ((profile as any).job_function as 'se' | 'ae' | 'manager') || null,
        roles: allRoles
          ?.filter((r: any) => r.user_id === profile.id)
          .map((r: any) => r.role as AppRole) || [],
      }));

      return usersWithRoles;
    },
  });
}

import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';
import { useAccountUseCases } from './useAccountUseCases';
import { useModulePricing, useUseCaseTemplateProducts } from './useModulePricing';

export interface ValueMapNode {
  id: string;
  type: 'pendo-module' | 'functional-area' | 'use-case' | 'technology';
  name: string;
  category?: string;
  layer?: string;
  status: 'accepted' | 'validated' | 'proposed' | 'whitespace';
  moduleType?: 'platform' | 'mau' | 'module';
  potentialRevenue?: number;
  linkedUseCases?: string[];
  linkedModules?: string[];
  description?: string;
}

export interface ValueMapConnection {
  id: string;
  source: string;
  target: string;
  sourceType: 'pendo-module' | 'functional-area' | 'use-case' | 'technology';
  targetType: 'pendo-module' | 'functional-area' | 'use-case' | 'technology';
  status: 'active' | 'potential';
  label?: string;
}

export interface ValueMapData {
  pendoModules: ValueMapNode[];
  functionalAreas: ValueMapNode[];
  useCases: ValueMapNode[];
  technologies: ValueMapNode[];
  connections: ValueMapConnection[];
  stats: {
    acceptedCount: number;
    validatedCount: number;
    proposedCount: number;
    whitespaceCount: number;
    totalPotentialRevenue: number;
    coveragePercent: number;
  };
}

export function useValueMapData(accountId: string, opportunityId?: string) {
  const { data: accountUseCases, isLoading: useCasesLoading } = useAccountUseCases(accountId);
  const { data: modulePricing, isLoading: pricingLoading } = useModulePricing();
  const { data: templateProducts, isLoading: templateProductsLoading } = useUseCaseTemplateProducts();

  // Fetch functional areas
  const { data: functionalAreas, isLoading: areasLoading } = useQuery({
    queryKey: ['functional-areas-value-map'],
    queryFn: async () => {
      const response = await gateway.from('functional_areas')
        .select('id, name, layer, color, description')
        .order('sort_order')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as { id: string; name: string; layer: string; color: string | null; description: string | null }[];
    },
  });

  // Fetch use case templates
  const { data: useCaseTemplates, isLoading: templatesLoading } = useQuery({
    queryKey: ['use-case-templates-value-map'],
    queryFn: async () => {
      const response = await gateway.from('use_case_templates')
        .select('id, name, functional_area_id, business_outcome, description')
        .eq('is_active', true)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as { id: string; name: string; functional_area_id: string; business_outcome: string | null; description: string | null }[];
    },
  });

  // Fetch account technologies
  const { data: accountTechnologies, isLoading: techLoading } = useQuery({
    queryKey: ['account-technologies-value-map', accountId],
    queryFn: async () => {
      const response = await gateway.from('account_technologies')
        .select('id, name, layer, category, relationship_status, repository_tech_id')
        .eq('account_id', accountId)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as { id: string; name: string; layer: string; category: string; relationship_status: string | null; repository_tech_id: string | null }[];
    },
    enabled: !!accountId,
  });

  // Fetch opportunity included modules if opportunityId provided
  const { data: opportunityData, isLoading: oppLoading } = useQuery({
    queryKey: ['opportunity-included-modules', opportunityId],
    queryFn: async () => {
      const response = await gateway.from('opportunities')
        .select('included_module_ids')
        .eq('id', opportunityId!)
        .maybeSingle();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as { included_module_ids: string[] | null } | null;
    },
    enabled: !!opportunityId,
  });

  const valueMapData = useMemo<ValueMapData | null>(() => {
    if (!accountUseCases || !modulePricing || !functionalAreas || !useCaseTemplates || !templateProducts) {
      return null;
    }

    const includedModuleIds = new Set(opportunityData?.included_module_ids || []);

    // Build template-to-module map
    const templateToModules = new Map<string, string[]>();
    templateProducts.forEach(tp => {
      const existing = templateToModules.get(tp.use_case_template_id) || [];
      existing.push(tp.module_pricing_id);
      templateToModules.set(tp.use_case_template_id, existing);
    });

    // Build module map
    const moduleMap = new Map(modulePricing.map(m => [m.id, m]));

    // Categorize account use cases by acceptance status
    const useCasesByStatus = {
      accepted: accountUseCases.filter(uc => uc.acceptance_status === 'accepted'),
      validated: accountUseCases.filter(uc => uc.acceptance_status === 'validated'),
      proposed: accountUseCases.filter(uc => uc.acceptance_status === 'proposed' || !uc.acceptance_status),
    };

    // Find covered template names
    const coveredTemplateNames = new Set(
      accountUseCases.map(uc => uc.use_case?.toLowerCase().trim()).filter(Boolean)
    );

    // Find whitespace templates (not covered by any account use case)
    const whitespaceTemplates = useCaseTemplates.filter(template => {
      const templateName = template.name.toLowerCase().trim();
      return !Array.from(coveredTemplateNames).some(ucName => 
        ucName?.includes(templateName) || templateName.includes(ucName || '')
      );
    });

    // Build Pendo modules nodes
    const pendoModules: ValueMapNode[] = modulePricing.map(module => {
      const linkedTemplates = useCaseTemplates.filter(template => {
        const moduleIds = templateToModules.get(template.id) || [];
        return moduleIds.includes(module.id);
      });

      const hasAcceptedUseCases = linkedTemplates.some(template => {
        const templateName = template.name.toLowerCase().trim();
        return useCasesByStatus.accepted.some(uc => 
          uc.use_case?.toLowerCase().includes(templateName) || templateName.includes(uc.use_case?.toLowerCase() || '')
        );
      });

      const hasValidatedUseCases = linkedTemplates.some(template => {
        const templateName = template.name.toLowerCase().trim();
        return useCasesByStatus.validated.some(uc => 
          uc.use_case?.toLowerCase().includes(templateName) || templateName.includes(uc.use_case?.toLowerCase() || '')
        );
      });

      const isInDeal = includedModuleIds.has(module.id);

      let status: 'accepted' | 'validated' | 'proposed' | 'whitespace' = 'whitespace';
      if (isInDeal || hasAcceptedUseCases) status = 'accepted';
      else if (hasValidatedUseCases) status = 'validated';
      else if (linkedTemplates.some(t => !whitespaceTemplates.includes(t))) status = 'proposed';

      return {
        id: module.id,
        type: 'pendo-module' as const,
        name: module.module_name,
        status,
        moduleType: module.module_type,
        linkedUseCases: linkedTemplates.map(t => t.id),
        description: module.description || undefined,
      };
    });

    // Build functional area nodes
    const functionalAreaNodes: ValueMapNode[] = functionalAreas.map(area => {
      const areaUseCases = accountUseCases.filter(uc => uc.functional_area === area.name);
      const hasAccepted = areaUseCases.some(uc => uc.acceptance_status === 'accepted');
      const hasValidated = areaUseCases.some(uc => uc.acceptance_status === 'validated');

      let status: 'accepted' | 'validated' | 'proposed' | 'whitespace' = 'whitespace';
      if (hasAccepted) status = 'accepted';
      else if (hasValidated) status = 'validated';
      else if (areaUseCases.length > 0) status = 'proposed';

      return {
        id: area.id,
        type: 'functional-area' as const,
        name: area.name,
        layer: area.layer,
        status,
        description: area.description || undefined,
      };
    });

    // Build use case nodes
    const useCaseNodes: ValueMapNode[] = accountUseCases.map(uc => ({
      id: uc.id,
      type: 'use-case' as const,
      name: uc.use_case || '',
      category: uc.functional_area,
      status: (uc.acceptance_status as 'accepted' | 'validated' | 'proposed') || 'proposed',
      description: uc.description || undefined,
    }));

    // Add whitespace use cases from templates
    whitespaceTemplates.forEach(template => {
      const area = functionalAreas.find(a => a.id === template.functional_area_id);
      useCaseNodes.push({
        id: `whitespace-${template.id}`,
        type: 'use-case',
        name: template.name,
        category: area?.name,
        status: 'whitespace',
        description: template.description || template.business_outcome || undefined,
        linkedModules: templateToModules.get(template.id),
      });
    });

    // Build technology nodes
    const technologyNodes: ValueMapNode[] = (accountTechnologies || []).map(tech => ({
      id: tech.id,
      type: 'technology' as const,
      name: tech.name,
      layer: tech.layer,
      category: tech.category,
      status: 'accepted' as const,
    }));

    // Build connections
    const connections: ValueMapConnection[] = [];

    // Connect use cases to functional areas
    useCaseNodes.forEach(uc => {
      const area = functionalAreaNodes.find(a => a.name === uc.category);
      if (area) {
        connections.push({
          id: `${uc.id}-to-${area.id}`,
          source: uc.id,
          target: area.id,
          sourceType: 'use-case',
          targetType: 'functional-area',
          status: uc.status === 'whitespace' ? 'potential' : 'active',
        });
      }
    });

    // Connect modules to use cases via templates
    pendoModules.forEach(module => {
      (module.linkedUseCases || []).forEach(templateId => {
        const template = useCaseTemplates.find(t => t.id === templateId);
        if (!template) return;

        // Find matching use case node
        const matchingUseCase = useCaseNodes.find(uc => {
          const ucName = uc.name.toLowerCase().trim();
          const templateName = template.name.toLowerCase().trim();
          return ucName.includes(templateName) || templateName.includes(ucName) || uc.id === `whitespace-${templateId}`;
        });

        if (matchingUseCase) {
          connections.push({
            id: `${module.id}-to-${matchingUseCase.id}`,
            source: module.id,
            target: matchingUseCase.id,
            sourceType: 'pendo-module',
            targetType: 'use-case',
            status: matchingUseCase.status === 'whitespace' ? 'potential' : 'active',
          });
        }
      });
    });

    // Connect technologies to functional areas
    technologyNodes.forEach(tech => {
      const area = functionalAreaNodes.find(a => a.name === tech.category);
      if (area) {
        connections.push({
          id: `${tech.id}-to-${area.id}`,
          source: tech.id,
          target: area.id,
          sourceType: 'technology',
          targetType: 'functional-area',
          status: 'active',
        });
      }
    });

    // Calculate stats
    const acceptedCount = useCaseNodes.filter(uc => uc.status === 'accepted').length;
    const validatedCount = useCaseNodes.filter(uc => uc.status === 'validated').length;
    const proposedCount = useCaseNodes.filter(uc => uc.status === 'proposed').length;
    const whitespaceCount = useCaseNodes.filter(uc => uc.status === 'whitespace').length;
    const totalUseCases = useCaseNodes.length;
    const coveragePercent = totalUseCases > 0 ? Math.round(((acceptedCount + validatedCount + proposedCount) / totalUseCases) * 100) : 0;

    return {
      pendoModules,
      functionalAreas: functionalAreaNodes,
      useCases: useCaseNodes,
      technologies: technologyNodes,
      connections,
      stats: {
        acceptedCount,
        validatedCount,
        proposedCount,
        whitespaceCount,
        totalPotentialRevenue: 0, // Calculate from whitespace
        coveragePercent,
      },
    };
  }, [accountUseCases, modulePricing, functionalAreas, useCaseTemplates, templateProducts, accountTechnologies, opportunityData]);

  return {
    data: valueMapData,
    isLoading: useCasesLoading || pricingLoading || areasLoading || templatesLoading || techLoading || templateProductsLoading || (opportunityId ? oppLoading : false),
  };
}

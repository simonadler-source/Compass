import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { gateway, getErrorMessage } from '@/lib/apiGateway';

export interface WhitespaceNBA {
  id: string;
  type: 'use_case_gap' | 'tech_gap' | 'low_coverage';
  action: string;
  priority: 'high' | 'medium' | 'low';
  functionalArea: string;
  functionalAreaId: string;
  discoveryQuestions: string[];
  reasoning: string;
  score: number;
  potentialRevenue?: number; // Revenue potential for this gap
  modules?: string[]; // Modules that could address this gap
}

interface FunctionalArea {
  id: string;
  name: string;
  layer: string;
}

interface UseCaseTemplate {
  id: string;
  name: string;
  description: string | null;
  functional_area_id: string;
}

interface AccountUseCase {
  id: string;
  use_case: string;
  functional_area: string;
}

interface AccountTechnology {
  id: string;
  name: string;
  category: string;
  repository_tech_id: string | null;
}

interface DiscoveryQuestion {
  id: string;
  question: string;
  functional_area_id: string;
  category: string | null;
}

interface Account {
  id: string;
  name: string;
  stage: string | null;
  arr: number | null;
  mau_count: number | null;
  base_mau_value: number | null;
  employee_count: number | null;
}

interface ModulePricing {
  id: string;
  module_name: string;
  module_type: string;
  fixed_cost: number;
  per_mau_cost: number;
  mau_percentage: number;
  discount_percentage: number;
}

interface UseCaseTemplateProduct {
  use_case_template_id: string;
  module_pricing_id: string;
}

interface TechRepoItem {
  id: string;
  competing_module_ids: string[] | null;
}

// Priority weights for functional areas
const functionalAreaPriority: Record<string, number> = {
  'CRM': 10,
  'Analytics & Insights': 9,
  'Digital Adoption & In-App Guides': 9,
  'Host Application': 8,
  'Roadmap & Feedback': 7,
  'Executive Dashboards & BI': 7,
  'Data Lake / Warehouse': 6,
  'Issue Tracking & Agile': 5,
  'Knowledge Base & Content': 5,
  'Learning Management System (LMS)': 4,
  'Financial & Planning Systems (ERP, FP&A)': 4,
  'Back Office Processes': 3,
  'Third-Party Apps': 3,
  'Pendo Javascript Snippet / SDK / API': 2,
};

// Stage multipliers for priority
const stageMultipliers: Record<string, number> = {
  'discovery': 1.2,
  'evaluation': 1.1,
  'customer': 0.8,
  'closed': 0.5,
};

function calculateScore(
  baseScore: number,
  account: Account | undefined,
  functionalAreaName: string,
  useCaseCount: number = 0
): number {
  const areaPriority = functionalAreaPriority[functionalAreaName] ?? 5;
  const stageMultiplier = stageMultipliers[account?.stage ?? 'discovery'] ?? 1;
  const arrMultiplier = account?.arr ? Math.min(1 + (account.arr / 100000) * 0.1, 1.5) : 1;
  
  // Use case count multiplier - more use cases = higher importance
  // Each use case adds 10% importance, capped at 2x multiplier
  const useCaseMultiplier = Math.min(1 + (useCaseCount * 0.1), 2);
  
  return Math.round(baseScore * areaPriority * stageMultiplier * arrMultiplier * useCaseMultiplier);
}

function scoreToPriority(score: number): 'high' | 'medium' | 'low' {
  if (score >= 70) return 'high';
  if (score >= 40) return 'medium';
  return 'low';
}

export function useWhitespaceNBAs(accountId: string) {
  // Fetch functional areas
  const { data: functionalAreas } = useQuery({
    queryKey: ['functional-areas'],
    queryFn: async () => {
      const response = await gateway.from<FunctionalArea>('functional_areas')
        .select('id, name, layer')
        .order('sort_order')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as FunctionalArea[];
    },
  });

  // Fetch use case templates
  const { data: useCaseTemplates } = useQuery({
    queryKey: ['use-case-templates'],
    queryFn: async () => {
      const response = await gateway.from<UseCaseTemplate>('use_case_templates')
        .select('id, name, description, functional_area_id')
        .eq('is_active', true)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as UseCaseTemplate[];
    },
  });

  // Fetch account use cases
  const { data: accountUseCases } = useQuery({
    queryKey: ['account-use-cases', accountId],
    queryFn: async () => {
      const response = await gateway.from<AccountUseCase>('account_use_cases')
        .select('id, use_case, functional_area')
        .eq('account_id', accountId)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as AccountUseCase[];
    },
    enabled: !!accountId,
  });

  // Fetch account technologies (include repository_tech_id for competing module lookup)
  const { data: accountTechnologies } = useQuery({
    queryKey: ['account-technologies-whitespace', accountId],
    queryFn: async () => {
      const response = await gateway.from<AccountTechnology>('account_technologies')
        .select('id, name, category, repository_tech_id')
        .eq('account_id', accountId)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as AccountTechnology[];
    },
    enabled: !!accountId,
  });

  // Fetch discovery questions
  const { data: discoveryQuestions } = useQuery({
    queryKey: ['discovery-questions'],
    queryFn: async () => {
      const response = await gateway.from<DiscoveryQuestion>('discovery_questions')
        .select('id, question, functional_area_id, category')
        .eq('is_active', true)
        .order('sort_order')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as DiscoveryQuestion[];
    },
  });

  // Fetch account details for scoring (including MAU for revenue calculation)
  const { data: account } = useQuery({
    queryKey: ['account-scoring-full', accountId],
    queryFn: async () => {
      const response = await gateway.from<Account>('accounts')
        .select('id, name, stage, arr, mau_count, base_mau_value, employee_count')
        .eq('id', accountId)
        .single()
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return response.data as Account;
    },
    enabled: !!accountId,
  });

  // Fetch module pricing for revenue calculation
  const { data: modulePricing } = useQuery({
    queryKey: ['module-pricing-whitespace'],
    queryFn: async () => {
      const response = await gateway.from<ModulePricing>('module_pricing')
        .select('id, module_name, module_type, fixed_cost, per_mau_cost, mau_percentage, discount_percentage')
        .eq('is_active', true)
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as ModulePricing[];
    },
  });

  // Fetch use case template to product mappings
  const { data: templateProducts } = useQuery({
    queryKey: ['template-products-whitespace'],
    queryFn: async () => {
      const response = await gateway.from<UseCaseTemplateProduct>('use_case_template_products')
        .select('use_case_template_id, module_pricing_id')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as UseCaseTemplateProduct[];
    },
  });

  // Fetch technology repository for competing module exclusions
  const { data: techRepository } = useQuery({
    queryKey: ['tech-repository-competing'],
    queryFn: async () => {
      const response = await gateway.from<TechRepoItem>('technology_repository')
        .select('id, competing_module_ids')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as TechRepoItem[];
    },
  });

  // Fetch global pricing settings
  const { data: pricingSettings } = useQuery({
    queryKey: ['pricing-settings-whitespace'],
    queryFn: async () => {
      const response = await gateway
        .from('pricing_settings')
        .select('setting_key, setting_value')
        .execute();
      if (response.error) throw new Error(getErrorMessage(response.error));
      return (response.data || []) as { setting_key: string; setting_value: number }[];
    },
  });

  // Parse global pricing settings
  const globalListPricePerMau = pricingSettings?.find(s => s.setting_key === 'list_price_per_mau')?.setting_value || 0.50;

  // Calculate whitespace NBAs
  const whitespaceNBAs = useMemo(() => {
    if (!functionalAreas || !accountId) return [];

    const nbas: WhitespaceNBA[] = [];
    const useCasesByArea = new Map<string, string[]>();
    const techsByArea = new Map<string, string[]>();
    
    // Group account use cases by functional area
    accountUseCases?.forEach(uc => {
      if (!uc.functional_area || !uc.use_case) return;
      const existing = useCasesByArea.get(uc.functional_area) || [];
      existing.push(uc.use_case.toLowerCase());
      useCasesByArea.set(uc.functional_area, existing);
    });

    // Group technologies by category (rough mapping to functional area)
    accountTechnologies?.forEach(tech => {
      if (!tech.category || !tech.name) return;
      const existing = techsByArea.get(tech.category) || [];
      existing.push(tech.name.toLowerCase());
      techsByArea.set(tech.category, existing);
    });

    // Get questions for a functional area
    const getQuestionsForArea = (areaId: string): string[] => {
      return discoveryQuestions
        ?.filter(q => q.functional_area_id === areaId)
        .map(q => q.question) || [];
    };

    // Build competing module exclusion set
    const competingModuleIds = new Set<string>();
    if (accountTechnologies && techRepository) {
      const repoMap = new Map(techRepository.map(t => [t.id, t]));
      accountTechnologies.forEach(tech => {
        if (tech.repository_tech_id) {
          const repoTech = repoMap.get(tech.repository_tech_id);
          repoTech?.competing_module_ids?.forEach(mid => competingModuleIds.add(mid));
        }
      });
    }

    // Build template-to-modules map
    const templateToModules = new Map<string, string[]>();
    templateProducts?.forEach(tp => {
      const existing = templateToModules.get(tp.use_case_template_id) || [];
      existing.push(tp.module_pricing_id);
      templateToModules.set(tp.use_case_template_id, existing);
    });

    // Build module pricing map
    const modulePricingMap = new Map<string, ModulePricing>();
    modulePricing?.forEach(mp => modulePricingMap.set(mp.id, mp));

    // Calculate MAU-based value for pricing
    const mauCount = account?.mau_count || (account?.employee_count ? Math.round(account.employee_count * 0.2) : 0);
    const baseMauValue = account?.base_mau_value || 0;

    // Calculate revenue for a set of uncovered templates
    const calculateRevenueForTemplates = (templates: UseCaseTemplate[]): { revenue: number; modules: string[] } => {
      if (!mauCount || !modulePricing) return { revenue: 0, modules: [] };
      
      const moduleRevenues = new Map<string, number>();
      const moduleNames: string[] = [];
      
      templates.forEach(template => {
        const moduleIds = templateToModules.get(template.id) || [];
        moduleIds.forEach(moduleId => {
          // Skip if competing tech exists
          if (competingModuleIds.has(moduleId)) return;
          // Skip if already calculated
          if (moduleRevenues.has(moduleId)) return;
          
          const mp = modulePricingMap.get(moduleId);
          if (!mp) return;
          
          let revenue = 0;
          const discount = mp.discount_percentage || 0;
          
          if (mp.module_type === 'module' && mp.mau_percentage > 0) {
            // Percentage-based pricing
            // Priority: account-specific base_mau_value > global list price per MAU * MAU * 12 (annual)
            const mauValue = baseMauValue > 0 ? baseMauValue : (globalListPricePerMau * mauCount * 12);
            revenue = mauValue * (mp.mau_percentage / 100) * (1 - discount / 100);
          } else if (mp.per_mau_cost > 0) {
            revenue = mp.per_mau_cost * mauCount * 12 * (1 - discount / 100);
          } else if (mp.fixed_cost > 0) {
            revenue = mp.fixed_cost * (1 - discount / 100);
          }
          
          moduleRevenues.set(moduleId, revenue);
          moduleNames.push(mp.module_name);
        });
      });
      
      const totalRevenue = Array.from(moduleRevenues.values()).reduce((sum, r) => sum + r, 0);
      return { revenue: Math.round(totalRevenue), modules: [...new Set(moduleNames)] };
    };

    // 1. Use Case Gap NBAs - only for areas WITH defined use cases (Pendo can support)
    functionalAreas.forEach(area => {
      const templates = useCaseTemplates?.filter(t => t.functional_area_id === area.id) || [];
      const accountUCs = useCasesByArea.get(area.name) || [];
      
      // SKIP functional areas without any use cases - not good candidates for action
      if (accountUCs.length === 0) return;
      
      // Find templates not covered by account use cases
      const missingTemplates = templates.filter(template => {
        const templateName = template.name.toLowerCase();
        return !accountUCs.some(uc => 
          uc.includes(templateName) || templateName.includes(uc)
        );
      });

      if (missingTemplates.length > 0 && templates.length > 0) {
        const coveragePercent = ((templates.length - missingTemplates.length) / templates.length) * 100;
        
        // Only create NBA if we have templates and coverage is below 50%
        if (coveragePercent < 50 && templates.length >= 2) {
          // Use case count boosts importance
          const score = calculateScore(10, account, area.name, accountUCs.length);
          const questions = getQuestionsForArea(area.id);
          
          // Calculate potential revenue for this gap
          const { revenue, modules } = calculateRevenueForTemplates(missingTemplates);
          
          nbas.push({
            id: `use-case-gap-${area.id}`,
            type: 'use_case_gap',
            action: `Explore ${area.name} use cases: ${missingTemplates.slice(0, 3).map(t => t.name).join(', ')}${missingTemplates.length > 3 ? ` (+${missingTemplates.length - 3} more)` : ''}`,
            priority: scoreToPriority(score),
            functionalArea: area.name,
            functionalAreaId: area.id,
            discoveryQuestions: questions.slice(0, 3),
            reasoning: `${accountUCs.length} use case(s) identified. ${missingTemplates.length} of ${templates.length} templates not yet explored (${Math.round(coveragePercent)}% coverage)`,
            score,
            potentialRevenue: revenue,
            modules,
          });
        }
      }
    });

    // 2. Tech Gap NBAs - ONLY for functional areas that HAVE use cases
    functionalAreas.forEach(area => {
      // Skip areas that are more about processes than technologies
      if (['Back Office Processes', 'Third-Party Apps'].includes(area.name)) return;
      
      const accountUCs = useCasesByArea.get(area.name) || [];
      
      // SKIP functional areas without use cases - not actionable
      if (accountUCs.length === 0) return;
      
      const areaTechs = techsByArea.get(area.name) || [];
      const hasNoTech = areaTechs.length === 0;
      
      if (hasNoTech) {
        // Use case count boosts importance
        const score = calculateScore(9, account, area.name, accountUCs.length);
        const questions = getQuestionsForArea(area.id);
        
        // Only create if we have discovery questions for this area
        if (questions.length > 0) {
          nbas.push({
            id: `tech-gap-${area.id}`,
            type: 'tech_gap',
            action: `Discover current ${area.name} technology stack`,
            priority: scoreToPriority(score),
            functionalArea: area.name,
            functionalAreaId: area.id,
            discoveryQuestions: questions.slice(0, 3),
            reasoning: `${accountUCs.length} use case(s) identified in ${area.name} but no technologies mapped yet`,
            score,
          });
        }
      }
    });

    // 3. Low Coverage NBAs - only consider functional areas WITH use cases
    // Calculate coverage only among areas that have use cases (actionable areas)
    const areasWithUseCases = functionalAreas.filter(area => 
      (useCasesByArea.get(area.name) || []).length > 0
    );
    
    if (areasWithUseCases.length > 0) {
      const coveredAreas = areasWithUseCases.filter(area => {
        const hasTech = (techsByArea.get(area.name) || []).length > 0;
        return hasTech;
      });
      
      const techCoverage = (coveredAreas.length / areasWithUseCases.length) * 100;
      
      if (techCoverage < 30) {
        // Find areas with use cases but no tech - sorted by use case count (most important first)
        const uncoveredAreasWithUseCases = areasWithUseCases
          .filter(area => (techsByArea.get(area.name) || []).length === 0)
          .map(area => ({
            ...area,
            useCaseCount: (useCasesByArea.get(area.name) || []).length
          }))
          .sort((a, b) => b.useCaseCount - a.useCaseCount)
          .slice(0, 3);

        if (uncoveredAreasWithUseCases.length > 0) {
          const allQuestions = uncoveredAreasWithUseCases.flatMap(area => getQuestionsForArea(area.id));
          const totalUseCases = uncoveredAreasWithUseCases.reduce((sum, a) => sum + a.useCaseCount, 0);
          const score = calculateScore(8, account, uncoveredAreasWithUseCases[0]?.name || 'CRM', totalUseCases);
          
          nbas.push({
            id: `low-coverage-${accountId}`,
            type: 'low_coverage',
            action: `Conduct broad discovery - only ${Math.round(techCoverage)}% tech coverage across ${areasWithUseCases.length} active areas`,
            priority: scoreToPriority(score),
            functionalArea: uncoveredAreasWithUseCases.map(a => a.name).join(', '),
            functionalAreaId: uncoveredAreasWithUseCases[0]?.id || '',
            discoveryQuestions: allQuestions.slice(0, 5),
            reasoning: `Focus on: ${uncoveredAreasWithUseCases.map(a => `${a.name} (${a.useCaseCount} use cases)`).join(', ')}`,
            score,
          });
        }
      }
    }

    // Sort by score descending, then by revenue
    return nbas.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return (b.potentialRevenue || 0) - (a.potentialRevenue || 0);
    });
  }, [functionalAreas, useCaseTemplates, accountUseCases, accountTechnologies, discoveryQuestions, account, accountId, modulePricing, templateProducts, techRepository]);

  return {
    whitespaceNBAs,
    isLoading: !functionalAreas || !useCaseTemplates || !discoveryQuestions || !modulePricing,
  };
}

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      account_captured_insights: {
        Row: {
          account_id: string
          capture_field_id: string
          confidence_score: number | null
          encryption_iv: string | null
          extracted_at: string
          id: string
          is_encrypted: boolean | null
          opportunity_id: string | null
          rule_match_id: string | null
          source_transcript_id: string | null
          updated_at: string
          value: string | null
          value_encrypted: string | null
          value_json: Json | null
          value_json_encrypted: string | null
        }
        Insert: {
          account_id: string
          capture_field_id: string
          confidence_score?: number | null
          encryption_iv?: string | null
          extracted_at?: string
          id?: string
          is_encrypted?: boolean | null
          opportunity_id?: string | null
          rule_match_id?: string | null
          source_transcript_id?: string | null
          updated_at?: string
          value?: string | null
          value_encrypted?: string | null
          value_json?: Json | null
          value_json_encrypted?: string | null
        }
        Update: {
          account_id?: string
          capture_field_id?: string
          confidence_score?: number | null
          encryption_iv?: string | null
          extracted_at?: string
          id?: string
          is_encrypted?: boolean | null
          opportunity_id?: string | null
          rule_match_id?: string | null
          source_transcript_id?: string | null
          updated_at?: string
          value?: string | null
          value_encrypted?: string | null
          value_json?: Json | null
          value_json_encrypted?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "account_captured_insights_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_captured_insights_capture_field_id_fkey"
            columns: ["capture_field_id"]
            isOneToOne: false
            referencedRelation: "detection_rule_capture_fields"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_captured_insights_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_captured_insights_rule_match_id_fkey"
            columns: ["rule_match_id"]
            isOneToOne: false
            referencedRelation: "detection_rule_matches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_captured_insights_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      account_contacts: {
        Row: {
          account_id: string
          advocacy_signals: Json | null
          assessment_source: string | null
          champion_score: number | null
          created_at: string
          email_encrypted: string | null
          encryption_iv: string | null
          id: string
          ignored_reason: string | null
          influence_level: number | null
          info_sharing_signals: Json | null
          is_encrypted: boolean | null
          is_ignored: boolean | null
          is_internal: boolean | null
          last_assessed_at: string | null
          name_encrypted: string | null
          notes_encrypted: string | null
          opportunity_id: string | null
          phone_encrypted: string | null
          role_encrypted: string | null
          sentiment: number | null
          source: string | null
          stakeholder_type: string | null
          updated_at: string
        }
        Insert: {
          account_id: string
          advocacy_signals?: Json | null
          assessment_source?: string | null
          champion_score?: number | null
          created_at?: string
          email_encrypted?: string | null
          encryption_iv?: string | null
          id?: string
          ignored_reason?: string | null
          influence_level?: number | null
          info_sharing_signals?: Json | null
          is_encrypted?: boolean | null
          is_ignored?: boolean | null
          is_internal?: boolean | null
          last_assessed_at?: string | null
          name_encrypted?: string | null
          notes_encrypted?: string | null
          opportunity_id?: string | null
          phone_encrypted?: string | null
          role_encrypted?: string | null
          sentiment?: number | null
          source?: string | null
          stakeholder_type?: string | null
          updated_at?: string
        }
        Update: {
          account_id?: string
          advocacy_signals?: Json | null
          assessment_source?: string | null
          champion_score?: number | null
          created_at?: string
          email_encrypted?: string | null
          encryption_iv?: string | null
          id?: string
          ignored_reason?: string | null
          influence_level?: number | null
          info_sharing_signals?: Json | null
          is_encrypted?: boolean | null
          is_ignored?: boolean | null
          is_internal?: boolean | null
          last_assessed_at?: string | null
          name_encrypted?: string | null
          notes_encrypted?: string | null
          opportunity_id?: string | null
          phone_encrypted?: string | null
          role_encrypted?: string | null
          sentiment?: number | null
          source?: string | null
          stakeholder_type?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "account_contacts_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_contacts_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      account_documents: {
        Row: {
          account_id: string
          content: string | null
          content_encrypted: string | null
          created_at: string
          description: string | null
          description_encrypted: string | null
          encryption_iv: string | null
          expiry_date: string | null
          file_url: string | null
          id: string
          is_encrypted: boolean | null
          is_external_url: boolean | null
          name: string
          name_encrypted: string | null
          opportunity_id: string | null
          owner_email: string | null
          owner_email_encrypted: string | null
          status: string | null
          tags: string[] | null
          type: string
          updated_at: string
          version: string | null
        }
        Insert: {
          account_id: string
          content?: string | null
          content_encrypted?: string | null
          created_at?: string
          description?: string | null
          description_encrypted?: string | null
          encryption_iv?: string | null
          expiry_date?: string | null
          file_url?: string | null
          id?: string
          is_encrypted?: boolean | null
          is_external_url?: boolean | null
          name: string
          name_encrypted?: string | null
          opportunity_id?: string | null
          owner_email?: string | null
          owner_email_encrypted?: string | null
          status?: string | null
          tags?: string[] | null
          type: string
          updated_at?: string
          version?: string | null
        }
        Update: {
          account_id?: string
          content?: string | null
          content_encrypted?: string | null
          created_at?: string
          description?: string | null
          description_encrypted?: string | null
          encryption_iv?: string | null
          expiry_date?: string | null
          file_url?: string | null
          id?: string
          is_encrypted?: boolean | null
          is_external_url?: boolean | null
          name?: string
          name_encrypted?: string | null
          opportunity_id?: string | null
          owner_email?: string | null
          owner_email_encrypted?: string | null
          status?: string | null
          tags?: string[] | null
          type?: string
          updated_at?: string
          version?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "account_documents_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_documents_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      account_exec_summaries: {
        Row: {
          account_id: string
          encryption_iv: string | null
          engagement_summary: Json | null
          engagement_summary_encrypted: string | null
          generated_at: string
          health_indicators: Json | null
          health_indicators_encrypted: string | null
          id: string
          is_encrypted: boolean | null
          key_opportunities: Json | null
          key_opportunities_encrypted: string | null
          key_risks: Json | null
          key_risks_encrypted: string | null
          summary_narrative: string | null
          summary_narrative_encrypted: string | null
          updated_at: string
        }
        Insert: {
          account_id: string
          encryption_iv?: string | null
          engagement_summary?: Json | null
          engagement_summary_encrypted?: string | null
          generated_at?: string
          health_indicators?: Json | null
          health_indicators_encrypted?: string | null
          id?: string
          is_encrypted?: boolean | null
          key_opportunities?: Json | null
          key_opportunities_encrypted?: string | null
          key_risks?: Json | null
          key_risks_encrypted?: string | null
          summary_narrative?: string | null
          summary_narrative_encrypted?: string | null
          updated_at?: string
        }
        Update: {
          account_id?: string
          encryption_iv?: string | null
          engagement_summary?: Json | null
          engagement_summary_encrypted?: string | null
          generated_at?: string
          health_indicators?: Json | null
          health_indicators_encrypted?: string | null
          id?: string
          is_encrypted?: boolean | null
          key_opportunities?: Json | null
          key_opportunities_encrypted?: string | null
          key_risks?: Json | null
          key_risks_encrypted?: string | null
          summary_narrative?: string | null
          summary_narrative_encrypted?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "account_exec_summaries_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: true
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      account_insight_snapshots: {
        Row: {
          account_id: string
          captured_at: string
          change_reason: string | null
          change_source: string
          contact_id: string | null
          created_at: string
          created_by: string | null
          data_cleartext: Json
          data_encrypted: string | null
          encryption_iv: string | null
          field_encryption_map: Json | null
          id: string
          insight_type: string
          opportunity_id: string | null
          previous_snapshot_id: string | null
          source_transcript_id: string | null
          valid_from: string
          valid_to: string | null
          version_number: number
        }
        Insert: {
          account_id: string
          captured_at?: string
          change_reason?: string | null
          change_source?: string
          contact_id?: string | null
          created_at?: string
          created_by?: string | null
          data_cleartext?: Json
          data_encrypted?: string | null
          encryption_iv?: string | null
          field_encryption_map?: Json | null
          id?: string
          insight_type: string
          opportunity_id?: string | null
          previous_snapshot_id?: string | null
          source_transcript_id?: string | null
          valid_from?: string
          valid_to?: string | null
          version_number?: number
        }
        Update: {
          account_id?: string
          captured_at?: string
          change_reason?: string | null
          change_source?: string
          contact_id?: string | null
          created_at?: string
          created_by?: string | null
          data_cleartext?: Json
          data_encrypted?: string | null
          encryption_iv?: string | null
          field_encryption_map?: Json | null
          id?: string
          insight_type?: string
          opportunity_id?: string | null
          previous_snapshot_id?: string | null
          source_transcript_id?: string | null
          valid_from?: string
          valid_to?: string | null
          version_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "account_insight_snapshots_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_insight_snapshots_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "account_contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_insight_snapshots_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_insight_snapshots_previous_snapshot_id_fkey"
            columns: ["previous_snapshot_id"]
            isOneToOne: false
            referencedRelation: "account_insight_snapshots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_insight_snapshots_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      account_metric_history: {
        Row: {
          account_id: string
          change_reason: string | null
          change_source: string
          changed_at: string
          changed_by: string | null
          confidence_score: number | null
          id: string
          metric_type: string
          new_value: Json
          old_value: Json | null
          source_transcript_id: string | null
        }
        Insert: {
          account_id: string
          change_reason?: string | null
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          confidence_score?: number | null
          id?: string
          metric_type: string
          new_value: Json
          old_value?: Json | null
          source_transcript_id?: string | null
        }
        Update: {
          account_id?: string
          change_reason?: string | null
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          confidence_score?: number | null
          id?: string
          metric_type?: string
          new_value?: Json
          old_value?: Json | null
          source_transcript_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "account_metric_history_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_metric_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_metric_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_metric_history_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      account_metrics: {
        Row: {
          account_id: string
          confidence_score: number | null
          context: string | null
          context_encrypted: string | null
          created_at: string
          encryption_iv: string | null
          id: string
          is_encrypted: boolean | null
          last_validated_at: string | null
          mentioned_by_email: string | null
          mentioned_by_email_encrypted: string | null
          mentioned_by_name: string | null
          mentioned_by_name_encrypted: string | null
          mentioned_by_type: string | null
          merged_from_ids: string[] | null
          metric_category: string
          metric_name: string
          metric_numeric_value: number | null
          metric_value: string | null
          metric_value_encrypted: string | null
          needs_review: boolean | null
          opportunity_id: string | null
          source: string | null
          source_transcript_id: string | null
          updated_at: string
          validation_count: number | null
        }
        Insert: {
          account_id: string
          confidence_score?: number | null
          context?: string | null
          context_encrypted?: string | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          last_validated_at?: string | null
          mentioned_by_email?: string | null
          mentioned_by_email_encrypted?: string | null
          mentioned_by_name?: string | null
          mentioned_by_name_encrypted?: string | null
          mentioned_by_type?: string | null
          merged_from_ids?: string[] | null
          metric_category?: string
          metric_name: string
          metric_numeric_value?: number | null
          metric_value?: string | null
          metric_value_encrypted?: string | null
          needs_review?: boolean | null
          opportunity_id?: string | null
          source?: string | null
          source_transcript_id?: string | null
          updated_at?: string
          validation_count?: number | null
        }
        Update: {
          account_id?: string
          confidence_score?: number | null
          context?: string | null
          context_encrypted?: string | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          last_validated_at?: string | null
          mentioned_by_email?: string | null
          mentioned_by_email_encrypted?: string | null
          mentioned_by_name?: string | null
          mentioned_by_name_encrypted?: string | null
          mentioned_by_type?: string | null
          merged_from_ids?: string[] | null
          metric_category?: string
          metric_name?: string
          metric_numeric_value?: number | null
          metric_value?: string | null
          metric_value_encrypted?: string | null
          needs_review?: boolean | null
          opportunity_id?: string | null
          source?: string | null
          source_transcript_id?: string | null
          updated_at?: string
          validation_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "account_metrics_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_metrics_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_metrics_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      account_nbas: {
        Row: {
          account_id: string
          action: string | null
          action_encrypted: string | null
          action_type: string
          assigned_to: string | null
          auto_complete_confidence: number | null
          auto_complete_reason: string | null
          auto_completed_by_transcript_id: string | null
          completed_at: string | null
          created_at: string
          delivery_method: string | null
          due_date: string | null
          encryption_iv: string | null
          id: string
          is_encrypted: boolean | null
          notes: string | null
          notes_encrypted: string | null
          opportunity_id: string | null
          parent_nba_id: string | null
          priority: string | null
          source_transcript_id: string | null
          status: string | null
          sub_task_order: number | null
          updated_at: string
        }
        Insert: {
          account_id: string
          action?: string | null
          action_encrypted?: string | null
          action_type?: string
          assigned_to?: string | null
          auto_complete_confidence?: number | null
          auto_complete_reason?: string | null
          auto_completed_by_transcript_id?: string | null
          completed_at?: string | null
          created_at?: string
          delivery_method?: string | null
          due_date?: string | null
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          notes?: string | null
          notes_encrypted?: string | null
          opportunity_id?: string | null
          parent_nba_id?: string | null
          priority?: string | null
          source_transcript_id?: string | null
          status?: string | null
          sub_task_order?: number | null
          updated_at?: string
        }
        Update: {
          account_id?: string
          action?: string | null
          action_encrypted?: string | null
          action_type?: string
          assigned_to?: string | null
          auto_complete_confidence?: number | null
          auto_complete_reason?: string | null
          auto_completed_by_transcript_id?: string | null
          completed_at?: string | null
          created_at?: string
          delivery_method?: string | null
          due_date?: string | null
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          notes?: string | null
          notes_encrypted?: string | null
          opportunity_id?: string | null
          parent_nba_id?: string | null
          priority?: string | null
          source_transcript_id?: string | null
          status?: string | null
          sub_task_order?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "account_nbas_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_nbas_auto_completed_by_transcript_id_fkey"
            columns: ["auto_completed_by_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_nbas_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_nbas_parent_nba_id_fkey"
            columns: ["parent_nba_id"]
            isOneToOne: false
            referencedRelation: "account_nbas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_nbas_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      account_pain_points: {
        Row: {
          account_id: string
          business_impact: string[] | null
          business_impact_encrypted: string | null
          business_theme: string | null
          confidence_score: number | null
          created_at: string
          encryption_iv: string | null
          id: string
          is_encrypted: boolean | null
          last_validated_at: string | null
          merged_from_ids: string[] | null
          opportunity_id: string | null
          pain_category: string | null
          pain_point: string | null
          pain_point_encrypted: string | null
          severity: string | null
          source: string | null
          source_transcript_id: string | null
          theme_confidence: number | null
          updated_at: string
          validation_count: number | null
        }
        Insert: {
          account_id: string
          business_impact?: string[] | null
          business_impact_encrypted?: string | null
          business_theme?: string | null
          confidence_score?: number | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          last_validated_at?: string | null
          merged_from_ids?: string[] | null
          opportunity_id?: string | null
          pain_category?: string | null
          pain_point?: string | null
          pain_point_encrypted?: string | null
          severity?: string | null
          source?: string | null
          source_transcript_id?: string | null
          theme_confidence?: number | null
          updated_at?: string
          validation_count?: number | null
        }
        Update: {
          account_id?: string
          business_impact?: string[] | null
          business_impact_encrypted?: string | null
          business_theme?: string | null
          confidence_score?: number | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          last_validated_at?: string | null
          merged_from_ids?: string[] | null
          opportunity_id?: string | null
          pain_category?: string | null
          pain_point?: string | null
          pain_point_encrypted?: string | null
          severity?: string | null
          source?: string | null
          source_transcript_id?: string | null
          theme_confidence?: number | null
          updated_at?: string
          validation_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "account_pain_points_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_pain_points_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_pain_points_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      account_strategic_themes: {
        Row: {
          account_id: string
          created_at: string
          description: string | null
          description_encrypted: string | null
          encryption_iv: string | null
          id: string
          impact_level: string | null
          is_encrypted: boolean | null
          item_count: number | null
          linked_opportunity_ids: string[] | null
          supporting_evidence: Json | null
          supporting_evidence_encrypted: string | null
          theme_name: string | null
          theme_name_encrypted: string | null
          theme_type: string
          updated_at: string
        }
        Insert: {
          account_id: string
          created_at?: string
          description?: string | null
          description_encrypted?: string | null
          encryption_iv?: string | null
          id?: string
          impact_level?: string | null
          is_encrypted?: boolean | null
          item_count?: number | null
          linked_opportunity_ids?: string[] | null
          supporting_evidence?: Json | null
          supporting_evidence_encrypted?: string | null
          theme_name?: string | null
          theme_name_encrypted?: string | null
          theme_type: string
          updated_at?: string
        }
        Update: {
          account_id?: string
          created_at?: string
          description?: string | null
          description_encrypted?: string | null
          encryption_iv?: string | null
          id?: string
          impact_level?: string | null
          is_encrypted?: boolean | null
          item_count?: number | null
          linked_opportunity_ids?: string[] | null
          supporting_evidence?: Json | null
          supporting_evidence_encrypted?: string | null
          theme_name?: string | null
          theme_name_encrypted?: string | null
          theme_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "account_strategic_themes_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      account_team_members: {
        Row: {
          account_id: string
          added_from_meeting_id: string | null
          created_at: string
          encryption_iv: string | null
          id: string
          is_encrypted: boolean | null
          role: string | null
          team_member_email: string | null
          team_member_email_encrypted: string | null
          updated_at: string
        }
        Insert: {
          account_id: string
          added_from_meeting_id?: string | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          role?: string | null
          team_member_email?: string | null
          team_member_email_encrypted?: string | null
          updated_at?: string
        }
        Update: {
          account_id?: string
          added_from_meeting_id?: string | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          role?: string | null
          team_member_email?: string | null
          team_member_email_encrypted?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "account_team_members_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_team_members_added_from_meeting_id_fkey"
            columns: ["added_from_meeting_id"]
            isOneToOne: false
            referencedRelation: "momentum_meetings"
            referencedColumns: ["id"]
          },
        ]
      }
      account_technologies: {
        Row: {
          account_id: string
          category: string
          context: string | null
          context_encrypted: string | null
          created_at: string
          encryption_iv: string | null
          extraction_confidence: number | null
          id: string
          is_encrypted: boolean | null
          layer: string
          name: string
          needs_review: boolean | null
          notes: string | null
          notes_encrypted: string | null
          owner_email: string | null
          owner_email_encrypted: string | null
          owner_name: string | null
          owner_name_encrypted: string | null
          priority: string | null
          relationship_status: string | null
          repository_tech_id: string | null
          status: string
        }
        Insert: {
          account_id: string
          category: string
          context?: string | null
          context_encrypted?: string | null
          created_at?: string
          encryption_iv?: string | null
          extraction_confidence?: number | null
          id?: string
          is_encrypted?: boolean | null
          layer: string
          name: string
          needs_review?: boolean | null
          notes?: string | null
          notes_encrypted?: string | null
          owner_email?: string | null
          owner_email_encrypted?: string | null
          owner_name?: string | null
          owner_name_encrypted?: string | null
          priority?: string | null
          relationship_status?: string | null
          repository_tech_id?: string | null
          status?: string
        }
        Update: {
          account_id?: string
          category?: string
          context?: string | null
          context_encrypted?: string | null
          created_at?: string
          encryption_iv?: string | null
          extraction_confidence?: number | null
          id?: string
          is_encrypted?: boolean | null
          layer?: string
          name?: string
          needs_review?: boolean | null
          notes?: string | null
          notes_encrypted?: string | null
          owner_email?: string | null
          owner_email_encrypted?: string | null
          owner_name?: string | null
          owner_name_encrypted?: string | null
          priority?: string | null
          relationship_status?: string | null
          repository_tech_id?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "account_technologies_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_technologies_repository_tech_id_fkey"
            columns: ["repository_tech_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
        ]
      }
      account_use_cases: {
        Row: {
          acceptance_evidence: string | null
          acceptance_status: string | null
          account_id: string
          business_outcome: string | null
          business_theme: string | null
          confidence_score: number | null
          created_at: string
          description: string | null
          description_encrypted: string | null
          encryption_iv: string | null
          functional_area: string | null
          id: string
          is_encrypted: boolean | null
          last_validated_at: string | null
          mentioned_by_email: string | null
          mentioned_by_name: string | null
          mentioned_by_type: string | null
          merged_from_ids: string[] | null
          opportunity_id: string | null
          priority: string | null
          radar_x: number | null
          radar_y: number | null
          required_module_ids: string[] | null
          solution_description: string | null
          sort_order: number | null
          source: string | null
          source_transcript_id: string | null
          status: string
          theme_confidence: number | null
          updated_at: string
          use_case: string | null
          use_case_encrypted: string | null
          use_case_template_id: string | null
          validation_count: number | null
        }
        Insert: {
          acceptance_evidence?: string | null
          acceptance_status?: string | null
          account_id: string
          business_outcome?: string | null
          business_theme?: string | null
          confidence_score?: number | null
          created_at?: string
          description?: string | null
          description_encrypted?: string | null
          encryption_iv?: string | null
          functional_area?: string | null
          id?: string
          is_encrypted?: boolean | null
          last_validated_at?: string | null
          mentioned_by_email?: string | null
          mentioned_by_name?: string | null
          mentioned_by_type?: string | null
          merged_from_ids?: string[] | null
          opportunity_id?: string | null
          priority?: string | null
          radar_x?: number | null
          radar_y?: number | null
          required_module_ids?: string[] | null
          solution_description?: string | null
          sort_order?: number | null
          source?: string | null
          source_transcript_id?: string | null
          status?: string
          theme_confidence?: number | null
          updated_at?: string
          use_case?: string | null
          use_case_encrypted?: string | null
          use_case_template_id?: string | null
          validation_count?: number | null
        }
        Update: {
          acceptance_evidence?: string | null
          acceptance_status?: string | null
          account_id?: string
          business_outcome?: string | null
          business_theme?: string | null
          confidence_score?: number | null
          created_at?: string
          description?: string | null
          description_encrypted?: string | null
          encryption_iv?: string | null
          functional_area?: string | null
          id?: string
          is_encrypted?: boolean | null
          last_validated_at?: string | null
          mentioned_by_email?: string | null
          mentioned_by_name?: string | null
          mentioned_by_type?: string | null
          merged_from_ids?: string[] | null
          opportunity_id?: string | null
          priority?: string | null
          radar_x?: number | null
          radar_y?: number | null
          required_module_ids?: string[] | null
          solution_description?: string | null
          sort_order?: number | null
          source?: string | null
          source_transcript_id?: string | null
          status?: string
          theme_confidence?: number | null
          updated_at?: string
          use_case?: string | null
          use_case_encrypted?: string | null
          use_case_template_id?: string | null
          validation_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "account_use_cases_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_use_cases_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_use_cases_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_use_cases_use_case_template_id_fkey"
            columns: ["use_case_template_id"]
            isOneToOne: false
            referencedRelation: "use_case_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      accounts: {
        Row: {
          arr: number | null
          auto_import_transcripts: boolean | null
          base_mau_value: number | null
          created_at: string
          detection_signal_fields: Json | null
          employee_count: number | null
          engagement_score: number | null
          id: string
          industry: string | null
          mau_count: number | null
          momentum_score: number | null
          name: string
          owner_id: string | null
          primary_se_email: string | null
          relationship_status: string | null
          salesforce_account_id: string | null
          stage: string | null
          status: string | null
          updated_at: string
        }
        Insert: {
          arr?: number | null
          auto_import_transcripts?: boolean | null
          base_mau_value?: number | null
          created_at?: string
          detection_signal_fields?: Json | null
          employee_count?: number | null
          engagement_score?: number | null
          id?: string
          industry?: string | null
          mau_count?: number | null
          momentum_score?: number | null
          name: string
          owner_id?: string | null
          primary_se_email?: string | null
          relationship_status?: string | null
          salesforce_account_id?: string | null
          stage?: string | null
          status?: string | null
          updated_at?: string
        }
        Update: {
          arr?: number | null
          auto_import_transcripts?: boolean | null
          base_mau_value?: number | null
          created_at?: string
          detection_signal_fields?: Json | null
          employee_count?: number | null
          engagement_score?: number | null
          id?: string
          industry?: string | null
          mau_count?: number | null
          momentum_score?: number | null
          name?: string
          owner_id?: string | null
          primary_se_email?: string | null
          relationship_status?: string | null
          salesforce_account_id?: string | null
          stage?: string | null
          status?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      activity_types: {
        Row: {
          color: string
          created_at: string
          description: string | null
          icon: string
          id: string
          is_active: boolean
          is_minor: boolean | null
          label: string
          name: string
          sort_order: number | null
          updated_at: string
        }
        Insert: {
          color?: string
          created_at?: string
          description?: string | null
          icon?: string
          id?: string
          is_active?: boolean
          is_minor?: boolean | null
          label: string
          name: string
          sort_order?: number | null
          updated_at?: string
        }
        Update: {
          color?: string
          created_at?: string
          description?: string | null
          icon?: string
          id?: string
          is_active?: boolean
          is_minor?: boolean | null
          label?: string
          name?: string
          sort_order?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      ai_provider_settings: {
        Row: {
          created_at: string
          id: string
          provider: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          provider?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          provider?: string
          updated_at?: string
        }
        Relationships: []
      }
      ai_settings: {
        Row: {
          id: string
          setting_key: string
          setting_value: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          id?: string
          setting_key: string
          setting_value: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          id?: string
          setting_key?: string
          setting_value?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      analysis_pass_dependencies: {
        Row: {
          created_at: string | null
          dependency_type: string
          depends_on_pass_id: string
          field_mappings: Json | null
          id: string
          pass_id: string
        }
        Insert: {
          created_at?: string | null
          dependency_type?: string
          depends_on_pass_id: string
          field_mappings?: Json | null
          id?: string
          pass_id: string
        }
        Update: {
          created_at?: string | null
          dependency_type?: string
          depends_on_pass_id?: string
          field_mappings?: Json | null
          id?: string
          pass_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "analysis_pass_dependencies_depends_on_pass_id_fkey"
            columns: ["depends_on_pass_id"]
            isOneToOne: false
            referencedRelation: "analysis_passes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "analysis_pass_dependencies_pass_id_fkey"
            columns: ["pass_id"]
            isOneToOne: false
            referencedRelation: "analysis_passes"
            referencedColumns: ["id"]
          },
        ]
      }
      analysis_pass_versions: {
        Row: {
          change_notes: string | null
          created_at: string | null
          created_by: string | null
          id: string
          output_schema: Json | null
          pass_id: string
          system_prompt: string
          version_number: number
        }
        Insert: {
          change_notes?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          output_schema?: Json | null
          pass_id: string
          system_prompt: string
          version_number: number
        }
        Update: {
          change_notes?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          output_schema?: Json | null
          pass_id?: string
          system_prompt?: string
          version_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "analysis_pass_versions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "analysis_pass_versions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "analysis_pass_versions_pass_id_fkey"
            columns: ["pass_id"]
            isOneToOne: false
            referencedRelation: "analysis_passes"
            referencedColumns: ["id"]
          },
        ]
      }
      analysis_passes: {
        Row: {
          condition_config: Json | null
          created_at: string | null
          description: string | null
          id: string
          is_async: boolean | null
          last_edited_by: string | null
          max_tokens: number | null
          name: string
          output_schema: Json | null
          pass_key: string
          pipeline_id: string
          sort_order: number
          status: Database["public"]["Enums"]["analysis_pass_status"] | null
          system_prompt: string
          timeout_seconds: number | null
          updated_at: string | null
          version: number | null
        }
        Insert: {
          condition_config?: Json | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_async?: boolean | null
          last_edited_by?: string | null
          max_tokens?: number | null
          name: string
          output_schema?: Json | null
          pass_key: string
          pipeline_id: string
          sort_order?: number
          status?: Database["public"]["Enums"]["analysis_pass_status"] | null
          system_prompt: string
          timeout_seconds?: number | null
          updated_at?: string | null
          version?: number | null
        }
        Update: {
          condition_config?: Json | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_async?: boolean | null
          last_edited_by?: string | null
          max_tokens?: number | null
          name?: string
          output_schema?: Json | null
          pass_key?: string
          pipeline_id?: string
          sort_order?: number
          status?: Database["public"]["Enums"]["analysis_pass_status"] | null
          system_prompt?: string
          timeout_seconds?: number | null
          updated_at?: string | null
          version?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "analysis_passes_last_edited_by_fkey"
            columns: ["last_edited_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "analysis_passes_last_edited_by_fkey"
            columns: ["last_edited_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "analysis_passes_pipeline_id_fkey"
            columns: ["pipeline_id"]
            isOneToOne: false
            referencedRelation: "analysis_pipelines"
            referencedColumns: ["id"]
          },
        ]
      }
      analysis_pipelines: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          is_active: boolean | null
          is_default: boolean | null
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      analysis_run_logs: {
        Row: {
          completed_at: string | null
          created_at: string
          duration_ms: number | null
          error_category: string | null
          error_message: string | null
          id: string
          input_tokens_estimate: number | null
          max_retries: number
          metadata: Json | null
          output_tokens_estimate: number | null
          pass_key: string
          pass_name: string | null
          phase: string
          result_summary: Json | null
          retry_attempt: number
          started_at: string
          status: string
          transcript_id: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          duration_ms?: number | null
          error_category?: string | null
          error_message?: string | null
          id?: string
          input_tokens_estimate?: number | null
          max_retries?: number
          metadata?: Json | null
          output_tokens_estimate?: number | null
          pass_key: string
          pass_name?: string | null
          phase?: string
          result_summary?: Json | null
          retry_attempt?: number
          started_at?: string
          status?: string
          transcript_id: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          duration_ms?: number | null
          error_category?: string | null
          error_message?: string | null
          id?: string
          input_tokens_estimate?: number | null
          max_retries?: number
          metadata?: Json | null
          output_tokens_estimate?: number | null
          pass_key?: string
          pass_name?: string | null
          phase?: string
          result_summary?: Json | null
          retry_attempt?: number
          started_at?: string
          status?: string
          transcript_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "analysis_run_logs_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      architecture_versions: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_current: boolean | null
          name: string
          snapshot: Json
          version_number: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_current?: boolean | null
          name: string
          snapshot: Json
          version_number?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_current?: boolean | null
          name?: string
          snapshot?: Json
          version_number?: number
        }
        Relationships: []
      }
      competitive_audit_log: {
        Row: {
          audit_datetime: string
          created_at: string
          current_score: number | null
          evidence_confidence_weight: number
          evidence_source: string
          evidence_url: string | null
          file_score: number | null
          file_score_term: string | null
          id: string
          rationale: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          source_transcript_id: string | null
          source_type: string | null
          status: string | null
          subcategory: string
          type: string | null
          validated_score: number | null
          validated_score_term: string | null
          vendor_name: string
        }
        Insert: {
          audit_datetime?: string
          created_at?: string
          current_score?: number | null
          evidence_confidence_weight?: number
          evidence_source?: string
          evidence_url?: string | null
          file_score?: number | null
          file_score_term?: string | null
          id?: string
          rationale?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          source_transcript_id?: string | null
          source_type?: string | null
          status?: string | null
          subcategory: string
          type?: string | null
          validated_score?: number | null
          validated_score_term?: string | null
          vendor_name: string
        }
        Update: {
          audit_datetime?: string
          created_at?: string
          current_score?: number | null
          evidence_confidence_weight?: number
          evidence_source?: string
          evidence_url?: string | null
          file_score?: number | null
          file_score_term?: string | null
          id?: string
          rationale?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          source_transcript_id?: string | null
          source_type?: string | null
          status?: string | null
          subcategory?: string
          type?: string | null
          validated_score?: number | null
          validated_score_term?: string | null
          vendor_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "competitive_audit_log_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_audit_log_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_audit_log_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      competitive_categories: {
        Row: {
          created_at: string
          id: string
          name: string
          sort_order: number | null
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          sort_order?: number | null
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          sort_order?: number | null
        }
        Relationships: []
      }
      competitive_features: {
        Row: {
          category_id: string
          created_at: string
          id: string
          maturity_level_1: string | null
          maturity_level_2: string | null
          maturity_level_3: string | null
          maturity_level_4: string | null
          maturity_level_5: string | null
          name: string
          sort_order: number | null
        }
        Insert: {
          category_id: string
          created_at?: string
          id?: string
          maturity_level_1?: string | null
          maturity_level_2?: string | null
          maturity_level_3?: string | null
          maturity_level_4?: string | null
          maturity_level_5?: string | null
          name: string
          sort_order?: number | null
        }
        Update: {
          category_id?: string
          created_at?: string
          id?: string
          maturity_level_1?: string | null
          maturity_level_2?: string | null
          maturity_level_3?: string | null
          maturity_level_4?: string | null
          maturity_level_5?: string | null
          name?: string
          sort_order?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "competitive_features_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "competitive_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      competitive_play_suggestions: {
        Row: {
          competitor_id: string | null
          created_at: string
          highlight_feature_ids: string[] | null
          id: string
          linked_use_case_ids: string[] | null
          opportunity_id: string
          play_description: string | null
          play_strategy: string | null
          play_title: string
          play_type: string
          relevance_score: number | null
          status: string | null
          talking_points: Json | null
          triggered_by: string | null
          updated_at: string
        }
        Insert: {
          competitor_id?: string | null
          created_at?: string
          highlight_feature_ids?: string[] | null
          id?: string
          linked_use_case_ids?: string[] | null
          opportunity_id: string
          play_description?: string | null
          play_strategy?: string | null
          play_title: string
          play_type: string
          relevance_score?: number | null
          status?: string | null
          talking_points?: Json | null
          triggered_by?: string | null
          updated_at?: string
        }
        Update: {
          competitor_id?: string | null
          created_at?: string
          highlight_feature_ids?: string[] | null
          id?: string
          linked_use_case_ids?: string[] | null
          opportunity_id?: string
          play_description?: string | null
          play_strategy?: string | null
          play_title?: string
          play_type?: string
          relevance_score?: number | null
          status?: string | null
          talking_points?: Json | null
          triggered_by?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "competitive_play_suggestions_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_play_suggestions_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      competitive_plays: {
        Row: {
          account_id: string | null
          competitor_id: string | null
          competitor_name: string
          competitor_weakness_score: number | null
          confidence_score: number | null
          created_at: string
          dismissed_at: string | null
          id: string
          linked_use_case_ids: string[] | null
          opportunity_id: string | null
          pendo_advantage_score: number | null
          play_description: string | null
          play_strategy: string | null
          play_title: string
          play_type: string
          relevant_categories: string[] | null
          source_transcript_id: string | null
          status: string | null
          talking_points: Json | null
          updated_at: string
          used_at: string | null
        }
        Insert: {
          account_id?: string | null
          competitor_id?: string | null
          competitor_name: string
          competitor_weakness_score?: number | null
          confidence_score?: number | null
          created_at?: string
          dismissed_at?: string | null
          id?: string
          linked_use_case_ids?: string[] | null
          opportunity_id?: string | null
          pendo_advantage_score?: number | null
          play_description?: string | null
          play_strategy?: string | null
          play_title: string
          play_type: string
          relevant_categories?: string[] | null
          source_transcript_id?: string | null
          status?: string | null
          talking_points?: Json | null
          updated_at?: string
          used_at?: string | null
        }
        Update: {
          account_id?: string | null
          competitor_id?: string | null
          competitor_name?: string
          competitor_weakness_score?: number | null
          confidence_score?: number | null
          created_at?: string
          dismissed_at?: string | null
          id?: string
          linked_use_case_ids?: string[] | null
          opportunity_id?: string | null
          pendo_advantage_score?: number | null
          play_description?: string | null
          play_strategy?: string | null
          play_title?: string
          play_type?: string
          relevant_categories?: string[] | null
          source_transcript_id?: string | null
          status?: string | null
          talking_points?: Json | null
          updated_at?: string
          used_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "competitive_plays_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_plays_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_plays_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_plays_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      competitive_rubric: {
        Row: {
          category: string
          created_at: string
          id: string
          level_1_description: string | null
          level_2_description: string | null
          level_3_description: string | null
          level_4_description: string | null
          level_5_description: string | null
          subcategory: string
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          level_1_description?: string | null
          level_2_description?: string | null
          level_3_description?: string | null
          level_4_description?: string | null
          level_5_description?: string | null
          subcategory: string
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          level_1_description?: string | null
          level_2_description?: string | null
          level_3_description?: string | null
          level_4_description?: string | null
          level_5_description?: string | null
          subcategory?: string
          updated_at?: string
        }
        Relationships: []
      }
      competitive_scorecard: {
        Row: {
          category: string
          competitor_id: string | null
          created_at: string
          id: string
          last_audited_at: string | null
          last_validated_at: string | null
          rubric_id: string | null
          score: number | null
          subcategory: string
          updated_at: string
          validated_by: string | null
          vendor_name: string
        }
        Insert: {
          category: string
          competitor_id?: string | null
          created_at?: string
          id?: string
          last_audited_at?: string | null
          last_validated_at?: string | null
          rubric_id?: string | null
          score?: number | null
          subcategory: string
          updated_at?: string
          validated_by?: string | null
          vendor_name: string
        }
        Update: {
          category?: string
          competitor_id?: string | null
          created_at?: string
          id?: string
          last_audited_at?: string | null
          last_validated_at?: string | null
          rubric_id?: string | null
          score?: number | null
          subcategory?: string
          updated_at?: string
          validated_by?: string | null
          vendor_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "competitive_scorecard_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_scorecard_rubric_id_fkey"
            columns: ["rubric_id"]
            isOneToOne: false
            referencedRelation: "competitive_rubric"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_scorecard_validated_by_fkey"
            columns: ["validated_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_scorecard_validated_by_fkey"
            columns: ["validated_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      competitive_sources: {
        Row: {
          added_by: string | null
          created_at: string
          date_added: string | null
          id: string
          key_takeaways: string | null
          last_used_date: string | null
          reference_number: string | null
          source_description: string | null
          source_name: string
          source_url: string | null
          status: string | null
          subcategory_alignment: string | null
          updated_at: string
        }
        Insert: {
          added_by?: string | null
          created_at?: string
          date_added?: string | null
          id?: string
          key_takeaways?: string | null
          last_used_date?: string | null
          reference_number?: string | null
          source_description?: string | null
          source_name: string
          source_url?: string | null
          status?: string | null
          subcategory_alignment?: string | null
          updated_at?: string
        }
        Update: {
          added_by?: string | null
          created_at?: string
          date_added?: string | null
          id?: string
          key_takeaways?: string | null
          last_used_date?: string | null
          reference_number?: string | null
          source_description?: string | null
          source_name?: string
          source_url?: string | null
          status?: string | null
          subcategory_alignment?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      competitive_transcript_evidence: {
        Row: {
          account_id: string | null
          categories_discussed: string[] | null
          competitor_name: string
          confidence_score: number | null
          context: string | null
          created_at: string
          features_compared: Json | null
          id: string
          mention_type: string
          opportunity_id: string | null
          sentiment: string | null
          speaker_type: string | null
          transcript_id: string | null
        }
        Insert: {
          account_id?: string | null
          categories_discussed?: string[] | null
          competitor_name: string
          confidence_score?: number | null
          context?: string | null
          created_at?: string
          features_compared?: Json | null
          id?: string
          mention_type: string
          opportunity_id?: string | null
          sentiment?: string | null
          speaker_type?: string | null
          transcript_id?: string | null
        }
        Update: {
          account_id?: string | null
          categories_discussed?: string[] | null
          competitor_name?: string
          confidence_score?: number | null
          context?: string | null
          created_at?: string
          features_compared?: Json | null
          id?: string
          mention_type?: string
          opportunity_id?: string | null
          sentiment?: string | null
          speaker_type?: string | null
          transcript_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "competitive_transcript_evidence_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_transcript_evidence_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitive_transcript_evidence_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      competitor_scores: {
        Row: {
          competitor_id: string
          created_at: string
          encryption_iv: string | null
          feature_id: string
          id: string
          is_encrypted: boolean | null
          rationale: string | null
          rationale_encrypted: string | null
          score: number
          source_date: string | null
          source_url: string | null
          updated_at: string
        }
        Insert: {
          competitor_id: string
          created_at?: string
          encryption_iv?: string | null
          feature_id: string
          id?: string
          is_encrypted?: boolean | null
          rationale?: string | null
          rationale_encrypted?: string | null
          score: number
          source_date?: string | null
          source_url?: string | null
          updated_at?: string
        }
        Update: {
          competitor_id?: string
          created_at?: string
          encryption_iv?: string | null
          feature_id?: string
          id?: string
          is_encrypted?: boolean | null
          rationale?: string | null
          rationale_encrypted?: string | null
          score?: number
          source_date?: string | null
          source_url?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "competitor_scores_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitor_scores_feature_id_fkey"
            columns: ["feature_id"]
            isOneToOne: false
            referencedRelation: "competitive_features"
            referencedColumns: ["id"]
          },
        ]
      }
      competitors: {
        Row: {
          created_at: string
          description: string | null
          description_encrypted: string | null
          encryption_iv: string | null
          id: string
          is_encrypted: boolean | null
          is_portfolio: boolean | null
          is_primary_competitor: boolean | null
          logo_url: string | null
          name: string
          parent_company_id: string | null
          relationship_notes: string | null
          relationship_notes_encrypted: string | null
          total_score: number | null
          updated_at: string
          website_url: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          description_encrypted?: string | null
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          is_portfolio?: boolean | null
          is_primary_competitor?: boolean | null
          logo_url?: string | null
          name: string
          parent_company_id?: string | null
          relationship_notes?: string | null
          relationship_notes_encrypted?: string | null
          total_score?: number | null
          updated_at?: string
          website_url?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          description_encrypted?: string | null
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          is_portfolio?: boolean | null
          is_primary_competitor?: boolean | null
          logo_url?: string | null
          name?: string
          parent_company_id?: string | null
          relationship_notes?: string | null
          relationship_notes_encrypted?: string | null
          total_score?: number | null
          updated_at?: string
          website_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "competitors_parent_company_id_fkey"
            columns: ["parent_company_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      contact_meeting_snapshots: {
        Row: {
          action_items: string[] | null
          action_items_encrypted: string | null
          champion_score: number | null
          concerns_raised: string[] | null
          concerns_raised_encrypted: string | null
          contact_id: string
          created_at: string
          encryption_iv: string | null
          engagement_score: number | null
          id: string
          influence_level: number | null
          is_encrypted: boolean | null
          key_quotes: string[] | null
          key_quotes_encrypted: string | null
          meeting_date: string
          meeting_type: string | null
          notes: string | null
          notes_encrypted: string | null
          opportunity_id: string | null
          sentiment: number | null
          topics_discussed: string[] | null
          topics_discussed_encrypted: string | null
          transcript_id: string
          updated_at: string
        }
        Insert: {
          action_items?: string[] | null
          action_items_encrypted?: string | null
          champion_score?: number | null
          concerns_raised?: string[] | null
          concerns_raised_encrypted?: string | null
          contact_id: string
          created_at?: string
          encryption_iv?: string | null
          engagement_score?: number | null
          id?: string
          influence_level?: number | null
          is_encrypted?: boolean | null
          key_quotes?: string[] | null
          key_quotes_encrypted?: string | null
          meeting_date: string
          meeting_type?: string | null
          notes?: string | null
          notes_encrypted?: string | null
          opportunity_id?: string | null
          sentiment?: number | null
          topics_discussed?: string[] | null
          topics_discussed_encrypted?: string | null
          transcript_id: string
          updated_at?: string
        }
        Update: {
          action_items?: string[] | null
          action_items_encrypted?: string | null
          champion_score?: number | null
          concerns_raised?: string[] | null
          concerns_raised_encrypted?: string | null
          contact_id?: string
          created_at?: string
          encryption_iv?: string | null
          engagement_score?: number | null
          id?: string
          influence_level?: number | null
          is_encrypted?: boolean | null
          key_quotes?: string[] | null
          key_quotes_encrypted?: string | null
          meeting_date?: string
          meeting_type?: string | null
          notes?: string | null
          notes_encrypted?: string | null
          opportunity_id?: string | null
          sentiment?: number | null
          topics_discussed?: string[] | null
          topics_discussed_encrypted?: string | null
          transcript_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "contact_meeting_snapshots_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "account_contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contact_meeting_snapshots_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contact_meeting_snapshots_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      custom_roles: {
        Row: {
          created_at: string | null
          description: string | null
          display_name: string
          id: string
          is_system: boolean | null
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          display_name: string
          id?: string
          is_system?: boolean | null
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          display_name?: string
          id?: string
          is_system?: boolean | null
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      customer_stories: {
        Row: {
          account_id: string
          behavior: string | null
          behavior_encrypted: string | null
          created_at: string
          created_by: string | null
          encryption_iv: string | null
          id: string
          impact: string | null
          impact_encrypted: string | null
          impact_metrics: Json | null
          impact_metrics_encrypted: string | null
          industry: string | null
          is_encrypted: boolean | null
          situation: string | null
          situation_encrypted: string | null
          situation_metrics: string | null
          status: string | null
          tags: string[] | null
          technologies_used: string[] | null
          title: string
          updated_at: string
          use_cases: string[] | null
        }
        Insert: {
          account_id: string
          behavior?: string | null
          behavior_encrypted?: string | null
          created_at?: string
          created_by?: string | null
          encryption_iv?: string | null
          id?: string
          impact?: string | null
          impact_encrypted?: string | null
          impact_metrics?: Json | null
          impact_metrics_encrypted?: string | null
          industry?: string | null
          is_encrypted?: boolean | null
          situation?: string | null
          situation_encrypted?: string | null
          situation_metrics?: string | null
          status?: string | null
          tags?: string[] | null
          technologies_used?: string[] | null
          title: string
          updated_at?: string
          use_cases?: string[] | null
        }
        Update: {
          account_id?: string
          behavior?: string | null
          behavior_encrypted?: string | null
          created_at?: string
          created_by?: string | null
          encryption_iv?: string | null
          id?: string
          impact?: string | null
          impact_encrypted?: string | null
          impact_metrics?: Json | null
          impact_metrics_encrypted?: string | null
          industry?: string | null
          is_encrypted?: boolean | null
          situation?: string | null
          situation_encrypted?: string | null
          situation_metrics?: string | null
          status?: string | null
          tags?: string[] | null
          technologies_used?: string[] | null
          title?: string
          updated_at?: string
          use_cases?: string[] | null
        }
        Relationships: [
          {
            foreignKeyName: "customer_stories_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      data_integrations: {
        Row: {
          config: Json | null
          created_at: string
          cursor_state: Json | null
          display_name: string
          id: string
          is_enabled: boolean
          last_sync_at: string | null
          last_sync_error: string | null
          last_sync_meetings_count: number | null
          last_sync_status: string | null
          polling_interval_minutes: number
          provider: string
          updated_at: string
        }
        Insert: {
          config?: Json | null
          created_at?: string
          cursor_state?: Json | null
          display_name: string
          id?: string
          is_enabled?: boolean
          last_sync_at?: string | null
          last_sync_error?: string | null
          last_sync_meetings_count?: number | null
          last_sync_status?: string | null
          polling_interval_minutes?: number
          provider: string
          updated_at?: string
        }
        Update: {
          config?: Json | null
          created_at?: string
          cursor_state?: Json | null
          display_name?: string
          id?: string
          is_enabled?: boolean
          last_sync_at?: string | null
          last_sync_error?: string | null
          last_sync_meetings_count?: number | null
          last_sync_status?: string | null
          polling_interval_minutes?: number
          provider?: string
          updated_at?: string
        }
        Relationships: []
      }
      deployment_types: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          sort_order: number | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          sort_order?: number | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          sort_order?: number | null
        }
        Relationships: []
      }
      detection_rule_actions: {
        Row: {
          action_config: Json
          action_type: string
          created_at: string
          id: string
          is_active: boolean | null
          legacy_capture_field_id: string | null
          rule_id: string
          sort_order: number | null
          target_entity: string | null
          updated_at: string
        }
        Insert: {
          action_config?: Json
          action_type: string
          created_at?: string
          id?: string
          is_active?: boolean | null
          legacy_capture_field_id?: string | null
          rule_id: string
          sort_order?: number | null
          target_entity?: string | null
          updated_at?: string
        }
        Update: {
          action_config?: Json
          action_type?: string
          created_at?: string
          id?: string
          is_active?: boolean | null
          legacy_capture_field_id?: string | null
          rule_id?: string
          sort_order?: number | null
          target_entity?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "detection_rule_actions_legacy_capture_field_id_fkey"
            columns: ["legacy_capture_field_id"]
            isOneToOne: false
            referencedRelation: "detection_rule_capture_fields"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "detection_rule_actions_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "detection_rules"
            referencedColumns: ["id"]
          },
        ]
      }
      detection_rule_capture_fields: {
        Row: {
          created_at: string
          description: string | null
          extraction_prompt: string | null
          field_name: string
          field_type: string
          id: string
          is_required: boolean | null
          rule_id: string
          sort_order: number | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          extraction_prompt?: string | null
          field_name: string
          field_type?: string
          id?: string
          is_required?: boolean | null
          rule_id: string
          sort_order?: number | null
        }
        Update: {
          created_at?: string
          description?: string | null
          extraction_prompt?: string | null
          field_name?: string
          field_type?: string
          id?: string
          is_required?: boolean | null
          rule_id?: string
          sort_order?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "detection_rule_capture_fields_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "detection_rules"
            referencedColumns: ["id"]
          },
        ]
      }
      detection_rule_matches: {
        Row: {
          confidence_score: number | null
          created_at: string
          crm_stage_at_detection: number | null
          encryption_iv: string | null
          first_detected_at: string | null
          id: string
          is_encrypted: boolean | null
          matched_phrases: string[] | null
          matched_phrases_encrypted: string | null
          occurrence_count: number | null
          opportunity_id: string | null
          pre_sales_stage_at_detection: number | null
          rule_id: string
          sentiment_label: string | null
          sentiment_score: number | null
          signal_occurrence_count: number | null
          signal_occurrences: Json | null
          signal_occurrences_encrypted: string | null
          speaker_email: string | null
          speaker_email_encrypted: string | null
          speaker_name: string | null
          speaker_name_encrypted: string | null
          speaker_type: string | null
          transcript_id: string
        }
        Insert: {
          confidence_score?: number | null
          created_at?: string
          crm_stage_at_detection?: number | null
          encryption_iv?: string | null
          first_detected_at?: string | null
          id?: string
          is_encrypted?: boolean | null
          matched_phrases?: string[] | null
          matched_phrases_encrypted?: string | null
          occurrence_count?: number | null
          opportunity_id?: string | null
          pre_sales_stage_at_detection?: number | null
          rule_id: string
          sentiment_label?: string | null
          sentiment_score?: number | null
          signal_occurrence_count?: number | null
          signal_occurrences?: Json | null
          signal_occurrences_encrypted?: string | null
          speaker_email?: string | null
          speaker_email_encrypted?: string | null
          speaker_name?: string | null
          speaker_name_encrypted?: string | null
          speaker_type?: string | null
          transcript_id: string
        }
        Update: {
          confidence_score?: number | null
          created_at?: string
          crm_stage_at_detection?: number | null
          encryption_iv?: string | null
          first_detected_at?: string | null
          id?: string
          is_encrypted?: boolean | null
          matched_phrases?: string[] | null
          matched_phrases_encrypted?: string | null
          occurrence_count?: number | null
          opportunity_id?: string | null
          pre_sales_stage_at_detection?: number | null
          rule_id?: string
          sentiment_label?: string | null
          sentiment_score?: number | null
          signal_occurrence_count?: number | null
          signal_occurrences?: Json | null
          signal_occurrences_encrypted?: string | null
          speaker_email?: string | null
          speaker_email_encrypted?: string | null
          speaker_name?: string | null
          speaker_name_encrypted?: string | null
          speaker_type?: string | null
          transcript_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "detection_rule_matches_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "detection_rule_matches_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "detection_rules"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "detection_rule_matches_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      detection_rule_nba_templates: {
        Row: {
          action_text: string
          action_type: string | null
          created_at: string
          id: string
          priority: string | null
          rule_id: string
          sort_order: number | null
        }
        Insert: {
          action_text: string
          action_type?: string | null
          created_at?: string
          id?: string
          priority?: string | null
          rule_id: string
          sort_order?: number | null
        }
        Update: {
          action_text?: string
          action_type?: string | null
          created_at?: string
          id?: string
          priority?: string | null
          rule_id?: string
          sort_order?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "detection_rule_nba_templates_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "detection_rules"
            referencedColumns: ["id"]
          },
        ]
      }
      detection_rule_pass_links: {
        Row: {
          created_at: string | null
          detection_rule_id: string
          id: string
          pass_id: string
          trigger_behavior: string | null
        }
        Insert: {
          created_at?: string | null
          detection_rule_id: string
          id?: string
          pass_id: string
          trigger_behavior?: string | null
        }
        Update: {
          created_at?: string | null
          detection_rule_id?: string
          id?: string
          pass_id?: string
          trigger_behavior?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "detection_rule_pass_links_detection_rule_id_fkey"
            columns: ["detection_rule_id"]
            isOneToOne: false
            referencedRelation: "detection_rules"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "detection_rule_pass_links_pass_id_fkey"
            columns: ["pass_id"]
            isOneToOne: false
            referencedRelation: "analysis_passes"
            referencedColumns: ["id"]
          },
        ]
      }
      detection_rule_questions: {
        Row: {
          created_at: string
          id: string
          is_required: boolean | null
          question_text: string
          rule_id: string
          sort_order: number | null
        }
        Insert: {
          created_at?: string
          id?: string
          is_required?: boolean | null
          question_text: string
          rule_id: string
          sort_order?: number | null
        }
        Update: {
          created_at?: string
          id?: string
          is_required?: boolean | null
          question_text?: string
          rule_id?: string
          sort_order?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "detection_rule_questions_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "detection_rules"
            referencedColumns: ["id"]
          },
        ]
      }
      detection_rule_readiness_mappings: {
        Row: {
          auto_answer: string | null
          auto_answer_json: Json | null
          created_at: string
          id: string
          readiness_question_id: string
          rule_id: string
        }
        Insert: {
          auto_answer?: string | null
          auto_answer_json?: Json | null
          created_at?: string
          id?: string
          readiness_question_id: string
          rule_id: string
        }
        Update: {
          auto_answer?: string | null
          auto_answer_json?: Json | null
          created_at?: string
          id?: string
          readiness_question_id?: string
          rule_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "detection_rule_readiness_mappings_readiness_question_id_fkey"
            columns: ["readiness_question_id"]
            isOneToOne: false
            referencedRelation: "readiness_template_questions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "detection_rule_readiness_mappings_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "detection_rules"
            referencedColumns: ["id"]
          },
        ]
      }
      detection_rule_trees: {
        Row: {
          created_at: string
          deployment_type_id: string | null
          description: string | null
          id: string
          is_active: boolean | null
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          deployment_type_id?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          deployment_type_id?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "detection_rule_trees_deployment_type_id_fkey"
            columns: ["deployment_type_id"]
            isOneToOne: false
            referencedRelation: "deployment_types"
            referencedColumns: ["id"]
          },
        ]
      }
      detection_rules: {
        Row: {
          confidence_threshold: number | null
          confirmation_patterns: string[] | null
          context_qualifiers: string[] | null
          created_at: string
          description: string | null
          detection_intent: string | null
          display_name: string | null
          exclusion_phrases: string[] | null
          id: string
          is_active: boolean | null
          name: string
          parent_rule_id: string | null
          rule_type: string | null
          signal_field_name: string | null
          signal_field_target: string | null
          sort_order: number | null
          speaker_context: string | null
          technology_id: string | null
          tree_id: string | null
          trigger_phrases: string[]
          updated_at: string
          validation_task_template_id: string | null
        }
        Insert: {
          confidence_threshold?: number | null
          confirmation_patterns?: string[] | null
          context_qualifiers?: string[] | null
          created_at?: string
          description?: string | null
          detection_intent?: string | null
          display_name?: string | null
          exclusion_phrases?: string[] | null
          id?: string
          is_active?: boolean | null
          name: string
          parent_rule_id?: string | null
          rule_type?: string | null
          signal_field_name?: string | null
          signal_field_target?: string | null
          sort_order?: number | null
          speaker_context?: string | null
          technology_id?: string | null
          tree_id?: string | null
          trigger_phrases?: string[]
          updated_at?: string
          validation_task_template_id?: string | null
        }
        Update: {
          confidence_threshold?: number | null
          confirmation_patterns?: string[] | null
          context_qualifiers?: string[] | null
          created_at?: string
          description?: string | null
          detection_intent?: string | null
          display_name?: string | null
          exclusion_phrases?: string[] | null
          id?: string
          is_active?: boolean | null
          name?: string
          parent_rule_id?: string | null
          rule_type?: string | null
          signal_field_name?: string | null
          signal_field_target?: string | null
          sort_order?: number | null
          speaker_context?: string | null
          technology_id?: string | null
          tree_id?: string | null
          trigger_phrases?: string[]
          updated_at?: string
          validation_task_template_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "detection_rules_parent_rule_id_fkey"
            columns: ["parent_rule_id"]
            isOneToOne: false
            referencedRelation: "detection_rules"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "detection_rules_technology_id_fkey"
            columns: ["technology_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "detection_rules_tree_id_fkey"
            columns: ["tree_id"]
            isOneToOne: false
            referencedRelation: "detection_rule_trees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "detection_rules_validation_task_template_id_fkey"
            columns: ["validation_task_template_id"]
            isOneToOne: false
            referencedRelation: "validation_task_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      detection_tree_config: {
        Row: {
          created_at: string
          description: string | null
          name: string
          tree_id: string
          triage_context_field: string | null
          triage_enabled: boolean
          triage_keywords: string[] | null
          triage_prompt: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          name: string
          tree_id: string
          triage_context_field?: string | null
          triage_enabled?: boolean
          triage_keywords?: string[] | null
          triage_prompt?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          name?: string
          tree_id?: string
          triage_context_field?: string | null
          triage_enabled?: boolean
          triage_keywords?: string[] | null
          triage_prompt?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      discovery_questions: {
        Row: {
          category: string | null
          created_at: string
          functional_area_id: string
          id: string
          is_active: boolean | null
          question: string
          sort_order: number | null
          updated_at: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          functional_area_id: string
          id?: string
          is_active?: boolean | null
          question: string
          sort_order?: number | null
          updated_at?: string
        }
        Update: {
          category?: string | null
          created_at?: string
          functional_area_id?: string
          id?: string
          is_active?: boolean | null
          question?: string
          sort_order?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "discovery_questions_functional_area_id_fkey"
            columns: ["functional_area_id"]
            isOneToOne: false
            referencedRelation: "functional_areas"
            referencedColumns: ["id"]
          },
        ]
      }
      email_log: {
        Row: {
          created_at: string | null
          id: string
          recipient_email: string
          recipient_user_id: string | null
          resend_id: string | null
          status: string
          subject: string
          template_key: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          recipient_email: string
          recipient_user_id?: string | null
          resend_id?: string | null
          status: string
          subject: string
          template_key: string
        }
        Update: {
          created_at?: string | null
          id?: string
          recipient_email?: string
          recipient_user_id?: string | null
          resend_id?: string | null
          status?: string
          subject?: string
          template_key?: string
        }
        Relationships: []
      }
      email_queue: {
        Row: {
          created_at: string | null
          data: Json | null
          error_message: string | null
          html_content: string
          id: string
          recipient_email: string
          recipient_user_id: string | null
          retry_count: number | null
          scheduled_for: string | null
          sent_at: string | null
          status: string | null
          subject: string
          template_key: string
        }
        Insert: {
          created_at?: string | null
          data?: Json | null
          error_message?: string | null
          html_content: string
          id?: string
          recipient_email: string
          recipient_user_id?: string | null
          retry_count?: number | null
          scheduled_for?: string | null
          sent_at?: string | null
          status?: string | null
          subject: string
          template_key: string
        }
        Update: {
          created_at?: string | null
          data?: Json | null
          error_message?: string | null
          html_content?: string
          id?: string
          recipient_email?: string
          recipient_user_id?: string | null
          retry_count?: number | null
          scheduled_for?: string | null
          sent_at?: string | null
          status?: string | null
          subject?: string
          template_key?: string
        }
        Relationships: []
      }
      email_templates: {
        Row: {
          created_at: string | null
          description: string | null
          html_template: string
          id: string
          is_active: boolean | null
          name: string
          subject: string
          template_key: string
          updated_at: string | null
          updated_by: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          html_template: string
          id?: string
          is_active?: boolean | null
          name: string
          subject: string
          template_key: string
          updated_at?: string | null
          updated_by?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          html_template?: string
          id?: string
          is_active?: boolean | null
          name?: string
          subject?: string
          template_key?: string
          updated_at?: string | null
          updated_by?: string | null
        }
        Relationships: []
      }
      evaluation_success_criteria: {
        Row: {
          created_at: string
          criterion: string
          current_value: string | null
          id: string
          linked_use_case_ids: string[] | null
          metric_name: string | null
          notes: string | null
          opportunity_id: string
          source: string | null
          source_transcript_id: string | null
          status: string
          target_value: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          criterion: string
          current_value?: string | null
          id?: string
          linked_use_case_ids?: string[] | null
          metric_name?: string | null
          notes?: string | null
          opportunity_id: string
          source?: string | null
          source_transcript_id?: string | null
          status?: string
          target_value?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          criterion?: string
          current_value?: string | null
          id?: string
          linked_use_case_ids?: string[] | null
          metric_name?: string | null
          notes?: string | null
          opportunity_id?: string
          source?: string | null
          source_transcript_id?: string | null
          status?: string
          target_value?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "evaluation_success_criteria_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "evaluation_success_criteria_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      evaluation_technical_risks: {
        Row: {
          created_at: string
          customer_owner: string | null
          entry_type: string
          id: string
          mitigation_plan: string | null
          opportunity_id: string
          owner_email: string | null
          project_impact: string | null
          risk_description: string
          severity: string
          source: string | null
          source_transcript_id: string | null
          status: string
          technical_root_cause: string | null
          tracker_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_owner?: string | null
          entry_type?: string
          id?: string
          mitigation_plan?: string | null
          opportunity_id: string
          owner_email?: string | null
          project_impact?: string | null
          risk_description: string
          severity?: string
          source?: string | null
          source_transcript_id?: string | null
          status?: string
          technical_root_cause?: string | null
          tracker_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_owner?: string | null
          entry_type?: string
          id?: string
          mitigation_plan?: string | null
          opportunity_id?: string
          owner_email?: string | null
          project_impact?: string | null
          risk_description?: string
          severity?: string
          source?: string | null
          source_transcript_id?: string | null
          status?: string
          technical_root_cause?: string | null
          tracker_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "evaluation_technical_risks_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "evaluation_technical_risks_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      functional_areas: {
        Row: {
          color: string | null
          created_at: string
          default_height: number | null
          default_width: number | null
          description: string | null
          id: string
          layer: string
          name: string
          sort_order: number | null
        }
        Insert: {
          color?: string | null
          created_at?: string
          default_height?: number | null
          default_width?: number | null
          description?: string | null
          id?: string
          layer?: string
          name: string
          sort_order?: number | null
        }
        Update: {
          color?: string | null
          created_at?: string
          default_height?: number | null
          default_width?: number | null
          description?: string | null
          id?: string
          layer?: string
          name?: string
          sort_order?: number | null
        }
        Relationships: []
      }
      inbound_emails: {
        Row: {
          bcc_emails: string[] | null
          cc_emails: string[] | null
          created_at: string
          email_sent_at: string | null
          from_email: string
          from_name: string | null
          html_body: string | null
          id: string
          match_confidence: number | null
          match_details: Json | null
          match_method: string | null
          match_status: string
          matched_account_id: string | null
          matched_opportunity_id: string | null
          processed_at: string | null
          raw_headers: Json | null
          received_at: string
          resend_message_id: string | null
          review_notes: string | null
          reviewed_by: string | null
          subject: string | null
          text_body: string | null
          to_emails: string[] | null
          transcript_review_id: string | null
          updated_at: string
        }
        Insert: {
          bcc_emails?: string[] | null
          cc_emails?: string[] | null
          created_at?: string
          email_sent_at?: string | null
          from_email: string
          from_name?: string | null
          html_body?: string | null
          id?: string
          match_confidence?: number | null
          match_details?: Json | null
          match_method?: string | null
          match_status?: string
          matched_account_id?: string | null
          matched_opportunity_id?: string | null
          processed_at?: string | null
          raw_headers?: Json | null
          received_at?: string
          resend_message_id?: string | null
          review_notes?: string | null
          reviewed_by?: string | null
          subject?: string | null
          text_body?: string | null
          to_emails?: string[] | null
          transcript_review_id?: string | null
          updated_at?: string
        }
        Update: {
          bcc_emails?: string[] | null
          cc_emails?: string[] | null
          created_at?: string
          email_sent_at?: string | null
          from_email?: string
          from_name?: string | null
          html_body?: string | null
          id?: string
          match_confidence?: number | null
          match_details?: Json | null
          match_method?: string | null
          match_status?: string
          matched_account_id?: string | null
          matched_opportunity_id?: string | null
          processed_at?: string | null
          raw_headers?: Json | null
          received_at?: string
          resend_message_id?: string | null
          review_notes?: string | null
          reviewed_by?: string | null
          subject?: string | null
          text_body?: string | null
          to_emails?: string[] | null
          transcript_review_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "inbound_emails_matched_account_id_fkey"
            columns: ["matched_account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inbound_emails_matched_opportunity_id_fkey"
            columns: ["matched_opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inbound_emails_transcript_review_id_fkey"
            columns: ["transcript_review_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      insight_trend_metrics: {
        Row: {
          account_id: string | null
          avg_confidence: number | null
          category_counts: Json | null
          created_at: string
          id: string
          insight_type: string
          metric_date: string
          new_count: number
          priority_distribution: Json | null
          resolved_count: number
          severity_distribution: Json | null
          status_distribution: Json | null
          theme_counts: Json | null
          total_count: number
          updated_at: string
        }
        Insert: {
          account_id?: string | null
          avg_confidence?: number | null
          category_counts?: Json | null
          created_at?: string
          id?: string
          insight_type: string
          metric_date: string
          new_count?: number
          priority_distribution?: Json | null
          resolved_count?: number
          severity_distribution?: Json | null
          status_distribution?: Json | null
          theme_counts?: Json | null
          total_count?: number
          updated_at?: string
        }
        Update: {
          account_id?: string | null
          avg_confidence?: number | null
          category_counts?: Json | null
          created_at?: string
          id?: string
          insight_type?: string
          metric_date?: string
          new_count?: number
          priority_distribution?: Json | null
          resolved_count?: number
          severity_distribution?: Json | null
          status_distribution?: Json | null
          theme_counts?: Json | null
          total_count?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "insight_trend_metrics_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      layers: {
        Row: {
          bg_color: string
          color: string
          created_at: string
          height: number
          id: string
          label: string
          line_color: string
          name: string
          sort_order: number
          subtitle: string | null
          updated_at: string
        }
        Insert: {
          bg_color?: string
          color?: string
          created_at?: string
          height?: number
          id?: string
          label: string
          line_color?: string
          name: string
          sort_order?: number
          subtitle?: string | null
          updated_at?: string
        }
        Update: {
          bg_color?: string
          color?: string
          created_at?: string
          height?: number
          id?: string
          label?: string
          line_color?: string
          name?: string
          sort_order?: number
          subtitle?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      login_history: {
        Row: {
          encryption_iv: string | null
          failure_reason: string | null
          id: string
          ip_address: string | null
          ip_address_encrypted: string | null
          is_encrypted: boolean | null
          login_at: string
          session_id: string | null
          success: boolean
          user_agent: string | null
          user_agent_encrypted: string | null
          user_id: string
        }
        Insert: {
          encryption_iv?: string | null
          failure_reason?: string | null
          id?: string
          ip_address?: string | null
          ip_address_encrypted?: string | null
          is_encrypted?: boolean | null
          login_at?: string
          session_id?: string | null
          success?: boolean
          user_agent?: string | null
          user_agent_encrypted?: string | null
          user_id: string
        }
        Update: {
          encryption_iv?: string | null
          failure_reason?: string | null
          id?: string
          ip_address?: string | null
          ip_address_encrypted?: string | null
          is_encrypted?: boolean | null
          login_at?: string
          session_id?: string | null
          success?: boolean
          user_agent?: string | null
          user_agent_encrypted?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "login_history_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "login_history_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      manual_meetings: {
        Row: {
          account_id: string | null
          attendee_emails: string[]
          created_at: string
          created_by: string
          id: string
          is_highlighted: boolean
          meeting_date: string
          meeting_type: string
          notes: string | null
          opportunity_id: string | null
          updated_at: string
        }
        Insert: {
          account_id?: string | null
          attendee_emails?: string[]
          created_at?: string
          created_by: string
          id?: string
          is_highlighted?: boolean
          meeting_date: string
          meeting_type?: string
          notes?: string | null
          opportunity_id?: string | null
          updated_at?: string
        }
        Update: {
          account_id?: string | null
          attendee_emails?: string[]
          created_at?: string
          created_by?: string
          id?: string
          is_highlighted?: boolean
          meeting_date?: string
          meeting_type?: string
          notes?: string | null
          opportunity_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "manual_meetings_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "manual_meetings_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      mcp_access_logs: {
        Row: {
          api_key_id: string | null
          api_key_name: string | null
          created_at: string
          error_message: string | null
          execution_time_ms: number | null
          id: string
          request_params: Json | null
          response_status: string
          tool_name: string
        }
        Insert: {
          api_key_id?: string | null
          api_key_name?: string | null
          created_at?: string
          error_message?: string | null
          execution_time_ms?: number | null
          id?: string
          request_params?: Json | null
          response_status?: string
          tool_name: string
        }
        Update: {
          api_key_id?: string | null
          api_key_name?: string | null
          created_at?: string
          error_message?: string | null
          execution_time_ms?: number | null
          id?: string
          request_params?: Json | null
          response_status?: string
          tool_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "mcp_access_logs_api_key_id_fkey"
            columns: ["api_key_id"]
            isOneToOne: false
            referencedRelation: "mcp_api_keys"
            referencedColumns: ["id"]
          },
        ]
      }
      mcp_api_keys: {
        Row: {
          allowed_tools: string[] | null
          created_at: string
          created_by: string | null
          description: string | null
          expires_at: string | null
          id: string
          is_active: boolean
          key_hash: string
          key_prefix: string
          last_used_at: string | null
          name: string
          permissions: Json
          request_count: number
          updated_at: string
        }
        Insert: {
          allowed_tools?: string[] | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean
          key_hash: string
          key_prefix: string
          last_used_at?: string | null
          name: string
          permissions?: Json
          request_count?: number
          updated_at?: string
        }
        Update: {
          allowed_tools?: string[] | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean
          key_hash?: string
          key_prefix?: string
          last_used_at?: string | null
          name?: string
          permissions?: Json
          request_count?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "mcp_api_keys_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mcp_api_keys_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      milestone_history: {
        Row: {
          change_source: string
          changed_at: string
          changed_by: string | null
          encryption_iv: string | null
          field_changed: string
          id: string
          is_encrypted: boolean | null
          milestone_id: string
          new_value: Json
          new_value_encrypted: string | null
          notes: string | null
          notes_encrypted: string | null
          old_value: Json | null
          old_value_encrypted: string | null
          opportunity_id: string
        }
        Insert: {
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          encryption_iv?: string | null
          field_changed: string
          id?: string
          is_encrypted?: boolean | null
          milestone_id: string
          new_value: Json
          new_value_encrypted?: string | null
          notes?: string | null
          notes_encrypted?: string | null
          old_value?: Json | null
          old_value_encrypted?: string | null
          opportunity_id: string
        }
        Update: {
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          encryption_iv?: string | null
          field_changed?: string
          id?: string
          is_encrypted?: boolean | null
          milestone_id?: string
          new_value?: Json
          new_value_encrypted?: string | null
          notes?: string | null
          notes_encrypted?: string | null
          old_value?: Json | null
          old_value_encrypted?: string | null
          opportunity_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "milestone_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "milestone_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "milestone_history_milestone_id_fkey"
            columns: ["milestone_id"]
            isOneToOne: false
            referencedRelation: "opportunity_milestones"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "milestone_history_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      milestone_templates: {
        Row: {
          created_at: string
          default_participants: string | null
          description: string | null
          id: string
          name: string
          phase: string
          sort_order: number | null
          typical_duration_days: number | null
        }
        Insert: {
          created_at?: string
          default_participants?: string | null
          description?: string | null
          id?: string
          name: string
          phase: string
          sort_order?: number | null
          typical_duration_days?: number | null
        }
        Update: {
          created_at?: string
          default_participants?: string | null
          description?: string | null
          id?: string
          name?: string
          phase?: string
          sort_order?: number | null
          typical_duration_days?: number | null
        }
        Relationships: []
      }
      module_pricing: {
        Row: {
          created_at: string
          description: string | null
          discount_percentage: number | null
          discount_reason: string | null
          fixed_cost: number | null
          functional_area_id: string | null
          id: string
          is_active: boolean | null
          is_base_module: boolean | null
          mau_percentage: number | null
          module_name: string
          module_type: string
          per_mau_cost: number | null
          sort_order: number | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          discount_percentage?: number | null
          discount_reason?: string | null
          fixed_cost?: number | null
          functional_area_id?: string | null
          id?: string
          is_active?: boolean | null
          is_base_module?: boolean | null
          mau_percentage?: number | null
          module_name: string
          module_type?: string
          per_mau_cost?: number | null
          sort_order?: number | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          discount_percentage?: number | null
          discount_reason?: string | null
          fixed_cost?: number | null
          functional_area_id?: string | null
          id?: string
          is_active?: boolean | null
          is_base_module?: boolean | null
          mau_percentage?: number | null
          module_name?: string
          module_type?: string
          per_mau_cost?: number | null
          sort_order?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "module_pricing_functional_area_id_fkey"
            columns: ["functional_area_id"]
            isOneToOne: false
            referencedRelation: "functional_areas"
            referencedColumns: ["id"]
          },
        ]
      }
      momentum_meetings: {
        Row: {
          attendees: Json | null
          attendees_encrypted: string | null
          created_at: string
          encryption_iv: string | null
          end_time: string | null
          host_email: string | null
          host_email_encrypted: string | null
          host_name: string | null
          host_name_encrypted: string | null
          id: string
          ignored_at: string | null
          imported_at: string | null
          is_encrypted: boolean | null
          is_highlighted: boolean | null
          manual_meeting_type: string | null
          matched_account_id: string | null
          meeting_context: string
          meeting_type_confidence: number | null
          momentum_id: string | null
          notes: string | null
          opportunity_id: string | null
          pii_encryption_iv: string | null
          retry_count: number | null
          salesforce_account_id: string | null
          salesforce_opportunity_id: string | null
          source: string
          start_time: string
          status: string
          title: string | null
          title_encrypted: string | null
          transcript_content: string | null
          transcript_content_encrypted: string | null
          transcript_content_hash: string | null
          updated_at: string
        }
        Insert: {
          attendees?: Json | null
          attendees_encrypted?: string | null
          created_at?: string
          encryption_iv?: string | null
          end_time?: string | null
          host_email?: string | null
          host_email_encrypted?: string | null
          host_name?: string | null
          host_name_encrypted?: string | null
          id?: string
          ignored_at?: string | null
          imported_at?: string | null
          is_encrypted?: boolean | null
          is_highlighted?: boolean | null
          manual_meeting_type?: string | null
          matched_account_id?: string | null
          meeting_context?: string
          meeting_type_confidence?: number | null
          momentum_id?: string | null
          notes?: string | null
          opportunity_id?: string | null
          pii_encryption_iv?: string | null
          retry_count?: number | null
          salesforce_account_id?: string | null
          salesforce_opportunity_id?: string | null
          source?: string
          start_time: string
          status?: string
          title?: string | null
          title_encrypted?: string | null
          transcript_content?: string | null
          transcript_content_encrypted?: string | null
          transcript_content_hash?: string | null
          updated_at?: string
        }
        Update: {
          attendees?: Json | null
          attendees_encrypted?: string | null
          created_at?: string
          encryption_iv?: string | null
          end_time?: string | null
          host_email?: string | null
          host_email_encrypted?: string | null
          host_name?: string | null
          host_name_encrypted?: string | null
          id?: string
          ignored_at?: string | null
          imported_at?: string | null
          is_encrypted?: boolean | null
          is_highlighted?: boolean | null
          manual_meeting_type?: string | null
          matched_account_id?: string | null
          meeting_context?: string
          meeting_type_confidence?: number | null
          momentum_id?: string | null
          notes?: string | null
          opportunity_id?: string | null
          pii_encryption_iv?: string | null
          retry_count?: number | null
          salesforce_account_id?: string | null
          salesforce_opportunity_id?: string | null
          source?: string
          start_time?: string
          status?: string
          title?: string | null
          title_encrypted?: string | null
          transcript_content?: string | null
          transcript_content_encrypted?: string | null
          transcript_content_hash?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "momentum_meetings_matched_account_id_fkey"
            columns: ["matched_account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "momentum_meetings_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      momentum_sync_state: {
        Row: {
          created_at: string
          id: string
          is_enabled: boolean
          last_sync_at: string
          meetings_synced: number | null
        }
        Insert: {
          created_at?: string
          id?: string
          is_enabled?: boolean
          last_sync_at?: string
          meetings_synced?: number | null
        }
        Update: {
          created_at?: string
          id?: string
          is_enabled?: boolean
          last_sync_at?: string
          meetings_synced?: number | null
        }
        Relationships: []
      }
      nba_completion_history: {
        Row: {
          account_id: string
          auto_complete_transcript_id: string | null
          auto_completed: boolean | null
          change_source: string
          changed_at: string
          changed_by: string | null
          completed_at: string | null
          id: string
          nba_id: string
          new_status: string
          old_status: string | null
          opportunity_id: string | null
        }
        Insert: {
          account_id: string
          auto_complete_transcript_id?: string | null
          auto_completed?: boolean | null
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          completed_at?: string | null
          id?: string
          nba_id: string
          new_status: string
          old_status?: string | null
          opportunity_id?: string | null
        }
        Update: {
          account_id?: string
          auto_complete_transcript_id?: string | null
          auto_completed?: boolean | null
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          completed_at?: string | null
          id?: string
          nba_id?: string
          new_status?: string
          old_status?: string | null
          opportunity_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "nba_completion_history_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "nba_completion_history_auto_complete_transcript_id_fkey"
            columns: ["auto_complete_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "nba_completion_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "nba_completion_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "nba_completion_history_nba_id_fkey"
            columns: ["nba_id"]
            isOneToOne: false
            referencedRelation: "account_nbas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "nba_completion_history_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      nba_due_date_changes: {
        Row: {
          change_reason: string | null
          change_type: string
          changed_by: string | null
          changed_by_email: string | null
          created_at: string
          days_changed: number | null
          id: string
          nba_id: string
          new_due_date: string
          previous_due_date: string | null
        }
        Insert: {
          change_reason?: string | null
          change_type: string
          changed_by?: string | null
          changed_by_email?: string | null
          created_at?: string
          days_changed?: number | null
          id?: string
          nba_id: string
          new_due_date: string
          previous_due_date?: string | null
        }
        Update: {
          change_reason?: string | null
          change_type?: string
          changed_by?: string | null
          changed_by_email?: string | null
          created_at?: string
          days_changed?: number | null
          id?: string
          nba_id?: string
          new_due_date?: string
          previous_due_date?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "nba_due_date_changes_nba_id_fkey"
            columns: ["nba_id"]
            isOneToOne: false
            referencedRelation: "account_nbas"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_preferences: {
        Row: {
          created_at: string | null
          digest_day: number | null
          digest_time: string | null
          email_enabled: boolean | null
          frequency: string | null
          id: string
          notify_alerts: boolean | null
          notify_new_actions: boolean | null
          notify_overdue_reminders: boolean | null
          quiet_hours_end: string | null
          quiet_hours_start: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          digest_day?: number | null
          digest_time?: string | null
          email_enabled?: boolean | null
          frequency?: string | null
          id?: string
          notify_alerts?: boolean | null
          notify_new_actions?: boolean | null
          notify_overdue_reminders?: boolean | null
          quiet_hours_end?: string | null
          quiet_hours_start?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          digest_day?: number | null
          digest_time?: string | null
          email_enabled?: boolean | null
          frequency?: string | null
          id?: string
          notify_alerts?: boolean | null
          notify_new_actions?: boolean | null
          notify_overdue_reminders?: boolean | null
          quiet_hours_end?: string | null
          quiet_hours_start?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notification_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notification_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_types: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          is_enabled: boolean | null
          name: string
          template_id: string | null
          type_key: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_enabled?: boolean | null
          name: string
          template_id?: string | null
          type_key: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_enabled?: boolean | null
          name?: string
          template_id?: string | null
          type_key?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notification_types_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "email_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      operational_questions: {
        Row: {
          category: string
          created_at: string
          id: string
          is_active: boolean | null
          question: string
          sort_order: number | null
          sub_category: string | null
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          id?: string
          is_active?: boolean | null
          question: string
          sort_order?: number | null
          sub_category?: string | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          is_active?: boolean | null
          question?: string
          sort_order?: number | null
          sub_category?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      opportunities: {
        Row: {
          account_id: string
          close_date: string | null
          competitive_threat_level: string | null
          competitive_threat_score: number | null
          created_at: string
          demo_request_signal_detected_at: string | null
          description: string | null
          detection_signal_fields: Json | null
          employee_count: number | null
          engagement_score: number | null
          eval_end_date: string | null
          eval_notes: string | null
          eval_phase_override: string | null
          eval_radar_dismissed: boolean
          eval_start_date: string | null
          eval_type: string | null
          evaluation_signal_detected_at: string | null
          id: string
          included_module_ids: string[] | null
          initial_product_interest: string[] | null
          is_archived: boolean | null
          last_meeting_at: string | null
          mau_count: number | null
          momentum_score: number | null
          name: string
          next_step: string | null
          opportunity_type: string | null
          owner_email: string | null
          owner_id: string | null
          pre_sales_stage: string | null
          primary_competitor_id: string | null
          primary_eval_quote: string | null
          primary_se_email: string | null
          priority: string | null
          readiness_score: number | null
          relationship_status: string | null
          reverse_demo_signal_detected_at: string | null
          sales_stage: string | null
          salesforce_opportunity_id: string | null
          stage: string | null
          stage_changed_at: string | null
          tcv: number | null
          tcv_currency: string | null
          updated_at: string
          value: number | null
        }
        Insert: {
          account_id: string
          close_date?: string | null
          competitive_threat_level?: string | null
          competitive_threat_score?: number | null
          created_at?: string
          demo_request_signal_detected_at?: string | null
          description?: string | null
          detection_signal_fields?: Json | null
          employee_count?: number | null
          engagement_score?: number | null
          eval_end_date?: string | null
          eval_notes?: string | null
          eval_phase_override?: string | null
          eval_radar_dismissed?: boolean
          eval_start_date?: string | null
          eval_type?: string | null
          evaluation_signal_detected_at?: string | null
          id?: string
          included_module_ids?: string[] | null
          initial_product_interest?: string[] | null
          is_archived?: boolean | null
          last_meeting_at?: string | null
          mau_count?: number | null
          momentum_score?: number | null
          name: string
          next_step?: string | null
          opportunity_type?: string | null
          owner_email?: string | null
          owner_id?: string | null
          pre_sales_stage?: string | null
          primary_competitor_id?: string | null
          primary_eval_quote?: string | null
          primary_se_email?: string | null
          priority?: string | null
          readiness_score?: number | null
          relationship_status?: string | null
          reverse_demo_signal_detected_at?: string | null
          sales_stage?: string | null
          salesforce_opportunity_id?: string | null
          stage?: string | null
          stage_changed_at?: string | null
          tcv?: number | null
          tcv_currency?: string | null
          updated_at?: string
          value?: number | null
        }
        Update: {
          account_id?: string
          close_date?: string | null
          competitive_threat_level?: string | null
          competitive_threat_score?: number | null
          created_at?: string
          demo_request_signal_detected_at?: string | null
          description?: string | null
          detection_signal_fields?: Json | null
          employee_count?: number | null
          engagement_score?: number | null
          eval_end_date?: string | null
          eval_notes?: string | null
          eval_phase_override?: string | null
          eval_radar_dismissed?: boolean
          eval_start_date?: string | null
          eval_type?: string | null
          evaluation_signal_detected_at?: string | null
          id?: string
          included_module_ids?: string[] | null
          initial_product_interest?: string[] | null
          is_archived?: boolean | null
          last_meeting_at?: string | null
          mau_count?: number | null
          momentum_score?: number | null
          name?: string
          next_step?: string | null
          opportunity_type?: string | null
          owner_email?: string | null
          owner_id?: string | null
          pre_sales_stage?: string | null
          primary_competitor_id?: string | null
          primary_eval_quote?: string | null
          primary_se_email?: string | null
          priority?: string | null
          readiness_score?: number | null
          relationship_status?: string | null
          reverse_demo_signal_detected_at?: string | null
          sales_stage?: string | null
          salesforce_opportunity_id?: string | null
          stage?: string | null
          stage_changed_at?: string | null
          tcv?: number | null
          tcv_currency?: string | null
          updated_at?: string
          value?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "opportunities_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunities_primary_competitor_id_fkey"
            columns: ["primary_competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_activities: {
        Row: {
          account_id: string
          activity_date: string
          activity_type_id: string
          ae_email: string | null
          assigned_to: string | null
          confidence_score: number | null
          created_at: string
          detection_source: string | null
          id: string
          notes: string | null
          opportunity_id: string
          se_email: string | null
          sentiment_label: string | null
          sentiment_score: number | null
          summary_text: string | null
          title: string | null
          transcript_id: string | null
          updated_at: string
        }
        Insert: {
          account_id: string
          activity_date: string
          activity_type_id: string
          ae_email?: string | null
          assigned_to?: string | null
          confidence_score?: number | null
          created_at?: string
          detection_source?: string | null
          id?: string
          notes?: string | null
          opportunity_id: string
          se_email?: string | null
          sentiment_label?: string | null
          sentiment_score?: number | null
          summary_text?: string | null
          title?: string | null
          transcript_id?: string | null
          updated_at?: string
        }
        Update: {
          account_id?: string
          activity_date?: string
          activity_type_id?: string
          ae_email?: string | null
          assigned_to?: string | null
          confidence_score?: number | null
          created_at?: string
          detection_source?: string | null
          id?: string
          notes?: string | null
          opportunity_id?: string
          se_email?: string | null
          sentiment_label?: string | null
          sentiment_score?: number | null
          summary_text?: string | null
          title?: string | null
          transcript_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_activities_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_activities_activity_type_id_fkey"
            columns: ["activity_type_id"]
            isOneToOne: false
            referencedRelation: "activity_types"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_activities_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_activities_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: true
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_alert_history: {
        Row: {
          id: string
          is_from_system_rule: boolean | null
          nba_id: string | null
          opportunity_id: string
          rule_id: string
          rule_owner_id: string | null
          trigger_data: Json | null
          triggered_at: string
        }
        Insert: {
          id?: string
          is_from_system_rule?: boolean | null
          nba_id?: string | null
          opportunity_id: string
          rule_id: string
          rule_owner_id?: string | null
          trigger_data?: Json | null
          triggered_at?: string
        }
        Update: {
          id?: string
          is_from_system_rule?: boolean | null
          nba_id?: string | null
          opportunity_id?: string
          rule_id?: string
          rule_owner_id?: string | null
          trigger_data?: Json | null
          triggered_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_alert_history_nba_id_fkey"
            columns: ["nba_id"]
            isOneToOne: false
            referencedRelation: "account_nbas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_alert_history_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_alert_history_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "opportunity_alert_rules"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_alert_history_rule_owner_id_fkey"
            columns: ["rule_owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_alert_history_rule_owner_id_fkey"
            columns: ["rule_owner_id"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_alert_rules: {
        Row: {
          assigned_to_type: string
          cooldown_days: number
          copied_from_rule_id: string | null
          created_at: string
          description: string | null
          exclude_archived: boolean | null
          id: string
          is_active: boolean
          is_system_rule: boolean
          name: string
          nba_action_text: string
          nba_delivery_method: string
          nba_priority: string
          owner_id: string | null
          rule_type: string
          sort_order: number | null
          threshold_config: Json
          updated_at: string
        }
        Insert: {
          assigned_to_type?: string
          cooldown_days?: number
          copied_from_rule_id?: string | null
          created_at?: string
          description?: string | null
          exclude_archived?: boolean | null
          id?: string
          is_active?: boolean
          is_system_rule?: boolean
          name: string
          nba_action_text: string
          nba_delivery_method?: string
          nba_priority?: string
          owner_id?: string | null
          rule_type: string
          sort_order?: number | null
          threshold_config?: Json
          updated_at?: string
        }
        Update: {
          assigned_to_type?: string
          cooldown_days?: number
          copied_from_rule_id?: string | null
          created_at?: string
          description?: string | null
          exclude_archived?: boolean | null
          id?: string
          is_active?: boolean
          is_system_rule?: boolean
          name?: string
          nba_action_text?: string
          nba_delivery_method?: string
          nba_priority?: string
          owner_id?: string | null
          rule_type?: string
          sort_order?: number | null
          threshold_config?: Json
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_alert_rules_copied_from_rule_id_fkey"
            columns: ["copied_from_rule_id"]
            isOneToOne: false
            referencedRelation: "opportunity_alert_rules"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_alert_rules_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_alert_rules_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_competitive_insights: {
        Row: {
          account_id: string
          comparison_notes: string | null
          comparison_notes_encrypted: string | null
          competitor_id: string | null
          competitor_name: string
          confidence_score: number | null
          created_at: string
          detected_at: string
          encryption_iv: string | null
          evidence_confidence_weight: number
          evidence_source: string
          feature_discussed: string | null
          id: string
          is_encrypted: boolean | null
          is_objection: boolean | null
          loss_signal: boolean | null
          mention_context: string | null
          mention_context_encrypted: string | null
          mention_type: string | null
          objection_severity: string | null
          objection_text: string | null
          objection_text_encrypted: string | null
          objection_type: string | null
          opportunity_id: string
          pendo_position: string | null
          sentiment: string | null
          signal_indicator: string | null
          speaker_email: string | null
          speaker_name: string | null
          speaker_type: string | null
          transcript_id: string | null
          updated_at: string
          win_signal: boolean | null
        }
        Insert: {
          account_id: string
          comparison_notes?: string | null
          comparison_notes_encrypted?: string | null
          competitor_id?: string | null
          competitor_name: string
          confidence_score?: number | null
          created_at?: string
          detected_at?: string
          encryption_iv?: string | null
          evidence_confidence_weight?: number
          evidence_source?: string
          feature_discussed?: string | null
          id?: string
          is_encrypted?: boolean | null
          is_objection?: boolean | null
          loss_signal?: boolean | null
          mention_context?: string | null
          mention_context_encrypted?: string | null
          mention_type?: string | null
          objection_severity?: string | null
          objection_text?: string | null
          objection_text_encrypted?: string | null
          objection_type?: string | null
          opportunity_id: string
          pendo_position?: string | null
          sentiment?: string | null
          signal_indicator?: string | null
          speaker_email?: string | null
          speaker_name?: string | null
          speaker_type?: string | null
          transcript_id?: string | null
          updated_at?: string
          win_signal?: boolean | null
        }
        Update: {
          account_id?: string
          comparison_notes?: string | null
          comparison_notes_encrypted?: string | null
          competitor_id?: string | null
          competitor_name?: string
          confidence_score?: number | null
          created_at?: string
          detected_at?: string
          encryption_iv?: string | null
          evidence_confidence_weight?: number
          evidence_source?: string
          feature_discussed?: string | null
          id?: string
          is_encrypted?: boolean | null
          is_objection?: boolean | null
          loss_signal?: boolean | null
          mention_context?: string | null
          mention_context_encrypted?: string | null
          mention_type?: string | null
          objection_severity?: string | null
          objection_text?: string | null
          objection_text_encrypted?: string | null
          objection_type?: string | null
          opportunity_id?: string
          pendo_position?: string | null
          sentiment?: string | null
          signal_indicator?: string | null
          speaker_email?: string | null
          speaker_name?: string | null
          speaker_type?: string | null
          transcript_id?: string | null
          updated_at?: string
          win_signal?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_competitive_insights_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_competitive_insights_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_competitive_insights_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_competitive_insights_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_deletion_tombstones: {
        Row: {
          account_id: string
          deleted_at: string
          deleted_by: string | null
          id: string
          opportunity_id: string | null
          salesforce_opportunity_id: string | null
        }
        Insert: {
          account_id: string
          deleted_at?: string
          deleted_by?: string | null
          id?: string
          opportunity_id?: string | null
          salesforce_opportunity_id?: string | null
        }
        Update: {
          account_id?: string
          deleted_at?: string
          deleted_by?: string | null
          id?: string
          opportunity_id?: string | null
          salesforce_opportunity_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_deletion_tombstones_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_deletion_tombstones_deleted_by_fkey"
            columns: ["deleted_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_deletion_tombstones_deleted_by_fkey"
            columns: ["deleted_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_deletion_tombstones_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_deployment_types: {
        Row: {
          created_at: string
          deployment_type_id: string
          id: string
          opportunity_id: string
        }
        Insert: {
          created_at?: string
          deployment_type_id: string
          id?: string
          opportunity_id: string
        }
        Update: {
          created_at?: string
          deployment_type_id?: string
          id?: string
          opportunity_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_deployment_types_deployment_type_id_fkey"
            columns: ["deployment_type_id"]
            isOneToOne: false
            referencedRelation: "deployment_types"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_deployment_types_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_metric_history: {
        Row: {
          change_reason: string | null
          change_source: string
          changed_at: string
          changed_by: string | null
          confidence_score: number | null
          id: string
          metric_type: string
          new_value: Json
          old_value: Json | null
          opportunity_id: string
          source_transcript_id: string | null
        }
        Insert: {
          change_reason?: string | null
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          confidence_score?: number | null
          id?: string
          metric_type: string
          new_value: Json
          old_value?: Json | null
          opportunity_id: string
          source_transcript_id?: string | null
        }
        Update: {
          change_reason?: string | null
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          confidence_score?: number | null
          id?: string
          metric_type?: string
          new_value?: Json
          old_value?: Json | null
          opportunity_id?: string
          source_transcript_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_metric_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_metric_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_metric_history_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_metric_history_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_milestones: {
        Row: {
          assigned_to: string | null
          completed_date: string | null
          created_at: string
          description: string | null
          description_encrypted: string | null
          encryption_iv: string | null
          id: string
          is_encrypted: boolean | null
          name: string | null
          notes: string | null
          notes_encrypted: string | null
          opportunity_id: string
          phase: string
          required_participants: string | null
          scheduled_date: string | null
          sort_order: number | null
          status: string
          template_id: string | null
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          completed_date?: string | null
          created_at?: string
          description?: string | null
          description_encrypted?: string | null
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          name?: string | null
          notes?: string | null
          notes_encrypted?: string | null
          opportunity_id: string
          phase: string
          required_participants?: string | null
          scheduled_date?: string | null
          sort_order?: number | null
          status?: string
          template_id?: string | null
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          completed_date?: string | null
          created_at?: string
          description?: string | null
          description_encrypted?: string | null
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          name?: string | null
          notes?: string | null
          notes_encrypted?: string | null
          opportunity_id?: string
          phase?: string
          required_participants?: string | null
          scheduled_date?: string | null
          sort_order?: number | null
          status?: string
          template_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_milestones_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_milestones_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "milestone_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_readiness_answers: {
        Row: {
          answer: string | null
          answer_encrypted: string | null
          answer_json: Json | null
          app_id: string | null
          confidence_score: number | null
          created_at: string
          encryption_iv: string | null
          id: string
          is_encrypted: boolean | null
          is_red_flag: boolean | null
          last_confirmed_at: string | null
          last_confirmed_transcript_id: string | null
          manual_flag_status: string | null
          notes: string | null
          notes_encrypted: string | null
          opportunity_id: string
          question_id: string
          source: string | null
          source_transcript_id: string | null
          updated_at: string
        }
        Insert: {
          answer?: string | null
          answer_encrypted?: string | null
          answer_json?: Json | null
          app_id?: string | null
          confidence_score?: number | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          is_red_flag?: boolean | null
          last_confirmed_at?: string | null
          last_confirmed_transcript_id?: string | null
          manual_flag_status?: string | null
          notes?: string | null
          notes_encrypted?: string | null
          opportunity_id: string
          question_id: string
          source?: string | null
          source_transcript_id?: string | null
          updated_at?: string
        }
        Update: {
          answer?: string | null
          answer_encrypted?: string | null
          answer_json?: Json | null
          app_id?: string | null
          confidence_score?: number | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          is_red_flag?: boolean | null
          last_confirmed_at?: string | null
          last_confirmed_transcript_id?: string | null
          manual_flag_status?: string | null
          notes?: string | null
          notes_encrypted?: string | null
          opportunity_id?: string
          question_id?: string
          source?: string | null
          source_transcript_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_readiness_answers_app_id_fkey"
            columns: ["app_id"]
            isOneToOne: false
            referencedRelation: "opportunity_readiness_apps"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_readiness_answers_last_confirmed_transcript_id_fkey"
            columns: ["last_confirmed_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_readiness_answers_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_readiness_answers_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "readiness_template_questions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_readiness_answers_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_readiness_apps: {
        Row: {
          app_name: string
          created_at: string
          id: string
          is_primary: boolean
          opportunity_id: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          app_name: string
          created_at?: string
          id?: string
          is_primary?: boolean
          opportunity_id: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          app_name?: string
          created_at?: string
          id?: string
          is_primary?: boolean
          opportunity_id?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_readiness_apps_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_se_updates: {
        Row: {
          created_at: string
          encryption_iv: string | null
          id: string
          is_encrypted: boolean | null
          opportunity_id: string
          potential_risks: string | null
          potential_risks_encrypted: string | null
          updated_at: string
          updated_by: string
          weekly_update: string | null
          weekly_update_encrypted: string | null
        }
        Insert: {
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          opportunity_id: string
          potential_risks?: string | null
          potential_risks_encrypted?: string | null
          updated_at?: string
          updated_by: string
          weekly_update?: string | null
          weekly_update_encrypted?: string | null
        }
        Update: {
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          opportunity_id?: string
          potential_risks?: string | null
          potential_risks_encrypted?: string | null
          updated_at?: string
          updated_by?: string
          weekly_update?: string | null
          weekly_update_encrypted?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_se_updates_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_share_links: {
        Row: {
          access_count: number
          created_at: string
          created_by: string | null
          id: string
          label: string | null
          last_accessed_at: string | null
          opportunity_id: string
          revoked_at: string | null
          share_token: string
        }
        Insert: {
          access_count?: number
          created_at?: string
          created_by?: string | null
          id?: string
          label?: string | null
          last_accessed_at?: string | null
          opportunity_id: string
          revoked_at?: string | null
          share_token?: string
        }
        Update: {
          access_count?: number
          created_at?: string
          created_by?: string | null
          id?: string
          label?: string | null
          last_accessed_at?: string | null
          opportunity_id?: string
          revoked_at?: string | null
          share_token?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_share_links_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_share_links_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_share_links_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_stage_history: {
        Row: {
          change_source: string
          changed_at: string
          changed_by: string | null
          created_at: string
          duration_in_previous_stage: string | null
          id: string
          new_value: string
          notes: string | null
          old_value: string | null
          opportunity_id: string
          stage_type: string
        }
        Insert: {
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          created_at?: string
          duration_in_previous_stage?: string | null
          id?: string
          new_value: string
          notes?: string | null
          old_value?: string | null
          opportunity_id: string
          stage_type: string
        }
        Update: {
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          created_at?: string
          duration_in_previous_stage?: string | null
          id?: string
          new_value?: string
          notes?: string | null
          old_value?: string | null
          opportunity_id?: string
          stage_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_stage_history_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_summaries: {
        Row: {
          content_hash: string | null
          created_at: string
          generated_at: string
          id: string
          key_risks: string[] | null
          next_critical_action: string | null
          one_liner: string
          opportunity_id: string
          source_transcript_ids: string[] | null
          structured_brief: Json
          updated_at: string
        }
        Insert: {
          content_hash?: string | null
          created_at?: string
          generated_at?: string
          id?: string
          key_risks?: string[] | null
          next_critical_action?: string | null
          one_liner: string
          opportunity_id: string
          source_transcript_ids?: string[] | null
          structured_brief?: Json
          updated_at?: string
        }
        Update: {
          content_hash?: string | null
          created_at?: string
          generated_at?: string
          id?: string
          key_risks?: string[] | null
          next_critical_action?: string | null
          one_liner?: string
          opportunity_id?: string
          source_transcript_ids?: string[] | null
          structured_brief?: Json
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_summaries_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: true
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_team_members: {
        Row: {
          added_from_meeting_id: string | null
          created_at: string
          encryption_iv: string | null
          id: string
          is_encrypted: boolean | null
          opportunity_id: string
          role: string | null
          team_member_email: string | null
          team_member_email_encrypted: string | null
          updated_at: string
        }
        Insert: {
          added_from_meeting_id?: string | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          opportunity_id: string
          role?: string | null
          team_member_email?: string | null
          team_member_email_encrypted?: string | null
          updated_at?: string
        }
        Update: {
          added_from_meeting_id?: string | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          opportunity_id?: string
          role?: string | null
          team_member_email?: string | null
          team_member_email_encrypted?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_team_members_added_from_meeting_id_fkey"
            columns: ["added_from_meeting_id"]
            isOneToOne: false
            referencedRelation: "momentum_meetings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_team_members_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_validation_tasks: {
        Row: {
          activity: string
          completed_at: string | null
          created_at: string
          encryption_iv: string | null
          id: string
          is_encrypted: boolean | null
          linked_success_criteria_ids: string[] | null
          module: string
          notes: string | null
          notes_encrypted: string | null
          opportunity_id: string
          owner: string | null
          sort_order: number | null
          status: string
          sub_module: string | null
          template_id: string | null
          updated_at: string
        }
        Insert: {
          activity: string
          completed_at?: string | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          linked_success_criteria_ids?: string[] | null
          module: string
          notes?: string | null
          notes_encrypted?: string | null
          opportunity_id: string
          owner?: string | null
          sort_order?: number | null
          status?: string
          sub_module?: string | null
          template_id?: string | null
          updated_at?: string
        }
        Update: {
          activity?: string
          completed_at?: string | null
          created_at?: string
          encryption_iv?: string | null
          id?: string
          is_encrypted?: boolean | null
          linked_success_criteria_ids?: string[] | null
          module?: string
          notes?: string | null
          notes_encrypted?: string | null
          opportunity_id?: string
          owner?: string | null
          sort_order?: number | null
          status?: string
          sub_module?: string | null
          template_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_validation_tasks_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_validation_tasks_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "validation_task_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      page_role_access: {
        Row: {
          created_at: string
          id: string
          page_name: string
          page_path: string
          role: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          page_name: string
          page_path: string
          role: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          page_name?: string
          page_path?: string
          role?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "page_role_access_role_fkey"
            columns: ["role"]
            isOneToOne: false
            referencedRelation: "custom_roles"
            referencedColumns: ["name"]
          },
        ]
      }
      pre_sales_stage_mapping: {
        Row: {
          created_at: string
          id: string
          sort_order: number
          stage_key: string
          stage_label: string
          timeline_position: number
        }
        Insert: {
          created_at?: string
          id?: string
          sort_order: number
          stage_key: string
          stage_label: string
          timeline_position: number
        }
        Update: {
          created_at?: string
          id?: string
          sort_order?: number
          stage_key?: string
          stage_label?: string
          timeline_position?: number
        }
        Relationships: []
      }
      pricing_settings: {
        Row: {
          description: string | null
          id: string
          setting_key: string
          setting_value: number
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          description?: string | null
          id?: string
          setting_key: string
          setting_value?: number
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          description?: string | null
          id?: string
          setting_key?: string
          setting_value?: number
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "pricing_settings_updated_by_fkey"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pricing_settings_updated_by_fkey"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      product_mentions: {
        Row: {
          account_id: string | null
          confidence_score: number | null
          context_snippet: string | null
          created_at: string
          id: string
          integration_context: string | null
          is_manual: boolean | null
          meeting_context: string
          mention_count: number
          mention_type: string
          opportunity_id: string | null
          product_name: string
          sentiment_label: string | null
          sentiment_score: number | null
          speaker_type: string | null
          technology_id: string | null
          transcript_date: string | null
          transcript_id: string | null
          updated_at: string
        }
        Insert: {
          account_id?: string | null
          confidence_score?: number | null
          context_snippet?: string | null
          created_at?: string
          id?: string
          integration_context?: string | null
          is_manual?: boolean | null
          meeting_context?: string
          mention_count?: number
          mention_type: string
          opportunity_id?: string | null
          product_name: string
          sentiment_label?: string | null
          sentiment_score?: number | null
          speaker_type?: string | null
          technology_id?: string | null
          transcript_date?: string | null
          transcript_id?: string | null
          updated_at?: string
        }
        Update: {
          account_id?: string | null
          confidence_score?: number | null
          context_snippet?: string | null
          created_at?: string
          id?: string
          integration_context?: string | null
          is_manual?: boolean | null
          meeting_context?: string
          mention_count?: number
          mention_type?: string
          opportunity_id?: string | null
          product_name?: string
          sentiment_label?: string | null
          sentiment_score?: number | null
          speaker_type?: string | null
          technology_id?: string | null
          transcript_date?: string | null
          transcript_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_mentions_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_mentions_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_mentions_technology_id_fkey"
            columns: ["technology_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_mentions_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          auth_provider: string | null
          created_at: string
          email: string
          email_verification_expires_at: string | null
          email_verification_token: string | null
          email_verified: boolean | null
          failed_login_attempts: number | null
          full_name: string | null
          google_email: string | null
          google_linked: boolean | null
          id: string
          invited_at: string | null
          invited_by: string | null
          last_failed_login_at: string | null
          last_login_at: string | null
          locked_until: string | null
          mfa_enabled: boolean | null
          password_hash: string | null
          password_reset_expires_at: string | null
          password_reset_token: string | null
          status: string | null
          temp_password: boolean | null
          timezone: string | null
          totp_secret: string | null
          totp_secret_pending: string | null
          totp_verified_at: string | null
          updated_at: string
        }
        Insert: {
          auth_provider?: string | null
          created_at?: string
          email: string
          email_verification_expires_at?: string | null
          email_verification_token?: string | null
          email_verified?: boolean | null
          failed_login_attempts?: number | null
          full_name?: string | null
          google_email?: string | null
          google_linked?: boolean | null
          id: string
          invited_at?: string | null
          invited_by?: string | null
          last_failed_login_at?: string | null
          last_login_at?: string | null
          locked_until?: string | null
          mfa_enabled?: boolean | null
          password_hash?: string | null
          password_reset_expires_at?: string | null
          password_reset_token?: string | null
          status?: string | null
          temp_password?: boolean | null
          timezone?: string | null
          totp_secret?: string | null
          totp_secret_pending?: string | null
          totp_verified_at?: string | null
          updated_at?: string
        }
        Update: {
          auth_provider?: string | null
          created_at?: string
          email?: string
          email_verification_expires_at?: string | null
          email_verification_token?: string | null
          email_verified?: boolean | null
          failed_login_attempts?: number | null
          full_name?: string | null
          google_email?: string | null
          google_linked?: boolean | null
          id?: string
          invited_at?: string | null
          invited_by?: string | null
          last_failed_login_at?: string | null
          last_login_at?: string | null
          locked_until?: string | null
          mfa_enabled?: boolean | null
          password_hash?: string | null
          password_reset_expires_at?: string | null
          password_reset_token?: string | null
          status?: string | null
          temp_password?: boolean | null
          timezone?: string | null
          totp_secret?: string | null
          totp_secret_pending?: string | null
          totp_verified_at?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      readiness_sub_questions: {
        Row: {
          created_at: string
          discovery_prompt: string | null
          field_type: string
          help_text: string | null
          id: string
          is_required: boolean | null
          options: Json | null
          parent_question_id: string
          placeholder: string | null
          question: string
          sort_order: number | null
          trigger_condition: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          discovery_prompt?: string | null
          field_type?: string
          help_text?: string | null
          id?: string
          is_required?: boolean | null
          options?: Json | null
          parent_question_id: string
          placeholder?: string | null
          question: string
          sort_order?: number | null
          trigger_condition?: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          discovery_prompt?: string | null
          field_type?: string
          help_text?: string | null
          id?: string
          is_required?: boolean | null
          options?: Json | null
          parent_question_id?: string
          placeholder?: string | null
          question?: string
          sort_order?: number | null
          trigger_condition?: Json
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "readiness_sub_questions_parent_question_id_fkey"
            columns: ["parent_question_id"]
            isOneToOne: false
            referencedRelation: "readiness_template_questions"
            referencedColumns: ["id"]
          },
        ]
      }
      readiness_template_categories: {
        Row: {
          created_at: string
          deployment_type_id: string | null
          description: string | null
          id: string
          is_app_scoped: boolean
          name: string
          sort_order: number | null
        }
        Insert: {
          created_at?: string
          deployment_type_id?: string | null
          description?: string | null
          id?: string
          is_app_scoped?: boolean
          name: string
          sort_order?: number | null
        }
        Update: {
          created_at?: string
          deployment_type_id?: string | null
          description?: string | null
          id?: string
          is_app_scoped?: boolean
          name?: string
          sort_order?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "readiness_template_categories_deployment_type_id_fkey"
            columns: ["deployment_type_id"]
            isOneToOne: false
            referencedRelation: "deployment_types"
            referencedColumns: ["id"]
          },
        ]
      }
      readiness_template_questions: {
        Row: {
          category_id: string
          created_at: string
          discovery_prompts: string[] | null
          field_type: string
          help_text: string | null
          id: string
          is_required: boolean | null
          options: Json | null
          parent_question_id: string | null
          placeholder: string | null
          question: string
          red_flag_condition: Json | null
          sort_order: number | null
          trigger_condition: Json | null
          updated_at: string
        }
        Insert: {
          category_id: string
          created_at?: string
          discovery_prompts?: string[] | null
          field_type?: string
          help_text?: string | null
          id?: string
          is_required?: boolean | null
          options?: Json | null
          parent_question_id?: string | null
          placeholder?: string | null
          question: string
          red_flag_condition?: Json | null
          sort_order?: number | null
          trigger_condition?: Json | null
          updated_at?: string
        }
        Update: {
          category_id?: string
          created_at?: string
          discovery_prompts?: string[] | null
          field_type?: string
          help_text?: string | null
          id?: string
          is_required?: boolean | null
          options?: Json | null
          parent_question_id?: string | null
          placeholder?: string | null
          question?: string
          red_flag_condition?: Json | null
          sort_order?: number | null
          trigger_condition?: Json | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "readiness_template_questions_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "readiness_template_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "readiness_template_questions_parent_question_id_fkey"
            columns: ["parent_question_id"]
            isOneToOne: false
            referencedRelation: "readiness_template_questions"
            referencedColumns: ["id"]
          },
        ]
      }
      reference_technologies: {
        Row: {
          category: string
          created_at: string
          description: string | null
          id: string
          integration_type: string | null
          layer: string
          name: string
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          description?: string | null
          id?: string
          integration_type?: string | null
          layer: string
          name: string
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          integration_type?: string | null
          layer?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      rejected_competitor_mentions: {
        Row: {
          account_id: string
          competitor_name: string
          created_at: string
          id: string
          opportunity_id: string | null
          rejected_at: string
          rejected_by: string | null
          transcript_id: string | null
        }
        Insert: {
          account_id: string
          competitor_name: string
          created_at?: string
          id?: string
          opportunity_id?: string | null
          rejected_at?: string
          rejected_by?: string | null
          transcript_id?: string | null
        }
        Update: {
          account_id?: string
          competitor_name?: string
          created_at?: string
          id?: string
          opportunity_id?: string | null
          rejected_at?: string
          rejected_by?: string | null
          transcript_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "rejected_competitor_mentions_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rejected_competitor_mentions_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rejected_competitor_mentions_rejected_by_fkey"
            columns: ["rejected_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rejected_competitor_mentions_rejected_by_fkey"
            columns: ["rejected_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rejected_competitor_mentions_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      rejected_technology_detections: {
        Row: {
          account_id: string
          detected_name: string | null
          id: string
          rejected_at: string
          rejected_by: string | null
          repository_tech_id: string | null
          transcript_id: string
        }
        Insert: {
          account_id: string
          detected_name?: string | null
          id?: string
          rejected_at?: string
          rejected_by?: string | null
          repository_tech_id?: string | null
          transcript_id: string
        }
        Update: {
          account_id?: string
          detected_name?: string | null
          id?: string
          rejected_at?: string
          rejected_by?: string | null
          repository_tech_id?: string | null
          transcript_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "rejected_technology_detections_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rejected_technology_detections_rejected_by_fkey"
            columns: ["rejected_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rejected_technology_detections_rejected_by_fkey"
            columns: ["rejected_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rejected_technology_detections_repository_tech_id_fkey"
            columns: ["repository_tech_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rejected_technology_detections_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      salesforce_connections: {
        Row: {
          created_at: string
          encrypted_password: string
          encryption_iv: string | null
          id: string
          instance_url: string | null
          is_encrypted: boolean | null
          is_sandbox: boolean | null
          security_token: string | null
          security_token_encrypted: string | null
          session_expires_at: string | null
          session_id: string | null
          session_id_encrypted: string | null
          updated_at: string
          user_id: string
          username: string
          username_encrypted: string | null
        }
        Insert: {
          created_at?: string
          encrypted_password: string
          encryption_iv?: string | null
          id?: string
          instance_url?: string | null
          is_encrypted?: boolean | null
          is_sandbox?: boolean | null
          security_token?: string | null
          security_token_encrypted?: string | null
          session_expires_at?: string | null
          session_id?: string | null
          session_id_encrypted?: string | null
          updated_at?: string
          user_id: string
          username: string
          username_encrypted?: string | null
        }
        Update: {
          created_at?: string
          encrypted_password?: string
          encryption_iv?: string | null
          id?: string
          instance_url?: string | null
          is_encrypted?: boolean | null
          is_sandbox?: boolean | null
          security_token?: string | null
          security_token_encrypted?: string | null
          session_expires_at?: string | null
          session_id?: string | null
          session_id_encrypted?: string | null
          updated_at?: string
          user_id?: string
          username?: string
          username_encrypted?: string | null
        }
        Relationships: []
      }
      se_coaching_scores: {
        Row: {
          account_id: string | null
          actionable_next_step: string | null
          analysis_model: string | null
          analyzed_at: string
          avg_words_per_minute: number | null
          champion_arming_evidence: string | null
          champion_arming_score: number | null
          coaching_guidance: Json | null
          created_at: string
          differentiation_evidence: string | null
          differentiation_score: number | null
          energy_delivery_breakdown: Json | null
          energy_inspiration_evidence: string | null
          energy_inspiration_score: number | null
          greatness_moment: string | null
          id: string
          improvement_example: string | null
          meeting_date: string | null
          meeting_type: string
          objection_handling_evidence: string | null
          objection_handling_score: number | null
          opportunity_gap: string | null
          opportunity_id: string | null
          overall_score: number | null
          ownership_control_evidence: string | null
          ownership_control_score: number | null
          pain_quantification_evidence: string | null
          pain_quantification_score: number | null
          pause_for_impact_count: number | null
          pov_challenge_evidence: string | null
          pov_challenge_score: number | null
          prospect_sentiment: string | null
          questioning_evidence: string | null
          questioning_score: number | null
          reverse_demo_evidence: string | null
          reverse_demo_score: number | null
          rushed_speech_detected: boolean | null
          se_email: string
          se_talk_ratio: number | null
          storytelling_proof_evidence: string | null
          storytelling_proof_score: number | null
          strategy_rigor_evidence: string | null
          strategy_rigor_score: number | null
          talk_ratio_score: number | null
          target_talk_ratio_max: number | null
          target_talk_ratio_min: number | null
          technical_competency_evidence: string | null
          technical_competency_score: number | null
          transcript_id: string
          updated_at: string
          value_anchoring_evidence: string | null
          value_anchoring_score: number | null
          weights_used: Json
          what_didnt_work: Json | null
          what_worked_well: Json | null
        }
        Insert: {
          account_id?: string | null
          actionable_next_step?: string | null
          analysis_model?: string | null
          analyzed_at?: string
          avg_words_per_minute?: number | null
          champion_arming_evidence?: string | null
          champion_arming_score?: number | null
          coaching_guidance?: Json | null
          created_at?: string
          differentiation_evidence?: string | null
          differentiation_score?: number | null
          energy_delivery_breakdown?: Json | null
          energy_inspiration_evidence?: string | null
          energy_inspiration_score?: number | null
          greatness_moment?: string | null
          id?: string
          improvement_example?: string | null
          meeting_date?: string | null
          meeting_type: string
          objection_handling_evidence?: string | null
          objection_handling_score?: number | null
          opportunity_gap?: string | null
          opportunity_id?: string | null
          overall_score?: number | null
          ownership_control_evidence?: string | null
          ownership_control_score?: number | null
          pain_quantification_evidence?: string | null
          pain_quantification_score?: number | null
          pause_for_impact_count?: number | null
          pov_challenge_evidence?: string | null
          pov_challenge_score?: number | null
          prospect_sentiment?: string | null
          questioning_evidence?: string | null
          questioning_score?: number | null
          reverse_demo_evidence?: string | null
          reverse_demo_score?: number | null
          rushed_speech_detected?: boolean | null
          se_email: string
          se_talk_ratio?: number | null
          storytelling_proof_evidence?: string | null
          storytelling_proof_score?: number | null
          strategy_rigor_evidence?: string | null
          strategy_rigor_score?: number | null
          talk_ratio_score?: number | null
          target_talk_ratio_max?: number | null
          target_talk_ratio_min?: number | null
          technical_competency_evidence?: string | null
          technical_competency_score?: number | null
          transcript_id: string
          updated_at?: string
          value_anchoring_evidence?: string | null
          value_anchoring_score?: number | null
          weights_used?: Json
          what_didnt_work?: Json | null
          what_worked_well?: Json | null
        }
        Update: {
          account_id?: string | null
          actionable_next_step?: string | null
          analysis_model?: string | null
          analyzed_at?: string
          avg_words_per_minute?: number | null
          champion_arming_evidence?: string | null
          champion_arming_score?: number | null
          coaching_guidance?: Json | null
          created_at?: string
          differentiation_evidence?: string | null
          differentiation_score?: number | null
          energy_delivery_breakdown?: Json | null
          energy_inspiration_evidence?: string | null
          energy_inspiration_score?: number | null
          greatness_moment?: string | null
          id?: string
          improvement_example?: string | null
          meeting_date?: string | null
          meeting_type?: string
          objection_handling_evidence?: string | null
          objection_handling_score?: number | null
          opportunity_gap?: string | null
          opportunity_id?: string | null
          overall_score?: number | null
          ownership_control_evidence?: string | null
          ownership_control_score?: number | null
          pain_quantification_evidence?: string | null
          pain_quantification_score?: number | null
          pause_for_impact_count?: number | null
          pov_challenge_evidence?: string | null
          pov_challenge_score?: number | null
          prospect_sentiment?: string | null
          questioning_evidence?: string | null
          questioning_score?: number | null
          reverse_demo_evidence?: string | null
          reverse_demo_score?: number | null
          rushed_speech_detected?: boolean | null
          se_email?: string
          se_talk_ratio?: number | null
          storytelling_proof_evidence?: string | null
          storytelling_proof_score?: number | null
          strategy_rigor_evidence?: string | null
          strategy_rigor_score?: number | null
          talk_ratio_score?: number | null
          target_talk_ratio_max?: number | null
          target_talk_ratio_min?: number | null
          technical_competency_evidence?: string | null
          technical_competency_score?: number | null
          transcript_id?: string
          updated_at?: string
          value_anchoring_evidence?: string | null
          value_anchoring_score?: number | null
          weights_used?: Json
          what_didnt_work?: Json | null
          what_worked_well?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "se_coaching_scores_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "se_coaching_scores_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "se_coaching_scores_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      signal_occurrences: {
        Row: {
          confidence_score: number | null
          crm_stage: number | null
          detected_at: string
          id: string
          match_id: string
          matched_phrases: string[] | null
          pre_sales_stage: number | null
          speaker_name: string | null
          speaker_type: string | null
          transcript_id: string
        }
        Insert: {
          confidence_score?: number | null
          crm_stage?: number | null
          detected_at?: string
          id?: string
          match_id: string
          matched_phrases?: string[] | null
          pre_sales_stage?: number | null
          speaker_name?: string | null
          speaker_type?: string | null
          transcript_id: string
        }
        Update: {
          confidence_score?: number | null
          crm_stage?: number | null
          detected_at?: string
          id?: string
          match_id?: string
          matched_phrases?: string[] | null
          pre_sales_stage?: number | null
          speaker_name?: string | null
          speaker_type?: string | null
          transcript_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "signal_occurrences_match_id_fkey"
            columns: ["match_id"]
            isOneToOne: false
            referencedRelation: "detection_rule_matches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "signal_occurrences_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      stakeholder_history: {
        Row: {
          account_id: string
          change_source: string
          changed_at: string
          changed_by: string | null
          confidence_score: number | null
          contact_id: string
          id: string
          metric_type: string
          new_value: Json
          old_value: Json | null
          opportunity_id: string | null
          source_transcript_id: string | null
        }
        Insert: {
          account_id: string
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          confidence_score?: number | null
          contact_id: string
          id?: string
          metric_type: string
          new_value: Json
          old_value?: Json | null
          opportunity_id?: string | null
          source_transcript_id?: string | null
        }
        Update: {
          account_id?: string
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          confidence_score?: number | null
          contact_id?: string
          id?: string
          metric_type?: string
          new_value?: Json
          old_value?: Json | null
          opportunity_id?: string | null
          source_transcript_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "stakeholder_history_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stakeholder_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stakeholder_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stakeholder_history_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "account_contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stakeholder_history_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stakeholder_history_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      success_criteria_deliverables: {
        Row: {
          completed_at: string | null
          created_at: string
          criterion_id: string
          id: string
          is_completed: boolean
          sort_order: number
          title: string
          updated_at: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          criterion_id: string
          id?: string
          is_completed?: boolean
          sort_order?: number
          title: string
          updated_at?: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          criterion_id?: string
          id?: string
          is_completed?: boolean
          sort_order?: number
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "success_criteria_deliverables_criterion_id_fkey"
            columns: ["criterion_id"]
            isOneToOne: false
            referencedRelation: "evaluation_success_criteria"
            referencedColumns: ["id"]
          },
        ]
      }
      suppressed_extracted_technologies: {
        Row: {
          account_id: string
          id: string
          reason: string | null
          suppressed_at: string
          suppressed_by: string | null
          technology_name: string
        }
        Insert: {
          account_id: string
          id?: string
          reason?: string | null
          suppressed_at?: string
          suppressed_by?: string | null
          technology_name: string
        }
        Update: {
          account_id?: string
          id?: string
          reason?: string | null
          suppressed_at?: string
          suppressed_by?: string | null
          technology_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "suppressed_extracted_technologies_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "suppressed_extracted_technologies_suppressed_by_fkey"
            columns: ["suppressed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "suppressed_extracted_technologies_suppressed_by_fkey"
            columns: ["suppressed_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      suppressed_product_mentions: {
        Row: {
          created_at: string
          id: string
          mention_type: string | null
          product_name: string
          reason: string | null
          suppressed_by: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          mention_type?: string | null
          product_name: string
          reason?: string | null
          suppressed_by?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          mention_type?: string | null
          product_name?: string
          reason?: string | null
          suppressed_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "suppressed_product_mentions_suppressed_by_fkey"
            columns: ["suppressed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "suppressed_product_mentions_suppressed_by_fkey"
            columns: ["suppressed_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      system_logs: {
        Row: {
          created_at: string
          id: string
          log_data: Json | null
          log_type: string
        }
        Insert: {
          created_at?: string
          id?: string
          log_data?: Json | null
          log_type: string
        }
        Update: {
          created_at?: string
          id?: string
          log_data?: Json | null
          log_type?: string
        }
        Relationships: []
      }
      system_notifications: {
        Row: {
          created_at: string
          data: Json | null
          expires_at: string | null
          id: string
          is_read: boolean | null
          message: string | null
          title: string
          type: string
        }
        Insert: {
          created_at?: string
          data?: Json | null
          expires_at?: string | null
          id?: string
          is_read?: boolean | null
          message?: string | null
          title: string
          type: string
        }
        Update: {
          created_at?: string
          data?: Json | null
          expires_at?: string | null
          id?: string
          is_read?: boolean | null
          message?: string | null
          title?: string
          type?: string
        }
        Relationships: []
      }
      team_hierarchy: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          manager_id: string
          relationship_type: string
          report_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          manager_id: string
          relationship_type?: string
          report_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          manager_id?: string
          relationship_type?: string
          report_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_hierarchy_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_hierarchy_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_hierarchy_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_hierarchy_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_hierarchy_report_id_fkey"
            columns: ["report_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_hierarchy_report_id_fkey"
            columns: ["report_id"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      team_members: {
        Row: {
          created_at: string
          id: string
          is_active: boolean | null
          manager_id: string
          member_email: string
          member_name: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean | null
          manager_id: string
          member_email: string
          member_name?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean | null
          manager_id?: string
          member_email?: string
          member_name?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      technical_readiness_history: {
        Row: {
          change_source: string
          changed_at: string
          changed_by: string | null
          id: string
          new_answer: Json
          new_score: number | null
          old_answer: Json | null
          old_score: number | null
          opportunity_id: string
          question_id: string
          source_transcript_id: string | null
        }
        Insert: {
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          id?: string
          new_answer: Json
          new_score?: number | null
          old_answer?: Json | null
          old_score?: number | null
          opportunity_id: string
          question_id: string
          source_transcript_id?: string | null
        }
        Update: {
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          id?: string
          new_answer?: Json
          new_score?: number | null
          old_answer?: Json | null
          old_score?: number | null
          opportunity_id?: string
          question_id?: string
          source_transcript_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "technical_readiness_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "technical_readiness_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "technical_readiness_history_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "technical_readiness_history_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "readiness_template_questions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "technical_readiness_history_source_transcript_id_fkey"
            columns: ["source_transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      technology_functional_areas: {
        Row: {
          created_at: string
          functional_area_id: string
          id: string
          is_primary: boolean
          technology_id: string
        }
        Insert: {
          created_at?: string
          functional_area_id: string
          id?: string
          is_primary?: boolean
          technology_id: string
        }
        Update: {
          created_at?: string
          functional_area_id?: string
          id?: string
          is_primary?: boolean
          technology_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "technology_functional_areas_functional_area_id_fkey"
            columns: ["functional_area_id"]
            isOneToOne: false
            referencedRelation: "functional_areas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "technology_functional_areas_technology_id_fkey"
            columns: ["technology_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
        ]
      }
      technology_relationships: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          related_technology_id: string
          relationship_type: string
          technology_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          related_technology_id: string
          relationship_type?: string
          technology_id: string
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          related_technology_id?: string
          relationship_type?: string
          technology_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "technology_relationships_related_technology_id_fkey"
            columns: ["related_technology_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "technology_relationships_technology_id_fkey"
            columns: ["technology_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
        ]
      }
      technology_repository: {
        Row: {
          aliases: string[] | null
          capabilities: string[] | null
          competing_module_ids: string[] | null
          competitor_id: string | null
          competitor_overlap: string | null
          create_detection_rule: boolean
          created_at: string
          customer_notes: string | null
          description: string | null
          detection_rule_id: string | null
          functional_area: string
          id: string
          is_competitor: boolean | null
          is_customer: boolean | null
          is_pendo_product: boolean | null
          layer: string
          logo_url: string | null
          name: string
          normalized_name: string | null
          parent_category_id: string | null
          parent_company: string | null
          parent_id: string | null
          status: string
          synonyms: string[] | null
          technology_type: string
          updated_at: string
          website_url: string | null
        }
        Insert: {
          aliases?: string[] | null
          capabilities?: string[] | null
          competing_module_ids?: string[] | null
          competitor_id?: string | null
          competitor_overlap?: string | null
          create_detection_rule?: boolean
          created_at?: string
          customer_notes?: string | null
          description?: string | null
          detection_rule_id?: string | null
          functional_area: string
          id?: string
          is_competitor?: boolean | null
          is_customer?: boolean | null
          is_pendo_product?: boolean | null
          layer?: string
          logo_url?: string | null
          name: string
          normalized_name?: string | null
          parent_category_id?: string | null
          parent_company?: string | null
          parent_id?: string | null
          status?: string
          synonyms?: string[] | null
          technology_type?: string
          updated_at?: string
          website_url?: string | null
        }
        Update: {
          aliases?: string[] | null
          capabilities?: string[] | null
          competing_module_ids?: string[] | null
          competitor_id?: string | null
          competitor_overlap?: string | null
          create_detection_rule?: boolean
          created_at?: string
          customer_notes?: string | null
          description?: string | null
          detection_rule_id?: string | null
          functional_area?: string
          id?: string
          is_competitor?: boolean | null
          is_customer?: boolean | null
          is_pendo_product?: boolean | null
          layer?: string
          logo_url?: string | null
          name?: string
          normalized_name?: string | null
          parent_category_id?: string | null
          parent_company?: string | null
          parent_id?: string | null
          status?: string
          synonyms?: string[] | null
          technology_type?: string
          updated_at?: string
          website_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "technology_repository_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "technology_repository_detection_rule_id_fkey"
            columns: ["detection_rule_id"]
            isOneToOne: false
            referencedRelation: "detection_rules"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "technology_repository_parent_category_id_fkey"
            columns: ["parent_category_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "technology_repository_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "technology_repository"
            referencedColumns: ["id"]
          },
        ]
      }
      transcript_full_reanalysis_queue: {
        Row: {
          account_id: string
          batch_number: number | null
          completed_at: string | null
          created_at: string
          error_message: string | null
          id: string
          opportunity_id: string | null
          started_at: string | null
          status: string
          transcript_id: string
        }
        Insert: {
          account_id: string
          batch_number?: number | null
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          opportunity_id?: string | null
          started_at?: string | null
          status?: string
          transcript_id: string
        }
        Update: {
          account_id?: string
          batch_number?: number | null
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          opportunity_id?: string | null
          started_at?: string | null
          status?: string
          transcript_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "transcript_full_reanalysis_queue_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transcript_full_reanalysis_queue_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transcript_full_reanalysis_queue_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: true
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      transcript_reanalysis_queue: {
        Row: {
          account_id: string | null
          analysis_types: string[]
          attempts: number
          completed_at: string | null
          created_at: string
          error_message: string | null
          id: string
          opportunity_id: string | null
          started_at: string | null
          status: string
          transcript_id: string
        }
        Insert: {
          account_id?: string | null
          analysis_types?: string[]
          attempts?: number
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          opportunity_id?: string | null
          started_at?: string | null
          status?: string
          transcript_id: string
        }
        Update: {
          account_id?: string | null
          analysis_types?: string[]
          attempts?: number
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          opportunity_id?: string | null
          started_at?: string | null
          status?: string
          transcript_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "transcript_reanalysis_queue_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transcript_reanalysis_queue_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transcript_reanalysis_queue_transcript_id_fkey"
            columns: ["transcript_id"]
            isOneToOne: false
            referencedRelation: "transcript_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      transcript_reviews: {
        Row: {
          call_summary: Json | null
          content_hash: string | null
          created_at: string
          created_by: string | null
          encryption_iv: string | null
          enrichment_completed_at: string | null
          enrichment_error: string | null
          enrichment_retry_count: number | null
          enrichment_started_at: string | null
          enrichment_status: string | null
          extracted_insights: Json | null
          extracted_insights_encrypted: string | null
          extracted_technologies: Json | null
          file_name: string | null
          final_account_id: string | null
          id: string
          is_encrypted: boolean | null
          last_analyzed_at: string | null
          last_enriched_hash: string | null
          meeting_context: string
          meeting_title: string | null
          meeting_type: string | null
          meeting_type_confidence: number | null
          momentum_meeting_id: string | null
          opportunity_id: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          suggested_account_confidence: number | null
          suggested_account_id: string | null
          transcript_content: string | null
          transcript_content_encrypted: string | null
          updated_at: string
        }
        Insert: {
          call_summary?: Json | null
          content_hash?: string | null
          created_at?: string
          created_by?: string | null
          encryption_iv?: string | null
          enrichment_completed_at?: string | null
          enrichment_error?: string | null
          enrichment_retry_count?: number | null
          enrichment_started_at?: string | null
          enrichment_status?: string | null
          extracted_insights?: Json | null
          extracted_insights_encrypted?: string | null
          extracted_technologies?: Json | null
          file_name?: string | null
          final_account_id?: string | null
          id?: string
          is_encrypted?: boolean | null
          last_analyzed_at?: string | null
          last_enriched_hash?: string | null
          meeting_context?: string
          meeting_title?: string | null
          meeting_type?: string | null
          meeting_type_confidence?: number | null
          momentum_meeting_id?: string | null
          opportunity_id?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          suggested_account_confidence?: number | null
          suggested_account_id?: string | null
          transcript_content?: string | null
          transcript_content_encrypted?: string | null
          updated_at?: string
        }
        Update: {
          call_summary?: Json | null
          content_hash?: string | null
          created_at?: string
          created_by?: string | null
          encryption_iv?: string | null
          enrichment_completed_at?: string | null
          enrichment_error?: string | null
          enrichment_retry_count?: number | null
          enrichment_started_at?: string | null
          enrichment_status?: string | null
          extracted_insights?: Json | null
          extracted_insights_encrypted?: string | null
          extracted_technologies?: Json | null
          file_name?: string | null
          final_account_id?: string | null
          id?: string
          is_encrypted?: boolean | null
          last_analyzed_at?: string | null
          last_enriched_hash?: string | null
          meeting_context?: string
          meeting_title?: string | null
          meeting_type?: string | null
          meeting_type_confidence?: number | null
          momentum_meeting_id?: string | null
          opportunity_id?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          suggested_account_confidence?: number | null
          suggested_account_id?: string | null
          transcript_content?: string | null
          transcript_content_encrypted?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "transcript_reviews_final_account_id_fkey"
            columns: ["final_account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transcript_reviews_momentum_meeting_id_fkey"
            columns: ["momentum_meeting_id"]
            isOneToOne: false
            referencedRelation: "momentum_meetings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transcript_reviews_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transcript_reviews_suggested_account_id_fkey"
            columns: ["suggested_account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      use_case_template_products: {
        Row: {
          created_at: string
          id: string
          module_pricing_id: string
          use_case_template_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          module_pricing_id: string
          use_case_template_id: string
        }
        Update: {
          created_at?: string
          id?: string
          module_pricing_id?: string
          use_case_template_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "use_case_template_products_module_pricing_id_fkey"
            columns: ["module_pricing_id"]
            isOneToOne: false
            referencedRelation: "module_pricing"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "use_case_template_products_use_case_template_id_fkey"
            columns: ["use_case_template_id"]
            isOneToOne: false
            referencedRelation: "use_case_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      use_case_templates: {
        Row: {
          business_outcome: string | null
          created_at: string
          description: string | null
          example_outcomes: string | null
          functional_area_id: string
          id: string
          is_active: boolean | null
          name: string
          solution_description: string | null
          sort_order: number | null
          updated_at: string
        }
        Insert: {
          business_outcome?: string | null
          created_at?: string
          description?: string | null
          example_outcomes?: string | null
          functional_area_id: string
          id?: string
          is_active?: boolean | null
          name: string
          solution_description?: string | null
          sort_order?: number | null
          updated_at?: string
        }
        Update: {
          business_outcome?: string | null
          created_at?: string
          description?: string | null
          example_outcomes?: string | null
          functional_area_id?: string
          id?: string
          is_active?: boolean | null
          name?: string
          solution_description?: string | null
          sort_order?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "use_case_templates_functional_area_id_fkey"
            columns: ["functional_area_id"]
            isOneToOne: false
            referencedRelation: "functional_areas"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          granted_by: string | null
          id: string
          role: string
          user_id: string
        }
        Insert: {
          created_at?: string
          granted_by?: string | null
          id?: string
          role?: string
          user_id: string
        }
        Update: {
          created_at?: string
          granted_by?: string | null
          id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_granted_by_fkey"
            columns: ["granted_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_roles_granted_by_fkey"
            columns: ["granted_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      user_sessions: {
        Row: {
          created_at: string
          expires_at: string
          fingerprint_hash: string | null
          id: string
          ip_address: string | null
          last_activity_at: string
          token: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at: string
          fingerprint_hash?: string | null
          id?: string
          ip_address?: string | null
          last_activity_at?: string
          token: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          fingerprint_hash?: string | null
          id?: string
          ip_address?: string | null
          last_activity_at?: string
          token?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_sessions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_sessions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      validation_task_history: {
        Row: {
          change_source: string
          changed_at: string
          changed_by: string | null
          id: string
          new_completed_at: string | null
          new_status: string
          notes: string | null
          old_completed_at: string | null
          old_status: string | null
          opportunity_id: string
          task_id: string
        }
        Insert: {
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          id?: string
          new_completed_at?: string | null
          new_status: string
          notes?: string | null
          old_completed_at?: string | null
          old_status?: string | null
          opportunity_id: string
          task_id: string
        }
        Update: {
          change_source?: string
          changed_at?: string
          changed_by?: string | null
          id?: string
          new_completed_at?: string | null
          new_status?: string
          notes?: string | null
          old_completed_at?: string | null
          old_status?: string | null
          opportunity_id?: string
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "validation_task_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "validation_task_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "validation_task_history_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "validation_task_history_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "opportunity_validation_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      validation_task_templates: {
        Row: {
          activity: string
          created_at: string
          default_owner: string | null
          deployment_type_id: string | null
          id: string
          module: string
          resources_url: string | null
          sort_order: number | null
          sub_module: string | null
        }
        Insert: {
          activity: string
          created_at?: string
          default_owner?: string | null
          deployment_type_id?: string | null
          id?: string
          module: string
          resources_url?: string | null
          sort_order?: number | null
          sub_module?: string | null
        }
        Update: {
          activity?: string
          created_at?: string
          default_owner?: string | null
          deployment_type_id?: string | null
          id?: string
          module?: string
          resources_url?: string | null
          sort_order?: number | null
          sub_module?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "validation_task_templates_deployment_type_id_fkey"
            columns: ["deployment_type_id"]
            isOneToOne: false
            referencedRelation: "deployment_types"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      profiles_public: {
        Row: {
          created_at: string | null
          email: string | null
          email_verified: boolean | null
          full_name: string | null
          id: string | null
          last_login_at: string | null
          mfa_enabled: boolean | null
          status: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          email?: string | null
          email_verified?: boolean | null
          full_name?: string | null
          id?: string | null
          last_login_at?: string | null
          mfa_enabled?: boolean | null
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          email?: string | null
          email_verified?: boolean | null
          full_name?: string | null
          id?: string | null
          last_login_at?: string | null
          mfa_enabled?: boolean | null
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      can_access_page: {
        Args: { _page_path: string; _user_id: string }
        Returns: boolean
      }
      cleanup_expired_sessions: { Args: never; Returns: undefined }
      get_daily_call_counts: {
        Args: { p_from: string; p_meeting_context?: string; p_to: string }
        Returns: {
          call_count: number
          call_date: string
        }[]
      }
      get_next_reanalysis_batch: {
        Args: never
        Returns: {
          account_id: string
          batch_number: number
          id: string
          opportunity_id: string
          transcript_id: string
        }[]
      }
      get_product_mention_stats: {
        Args: { p_from: string; p_meeting_context?: string; p_to: string }
        Returns: {
          avg_sentiment: number
          mention_type: string
          mixed_count: number
          negative_count: number
          neutral_count: number
          positive_count: number
          product_name: string
          total_mentions: number
        }[]
      }
      get_product_mention_trends: {
        Args: { p_from: string; p_meeting_context?: string; p_to: string }
        Returns: {
          mention_date: string
          mention_type: string
          total_count: number
        }[]
      }
      get_team_branch: {
        Args: { _user_id: string }
        Returns: {
          depth: number
          user_id: string
        }[]
      }
      get_team_members: {
        Args: { _manager_id: string }
        Returns: {
          depth: number
          user_id: string
        }[]
      }
      get_user_email: { Args: { _user_id: string }; Returns: string }
      has_role:
        | {
            Args: {
              _role: Database["public"]["Enums"]["app_role"]
              _user_id: string
            }
            Returns: boolean
          }
        | { Args: { _role: string; _user_id: string }; Returns: boolean }
      increment_failed_login: {
        Args: { _user_id: string }
        Returns: {
          attempts: number
          lockout_until: string
        }[]
      }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      is_in_team: {
        Args: { _manager_id: string; _user_id: string }
        Returns: boolean
      }
      is_manager: { Args: { _user_id: string }; Returns: boolean }
      populate_reanalysis_queue: { Args: never; Returns: number }
      prepare_full_reanalysis: {
        Args: { p_account_ids?: string[] }
        Returns: {
          insights_deleted: Json
          transcripts_queued: number
        }[]
      }
      reset_failed_login_attempts: {
        Args: { _user_id: string }
        Returns: undefined
      }
      validate_session: {
        Args: { _token: string }
        Returns: {
          auth_provider: string
          email: string
          full_name: string
          mfa_enabled: boolean
          status: string
          user_id: string
        }[]
      }
    }
    Enums: {
      analysis_pass_status: "active" | "inactive" | "deprecated"
      app_role:
        | "admin"
        | "user"
        | "se"
        | "ae"
        | "manager"
        | "moderator"
        | "product"
      business_impact_type:
        | "revenue_enablement"
        | "cost_reduction"
        | "risk_mitigation"
        | "efficiency_gains"
      pain_category_type:
        | "vendor_relationship"
        | "technical_limitations"
        | "operational_friction"
        | "resource_constraints"
        | "strategic_misalignment"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      analysis_pass_status: ["active", "inactive", "deprecated"],
      app_role: [
        "admin",
        "user",
        "se",
        "ae",
        "manager",
        "moderator",
        "product",
      ],
      business_impact_type: [
        "revenue_enablement",
        "cost_reduction",
        "risk_mitigation",
        "efficiency_gains",
      ],
      pain_category_type: [
        "vendor_relationship",
        "technical_limitations",
        "operational_friction",
        "resource_constraints",
        "strategic_misalignment",
      ],
    },
  },
} as const

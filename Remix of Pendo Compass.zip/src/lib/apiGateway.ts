import { supabase } from "@/integrations/supabase/client";

// Helper to extract error message from gateway error
export function getErrorMessage(error: string | { message: string; code?: string } | null): string {
  if (!error) return 'Unknown error';
  if (typeof error === 'string') return error;
  return error.message || 'Unknown error';
}

// Types for gateway operations
export type GatewayAction = 'select' | 'insert' | 'update' | 'upsert' | 'delete';

export interface QueryFilter {
  column: string;
  operator: 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'like' | 'ilike' | 'is' | 'in' | 'contains' | 'containedBy' | 'not.is' | 'or';
  value: any;
}

export interface QueryParams {
  select?: string;
  filters?: QueryFilter[];
  order?: { column: string; ascending?: boolean };
  limit?: number;
  offset?: number;
  single?: boolean;
  maybeSingle?: boolean;
  onConflict?: string;
  countOnly?: boolean;
}

export interface GatewayRequest {
  action: GatewayAction;
  table: string;
  data?: Record<string, any> | Record<string, any>[];
  params?: QueryParams;
  returning?: boolean;
}

export interface GatewayResponse<T = any> {
  data: T | null;
  error: { message: string; code?: string } | null;
  success: boolean;
}

// Session token key must match AuthContext
const SESSION_TOKEN_KEY = 'auth_session_token';

// Get session token from localStorage
function getSessionToken(): string | null {
  return localStorage.getItem(SESSION_TOKEN_KEY);
}

function tryParseEdgeFunctionPayload(message: string): { message?: string; code?: string } | null {
  // Supabase FunctionsHttpError often looks like:
  // "Edge function returned 503: Error, {\"error\":...,\"message\":...,\"code\":...}"
  const start = message.indexOf('{');
  const end = message.lastIndexOf('}');
  if (start === -1 || end === -1 || end <= start) return null;
  const candidate = message.slice(start, end + 1);
  try {
    const parsed = JSON.parse(candidate);
    if (parsed && typeof parsed === 'object') {
      return {
        message: parsed.message ?? parsed.error ?? undefined,
        code: parsed.code ?? undefined,
      };
    }
  } catch {
    // ignore
  }
  return null;
}

// Concurrency limiter to prevent 503 boot failures from too many parallel edge function calls
const MAX_CONCURRENT = 4;
let activeRequests = 0;
const requestQueue: Array<{ resolve: () => void }> = [];

// Deduplicate concurrent identical SELECTs to avoid request bursts during page load.
const inflightSelectRequests = new Map<string, Promise<GatewayResponse<any>>>();

function acquireSlot(): Promise<void> {
  if (activeRequests < MAX_CONCURRENT) {
    activeRequests++;
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    requestQueue.push({ resolve });
  });
}

function releaseSlot() {
  activeRequests--;
  if (requestQueue.length > 0 && activeRequests < MAX_CONCURRENT) {
    activeRequests++;
    requestQueue.shift()!.resolve();
  }
}

function buildSelectRequestKey(sessionToken: string, request: GatewayRequest): string {
  return `${sessionToken}::${JSON.stringify({ table: request.table, action: request.action, params: request.params })}`;
}

// Main gateway function
export async function apiGateway<T = any>(request: GatewayRequest): Promise<GatewayResponse<T>> {
  const sessionToken = getSessionToken();

  if (!sessionToken) {
    console.warn('[Gateway] No session token found - user may not be logged in');
    return {
      data: null,
      error: { message: 'No session token - please log in' },
      success: false,
    };
  }

  const isDeduplicableSelect = request.action === 'select';
  const selectRequestKey = isDeduplicableSelect ? buildSelectRequestKey(sessionToken, request) : null;
  if (selectRequestKey) {
    const inflight = inflightSelectRequests.get(selectRequestKey);
    if (inflight) {
      return inflight as Promise<GatewayResponse<T>>;
    }
  }

  const executeRequest = async (): Promise<GatewayResponse<T>> => {
    await acquireSlot();
    console.log(`[Gateway] ${request.action} on ${request.table}`);

    try {
      const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
      const retryDelay = (attempt: number) => 1000 * (attempt + 1) + Math.floor(Math.random() * 250);
      const isRetryable = (err: unknown): boolean => {
        if (err instanceof TypeError && /Failed to fetch/i.test(err.message)) return true;
        const msg = (err as any)?.message || '';
        if (/503|service unavailable|boot|session validation timed out/i.test(msg)) return true;
        if ((err as any)?.name === 'FunctionsHttpError') return true;
        return false;
      };
      const isServiceUnavailable = (data: any) =>
        data?.code === 'SERVICE_UNAVAILABLE' || data?.error === 'Service Unavailable';

      let invokeResult: { data: any; error: any } | null = null;
      const MAX_RETRIES = 3;

      for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
        try {
          invokeResult = await supabase.functions.invoke('api-gateway', {
            body: request,
            headers: {
              'x-session-token': sessionToken,
            },
          });

          if (attempt < MAX_RETRIES - 1 && invokeResult?.data && isServiceUnavailable(invokeResult.data)) {
            console.warn(`[Gateway] Service unavailable (attempt ${attempt + 1}/${MAX_RETRIES}). Retrying…`);
            await delay(retryDelay(attempt));
            continue;
          }

          break;
        } catch (e) {
          if (attempt < MAX_RETRIES - 1 && isRetryable(e)) {
            console.warn(`[Gateway] Transient error (attempt ${attempt + 1}/${MAX_RETRIES}): ${(e as any)?.message?.slice(0, 80)}. Retrying…`);
            await delay(retryDelay(attempt));
            continue;
          }
          throw e;
        }
      }

      const { data, error } = invokeResult!;

      if (error) {
        console.error('[Gateway] Invoke error:', error);
        const parsed = typeof error?.message === 'string' ? tryParseEdgeFunctionPayload(error.message) : null;
        return {
          data: null,
          error: {
            message: parsed?.message || error.message || 'Gateway request failed',
            code: parsed?.code,
          },
          success: false,
        };
      }

      // Handle unauthorized - clear session and redirect
      if (data?.error === 'Unauthorized') {
        console.warn('[Gateway] Session invalid, clearing...');
        localStorage.removeItem(SESSION_TOKEN_KEY);
        window.location.href = '/auth';
        return {
          data: null,
          error: { message: data.message || 'Session expired' },
          success: false,
        };
      }

      if (data?.error) {
        return {
          data: null,
          error: { message: data.message, code: data.code },
          success: false,
        };
      }

      return {
        data: data?.data ?? null,
        error: null,
        success: true,
      };
    } catch (e) {
      console.error('[Gateway] Exception:', e);
      return {
        data: null,
        error: {
          message:
            e instanceof Error
              ? e.message
              : 'Unknown error',
        },
        success: false,
      };
    } finally {
      releaseSlot();
      if (selectRequestKey) {
        inflightSelectRequests.delete(selectRequestKey);
      }
    }
  };

  const requestPromise = executeRequest();
  if (selectRequestKey) {
    inflightSelectRequests.set(selectRequestKey, requestPromise as Promise<GatewayResponse<any>>);
  }

  return requestPromise;
}

// ==================== CONVENIENCE METHODS ====================

// SELECT helper with fluent builder pattern
export class GatewayQuery<T = any> {
  private table: string;
  private action: GatewayAction = 'select';
  private selectClause: string = '*';
  private filters: QueryFilter[] = [];
  private orderClause?: { column: string; ascending?: boolean };
  private limitValue?: number;
  private offsetValue?: number;
  private singleMode: boolean = false;
  private maybeSingleMode: boolean = false;
  private dataPayload?: Record<string, any> | Record<string, any>[];
  private onConflictClause?: string;
  private countOnlyMode: boolean = false;

  constructor(table: string) {
    this.table = table;
  }

  select(columns: string = '*'): this {
    // Important: allow `.insert(...).select(...)` and `.update(...).select(...)` without
    // changing the action back to `select` (mimics supabase-js returning behavior).
    this.selectClause = columns;
    return this;
  }

  insert(data: Record<string, any> | Record<string, any>[]): this {
    this.action = 'insert';
    this.dataPayload = data;
    return this;
  }

  update(data: Record<string, any>): this {
    this.action = 'update';
    this.dataPayload = data;
    return this;
  }

  upsert(data: Record<string, any> | Record<string, any>[], options?: { onConflict?: string }): this {
    this.action = 'upsert';
    this.dataPayload = data;
    this.onConflictClause = options?.onConflict;
    return this;
  }

  delete(): this {
    this.action = 'delete';
    return this;
  }

  eq(column: string, value: any): this {
    if (value === undefined || value === null) {
      console.error(`[Gateway] eq() called with ${value} for column "${column}" — skipping filter to prevent DB error`);
      return this;
    }
    this.filters.push({ column, operator: 'eq', value });
    return this;
  }

  neq(column: string, value: any): this {
    this.filters.push({ column, operator: 'neq', value });
    return this;
  }

  gt(column: string, value: any): this {
    this.filters.push({ column, operator: 'gt', value });
    return this;
  }

  gte(column: string, value: any): this {
    this.filters.push({ column, operator: 'gte', value });
    return this;
  }

  lt(column: string, value: any): this {
    this.filters.push({ column, operator: 'lt', value });
    return this;
  }

  lte(column: string, value: any): this {
    this.filters.push({ column, operator: 'lte', value });
    return this;
  }

  like(column: string, value: string): this {
    this.filters.push({ column, operator: 'like', value });
    return this;
  }

  ilike(column: string, value: string): this {
    this.filters.push({ column, operator: 'ilike', value });
    return this;
  }

  is(column: string, value: null | boolean): this {
    this.filters.push({ column, operator: 'is', value });
    return this;
  }

  not(column: string, operator: 'is', value: any): this {
    this.filters.push({ column, operator: 'not.is', value });
    return this;
  }

  in(column: string, values: any[]): this {
    if (!values || values.length === 0) {
      console.warn(`[Gateway] in() called with empty array for column "${column}" — skipping filter`);
      return this;
    }
    this.filters.push({ column, operator: 'in', value: values });
    return this;
  }

  contains(column: string, value: any): this {
    this.filters.push({ column, operator: 'contains', value });
    return this;
  }

  // Support for raw OR conditions (e.g., "status.eq.active,status.eq.pending")
  or(condition: string): this {
    this.filters.push({ column: '_or', operator: 'or', value: condition });
    return this;
  }

  order(column: string, options?: { ascending?: boolean }): this {
    this.orderClause = { column, ascending: options?.ascending ?? true };
    return this;
  }

  limit(count: number): this {
    this.limitValue = count;
    return this;
  }

  offset(count: number): this {
    this.offsetValue = count;
    return this;
  }

  range(from: number, to: number): this {
    this.offsetValue = from;
    this.limitValue = to - from + 1;
    return this;
  }

  single(): this {
    this.singleMode = true;
    return this;
  }

  maybeSingle(): this {
    this.maybeSingleMode = true;
    return this;
  }

  countOnly(): this {
    this.countOnlyMode = true;
    return this;
  }

  async execute(): Promise<GatewayResponse<T>> {
    // Safety: prevent delete/update without filters (would affect all rows)
    if ((this.action === 'delete' || this.action === 'update') && this.filters.length === 0) {
      console.error(`[Gateway] ${this.action.toUpperCase()} on "${this.table}" called without any filters — aborting to prevent data loss`);
      return { data: null, error: { message: `${this.action} requires at least one filter`, code: 'CLIENT_SAFETY' } } as GatewayResponse<T>;
    }

    return apiGateway<T>({
      action: this.action,
      table: this.table,
      data: this.dataPayload,
      params: {
        select: this.action === 'select' 
          ? this.selectClause 
          : (this.selectClause && this.selectClause !== '*' ? this.selectClause : undefined),
        filters: this.filters.length > 0 ? this.filters : undefined,
        order: this.orderClause,
        limit: this.limitValue,
        offset: this.offsetValue,
        single: this.singleMode || undefined,
        maybeSingle: this.maybeSingleMode || undefined,
        onConflict: this.onConflictClause,
        countOnly: this.countOnlyMode || undefined,
      },
      returning: this.action !== 'select',
    });
  }

  // Alias for execute() to match Supabase pattern
  then<TResult1 = GatewayResponse<T>, TResult2 = never>(
    onfulfilled?: ((value: GatewayResponse<T>) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null
  ): Promise<TResult1 | TResult2> {
    return this.execute().then(onfulfilled, onrejected);
  }
}

// Fluent query builder entry point
export function from<T = any>(table: string): GatewayQuery<T> {
  return new GatewayQuery<T>(table);
}

// INSERT helper (standalone function)
export async function insert<T = any>(
  table: string, 
  data: Record<string, any> | Record<string, any>[],
  options?: { returning?: boolean }
): Promise<GatewayResponse<T>> {
  return apiGateway<T>({
    action: 'insert',
    table,
    data,
    returning: options?.returning ?? true,
  });
}

// UPDATE helper (standalone function)
export async function update<T = any>(
  table: string,
  data: Record<string, any>,
  filters: QueryFilter[],
  options?: { returning?: boolean }
): Promise<GatewayResponse<T>> {
  return apiGateway<T>({
    action: 'update',
    table,
    data,
    params: { filters },
    returning: options?.returning ?? true,
  });
}

// UPSERT helper (standalone function)
export async function upsert<T = any>(
  table: string,
  data: Record<string, any> | Record<string, any>[],
  options?: { onConflict?: string; returning?: boolean }
): Promise<GatewayResponse<T>> {
  return apiGateway<T>({
    action: 'upsert',
    table,
    data,
    params: options?.onConflict ? { onConflict: options.onConflict } : undefined,
    returning: options?.returning ?? true,
  });
}

// DELETE helper (standalone function)
export async function deleteFrom(
  table: string,
  filters: QueryFilter[]
): Promise<GatewayResponse<null>> {
  return apiGateway({
    action: 'delete',
    table,
    params: { filters },
  });
}

// Re-export everything under a namespace for convenience
export const gateway = {
  from,
  insert,
  update,
  upsert,
  delete: deleteFrom,
  raw: apiGateway,
};

export default gateway;

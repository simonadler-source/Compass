/**
 * Get the production app URL for shareable links.
 * Always returns the published domain, never the preview domain.
 */
export function getAppUrl(): string {
  // Use the custom domain for all shareable links
  const publishedDomain = 'https://sependo.org';
  
  // In development/local, fall back to current origin
  if (typeof window !== 'undefined') {
    const origin = window.location.origin;
    // If we're on localhost, use localhost for testing
    if (origin.includes('localhost') || origin.includes('127.0.0.1')) {
      return origin;
    }
  }
  
  return publishedDomain;
}

/**
 * Build a shareable opportunity URL
 */
export function getOpportunityUrl(opportunityId: string): string {
  return `${getAppUrl()}/opportunities/${opportunityId}`;
}

/**
 * Build a shareable account URL
 */
export function getAccountUrl(accountId: string): string {
  return `${getAppUrl()}/accounts/${accountId}`;
}

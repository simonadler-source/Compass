// Pendo Customer Engagement Process (CEP) Configuration
// Based on the CEP process document defining 7 stages (0-6)

export interface CEPActivity {
  key: string;
  label: string;
}

export interface CEPStage {
  id: number;
  name: string;
  phase: 'pipeline_generation' | 'visible_opportunity' | 'value_realization';
  description: string;
  keyActivity: string;
  exampleActivities: string[];
  exitCriteria: string[];
  // Maps to detection rule IDs or signal types
  signalMappings: string[];
}

export const CEP_PHASES = {
  pipeline_generation: {
    label: 'Pipeline Generation (PG)',
    color: 'hsl(285, 90%, 65%)', // Purple/magenta
    bgColor: 'hsl(285, 90%, 65%, 0.15)',
    stages: [0, 1],
  },
  visible_opportunity: {
    label: 'Visible Opportunity (VO)',
    color: 'hsl(330, 85%, 60%)', // Pink/magenta
    bgColor: 'hsl(330, 85%, 60%, 0.15)',
    stages: [2, 3, 4],
  },
  value_realization: {
    label: 'Value Realization',
    color: 'hsl(35, 95%, 55%)', // Orange/gold
    bgColor: 'hsl(35, 95%, 55%, 0.15)',
    stages: [5, 6],
  },
} as const;

export const CEP_STAGES: CEPStage[] = [
  {
    id: 0,
    name: 'Qualification',
    phase: 'pipeline_generation',
    description: 'Customer agrees to further conversations',
    keyActivity: 'Deliver Pendo Overview',
    exampleActivities: [
      'Discovery calls & Introductions',
      'Initial demo',
      'Multi-thread PG',
      'Self guided tours',
      'Field marketing events',
      'More account research',
    ],
    exitCriteria: [
      'Completed Pendo Overview',
      'Potential pain identified',
      'Champion identified',
      'Next steps agreed',
    ],
    signalMappings: ['demo', 'discovery'],
  },
  {
    id: 1,
    name: 'Discovery',
    phase: 'pipeline_generation',
    description: 'Customer is open to change & shares info',
    keyActivity: '1:1 call with Champion to test Power & Influence',
    exampleActivities: [
      'Second/custom demo',
      'Reverse demo',
      'Schedule easy on-site',
      'Reference call',
      'Install Pendo Free',
    ],
    exitCriteria: [
      'FLM inspects and confirms Pain and Champion',
      'Should only be in this stage for <30 days',
    ],
    signalMappings: ['demo', 'reverse_demo'],
  },
  {
    id: 2,
    name: 'Solution',
    phase: 'visible_opportunity',
    description: 'Customer tells us problems and impacts',
    keyActivity: 'Eval Kickoff',
    exampleActivities: [
      'Mutual action plan',
      'PG other stakeholders',
      'Pendo on Pendo demo',
      'Intro w/ Pendo leader',
      'Field marketing events',
      'POV/POT scoping meeting',
      'Transformation workshop',
    ],
    exitCriteria: [
      'EB identified',
      'Intro requested',
      'Documented decision criteria',
    ],
    signalMappings: ['evaluation', 'demo', 'reverse_demo'],
  },
  {
    id: 3,
    name: 'Proof',
    phase: 'visible_opportunity',
    description: 'Customer tells us benefits of our solution',
    keyActivity: 'Build Business Value Assessment (BVA)',
    exampleActivities: [
      'Eval tech syncs',
      'Eval playback',
      'Transform workshops',
      'Scope services',
      'Intro w/ Pendo Leader',
      'Initial pricing calls',
      'Reference calls',
      'Procurement & Legal',
    ],
    exitCriteria: [
      'Documented Value Summary',
      'Met with the EB',
    ],
    signalMappings: ['evaluation', 'bva', 'technical_sync'],
  },
  {
    id: 4,
    name: 'Negotiate',
    phase: 'visible_opportunity',
    description: 'Customer provides access to procurement & legal',
    keyActivity: 'BVA Playback & Negotiation',
    exampleActivities: [
      'Final pricing calls',
      'Ongoing activities w/ Legal & Procurement',
      'Continued deposits with champions',
      'Initiate intro to CS & TAM',
    ],
    exitCriteria: [
      'Contract signed',
    ],
    signalMappings: ['negotiation', 'legal', 'procurement'],
  },
  {
    id: 5,
    name: 'Sales Won',
    phase: 'value_realization',
    description: 'Customer is ready to move forward & purchase Pendo',
    keyActivity: 'Internal knowledge transfer',
    exampleActivities: [
      'Write up note for #announcements',
      'Thank those who helped (including customer)',
    ],
    exitCriteria: [
      'Deal Desk Approved',
    ],
    signalMappings: ['closed_won', 'deal_desk'],
  },
  {
    id: 6,
    name: 'Closed Won',
    phase: 'value_realization',
    description: 'Customer actively uses Pendo & shares successes within the org',
    keyActivity: 'QBR/EBR on Value Realization',
    exampleActivities: [
      'New Customer Kickoff Call',
      'Services Implementation',
      'QBR/EBR',
      'CABs',
      'Field Marketing Events',
      'Pendomonium',
      'All of Pendo helping customer receive value',
    ],
    exitCriteria: [
      'Implementation Completed',
      'Value Realized',
      'Expansion Identified',
    ],
    signalMappings: ['implementation', 'qbr', 'expansion'],
  },
];

// Map sales_stage field values to CEP stage numbers
// Stage 0 - Qualification, Stage 1 - Discovery, Stage 2 - Solution, Stage 3 - Proof, 
// Stage 4 - Negotiate, Stage 5 - Sales Won, Stage 6 - Closed Won
export const SALES_STAGE_TO_CEP: Record<string, number> = {
  stage_0: 0,
  stage_1: 1,
  stage_2: 2,
  stage_3: 3,
  stage_4: 4,
  stage_5_sales_won: 5,
  stage_6_closed_won: 6,
  stage_7_closed_lost: 7,
  stage_5: 5,
  stage_6: 6,
  stage_7: 7,
  // Also support label-based values
  'Qualification': 0,
  'Discovery': 1,
  'Solution': 2,
  'Proof': 3,
  'Negotiate': 4,
  'Sales Won': 5,
  'Closed Won': 6,
  'Closed Lost': 7,
};

// Map raw stage value to display label
export const SALES_STAGE_LABELS: Record<string, string> = {
  'stage_0': 'Qualification',
  'stage_1': 'Discovery',
  'stage_2': 'Solution',
  'stage_3': 'Proof',
  'stage_4': 'Negotiate',
  'stage_5': 'Sales Won',
  'stage_5_sales_won': 'Sales Won',
  'stage_6': 'Closed Won',
  'stage_6_closed_won': 'Closed Won',
  'stage_7': 'Closed Lost',
  'stage_7_closed_lost': 'Closed Lost',
  'closed_lost': 'Closed Lost',
  'closed_won': 'Closed Won',
  'disqualified': 'Disqualified',
  'identified': 'Identified',
};

// Signal types for CEP
export type CEPSignalType = 
  | 'demo' 
  | 'demo_delivered'
  | 'reverse_demo' 
  | 'evaluation' 
  | 'legal' 
  | 'security' 
  | 'technical_discovery' 
  | 'process_discovery'
  | 'nda'
  | 'pricing'
  | 'dry_run'
  | 'eval_active'
  | 'eval_pending';

// Signal type configuration with labels and colors
export const SIGNAL_TYPE_CONFIG: Record<CEPSignalType, { label: string; color: string }> = {
  demo: { label: 'Demo Request', color: 'text-emerald-500' },
  demo_delivered: { label: 'Demo Delivered', color: 'text-green-600' },
  reverse_demo: { label: 'Reverse Demo', color: 'text-blue-500' },
  evaluation: { label: 'Evaluation', color: 'text-amber-500' },
  legal: { label: 'Legal', color: 'text-indigo-500' },
  security: { label: 'Security', color: 'text-cyan-500' },
  technical_discovery: { label: 'Tech Discovery', color: 'text-teal-500' },
  process_discovery: { label: 'Process Discovery', color: 'text-orange-500' },
  nda: { label: 'NDA', color: 'text-violet-500' },
  pricing: { label: 'Pricing', color: 'text-rose-500' },
  dry_run: { label: 'Dry Run', color: 'text-lime-600' },
  eval_active: { label: 'Evaluation Active', color: 'text-orange-600' },
  eval_pending: { label: 'Eval Pending (Quote)', color: 'text-yellow-600' },
};

// Map detection rule names to CEP activity keywords for signal placement
export const SIGNAL_TO_CEP_ACTIVITIES: Record<string, { stageStart: number; stageEnd: number; type: CEPSignalType }> = {
  // Demo request signals (early stage)
  'Demo Request Signals': { stageStart: 0, stageEnd: 1, type: 'demo' },
  'Demo Signals': { stageStart: 0, stageEnd: 1, type: 'demo' },
  // Demo delivered signals (demo actually happened)
  'Demo Delivered Signals': { stageStart: 1, stageEnd: 2, type: 'demo_delivered' },
  'Demo Delivered': { stageStart: 1, stageEnd: 2, type: 'demo_delivered' },
  // Reverse demo signals
  'Reverse Demo Signals': { stageStart: 1, stageEnd: 2, type: 'reverse_demo' },
  // Evaluation signals
  'Evaluation & POC Signals': { stageStart: 2, stageEnd: 3, type: 'evaluation' },
  'Evaluation Signals': { stageStart: 2, stageEnd: 3, type: 'evaluation' },
  // Legal signals
  'Legal Engagement Signals': { stageStart: 3, stageEnd: 4, type: 'legal' },
  'Legal Signals': { stageStart: 3, stageEnd: 4, type: 'legal' },
  // Security signals
  'Security Review Signals': { stageStart: 3, stageEnd: 4, type: 'security' },
  'Security Signals': { stageStart: 3, stageEnd: 4, type: 'security' },
  // Technical discovery signals
  'Technical Discovery Signals': { stageStart: 1, stageEnd: 2, type: 'technical_discovery' },
  'Technical Discovery': { stageStart: 1, stageEnd: 2, type: 'technical_discovery' },
  // Process discovery signals
  'Process Discovery Signals': { stageStart: 1, stageEnd: 2, type: 'process_discovery' },
  'Process Discovery': { stageStart: 1, stageEnd: 2, type: 'process_discovery' },
  // Technical Win - maps to evaluation phase
  'Technical Win': { stageStart: 2, stageEnd: 4, type: 'evaluation' },
  'Technical Win Signals': { stageStart: 2, stageEnd: 4, type: 'evaluation' },
  'Technical Loss': { stageStart: 2, stageEnd: 4, type: 'evaluation' },
  'Technical Loss Signals': { stageStart: 2, stageEnd: 4, type: 'evaluation' },
  // Other signals
  'NDA Signals': { stageStart: 2, stageEnd: 4, type: 'nda' },
  'NDA': { stageStart: 2, stageEnd: 4, type: 'nda' },
  'Pricing Signals': { stageStart: 3, stageEnd: 5, type: 'pricing' },
  'Pricing': { stageStart: 3, stageEnd: 5, type: 'pricing' },
  'Dry Run Signals': { stageStart: 2, stageEnd: 4, type: 'dry_run' },
  'Dry Run': { stageStart: 2, stageEnd: 4, type: 'dry_run' },
};

export function getCEPStageById(id: number): CEPStage | undefined {
  return CEP_STAGES.find(s => s.id === id);
}

export function getPhaseForStage(stageId: number): typeof CEP_PHASES[keyof typeof CEP_PHASES] | undefined {
  const stage = getCEPStageById(stageId);
  if (!stage) return undefined;
  return CEP_PHASES[stage.phase];
}

export function getPhaseColor(phase: keyof typeof CEP_PHASES): string {
  return CEP_PHASES[phase].color;
}

export function getStageColor(stageId: number): string {
  const stage = getCEPStageById(stageId);
  if (!stage) return 'hsl(var(--muted))';
  return CEP_PHASES[stage.phase].color;
}

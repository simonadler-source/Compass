// Utilities to ensure timeline/activity ordering reflects the real-world event time
// (e.g., email Sent/Date header) rather than when the record was created.

/**
 * Parse a date string (from email headers or user input) into ISO format.
 * Handles various formats including:
 * - "Wednesday, January 14, 2026 4:28 PM"
 * - "Wed, 14 Jan 2026 16:28:00 -0500"
 * - "2026-01-14 16:28"
 * - "January 14, 2026 at 4:28 PM"
 */
export function parseEmailDateToISO(dateStr: string | null | undefined): string | null {
  if (!dateStr) return null;
  const trimmed = dateStr.trim();
  if (!trimmed) return null;

  const parsedMs = Date.parse(trimmed);
  if (Number.isNaN(parsedMs)) return null;
  return new Date(parsedMs).toISOString();
}

/**
 * Extract the email sent timestamp from raw email content by scanning for common header patterns.
 * Looks for patterns like:
 * - "Sent: Wednesday, January 14, 2026 4:28 PM"
 * - "Date: Wed, 14 Jan 2026 16:28:00 -0500"
 * - "On January 14, 2026, at 4:28 PM, John wrote:"
 */
export function extractEmailSentAtISO(raw: string | null | undefined): string | null {
  if (!raw) return null;

  // Pattern 1: Standard header formats
  const headerMatch = raw.match(/^(?:Sent|Date):\s*(.+)$/im);
  if (headerMatch) {
    const parsed = parseEmailDateToISO(headerMatch[1]);
    if (parsed) return parsed;
  }

  // Pattern 2: "On [date] at [time], [name] wrote:" format
  const onWroteMatch = raw.match(/^On\s+(.+?(?:\d{4})?(?:,?\s+at\s+\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?)?),?\s+.+?\s+wrote:/im);
  if (onWroteMatch) {
    const parsed = parseEmailDateToISO(onWroteMatch[1]);
    if (parsed) return parsed;
  }

  // Pattern 3: ISO-like inline dates "2026-01-14T16:28:00"
  const isoMatch = raw.match(/\b(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2})?(?:[+-]\d{2}:?\d{2}|Z)?)\b/);
  if (isoMatch) {
    const parsed = parseEmailDateToISO(isoMatch[1]);
    if (parsed) return parsed;
  }

  return null;
}

/**
 * Extract all timestamps from an email thread content, returning them in chronological order.
 * Useful for multi-message threads where each message has its own timestamp.
 */
export function extractAllEmailTimestamps(raw: string | null | undefined): string[] {
  if (!raw) return [];

  const timestamps: string[] = [];
  
  // Match Sent/Date headers throughout the content
  const headerMatches = raw.matchAll(/(?:Sent|Date):\s*(.+)$/gim);
  for (const match of headerMatches) {
    const parsed = parseEmailDateToISO(match[1]);
    if (parsed) timestamps.push(parsed);
  }

  // Match "On X wrote:" patterns
  const onWroteMatches = raw.matchAll(/On\s+(.+?(?:\d{4})(?:,?\s+at\s+\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?)?),?\s+.+?\s+wrote:/gim);
  for (const match of onWroteMatches) {
    const parsed = parseEmailDateToISO(match[1]);
    if (parsed) timestamps.push(parsed);
  }

  // Deduplicate and sort chronologically
  const unique = [...new Set(timestamps)];
  unique.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
  
  return unique;
}

/**
 * Get the most recent (latest) timestamp from an email thread.
 * This is typically the timestamp of the newest message in the thread.
 */
export function extractLatestEmailTimestamp(raw: string | null | undefined): string | null {
  const timestamps = extractAllEmailTimestamps(raw);
  return timestamps.length > 0 ? timestamps[timestamps.length - 1] : null;
}

/**
 * Get the earliest timestamp from an email thread.
 * This is typically the timestamp of the original message that started the thread.
 */
export function extractEarliestEmailTimestamp(raw: string | null | undefined): string | null {
  const timestamps = extractAllEmailTimestamps(raw);
  return timestamps.length > 0 ? timestamps[0] : null;
}

/**
 * Convert a date-only string to a midday ISO timestamp.
 * Use midday UTC to reduce timezone edge cases with date-only inputs.
 * @deprecated Prefer using dateTimeToISO with explicit time when available
 */
export function dateOnlyToMiddayISO(dateOnly: string | null | undefined): string {
  if (dateOnly && /^\d{4}-\d{2}-\d{2}$/.test(dateOnly)) {
    return `${dateOnly}T12:00:00.000Z`;
  }
  return new Date().toISOString();
}

/**
 * Combine a date string and optional time string into a full ISO timestamp.
 * If time is not provided, defaults to midday UTC.
 * @param dateStr Date in YYYY-MM-DD format
 * @param timeStr Optional time in HH:MM or HH:MM:SS format (24-hour)
 */
export function dateTimeToISO(dateStr: string | null | undefined, timeStr?: string | null): string {
  if (!dateStr || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return new Date().toISOString();
  }

  if (!timeStr) {
    return `${dateStr}T12:00:00.000Z`;
  }

  // Normalize time to HH:MM:SS format
  const timeParts = timeStr.trim().match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (!timeParts) {
    return `${dateStr}T12:00:00.000Z`;
  }

  const hours = timeParts[1].padStart(2, '0');
  const minutes = timeParts[2];
  const seconds = timeParts[3] || '00';

  return `${dateStr}T${hours}:${minutes}:${seconds}.000Z`;
}

/**
 * Parse individual email messages from a thread, extracting sender, timestamp, and body for each.
 * Returns messages in chronological order (oldest first).
 */
export interface ParsedEmailMessage {
  sender: string;
  timestamp: string | null;
  body: string;
  index: number;
}

export function parseEmailThreadWithTimestamps(content: string): ParsedEmailMessage[] {
  if (!content?.trim()) return [];

  // Common email separators
  const separatorPatterns = [
    /^-{3,}\s*Original Message\s*-{3,}$/gim,
    /^-{3,}\s*Forwarded Message\s*-{3,}$/gim,
    /^On .+ wrote:$/gim,
    /^From: .+\nSent: .+\nTo: .+(?:\nSubject: .+)?$/gim,
    /^_{5,}$/gm,
    /^>{1,}\s*On .+ at .+, .+ wrote:$/gim,
  ];

  // Try to split by common patterns
  let messages: string[] = [content];
  
  for (const pattern of separatorPatterns) {
    const newMessages: string[] = [];
    for (const msg of messages) {
      const parts = msg.split(pattern);
      newMessages.push(...parts.filter(p => p.trim()));
    }
    if (newMessages.length > messages.length) {
      messages = newMessages;
    }
  }

  // Parse each message for sender/timestamp info
  const parsed: ParsedEmailMessage[] = messages.map((msg, index) => {
    const fromMatch = msg.match(/^From:\s*(.+)$/im);
    
    // Try multiple patterns for timestamp extraction
    let timestamp: string | null = null;
    
    // Pattern 1: Sent/Date header
    const dateMatch = msg.match(/(?:Sent|Date):\s*(.+)$/im);
    if (dateMatch) {
      timestamp = parseEmailDateToISO(dateMatch[1]);
    }
    
    // Pattern 2: "On X wrote:" at the start
    if (!timestamp) {
      const onWroteMatch = msg.match(/^On\s+(.+?(?:\d{4})(?:,?\s+at\s+\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?)?),?\s+.+?\s+wrote:/im);
      if (onWroteMatch) {
        timestamp = parseEmailDateToISO(onWroteMatch[1]);
      }
    }
    
    return {
      sender: fromMatch?.[1]?.trim() || `Message ${index + 1}`,
      timestamp,
      body: msg.trim(),
      index,
    };
  });

  // Sort by timestamp if available, maintaining original order for those without timestamps
  parsed.sort((a, b) => {
    if (a.timestamp && b.timestamp) {
      return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
    }
    if (a.timestamp && !b.timestamp) return -1;
    if (!a.timestamp && b.timestamp) return 1;
    return a.index - b.index;
  });

  return parsed;
}

/**
 * Infer the best timestamp to use for an imported piece of content.
 * For emails, parses the thread and returns the LATEST message timestamp.
 * For meetings with date+time, combines them properly.
 */
export function inferContentTimestamp(
  contentType: 'email' | 'meeting',
  content: string,
  dateStr?: string | null,
  timeStr?: string | null
): string {
  if (contentType === 'email') {
    // For emails, try to extract from content first
    const latestFromContent = extractLatestEmailTimestamp(content);
    if (latestFromContent) return latestFromContent;
    
    // Fall back to provided date/time
    if (dateStr) {
      return dateTimeToISO(dateStr, timeStr);
    }
    
    return new Date().toISOString();
  }
  
  // For meetings, use provided date/time
  if (dateStr) {
    return dateTimeToISO(dateStr, timeStr);
  }
  
  return new Date().toISOString();
}

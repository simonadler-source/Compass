import { supabase } from "@/integrations/supabase/client";

/**
 * Tables that require encryption for PII/sensitive data
 */
const ENCRYPTED_TABLES = [
  'momentum_meetings',
  'account_contacts',
  'transcript_reviews',
  'account_nbas',
  'account_pain_points',
  'account_use_cases',
  'account_metrics',
  'account_strategic_themes',
  'account_exec_summaries',
  'customer_stories',
  'contact_meeting_snapshots',
  'account_captured_insights',
  'opportunity_milestones',
  'opportunity_validation_tasks',
  'opportunity_readiness_answers',
  'competitor_scores',
  'profiles',
  'account_team_members',
  'opportunity_team_members',
  // Newly added tables
  'detection_rule_matches',
  'login_history',
  'milestone_history',
  'account_technologies',
  'account_documents',
  'competitors',
] as const;

type EncryptedTable = typeof ENCRYPTED_TABLES[number];

/**
 * Insert a record with automatic encryption of sensitive fields.
 * Uses the encrypt-pii edge function to handle encryption server-side.
 */
export async function encryptedInsert<T extends Record<string, unknown>>(
  table: EncryptedTable,
  data: T
): Promise<{ data: T | null; error: Error | null }> {
  try {
    const { data: result, error } = await supabase.functions.invoke('encrypt-pii', {
      body: { table, data, operation: 'insert' },
    });
    
    if (error) throw new Error(error.message);
    if (!result?.success) throw new Error(result?.error || 'Insert failed');
    
    return { data: result.data as T, error: null };
  } catch (err) {
    console.error(`[encryptedInsert] ${table} failed:`, err);
    return { data: null, error: err instanceof Error ? err : new Error(String(err)) };
  }
}

/**
 * Update a record with automatic encryption of sensitive fields.
 */
export async function encryptedUpdate<T extends Record<string, unknown>>(
  table: EncryptedTable,
  recordId: string,
  data: Partial<T>
): Promise<{ data: T | null; error: Error | null }> {
  try {
    const { data: result, error } = await supabase.functions.invoke('encrypt-pii', {
      body: { table, recordId, data, operation: 'update' },
    });
    
    if (error) throw new Error(error.message);
    if (!result?.success) throw new Error(result?.error || 'Update failed');
    
    return { data: result.data as T, error: null };
  } catch (err) {
    console.error(`[encryptedUpdate] ${table}:${recordId} failed:`, err);
    return { data: null, error: err instanceof Error ? err : new Error(String(err)) };
  }
}

/**
 * Upsert a record with automatic encryption of sensitive fields.
 */
export async function encryptedUpsert<T extends Record<string, unknown>>(
  table: EncryptedTable,
  data: T
): Promise<{ data: T | null; error: Error | null }> {
  try {
    const { data: result, error } = await supabase.functions.invoke('encrypt-pii', {
      body: { table, data, operation: 'upsert' },
    });
    
    if (error) throw new Error(error.message);
    if (!result?.success) throw new Error(result?.error || 'Upsert failed');
    
    return { data: result.data as T, error: null };
  } catch (err) {
    console.error(`[encryptedUpsert] ${table} failed:`, err);
    return { data: null, error: err instanceof Error ? err : new Error(String(err)) };
  }
}

/**
 * Batch insert multiple records with encryption.
 * Each record is encrypted individually to ensure proper IV per record.
 */
export async function encryptedBatchInsert<T extends Record<string, unknown>>(
  table: EncryptedTable,
  records: T[]
): Promise<{ inserted: number; failed: number; errors: string[] }> {
  const results = { inserted: 0, failed: 0, errors: [] as string[] };
  
  for (const record of records) {
    const { error } = await encryptedInsert(table, record);
    if (error) {
      results.failed++;
      results.errors.push(error.message);
    } else {
      results.inserted++;
    }
  }
  
  return results;
}

/**
 * Decrypt specific fields from a record.
 * Returns an object with the decrypted field values.
 */
export async function decryptFields(
  table: EncryptedTable,
  recordId: string,
  fields: string[]
): Promise<{ data: Record<string, string | null> | null; error: Error | null; encrypted: boolean }> {
  try {
    const { data: result, error } = await supabase.functions.invoke('decrypt-pii', {
      body: { recordId, table, fields },
    });
    
    if (error) throw new Error(error.message);
    if (!result?.success) throw new Error(result?.error || 'Decryption failed');
    
    return { data: result.decrypted, error: null, encrypted: result.encrypted };
  } catch (err) {
    console.error(`[decryptFields] ${table}:${recordId} failed:`, err);
    return { data: null, error: err instanceof Error ? err : new Error(String(err)), encrypted: false };
  }
}

/**
 * Helper to check if a table requires encryption
 */
export function isEncryptedTable(table: string): table is EncryptedTable {
  return ENCRYPTED_TABLES.includes(table as EncryptedTable);
}

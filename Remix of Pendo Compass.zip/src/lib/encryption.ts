import { supabase } from "@/integrations/supabase/client";

/**
 * Encrypts data by calling the encrypt-transcript edge function.
 * Returns the encrypted ciphertext and IV.
 */
export async function encryptData(content: string): Promise<{ ciphertext: string; iv: string }> {
  const { data, error } = await supabase.functions.invoke('encrypt-transcript', {
    body: { content },
  });
  
  if (error) throw new Error(`Encryption failed: ${error.message}`);
  if (!data?.success) throw new Error(data?.error || 'Encryption failed');
  
  return { ciphertext: data.ciphertext, iv: data.iv };
}

/**
 * Decrypts data by calling the decrypt-transcript edge function.
 * Can decrypt from any table with encrypted content.
 */
export async function decryptTranscript(
  transcriptId: string, 
  table: 'transcript_reviews' | 'momentum_meetings' = 'transcript_reviews'
): Promise<string> {
  const { data, error } = await supabase.functions.invoke('decrypt-transcript', {
    body: { transcriptId, table },
  });
  
  if (error) throw new Error(`Decryption failed: ${error.message}`);
  if (!data?.success) throw new Error(data?.error || 'Decryption failed');
  
  return data.content;
}

/**
 * Encrypts multiple fields for a record.
 * Returns an object with encrypted field names and their ciphertext values,
 * plus a shared IV.
 */
export async function encryptFields(
  fields: Record<string, string | null | undefined>
): Promise<{ encryptedFields: Record<string, string | null>; iv: string }> {
  const encryptedFields: Record<string, string | null> = {};
  let iv: string | null = null;
  
  for (const [fieldName, value] of Object.entries(fields)) {
    if (value === null || value === undefined) {
      encryptedFields[`${fieldName}_encrypted`] = null;
      continue;
    }
    
    const result = await encryptData(typeof value === 'object' ? JSON.stringify(value) : value);
    encryptedFields[`${fieldName}_encrypted`] = result.ciphertext;
    if (!iv) iv = result.iv;
  }
  
  return { encryptedFields, iv: iv || '' };
}

/**
 * Decrypts PII fields from a record using the decrypt-pii edge function.
 */
export async function decryptPII(
  recordId: string,
  table: string,
  fields: string[]
): Promise<Record<string, string | null>> {
  const { data, error } = await supabase.functions.invoke('decrypt-pii', {
    body: { recordId, table, fields },
  });
  
  if (error) throw new Error(`Decryption failed: ${error.message}`);
  if (!data?.success) throw new Error(data?.error || 'Decryption failed');
  
  return data.decrypted;
}

/**
 * Helper to prepare encrypted insert/update data for a record.
 * Encrypts specified fields and returns the full update object.
 */
export async function prepareEncryptedData(
  plaintextData: Record<string, unknown>,
  fieldsToEncrypt: string[]
): Promise<Record<string, unknown>> {
  const result: Record<string, unknown> = { ...plaintextData };
  
  const fieldsToProcess: Record<string, string> = {};
  for (const field of fieldsToEncrypt) {
    const value = plaintextData[field];
    if (value !== null && value !== undefined) {
      fieldsToProcess[field] = typeof value === 'object' ? JSON.stringify(value) : String(value);
    }
  }
  
  if (Object.keys(fieldsToProcess).length === 0) {
    result.is_encrypted = true;
    return result;
  }
  
  const { encryptedFields, iv } = await encryptFields(fieldsToProcess);
  
  // Add encrypted fields to result
  for (const [key, value] of Object.entries(encryptedFields)) {
    result[key] = value;
  }
  
  // Clear plaintext fields
  for (const field of fieldsToEncrypt) {
    result[field] = null;
  }
  
  result.encryption_iv = iv;
  result.is_encrypted = true;
  
  return result;
}

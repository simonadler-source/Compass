import jsPDF from 'jspdf';
import type { SECoachingScore } from '@/hooks/useSECoachingScores';
import { format } from 'date-fns';

const DIMENSION_LABELS: Record<string, string> = {
  pov_challenge_score: 'POV & Challenge',
  ownership_control_score: 'Ownership & Control',
  storytelling_proof_score: 'Storytelling & Proof',
  reverse_demo_score: 'Reverse Demo',
  champion_arming_score: 'Champion Arming',
  objection_handling_score: 'Objection Handling',
  pain_quantification_score: 'Pain Quantification',
  questioning_score: 'Questioning',
  differentiation_score: 'Differentiation',
  strategy_rigor_score: 'Strategy & Rigor',
  technical_competency_score: 'Technical Competency',
  value_anchoring_score: 'Value Anchoring',
  energy_inspiration_score: 'Energy & Inspiration',
};

const ENABLEMENT_LABELS: Record<string, string> = {
  pov_challenge_score: 'Executive Framing / Challenge Articulation',
  ownership_control_score: 'Story Flow & Structure',
  storytelling_proof_score: 'Use Case Alignment',
  reverse_demo_score: '',
  champion_arming_score: '',
  objection_handling_score: '',
  pain_quantification_score: 'Negative Consequence',
  questioning_score: 'Discovery Quality',
  differentiation_score: '',
  strategy_rigor_score: 'Account Context & Business Relevance',
  technical_competency_score: 'Confidence & Delivery',
  value_anchoring_score: 'PBO Clarity',
  energy_inspiration_score: 'Prospect Activation',
};

const EVIDENCE_KEYS: Record<string, string> = {
  pov_challenge_score: 'pov_challenge_evidence',
  ownership_control_score: 'ownership_control_evidence',
  storytelling_proof_score: 'storytelling_proof_evidence',
  reverse_demo_score: 'reverse_demo_evidence',
  champion_arming_score: 'champion_arming_evidence',
  objection_handling_score: 'objection_handling_evidence',
  pain_quantification_score: 'pain_quantification_evidence',
  questioning_score: 'questioning_evidence',
  differentiation_score: 'differentiation_evidence',
  strategy_rigor_score: 'strategy_rigor_evidence',
  technical_competency_score: 'technical_competency_evidence',
  value_anchoring_score: 'value_anchoring_evidence',
  energy_inspiration_score: 'energy_inspiration_evidence',
};

const MARGIN = 15;
const PAGE_TOP = 20;
const PAGE_BOTTOM = 280;
const FOOTER_Y = 288;
const LINE_BODY = 4.5;
const LINE_EVIDENCE = 3.8;
const MAX_BLOCK_HEIGHT = PAGE_BOTTOM - PAGE_TOP - 2;

const SUCCESS_COLOR: [number, number, number] = [22, 163, 74];
const WARNING_COLOR: [number, number, number] = [180, 100, 0];

function normalizePdfText(value: unknown): string {
  return String(value ?? '')
    .replace(/\r\n?/g, '\n')
    .replace(/\u00A0/g, ' ')
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/[‐‑‒–—]/g, '-')
    .replace(/[…]/g, '...')
    .replace(/[→➜➝⟶]/g, '->')
    .replace(/[^\u0009\u000A\u000D\u0020-\u00FF]/g, '')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function splitSafeText(doc: jsPDF, text: string, maxWidth: number): string[] {
  const safeWidth = Math.max(20, maxWidth);
  const normalized = normalizePdfText(text);

  if (!normalized) return [];

  const paragraphs = normalized.split('\n');
  const lines: string[] = [];

  for (let i = 0; i < paragraphs.length; i++) {
    const paragraph = paragraphs[i]?.trim() ?? '';
    if (!paragraph) {
      lines.push('');
      continue;
    }

    const wrapped = doc.splitTextToSize(paragraph, safeWidth) as string[];
    lines.push(...wrapped);

    if (i < paragraphs.length - 1) {
      lines.push('');
    }
  }

  while (lines[0] === '') lines.shift();
  while (lines[lines.length - 1] === '') lines.pop();

  return lines;
}

function measureLinesHeight(lines: string[], lineHeight: number): number {
  if (!lines.length) return 0;
  return lines.reduce((sum, line) => sum + (line ? lineHeight : lineHeight * 0.55), 0);
}

function measureWrapped(doc: jsPDF, text: string, maxWidth: number, lineHeight: number): number {
  return measureLinesHeight(splitSafeText(doc, text, maxWidth), lineHeight);
}

function ensureSpace(doc: jsPDF, y: number, needed: number): number {
  if (y + needed > PAGE_BOTTOM) {
    doc.addPage();
    return PAGE_TOP;
  }
  return y;
}

function ensureBlockSpace(doc: jsPDF, y: number, blockHeight: number): number {
  return ensureSpace(doc, y, Math.min(blockHeight, MAX_BLOCK_HEIGHT));
}

function addWrappedLines(
  doc: jsPDF,
  lines: string[],
  x: number,
  y: number,
  lineHeight: number,
): number {
  for (const line of lines) {
    const drawHeight = line ? lineHeight : lineHeight * 0.55;
    y = ensureSpace(doc, y, drawHeight);
    if (line) {
      doc.text(line, x, y);
    }
    y += drawHeight;
  }
  return y;
}

function addWrapped(
  doc: jsPDF,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
): number {
  const safeWidth = Math.max(20, Math.min(maxWidth, doc.internal.pageSize.getWidth() - x - MARGIN));
  const lines = splitSafeText(doc, text, safeWidth);
  return addWrappedLines(doc, lines, x, y, lineHeight);
}

function drawFooter(doc: jsPDF) {
  const generatedLabel = `Generated ${format(new Date(), 'MMM d, yyyy HH:mm')} - Pendo Compass Coaching`;
  const pages = doc.getNumberOfPages();

  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(150);

    doc.text(generatedLabel, MARGIN, FOOTER_Y);

    const pageLabel = `Page ${i} of ${pages}`;
    const rightX = doc.internal.pageSize.getWidth() - MARGIN - doc.getTextWidth(pageLabel);
    doc.text(pageLabel, rightX, FOOTER_Y);
  }
}

function sectionHeading(
  doc: jsPDF,
  y: number,
  title: string,
  color: [number, number, number] = [0, 0, 0],
): number {
  y = ensureBlockSpace(doc, y, 16);
  doc.setDrawColor(210);
  doc.setLineWidth(0.3);
  doc.line(MARGIN, y - 2, doc.internal.pageSize.getWidth() - MARGIN, y - 2);

  y += 4;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...color);
  doc.text(normalizePdfText(title), MARGIN, y);

  doc.setTextColor(0);
  y += 7;
  return y;
}

export function exportCoachingPdf(score: SECoachingScore) {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const contentWidth = pageWidth - MARGIN * 2;
  let y = PAGE_TOP;

  // ===== HEADER =====
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('SE Coaching Report', MARGIN, y);
  y += 7;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(120);
  doc.text('Confidential - For Growth Conversation Use', MARGIN, y);
  doc.setTextColor(0);
  y += 10;

  // ===== SE INFO =====
  const infoLines: [string, string][] = [
    ['SE:', normalizePdfText(score.se_email)],
    ['Date:', format(new Date(score.analyzed_at), 'MMMM d, yyyy')],
  ];

  if (score.opportunity_name) {
    infoLines.push(['Opportunity:', normalizePdfText(score.opportunity_name)]);
  }

  infoLines.push(['Meeting Type:', normalizePdfText(score.meeting_type).replace(/_/g, ' ')]);

  doc.setFontSize(10);
  for (const [label, value] of infoLines) {
    doc.setFont('helvetica', 'bold');
    const labelW = doc.getTextWidth(label) + 3;
    doc.text(label, MARGIN, y);

    doc.setFont('helvetica', 'normal');
    doc.text(value || '-', MARGIN + labelW, y);
    y += 5.5;
  }
  y += 4;

  // ===== OVERALL SCORE BOX =====
  doc.setFillColor(243, 244, 246);
  doc.roundedRect(MARGIN, y - 4, contentWidth, 14, 3, 3, 'F');

  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(
    `Overall Score: ${score.overall_score != null ? score.overall_score.toFixed(1) : '-'} / 5.0`,
    MARGIN + 5,
    y + 5,
  );

  if (score.se_talk_ratio != null) {
    const talkText = `Talk Ratio: ${Math.round(score.se_talk_ratio)}%`;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(talkText, pageWidth - MARGIN - doc.getTextWidth(talkText) - 5, y + 5);
  }

  y += 18;

  // ===== DIMENSION SCORES =====
  y = sectionHeading(doc, y, 'Dimension Scores');

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setFillColor(235, 235, 235);
  doc.rect(MARGIN, y - 3.5, contentWidth, 6, 'F');
  doc.setTextColor(60);
  doc.text('Dimension', MARGIN + 3, y);
  doc.text('Score', MARGIN + 56, y);
  doc.text('Weight', MARGIN + 73, y);
  doc.setTextColor(0);
  y += 6;

  for (const [dimKey, label] of Object.entries(DIMENSION_LABELS)) {
    const val = score[dimKey as keyof SECoachingScore] as number | null;
    const evidenceKey = EVIDENCE_KEYS[dimKey];
    const evidenceRaw = evidenceKey
      ? (score[evidenceKey as keyof SECoachingScore] as string | null) ?? ''
      : '';

    const weightKey = dimKey.replace('_score', '');
    const weights = score.weights_used as Record<string, number> | null;
    const weight = weights?.[weightKey];
    const weightPct = weight != null ? `${Math.round(weight * 100)}%` : '-';

    const evidenceLines = splitSafeText(doc, evidenceRaw, contentWidth - 10);
    const blockHeight = 5 + measureLinesHeight(evidenceLines, LINE_EVIDENCE) + 4;
    y = ensureBlockSpace(doc, y, blockHeight);

    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0);
    const enablementLabel = ENABLEMENT_LABELS[dimKey];
    const displayLabel = enablementLabel ? `${label}  (${enablementLabel})` : label;
    doc.text(displayLabel, MARGIN + 3, y);

    const scoreText = val != null ? val.toFixed(1) : '-';
    if (val != null) {
      if (val >= 4) doc.setTextColor(...SUCCESS_COLOR);
      else if (val >= 3) doc.setTextColor(...WARNING_COLOR);
      else doc.setTextColor(220, 38, 38);
    }

    const scoreX = Math.max(MARGIN + 130, doc.getTextWidth(displayLabel) + MARGIN + 10);
    doc.text(scoreText, scoreX, y);
    doc.setTextColor(100);
    doc.setFont('helvetica', 'normal');
    doc.text(weightPct, scoreX + 17, y);

    doc.setTextColor(0);
    y += 5;

    if (evidenceLines.length > 0) {
      doc.setFontSize(7.5);
      doc.setFont('helvetica', 'italic');
      doc.setTextColor(90);
      y = addWrappedLines(doc, evidenceLines, MARGIN + 5, y, LINE_EVIDENCE);
      doc.setTextColor(0);
    }

    // Delivery technique breakdown for Energy & Inspiration
    if (dimKey === 'energy_inspiration_score') {
      const breakdown = (score as any).energy_delivery_breakdown;
      if (breakdown) {
        const techLabels: [string, string][] = [
          ['pitch_variation', 'Pitch Variation (Staircase)'],
          ['value_word_emphasis', 'Value Word Emphasis'],
          ['pace_variation', 'Pace Variation (BPM)'],
          ['vocal_warmth', 'Vocal Warmth'],
          ['verbal_highlighters', 'Verbal Highlighters'],
        ];
        y = ensureSpace(doc, y, 5 + techLabels.length * 4.5);
        doc.setFontSize(7.5);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(60);
        doc.text('Delivery Technique Breakdown:', MARGIN + 5, y);
        y += 4;
        for (const [key, techLabel] of techLabels) {
          const techScore = breakdown[`${key}_score`] as number | undefined;
          const techEvidence = breakdown[`${key}_evidence`] as string | undefined;
          doc.setFont('helvetica', 'normal');
          doc.setTextColor(90);
          doc.text(`${techLabel}:`, MARGIN + 8, y);
          if (techScore != null) {
            if (techScore >= 4) doc.setTextColor(...SUCCESS_COLOR);
            else if (techScore >= 3) doc.setTextColor(...WARNING_COLOR);
            else doc.setTextColor(220, 38, 38);
            doc.setFont('helvetica', 'bold');
            doc.text(`${techScore}/5`, MARGIN + 65, y);
          }
          doc.setTextColor(0);
          y += 4;
          if (techEvidence) {
            doc.setFontSize(7);
            doc.setFont('helvetica', 'italic');
            doc.setTextColor(100);
            const evidenceLines = splitSafeText(doc, techEvidence, contentWidth - 18);
            y = ensureSpace(doc, y, measureLinesHeight(evidenceLines, LINE_EVIDENCE));
            y = addWrappedLines(doc, evidenceLines, MARGIN + 10, y, LINE_EVIDENCE);
            doc.setFontSize(7.5);
            doc.setTextColor(0);
            y += 1;
          }
        }
      }
    }

    y += 1.5;
    doc.setDrawColor(230);
    doc.setLineWidth(0.15);
    doc.line(MARGIN + 3, y, pageWidth - MARGIN - 3, y);
    y += 3;
  }

  // ===== GREATNESS MOMENT =====
  if (score.greatness_moment) {
    y = sectionHeading(doc, y, 'The "Greatness" Moment', SUCCESS_COLOR);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'italic');
    y = addWrapped(doc, `"${score.greatness_moment}"`, MARGIN + 4, y, contentWidth - 8, LINE_BODY);
    y += 4;
  }

  // ===== OPPORTUNITY GAP =====
  if (score.opportunity_gap) {
    y = sectionHeading(doc, y, 'The "Opportunity" Gap', WARNING_COLOR);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    y = addWrapped(doc, score.opportunity_gap, MARGIN + 4, y, contentWidth - 8, LINE_BODY);
    y += 4;
  }

  // ===== WHAT WORKED WELL =====
  const whatWorked = (score.what_worked_well as Array<{ snippet: string; explanation: string }>) || [];
  if (whatWorked.length > 0) {
    y = sectionHeading(doc, y, 'What Worked Well', SUCCESS_COLOR);

    for (const item of whatWorked) {
      const snippetText = `"${normalizePdfText(item.snippet)}"`;
      const explanationText = normalizePdfText(item.explanation);

      const itemHeight =
        measureWrapped(doc, snippetText, contentWidth - 10, LINE_BODY) +
        measureWrapped(doc, explanationText, contentWidth - 10, LINE_BODY) +
        6;

      y = ensureBlockSpace(doc, y, itemHeight);

      doc.setFontSize(9);
      doc.setFont('helvetica', 'italic');
      doc.setTextColor(0);
      y = addWrapped(doc, snippetText, MARGIN + 4, y, contentWidth - 10, LINE_BODY);

      doc.setFont('helvetica', 'normal');
      doc.setTextColor(80);
      y = addWrapped(doc, explanationText, MARGIN + 4, y, contentWidth - 10, LINE_BODY);

      doc.setTextColor(0);
      y += 5;
    }
  }

  // ===== AREAS FOR IMPROVEMENT + COACHING =====
  const whatDidnt = (score.what_didnt_work as Array<{ snippet: string; explanation: string }>) || [];
  const guidance =
    (score.coaching_guidance as Array<{ pattern_observed: string; technique: string; expected_impact: string }>) || [];

  if (whatDidnt.length > 0) {
    y = sectionHeading(doc, y, 'Areas for Improvement', WARNING_COLOR);

    whatDidnt.forEach((item, i) => {
      const snippetText = `"${normalizePdfText(item.snippet)}"`;
      const explanationText = normalizePdfText(item.explanation);
      const tip = guidance[i];

      let tipRenderHeight = 0;
      let tipMainLines: string[] = [];
      let tipImpactLines: string[] = [];
      const boxWidth = contentWidth - 12;
      const boxInnerWidth = boxWidth - 10;

      if (tip) {
        const tipMainText = `What to do instead: ${normalizePdfText(tip.technique)}`;
        const tipImpactText = `Expected impact: ${normalizePdfText(tip.expected_impact)}`;

        tipMainLines = splitSafeText(doc, tipMainText, boxInnerWidth);
        tipImpactLines = splitSafeText(doc, tipImpactText, boxInnerWidth);

        const boxHeight =
          measureLinesHeight(tipMainLines, 4) +
          measureLinesHeight(tipImpactLines, 3.5) +
          8;

        tipRenderHeight = boxHeight > MAX_BLOCK_HEIGHT - 10
          ? measureWrapped(doc, tipMainText, contentWidth - 10, LINE_BODY) +
            measureWrapped(doc, tipImpactText, contentWidth - 10, LINE_BODY) +
            3
          : boxHeight + 4;
      }

      const itemHeight =
        measureWrapped(doc, snippetText, contentWidth - 10, LINE_BODY) +
        measureWrapped(doc, explanationText, contentWidth - 10, LINE_BODY) +
        tipRenderHeight +
        8;

      y = ensureBlockSpace(doc, y, itemHeight);

      doc.setFontSize(9);
      doc.setFont('helvetica', 'italic');
      doc.setTextColor(0);
      y = addWrapped(doc, snippetText, MARGIN + 4, y, contentWidth - 10, LINE_BODY);

      doc.setFont('helvetica', 'normal');
      doc.setTextColor(80);
      y = addWrapped(doc, explanationText, MARGIN + 4, y, contentWidth - 10, LINE_BODY);
      doc.setTextColor(0);
      y += 2;

      if (tip) {
        const tipMainText = `What to do instead: ${normalizePdfText(tip.technique)}`;
        const tipImpactText = `Expected impact: ${normalizePdfText(tip.expected_impact)}`;

        const boxHeight =
          measureLinesHeight(tipMainLines, 4) +
          measureLinesHeight(tipImpactLines, 3.5) +
          8;

        if (boxHeight > MAX_BLOCK_HEIGHT - 10) {
          doc.setFontSize(8.5);
          doc.setFont('helvetica', 'bold');
          y = addWrapped(doc, tipMainText, MARGIN + 6, y, contentWidth - 12, LINE_BODY);
          doc.setFont('helvetica', 'normal');
          doc.setTextColor(90);
          y = addWrapped(doc, tipImpactText, MARGIN + 6, y, contentWidth - 12, LINE_BODY);
          doc.setTextColor(0);
          y += 2;
        } else {
          y = ensureBlockSpace(doc, y, boxHeight + 4);

          doc.setFillColor(238, 242, 255);
          doc.setDrawColor(190, 200, 230);
          doc.setLineWidth(0.3);
          doc.roundedRect(MARGIN + 6, y - 2, boxWidth, boxHeight, 2, 2, 'FD');

          doc.setFontSize(8);
          doc.setFont('helvetica', 'bold');
          doc.setTextColor(30);

          let tipY = y + 3;
          for (const line of tipMainLines) {
            const drawHeight = line ? 4 : 2.2;
            if (line) doc.text(line, MARGIN + 11, tipY);
            tipY += drawHeight;
          }

          doc.setFont('helvetica', 'normal');
          doc.setTextColor(90);
          tipY += 0.5;

          for (const line of tipImpactLines) {
            const drawHeight = line ? 3.5 : 2;
            if (line) doc.text(line, MARGIN + 11, tipY);
            tipY += drawHeight;
          }

          doc.setTextColor(0);
          y += boxHeight + 4;
        }
      }

      y += 4;
    });
  }

  // ===== ACTIONABLE NEXT STEP =====
  if (score.actionable_next_step) {
    y = sectionHeading(doc, y, 'Actionable Next Step');
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    y = addWrapped(doc, score.actionable_next_step, MARGIN + 4, y, contentWidth - 8, LINE_BODY);
  }

  // ===== FOOTER ON ALL PAGES =====
  drawFooter(doc);

  const safeEmailPrefix = normalizePdfText(score.se_email)
    .split('@')[0]
    .replace(/[^a-zA-Z0-9._-]+/g, '-')
    .replace(/-+/g, '-');

  const fileName = `coaching-${safeEmailPrefix || 'report'}-${format(new Date(score.analyzed_at), 'yyyy-MM-dd')}.pdf`;
  doc.save(fileName);
}

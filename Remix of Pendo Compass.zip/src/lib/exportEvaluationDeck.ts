import PptxGenJS from 'pptxgenjs';
import { type EvaluationDeckData, type ReadinessQuestionDetail } from '@/hooks/useEvaluationDeckData';
import { format } from 'date-fns';

// ─── Brand palette (matching the React slide components) ─────────────────────
const BRAND = {
  navy: '1B2A4A',
  navyEnd: '2D3E5F',
  white: 'FFFFFF',
  gray50: 'F9FAFB',
  gray100: 'F3F4F6',
  gray200: 'E5E7EB',
  gray400: '9CA3AF',
  gray500: '6B7280',
  gray600: '4B5563',
  gray700: '374151',
  gray800: '1F2937',
  blue50: 'EFF6FF',
  blue100: 'DBEAFE',
  blue400: '60A5FA',
  blue500: '3B82F6',
  blue600: '2563EB',
  green500: '16A34A',
  green50: 'F0FDF4',
  green100: 'DCFCE7',
  emerald50: 'ECFDF5',
  emerald100: 'D1FAE5',
  emerald500: '10B981',
  emerald700: '047857',
  amber100: 'FEF3C7',
  amber500: 'F59E0B',
  amber600: 'D97706',
  amber700: 'B45309',
  red50: 'FEF2F2',
  red100: 'FEE2E2',
  red400: 'F87171',
  red500: 'EF4444',
  red700: 'B91C1C',
  pink: 'EC407A',
  violet50: 'F5F3FF',
  violet600: '7C3AED',
  orange50: 'FFF7ED',
  orange100: 'FFEDD5',
  orange200: 'FDBA74',
  orange700: 'C2410C',
  yellow50: 'FEFCE8',
  yellow200: 'FDE047',
  yellow700: 'A16207',
  teal50: 'F0FDFA',
  teal200: '99F6E4',
  teal700: '0F766E',
  rose50: 'FFF1F2',
  rose200: 'FECDD3',
  rose700: 'BE123C',
};

const FONT = 'Arial';
const SLIDE_W = 13.33; // LAYOUT_WIDE
const SLIDE_H = 7.5;

// ─── Shared helpers ──────────────────────────────────────────────────────────

function addGradientHeader(slide: PptxGenJS.Slide, title: string, subtitle: string, headerH = 1.3) {
  slide.addShape('rect', { x: 0, y: 0, w: '100%', h: headerH, fill: { color: BRAND.navy } });
  slide.addText(title, { x: 0.8, y: headerH * 0.12, w: 9, h: headerH * 0.5, fontSize: 32, bold: true, color: BRAND.white, fontFace: FONT });
  slide.addText(subtitle, { x: 0.8, y: headerH * 0.55, w: 9, h: headerH * 0.35, fontSize: 16, color: 'FFFFFF99', fontFace: FONT });
}

function addFooter(slide: PptxGenJS.Slide, oppUrl: string, slideNum: number, total: number) {
  const y = SLIDE_H - 0.45;
  slide.addShape('rect', { x: 0, y, w: '100%', h: 0.45, fill: { color: BRAND.gray50 }, line: { color: BRAND.gray200, width: 0.5 } });
  if (oppUrl) {
    slide.addText(oppUrl, { x: 0.8, y: y + 0.05, w: 8, h: 0.35, fontSize: 9, color: BRAND.blue400, fontFace: FONT, hyperlink: { url: oppUrl } });
  }
  slide.addText(`${slideNum} / ${total}`, { x: 10.5, y: y + 0.05, w: 2, h: 0.35, fontSize: 9, color: BRAND.gray400, fontFace: FONT, align: 'right' });
}

/** Strip internal metadata prefixes from descriptions */
function cleanDescription(raw: string | null | undefined): string | null {
  if (!raw) return null;
  return raw.replace(/^Linked from discovered:\s*"?/i, '').replace(/"$/, '').trim() || null;
}

// ─── Slide 1: Overview ───────────────────────────────────────────────────────

function buildSlideOverview(pptx: PptxGenJS, data: EvaluationDeckData, oppUrl: string) {
  const s = pptx.addSlide();
  addGradientHeader(s, data.accountName, 'Evaluation Overview');

  let y = 1.55;

  // Executive synopsis
  if (data.customerSynopsis) {
    s.addShape('rect', { x: 0.8, y, w: 11.7, h: 1.3, fill: { color: BRAND.gray100 }, rectRadius: 0.12 });
    s.addText([
      { text: 'Executive Synopsis', options: { bold: true, fontSize: 16, color: BRAND.gray800 } },
      { text: '\n' + data.customerSynopsis, options: { fontSize: 12, color: BRAND.gray600, lineSpacingMultiple: 1.3 } },
    ], { x: 1.0, y: y + 0.1, w: 11.3, h: 1.1, valign: 'top', fontFace: FONT });
    y += 1.5;
  }

  const colW = 5.65;
  const boxH = SLIDE_H - y - 0.65;

  // Current State - Challenges
  s.addShape('rect', { x: 0.8, y, w: colW, h: boxH, fill: { color: 'FEF2F2' }, rectRadius: 0.12 });
  s.addShape('ellipse', { x: 1.0, y: y + 0.2, w: 0.45, h: 0.45, fill: { color: BRAND.red100 } });
  s.addText('✕', { x: 1.0, y: y + 0.2, w: 0.45, h: 0.45, fontSize: 13, align: 'center', valign: 'middle', color: BRAND.red500, fontFace: FONT });
  s.addText('Current State — Challenges', { x: 1.55, y: y + 0.2, w: 4.6, h: 0.45, fontSize: 15, bold: true, color: BRAND.gray800, fontFace: FONT, valign: 'middle' });

  const painTexts: PptxGenJS.TextProps[] = data.painPoints.slice(0, 6).map(pp => ({
    text: '✕  ' + (pp.pain_point || '') + '\n',
    options: { fontSize: 11.5, color: BRAND.gray700, lineSpacingMultiple: 1.5, bullet: false } as any,
  }));
  if (painTexts.length > 0) {
    s.addText(painTexts, { x: 1.0, y: y + 0.85, w: colW - 0.4, h: boxH - 1.1, valign: 'top', fontFace: FONT });
  }

  // Future State - Potential Outcomes
  const rx = 0.8 + colW + 0.4;
  const rw = SLIDE_W - rx - 0.8;
  s.addShape('rect', { x: rx, y, w: rw, h: boxH, fill: { color: BRAND.emerald50 }, rectRadius: 0.12 });
  s.addShape('ellipse', { x: rx + 0.2, y: y + 0.2, w: 0.45, h: 0.45, fill: { color: BRAND.emerald100 } });
  s.addText('✓', { x: rx + 0.2, y: y + 0.2, w: 0.45, h: 0.45, fontSize: 13, align: 'center', valign: 'middle', color: BRAND.emerald500, fontFace: FONT });
  s.addText('Future State — Potential Outcomes', { x: rx + 0.75, y: y + 0.2, w: rw - 1, h: 0.45, fontSize: 15, bold: true, color: BRAND.gray800, fontFace: FONT, valign: 'middle' });

  const ucTexts: PptxGenJS.TextProps[] = data.useCases.slice(0, 6).map(uc => {
    const rawTitle = uc.use_case || '';
    const isEncrypted = !rawTitle || (rawTitle.includes('/') && rawTitle.length > 40 && !rawTitle.includes(' '));
    const title = isEncrypted ? ((uc as any).solution_description || uc.functional_area || '') : rawTitle;
    return {
      text: '✓  ' + title + '\n',
      options: { fontSize: 11.5, color: BRAND.gray700, lineSpacingMultiple: 1.5 } as any,
    };
  });
  if (ucTexts.length > 0) {
    s.addText(ucTexts, { x: rx + 0.2, y: y + 0.85, w: rw - 0.4, h: boxH - 1.1, valign: 'top', fontFace: FONT });
  }

  addFooter(s, oppUrl, 1, 8);
}

// ─── Slide 2: Strategic Themes ───────────────────────────────────────────────

function buildSlideStrategicThemes(pptx: PptxGenJS, data: EvaluationDeckData, oppUrl: string) {
  const s = pptx.addSlide();
  addGradientHeader(s, 'Strategic Themes', data.accountName, 1.15);

  const challenges = data.opportunityChallenges.length > 0 ? data.opportunityChallenges : data.strategicChallenges;
  const initiatives = data.opportunityInitiatives.length > 0 ? data.opportunityInitiatives : data.strategicInitiatives;

  const colW = 5.8;
  let y = 1.4;

  // Challenges header
  s.addShape('rect', { x: 0.8, y, w: 0.4, h: 0.4, fill: { color: BRAND.amber100 }, rectRadius: 0.05 });
  s.addText('⚠', { x: 0.8, y, w: 0.4, h: 0.4, fontSize: 12, align: 'center', valign: 'middle', fontFace: FONT });
  s.addText([
    { text: 'Strategic Challenges ', options: { bold: true, fontSize: 17, color: BRAND.gray800 } },
    { text: `(${challenges.length})`, options: { fontSize: 14, color: BRAND.gray400 } },
  ], { x: 1.3, y, w: 5, h: 0.4, fontFace: FONT, valign: 'middle' });

  // Initiatives header
  const ix = 0.8 + colW + 0.5;
  s.addShape('rect', { x: ix, y, w: 0.4, h: 0.4, fill: { color: BRAND.blue100 }, rectRadius: 0.05 });
  s.addText('💡', { x: ix, y, w: 0.4, h: 0.4, fontSize: 12, align: 'center', valign: 'middle', fontFace: FONT });
  s.addText([
    { text: 'Strategic Initiatives ', options: { bold: true, fontSize: 17, color: BRAND.gray800 } },
    { text: `(${initiatives.length})`, options: { fontSize: 14, color: BRAND.gray400 } },
  ], { x: ix + 0.5, y, w: 5, h: 0.4, fontFace: FONT, valign: 'middle' });

  y += 0.55;

  // Challenge cards
  challenges.slice(0, 4).forEach((t: any, i: number) => {
    const cy = y + i * 1.15;
    const impact = t.impact_level || 'medium';
    const impactColor = impact === 'critical' ? BRAND.red700 : impact === 'high' ? BRAND.orange700 : BRAND.amber700;
    const impactBg = impact === 'critical' ? BRAND.red100 : impact === 'high' ? BRAND.orange100 : BRAND.amber100;

    s.addShape('rect', { x: 0.8, y: cy, w: colW, h: 1.0, fill: { color: 'FEF9F0' }, line: { color: BRAND.amber100, width: 0.75 }, rectRadius: 0.08 });
    s.addText(t.theme_name || '', { x: 1.0, y: cy + 0.1, w: colW - 1.4, h: 0.3, fontSize: 12, bold: true, color: BRAND.gray800, fontFace: FONT });
    // Impact badge
    s.addShape('rect', { x: 0.8 + colW - 0.9, y: cy + 0.1, w: 0.7, h: 0.25, fill: { color: impactBg }, rectRadius: 0.04 });
    s.addText(impact, { x: 0.8 + colW - 0.9, y: cy + 0.1, w: 0.7, h: 0.25, fontSize: 8, align: 'center', valign: 'middle', color: impactColor, fontFace: FONT, bold: true });
    // Description
    if (t.description) {
      s.addText(t.description, { x: 1.0, y: cy + 0.42, w: colW - 0.4, h: 0.5, fontSize: 9.5, color: BRAND.gray500, fontFace: FONT, valign: 'top', lineSpacingMultiple: 1.2 });
    }
  });

  // Initiative cards
  initiatives.slice(0, 4).forEach((t: any, i: number) => {
    const cy = y + i * 1.15;
    s.addShape('rect', { x: ix, y: cy, w: colW, h: 1.0, fill: { color: BRAND.blue50 }, line: { color: BRAND.blue100, width: 0.75 }, rectRadius: 0.08 });
    s.addText(t.theme_name || '', { x: ix + 0.2, y: cy + 0.1, w: colW - 0.5, h: 0.3, fontSize: 12, bold: true, color: BRAND.gray800, fontFace: FONT });
    if (t.description) {
      s.addText(t.description, { x: ix + 0.2, y: cy + 0.42, w: colW - 0.4, h: 0.5, fontSize: 9.5, color: BRAND.gray500, fontFace: FONT, valign: 'top', lineSpacingMultiple: 1.2 });
    }
  });

  addFooter(s, oppUrl, 2, 8);
}

// ─── Slide 3: Use Cases ──────────────────────────────────────────────────────

const outcomeIcons: Record<string, string> = {
  'Increase Revenue': '📈', 'Cut Costs': '✂️', 'Reduce Risk': '🛡️',
  'Improve Experience': '✨', 'Drive Efficiency': '⚡',
};

function buildSlideUseCases(pptx: PptxGenJS, data: EvaluationDeckData, oppUrl: string) {
  const ucGrouped: Record<string, typeof data.useCases> = {};
  data.useCases.forEach(uc => {
    const outcome = (uc as any).business_outcome || 'Other';
    if (!ucGrouped[outcome]) ucGrouped[outcome] = [];
    ucGrouped[outcome].push(uc);
  });

  const groups = Object.entries(ucGrouped);
  const totalUCs = data.useCases.length;
  const compact = totalUCs > 8;
  const cardH = compact ? 0.65 : 0.95;
  const cardW = 5.65;

  let slideIdx = 0;
  let s: PptxGenJS.Slide | null = null;
  let y = 0;

  const startNewSlide = () => {
    s = pptx.addSlide();
    const subtitle = slideIdx === 0
      ? `${data.accountName} — ${totalUCs} use cases`
      : `${data.accountName} — continued`;
    addGradientHeader(s, 'Evaluation Use Cases', subtitle, 1.15);
    y = 1.35;
    slideIdx++;
  };

  startNewSlide();

  groups.forEach(([outcome, ucs]) => {
    const rowsNeeded = Math.ceil(Math.min(ucs.length, 4) / 2);
    const groupHeight = 0.4 + rowsNeeded * (cardH + 0.1) + 0.15;

    if (y + groupHeight > 6.8 && y > 1.5) {
      addFooter(s!, oppUrl, 3, 8);
      startNewSlide();
    }

    // Outcome header
    const icon = outcomeIcons[outcome] || '💡';
    s!.addText([
      { text: icon + '  ', options: { fontSize: 12 } },
      { text: outcome, options: { bold: true, fontSize: 14, color: BRAND.pink } },
      { text: `  ${ucs.length}`, options: { fontSize: 11, color: BRAND.gray400 } },
    ], { x: 0.8, y, w: 11.7, h: 0.35, fontFace: FONT, valign: 'middle' });
    y += 0.4;

    // Use case cards in 2-column grid
    ucs.slice(0, 4).forEach((uc, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const cx = 0.8 + col * (cardW + 0.4);
      const cy = y + row * (cardH + 0.1);
      const ucAny = uc as any;
      const rawDesc = ucAny.description || ucAny.solution_description || null;
      const desc = cleanDescription(rawDesc);

      // Card background
      s!.addShape('rect', { x: cx, y: cy, w: cardW, h: cardH, fill: { color: BRAND.blue50 }, line: { color: BRAND.blue100, width: 0.5 }, rectRadius: 0.06 });

      // Use case name
      const rawTitle = uc.use_case || '';
      const isEncrypted = !rawTitle || (rawTitle.includes('/') && rawTitle.length > 40 && !rawTitle.includes(' '));
      const ucTitle = isEncrypted ? (ucAny.solution_description || 'Untitled Use Case') : rawTitle;
      s!.addText(ucTitle, { x: cx + 0.15, y: cy + 0.06, w: cardW - 1.8, h: 0.22, fontSize: 10.5, bold: true, color: BRAND.gray800, fontFace: FONT, valign: 'top' });

      // Priority badge
      if (ucAny.priority) {
        const priColor = ucAny.priority === 'high' ? BRAND.red700 : ucAny.priority === 'medium' ? BRAND.amber700 : BRAND.gray500;
        const priBg = ucAny.priority === 'high' ? BRAND.red100 : ucAny.priority === 'medium' ? BRAND.amber100 : BRAND.gray100;
        s!.addShape('rect', { x: cx + cardW - 1.4, y: cy + 0.08, w: 0.6, h: 0.18, fill: { color: priBg }, rectRadius: 0.03 });
        s!.addText(ucAny.priority.toUpperCase(), { x: cx + cardW - 1.4, y: cy + 0.08, w: 0.6, h: 0.18, fontSize: 7, align: 'center', valign: 'middle', color: priColor, fontFace: FONT, bold: true });
      }

      // Status badge
      if (ucAny.status) {
        const statLabel = ucAny.status.charAt(0).toUpperCase() + ucAny.status.slice(1);
        const statusColors: Record<string, { bg: string; fg: string }> = {
          identified: { bg: BRAND.blue50, fg: BRAND.blue600 },
          validated: { bg: BRAND.emerald50, fg: BRAND.emerald700 },
          accepted: { bg: BRAND.emerald100, fg: BRAND.emerald700 },
          proposed: { bg: BRAND.violet50, fg: BRAND.violet600 },
          rejected: { bg: BRAND.red50, fg: BRAND.red700 },
        };
        const sc = statusColors[ucAny.status] || { bg: BRAND.blue50, fg: BRAND.blue600 };
        s!.addShape('rect', { x: cx + cardW - 0.75, y: cy + 0.08, w: 0.6, h: 0.18, fill: { color: sc.bg }, rectRadius: 0.03 });
        s!.addText(statLabel, { x: cx + cardW - 0.75, y: cy + 0.08, w: 0.6, h: 0.18, fontSize: 7, align: 'center', valign: 'middle', color: sc.fg, fontFace: FONT });
      }

      // Description — show full text, no truncation
      const descText = desc && desc !== ucTitle ? desc : null;
      if (descText && !compact) {
        s!.addText(descText, { x: cx + 0.15, y: cy + 0.3, w: cardW - 0.3, h: 0.35, fontSize: 8, color: BRAND.gray500, fontFace: FONT, valign: 'top', lineSpacingMultiple: 1.2 });
      }

      // Bottom row: functional area, business theme, confidence
      const bottomY = cy + cardH - 0.22;
      let chipX = cx + 0.15;

      if (uc.functional_area) {
        const faWidth = Math.min(uc.functional_area.length * 0.06 + 0.2, 1.5);
        s!.addShape('rect', { x: chipX, y: bottomY, w: faWidth, h: 0.16, fill: { color: BRAND.gray100 }, rectRadius: 0.03 });
        s!.addText(uc.functional_area, { x: chipX, y: bottomY, w: faWidth, h: 0.16, fontSize: 7, color: BRAND.gray600, fontFace: FONT, valign: 'middle' });
        chipX += faWidth + 0.1;
      }

      if (ucAny.business_theme && ucAny.business_theme !== outcome) {
        const btWidth = Math.min(ucAny.business_theme.length * 0.06 + 0.2, 1.5);
        s!.addShape('rect', { x: chipX, y: bottomY, w: btWidth, h: 0.16, fill: { color: 'FDF2F8' }, rectRadius: 0.03 });
        s!.addText(ucAny.business_theme, { x: chipX, y: bottomY, w: btWidth, h: 0.16, fontSize: 7, color: BRAND.pink, fontFace: FONT, valign: 'middle' });
        chipX += btWidth + 0.1;
      }

      if (ucAny.confidence_score != null) {
        const confText = `${Math.round(ucAny.confidence_score * 100)}% conf`;
        s!.addText(confText, { x: cx + cardW - 0.8, y: bottomY, w: 0.65, h: 0.16, fontSize: 7, color: BRAND.gray400, fontFace: FONT, align: 'right', valign: 'middle' });
      }
    });

    y += Math.ceil(Math.min(ucs.length, 4) / 2) * (cardH + 0.1) + 0.15;

    if (ucs.length > 4) {
      s!.addText(`+ ${ucs.length - 4} more`, { x: 0.8, y: y - 0.1, w: 3, h: 0.2, fontSize: 8, color: BRAND.gray400, fontFace: FONT });
      y += 0.15;
    }
  });

  addFooter(s!, oppUrl, 3, 8);
}

// ─── Slide 4: Success Criteria (paginated) ──────────────────────────────────

const statusDotColor: Record<string, string> = {
  new: BRAND.gray400, in_review: BRAND.blue500, awaiting_feedback: BRAND.amber500,
  met: BRAND.emerald500, at_risk: BRAND.red500, not_met: BRAND.red500, closed: BRAND.gray400, proposed: BRAND.violet600,
};
const statusLabel: Record<string, string> = {
  new: 'New', in_review: 'In Review', awaiting_feedback: 'Awaiting Feedback',
  met: 'Met', at_risk: 'At Risk', not_met: 'Not Met', closed: 'Closed', proposed: 'AI Proposed',
};
const statusBgColor: Record<string, string> = {
  new: BRAND.gray100, in_review: BRAND.blue100, awaiting_feedback: BRAND.orange100,
  met: BRAND.emerald100, at_risk: BRAND.red100, not_met: BRAND.red100, closed: BRAND.gray100, proposed: BRAND.violet50,
};
const statusTitleColorPPTX: Record<string, string> = {
  new: BRAND.pink, in_review: BRAND.blue600, awaiting_feedback: BRAND.amber600,
  met: BRAND.emerald700, at_risk: BRAND.red700, not_met: BRAND.red700, closed: BRAND.gray400, proposed: BRAND.violet600,
};

/** Estimate text height in inches based on character count and available width */
function estimateTextHeight(text: string, fontSize: number, widthInches: number): number {
  const charsPerInch = (72 / fontSize) * 1.8; // approximate chars per inch
  const charsPerLine = Math.floor(widthInches * charsPerInch);
  const lines = Math.ceil(text.length / charsPerLine);
  const lineHeight = (fontSize / 72) * 1.4; // line height in inches
  return lines * lineHeight;
}

function buildSlideSuccessCriteria(pptx: PptxGenJS, data: EvaluationDeckData, oppUrl: string, slideCounter: { current: number; total: number }) {
  const criteria = data.successCriteria;
  const metCount = criteria.filter(c => c.status === 'met').length;
  const atRiskCount = criteria.filter(c => c.status === 'at_risk' || c.status === 'not_met').length;
  const inProgressCount = criteria.filter(c => c.status === 'in_review' || c.status === 'awaiting_feedback').length;
  const newCount = criteria.length - metCount - inProgressCount - atRiskCount;
  const totalDel = criteria.reduce((sum, c) => sum + c.deliverables.length, 0);
  const completedDel = criteria.reduce((sum, c) => sum + c.deliverables.filter(d => d.is_completed).length, 0);

  let pageIdx = 0;
  let s: PptxGenJS.Slide | null = null;
  let y = 0;

  const startNewPage = () => {
    s = pptx.addSlide();
    const continued = pageIdx > 0;
    addGradientHeader(s, `Success Criteria${continued ? ' (continued)' : ''}`, data.accountName, 1.15);

    // Summary bar
    y = 1.3;
    s.addShape('rect', { x: 0, y, w: '100%', h: 0.4, fill: { color: BRAND.gray50 }, line: { color: BRAND.gray100, width: 0.5 } });
    const statPills = [
      { color: BRAND.emerald500, label: `${metCount} Met` },
      { color: BRAND.blue500, label: `${inProgressCount} In Progress` },
      { color: BRAND.red500, label: `${atRiskCount} At Risk` },
      { color: BRAND.gray400, label: `${newCount} New` },
    ];
    statPills.forEach((p, i) => {
      s!.addShape('ellipse', { x: 0.8 + i * 1.6, y: y + 0.14, w: 0.13, h: 0.13, fill: { color: p.color } });
      s!.addText(p.label, { x: 0.98 + i * 1.6, y: y + 0.05, w: 1.3, h: 0.3, fontSize: 9, color: BRAND.gray600, fontFace: FONT, bold: true, valign: 'middle' });
    });
    s.addText(`Deliverables: ${completedDel}/${totalDel}`, { x: 9, y: y + 0.05, w: 2, h: 0.3, fontSize: 9, color: BRAND.gray500, fontFace: FONT, align: 'right', valign: 'middle' });
    if (totalDel > 0) {
      s.addShape('rect', { x: 11.1, y: y + 0.16, w: 1.5, h: 0.1, fill: { color: BRAND.gray200 }, rectRadius: 0.05 });
      s.addShape('rect', { x: 11.1, y: y + 0.16, w: 1.5 * (completedDel / totalDel), h: 0.1, fill: { color: BRAND.emerald500 }, rectRadius: 0.05 });
    }
    y = 1.85;
    pageIdx++;
  };

  startNewPage();

  criteria.forEach((c) => {
    const delRows = Math.ceil(c.deliverables.length / 3);
    // Calculate heights — use full text, no truncation
    const titleH = 0.35;
    const notesTextH = c.notes ? Math.max(0.22, estimateTextHeight(c.notes, 8, 10.9)) : 0;
    const delHeaderH = c.deliverables.length > 0 ? 0.2 : 0;
    const delContentH = delRows > 0 ? delRows * 0.22 : 0;
    const rowH = titleH + notesTextH + delHeaderH + delContentH + 0.12;

    // Check if we need a new page
    if (y + rowH > SLIDE_H - 0.55) {
      addFooter(s!, oppUrl, slideCounter.current, slideCounter.total);
      slideCounter.current++;
      startNewPage();
    }

    const dotColor = statusDotColor[c.status] || BRAND.gray400;
    const label = statusLabel[c.status] || c.status;
    const sBg = statusBgColor[c.status] || BRAND.gray100;
    const titleColor = statusTitleColorPPTX[c.status] || BRAND.pink;

    // Card background
    s!.addShape('rect', { x: 0.8, y, w: 11.7, h: rowH, fill: { color: BRAND.white }, line: { color: BRAND.gray200, width: 0.75 }, rectRadius: 0.06 });

    // Status dot + full criterion name (no truncation)
    s!.addShape('ellipse', { x: 1.0, y: y + 0.12, w: 0.14, h: 0.14, fill: { color: dotColor } });
    s!.addText(c.criterion, { x: 1.25, y: y + 0.06, w: 9.2, h: 0.26, fontSize: 10.5, bold: true, color: titleColor, fontFace: FONT });

    // Status badge
    s!.addShape('rect', { x: 11.0, y: y + 0.08, w: 1.2, h: 0.22, fill: { color: sBg }, rectRadius: 0.11 });
    s!.addText(label, { x: 11.0, y: y + 0.08, w: 1.2, h: 0.22, fontSize: 8, align: 'center', valign: 'middle', color: dotColor, fontFace: FONT, bold: true });

    let subY = y + titleH;

    // Deliverables count
    if (c.deliverables.length > 0) {
      const compDel = c.deliverables.filter(d => d.is_completed).length;
      s!.addText(`Deliverables ${compDel}/${c.deliverables.length}`, {
        x: 9.5, y: y + 0.06, w: 1.5, h: 0.22, fontSize: 8,
        color: compDel === c.deliverables.length && c.deliverables.length > 0 ? BRAND.emerald700 : BRAND.gray400, fontFace: FONT, bold: true, align: 'right',
      });
    }

    // Full notes text (no truncation)
    if (c.notes) {
      s!.addText(c.notes, { x: 1.25, y: subY, w: 10.9, h: notesTextH, fontSize: 8, color: BRAND.gray500, fontFace: FONT, valign: 'top', lineSpacingMultiple: 1.2 });
      subY += notesTextH;
    }

    // All deliverables in 3-column grid — full titles
    if (c.deliverables.length > 0) {
      subY += 0.04;
      c.deliverables.forEach((d, di) => {
        const col = di % 3;
        const row = Math.floor(di / 3);
        const dx = 1.25 + col * 3.5;
        const dy = subY + row * 0.22;

        const checkColor = d.is_completed ? BRAND.emerald500 : BRAND.gray200;
        s!.addShape('rect', { x: dx, y: dy + 0.02, w: 0.12, h: 0.12, fill: { color: d.is_completed ? BRAND.emerald500 : BRAND.white }, line: { color: checkColor, width: 0.5 }, rectRadius: 0.02 });
        if (d.is_completed) {
          s!.addText('✓', { x: dx, y: dy, w: 0.12, h: 0.15, fontSize: 6.5, align: 'center', valign: 'middle', color: BRAND.white, fontFace: FONT });
        }
        // Full title, no truncation
        s!.addText(d.title, { x: dx + 0.16, y: dy, w: 3.1, h: 0.2, fontSize: 7.5, color: d.is_completed ? BRAND.gray400 : BRAND.gray600, fontFace: FONT, valign: 'middle' });
      });
    }

    y += rowH + 0.08;
  });

  addFooter(s!, oppUrl, slideCounter.current, slideCounter.total);
  slideCounter.current++;
}

// ─── Slide 5: Technical Readiness (full Q&A table, paginated) ───────────────

function buildSlideReadiness(pptx: PptxGenJS, data: EvaluationDeckData, oppUrl: string, slideCounter: { current: number; total: number }) {
  const r = data.readiness;

  if (!r) {
    const s = pptx.addSlide();
    addGradientHeader(s, 'Technical Readiness', data.accountName, 1.0);
    s.addText('No readiness data available', { x: 2, y: 3, w: 9, h: 1, fontSize: 20, color: BRAND.gray400, align: 'center', fontFace: FONT });
    addFooter(s, oppUrl, slideCounter.current, slideCounter.total);
    slideCounter.current++;
    return;
  }

  // Group by category
  const byCategory: Record<string, ReadinessQuestionDetail[]> = {};
  (r.questions || []).forEach(q => {
    const cat = q.categoryName || 'General';
    if (!byCategory[cat]) byCategory[cat] = [];
    byCategory[cat].push(q);
  });
  const categories = Object.entries(byCategory);

  const flagColors: Record<string, { bg: string; dot: string }> = {
    green: { bg: BRAND.green50, dot: BRAND.green500 },
    amber: { bg: 'FFFBEB', dot: BRAND.amber500 },
    red: { bg: BRAND.red50, dot: BRAND.red500 },
  };

  let pageIdx = 0;
  let s: PptxGenJS.Slide | null = null;
  let y = 0;

  const CONTENT_Y_START = 1.72;
  const CONTENT_BOTTOM = SLIDE_H - 0.55;
  const NUM_COLS = 3;
  const colWidth = 3.85;
  const colGap = 0.2;

  const addReadinessHeader = () => {
    s = pptx.addSlide();
    const continued = pageIdx > 0;
    addGradientHeader(s, `Technical Readiness${continued ? ' (continued)' : ''}`, data.accountName, 1.0);

    // Score bar
    y = 1.15;
    s.addShape('rect', { x: 0, y, w: '100%', h: 0.45, fill: { color: BRAND.gray50 }, line: { color: BRAND.gray200, width: 0.5 } });
    const scoreColor = r.score >= 70 ? BRAND.green500 : r.score >= 40 ? BRAND.amber500 : BRAND.red500;
    s.addText(`${r.score}%`, { x: 0.5, y: y + 0.02, w: 0.8, h: 0.4, fontSize: 22, bold: true, color: scoreColor, fontFace: FONT, valign: 'middle' });
    s.addText(`${r.answered}/${r.total} answered${r.excluded > 0 ? ` · ${r.excluded} excluded` : ''}`, {
      x: 1.35, y: y + 0.02, w: 3, h: 0.4, fontSize: 9, color: BRAND.gray500, fontFace: FONT, valign: 'middle',
    });
    
    // Category name if applicable
    if (categories.length > 0) {
      const catNames = categories.map(([n]) => n).join(' & ');
      s.addText(catNames.toUpperCase(), { x: 4.5, y: y + 0.02, w: 4, h: 0.4, fontSize: 9, bold: true, color: BRAND.gray700, fontFace: FONT, valign: 'middle', align: 'center' });
    }
    
    const flags = [
      { color: BRAND.green500, label: `${r.greenCount} Green` },
      { color: BRAND.amber500, label: `${r.amberCount} Amber` },
      { color: BRAND.red500, label: `${r.redCount} Red` },
    ];
    flags.forEach((f, i) => {
      const fx = 9 + i * 1.4;
      s!.addShape('ellipse', { x: fx, y: y + 0.17, w: 0.11, h: 0.11, fill: { color: f.color } });
      s!.addText(f.label, { x: fx + 0.16, y: y + 0.08, w: 1.1, h: 0.3, fontSize: 8, color: BRAND.gray700, fontFace: FONT, bold: true, valign: 'middle' });
    });

    y = CONTENT_Y_START;
    pageIdx++;
  };

  // Build items list with height estimates
  type QItem = { type: 'header'; name: string; h: number } | { type: 'question'; q: ReadinessQuestionDetail; idx: number; h: number };
  const allItems: QItem[] = [];
  categories.forEach(([name, qs]) => {
    allItems.push({ type: 'header', name, h: 0.26 });
    qs.forEach((q, idx) => {
      // Estimate height based on answer length
      const hasAnswer = !!q.answer;
      let qH = 0.24; // question text height
      if (hasAnswer) {
        const answerH = estimateTextHeight(q.answer!, 7, colWidth - 0.3);
        qH += Math.min(answerH, 0.8); // cap individual answer height to prevent overflow
      }
      qH += 0.04; // padding
      allItems.push({ type: 'question', q, idx, h: qH });
    });
  });

  // Distribute items across columns, paginating when needed
  addReadinessHeader();
  
  // Simple approach: render items in 3 columns, paginate when columns overflow
  const columnItems: QItem[][] = [[], [], []];
  const columnHeights = [0, 0, 0];
  const availableH = CONTENT_BOTTOM - CONTENT_Y_START;

  let currentCol = 0;
  for (const item of allItems) {
    // If item doesn't fit in current column, move to next
    if (columnHeights[currentCol] + item.h > availableH && columnHeights[currentCol] > 0) {
      currentCol++;
      if (currentCol >= NUM_COLS) {
        // Render current page
        renderReadinessColumns(s!, columnItems, CONTENT_Y_START, colWidth, colGap, flagColors);
        addFooter(s!, oppUrl, slideCounter.current, slideCounter.total);
        slideCounter.current++;
        addReadinessHeader();
        // Reset columns
        for (let c = 0; c < NUM_COLS; c++) { columnItems[c] = []; columnHeights[c] = 0; }
        currentCol = 0;
      }
    }
    columnItems[currentCol].push(item);
    columnHeights[currentCol] += item.h;
  }

  // Render final page
  renderReadinessColumns(s!, columnItems, CONTENT_Y_START, colWidth, colGap, flagColors);
  addFooter(s!, oppUrl, slideCounter.current, slideCounter.total);
  slideCounter.current++;
}

function renderReadinessColumns(
  s: PptxGenJS.Slide,
  columns: Array<Array<{ type: string; name?: string; q?: ReadinessQuestionDetail; idx?: number; h: number }>>,
  startY: number,
  colWidth: number,
  colGap: number,
  flagColors: Record<string, { bg: string; dot: string }>
) {
  columns.forEach((colItems, ci) => {
    const cx = 0.4 + ci * (colWidth + colGap);
    let qy = startY;

    colItems.forEach(item => {
      if (item.type === 'header') {
        s.addText((item.name || '').toUpperCase(), { x: cx, y: qy, w: colWidth, h: 0.22, fontSize: 7.5, bold: true, color: BRAND.gray700, fontFace: FONT, valign: 'middle' });
        qy += 0.26;
      } else if (item.q) {
        const fc = flagColors[item.q.flagType] || flagColors.red;
        const rowBg = (item.idx || 0) % 2 === 0 ? fc.bg : BRAND.white;
        const rowH = item.h - 0.04;

        s.addShape('rect', { x: cx, y: qy, w: colWidth, h: rowH, fill: { color: rowBg }, line: { color: BRAND.gray200, width: 0.25 } });
        s.addShape('ellipse', { x: cx + 0.08, y: qy + 0.06, w: 0.1, h: 0.1, fill: { color: fc.dot } });
        
        // Full question text
        s.addText(item.q.questionText, { x: cx + 0.22, y: qy + 0.01, w: colWidth - 0.3, h: 0.18, fontSize: 7, bold: true, color: BRAND.gray800, fontFace: FONT });
        
        // Full answer text (no truncation)
        if (item.q.answer) {
          const answerH = rowH - 0.2;
          s.addText(item.q.answer, { x: cx + 0.22, y: qy + 0.18, w: colWidth - 0.3, h: answerH, fontSize: 6.5, color: BRAND.gray500, fontFace: FONT, valign: 'top', lineSpacingMultiple: 1.15 });
        }
        qy += item.h;
      }
    });
  });
}

// ─── Slide 6: Timeline ───────────────────────────────────────────────────────

const phaseColorsPPTX: Record<string, { bg: string; border: string; text: string }> = {
  'Value Discovery': { bg: BRAND.orange50, border: BRAND.orange200, text: BRAND.orange700 },
  'Eval Planning': { bg: BRAND.yellow50, border: BRAND.yellow200, text: BRAND.yellow700 },
  'Eval Deployment': { bg: BRAND.teal50, border: BRAND.teal200, text: BRAND.teal700 },
  'Eval Workshops': { bg: BRAND.rose50, border: BRAND.rose200, text: BRAND.rose700 },
  'Conclusion': { bg: BRAND.blue50, border: '93C5FD', text: '1D4ED8' },
  'Procurement & Contracting': { bg: 'FFFBEB', border: 'FCD34D', text: '92400E' },
  'Go Live & Value Realization': { bg: BRAND.green50, border: '86EFAC', text: '166534' },
};

const statusIcons: Record<string, string> = {
  completed: '✅', in_progress: '▶', scheduled: '📅', not_scheduled: '○', skipped: '⏭',
};

function buildSlideTimeline(pptx: PptxGenJS, data: EvaluationDeckData, oppUrl: string) {
  const s = pptx.addSlide();
  addGradientHeader(s, 'Mutual Action Plan Timeline', data.accountName, 1.15);

  const grouped: Record<string, typeof data.milestones> = {};
  data.milestones.forEach(m => { if (!grouped[m.phase]) grouped[m.phase] = []; grouped[m.phase].push(m); });

  let y = 1.35;

  Object.entries(grouped).forEach(([phase, items]) => {
    if (y + 0.7 > SLIDE_H - 0.55) return; // safety overflow
    const colors = phaseColorsPPTX[phase] || phaseColorsPPTX['Conclusion'];
    const completed = items.filter(m => m.status === 'completed').length;

    // Phase header with left border
    s.addShape('rect', { x: 0.8, y, w: 11.7, h: 0.35, fill: { color: colors.bg }, rectRadius: 0.05 });
    s.addShape('rect', { x: 0.8, y, w: 0.06, h: 0.35, fill: { color: colors.border } });
    s.addText(phase, { x: 1.0, y, w: 8, h: 0.35, fontSize: 12, bold: true, color: colors.text, fontFace: FONT, valign: 'middle' });
    s.addText(`${completed} / ${items.length}`, { x: 10.5, y, w: 2, h: 0.35, fontSize: 10, color: colors.text, fontFace: FONT, align: 'right', valign: 'middle', bold: true });
    y += 0.42;

    // Milestone items in 2-column grid
    items.slice(0, 4).forEach((m, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const mx = 1.1 + col * 5.9;
      const my = y + row * 0.35;
      const icon = statusIcons[m.status] || '○';
      const dateStr = m.scheduled_date ? format(new Date(m.scheduled_date), 'MMM d') : '';

      s.addShape('rect', { x: mx, y: my, w: 5.6, h: 0.3, fill: { color: BRAND.white }, line: { color: BRAND.gray100, width: 0.5 }, rectRadius: 0.04 });
      s.addText(`${icon}  ${m.name}`, { x: mx + 0.1, y: my, w: 4, h: 0.3, fontSize: 10, color: BRAND.gray800, fontFace: FONT, valign: 'middle' });
      s.addText(dateStr, { x: mx + 4.2, y: my, w: 1.3, h: 0.3, fontSize: 8.5, color: BRAND.gray400, fontFace: FONT, align: 'right', valign: 'middle' });
    });
    y += Math.ceil(Math.min(items.length, 4) / 2) * 0.35 + 0.15;
  });

  addFooter(s, oppUrl, 6, 8);
}

// ─── Slide 7: Validation Tasks ───────────────────────────────────────────────

function buildSlideValidationTasks(pptx: PptxGenJS, data: EvaluationDeckData, oppUrl: string) {
  const s = pptx.addSlide();
  addGradientHeader(s, 'Validation Tasks', data.accountName, 1.15);

  const tasks = data.validationTasks;
  const completed = tasks.filter(t => t.status === 'completed').length;
  const inProgress = tasks.filter(t => t.status === 'in_progress').length;
  const blocked = tasks.filter(t => t.status === 'blocked').length;

  // KPI cards
  const kpis = [
    { label: 'Total Tasks', value: tasks.length, color: '1E293B' },
    { label: 'Completed', value: completed, color: BRAND.green500 },
    { label: 'In Progress', value: inProgress, color: BRAND.amber500 },
    { label: 'Blocked', value: blocked, color: BRAND.red500 },
  ];
  kpis.forEach((kpi, i) => {
    const x = 0.8 + i * 3;
    s.addShape('rect', { x, y: 1.4, w: 2.7, h: 1.2, fill: { color: BRAND.white }, line: { color: BRAND.gray200, width: 0.75 }, rectRadius: 0.08 });
    s.addText(String(kpi.value), { x, y: 1.45, w: 2.7, h: 0.7, fontSize: 28, bold: true, color: kpi.color, align: 'center', fontFace: FONT });
    s.addText(kpi.label, { x, y: 2.15, w: 2.7, h: 0.35, fontSize: 10, color: BRAND.gray500, align: 'center', fontFace: FONT });
  });

  // Progress bar
  let y = 2.9;
  s.addText('Overall Progress', { x: 0.8, y, w: 6, h: 0.3, fontSize: 12, bold: true, color: BRAND.gray700, fontFace: FONT });
  s.addText(`${completed} of ${tasks.length} completed`, { x: 7, y, w: 5.5, h: 0.3, fontSize: 10, color: BRAND.gray500, fontFace: FONT, align: 'right' });
  y += 0.35;
  s.addShape('rect', { x: 0.8, y, w: 11.7, h: 0.18, fill: { color: BRAND.gray100 }, rectRadius: 0.09 });
  if (tasks.length > 0) {
    s.addShape('rect', { x: 0.8, y, w: 11.7 * (completed / tasks.length), h: 0.18, fill: { color: BRAND.emerald500 }, rectRadius: 0.09 });
  }
  y += 0.5;

  // Module breakdown in 2-column grid — show ALL modules
  const grouped: Record<string, typeof tasks> = {};
  tasks.forEach(t => { if (!grouped[t.module]) grouped[t.module] = []; grouped[t.module].push(t); });

  const modules = Object.entries(grouped);
  modules.forEach(([module, moduleTasks], i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const mx = 0.8 + col * 6.1;
    const my = y + row * 0.85;
    
    if (my + 0.7 > SLIDE_H - 0.55) return; // safety overflow
    
    const moduleCompleted = moduleTasks.filter(t => t.status === 'completed').length;

    // Group by sub-category within module
    const subGroups: Record<string, number[]> = {};
    moduleTasks.forEach(t => {
      const sub = (t as any).category || module;
      if (!subGroups[sub]) subGroups[sub] = [0, 0];
      subGroups[sub][1]++;
      if (t.status === 'completed') subGroups[sub][0]++;
    });

    s.addShape('rect', { x: mx, y: my, w: 5.8, h: 0.7, fill: { color: BRAND.gray50 }, line: { color: BRAND.gray100, width: 0.5 }, rectRadius: 0.08 });
    s.addText(module, { x: mx + 0.2, y: my + 0.05, w: 4, h: 0.3, fontSize: 11, bold: true, color: BRAND.gray800, fontFace: FONT });
    s.addText(`${moduleCompleted}/${moduleTasks.length}`, { x: mx + 4.3, y: my + 0.05, w: 1.3, h: 0.3, fontSize: 9, color: BRAND.gray400, fontFace: FONT, align: 'right' });
    // Mini progress bar
    s.addShape('rect', { x: mx + 0.2, y: my + 0.45, w: 5.4, h: 0.1, fill: { color: BRAND.gray200 }, rectRadius: 0.05 });
    if (moduleTasks.length > 0) {
      s.addShape('rect', { x: mx + 0.2, y: my + 0.45, w: 5.4 * (moduleCompleted / moduleTasks.length), h: 0.1, fill: { color: BRAND.emerald500 }, rectRadius: 0.05 });
    }
  });

  addFooter(s, oppUrl, 7, 8);
}

// ─── Slide 8: Risks & Issues ─────────────────────────────────────────────────

function buildSlideRisks(pptx: PptxGenJS, data: EvaluationDeckData, oppUrl: string) {
  const s = pptx.addSlide();
  addGradientHeader(s, 'Risks & Issues', `${data.accountName} — ${data.risks.length} logged`, 1.15);

  if (data.risks.length === 0) {
    s.addShape('ellipse', { x: 6.0, y: 2.8, w: 1.0, h: 1.0, fill: { color: BRAND.gray100 } });
    s.addText('🛡️', { x: 6.0, y: 2.8, w: 1.0, h: 1.0, fontSize: 24, align: 'center', valign: 'middle', fontFace: FONT });
    s.addText('No risks or issues logged yet', { x: 3, y: 4.0, w: 7, h: 0.5, fontSize: 18, color: BRAND.gray400, align: 'center', fontFace: FONT });
    addFooter(s, oppUrl, 8, 8);
    return;
  }

  const severityConfig: Record<string, { bg: string; border: string; text: string; label: string }> = {
    critical: { bg: BRAND.red100, border: 'FECACA', text: '991B1B', label: 'Critical' },
    high: { bg: BRAND.orange50, border: 'FED7AA', text: '9A3412', label: 'High' },
    medium: { bg: 'FFFBEB', border: 'FDE68A', text: '92400E', label: 'Medium' },
    low: { bg: BRAND.blue50, border: 'BFDBFE', text: '1E40AF', label: 'Low' },
  };
  const statusLabels: Record<string, string> = {
    new: 'New', in_review: 'In Review', awaiting_feedback: 'Awaiting Feedback',
    mitigated: 'Mitigated', accepted: 'Accepted', closed: 'Closed',
  };

  let y = 1.4;
  data.risks.slice(0, 6).forEach((risk) => {
    const sev = severityConfig[risk.severity] || severityConfig.medium;
    const hasMitigation = !!risk.mitigation_plan;
    const hasOwner = !!risk.owner_email;
    const rowH = 0.6 + (hasMitigation ? 0.25 : 0) + (hasOwner ? 0.2 : 0);

    s.addShape('rect', { x: 0.8, y, w: 11.7, h: rowH, fill: { color: sev.bg }, line: { color: sev.border, width: 0.75 }, rectRadius: 0.08 });

    // Risk description
    s.addText(risk.risk_description, { x: 1.0, y: y + 0.1, w: 9, h: 0.3, fontSize: 12, bold: true, color: BRAND.gray800, fontFace: FONT });

    // Severity badge
    s.addShape('rect', { x: 10.5, y: y + 0.1, w: 0.8, h: 0.25, fill: { color: sev.text + '20' }, rectRadius: 0.04 });
    s.addText(sev.label, { x: 10.5, y: y + 0.1, w: 0.8, h: 0.25, fontSize: 8.5, align: 'center', valign: 'middle', color: sev.text, fontFace: FONT, bold: true });

    // Status badge
    s.addShape('rect', { x: 11.4, y: y + 0.1, w: 0.9, h: 0.25, fill: { color: BRAND.gray100 }, rectRadius: 0.04 });
    s.addText(statusLabels[risk.status] || risk.status, { x: 11.4, y: y + 0.1, w: 0.9, h: 0.25, fontSize: 8, align: 'center', valign: 'middle', color: BRAND.gray600, fontFace: FONT });

    let subY = y + 0.42;
    if (hasMitigation) {
      s.addText([
        { text: 'Mitigation: ', options: { bold: true, fontSize: 10, color: BRAND.gray600 } },
        { text: risk.mitigation_plan!, options: { fontSize: 10, color: BRAND.gray600 } },
      ], { x: 1.0, y: subY, w: 11.3, h: 0.22, fontFace: FONT });
      subY += 0.25;
    }
    if (hasOwner) {
      s.addText(`Owner: ${risk.owner_email}`, { x: 1.0, y: subY, w: 5, h: 0.18, fontSize: 9, color: BRAND.gray400, fontFace: FONT });
    }

    y += rowH + 0.15;
  });

  addFooter(s, oppUrl, 8, 8);
}

// ─── Main export function ────────────────────────────────────────────────────

function estimateTotalSlides(data: EvaluationDeckData): number {
  let total = 3; // overview, themes, use cases

  // Estimate criteria pages
  const criteria = data.successCriteria;
  let critHeight = 0;
  let critPages = 1;
  criteria.forEach(c => {
    const notesH = c.notes ? Math.max(0.22, estimateTextHeight(c.notes, 8, 10.9)) : 0;
    const delRows = Math.ceil(c.deliverables.length / 3);
    const rowH = 0.35 + notesH + (c.deliverables.length > 0 ? 0.2 : 0) + (delRows > 0 ? delRows * 0.22 : 0) + 0.12;
    critHeight += rowH + 0.08;
    if (critHeight > 4.8) { critPages++; critHeight = rowH; }
  });
  total += critPages;

  // Readiness pages estimate
  const readinessQs = data.readiness?.questions?.length || 0;
  total += Math.max(1, Math.ceil(readinessQs / 24)); // ~8 per column, 3 columns

  total += 3; // timeline, validation tasks, risks
  return total;
}

export async function generateEvaluationPPTX(data: EvaluationDeckData, oppUrl: string) {
  const pptx = new PptxGenJS();
  pptx.layout = 'LAYOUT_WIDE';
  pptx.author = 'Pendo Compass';
  pptx.title = `${data.accountName} - Evaluation Deck`;

  const totalSlides = estimateTotalSlides(data);
  const slideCounter = { current: 1, total: totalSlides };

  // Fixed slides 1-3
  buildSlideOverview(pptx, data, oppUrl);
  buildSlideStrategicThemes(pptx, data, oppUrl);
  buildSlideUseCases(pptx, data, oppUrl);
  slideCounter.current = 4;

  // Paginated slides
  buildSlideSuccessCriteria(pptx, data, oppUrl, slideCounter);
  buildSlideReadiness(pptx, data, oppUrl, slideCounter);

  // Remaining fixed slides
  buildSlideTimeline(pptx, data, oppUrl);
  buildSlideValidationTasks(pptx, data, oppUrl);
  buildSlideRisks(pptx, data, oppUrl);

  await pptx.writeFile({ fileName: `${data.accountName} - Evaluation Deck.pptx` });
}

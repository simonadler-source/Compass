import ExcelJS from 'exceljs';
import { format } from 'date-fns';

// Brand colors
const COLORS = {
  primary: 'FF3B82F6',      // Blue
  primaryLight: 'FFDBEAFE', // Light blue
  success: 'FF16A34A',      // Green
  successLight: 'FFDCFCE7', // Light green
  warning: 'FFF59E0B',      // Amber
  warningLight: 'FFFEF3C7', // Light amber
  danger: 'FFDC2626',       // Red
  dangerLight: 'FFFEE2E2',  // Light red
  gray: 'FF6B7280',
  grayLight: 'FFF3F4F6',
  white: 'FFFFFFFF',
  black: 'FF111827',
};

// Shared styles
const headerStyle: Partial<ExcelJS.Style> = {
  font: { bold: true, color: { argb: COLORS.white }, size: 11 },
  fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.primary } },
  alignment: { vertical: 'middle', horizontal: 'center', wrapText: true },
  border: {
    top: { style: 'thin', color: { argb: COLORS.gray } },
    bottom: { style: 'thin', color: { argb: COLORS.gray } },
    left: { style: 'thin', color: { argb: COLORS.gray } },
    right: { style: 'thin', color: { argb: COLORS.gray } },
  },
};

const cellStyle: Partial<ExcelJS.Style> = {
  alignment: { vertical: 'middle', wrapText: true },
  border: {
    top: { style: 'thin', color: { argb: 'FFE5E7EB' } },
    bottom: { style: 'thin', color: { argb: 'FFE5E7EB' } },
    left: { style: 'thin', color: { argb: 'FFE5E7EB' } },
    right: { style: 'thin', color: { argb: 'FFE5E7EB' } },
  },
};

const sectionHeaderStyle: Partial<ExcelJS.Style> = {
  font: { bold: true, size: 14, color: { argb: COLORS.primary } },
  alignment: { vertical: 'middle' },
};

interface MAPExportData {
  accountName: string;
  accountId: string;
  industry?: string;
  stage?: string;
  technologies: any[];
  useCases: any[];
  milestones: any[];
  milestoneTemplates: any[];
  validationTasks: any[];
  validationTemplates: any[];
  readinessCategories: any[];
  readinessAnswers: any[];
  teamMembers: any[];
  contacts: any[];
  opportunities: any[];
}

export async function exportMAPToExcel(data: MAPExportData): Promise<void> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Pendo SE Platform';
  workbook.created = new Date();

  // Create all sheets
  createCoverSheet(workbook, data);
  createExecutiveSummarySheet(workbook, data);
  createTeamSheet(workbook, data);
  createUseCasesSheet(workbook, data);
  createArchitectureSheet(workbook, data);
  createMilestonesSheet(workbook, data);
  createValidationTasksSheet(workbook, data);
  createTechnicalReadinessSheet(workbook, data);

  // Generate and download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${data.accountName.replace(/\s+/g, '_')}_Mutual_Activity_Plan.xlsx`;
  link.click();
  URL.revokeObjectURL(url);
}

function createCoverSheet(workbook: ExcelJS.Workbook, data: MAPExportData) {
  const sheet = workbook.addWorksheet('Cover', { properties: { tabColor: { argb: COLORS.primary } } });
  sheet.columns = [{ width: 60 }];

  // Title
  sheet.mergeCells('A3:A3');
  const titleCell = sheet.getCell('A3');
  titleCell.value = 'MUTUAL ACTIVITY PLAN';
  titleCell.font = { bold: true, size: 28, color: { argb: COLORS.primary } };
  titleCell.alignment = { horizontal: 'center' };

  // Account name
  sheet.mergeCells('A5:A5');
  const accountCell = sheet.getCell('A5');
  accountCell.value = data.accountName;
  accountCell.font = { bold: true, size: 20, color: { argb: COLORS.black } };
  accountCell.alignment = { horizontal: 'center' };

  // Industry
  if (data.industry) {
    sheet.mergeCells('A7:A7');
    const industryCell = sheet.getCell('A7');
    industryCell.value = data.industry;
    industryCell.font = { size: 14, color: { argb: COLORS.gray } };
    industryCell.alignment = { horizontal: 'center' };
  }

  // Date
  sheet.mergeCells('A10:A10');
  const dateCell = sheet.getCell('A10');
  dateCell.value = `Generated: ${format(new Date(), 'MMMM d, yyyy')}`;
  dateCell.font = { size: 12, color: { argb: COLORS.gray } };
  dateCell.alignment = { horizontal: 'center' };

  // Confidential notice
  sheet.mergeCells('A15:A15');
  const confCell = sheet.getCell('A15');
  confCell.value = 'CONFIDENTIAL';
  confCell.font = { bold: true, size: 10, color: { argb: COLORS.danger } };
  confCell.alignment = { horizontal: 'center' };
}

function createExecutiveSummarySheet(workbook: ExcelJS.Workbook, data: MAPExportData) {
  const sheet = workbook.addWorksheet('Executive Summary', { properties: { tabColor: { argb: COLORS.primary } } });
  sheet.columns = [
    { header: 'Metric', key: 'metric', width: 30 },
    { header: 'Value', key: 'value', width: 40 },
  ];

  // Header
  addSectionHeader(sheet, 'A1', 'Executive Summary');

  // Stats
  const stats = [
    ['Account', data.accountName],
    ['Industry', data.industry || 'Not specified'],
    ['Stage', data.stage || 'Not specified'],
    ['Use Cases Identified', data.useCases.length.toString()],
    ['Technologies Mapped', data.technologies.length.toString()],
    ['Milestones Planned', data.milestones.length.toString()],
    ['Team Members', data.teamMembers.length.toString()],
    ['Stakeholders', data.contacts.length.toString()],
  ];

  let row = 3;
  stats.forEach(([metric, value]) => {
    sheet.getCell(`A${row}`).value = metric;
    sheet.getCell(`A${row}`).font = { bold: true };
    sheet.getCell(`B${row}`).value = value;
    applyBorder(sheet, `A${row}:B${row}`);
    row++;
  });

  // Freeze header
  sheet.views = [{ state: 'frozen', ySplit: 2 }];
}

function createTeamSheet(workbook: ExcelJS.Workbook, data: MAPExportData) {
  const sheet = workbook.addWorksheet('Team', { properties: { tabColor: { argb: COLORS.success } } });
  
  // Internal Team Section
  addSectionHeader(sheet, 'A1', 'Internal Team');
  
  const internalHeaders = ['Email', 'Role', 'Added From'];
  sheet.getRow(3).values = ['', ...internalHeaders];
  styleHeaderRow(sheet, 3, 2, internalHeaders.length + 1);

  let row = 4;
  data.teamMembers.forEach((member, idx) => {
    sheet.getCell(`A${row}`).value = idx + 1;
    sheet.getCell(`B${row}`).value = member.team_member_email || 'N/A';
    sheet.getCell(`C${row}`).value = member.role || 'Team Member';
    sheet.getCell(`D${row}`).value = member.added_from_meeting_id ? 'Meeting' : 'Manual';
    applyBorder(sheet, `A${row}:D${row}`);
    row++;
  });

  // External Stakeholders Section
  row += 2;
  addSectionHeader(sheet, `A${row}`, 'External Stakeholders');
  row += 2;

  const externalHeaders = ['Name', 'Role', 'Type', 'Influence', 'Sentiment', 'Champion Score'];
  sheet.getRow(row).values = ['', ...externalHeaders];
  styleHeaderRow(sheet, row, 2, externalHeaders.length + 1);
  row++;

  data.contacts.forEach((contact, idx) => {
    sheet.getCell(`A${row}`).value = idx + 1;
    sheet.getCell(`B${row}`).value = contact.name || 'Unknown';
    sheet.getCell(`C${row}`).value = contact.role || 'N/A';
    sheet.getCell(`D${row}`).value = contact.stakeholder_type || 'N/A';
    sheet.getCell(`E${row}`).value = contact.influence_level ?? 'N/A';
    sheet.getCell(`F${row}`).value = contact.sentiment ?? 'N/A';
    sheet.getCell(`G${row}`).value = contact.champion_score ?? 'N/A';
    applyBorder(sheet, `A${row}:G${row}`);
    row++;
  });

  // Set column widths
  sheet.columns = [
    { width: 5 },
    { width: 35 },
    { width: 25 },
    { width: 20 },
    { width: 12 },
    { width: 12 },
    { width: 15 },
  ];

  sheet.views = [{ state: 'frozen', ySplit: 3 }];
}

function createUseCasesSheet(workbook: ExcelJS.Workbook, data: MAPExportData) {
  const sheet = workbook.addWorksheet('Use Cases', { properties: { tabColor: { argb: COLORS.warning } } });
  
  addSectionHeader(sheet, 'A1', 'Use Cases');

  const headers = ['Use Case', 'Business Theme', 'Functional Area', 'Priority', 'Status', 'Acceptance Status'];
  sheet.getRow(3).values = ['#', ...headers];
  styleHeaderRow(sheet, 3, 1, headers.length + 1);

  let row = 4;
  data.useCases.forEach((uc, idx) => {
    sheet.getCell(`A${row}`).value = idx + 1;
    sheet.getCell(`B${row}`).value = uc.use_case || uc.description || 'N/A';
    sheet.getCell(`C${row}`).value = uc.business_theme || 'Not categorized';
    sheet.getCell(`D${row}`).value = uc.functional_area || 'N/A';
    sheet.getCell(`E${row}`).value = uc.priority || 'Medium';
    sheet.getCell(`F${row}`).value = uc.status || 'Identified';
    sheet.getCell(`G${row}`).value = uc.acceptance_status || 'Pending';
    
    // Priority conditional formatting
    const priorityCell = sheet.getCell(`E${row}`);
    if (uc.priority === 'high') {
      priorityCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.dangerLight } };
      priorityCell.font = { color: { argb: COLORS.danger } };
    } else if (uc.priority === 'low') {
      priorityCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.successLight } };
      priorityCell.font = { color: { argb: COLORS.success } };
    }
    
    applyBorder(sheet, `A${row}:G${row}`);
    row++;
  });

  // Summary row with formula
  row += 1;
  sheet.getCell(`A${row}`).value = 'Summary';
  sheet.getCell(`A${row}`).font = { bold: true };
  sheet.getCell(`B${row}`).value = { formula: `COUNTA(B4:B${row - 2})&" use cases"` };

  sheet.columns = [
    { width: 5 },
    { width: 45 },
    { width: 25 },
    { width: 20 },
    { width: 12 },
    { width: 15 },
    { width: 18 },
  ];

  sheet.views = [{ state: 'frozen', ySplit: 3 }];
  sheet.autoFilter = { from: 'A3', to: `G${row - 2}` };
}

function createArchitectureSheet(workbook: ExcelJS.Workbook, data: MAPExportData) {
  const sheet = workbook.addWorksheet('Architecture', { properties: { tabColor: { argb: COLORS.gray } } });
  
  addSectionHeader(sheet, 'A1', 'Technology Architecture');

  const headers = ['Technology', 'Layer', 'Category', 'Status', 'Priority', 'Owner'];
  sheet.getRow(3).values = ['#', ...headers];
  styleHeaderRow(sheet, 3, 1, headers.length + 1);

  let row = 4;
  
  // Group by layer
  const layers = ['presentation', 'application', 'data', 'infrastructure'];
  layers.forEach(layer => {
    const layerTechs = data.technologies.filter(t => t.layer === layer);
    if (layerTechs.length > 0) {
      // Layer header
      sheet.mergeCells(`A${row}:G${row}`);
      const layerCell = sheet.getCell(`A${row}`);
      layerCell.value = layer.charAt(0).toUpperCase() + layer.slice(1) + ' Layer';
      layerCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.grayLight } };
      layerCell.font = { bold: true, color: { argb: COLORS.black } };
      row++;

      layerTechs.forEach((tech, idx) => {
        sheet.getCell(`A${row}`).value = idx + 1;
        sheet.getCell(`B${row}`).value = tech.name;
        sheet.getCell(`C${row}`).value = tech.layer;
        sheet.getCell(`D${row}`).value = tech.category || 'N/A';
        sheet.getCell(`E${row}`).value = tech.status || 'Active';
        sheet.getCell(`F${row}`).value = tech.priority || 'Medium';
        sheet.getCell(`G${row}`).value = tech.owner_name || 'N/A';
        
        // Status coloring
        const statusCell = sheet.getCell(`E${row}`);
        if (tech.status === 'active' || tech.status === 'current') {
          statusCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.successLight } };
        } else if (tech.status === 'planned' || tech.status === 'future') {
          statusCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.primaryLight } };
        }
        
        applyBorder(sheet, `A${row}:G${row}`);
        row++;
      });
      row++; // Gap between layers
    }
  });

  sheet.columns = [
    { width: 5 },
    { width: 30 },
    { width: 18 },
    { width: 20 },
    { width: 15 },
    { width: 12 },
    { width: 25 },
  ];

  sheet.views = [{ state: 'frozen', ySplit: 3 }];
}

function createMilestonesSheet(workbook: ExcelJS.Workbook, data: MAPExportData) {
  const sheet = workbook.addWorksheet('Milestones', { properties: { tabColor: { argb: COLORS.primary } } });
  
  addSectionHeader(sheet, 'A1', 'Milestones & Timeline');

  const headers = ['Milestone', 'Phase', 'Target Date', 'Actual Date', 'Status', 'Days Remaining', 'Progress'];
  sheet.getRow(3).values = ['#', ...headers];
  styleHeaderRow(sheet, 3, 1, headers.length + 1);

  const milestones = data.milestones.length > 0 ? data.milestones : data.milestoneTemplates.map(t => ({
    name: t.name,
    phase: t.phase,
    target_date: null,
    actual_date: null,
    status: 'pending',
  }));

  let row = 4;
  milestones.forEach((ms, idx) => {
    sheet.getCell(`A${row}`).value = idx + 1;
    sheet.getCell(`B${row}`).value = ms.name;
    sheet.getCell(`C${row}`).value = ms.phase || 'N/A';
    
    const targetCell = sheet.getCell(`D${row}`);
    targetCell.value = ms.target_date ? new Date(ms.target_date) : null;
    targetCell.numFmt = 'MMM DD, YYYY';
    
    const actualCell = sheet.getCell(`E${row}`);
    actualCell.value = ms.actual_date ? new Date(ms.actual_date) : null;
    actualCell.numFmt = 'MMM DD, YYYY';
    
    sheet.getCell(`F${row}`).value = ms.status || 'pending';
    
    // Days remaining formula
    const daysCell = sheet.getCell(`G${row}`);
    daysCell.value = { formula: `IF(D${row}="","",IF(F${row}="completed","✓",D${row}-TODAY()))` };
    
    // Progress bar (using conditional formatting approximation)
    const progressCell = sheet.getCell(`H${row}`);
    if (ms.status === 'completed') {
      progressCell.value = '100%';
      progressCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.successLight } };
    } else if (ms.status === 'in_progress') {
      progressCell.value = '50%';
      progressCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.warningLight } };
    } else {
      progressCell.value = '0%';
    }
    
    // Status conditional formatting
    const statusCell = sheet.getCell(`F${row}`);
    if (ms.status === 'completed') {
      statusCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.successLight } };
      statusCell.font = { color: { argb: COLORS.success } };
    } else if (ms.status === 'in_progress') {
      statusCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.warningLight } };
      statusCell.font = { color: { argb: COLORS.warning } };
    } else if (ms.status === 'blocked' || ms.status === 'at_risk') {
      statusCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.dangerLight } };
      statusCell.font = { color: { argb: COLORS.danger } };
    }
    
    applyBorder(sheet, `A${row}:H${row}`);
    row++;
  });

  // Summary formulas
  row += 2;
  sheet.getCell(`A${row}`).value = 'Progress Summary';
  sheet.getCell(`A${row}`).font = { bold: true, size: 12 };
  row++;
  
  sheet.getCell(`A${row}`).value = 'Total Milestones';
  sheet.getCell(`B${row}`).value = { formula: `COUNTA(B4:B${row - 3})` };
  row++;
  
  sheet.getCell(`A${row}`).value = 'Completed';
  sheet.getCell(`B${row}`).value = { formula: `COUNTIF(F4:F${row - 4},"completed")` };
  row++;
  
  sheet.getCell(`A${row}`).value = 'Completion %';
  sheet.getCell(`B${row}`).value = { formula: `IF(B${row - 2}=0,0,ROUND(B${row - 1}/B${row - 2}*100,1))&"%"` };
  sheet.getCell(`B${row}`).font = { bold: true, size: 14 };

  sheet.columns = [
    { width: 5 },
    { width: 35 },
    { width: 18 },
    { width: 15 },
    { width: 15 },
    { width: 15 },
    { width: 15 },
    { width: 12 },
  ];

  sheet.views = [{ state: 'frozen', ySplit: 3 }];
  sheet.autoFilter = { from: 'A3', to: `H${row - 5}` };
}

function createValidationTasksSheet(workbook: ExcelJS.Workbook, data: MAPExportData) {
  const sheet = workbook.addWorksheet('Validation Tasks', { properties: { tabColor: { argb: COLORS.warning } } });
  
  addSectionHeader(sheet, 'A1', 'Validation Tasks');

  const headers = ['Activity', 'Module', 'Sub-Module', 'Owner', 'Status', 'Completed'];
  sheet.getRow(3).values = ['#', ...headers];
  styleHeaderRow(sheet, 3, 1, headers.length + 1);

  const tasks = data.validationTasks.length > 0 ? data.validationTasks : data.validationTemplates.map(t => ({
    activity: t.activity,
    module: t.module,
    sub_module: t.sub_module,
    owner: t.default_owner,
    status: 'pending',
    completed_at: null,
  }));

  // Group by module
  const modules = [...new Set(tasks.map(t => t.module))];
  let row = 4;

  modules.forEach(module => {
    const moduleTasks = tasks.filter(t => t.module === module);
    
    // Module header
    sheet.mergeCells(`A${row}:G${row}`);
    const moduleCell = sheet.getCell(`A${row}`);
    moduleCell.value = module;
    moduleCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.grayLight } };
    moduleCell.font = { bold: true };
    row++;

    moduleTasks.forEach((task, idx) => {
      sheet.getCell(`A${row}`).value = idx + 1;
      sheet.getCell(`B${row}`).value = task.activity;
      sheet.getCell(`C${row}`).value = task.module;
      sheet.getCell(`D${row}`).value = task.sub_module || 'N/A';
      sheet.getCell(`E${row}`).value = task.owner || 'Unassigned';
      sheet.getCell(`F${row}`).value = task.status || 'pending';
      
      const completedCell = sheet.getCell(`G${row}`);
      completedCell.value = task.completed_at ? new Date(task.completed_at) : null;
      completedCell.numFmt = 'MMM DD, YYYY';
      
      // Status coloring
      const statusCell = sheet.getCell(`F${row}`);
      if (task.status === 'completed') {
        statusCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.successLight } };
        statusCell.font = { color: { argb: COLORS.success } };
      } else if (task.status === 'in_progress') {
        statusCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.warningLight } };
      } else if (task.status === 'blocked') {
        statusCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.dangerLight } };
        statusCell.font = { color: { argb: COLORS.danger } };
      }
      
      applyBorder(sheet, `A${row}:G${row}`);
      row++;
    });
    row++; // Gap between modules
  });

  // Summary
  const summaryStartRow = row + 1;
  sheet.getCell(`A${summaryStartRow}`).value = 'Task Summary';
  sheet.getCell(`A${summaryStartRow}`).font = { bold: true, size: 12 };
  
  sheet.getCell(`A${summaryStartRow + 1}`).value = 'Total Tasks';
  sheet.getCell(`B${summaryStartRow + 1}`).value = { formula: `COUNTA(B4:B${row - 2})-${modules.length}` };
  
  sheet.getCell(`A${summaryStartRow + 2}`).value = 'Completed';
  sheet.getCell(`B${summaryStartRow + 2}`).value = { formula: `COUNTIF(F4:F${row - 2},"completed")` };
  
  sheet.getCell(`A${summaryStartRow + 3}`).value = 'Completion %';
  sheet.getCell(`B${summaryStartRow + 3}`).value = { formula: `IF(B${summaryStartRow + 1}=0,0,ROUND(B${summaryStartRow + 2}/B${summaryStartRow + 1}*100,1))&"%"` };
  sheet.getCell(`B${summaryStartRow + 3}`).font = { bold: true, size: 14 };

  sheet.columns = [
    { width: 5 },
    { width: 45 },
    { width: 20 },
    { width: 20 },
    { width: 20 },
    { width: 15 },
    { width: 15 },
  ];

  sheet.views = [{ state: 'frozen', ySplit: 3 }];
}

function createTechnicalReadinessSheet(workbook: ExcelJS.Workbook, data: MAPExportData) {
  const sheet = workbook.addWorksheet('Technical Readiness', { properties: { tabColor: { argb: COLORS.danger } } });
  
  addSectionHeader(sheet, 'A1', 'Technical Readiness Assessment');

  const headers = ['Question', 'Answer', 'Confidence', 'Flag Status', 'Source'];
  sheet.getRow(3).values = ['Category', ...headers];
  styleHeaderRow(sheet, 3, 1, headers.length + 1);

  let row = 4;
  let greenCount = 0;
  let amberCount = 0;
  let redCount = 0;

  data.readinessCategories.forEach(category => {
    // Category header
    sheet.mergeCells(`A${row}:F${row}`);
    const catCell = sheet.getCell(`A${row}`);
    catCell.value = category.name;
    catCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.grayLight } };
    catCell.font = { bold: true };
    row++;

    category.questions?.forEach((question: any) => {
      const answer = data.readinessAnswers.find(a => a.question_id === question.id);
      const confidence = answer?.confidence_score ?? null;
      
      // Determine flag status
      let flagStatus = 'Red';
      let flagColor = COLORS.dangerLight;
      let flagFontColor = COLORS.danger;
      
      if (answer?.manual_flag_status) {
        flagStatus = answer.manual_flag_status.charAt(0).toUpperCase() + answer.manual_flag_status.slice(1);
        if (answer.manual_flag_status === 'green') {
          flagColor = COLORS.successLight;
          flagFontColor = COLORS.success;
          greenCount++;
        } else if (answer.manual_flag_status === 'amber') {
          flagColor = COLORS.warningLight;
          flagFontColor = COLORS.warning;
          amberCount++;
        } else {
          redCount++;
        }
      } else if (confidence !== null) {
        if (confidence >= 85) {
          flagStatus = 'Green';
          flagColor = COLORS.successLight;
          flagFontColor = COLORS.success;
          greenCount++;
        } else if (confidence >= 60) {
          flagStatus = 'Amber';
          flagColor = COLORS.warningLight;
          flagFontColor = COLORS.warning;
          amberCount++;
        } else {
          redCount++;
        }
      } else if (answer?.answer) {
        redCount++; // Has answer but no confidence
      } else {
        redCount++; // No answer
      }

      sheet.getCell(`A${row}`).value = '';
      sheet.getCell(`B${row}`).value = question.question;
      sheet.getCell(`C${row}`).value = answer?.answer || '';
      sheet.getCell(`D${row}`).value = confidence !== null ? `${confidence}%` : 'N/A';
      
      const flagCell = sheet.getCell(`E${row}`);
      flagCell.value = flagStatus;
      flagCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: flagColor } };
      flagCell.font = { color: { argb: flagFontColor }, bold: true };
      
      sheet.getCell(`F${row}`).value = answer?.source || 'Not answered';
      
      applyBorder(sheet, `A${row}:F${row}`);
      row++;
    });
    row++; // Gap between categories
  });

  // Summary with RAG counts
  const summaryRow = row + 1;
  sheet.getCell(`A${summaryRow}`).value = 'Readiness Summary';
  sheet.getCell(`A${summaryRow}`).font = { bold: true, size: 12 };
  
  // RAG summary with colors
  sheet.getCell(`A${summaryRow + 1}`).value = 'Green (Validated)';
  sheet.getCell(`B${summaryRow + 1}`).value = greenCount;
  sheet.getCell(`B${summaryRow + 1}`).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.successLight } };
  
  sheet.getCell(`A${summaryRow + 2}`).value = 'Amber (Needs Review)';
  sheet.getCell(`B${summaryRow + 2}`).value = amberCount;
  sheet.getCell(`B${summaryRow + 2}`).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.warningLight } };
  
  sheet.getCell(`A${summaryRow + 3}`).value = 'Red (Gaps)';
  sheet.getCell(`B${summaryRow + 3}`).value = redCount;
  sheet.getCell(`B${summaryRow + 3}`).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.dangerLight } };
  
  // Readiness score formula
  const total = greenCount + amberCount + redCount;
  const weightedDenom = (redCount * 2) + (amberCount * 1.5) + greenCount;
  const score = weightedDenom > 0 ? Math.round(((greenCount * 100) + (amberCount * 50)) / weightedDenom) : 0;
  
  sheet.getCell(`A${summaryRow + 5}`).value = 'Readiness Score';
  sheet.getCell(`A${summaryRow + 5}`).font = { bold: true };
  sheet.getCell(`B${summaryRow + 5}`).value = `${score}%`;
  sheet.getCell(`B${summaryRow + 5}`).font = { bold: true, size: 16 };
  if (score >= 70) {
    sheet.getCell(`B${summaryRow + 5}`).font.color = { argb: COLORS.success };
  } else if (score >= 40) {
    sheet.getCell(`B${summaryRow + 5}`).font.color = { argb: COLORS.warning };
  } else {
    sheet.getCell(`B${summaryRow + 5}`).font.color = { argb: COLORS.danger };
  }

  sheet.columns = [
    { width: 15 },
    { width: 50 },
    { width: 40 },
    { width: 12 },
    { width: 15 },
    { width: 18 },
  ];

  sheet.views = [{ state: 'frozen', ySplit: 3 }];
}

// Helper functions
function addSectionHeader(sheet: ExcelJS.Worksheet, cell: string, text: string) {
  const sectionCell = sheet.getCell(cell);
  sectionCell.value = text;
  sectionCell.font = { bold: true, size: 16, color: { argb: COLORS.primary } };
}

function styleHeaderRow(sheet: ExcelJS.Worksheet, rowNum: number, startCol: number, endCol: number) {
  const row = sheet.getRow(rowNum);
  for (let col = startCol; col <= endCol; col++) {
    const cell = row.getCell(col);
    Object.assign(cell, { style: headerStyle });
  }
  row.height = 25;
}

function applyBorder(sheet: ExcelJS.Worksheet, range: string) {
  const [start, end] = range.split(':');
  const startCell = sheet.getCell(start);
  const endCell = sheet.getCell(end);
  
  const startRow = Number(startCell.row) || 1;
  const endRow = Number(endCell.row) || 1;
  const startCol = Number(startCell.col) || 1;
  const endCol = Number(endCell.col) || 1;
  
  for (let r = startRow; r <= endRow; r++) {
    for (let c = startCol; c <= endCol; c++) {
      const cell = sheet.getCell(r, c);
      cell.border = cellStyle.border;
      if (!cell.alignment) {
        cell.alignment = { vertical: 'middle', wrapText: true };
      }
    }
  }
}

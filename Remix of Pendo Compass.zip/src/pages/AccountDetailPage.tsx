import { useEffect, useState, useCallback, useRef } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Sidebar } from '@/components/layout/Sidebar';
import { AccountDetailView } from '@/components/views/AccountDetailView';

export default function AccountDetailPage() {
  const { accountId } = useParams<{ accountId: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('details');
  
  // Get opportunityId and opportunity tab from URL params if present
  const opportunityIdFromUrl = searchParams.get('opportunityId');
  const opportunityTabFromUrl = searchParams.get('oppTab');

  // Track currently selected opportunity so tab changes can reliably persist it in the URL
  const [selectedOpportunityId, setSelectedOpportunityId] = useState<string>(opportunityIdFromUrl || '');

  const prevAccountIdRef = useRef(accountId);

  // Keep local state in sync if user lands via deep link / back-forward navigation
  useEffect(() => {
    setSelectedOpportunityId(opportunityIdFromUrl || '');
  }, [opportunityIdFromUrl]);

  // Clear stale opportunityId when switching to a different account
  useEffect(() => {
    if (prevAccountIdRef.current !== accountId) {
      prevAccountIdRef.current = accountId;
      // Account changed — clear any leftover opportunity from the previous account
      if (opportunityIdFromUrl) {
        setSearchParams(prev => {
          const newParams = new URLSearchParams(prev);
          newParams.delete('opportunityId');
          newParams.delete('oppTab');
          return newParams;
        }, { replace: true });
      }
      setSelectedOpportunityId('');
      setActiveTab('details');
    }
  }, [accountId, opportunityIdFromUrl, setSearchParams]);

  const handleBack = () => {
    navigate('/accounts');
  };

  // Handler for updating opportunity tab in URL
  const handleOpportunityTabChange = useCallback((tab: string) => {
    setSearchParams(prev => {
      const newParams = new URLSearchParams(prev);

       // If we're inside an opportunity view, ensure the opportunityId is persisted
       if (selectedOpportunityId && !newParams.get('opportunityId')) {
         newParams.set('opportunityId', selectedOpportunityId);
       }

      if (tab && tab !== 'overview') {
        newParams.set('oppTab', tab);
      } else {
        newParams.delete('oppTab');
      }
      return newParams;
    }, { replace: true });
  }, [setSearchParams, selectedOpportunityId]);

  // Handler for persisting selected opportunity in URL (so refresh stays on the Opportunity view)
  const handleOpportunitySelect = useCallback((opportunityId: string | null) => {
    setSelectedOpportunityId(opportunityId || '');
    setSearchParams(prev => {
      const newParams = new URLSearchParams(prev);
      if (opportunityId) {
        newParams.set('opportunityId', opportunityId);
      } else {
        newParams.delete('opportunityId');
        newParams.delete('oppTab');
      }
      return newParams;
    }, { replace: true });
  }, [setSearchParams]);

  if (!accountId) {
    navigate('/accounts');
    return null;
  }

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="flex h-screen bg-background overflow-hidden">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        <Sidebar />
        <main className="flex-1 overflow-auto relative">
          <AccountDetailView
            accountId={accountId}
            activeTab={activeTab}
            onBack={handleBack}
            onTabChange={setActiveTab}
            initialOpportunityId={opportunityIdFromUrl || undefined}
            initialOpportunityTab={opportunityTabFromUrl || undefined}
            onOpportunityTabChange={handleOpportunityTabChange}
            onOpportunitySelect={handleOpportunitySelect}
          />
        </main>
      </div>
    </DndProvider>
  );
}

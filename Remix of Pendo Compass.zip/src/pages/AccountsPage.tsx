import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Sidebar } from '@/components/layout/Sidebar';
import { AccountsView } from '@/components/views/AccountsView';
import { CreateAccountDialog } from '@/components/dialogs/CreateAccountDialog';

export default function AccountsPage() {
  const navigate = useNavigate();
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  const handleSelectAccount = (accountId: string) => {
    navigate(`/accounts/${accountId}`);
  };

  const handleSelectOpportunity = (accountId: string, opportunityId: string) => {
    navigate(`/accounts/${accountId}?opportunityId=${opportunityId}`);
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="flex h-screen bg-background overflow-hidden">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        <Sidebar />
        <main className="flex-1 overflow-auto relative">
          <AccountsView
            onSelectAccount={handleSelectAccount}
            onSelectOpportunity={handleSelectOpportunity}
            onCreateAccount={() => setShowCreateDialog(true)}
          />
        </main>
        <CreateAccountDialog
          open={showCreateDialog}
          onOpenChange={setShowCreateDialog}
          onAccountCreated={(accountId) => navigate(`/accounts/${accountId}`)}
        />
      </div>
    </DndProvider>
  );
}

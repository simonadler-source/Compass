import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CheckCircle2, XCircle, Clock, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ActionConfirmedPage() {
  const [searchParams] = useSearchParams();
  const status = searchParams.get('status') || 'success';
  const title = searchParams.get('title') || 'Action Updated';
  const message = searchParams.get('message') || 'Your action has been updated.';
  const [countdown, setCountdown] = useState(5);

  // Try to close the tab after countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // Try to close - only works if opened via JavaScript
          window.close();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const isSuccess = status === 'success';
  const isError = status === 'error';

  const getIcon = () => {
    if (isSuccess) return <CheckCircle2 className="w-16 h-16 text-green-500" />;
    if (isError) return <XCircle className="w-16 h-16 text-destructive" />;
    return <Clock className="w-16 h-16 text-amber-500" />;
  };

  const handleClose = () => {
    window.close();
    // Fallback: show message if close doesn't work
    setTimeout(() => {
      setCountdown(-1);
    }, 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
        <div className="flex justify-center mb-6">
          {getIcon()}
        </div>
        
        <h1 className="text-2xl font-bold text-slate-900 mb-2">
          {decodeURIComponent(title)}
        </h1>
        
        <p className="text-slate-600 mb-6">
          {decodeURIComponent(message)}
        </p>

        {countdown > 0 && (
          <p className="text-sm text-slate-400 mb-4">
            This tab will try to close in {countdown} second{countdown !== 1 ? 's' : ''}...
          </p>
        )}

        {countdown === 0 && (
          <p className="text-sm text-slate-500 mb-4">
            You can safely close this tab now.
          </p>
        )}

        {countdown === -1 && (
          <p className="text-sm text-amber-600 mb-4">
            Please close this tab manually.
          </p>
        )}

        <Button 
          onClick={handleClose}
          variant="outline"
          className="gap-2"
        >
          <X className="w-4 h-4" />
          Close Tab
        </Button>
      </div>
    </div>
  );
}

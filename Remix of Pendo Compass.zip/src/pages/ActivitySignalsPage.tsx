import { Sidebar } from '@/components/layout/Sidebar';
import { ActivitySignalsView } from '@/components/views/ActivitySignalsView';

export default function ActivitySignalsPage() {
  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          <ActivitySignalsView />
        </div>
      </main>
    </div>
  );
}

import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { lovable } from '@/integrations/lovable/index';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { Shield, Mail, KeyRound, CheckCircle } from 'lucide-react';
import pendoLogo from '@/assets/pendo-logo.png';
import { Setup2FADialog } from '@/components/Setup2FADialog';

const PENDO_EMAIL_DOMAIN = '@pendo.io';

export default function AuthPage() {
  const { signIn, user, loading, tempPassword, getSessionToken } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // MFA (2FA) states
  const [requiresMfa, setRequiresMfa] = useState(false);
  const [totpCode, setTotpCode] = useState('');
  
  // Email verification states
  const [verificationToken, setVerificationToken] = useState<string | null>(null);
  const [verificationSuccess, setVerificationSuccess] = useState(false);
  const [verifying, setVerifying] = useState(false);
  
  // Password reset states
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [resetEmailSent, setResetEmailSent] = useState(false);
  
  // Password reset with token
  const [resetToken, setResetToken] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  // Change password (for temp password users)
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');

  // Registration success
  const [registrationSuccess, setRegistrationSuccess] = useState(false);

  // 2FA Setup flow (shown after email verification for new users)
  const [show2FASetup, setShow2FASetup] = useState(false);
  const [setupSessionToken, setSetupSessionToken] = useState<string | null>(null);

  // Google SSO state
  const [googleLoading, setGoogleLoading] = useState(false);
  const googleCallbackProcessingRef = useRef(false);

  // Handle Google SSO callback - process Supabase auth session from Google redirect
  const handleGoogleCallback = useCallback(async () => {
    // Prevent double processing from both checkGoogleSession and onAuthStateChange
    if (googleCallbackProcessingRef.current) return;
    googleCallbackProcessingRef.current = true;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user?.email) {
        googleCallbackProcessingRef.current = false;
        return;
      }

      setGoogleLoading(true);
      const googleEmail = session.user.email;
      const googleName = session.user.user_metadata?.full_name || session.user.user_metadata?.name || null;

      // Clear any stale custom session token before exchanging for a new one
      localStorage.removeItem('auth_session_token');

      // Retry up to 2 times on transient failures (503, network errors)
      let lastError: any = null;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const { data, error } = await supabase.functions.invoke('auth', {
            body: { action: 'google-login', email: googleEmail, fullName: googleName },
          });

          if (error) {
            const errMsg = error?.message ?? '';
            const isTransient = errMsg.includes('503') || errMsg.includes('SERVICE_UNAVAILABLE') || errMsg.includes('Backend temporarily');
            if (isTransient && attempt < 2) {
              lastError = error;
              await new Promise(r => setTimeout(r, 1500 * (attempt + 1)));
              continue;
            }
            throw new Error(data?.error || error.message || 'Google sign-in failed');
          }

          if (data?.code === 'SERVICE_UNAVAILABLE' && attempt < 2) {
            lastError = new Error(data.error);
            await new Promise(r => setTimeout(r, 1500 * (attempt + 1)));
            continue;
          }

          // Clear Supabase auth session (we use custom sessions)
          await supabase.auth.signOut();

          if (!data?.success) {
            throw new Error(data?.error || 'Google sign-in failed');
          }

          // Store custom session token
          const token = data.session?.token;
          if (token) {
            localStorage.setItem('auth_session_token', token);
            toast.success('Signed in with Google!');
            window.location.href = '/';
          }
          return; // Success - exit retry loop
        } catch (attemptErr: any) {
          lastError = attemptErr;
          if (attempt < 2) {
            await new Promise(r => setTimeout(r, 1500 * (attempt + 1)));
            continue;
          }
        }
      }

      // All retries exhausted
      throw lastError || new Error('Google sign-in failed');
    } catch (err: any) {
      console.error('Google SSO callback error:', err);
      toast.error(err.message || 'Google sign-in failed. Please try again.');
      await supabase.auth.signOut().catch(() => {});
    } finally {
      setGoogleLoading(false);
      googleCallbackProcessingRef.current = false;
    }
  }, []);

  // Check for Supabase session on mount (Google redirect callback)
  // After Lovable managed OAuth redirect, a Supabase session exists that needs
  // to be exchanged for our custom session token
  useEffect(() => {
    const checkGoogleSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user?.email) {
          // There's a Supabase session - this is a Google callback.
          // Always process it, even if there's a stale custom session token.
          handleGoogleCallback();
        }
      } catch (e) {
        // Ignore errors
      }
    };
    checkGoogleSession();

    // Also listen for auth state changes as fallback
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session?.user?.email) {
        handleGoogleCallback();
      }
    });
    return () => subscription.unsubscribe();
  }, [handleGoogleCallback]);

  // Check URL params for verification/reset tokens
  useEffect(() => {
    const verifyToken = searchParams.get('verify');
    const action = searchParams.get('action');
    const token = searchParams.get('token');
    
    if (verifyToken) {
      setVerificationToken(verifyToken);
      handleEmailVerification(verifyToken);
    }
    
    // Handle reset action with token param (from email links)
    if (action === 'reset' && token) {
      setResetToken(token);
    }
    
    // Also support direct ?reset=token format
    const directReset = searchParams.get('reset');
    if (directReset) {
      setResetToken(directReset);
    }
  }, [searchParams]);

  // Redirect authenticated users
  useEffect(() => {
    if (!loading && user && !tempPassword && !showChangePassword) {
      navigate('/', { replace: true });
    }
    
    // Show change password dialog for temp password users
    if (user && tempPassword && !showChangePassword) {
      setShowChangePassword(true);
    }
  }, [user, loading, tempPassword, navigate, showChangePassword]);

  const handleEmailVerification = async (token: string) => {
    setVerifying(true);
    try {
      const { data, error } = await supabase.functions.invoke('auth', {
        body: { action: 'verify-email', token }
      });

      if (error || !data?.success) {
        toast.error(data?.error || 'Email verification failed. The link may have expired.');
      } else {
        setVerificationSuccess(true);
        toast.success('Email verified successfully! You can now sign in.');
      }
    } catch (error: any) {
      toast.error('Email verification failed');
    } finally {
      setVerifying(false);
    }
  };

  const isPendoEmail = (email: string) => {
    return email.toLowerCase().endsWith(PENDO_EMAIL_DOMAIN);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      if (isLogin) {
        if (requiresMfa && totpCode.trim().length === 0) {
          toast.error('Please enter your 2FA code');
          return;
        }

        const result = await signIn(email, password, requiresMfa ? totpCode.trim() : undefined);

        if (result.requireMfa) {
          setRequiresMfa(true);
          toast.info('Enter your 2FA code to finish signing in');
          return;
        }

        if (result.requirePasswordChange) {
          setShowChangePassword(true);
          toast.info('Please change your temporary password');
        } else {
          // Check if user needs to set up 2FA (first login after email verification)
          const token = getSessionToken();
          if (token && !user?.mfa_enabled) {
            setSetupSessionToken(token);
            setShow2FASetup(true);
          } else {
            toast.success('Welcome back!');
            navigate('/', { replace: true });
          }
        }
      } else {
        // Registration
        if (!isPendoEmail(email)) {
          toast.error('Registration is restricted to Pendo employees only. Please use your @pendo.io email address.');
          setSubmitting(false);
          return;
        }

        if (password.length < 12) {
          toast.error('Password must be at least 12 characters');
          setSubmitting(false);
          return;
        }

        const { data, error } = await supabase.functions.invoke('auth', {
          body: { action: 'register', email, password, fullName }
        });

        if (error || !data?.success) {
          throw new Error(data?.error || 'Registration failed');
        }

        setRegistrationSuccess(true);
        toast.success('Account created! Please check your email to verify your account.');
      }
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!resetEmail) {
      toast.error('Please enter your email address');
      return;
    }

    setSubmitting(true);
    try {
      let lastError: any = null;
      let result: any = null;
      
      // Retry up to 3 times to handle transient backend timeouts
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const { data, error } = await supabase.functions.invoke('auth', {
            body: { action: 'forgot-password', email: resetEmail }
          });
          if (error) {
            lastError = error;
            const msg = typeof error === 'object' ? JSON.stringify(error) : String(error);
            if (msg.includes('503') || msg.includes('timeout') || msg.includes('timed out') || msg.includes('SERVICE_UNAVAILABLE')) {
              console.warn(`[Auth] forgot-password attempt ${attempt + 1} transient error, retrying...`);
              await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
              continue;
            }
          }
          result = data;
          lastError = null;
          break;
        } catch (err) {
          lastError = err;
          console.warn(`[Auth] forgot-password attempt ${attempt + 1} failed:`, err);
          if (attempt < 2) await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
        }
      }

      if (lastError) {
        // Still show success to not reveal email existence
        toast.success('If an account exists with this email, you will receive a password reset link.');
      } else {
        toast.success('Password reset link sent! Check your email.');
      }
      setResetEmailSent(true);
    } catch (error: any) {
      toast.success('If an account exists with this email, you will receive a password reset link.');
      setResetEmailSent(true);
    } finally {
      setSubmitting(false);
    }
  };

  const handlePasswordReset = async () => {
    if (newPassword !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    if (newPassword.length < 12) {
      toast.error('Password must be at least 12 characters');
      return;
    }

    setSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke('auth', {
        body: { action: 'reset-password', token: resetToken, newPassword }
      });

      if (error || !data?.success) {
        throw new Error(data?.error || 'Password reset failed');
      }

      toast.success('Password updated successfully! Please sign in.');
      setResetToken(null);
      setNewPassword('');
      setConfirmPassword('');
      // Clear URL params
      navigate('/auth', { replace: true });
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleChangePassword = async () => {
    if (newPassword !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    if (newPassword.length < 12) {
      toast.error('Password must be at least 12 characters');
      return;
    }

    setSubmitting(true);
    try {
      const token = getSessionToken();
      const { data, error } = await supabase.functions.invoke('auth', {
        body: { action: 'change-password', currentPassword, newPassword },
        headers: { Authorization: `Bearer ${token}` }
      });

      if (error || !data?.success) {
        throw new Error(data?.error || 'Password change failed');
      }

      toast.success('Password changed successfully!');
      setShowChangePassword(false);
      setNewPassword('');
      setConfirmPassword('');
      setCurrentPassword('');
      navigate('/', { replace: true });
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  // 2FA Setup Screen (shown after first login if MFA not enabled)
  if (show2FASetup && setupSessionToken) {
    return (
      <Setup2FADialog
        sessionToken={setupSessionToken}
        onComplete={() => {
          setShow2FASetup(false);
          setSetupSessionToken(null);
          toast.success('Welcome to Pendo Compass!');
          navigate('/', { replace: true });
        }}
        onSkip={() => {
          setShow2FASetup(false);
          setSetupSessionToken(null);
          navigate('/', { replace: true });
        }}
      />
    );
  }

  // Email Verification Screen
  if (verificationToken) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        
        <div className="glass rounded-2xl p-8 w-full max-w-md relative z-10">
          <div className="flex flex-col items-center mb-6">
            <div className={`w-16 h-16 rounded-2xl ${verificationSuccess ? 'bg-green-500/10' : 'bg-[hsl(var(--pendo-pink))]/10'} flex items-center justify-center mb-4`}>
              {verifying ? (
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
              ) : verificationSuccess ? (
                <CheckCircle className="w-8 h-8 text-green-500" />
              ) : (
                <Mail className="w-8 h-8 text-[hsl(var(--pendo-pink))]" />
              )}
            </div>
            <h1 className="text-2xl font-bold text-foreground">
              {verifying ? 'Verifying Email...' : verificationSuccess ? 'Email Verified!' : 'Verification Failed'}
            </h1>
            <p className="text-sm text-muted-foreground text-center mt-2">
              {verifying 
                ? 'Please wait while we verify your email address.'
                : verificationSuccess 
                  ? 'Your email has been verified. You can now sign in.'
                  : 'The verification link may have expired or is invalid.'}
            </p>
          </div>

          {!verifying && (
            <Button 
              onClick={() => {
                setVerificationToken(null);
                navigate('/auth', { replace: true });
              }}
              className="w-full" 
              variant="glow"
            >
              {verificationSuccess ? 'Sign In' : 'Back to Sign In'}
            </Button>
          )}
        </div>
      </div>
    );
  }

  // Password Reset with Token Screen
  if (resetToken) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        
        <div className="glass rounded-2xl p-8 w-full max-w-md relative z-10">
          <div className="flex flex-col items-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-[hsl(var(--pendo-pink))]/10 flex items-center justify-center mb-4">
              <KeyRound className="w-8 h-8 text-[hsl(var(--pendo-pink))]" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Reset Password</h1>
            <p className="text-sm text-muted-foreground text-center mt-2">
              Enter your new password below
            </p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="new-password">New Password</Label>
              <Input
                id="new-password"
                type="password"
                placeholder="••••••••"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                minLength={8}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirm-password">Confirm Password</Label>
              <Input
                id="confirm-password"
                type="password"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                minLength={8}
              />
            </div>

            <Button 
              onClick={handlePasswordReset}
              className="w-full" 
              variant="glow" 
              disabled={submitting || !newPassword || !confirmPassword}
            >
              {submitting ? 'Updating...' : 'Update Password'}
            </Button>
          </div>

          <button
            type="button"
            onClick={() => {
              setResetToken(null);
              navigate('/auth', { replace: true });
            }}
            className="w-full mt-4 text-sm text-muted-foreground hover:text-primary transition-colors"
          >
            Back to Sign In
          </button>
        </div>
      </div>
    );
  }

  // Change Password Screen (for temp password users)
  if (showChangePassword && user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        
        <div className="glass rounded-2xl p-8 w-full max-w-md relative z-10">
          <div className="flex flex-col items-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-[hsl(var(--pendo-pink))]/10 flex items-center justify-center mb-4">
              <Shield className="w-8 h-8 text-[hsl(var(--pendo-pink))]" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Change Password</h1>
            <p className="text-sm text-muted-foreground text-center mt-2">
              Please set a new password for your account
            </p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="current-password">Current Password</Label>
              <Input
                id="current-password"
                type="password"
                placeholder="••••••••"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="new-password">New Password</Label>
              <Input
                id="new-password"
                type="password"
                placeholder="••••••••"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                minLength={8}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirm-password">Confirm New Password</Label>
              <Input
                id="confirm-password"
                type="password"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                minLength={8}
              />
            </div>

            <Button 
              onClick={handleChangePassword}
              className="w-full" 
              variant="glow" 
              disabled={submitting || !currentPassword || !newPassword || !confirmPassword}
            >
              {submitting ? 'Updating...' : 'Change Password'}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Registration Success Screen
  if (registrationSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        
        <div className="glass rounded-2xl p-8 w-full max-w-md relative z-10">
          <div className="flex flex-col items-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-green-500/10 flex items-center justify-center mb-4">
              <Mail className="w-8 h-8 text-green-500" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Check Your Email</h1>
            <p className="text-sm text-muted-foreground text-center mt-2">
              We've sent a verification link to <strong>{email}</strong>. 
              Click the link in your email to verify your account.
            </p>
          </div>

          <div className="p-4 rounded-lg bg-muted/50 border border-border">
            <p className="text-sm text-muted-foreground text-center">
              After verifying your email, you'll be able to sign in to your account. 
              Your account will be pending admin approval.
            </p>
          </div>

          <Button 
            onClick={() => {
              setRegistrationSuccess(false);
              setIsLogin(true);
              setEmail('');
              setPassword('');
              setFullName('');
            }}
            className="w-full mt-4" 
            variant="outline"
          >
            Back to Sign In
          </Button>
        </div>
      </div>
    );
  }

  // Forgot Password Screen
  if (showForgotPassword) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        
        <div className="glass rounded-2xl p-8 w-full max-w-md relative z-10">
          <div className="flex flex-col items-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-[hsl(var(--pendo-pink))]/10 flex items-center justify-center mb-4">
              <img src={pendoLogo} alt="Pendo" className="w-10 h-10 object-contain" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Reset Password</h1>
            <p className="text-sm text-muted-foreground text-center mt-2">
              {resetEmailSent 
                ? 'Check your email for the password reset link.'
                : 'Enter your email address and we\'ll send you a link to reset your password.'}
            </p>
          </div>

          {!resetEmailSent ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="reset-email">Email Address</Label>
                <Input
                  id="reset-email"
                  type="email"
                  placeholder="your@pendo.io"
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                />
              </div>

              <Button 
                onClick={handleForgotPassword} 
                className="w-full" 
                variant="glow" 
                disabled={submitting || !resetEmail}
              >
                {submitting ? 'Sending...' : 'Send Reset Link'}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                <p className="text-sm text-center">
                  If an account exists with <strong>{resetEmail}</strong>, 
                  you will receive a password reset link.
                </p>
              </div>
              <Button 
                onClick={() => setResetEmailSent(false)}
                variant="outline"
                className="w-full"
              >
                Send Again
              </Button>
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              setShowForgotPassword(false);
              setResetEmail('');
              setResetEmailSent(false);
            }}
            className="w-full mt-4 text-sm text-muted-foreground hover:text-primary transition-colors"
          >
            Back to Sign In
          </button>
        </div>
      </div>
    );
  }

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin + '/auth',
        extraParams: { hd: "pendo.io", prompt: "select_account" },
      });
      if (result?.error) throw result.error;
    } catch (err: any) {
      toast.error(err.message || 'Failed to start Google sign-in');
      setGoogleLoading(false);
    }
  };

  // Main Login/Register Screen
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="fixed inset-0 bg-glow pointer-events-none" />
      
      <div className="glass rounded-2xl p-8 w-full max-w-md relative z-10">
        <div className="flex flex-col items-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-[hsl(var(--pendo-pink))]/10 flex items-center justify-center mb-4">
            <img src={pendoLogo} alt="Pendo" className="w-10 h-10 object-contain" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">
            {isLogin ? 'Welcome Back' : 'Create Account'}
          </h1>
          <p className="text-sm text-muted-foreground">
            {isLogin ? 'Sign in to Pendo Compass' : 'Register for Pendo Compass'}
          </p>
        </div>

        {isLogin && (
          <>
            <Button
              type="button"
              variant="outline"
              className="w-full mb-4 h-11 gap-3 border-border hover:bg-muted/50"
              onClick={handleGoogleSignIn}
              disabled={googleLoading || submitting}
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              {googleLoading ? 'Signing in...' : 'Sign in with Google'}
            </Button>
            <div className="relative mb-4">
              <Separator />
              <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-card px-3 text-xs text-muted-foreground">
                or continue with email
              </span>
            </div>
          </>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input id="fullName" type="text" placeholder="John Doe" value={fullName} onChange={(e) => setFullName(e.target.value)} required={!isLogin} />
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" placeholder={isLogin ? "your@email.com" : "your@pendo.io"} value={email} onChange={(e) => setEmail(e.target.value)} required />
            {!isLogin && <p className="text-xs text-muted-foreground">Only @pendo.io email addresses are allowed</p>}
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" placeholder="••••••••••••" value={password} onChange={(e) => { setPassword(e.target.value); if (requiresMfa) { setRequiresMfa(false); setTotpCode(''); } }} required minLength={12} autoComplete="current-password" disabled={requiresMfa} />
          </div>
          {isLogin && requiresMfa && (
            <div className="space-y-2">
              <Label htmlFor="totp">2FA Code</Label>
              <Input id="totp" type="text" inputMode="numeric" pattern="[0-9]*" maxLength={6} autoComplete="off" autoFocus placeholder="123456" value={totpCode} onChange={(e) => setTotpCode(e.target.value.replace(/\D/g, '').slice(0, 6))} />
              <p className="text-xs text-muted-foreground">Enter the 6-digit code from your authenticator app.</p>
            </div>
          )}
          <Button type="submit" className="w-full" variant="glow" disabled={submitting || googleLoading}>
            {submitting ? 'Please wait...' : isLogin ? 'Sign In' : 'Create Account'}
          </Button>
        </form>

        {isLogin && (
          <button type="button" onClick={() => setShowForgotPassword(true)} className="w-full mt-4 text-sm text-muted-foreground hover:text-primary transition-colors">
            Forgot your password?
          </button>
        )}

        <div className="mt-6 text-center text-sm text-muted-foreground">
          {isLogin ? (
            <>Don&apos;t have an account?{' '}<button type="button" onClick={() => { setIsLogin(false); setRequiresMfa(false); setTotpCode(''); }} className="text-primary hover:underline font-medium">Register</button></>
          ) : (
            <>Already have an account?{' '}<button type="button" onClick={() => { setIsLogin(true); setRequiresMfa(false); setTotpCode(''); }} className="text-primary hover:underline font-medium">Sign In</button></>
          )}
        </div>

        {isLogin && (
          <p className="mt-4 text-xs text-center text-muted-foreground">@pendo.io employees can use Google SSO for passwordless sign-in</p>
        )}
      </div>
    </div>
  );
}

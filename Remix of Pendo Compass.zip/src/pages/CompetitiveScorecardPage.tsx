import { Sidebar } from '@/components/layout/Sidebar';
import { CompetitiveHeatmapView } from '@/components/competitive/CompetitiveHeatmapView';

export default function CompetitiveScorecardPage() {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          <CompetitiveHeatmapView />
        </div>
      </main>
    </div>
  );
}

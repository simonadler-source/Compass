import { Sidebar } from '@/components/layout/Sidebar';
import { DetectionRulesView } from '@/components/views/DetectionRulesView';
import { useUserRole } from '@/hooks/useUserRole';
import { Navigate } from 'react-router-dom';

export default function DetectionRulesPage() {
  const { isAdmin, isLoading } = useUserRole();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }
  
  // Redirect non-admins
  if (!isAdmin) {
    return <Navigate to="/" replace />;
  }
  
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-hidden">
        <DetectionRulesView />
      </main>
    </div>
  );
}

import { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LayoutDashboard, Activity, Grid2X2 } from 'lucide-react';
import { MissionControlView } from '@/components/home/MissionControlView';
import { ActivityFeedView } from '@/components/home/ActivityFeedView';
import { QuadrantDashboardView } from '@/components/home/QuadrantDashboardView';
import { useHomeData } from '@/hooks/useHomeData';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

type ViewMode = 'mission-control' | 'activity-feed' | 'quadrant';

const TIME_RANGES = [
  { value: '7', label: 'Last 7 days' },
  { value: '14', label: 'Last 14 days' },
  { value: '30', label: 'Last 30 days' },
  { value: '60', label: 'Last 60 days' },
  { value: '90', label: 'Last 90 days' },
];

export default function HomePage() {
  const [viewMode, setViewMode] = useState<ViewMode>('mission-control');
  const [timeRange, setTimeRange] = useState('30');
  const homeData = useHomeData(parseInt(timeRange));

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <div className="fixed inset-0 bg-glow pointer-events-none" />
      <Sidebar />
      <main className="flex-1 overflow-auto relative">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Home</h1>
              <p className="text-sm text-muted-foreground">
                Your book of business at a glance
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              {/* Time Range Selector */}
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TIME_RANGES.map(range => (
                    <SelectItem key={range.value} value={range.value}>
                      {range.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* View Mode Toggle */}
              <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as ViewMode)}>
                <TabsList className="bg-muted/50">
                  <TabsTrigger value="mission-control" className="gap-2">
                    <LayoutDashboard className="w-4 h-4" />
                    <span className="hidden sm:inline">Mission Control</span>
                  </TabsTrigger>
                  <TabsTrigger value="activity-feed" className="gap-2">
                    <Activity className="w-4 h-4" />
                    <span className="hidden sm:inline">Activity Feed</span>
                  </TabsTrigger>
                  <TabsTrigger value="quadrant" className="gap-2">
                    <Grid2X2 className="w-4 h-4" />
                    <span className="hidden sm:inline">Quadrant</span>
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>

          {/* View Content */}
          {viewMode === 'mission-control' && <MissionControlView data={homeData} />}
          {viewMode === 'activity-feed' && <ActivityFeedView data={homeData} />}
          {viewMode === 'quadrant' && <QuadrantDashboardView data={homeData} />}
        </div>
      </main>
    </div>
  );
}

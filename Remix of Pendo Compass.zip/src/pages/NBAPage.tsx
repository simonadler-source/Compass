import { useNavigate } from 'react-router-dom';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Sidebar } from '@/components/layout/Sidebar';
import { NBADashboard } from '@/components/views/NBADashboard';

export default function NBAPage() {
  const navigate = useNavigate();

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="flex h-screen bg-background overflow-hidden">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        <Sidebar />
        <main className="flex-1 overflow-auto relative">
          <NBADashboard
            onSelectAccount={(id) => navigate(`/accounts/${id}?tab=opportunities`)}
          />
        </main>
      </div>
    </DndProvider>
  );
}

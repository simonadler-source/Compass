import { Sidebar } from '@/components/layout/Sidebar';
import { OpportunityAlertRulesView } from '@/components/views/OpportunityAlertRulesView';
import { useCanAccessPage } from '@/hooks/usePageAccess';
import { Navigate } from 'react-router-dom';

export default function OpportunityAlertRulesPage() {
  const { canAccess, isLoading } = useCanAccessPage('/alert-rules');
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }
  
  // Redirect users without page access
  if (!canAccess) {
    return <Navigate to="/" replace />;
  }
  
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <OpportunityAlertRulesView />
      </main>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Loader2 } from 'lucide-react';

/**
 * Direct opportunity URL handler
 * Routes like /opportunities/:opportunityId redirect to the account page with the opportunity selected
 * This allows sharing direct links to opportunities
 */
export default function OpportunityPage() {
  const { opportunityId } = useParams<{ opportunityId: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);

  // Preserve any tab parameter from the URL
  const tabParam = searchParams.get('tab');

  useEffect(() => {
    async function fetchOpportunityAndRedirect() {
      if (!opportunityId) {
        navigate('/accounts');
        return;
      }

      try {
        // Fetch the opportunity to get its account_id
        const { data: opportunity, error: fetchError } = await supabase
          .from('opportunities')
          .select('account_id')
          .eq('id', opportunityId)
          .single();

        if (fetchError || !opportunity) {
          setError('Opportunity not found');
          setTimeout(() => navigate('/accounts'), 2000);
          return;
        }

        // Build the redirect URL with opportunity context
        const params = new URLSearchParams();
        params.set('opportunityId', opportunityId);
        if (tabParam) {
          params.set('oppTab', tabParam);
        }

        navigate(`/accounts/${opportunity.account_id}?${params.toString()}`, { replace: true });
      } catch (err) {
        console.error('Error fetching opportunity:', err);
        setError('Failed to load opportunity');
        setTimeout(() => navigate('/accounts'), 2000);
      }
    }

    fetchOpportunityAndRedirect();
  }, [opportunityId, tabParam, navigate]);

  if (error) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-destructive mb-2">{error}</p>
          <p className="text-muted-foreground text-sm">Redirecting to accounts...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen items-center justify-center bg-background">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
        <p className="text-muted-foreground">Loading opportunity...</p>
      </div>
    </div>
  );
}

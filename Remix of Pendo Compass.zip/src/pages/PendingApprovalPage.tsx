import { Clock, LogOut, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import pendoLogo from '@/assets/pendo-logo.png';

export default function PendingApprovalPage() {
  const { user, signOut } = useAuth();

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md glass border-border">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-[hsl(var(--pendo-pink))]/10">
              <img src={pendoLogo} alt="Pendo" className="w-10 h-10 object-contain" />
            </div>
          </div>
          <div className="space-y-2">
            <CardTitle className="text-2xl font-bold text-foreground">
              Awaiting Approval
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Your account is pending administrator approval
            </CardDescription>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="flex items-center justify-center">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-yellow-500/10 flex items-center justify-center">
                <Clock className="w-10 h-10 text-yellow-500" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-background border-2 border-yellow-500/30 flex items-center justify-center">
                <Shield className="w-4 h-4 text-yellow-500" />
              </div>
            </div>
          </div>
          
          <div className="bg-muted/30 rounded-lg p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center shrink-0 mt-0.5">
                <span className="text-green-500 text-sm">✓</span>
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">Account Created</p>
                <p className="text-xs text-muted-foreground">{user?.email}</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center shrink-0 mt-0.5">
                <span className="text-green-500 text-sm">✓</span>
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">Two-Factor Authentication</p>
                <p className="text-xs text-muted-foreground">Successfully configured</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-yellow-500/20 flex items-center justify-center shrink-0 mt-0.5 animate-pulse">
                <Clock className="w-3 h-3 text-yellow-500" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">Admin Approval</p>
                <p className="text-xs text-muted-foreground">Waiting for an administrator to approve your access</p>
              </div>
            </div>
          </div>
          
          <p className="text-center text-sm text-muted-foreground">
            An administrator will review your registration and grant access. 
            You'll be able to use Compass once approved.
          </p>
          
          <Button
            variant="outline"
            className="w-full"
            onClick={() => signOut()}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

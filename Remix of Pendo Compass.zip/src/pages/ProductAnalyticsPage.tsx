import { Sidebar } from '@/components/layout/Sidebar';
import { ProductAnalyticsView } from '@/components/views/ProductAnalyticsView';

export default function ProductAnalyticsPage() {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <ProductAnalyticsView />
      </main>
    </div>
  );
}

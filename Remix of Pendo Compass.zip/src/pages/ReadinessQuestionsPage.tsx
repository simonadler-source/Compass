import { Sidebar } from '@/components/layout/Sidebar';
import { ReadinessQuestionsManagement } from '@/components/views/ReadinessQuestionsManagement';

const ReadinessQuestionsPage = () => {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 p-6 overflow-auto">
        <div className="mb-6">
          <h1 className="page-heading">Readiness Questions</h1>
          <p className="text-muted-foreground">Manage readiness assessment questions and categories</p>
        </div>
        <ReadinessQuestionsManagement />
      </main>
    </div>
  );
};

export default ReadinessQuestionsPage;

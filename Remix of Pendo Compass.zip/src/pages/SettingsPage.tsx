import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Sidebar } from '@/components/layout/Sidebar';
import { SettingsView } from '@/components/views/SettingsView';

export default function SettingsPage() {
  return (
    <DndProvider backend={HTML5Backend}>
      <div className="flex h-screen bg-background overflow-hidden">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        <Sidebar />
        <main className="flex-1 overflow-auto relative">
          <SettingsView />
        </main>
      </div>
    </DndProvider>
  );
}

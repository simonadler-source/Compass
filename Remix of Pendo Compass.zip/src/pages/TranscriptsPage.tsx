import { useNavigate } from 'react-router-dom';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Sidebar } from '@/components/layout/Sidebar';
import { TranscriptsView } from '@/components/views/TranscriptsView';
import { ExtractedTech } from '@/types/architecture';

export default function TranscriptsPage() {
  const navigate = useNavigate();

  const handleTechnologiesExtracted = (techs: ExtractedTech[]) => {
    console.log('Technologies extracted:', techs);
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="flex h-screen bg-background overflow-hidden">
        <div className="fixed inset-0 bg-glow pointer-events-none" />
        <Sidebar />
        <main className="flex-1 overflow-auto relative">
          <TranscriptsView
            onTechnologiesExtracted={handleTechnologiesExtracted}
            onNavigateToAccount={(accountId) => navigate(`/accounts/${accountId}`)}
          />
        </main>
      </div>
    </DndProvider>
  );
}

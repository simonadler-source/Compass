import { Sidebar } from '@/components/layout/Sidebar';
import { ValidationTaskTemplatesManagement } from '@/components/views/ValidationTaskTemplatesManagement';

const ValidationTasksPage = () => {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 p-6 overflow-auto">
        <div className="mb-6">
          <h1 className="page-heading">Validation Task Templates</h1>
          <p className="text-muted-foreground">Manage validation task templates linked to detection rules</p>
        </div>
        <ValidationTaskTemplatesManagement />
      </main>
    </div>
  );
};

export default ValidationTasksPage;

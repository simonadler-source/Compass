export type LayerType = 'host' | 'build' | 'adopt' | 'growth' | 'ops';
export type PriorityLevel = 'critical' | 'high' | 'medium' | 'low';

export interface Technology {
  id: string;
  name: string;
  layer: LayerType;
  category: string;
  owner?: string;
  version?: string;
  securityModel?: string;
  integrations?: string[];
  issues?: string;
  status?: 'active' | 'planned' | 'deprecated';
  priority?: PriorityLevel;
  dataValue?: number; // 1-10 scale
  notes?: string;
}

export interface Account {
  id: string;
  name: string;
  industry?: string;
  technologies: Technology[];
  salesforceId?: string;
  primaryContact?: string;
  stage?: 'discovery' | 'evaluation' | 'proposal' | 'closing' | 'customer';
  createdAt: Date;
  updatedAt: Date;
}

export interface TranscriptAnalysis {
  id: string;
  fileName: string;
  extractedTechnologies: ExtractedTech[];
  analyzedAt: Date;
  status: 'pending' | 'processing' | 'complete' | 'failed';
  competitorMentions?: CompetitorMention[];
  useCasesIdentified?: UseCaseMatch[];
}

export interface ExtractedTech {
  name: string;
  confidence: number;
  context: string;
  suggestedLayer?: LayerType;
}

export interface CompetitorMention {
  name: string;
  context: string;
  sentiment: 'positive' | 'neutral' | 'negative';
}

export interface UseCaseMatch {
  id: string;
  name: string;
  matchConfidence: number;
  relevantQuotes: string[];
}

export interface Competitor {
  id: string;
  name: string;
  category: string;
  strengths?: string[];
  weaknesses?: string[];
  differentiators?: string[];
}

export interface UseCase {
  id: string;
  name: string;
  description: string;
  keywords: string[];
  industry?: string;
  successMetrics?: string[];
}

export interface CustomerStory {
  id: string;
  accountName: string;
  title: string;
  industry: string;
  challenge: string;
  solution: string;
  results: string;
  technologies: string[];
  useCases: string[];
  screenshots: ScreenshotCapture[];
  createdAt: Date;
  updatedAt: Date;
}

export interface ScreenshotCapture {
  id: string;
  name: string;
  url: string;
  description?: string;
  extractedTechnologies?: string[];
  annotations?: string[];
  capturedAt: Date;
}

export const LAYER_CONFIG: Record<LayerType, { label: string; description: string; color: string }> = {
  host: {
    label: 'Host Environment',
    description: 'Where the application lives',
    color: 'host',
  },
  build: {
    label: 'Build Stack',
    description: 'Product & Engineering tools',
    color: 'build',
  },
  adopt: {
    label: 'Adopt Stack',
    description: 'Enablement & Support systems',
    color: 'adopt',
  },
  growth: {
    label: 'Growth Stack',
    description: 'Revenue & CRM systems',
    color: 'growth',
  },
  ops: {
    label: 'Business Ops',
    description: 'C-Suite & Operations',
    color: 'ops',
  },
};

export const COMMON_TECHNOLOGIES: Partial<Technology>[] = [
  { name: 'Salesforce', layer: 'growth', category: 'CRM' },
  { name: 'HubSpot', layer: 'growth', category: 'CRM' },
  { name: 'Snowflake', layer: 'growth', category: 'Data Warehouse' },
  { name: 'React', layer: 'host', category: 'Frontend' },
  { name: 'Angular', layer: 'host', category: 'Frontend' },
  { name: 'Jira', layer: 'build', category: 'Issue Tracking' },
  { name: 'Confluence', layer: 'adopt', category: 'Knowledge Base' },
  { name: 'Workday', layer: 'host', category: 'Third-Party App' },
  { name: 'NetSuite', layer: 'ops', category: 'ERP' },
  { name: 'Tableau', layer: 'ops', category: 'BI' },
  { name: 'Google Analytics', layer: 'build', category: 'Analytics' },
  { name: 'Zendesk', layer: 'adopt', category: 'Support' },
  { name: 'Pendo', layer: 'adopt', category: 'Digital Adoption' },
  { name: 'Intercom', layer: 'adopt', category: 'Support' },
  { name: 'Stripe', layer: 'growth', category: 'Billing' },
  { name: 'AWS', layer: 'host', category: 'Cloud Platform' },
  { name: 'Azure', layer: 'host', category: 'Cloud Platform' },
  { name: 'GCP', layer: 'host', category: 'Cloud Platform' },
];


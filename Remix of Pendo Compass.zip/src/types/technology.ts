// Technology relationship statuses
export const TECHNOLOGY_RELATIONSHIP_STATUSES = [
  { value: 'mentioned', label: 'Mentioned', description: 'Just mentioned in passing', color: 'bg-gray-100 text-gray-800' },
  { value: 'experience', label: 'Has Experience', description: 'Team has experience but not in use', color: 'bg-blue-100 text-blue-800' },
  { value: 'in_use', label: 'In Use', description: 'Actively being used', color: 'bg-green-100 text-green-800' },
  { value: 'evaluating', label: 'Evaluating', description: 'Currently evaluating', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'considering', label: 'Considering', description: 'Considering for future use', color: 'bg-purple-100 text-purple-800' },
  { value: 'replaced', label: 'Replaced', description: 'Previously used, now replaced', color: 'bg-red-100 text-red-800' },
  { value: 'neutral', label: 'Neutral', description: 'Unknown relationship', color: 'bg-gray-100 text-gray-600' },
] as const;

export type TechnologyRelationshipStatus = typeof TECHNOLOGY_RELATIONSHIP_STATUSES[number]['value'];

export interface ExtractedTechnology {
  name: string;
  confidence: number;
  suggestedLayer: string;
  context: string;
  relationshipStatus: TechnologyRelationshipStatus;
  needsReview: boolean;
}

export interface AccountTechnology {
  id: string;
  account_id: string;
  name: string;
  category: string;
  layer: string;
  notes: string | null;
  status: string;
  owner_name: string | null;
  owner_email: string | null;
  relationship_status: TechnologyRelationshipStatus;
  repository_tech_id: string | null;
  priority: string | null;
  extraction_confidence: number | null;
  needs_review: boolean;
  context: string | null;
  created_at: string;
}

export function getRelationshipStatusConfig(status: string) {
  return TECHNOLOGY_RELATIONSHIP_STATUSES.find(s => s.value === status) || TECHNOLOGY_RELATIONSHIP_STATUSES[6]; // default to neutral
}

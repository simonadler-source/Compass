// Shared AI provider configuration
// This file determines which AI provider to use based on the ai_settings table

export type AIProvider = 'lovable' | 'gemini';
export type ModelTier = 'standard' | 'lite';

export interface AIConfig {
  endpoint: string;
  apiKey: string;
  model: string;
}

export async function getAIConfig(tier: ModelTier = 'standard'): Promise<AIConfig> {
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  
  let provider: AIProvider = 'lovable'; // Default to lovable
  
  // Fetch the configured provider from the database
  if (supabaseUrl && supabaseKey) {
    try {
      const response = await fetch(
        `${supabaseUrl}/rest/v1/ai_settings?setting_key=eq.ai_provider&select=setting_value`,
        {
          headers: {
            "Authorization": `Bearer ${supabaseKey}`,
            "apikey": supabaseKey,
          },
        }
      );
      
      if (response.ok) {
        const data = await response.json();
        if (data && data.length > 0 && data[0].setting_value) {
          provider = data[0].setting_value as AIProvider;
        }
      }
    } catch (error) {
      console.error("Failed to fetch AI provider setting, using default:", error);
    }
  }
  
  // Select model based on tier
  const getModel = (provider: AIProvider, tier: ModelTier): string => {
    if (provider === 'gemini') {
      return tier === 'lite' ? 'gemini-2.5-flash-lite' : 'gemini-2.5-flash';
    }
    // Lovable AI models
    return tier === 'lite' ? 'google/gemini-2.5-flash-lite' : 'google/gemini-2.5-flash';
  };
  
  const model = getModel(provider, tier);
  console.log(`Using AI provider: ${provider}, tier: ${tier}, model: ${model}`);
  
  if (provider === 'gemini') {
    const googleApiKey = Deno.env.get("GOOGLE_API_KEY");
    if (!googleApiKey) {
      throw new Error("GOOGLE_API_KEY is not configured. Please add it in settings.");
    }
    
    return {
      endpoint: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
      apiKey: googleApiKey,
      model,
    };
  }
  
  // Default: Lovable AI
  const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!lovableApiKey) {
    throw new Error("LOVABLE_API_KEY is not configured");
  }
  
  return {
    endpoint: "https://ai.gateway.lovable.dev/v1/chat/completions",
    apiKey: lovableApiKey,
    model,
  };
}

// Helper to compute a simple hash for cache detection
export function computeContentHash(content: string): string {
  let hash = 0;
  for (let i = 0; i < content.length; i++) {
    const char = content.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return hash.toString(16);
}

// Smart transcript truncation - extracts relevant speaker turns with keywords
export function smartTruncate(
  transcript: string, 
  maxLength: number = 30000,
  keywords: string[] = []
): string {
  if (transcript.length <= maxLength) {
    return transcript;
  }
  
  // If no keywords, just take first portion
  if (keywords.length === 0) {
    return transcript.slice(0, maxLength);
  }
  
  // Split into speaker turns (common patterns)
  const turnPatterns = /(?:\n\n|\r\n\r\n)(?=[A-Z][a-z]+ [A-Z][a-z]+:|(?:Speaker|Participant|Host|Guest) \d+:)/g;
  const turns = transcript.split(turnPatterns);
  
  // Score each turn by keyword relevance
  const keywordLower = keywords.map(k => k.toLowerCase());
  const scoredTurns = turns.map((turn, index) => {
    const turnLower = turn.toLowerCase();
    const score = keywordLower.reduce((acc, kw) => {
      return acc + (turnLower.includes(kw) ? 1 : 0);
    }, 0);
    return { turn, score, index };
  });
  
  // Sort by score (descending) then by original order for ties
  scoredTurns.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return a.index - b.index;
  });
  
  // Take top scoring turns until we hit maxLength
  let result = '';
  let currentLength = 0;
  const selectedTurns: { turn: string; index: number }[] = [];
  
  for (const t of scoredTurns) {
    if (currentLength + t.turn.length > maxLength) {
      if (selectedTurns.length === 0) {
        // At least include a truncated first turn
        selectedTurns.push({ turn: t.turn.slice(0, maxLength), index: t.index });
      }
      break;
    }
    selectedTurns.push({ turn: t.turn, index: t.index });
    currentLength += t.turn.length;
  }
  
  // Reorder by original position
  selectedTurns.sort((a, b) => a.index - b.index);
  result = selectedTurns.map(t => t.turn).join('\n\n');
  
  return result;
}

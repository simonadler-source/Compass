// Context builder for big-picture synthesis
// Fetches prior account/opportunity context to inject into transcript analysis

export interface AnalysisContext {
  // Recent meeting summaries (last 5)
  recentMeetings: {
    date: string;
    title: string;
    summary: string;
    keyTopics: string[];
  }[];
  
  // Open NBAs that might be addressed
  openNBAs: {
    id: string;
    action: string;
    actionType: string;
    priority: string;
    createdAt: string;
    dueDate?: string;
  }[];
  
  // Known stakeholders and their trajectories
  stakeholders: {
    name: string;
    role: string;
    stakeholderType: string;
    championScore: number;
    sentiment: number;
    lastSeenAt: string;
    meetingCount: number;
    // Trajectory indicators
    championTrend: 'rising' | 'stable' | 'declining' | 'unknown';
    sentimentTrend: 'improving' | 'stable' | 'worsening' | 'unknown';
  }[];
  
  // Existing pain points and use cases (for reinforcement detection)
  knownPainPoints: {
    description: string;
    painCategory: string;
    validationCount: number;
  }[];
  
  knownUseCases: {
    description: string;
    businessTheme: string;
    status: string;
    validationCount: number;
  }[];
  
  // Account-level context
  accountInfo: {
    name: string;
    industry: string;
    stage: string;
    engagementScore: number;
  };
  
  // Opportunity-level context (if applicable)
  opportunityInfo?: {
    name: string;
    stage: string;
    preSalesStage: string;
    value: number;
  };
}

// Decrypt helper
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < raw.length && i < 32; i++) key[i] = raw[i];
  return key;
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function decryptValue(ciphertext: string, keyInput: string, ivBase64: string): Promise<string> {
  try {
    const keyBytes = deriveKeyBytes(keyInput);
    const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["decrypt"]);
    const iv = base64ToBytes(ivBase64);
    const encryptedBytes = base64ToBytes(ciphertext);
    const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv: new Uint8Array(iv).buffer as ArrayBuffer }, key, new Uint8Array(encryptedBytes));
    return new TextDecoder().decode(decrypted);
  } catch (e) {
    return "";
  }
}

// Calculate trend from meeting snapshots
function calculateTrend(values: number[]): 'rising' | 'stable' | 'declining' | 'unknown' {
  if (values.length < 2) return 'unknown';
  
  const recent = values.slice(-3);
  const older = values.slice(0, -3);
  
  if (older.length === 0) {
    // Only recent data - check if last is higher than first
    if (recent[recent.length - 1] > recent[0] + 10) return 'rising';
    if (recent[recent.length - 1] < recent[0] - 10) return 'declining';
    return 'stable';
  }
  
  const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
  const olderAvg = older.reduce((a, b) => a + b, 0) / older.length;
  
  if (recentAvg > olderAvg + 10) return 'rising';
  if (recentAvg < olderAvg - 10) return 'declining';
  return 'stable';
}

// Fetch account/opportunity context for context-aware analysis
export async function buildAnalysisContext(
  supabaseUrl: string,
  supabaseKey: string,
  accountId: string,
  opportunityId?: string,
  encryptionKey?: string
): Promise<AnalysisContext> {
  const headers = {
    "Authorization": `Bearer ${supabaseKey}`,
    "apikey": supabaseKey,
    "Content-Type": "application/json",
  };

  // Fetch account info
  const accountRes = await fetch(
    `${supabaseUrl}/rest/v1/accounts?id=eq.${accountId}&select=name,industry,stage,engagement_score`,
    { headers }
  );
  const accounts = await accountRes.json();
  const account = accounts[0] || {};

  // Fetch opportunity info if provided
  let opportunityInfo: AnalysisContext['opportunityInfo'];
  if (opportunityId) {
    const oppRes = await fetch(
      `${supabaseUrl}/rest/v1/opportunities?id=eq.${opportunityId}&select=name,stage,pre_sales_stage,value`,
      { headers }
    );
    const opps = await oppRes.json();
    if (opps[0]) {
      opportunityInfo = {
        name: opps[0].name,
        stage: opps[0].stage,
        preSalesStage: opps[0].pre_sales_stage,
        value: opps[0].value,
      };
    }
  }

  // Fetch recent approved transcripts with summaries
  const transcriptsRes = await fetch(
    `${supabaseUrl}/rest/v1/transcript_reviews?final_account_id=eq.${accountId}&status=eq.approved&select=id,meeting_title,created_at,extracted_insights&order=created_at.desc&limit=5`,
    { headers }
  );
  const transcripts = await transcriptsRes.json();
  
  const recentMeetings = transcripts.map((t: any) => ({
    date: t.created_at,
    title: t.meeting_title || 'Meeting',
    summary: t.extracted_insights?.meetingSummary || t.extracted_insights?.summary || '',
    keyTopics: t.extracted_insights?.keyTopics || t.extracted_insights?.topics || [],
  })).filter((m: any) => m.summary || m.keyTopics.length > 0);

  // Fetch open NBAs
  let nbaQuery = `${supabaseUrl}/rest/v1/account_nbas?account_id=eq.${accountId}&status=in.(pending,in_progress)&select=id,action,action_encrypted,action_type,priority,created_at,due_date,encryption_iv&order=created_at.desc&limit=50`;
  if (opportunityId) {
    nbaQuery = `${supabaseUrl}/rest/v1/account_nbas?opportunity_id=eq.${opportunityId}&status=in.(pending,in_progress)&select=id,action,action_encrypted,action_type,priority,created_at,due_date,encryption_iv&order=created_at.desc&limit=50`;
  }
  const nbasRes = await fetch(nbaQuery, { headers });
  const rawNBAs = await nbasRes.json();
  
  const openNBAs: AnalysisContext['openNBAs'] = [];
  for (const nba of rawNBAs) {
    let action = nba.action;
    if (!action && nba.action_encrypted && nba.encryption_iv && encryptionKey) {
      action = await decryptValue(nba.action_encrypted, encryptionKey, nba.encryption_iv);
    }
    if (action) {
      openNBAs.push({
        id: nba.id,
        action,
        actionType: nba.action_type,
        priority: nba.priority,
        createdAt: nba.created_at,
        dueDate: nba.due_date,
      });
    }
  }

  // Fetch stakeholders with meeting history for trajectory
  const contactsRes = await fetch(
    `${supabaseUrl}/rest/v1/account_contacts?account_id=eq.${accountId}&is_internal=eq.false&is_ignored=eq.false&select=id,name_encrypted,role_encrypted,encryption_iv,stakeholder_type,champion_score,sentiment,updated_at`,
    { headers }
  );
  const rawContacts = await contactsRes.json();

  // Fetch meeting snapshots for trajectory calculation
  const snapshotsRes = await fetch(
    `${supabaseUrl}/rest/v1/contact_meeting_snapshots?account_id=eq.${accountId}&select=contact_id,champion_score,sentiment,meeting_date&order=meeting_date.desc`,
    { headers }
  );
  const snapshotsRaw = await snapshotsRes.json();
  const snapshots = Array.isArray(snapshotsRaw) ? snapshotsRaw : [];
  
  // Group snapshots by contact
  const snapshotsByContact: Record<string, any[]> = {};
  for (const s of snapshots) {
    if (!snapshotsByContact[s.contact_id]) snapshotsByContact[s.contact_id] = [];
    snapshotsByContact[s.contact_id].push(s);
  }

  const stakeholders: AnalysisContext['stakeholders'] = [];
  for (const contact of rawContacts) {
    let name = '';
    let role = '';
    if (contact.name_encrypted && contact.encryption_iv && encryptionKey) {
      name = await decryptValue(contact.name_encrypted, encryptionKey, contact.encryption_iv);
    }
    if (contact.role_encrypted && contact.encryption_iv && encryptionKey) {
      role = await decryptValue(contact.role_encrypted, encryptionKey, contact.encryption_iv);
    }
    if (!name) continue;

    const contactSnapshots = snapshotsByContact[contact.id] || [];
    const championScores = contactSnapshots.map(s => s.champion_score).filter(Boolean);
    const sentiments = contactSnapshots.map(s => s.sentiment).filter(Boolean);

    stakeholders.push({
      name,
      role,
      stakeholderType: contact.stakeholder_type || 'unknown',
      championScore: contact.champion_score || 0,
      sentiment: contact.sentiment || 50,
      lastSeenAt: contact.updated_at,
      meetingCount: contactSnapshots.length,
      championTrend: calculateTrend(championScores),
      sentimentTrend: (() => {
        const trend = calculateTrend(sentiments);
        if (trend === 'rising') return 'improving';
        if (trend === 'declining') return 'worsening';
        if (trend === 'stable') return 'stable';
        return 'unknown';
      })(),
    });
  }

  // Fetch known pain points
  const painRes = await fetch(
    `${supabaseUrl}/rest/v1/account_pain_points?account_id=eq.${accountId}&select=pain_point,pain_point_encrypted,pain_category,validation_count,encryption_iv&limit=15`,
    { headers }
  );
  const rawPains = await painRes.json();
  
  const knownPainPoints: AnalysisContext['knownPainPoints'] = [];
  for (const p of rawPains) {
    let description = p.pain_point;
    if (!description && p.pain_point_encrypted && p.encryption_iv && encryptionKey) {
      description = await decryptValue(p.pain_point_encrypted, encryptionKey, p.encryption_iv);
    }
    if (description) {
      knownPainPoints.push({
        description,
        painCategory: p.pain_category || 'general',
        validationCount: p.validation_count || 1,
      });
    }
  }

  // Fetch known use cases
  const ucRes = await fetch(
    `${supabaseUrl}/rest/v1/account_use_cases?account_id=eq.${accountId}&select=use_case,use_case_encrypted,business_theme,status,validation_count,encryption_iv&limit=15`,
    { headers }
  );
  const rawUCs = await ucRes.json();
  
  const knownUseCases: AnalysisContext['knownUseCases'] = [];
  for (const u of rawUCs) {
    let description = u.use_case;
    if (!description && u.use_case_encrypted && u.encryption_iv && encryptionKey) {
      description = await decryptValue(u.use_case_encrypted, encryptionKey, u.encryption_iv);
    }
    if (description) {
      knownUseCases.push({
        description,
        businessTheme: u.business_theme || 'general',
        status: u.status || 'identified',
        validationCount: u.validation_count || 1,
      });
    }
  }

  return {
    recentMeetings,
    openNBAs,
    stakeholders,
    knownPainPoints,
    knownUseCases,
    accountInfo: {
      name: account.name || 'Unknown',
      industry: account.industry || '',
      stage: account.stage || '',
      engagementScore: account.engagement_score || 0,
    },
    opportunityInfo,
  };
}

// Format context for injection into prompts
export function formatContextForPrompt(context: AnalysisContext, maxChars: number = 3000): string {
  const sections: string[] = [];
  
  // Account context
  sections.push(`## ACCOUNT: ${context.accountInfo.name}`);
  if (context.accountInfo.industry) sections.push(`Industry: ${context.accountInfo.industry}`);
  if (context.opportunityInfo) {
    sections.push(`\n## OPPORTUNITY: ${context.opportunityInfo.name}`);
    sections.push(`Stage: ${context.opportunityInfo.stage} | Pre-sales: ${context.opportunityInfo.preSalesStage}`);
  }
  
  // Recent meetings (for continuity)
  if (context.recentMeetings.length > 0) {
    sections.push(`\n## RECENT MEETINGS (${context.recentMeetings.length}):`);
    for (const m of context.recentMeetings.slice(0, 3)) {
      sections.push(`- ${m.date}: ${m.title}`);
      if (m.summary) sections.push(`  Summary: ${m.summary.substring(0, 150)}...`);
    }
  }
  
  // Open NBAs (for deduplication and completion detection)
  if (context.openNBAs.length > 0) {
    // Group by action type for a concise but complete view
    const byType: Record<string, typeof context.openNBAs> = {};
    for (const nba of context.openNBAs) {
      if (!byType[nba.actionType]) byType[nba.actionType] = [];
      byType[nba.actionType].push(nba);
    }

    sections.push(`\n## EXISTING OPEN ACTION ITEMS (${context.openNBAs.length} total — DO NOT ADD DUPLICATES):`);
    for (const [type, nbas] of Object.entries(byType)) {
      sections.push(`\n### ${type} (${nbas.length}):`);
      for (const nba of nbas.slice(0, 5)) {
        const dueInfo = nba.dueDate ? ` (due: ${nba.dueDate})` : '';
        sections.push(`- [${nba.priority}] ${nba.action}${dueInfo}`);
      }
      if (nbas.length > 5) {
        sections.push(`  ... and ${nbas.length - 5} more ${type} actions`);
      }
    }
    sections.push(`\nCRITICAL NBA RULES:`);
    sections.push(`1. There are already ${context.openNBAs.length} open actions — the list is TOO LONG. Be extremely selective.`);
    sections.push(`2. Do NOT generate new NBAs that overlap with ANY of the existing actions above.`);
    sections.push(`3. If this meeting addresses any of these actions, flag them as potentially complete.`);
    sections.push(`4. Only generate 1-2 genuinely NEW action items that emerged from THIS specific conversation.`);
    sections.push(`5. Consolidate related follow-ups into a single NBA. NEVER create multiple follow_up_meeting or internal_discussion actions.`);
    sections.push(`6. If there are already ${byType['follow_up_meeting']?.length || 0} follow_up_meeting and ${byType['internal_discussion']?.length || 0} internal_discussion actions, do NOT add more of those types.`);
  }
  
  // Key stakeholders with trajectories
  if (context.stakeholders.length > 0) {
    sections.push(`\n## KEY STAKEHOLDERS (${context.stakeholders.length}):`);
    const sortedStakeholders = [...context.stakeholders]
      .sort((a, b) => b.championScore - a.championScore)
      .slice(0, 5);
    
    for (const s of sortedStakeholders) {
      const trends: string[] = [];
      if (s.championTrend !== 'unknown') trends.push(`champion ${s.championTrend}`);
      if (s.sentimentTrend !== 'unknown' && s.sentimentTrend !== 'stable') trends.push(`sentiment ${s.sentimentTrend}`);
      const trendStr = trends.length > 0 ? ` [${trends.join(', ')}]` : '';
      sections.push(`- ${s.name} (${s.role}): ${s.stakeholderType}, champion=${s.championScore}, sentiment=${s.sentiment}${trendStr}`);
    }
    sections.push(`\nLook for changes in these stakeholders' engagement, sentiment, or champion behaviors.`);
  }
  
  // Known pain points (for validation/reinforcement)
  if (context.knownPainPoints.length > 0) {
    sections.push(`\n## KNOWN PAIN POINTS (${context.knownPainPoints.length}):`);
    for (const p of context.knownPainPoints.slice(0, 5)) {
      const validated = p.validationCount > 1 ? ` (validated ${p.validationCount}x)` : '';
      sections.push(`- [${p.painCategory}] ${p.description.substring(0, 100)}${validated}`);
    }
    sections.push(`\nIf this meeting confirms any known pain points, note reinforcement. Also identify NEW pain points.`);
  }
  
  // Known use cases (for validation/progression)
  if (context.knownUseCases.length > 0) {
    sections.push(`\n## KNOWN USE CASES (${context.knownUseCases.length}):`);
    for (const u of context.knownUseCases.slice(0, 5)) {
      sections.push(`- [${u.businessTheme}/${u.status}] ${u.description.substring(0, 100)}`);
    }
    sections.push(`\nNote if any use cases are discussed, validated, or show progress.`);
  }
  
  let result = sections.join('\n');
  
  // Truncate if too long
  if (result.length > maxChars) {
    result = result.substring(0, maxChars) + '\n\n[Context truncated for brevity]';
  }
  
  return result;
}

// Fetch competitive scorecard differentials for detected competitors
// Returns only significant gaps (|delta| > 1) between Pendo and each competitor
export interface ScorecardDifferential {
  competitorName: string;
  advantages: { category: string; subcategory: string; pendoScore: number; competitorScore: number; delta: number }[];
  gaps: { category: string; subcategory: string; pendoScore: number; competitorScore: number; delta: number }[];
}

export async function fetchScorecardDifferentials(
  supabaseUrl: string,
  supabaseKey: string,
  competitorNames: string[]
): Promise<ScorecardDifferential[]> {
  if (!competitorNames.length) return [];

  const headers = {
    "Authorization": `Bearer ${supabaseKey}`,
    "apikey": supabaseKey,
    "Content-Type": "application/json",
  };

  // Fetch Pendo scores
  const pendoRes = await fetch(
    `${supabaseUrl}/rest/v1/competitive_scorecard?vendor_name=eq.Pendo&select=category,subcategory,score`,
    { headers }
  );
  const pendoScores = await pendoRes.json();
  
  if (!pendoScores || pendoScores.length === 0) {
    console.log('[CompetitiveContext] No Pendo scorecard found');
    return [];
  }

  // Build Pendo lookup
  const pendoLookup = new Map<string, number>();
  for (const s of pendoScores) {
    pendoLookup.set(`${s.category}|${s.subcategory}`, s.score || 0);
  }

  const differentials: ScorecardDifferential[] = [];

  // Fetch scores for each competitor (in parallel)
  const competitorFetches = competitorNames.map(async (name) => {
    const encodedName = encodeURIComponent(name);
    const res = await fetch(
      `${supabaseUrl}/rest/v1/competitive_scorecard?vendor_name=eq.${encodedName}&select=category,subcategory,score`,
      { headers }
    );
    const scores = await res.json();
    if (!scores || scores.length === 0) return null;

    const advantages: ScorecardDifferential['advantages'] = [];
    const gaps: ScorecardDifferential['gaps'] = [];

    for (const cs of scores) {
      const key = `${cs.category}|${cs.subcategory}`;
      const pendoScore = pendoLookup.get(key) || 0;
      const competitorScore = cs.score || 0;
      
      // Skip if either is unscored (0)
      if (pendoScore === 0 && competitorScore === 0) continue;
      
      const delta = pendoScore - competitorScore;
      
      if (delta > 1) {
        // Pendo is significantly stronger
        advantages.push({
          category: cs.category,
          subcategory: cs.subcategory,
          pendoScore,
          competitorScore,
          delta,
        });
      } else if (delta < -1) {
        // Competitor is significantly stronger
        gaps.push({
          category: cs.category,
          subcategory: cs.subcategory,
          pendoScore,
          competitorScore,
          delta: Math.abs(delta),
        });
      }
    }

    // Sort by delta magnitude (most significant first)
    advantages.sort((a, b) => b.delta - a.delta);
    gaps.sort((a, b) => b.delta - a.delta);

    return {
      competitorName: name,
      advantages: advantages.slice(0, 10), // Top 10 advantages
      gaps: gaps.slice(0, 10), // Top 10 gaps
    };
  });

  const results = await Promise.all(competitorFetches);
  for (const r of results) {
    if (r) differentials.push(r);
  }

  console.log(`[CompetitiveContext] Fetched differentials for ${differentials.length} competitors`);
  return differentials;
}

// Format scorecard differentials for injection into competitive analysis prompt
export function formatScorecardContext(differentials: ScorecardDifferential[], maxChars: number = 2000): string {
  if (!differentials.length) return '';

  const sections: string[] = ['## COMPETITIVE SCORECARD INTELLIGENCE'];
  sections.push('Use these verified capability differentials to generate targeted competitive plays.\n');

  for (const diff of differentials) {
    sections.push(`### vs ${diff.competitorName}`);
    
    if (diff.advantages.length > 0) {
      sections.push('**Pendo Advantages (use for differentiation/landmine plays):**');
      for (const a of diff.advantages.slice(0, 5)) {
        sections.push(`  - ${a.subcategory} (${a.category}): Pendo=${a.pendoScore} vs ${diff.competitorName}=${a.competitorScore} [+${a.delta}]`);
      }
    }
    
    if (diff.gaps.length > 0) {
      sections.push('**Competitor Leads (prepare objection handlers):**');
      for (const g of diff.gaps.slice(0, 5)) {
        sections.push(`  - ${g.subcategory} (${g.category}): Pendo=${g.pendoScore} vs ${diff.competitorName}=${g.competitorScore} [-${g.delta}]`);
      }
    }
    
    if (diff.advantages.length === 0 && diff.gaps.length === 0) {
      sections.push('  No significant differentials found');
    }
  }

  let result = sections.join('\n');
  if (result.length > maxChars) {
    result = result.substring(0, maxChars) + '\n\n[Scorecard context truncated]';
  }
  return result;
}

// Use case context for competitive play generation
export interface UseCaseCompetitiveContext {
  id: string;
  useCase: string;
  functionalArea: string;
  businessTheme: string;
  priority: string;
  status: string;
  scorecardAlignment: 'pendo_strong' | 'competitor_strong' | 'neutral' | 'unknown';
  relevantCategories: string[];
}

// Map functional areas to scorecard categories
const FUNCTIONAL_AREA_TO_SCORECARD: Record<string, string[]> = {
  'Analytics & Insights': ['Product Analytics'],
  'Product Analytics': ['Product Analytics'],
  'Digital Adoption & In-App Guides': ['Guidance & In-App Experience'],
  'Guidance': ['Guidance & In-App Experience'],
  'AI & Automation': ['AI & Automation'],
  'Feedback & NPS': ['Feedback & NPS', 'AI & Automation'],
  'Session Replay': ['Session Replay & Heatmaps'],
  'Mobile': ['Mobile'],
  'Platform & Integrations': ['Platform & Integrations'],
  'Orchestration': ['Orchestration'],
  'Support & Community': ['Support & Community'],
};

export async function fetchUseCasesForCompetitive(
  supabaseUrl: string,
  supabaseKey: string,
  accountId: string,
  opportunityId: string | null,
  differentials: ScorecardDifferential[]
): Promise<UseCaseCompetitiveContext[]> {
  const headers = {
    "Authorization": `Bearer ${supabaseKey}`,
    "apikey": supabaseKey,
    "Content-Type": "application/json",
  };

  // Fetch use cases for this account/opportunity
  let query = `${supabaseUrl}/rest/v1/account_use_cases?account_id=eq.${accountId}&select=id,use_case,use_case_encrypted,functional_area,business_theme,priority,status,encryption_iv&limit=20`;
  if (opportunityId) {
    query += `&or=(opportunity_id.eq.${opportunityId},opportunity_id.is.null)`;
  }

  const res = await fetch(query, { headers });
  const rawUCs = await res.json();
  if (!rawUCs || rawUCs.length === 0) return [];

  const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');

  // Build a set of Pendo-strong and competitor-strong categories from differentials
  const pendoStrongCategories = new Set<string>();
  const competitorStrongCategories = new Set<string>();
  
  for (const diff of differentials) {
    for (const a of diff.advantages) pendoStrongCategories.add(a.category);
    for (const g of diff.gaps) competitorStrongCategories.add(g.category);
  }

  const results: UseCaseCompetitiveContext[] = [];
  
  for (const uc of rawUCs) {
    let useCaseName = uc.use_case;
    if (!useCaseName && uc.use_case_encrypted && uc.encryption_iv && encryptionKey) {
      try {
        useCaseName = await decryptValue(uc.use_case_encrypted, encryptionKey, uc.encryption_iv);
      } catch { useCaseName = ''; }
    }
    if (!useCaseName) continue;

    const functionalArea = uc.functional_area || 'General';
    const mappedCategories = FUNCTIONAL_AREA_TO_SCORECARD[functionalArea] || [];
    
    // Determine alignment
    let alignment: UseCaseCompetitiveContext['scorecardAlignment'] = 'unknown';
    if (mappedCategories.length > 0) {
      const pendoStrong = mappedCategories.some(c => pendoStrongCategories.has(c));
      const compStrong = mappedCategories.some(c => competitorStrongCategories.has(c));
      
      if (pendoStrong && !compStrong) alignment = 'pendo_strong';
      else if (compStrong && !pendoStrong) alignment = 'competitor_strong';
      else if (pendoStrong && compStrong) alignment = 'neutral';
    }

    results.push({
      id: uc.id,
      useCase: useCaseName,
      functionalArea,
      businessTheme: uc.business_theme || 'general',
      priority: uc.priority || 'medium',
      status: uc.status || 'identified',
      scorecardAlignment: alignment,
      relevantCategories: mappedCategories,
    });
  }

  console.log(`[CompetitiveContext] Fetched ${results.length} use cases (${results.filter(u => u.scorecardAlignment === 'pendo_strong').length} pendo-strong, ${results.filter(u => u.scorecardAlignment === 'competitor_strong').length} competitor-strong)`);
  return results;
}

// Format use case context for the competitive prompt
export function formatUseCaseContext(useCases: UseCaseCompetitiveContext[]): string {
  if (!useCases.length) return '';

  const sections: string[] = ['## CUSTOMER USE CASES & COMPETITIVE ALIGNMENT'];
  sections.push('Map competitive plays to these customer use cases. Generate ATTACK plays for Pendo-strong areas and DEFEND plays for competitor-strong areas.\n');

  const pendoStrong = useCases.filter(u => u.scorecardAlignment === 'pendo_strong');
  const compStrong = useCases.filter(u => u.scorecardAlignment === 'competitor_strong');
  const neutral = useCases.filter(u => u.scorecardAlignment === 'neutral' || u.scorecardAlignment === 'unknown');

  if (pendoStrong.length > 0) {
    sections.push('**ATTACK OPPORTUNITIES (Pendo advantage areas — expand the conversation here):**');
    for (const uc of pendoStrong) {
      sections.push(`  - [${uc.priority}] "${uc.useCase}" (${uc.functionalArea}) → maps to ${uc.relevantCategories.join(', ')} [ID: ${uc.id}]`);
    }
  }

  if (compStrong.length > 0) {
    sections.push('\n**DEFEND/MOAT AREAS (competitor stronger — build a moat, reframe, redirect):**');
    for (const uc of compStrong) {
      sections.push(`  - [${uc.priority}] "${uc.useCase}" (${uc.functionalArea}) → maps to ${uc.relevantCategories.join(', ')} [ID: ${uc.id}]`);
    }
  }

  if (neutral.length > 0) {
    sections.push('\n**NEUTRAL USE CASES (no clear advantage — differentiate on execution/value):**');
    for (const uc of neutral) {
      sections.push(`  - [${uc.priority}] "${uc.useCase}" (${uc.functionalArea}) [ID: ${uc.id}]`);
    }
  }

  sections.push('\nFor each competitive play, include the linkedUseCaseIds array with the relevant use case IDs.');
  sections.push('Set playStrategy to "attack" for Pendo-strong use cases and "defend" for competitor-strong use cases.');

  return sections.join('\n');
}

// Check if a meeting potentially completes any open NBAs
export function detectPotentialNBACompletions(
  transcript: string,
  openNBAs: AnalysisContext['openNBAs']
): { nbaId: string; confidence: number; reason: string }[] {
  const completions: { nbaId: string; confidence: number; reason: string }[] = [];
  const lowerTranscript = transcript.toLowerCase();
  
  for (const nba of openNBAs) {
    const lowerAction = nba.action.toLowerCase();
    
    // Extract key words from the action
    const keywords = lowerAction
      .split(/\s+/)
      .filter(w => w.length > 4 && !['will', 'should', 'would', 'could', 'need', 'with', 'about', 'their', 'there', 'these', 'those'].includes(w));
    
    // Check for completion indicators
    let matchCount = 0;
    for (const keyword of keywords) {
      if (lowerTranscript.includes(keyword)) matchCount++;
    }
    
    const matchRatio = keywords.length > 0 ? matchCount / keywords.length : 0;
    
    // Look for completion phrases
    const completionPhrases = [
      'completed', 'done', 'finished', 'sent', 'shared', 'provided',
      'reviewed', 'discussed', 'went through', 'covered', 'addressed',
      'here is', 'here\'s', 'attached', 'included', 'prepared'
    ];
    
    let hasCompletionPhrase = false;
    for (const phrase of completionPhrases) {
      if (lowerTranscript.includes(phrase)) {
        hasCompletionPhrase = true;
        break;
      }
    }
    
    if (matchRatio >= 0.5 && hasCompletionPhrase) {
      completions.push({
        nbaId: nba.id,
        confidence: Math.min(0.9, matchRatio + 0.2),
        reason: `Meeting discusses \"${keywords.slice(0, 3).join(', ')}\" with completion language`,
      });
    } else if (matchRatio >= 0.7) {
      completions.push({
        nbaId: nba.id,
        confidence: matchRatio * 0.7,
        reason: `Meeting references ${matchCount}/${keywords.length} keywords from action`,
      });
    }
  }
  
  return completions;
}

// Shared utilities for insight storage with JSONB and field-level encryption
// Used by unified-transcript-analysis and unified-reanalysis-queue

export interface InsightSnapshot {
  account_id: string;
  opportunity_id?: string;
  contact_id?: string; // For person-level insights (stakeholder assessments)
  source_transcript_id?: string;
  insight_type: 'pain_point' | 'use_case' | 'nba' | 'stakeholder' | 'metric' | 'technology' | 'strategic_theme' | 'health_indicator';
  data_cleartext: Record<string, any>;
  data_encrypted?: string;
  encryption_iv?: string;
  field_encryption_map: Record<string, boolean>;
  previous_snapshot_id?: string;
  change_source: 'transcript_analysis' | 'manual_edit' | 'reanalysis' | 'import';
  change_reason?: string;
}

// Fields that should be encrypted for each insight type
export const ENCRYPTED_FIELDS: Record<string, string[]> = {
  pain_point: ['description', 'context', 'evidence', 'recommendedApproach'],
  use_case: ['description', 'context', 'alignmentWithProduct'],
  nba: ['action', 'notes', 'reasoning'],
  stakeholder: ['name', 'email', 'phone', 'role', 'notes', 'quotes', 'advocacyExamples', 'infoSharingExamples'],
  metric: ['value', 'context', 'sourceQuote'],
  technology: ['context', 'notes', 'ownerName', 'ownerEmail'],
  strategic_theme: ['description', 'supportingEvidence', 'recommendedApproach', 'alignmentWithProduct'],
  health_indicator: ['summaryNarrative', 'keyRisks', 'keyOpportunities'],
};

// Fields that stay cleartext (for querying/aggregation)
export const CLEARTEXT_FIELDS: Record<string, string[]> = {
  pain_point: ['painCategory', 'severity', 'confidence', 'businessImpact', 'businessTheme', 'impactLevel', 'linkedPainCategories'],
  use_case: ['businessTheme', 'priority', 'confidence', 'status', 'functionalArea', 'linkedPainCategories', 'impactLevel', 'mentionedByType', 'acceptanceStatus'],
  nba: ['actionType', 'priority', 'status', 'ownerType', 'dueDate'],
  stakeholder: ['stakeholderType', 'influenceLevel', 'sentiment', 'championScore', 'isInternal', 'advocacyDetected', 'infoSharingDetected'],
  metric: ['metricName', 'metricCategory', 'metricNumericValue', 'confidence', 'needsReview', 'answerType'],
  technology: ['name', 'category', 'layer', 'relationshipStatus', 'confidence', 'needsReview'],
  strategic_theme: ['themeName', 'themeType', 'impactLevel', 'linkedPainCategories', 'linkedUseCases'],
  health_indicator: ['overallHealth', 'engagementTrend', 'competitiveThreat', 'expansionPotential'],
};

// Encryption helpers
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < raw.length && i < 32; i++) key[i] = raw[i];
  return key;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

export async function encryptJson(value: Record<string, any>, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plainBytes = new TextEncoder().encode(JSON.stringify(value));
  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plainBytes);
  return { ciphertext: bytesToBase64(new Uint8Array(cipherBytes)), iv: bytesToBase64(iv) };
}

// Split raw insight data into cleartext and encrypted portions
export function splitInsightData(
  insightType: string,
  rawData: Record<string, any>
): { cleartext: Record<string, any>; toEncrypt: Record<string, any>; fieldMap: Record<string, boolean> } {
  const encryptedFields = ENCRYPTED_FIELDS[insightType] || [];
  const cleartextFields = CLEARTEXT_FIELDS[insightType] || [];
  
  const cleartext: Record<string, any> = {};
  const toEncrypt: Record<string, any> = {};
  const fieldMap: Record<string, boolean> = {};
  
  for (const [key, value] of Object.entries(rawData)) {
    if (value === undefined || value === null) continue;
    
    if (encryptedFields.includes(key)) {
      toEncrypt[key] = value;
      fieldMap[key] = true;
    } else if (cleartextFields.includes(key)) {
      cleartext[key] = value;
      fieldMap[key] = false;
    } else {
      // Default: if it's a string longer than 50 chars, encrypt it
      if (typeof value === 'string' && value.length > 50) {
        toEncrypt[key] = value;
        fieldMap[key] = true;
      } else {
        cleartext[key] = value;
        fieldMap[key] = false;
      }
    }
  }
  
  return { cleartext, toEncrypt, fieldMap };
}

// Convert analysis results to insight snapshots
export async function createInsightSnapshots(
  analysisResult: any,
  accountId: string,
  opportunityId: string | undefined,
  transcriptId: string | undefined,
  encryptionKey: string,
  changeSource: 'transcript_analysis' | 'manual_edit' | 'reanalysis' | 'import' = 'transcript_analysis'
): Promise<InsightSnapshot[]> {
  const snapshots: InsightSnapshot[] = [];
  
  // Pain points
  for (const pp of (analysisResult.painPoints || [])) {
    const { cleartext, toEncrypt, fieldMap } = splitInsightData('pain_point', {
      description: pp.description,
      painCategory: pp.painCategory,
      businessImpact: pp.businessImpact,
      severity: pp.severity,
      confidence: pp.confidence,
      context: pp.context,
      evidence: pp.evidence,
    });
    
    let encryptedData: string | undefined;
    let iv: string | undefined;
    
    if (Object.keys(toEncrypt).length > 0) {
      const encrypted = await encryptJson(toEncrypt, encryptionKey);
      encryptedData = encrypted.ciphertext;
      iv = encrypted.iv;
    }
    
    snapshots.push({
      account_id: accountId,
      opportunity_id: opportunityId,
      source_transcript_id: transcriptId,
      insight_type: 'pain_point',
      data_cleartext: cleartext,
      data_encrypted: encryptedData,
      encryption_iv: iv,
      field_encryption_map: fieldMap,
      change_source: changeSource,
    });
  }
  
  // Use cases
  for (const uc of (analysisResult.useCases || [])) {
    // Determine status based on acceptance: validated/accepted = 'validated', proposed = 'identified'
    const statusFromAcceptance = (uc.acceptanceStatus === 'validated' || uc.acceptanceStatus === 'accepted') 
      ? 'validated' 
      : 'identified';
    
    const { cleartext, toEncrypt, fieldMap } = splitInsightData('use_case', {
      description: uc.description,
      businessTheme: uc.businessTheme,
      linkedPainCategories: uc.linkedPainCategories,
      priority: uc.priority,
      confidence: uc.confidence,
      status: statusFromAcceptance,
      functionalArea: uc.functionalArea || 'General',
      context: uc.context,
      // Speaker attribution
      mentionedByType: uc.mentionedByType || 'unknown',
      mentionedByName: uc.mentionedByName,
      mentionedByEmail: uc.mentionedByEmail,
      acceptanceStatus: uc.acceptanceStatus || 'proposed',
      acceptanceEvidence: uc.acceptanceEvidence,
    });
    
    let encryptedData: string | undefined;
    let iv: string | undefined;
    
    if (Object.keys(toEncrypt).length > 0) {
      const encrypted = await encryptJson(toEncrypt, encryptionKey);
      encryptedData = encrypted.ciphertext;
      iv = encrypted.iv;
    }
    
    snapshots.push({
      account_id: accountId,
      opportunity_id: opportunityId,
      source_transcript_id: transcriptId,
      insight_type: 'use_case',
      data_cleartext: cleartext,
      data_encrypted: encryptedData,
      encryption_iv: iv,
      field_encryption_map: fieldMap,
      change_source: changeSource,
    });
  }
  
  // NBAs
  for (const nba of (analysisResult.nbas || [])) {
    const { cleartext, toEncrypt, fieldMap } = splitInsightData('nba', {
      action: nba.action,
      actionType: nba.actionType,
      ownerType: nba.ownerType,
      ownerName: nba.ownerName,
      ownerEmail: nba.ownerEmail,
      priority: nba.priority,
      status: 'pending',
      notes: nba.notes,
      reasoning: nba.reasoning,
      dueDate: nba.dueDate,
    });
    
    let encryptedData: string | undefined;
    let iv: string | undefined;
    
    if (Object.keys(toEncrypt).length > 0) {
      const encrypted = await encryptJson(toEncrypt, encryptionKey);
      encryptedData = encrypted.ciphertext;
      iv = encrypted.iv;
    }
    
    snapshots.push({
      account_id: accountId,
      opportunity_id: opportunityId,
      source_transcript_id: transcriptId,
      insight_type: 'nba',
      data_cleartext: cleartext,
      data_encrypted: encryptedData,
      encryption_iv: iv,
      field_encryption_map: fieldMap,
      change_source: changeSource,
    });
  }
  
  // Stakeholders/People - split into internal (team members) and external (stakeholders)
  const internalPeople = (analysisResult.people || []).filter((p: any) => p.isInternal);
  const externalPeople = (analysisResult.people || []).filter((p: any) => !p.isInternal);
  
  // Store internal people for later processing (will be added to team tables by caller)
  if (internalPeople.length > 0) {
    (snapshots as any).__internalTeamMembers = internalPeople;
  }
  
  // External stakeholders
  for (const person of externalPeople) {
    const { cleartext, toEncrypt, fieldMap } = splitInsightData('stakeholder', {
      name: person.name,
      role: person.role,
      email: person.email,
      phone: person.phone,
      stakeholderType: person.stakeholderType,
      influenceLevel: person.influenceLevel,
      sentiment: person.sentiment,
      championScore: person.championScore,
      isInternal: person.isInternal,
      notes: person.context,
      quotes: person.advocacySignals?.examples || [],
      // Cleartext flags for querying
      advocacyDetected: person.advocacySignals?.detected || false,
      infoSharingDetected: person.infoSharingSignals?.detected || false,
      // Encrypted detailed examples
      advocacyExamples: person.advocacySignals?.examples || [],
      infoSharingExamples: person.infoSharingSignals?.examples || [],
    });
    
    let encryptedData: string | undefined;
    let iv: string | undefined;
    
    if (Object.keys(toEncrypt).length > 0) {
      const encrypted = await encryptJson(toEncrypt, encryptionKey);
      encryptedData = encrypted.ciphertext;
      iv = encrypted.iv;
    }
    
    snapshots.push({
      account_id: accountId,
      opportunity_id: opportunityId,
      // Note: contact_id would be set later when matching to existing contacts
      source_transcript_id: transcriptId,
      insight_type: 'stakeholder',
      data_cleartext: cleartext,
      data_encrypted: encryptedData,
      encryption_iv: iv,
      field_encryption_map: fieldMap,
      change_source: changeSource,
    });
  }
  
  // Metrics
  for (const metric of (analysisResult.operationalMetrics || [])) {
    const { cleartext, toEncrypt, fieldMap } = splitInsightData('metric', {
      metricName: metric.metricName,
      metricCategory: metric.metricCategory,
      metricNumericValue: metric.metricNumericValue,
      value: metric.metricValue,
      confidence: metric.confidence,
      needsReview: metric.needsReview,
      context: metric.context,
    });
    
    let encryptedData: string | undefined;
    let iv: string | undefined;
    
    if (Object.keys(toEncrypt).length > 0) {
      const encrypted = await encryptJson(toEncrypt, encryptionKey);
      encryptedData = encrypted.ciphertext;
      iv = encrypted.iv;
    }
    
    snapshots.push({
      account_id: accountId,
      opportunity_id: opportunityId,
      source_transcript_id: transcriptId,
      insight_type: 'metric',
      data_cleartext: cleartext,
      data_encrypted: encryptedData,
      encryption_iv: iv,
      field_encryption_map: fieldMap,
      change_source: changeSource,
    });
  }
  
  // Technologies
  for (const tech of (analysisResult.technologies || [])) {
    const { cleartext, toEncrypt, fieldMap } = splitInsightData('technology', {
      name: tech.name,
      category: tech.suggestedLayer,
      layer: tech.suggestedLayer,
      relationshipStatus: tech.relationshipStatus,
      confidence: tech.confidence,
      needsReview: tech.needsReview,
      context: tech.context,
      ownerName: tech.ownerName,
      ownerEmail: tech.ownerEmail,
    });
    
    let encryptedData: string | undefined;
    let iv: string | undefined;
    
    if (Object.keys(toEncrypt).length > 0) {
      const encrypted = await encryptJson(toEncrypt, encryptionKey);
      encryptedData = encrypted.ciphertext;
      iv = encrypted.iv;
    }
    
    snapshots.push({
      account_id: accountId,
      opportunity_id: opportunityId,
      source_transcript_id: transcriptId,
      insight_type: 'technology',
      data_cleartext: cleartext,
      data_encrypted: encryptedData,
      encryption_iv: iv,
      field_encryption_map: fieldMap,
      change_source: changeSource,
    });
  }
  
  return snapshots;
}

// Save snapshots to database
export async function saveInsightSnapshots(
  supabaseUrl: string,
  supabaseKey: string,
  snapshots: InsightSnapshot[]
): Promise<{ saved: number; errors: string[] }> {
  const errors: string[] = [];
  let saved = 0;
  
  for (const snapshot of snapshots) {
    try {
      const response = await fetch(`${supabaseUrl}/rest/v1/account_insight_snapshots`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseKey}`,
          'apikey': supabaseKey,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal',
        },
        body: JSON.stringify({
          account_id: snapshot.account_id,
          opportunity_id: snapshot.opportunity_id,
          contact_id: snapshot.contact_id, // For person-level insights
          source_transcript_id: snapshot.source_transcript_id,
          insight_type: snapshot.insight_type,
          data_cleartext: snapshot.data_cleartext,
          data_encrypted: snapshot.data_encrypted,
          encryption_iv: snapshot.encryption_iv,
          field_encryption_map: snapshot.field_encryption_map,
          previous_snapshot_id: snapshot.previous_snapshot_id,
          change_source: snapshot.change_source,
          change_reason: snapshot.change_reason,
        }),
      });
      
      if (!response.ok) {
        const text = await response.text();
        errors.push(`Failed to save ${snapshot.insight_type}: ${text}`);
      } else {
        saved++;
      }
    } catch (err) {
      errors.push(`Error saving ${snapshot.insight_type}: ${err}`);
    }
  }
  
  return { saved, errors };
}

// Add internal team members discovered in transcripts to opportunity and account team tables
export async function addInternalTeamMembers(
  supabaseUrl: string,
  supabaseKey: string,
  accountId: string,
  opportunityId: string | undefined,
  transcriptId: string | undefined,
  internalPeople: Array<{ name: string; email?: string; role?: string }>
): Promise<{ added: number; errors: string[] }> {
  const errors: string[] = [];
  let added = 0;
  
  for (const person of internalPeople) {
    // We need an email to add to team tables
    // If no email, try to infer from name (e.g., "David Curtis" -> david.curtis@pendo.io)
    let email = person.email?.toLowerCase()?.trim();
    
    if (!email && person.name) {
      // Try to infer @pendo.io email from name
      const nameParts = person.name.trim().toLowerCase().split(/\s+/);
      if (nameParts.length >= 2) {
        email = `${nameParts[0]}.${nameParts[nameParts.length - 1]}@pendo.io`;
      }
    }
    
    if (!email) continue;
    
    // Add to account_team_members
    try {
      const accResponse = await fetch(`${supabaseUrl}/rest/v1/account_team_members`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseKey}`,
          'apikey': supabaseKey,
          'Content-Type': 'application/json',
          'Prefer': 'resolution=merge-duplicates,return=minimal',
        },
        body: JSON.stringify({
          account_id: accountId,
          team_member_email: email,
          role: person.role || 'participant',
          is_encrypted: false,
        }),
      });
      
      if (accResponse.ok || accResponse.status === 409) {
        added++;
      } else {
        const text = await accResponse.text();
        // Don't log duplicate errors
        if (!text.includes('duplicate') && !text.includes('unique')) {
          errors.push(`Failed to add ${email} to account team: ${text}`);
        }
      }
    } catch (err) {
      errors.push(`Error adding ${email} to account team: ${err}`);
    }
    
    // Add to opportunity_team_members if we have an opportunity
    if (opportunityId) {
      try {
        const oppResponse = await fetch(`${supabaseUrl}/rest/v1/opportunity_team_members`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'apikey': supabaseKey,
            'Content-Type': 'application/json',
            'Prefer': 'resolution=merge-duplicates,return=minimal',
          },
          body: JSON.stringify({
            opportunity_id: opportunityId,
            team_member_email: email,
            role: person.role || 'participant',
            is_encrypted: false,
          }),
        });
        
        if (!oppResponse.ok && oppResponse.status !== 409) {
          const text = await oppResponse.text();
          if (!text.includes('duplicate') && !text.includes('unique')) {
            errors.push(`Failed to add ${email} to opportunity team: ${text}`);
          }
        }
      } catch (err) {
        errors.push(`Error adding ${email} to opportunity team: ${err}`);
      }
    }
  }
  
  return { added, errors };
}

// Extract internal team members from snapshots (used after createInsightSnapshots)
export function extractInternalTeamMembers(snapshots: InsightSnapshot[]): Array<{ name: string; email?: string; role?: string }> {
  return (snapshots as any).__internalTeamMembers || [];
}

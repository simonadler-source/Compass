// Shared prompt library - reads prompts from analysis_passes table
// This enables database-driven prompts with versioning and dependencies

export interface AnalysisPass {
  id: string;
  pass_key: string;
  name: string;
  system_prompt: string;
  output_schema: any;
  sort_order: number;
  max_tokens?: number;
  timeout_seconds?: number;
  is_async?: boolean;
  status: 'active' | 'draft' | 'deprecated';
  dependencies?: string[];
  condition_config?: {
    meeting_types?: string[];
  } | null;
}

export interface AnalysisPipeline {
  id: string;
  name: string;
  passes: AnalysisPass[];
}

// Unified taxonomy for pain categories (TYPE of pain, not business outcome)
export const PAIN_CATEGORIES = [
  "vendor_relationship",      // Support gaps, responsiveness, partnership issues
  "technical_limitations",    // Platform gaps, missing features, integration friction
  "operational_friction",     // Process inefficiencies, manual work, workarounds
  "resource_constraints",     // Skills, time, budget limitations
  "strategic_misalignment"    // Tool doesn't match business direction
] as const;

// Business impact tags (potential outcomes if pain is solved)
export const BUSINESS_IMPACTS = [
  "revenue_enablement",
  "cost_reduction", 
  "risk_mitigation",
  "efficiency_gains"
] as const;

// Business themes for use cases (what they want to ACCOMPLISH)
export const BUSINESS_THEMES = [
  "operational_efficiency",
  "customer_experience", 
  "revenue_growth",
  "cost_reduction",
  "compliance_risk",
  "digital_transformation",
  "data_insights",
  "team_productivity"
] as const;

// Fetch the default pipeline with all active passes
export async function getDefaultPipeline(supabaseUrl: string, supabaseKey: string): Promise<AnalysisPipeline | null> {
  try {
    // Fetch default pipeline
    const pipelineRes = await fetch(
      `${supabaseUrl}/rest/v1/analysis_pipelines?is_default=eq.true&is_active=eq.true&select=id,name&limit=1`,
      {
        headers: {
          "Authorization": `Bearer ${supabaseKey}`,
          "apikey": supabaseKey,
        },
      }
    );

    if (!pipelineRes.ok) {
      console.error("Failed to fetch pipeline:", await pipelineRes.text());
      return null;
    }

    const pipelines = await pipelineRes.json();
    if (!pipelines || pipelines.length === 0) {
      console.log("No default pipeline found, using fallback prompts");
      return null;
    }

    const pipeline = pipelines[0];

    // Fetch active passes for this pipeline with dependencies
    // NOTE: analysis_pass_dependencies has TWO relationships back to analysis_passes
    // (pass_id and depends_on_pass_id). PostgREST requires disambiguation.
    // We want the dependencies *for each pass*, i.e. analysis_pass_dependencies.pass_id -> analysis_passes.id
    const passesRes = await fetch(
      `${supabaseUrl}/rest/v1/analysis_passes?pipeline_id=eq.${pipeline.id}&status=eq.active&select=id,pass_key,name,system_prompt,output_schema,sort_order,max_tokens,timeout_seconds,is_async,status,condition_config,analysis_pass_dependencies!analysis_pass_dependencies_pass_id_fkey(depends_on_pass_id,dependency_type,field_mappings)&order=sort_order`,
      {
        headers: {
          "Authorization": `Bearer ${supabaseKey}`,
          "apikey": supabaseKey,
        },
      }
    );

    if (!passesRes.ok) {
      console.error("Failed to fetch passes:", await passesRes.text());
      return null;
    }

    const passes = await passesRes.json();
    
    // Map dependencies to pass keys
    const passKeyMap = new Map(passes.map((p: any) => [p.id, p.pass_key]));
    
    const mappedPasses: AnalysisPass[] = passes.map((p: any) => ({
      id: p.id,
      pass_key: p.pass_key,
      name: p.name,
      system_prompt: p.system_prompt,
      output_schema: p.output_schema,
      sort_order: p.sort_order,
      max_tokens: p.max_tokens,
      timeout_seconds: p.timeout_seconds,
      is_async: p.is_async,
      status: p.status,
      dependencies: p.analysis_pass_dependencies?.map((d: any) => passKeyMap.get(d.depends_on_pass_id)) || [],
      condition_config: p.condition_config || null,
    }));

    console.log(`Loaded pipeline "${pipeline.name}" with ${mappedPasses.length} active passes`);
    
    return {
      id: pipeline.id,
      name: pipeline.name,
      passes: mappedPasses,
    };
  } catch (error) {
    console.error("Error loading pipeline:", error);
    return null;
  }
}

// Get a specific pass by key
export async function getPassByKey(supabaseUrl: string, supabaseKey: string, passKey: string): Promise<AnalysisPass | null> {
  try {
    const res = await fetch(
      `${supabaseUrl}/rest/v1/analysis_passes?pass_key=eq.${passKey}&status=eq.active&select=id,pass_key,name,system_prompt,output_schema,sort_order,max_tokens,timeout_seconds,is_async,status&limit=1`,
      {
        headers: {
          "Authorization": `Bearer ${supabaseKey}`,
          "apikey": supabaseKey,
        },
      }
    );

    if (!res.ok) return null;

    const passes = await res.json();
    return passes.length > 0 ? passes[0] : null;
  } catch (error) {
    console.error("Error loading pass:", error);
    return null;
  }
}

// Fallback schemas when database is unavailable - aligned with DB pass_keys
// OPTIMIZATION: Added maxItems limits to control token usage
export const FALLBACK_SCHEMAS = {
  // Maps to DB pass_key: core_extraction
  core_extraction: {
    type: "object",
    properties: {
      technologies: {
        type: "array",
        maxItems: 20,
        items: {
          type: "object",
          properties: {
            name: { type: "string" },
            confidence: { type: "number" },
            suggestedLayer: { type: "string", enum: ["host", "build", "adopt", "growth", "ops"] },
            context: { type: "string", maxLength: 200 },
            relationshipStatus: { type: "string", enum: ["mentioned", "experience", "in_use", "evaluating", "considering", "replaced"] },
            needsReview: { type: "boolean" }
          },
          required: ["name", "confidence", "suggestedLayer", "context", "relationshipStatus", "needsReview"],
          additionalProperties: false
        }
      },
      people: {
        type: "array",
        maxItems: 15,
        items: {
          type: "object",
          properties: {
            name: { type: "string" },
            role: { type: "string" },
            email: { type: "string" },
            context: { type: "string", maxLength: 150 },
            stakeholderType: { type: "string", enum: ["champion", "economic_buyer", "decision_criteria_owner", "coach", "blocker", "end_user", "unknown"] },
            influenceLevel: { type: "number" },
            sentiment: { type: "number" },
            championScore: { type: "number" },
            isInternal: { type: "boolean" }
          },
          required: ["name", "context", "stakeholderType", "isInternal"],
          additionalProperties: false
        }
      },
      nbas: {
        type: "array",
        maxItems: 5,
        items: {
          type: "object",
          properties: {
            action: { type: "string", maxLength: 200 },
            actionType: { type: "string", enum: ["poc_setup", "integration_review", "security_assessment", "architecture_doc", "technical_deepdive", "api_exploration", "performance_benchmark", "follow_up_meeting", "send_content", "internal_discussion"] },
            ownerType: { type: "string", enum: ["prospect", "sales_rep", "sales_engineer"] },
            ownerName: { type: "string" },
            ownerEmail: { type: "string" },
            priority: { type: "string", enum: ["high", "medium", "low"] },
            reasoning: { type: "string", maxLength: 150 },
            dueDate: { type: "string" }
          },
          required: ["action", "actionType", "ownerType", "priority", "reasoning"],
          additionalProperties: false
        }
      },
      painPoints: { 
        type: "array",
        maxItems: 8,
        items: { 
          type: "object",
          properties: {
            description: { type: "string", maxLength: 200 },
            painCategory: { type: "string", enum: PAIN_CATEGORIES as unknown as string[] },
            businessImpact: { type: "array", items: { type: "string", enum: BUSINESS_IMPACTS as unknown as string[] }, maxItems: 2 },
            severity: { type: "string", enum: ["high", "medium", "low"] },
            confidence: { type: "number" }
          },
          required: ["description", "painCategory", "severity", "confidence"],
          additionalProperties: false
        }
      },
      useCases: { 
        type: "array",
        maxItems: 8,
        items: { 
          type: "object",
          properties: {
            description: { type: "string", maxLength: 200 },
            businessTheme: { type: "string", enum: BUSINESS_THEMES as unknown as string[] },
            linkedPainCategories: { type: "array", items: { type: "string", enum: PAIN_CATEGORIES as unknown as string[] }, maxItems: 3 },
            priority: { type: "string", enum: ["high", "medium", "low"] },
            confidence: { type: "number" },
            mentionedByType: { type: "string", enum: ["internal", "external", "unknown"] },
            mentionedByName: { type: "string" },
            mentionedByEmail: { type: "string" },
            acceptanceStatus: { type: "string", enum: ["validated", "proposed", "accepted"] },
            acceptanceEvidence: { type: "string", maxLength: 200 }
          },
          required: ["description", "businessTheme", "priority", "confidence", "mentionedByType", "acceptanceStatus"],
          additionalProperties: false
        }
      },
      competitorMentions: { type: "array", items: { type: "string" }, maxItems: 10 },
      contentTypeDetection: {
        type: "object",
        properties: {
          contentType: { type: "string", enum: ["email", "meeting"] },
          emailType: { type: "string", enum: ["followup", "proposal", "introduction", "status_update", "technical", "scheduling", "other"] },
          confidence: { type: "number" }
        },
        required: ["contentType", "confidence"],
        additionalProperties: false
      },
      meetingPurpose: {
        type: "object",
        properties: {
          meetingType: { 
            type: "string", 
            enum: ["discovery", "demo", "technical", "evaluation_workshop", "workshop", "dry_run", "executive", "commercial", "negotiation", "contract", "check_in", "training", "onboarding", "qbr"]
          },
          confidence: { type: "number" },
          reasoning: { type: "string", maxLength: 200 }
        },
        required: ["meetingType", "confidence", "reasoning"],
        additionalProperties: false
      }
    },
    required: ["technologies", "people", "nbas", "painPoints", "useCases", "competitorMentions", "contentTypeDetection", "meetingPurpose"]
  },

  // Maps to DB pass_key: call_summary (runs after core_extraction)
  call_summary: {
    type: "object",
    properties: {
      callSummary: {
        type: "object",
        properties: {
          quickRecap: { type: "string" },
          themeSections: {
            type: "array",
            maxItems: 8,
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                content: { type: "string" }
              },
              required: ["title", "content"],
              additionalProperties: false
            }
          },
          nextSteps: {
            type: "array",
            maxItems: 15,
            items: {
              type: "object",
              properties: {
                action: { type: "string" },
                owner: { type: "string" }
              },
              required: ["action"],
              additionalProperties: false
            }
          },
          suggestedActions: {
            type: "array",
            maxItems: 8,
            items: {
              type: "object",
              properties: {
                action: { type: "string" },
                rationale: { type: "string" }
              },
              required: ["action"],
              additionalProperties: false
            }
          },
          attendees: {
            type: "object",
            properties: {
              internal: { type: "array", items: { type: "object", properties: { name: { type: "string" }, role: { type: "string" } }, required: ["name"], additionalProperties: false }, maxItems: 10 },
              external: { type: "array", items: { type: "object", properties: { name: { type: "string" }, role: { type: "string" } }, required: ["name"], additionalProperties: false }, maxItems: 15 }
            },
            additionalProperties: false
          },
          durationMinutes: { type: "number" },
          opportunityContext: { type: "string" }
        },
        required: ["quickRecap", "themeSections", "nextSteps"],
        additionalProperties: false
      }
    },
    required: ["callSummary"]
  },
  
  // Maps to DB pass_key: stage_assessment
  stage_assessment: {
    type: "object",
    properties: {
      salesStageAssessment: {
        type: "object",
        properties: {
          stage: { type: "number" },
          stageName: { type: "string" },
          phase: { type: "string", enum: ["Pipeline Generation", "Visible Opportunity", "Value Realization"] },
          confidence: { type: "number" },
          reasoning: { type: "string" },
          exitCriteriaMet: { type: "array", items: { type: "string" } },
          exitCriteriaNotMet: { type: "array", items: { type: "string" } }
        },
        required: ["stage", "stageName", "phase", "confidence", "reasoning"]
      },
      preSalesStageAssessment: {
        type: "object",
        properties: {
          stage: { type: "string", enum: ["Not Started", "Discovery", "Demo", "Proof - Scoping", "Proof", "Technical Win", "Technical Loss", "Stale / Not Active", "Unqualified"] },
          confidence: { type: "number" },
          reasoning: { type: "string" },
          evidenceForStage: { type: "array", items: { type: "string" } }
        },
        required: ["stage", "confidence", "reasoning"]
      },
      commercialInsights: {
        type: "array",
        items: {
          type: "object",
          properties: {
            insight: { type: "string" },
            type: { type: "string", enum: ["build_vs_buy", "budget_timing", "competitive_positioning", "stakeholder_dynamics"] },
            swotCategory: { type: "string", enum: ["strength", "weakness", "opportunity", "threat"] },
            importance: { type: "string", enum: ["high", "medium", "low"] },
            context: { type: "string" }
          },
          required: ["insight", "type", "swotCategory", "importance", "context"]
        }
      },
      operationalMetrics: {
        type: "array",
        items: {
          type: "object",
          properties: {
            metricName: { type: "string" },
            metricValue: { type: "string" },
            metricNumericValue: { type: "number", nullable: true },
            metricCategory: { type: "string" },
            confidence: { type: "number" },
            needsReview: { type: "boolean" },
            context: { type: "string" }
          },
          required: ["metricName", "metricValue", "metricCategory", "confidence", "needsReview", "context"]
        }
      },
      discoveryQuestions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            question: { type: "string" },
            category: { type: "string" },
            functionalArea: { type: "string" },
            context: { type: "string" }
          },
          required: ["question", "category", "functionalArea", "context"]
        }
      }
    },
    required: ["salesStageAssessment", "preSalesStageAssessment", "commercialInsights", "operationalMetrics", "discoveryQuestions"]
  },

  // Maps to DB pass_key: enrichment_detection
  enrichment_detection: {
    type: "object",
    properties: {
      detectionMatches: {
        type: "array",
        items: {
          type: "object",
          properties: {
            ruleId: { type: "string" },
            ruleName: { type: "string" },
            confidence: { type: "number" },
            matchedPhrases: { type: "array", items: { type: "string" } },
            capturedFields: { type: "object" }
          },
          required: ["ruleId", "ruleName", "confidence"]
        }
      }
    },
    required: ["detectionMatches"]
  },

  // Maps to DB pass_key: enrichment_readiness
  enrichment_readiness: {
    type: "object",
    properties: {
      readinessAnswers: {
        type: "array",
        items: {
          type: "object",
          properties: {
            questionId: { type: "string" },
            answer: { type: "string" },
            confidence: { type: "number" },
            source: { type: "string" }
          },
          required: ["questionId", "answer", "confidence"]
        }
      },
      productMentions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            product: { type: "string" },
            context: { type: "string" },
            sentiment: { type: "string", enum: ["positive", "neutral", "negative"] },
            usageLevel: { type: "string", enum: ["heavy", "moderate", "light", "evaluating"] }
          },
          required: ["product", "context"]
        }
      }
    },
    required: ["readinessAnswers", "productMentions"]
  },

  // Maps to DB pass_key: account_synthesis
  account_synthesis: {
    type: "object",
    properties: {
      strategicThemes: {
        type: "array",
        items: {
          type: "object",
          properties: {
            themeName: { type: "string" },
            themeType: { type: "string", enum: ["pain", "use_case", "priority"] },
            description: { type: "string" },
            impactLevel: { type: "string", enum: ["high", "medium", "low"] },
            itemCount: { type: "number" },
            supportingEvidence: { type: "array", items: { type: "string" } }
          },
          required: ["themeName", "themeType", "description", "impactLevel"]
        }
      },
      healthIndicators: {
        type: "array",
        items: {
          type: "object",
          properties: {
            indicator: { type: "string" },
            status: { type: "string", enum: ["positive", "neutral", "negative"] },
            evidence: { type: "string" }
          },
          required: ["indicator", "status", "evidence"]
        }
      }
    },
    required: ["strategicThemes", "healthIndicators"]
  }
};

// Fallback prompts when database is unavailable - aligned with DB pass_keys
export const FALLBACK_PROMPTS = {
  core_extraction: `You are an AI analyzing sales communications. Extract strategic insights with UNIFIED TAXONOMY:

## PAIN POINTS - Categorize by TYPE of pain:
- vendor_relationship: Support gaps, lack of assistance, responsiveness issues, partnership friction
- technical_limitations: Platform gaps, missing features, integration friction, scalability issues
- operational_friction: Process inefficiencies, manual workarounds, slow execution
- resource_constraints: Skill gaps, time limitations, budget pressures
- strategic_misalignment: Tool doesn't match business direction, outgrowing solution

Also tag BUSINESS IMPACT if solved: revenue_enablement, cost_reduction, risk_mitigation, efficiency_gains

## USE CASES - What they want to ACCOMPLISH:
Theme by business objective: operational_efficiency, customer_experience, revenue_growth, cost_reduction, compliance_risk, digital_transformation, data_insights, team_productivity
Link to pain categories it addresses.

CRITICAL - Use Case Speaker Attribution:
For EACH use case, you MUST determine WHO mentioned it:
- mentionedByType: "external" = prospect/customer mentioned this need, "internal" = Pendo team member suggested it
- mentionedByName/mentionedByEmail: The person who first stated this use case
- acceptanceStatus: 
  - "validated" = Use ONLY if a PROSPECT/CUSTOMER explicitly stated this use case themselves
  - "proposed" = Use when an INTERNAL Pendo team member suggested this use case and the prospect did NOT confirm
  - "accepted" = Use when an internal team member suggested it AND the prospect confirmed with verbal agreement (e.g., "yes", "that's right", "exactly") OR engaged with follow-up questions/discussion about it

Examples:
- Prospect says "We want to improve onboarding completion rates" → mentionedByType: "external", acceptanceStatus: "validated"
- SE says "Would in-app guides help with onboarding?" and prospect says "Yes, that would be great" → mentionedByType: "internal", acceptanceStatus: "accepted", acceptanceEvidence: "Prospect confirmed: 'Yes, that would be great'"
- SE mentions "Analytics dashboards" but prospect doesn't respond or changes topic → mentionedByType: "internal", acceptanceStatus: "proposed"

## PEOPLE - MEDDIC Assessment with scores:
- stakeholderType: champion/economic_buyer/decision_criteria_owner/coach/blocker/end_user/unknown
- influenceLevel (0-100): C-level=80-100, Director=60-80, Manager=40-60, IC=20-40
- sentiment (0-100): Enthusiastic=80-100, Positive=60-80, Neutral=40-60, Skeptical=20-40
- championScore (0-100): ONLY >50 if BOTH advocacy AND info sharing signals

## NEXT BEST ACTIONS (MAX 5 - Quality over quantity)
CRITICAL CONSOLIDATION RULES:
- Generate at most 5 NBAs per transcript. Fewer is better.
- NEVER generate multiple "follow_up_meeting" NBAs — consolidate into ONE follow-up with combined agenda items.
- NEVER generate an NBA that restates an existing open action item (check EXISTING OPEN ACTION ITEMS in context).
- Each NBA must be a SPECIFIC, DISTINCT action — not a generic "align on next steps" or "continue the conversation".
- Prefer actions with concrete deliverables (e.g., "Send integration architecture diagram for X" not "Send over information").
- If a meeting naturally concluded with agreed next steps, capture those. Don't invent additional ones.

Include specific owner name and email from transcript. Assign to: prospect, sales_rep, or sales_engineer.
For each action, suggest a due date based on:
- Explicit deadlines mentioned in transcript
- Follow-up meetings: 2-3 business days
- Send content/docs: 1-2 business days
- POC setup: 1-2 weeks
- Technical deep-dives: 1 week
- Security assessments: 2-3 weeks
Use ISO date format (YYYY-MM-DD). Today's date context will be provided.

## TECHNOLOGIES
With relationship status: mentioned, in_use, evaluating, considering, replaced

## MEETING PURPOSE CLASSIFICATION
Determine the PRIMARY purpose of this meeting:
- discovery: Initial qualification, needs finding, open-ended exploration
- demo: Product demonstration, feature walkthrough
- technical: Architecture review, integration planning, API deep-dive
- evaluation_workshop: Hands-on POC, evaluation session
- workshop: Collaborative working session (non-evaluation)
- dry_run: Practice demo, presentation rehearsal
- executive: C-level briefing
- commercial: Pricing, proposal review
- negotiation: Contract term negotiation
- contract: Legal/MSA review
- check_in: Regular status update
- training: User training/enablement
- onboarding: Customer setup/go-live
- qbr: Quarterly business review

Assess confidence (0-1).

IMPORTANT: Consolidate similar items. Be specific about categories.`,

  call_summary: `You are a senior sales analyst generating executive-quality meeting summaries.

Given the transcript and extracted insights from the core extraction pass, generate a comprehensive structured summary.

## CALL SUMMARY — THIS IS THE MOST IMPORTANT OUTPUT
Generate a rich, executive-quality structured summary of this meeting/call. This should be comprehensive enough that someone who missed the call can fully understand what happened.

- quickRecap: Write a 4-6 sentence comprehensive overview. Include: who was on the call (by name), what the main topics were, what decisions were reached, and the overall sentiment/outcome. Be specific — mention product names, features, timelines, and numbers discussed.

- themeSections: Group the discussion into 3-6 themed sections with descriptive titles (e.g., "Technical Implementation and Data Privacy", "User Rollout and Segmentation"). Each section should be 4-8 sentences capturing the key points, decisions, concerns raised, and context. Write as if briefing a manager.

- nextSteps: List ALL concrete next steps agreed during the call. Be maximally specific — include the person's NAME, the exact deliverable, and timing if mentioned.

- suggestedActions: Recommend 3-6 internal follow-up actions for the SE/AE team. These are NOT agreed next steps but strategic recommendations.

- attendees: Separate internal (your company) and external (prospect/customer) attendees. Include roles when mentioned or inferable.

- opportunityContext: One sentence on how this call advances the deal.

The summary should read like a professional Momentum-style meeting recap — detailed, actionable, and complete.`,

  stage_assessment: `Analyze this sales transcript for:
1. Sales Stage (0-6): 0=Initial contact, 1=Info sharing, 2=Problem discussion, 3=Solution benefits, 4=Procurement access, 5=Purchase ready, 6=Active user
2. Pre-Sales Stage: Not Started, Discovery, Demo, Proof-Scoping, Proof, Technical Win/Loss, Stale, Unqualified
3. Commercial Insights (SWOT): Strengths, Weaknesses, Opportunities, Threats
4. Operational Metrics mentioned (with numeric values when available)
5. Discovery Questions asked or implied`,

  enrichment_detection: `Match transcript content against detection rules provided in context.
For each rule that matches, extract any captured fields defined by the rule.
Only report matches with confidence > 0.6.`,

  enrichment_readiness: `Extract answers to technical readiness questions from the transcript.
Also identify any product usage mentions with context and sentiment.`,

  account_synthesis: `Synthesize the extracted insights into strategic themes and health indicators.
Group related pain points and use cases into coherent themes.
Assess overall account health based on sentiment, engagement, and risk signals.`
};

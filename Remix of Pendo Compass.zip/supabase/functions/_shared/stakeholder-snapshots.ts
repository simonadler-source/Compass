// Stakeholder snapshot management
// Creates and updates contact_meeting_snapshots for trajectory tracking

export interface StakeholderMeetingData {
  contactId: string;
  transcriptId: string;
  meetingDate: string;
  opportunityId?: string;
  
  // Assessment scores
  championScore?: number;
  sentiment?: number;
  influenceLevel?: number;
  engagementScore?: number;
  
  // Contextual data
  topicsDiscussed?: string[];
  keyQuotes?: string[];
  concernsRaised?: string[];
  actionItems?: string[];
  notes?: string;
  
  // Meeting metadata
  meetingType?: string;
}

// Encryption helpers
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < raw.length && i < 32; i++) key[i] = raw[i];
  return key;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

async function encryptValue(value: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plainBytes = new TextEncoder().encode(value);
  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plainBytes);
  return { ciphertext: bytesToBase64(new Uint8Array(cipherBytes)), iv: bytesToBase64(iv) };
}

// Create a meeting snapshot for a stakeholder
export async function createStakeholderSnapshot(
  supabaseUrl: string,
  supabaseKey: string,
  accountId: string,
  data: StakeholderMeetingData,
  encryptionKey?: string
): Promise<{ success: boolean; snapshotId?: string; error?: string }> {
  try {
    const headers = {
      "Authorization": `Bearer ${supabaseKey}`,
      "apikey": supabaseKey,
      "Content-Type": "application/json",
      "Prefer": "return=representation",
    };

    // Prepare encrypted fields if key provided
    let encryptedFields: Record<string, any> = {};
    let iv: string | undefined;
    
    if (encryptionKey) {
      // Encrypt PII and sensitive text
      if (data.keyQuotes?.length) {
        const result = await encryptValue(JSON.stringify(data.keyQuotes), encryptionKey);
        encryptedFields.key_quotes_encrypted = result.ciphertext;
        iv = result.iv;
      }
      if (data.concernsRaised?.length) {
        const result = await encryptValue(JSON.stringify(data.concernsRaised), encryptionKey);
        encryptedFields.concerns_raised_encrypted = result.ciphertext;
        if (!iv) iv = result.iv;
      }
      if (data.actionItems?.length) {
        const result = await encryptValue(JSON.stringify(data.actionItems), encryptionKey);
        encryptedFields.action_items_encrypted = result.ciphertext;
        if (!iv) iv = result.iv;
      }
      if (data.topicsDiscussed?.length) {
        const result = await encryptValue(JSON.stringify(data.topicsDiscussed), encryptionKey);
        encryptedFields.topics_discussed_encrypted = result.ciphertext;
        if (!iv) iv = result.iv;
      }
      if (data.notes) {
        const result = await encryptValue(data.notes, encryptionKey);
        encryptedFields.notes_encrypted = result.ciphertext;
        if (!iv) iv = result.iv;
      }
    }

    const snapshotData = {
      contact_id: data.contactId,
      transcript_id: data.transcriptId,
      meeting_date: data.meetingDate,
      opportunity_id: data.opportunityId,
      champion_score: data.championScore,
      sentiment: data.sentiment,
      influence_level: data.influenceLevel,
      engagement_score: data.engagementScore,
      meeting_type: data.meetingType,
      // Store plaintext if no encryption, encrypted otherwise
      topics_discussed: encryptionKey ? null : data.topicsDiscussed,
      key_quotes: encryptionKey ? null : data.keyQuotes,
      concerns_raised: encryptionKey ? null : data.concernsRaised,
      action_items: encryptionKey ? null : data.actionItems,
      notes: encryptionKey ? null : data.notes,
      // Add encrypted fields
      ...encryptedFields,
      encryption_iv: iv,
      is_encrypted: !!encryptionKey && iv !== undefined,
    };

    const response = await fetch(
      `${supabaseUrl}/rest/v1/contact_meeting_snapshots`,
      {
        method: "POST",
        headers,
        body: JSON.stringify(snapshotData),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Failed to create stakeholder snapshot:", errorText);
      return { success: false, error: errorText };
    }

    const result = await response.json();
    return { success: true, snapshotId: result[0]?.id };
  } catch (error) {
    console.error("Error creating stakeholder snapshot:", error);
    return { success: false, error: String(error) };
  }
}

// Create snapshots for all stakeholders mentioned in analysis results
export async function createSnapshotsFromAnalysis(
  supabaseUrl: string,
  supabaseKey: string,
  accountId: string,
  transcriptId: string,
  meetingDate: string,
  analysisResults: any,
  opportunityId?: string,
  encryptionKey?: string
): Promise<{ created: number; errors: string[] }> {
  const headers = {
    "Authorization": `Bearer ${supabaseKey}`,
    "apikey": supabaseKey,
    "Content-Type": "application/json",
  };

  const people = analysisResults.people || [];
  const errors: string[] = [];
  let created = 0;

  // First, get existing contacts for matching
  const contactsRes = await fetch(
    `${supabaseUrl}/rest/v1/account_contacts?account_id=eq.${accountId}&is_internal=eq.false&select=id,name_encrypted,email_encrypted,encryption_iv`,
    { headers }
  );
  const existingContacts = await contactsRes.json();

  for (const person of people) {
    if (person.isInternal) continue; // Skip internal team members

    // Find matching contact by name or email
    let matchedContactId: string | null = null;
    
    // Try to match by exact name/email (simplified - in production would decrypt and compare)
    for (const contact of existingContacts) {
      // This is a simplified match - in production you'd decrypt and compare
      if (contact.id && person.name) {
        // For now, we'll create or use the most recent contact
        // A full implementation would do proper name matching
        matchedContactId = contact.id;
        break;
      }
    }

    if (!matchedContactId) {
      // Contact not found - would need to create one first
      // Skip for now to avoid orphaned snapshots
      continue;
    }

    const snapshotData: StakeholderMeetingData = {
      contactId: matchedContactId,
      transcriptId,
      meetingDate,
      opportunityId,
      championScore: person.championScore,
      sentiment: person.sentiment,
      influenceLevel: person.influenceLevel,
      engagementScore: person.engagementScore,
      topicsDiscussed: person.topicsDiscussed || [],
      keyQuotes: person.advocacySignals?.examples || [],
      concernsRaised: person.concerns || [],
      notes: person.context,
      meetingType: analysisResults.meetingType || 'call',
    };

    const result = await createStakeholderSnapshot(
      supabaseUrl,
      supabaseKey,
      accountId,
      snapshotData,
      encryptionKey
    );

    if (result.success) {
      created++;
    } else {
      errors.push(`Failed to create snapshot for ${person.name}: ${result.error}`);
    }
  }

  return { created, errors };
}

// Update the current contact record with latest snapshot data
export async function updateContactFromSnapshot(
  supabaseUrl: string,
  supabaseKey: string,
  contactId: string,
  championScore: number,
  sentiment: number,
  influenceLevel?: number,
  stakeholderType?: string
): Promise<boolean> {
  try {
    const headers = {
      "Authorization": `Bearer ${supabaseKey}`,
      "apikey": supabaseKey,
      "Content-Type": "application/json",
      "Prefer": "return=minimal",
    };

    const updateData: Record<string, any> = {
      updated_at: new Date().toISOString(),
    };

    // Only update if values are meaningful
    if (championScore > 0) updateData.champion_score = championScore;
    if (sentiment > 0) updateData.sentiment = sentiment;
    if (influenceLevel && influenceLevel > 0) updateData.influence_level = influenceLevel;
    if (stakeholderType) updateData.stakeholder_type = stakeholderType;

    const response = await fetch(
      `${supabaseUrl}/rest/v1/account_contacts?id=eq.${contactId}`,
      {
        method: "PATCH",
        headers,
        body: JSON.stringify(updateData),
      }
    );

    return response.ok;
  } catch (error) {
    console.error("Error updating contact from snapshot:", error);
    return false;
  }
}

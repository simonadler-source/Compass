import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function htmlResponse(html: string): Response {
  return new Response(html, {
    status: 200,
    headers: {
      "Content-Type": "text/html",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    },
  });
}

type ItemType = "nba" | "milestone" | "validation";

type ActionKind = "complete" | "cancel" | "delay" | "in_progress" | "skip";

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    const action = url.searchParams.get("action") as ActionKind | null;
    const days = parseInt(url.searchParams.get("days") || "1");
    const type = (url.searchParams.get("type") || "nba") as ItemType;

    if (!id || !action) {
      throw new Error("Missing required parameters");
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const appUrl = Deno.env.get("APP_URL") || "https://sependo.org";

    // Helpers - redirect to a dedicated confirmation page (doesn't require auth)
    const redirectSuccess = ({
      title,
      subtitle,
    }: {
      title: string;
      subtitle?: string;
    }) => {
      const params = new URLSearchParams({
        status: "success",
        title: title,
        ...(subtitle && { message: subtitle }),
      });
      const redirectUrl = `${appUrl}/action-confirmed?${params.toString()}`;
      
      return new Response(null, {
        status: 302,
        headers: {
          ...corsHeaders,
          "Location": redirectUrl,
        },
      });
    };

    const redirectError = (message: string) => {
      const params = new URLSearchParams({
        status: "error",
        title: "Error",
        message: message,
      });
      const redirectUrl = `${appUrl}/action-confirmed?${params.toString()}`;
      
      return new Response(null, {
        status: 302,
        headers: {
          ...corsHeaders,
          "Location": redirectUrl,
        },
      });
    };

    // -------------------------
    // NBA
    // -------------------------
    if (type === "nba") {
      const { data: nba, error: fetchError } = await supabase
        .from("account_nbas")
        .select("id, action, due_date, account_id, assigned_to")
        .eq("id", id)
        .single();

      if (fetchError || !nba) throw new Error("Action not found");

      let updateData: any = {};
      let title = "Updated";
      let icon = "✅";

      switch (action) {
        case "complete":
          updateData = { status: "completed", completed_at: new Date().toISOString() };
          title = "Action marked as complete!";
          icon = "✅";
          break;
        case "cancel":
          updateData = { status: "cancelled", completed_at: new Date().toISOString() };
          title = "Action cancelled.";
          icon = "❌";
          break;
        case "delay": {
          const currentDueDate = nba.due_date ? new Date(nba.due_date) : new Date();
          const newDueDate = new Date(currentDueDate.getTime() + days * 24 * 60 * 60 * 1000);
          updateData = { due_date: newDueDate.toISOString() };

          await supabase.from("nba_due_date_changes").insert({
            nba_id: id,
            previous_due_date: nba.due_date,
            new_due_date: newDueDate.toISOString(),
            change_type: "postponed",
            days_changed: days,
            change_reason: "Delayed via email",
            changed_by_email: nba.assigned_to || "email-action",
          });

          title = `Due date delayed by ${days} day${days > 1 ? "s" : ""}.`;
          icon = "📅";
          break;
        }
        default:
          throw new Error("Invalid action");
      }

      const { error: updateError } = await supabase.from("account_nbas").update(updateData).eq("id", id);
      if (updateError) throw updateError;

      return redirectSuccess({
        title,
        subtitle: nba.action || "Action item",
      });
    }

    // -------------------------
    // Milestone (timeline)
    // -------------------------
    if (type === "milestone") {
      const { data: milestone, error: msErr } = await supabase
        .from("opportunity_milestones")
        .select("id, name, opportunity_id, scheduled_date, status, phase")
        .eq("id", id)
        .single();

      if (msErr || !milestone) throw new Error("Timeline item not found");

      const { data: opp, error: oppErr } = await supabase
        .from("opportunities")
        .select("id, account_id")
        .eq("id", milestone.opportunity_id)
        .single();

      if (oppErr || !opp) throw new Error("Opportunity not found");

      let updateData: any = {};
      let title = "Timeline updated";
      let icon = "✅";

      switch (action) {
        case "complete":
          updateData = {
            status: "completed",
            completed_date: new Date().toISOString().split("T")[0],
          };
          title = "Timeline task marked complete!";
          icon = "✅";
          break;
        case "in_progress":
          updateData = { status: "in_progress" };
          title = "Timeline task set to in progress.";
          icon = "▶️";
          break;
        case "skip":
          updateData = { status: "skipped" };
          title = "Timeline task skipped.";
          icon = "⏭️";
          break;
        default:
          throw new Error("Invalid action for milestone");
      }

      const { error: upErr } = await supabase.from("opportunity_milestones").update(updateData).eq("id", id);
      if (upErr) throw upErr;

      return redirectSuccess({
        title,
        subtitle: milestone.name || milestone.phase || "Timeline task",
      });
    }

    // -------------------------
    // Validation tasks (optional)
    // -------------------------
    if (type === "validation") {
      const { data: task, error: tErr } = await supabase
        .from("opportunity_validation_tasks")
        .select("id, activity, opportunity_id, status")
        .eq("id", id)
        .single();

      if (tErr || !task) throw new Error("Validation task not found");

      const { data: opp, error: oppErr } = await supabase
        .from("opportunities")
        .select("id, account_id")
        .eq("id", task.opportunity_id)
        .single();

      if (oppErr || !opp) throw new Error("Opportunity not found");

      let updateData: any = {};
      let title = "Task updated";
      let icon = "✅";

      switch (action) {
        case "complete":
          updateData = { status: "completed", completed_at: new Date().toISOString() };
          title = "Validation task marked complete!";
          icon = "✅";
          break;
        case "in_progress":
          updateData = { status: "in_progress" };
          title = "Validation task set to in progress.";
          icon = "▶️";
          break;
        case "skip":
          updateData = { status: "skipped" };
          title = "Validation task skipped.";
          icon = "⏭️";
          break;
        default:
          throw new Error("Invalid action for validation task");
      }

      const { error: upErr } = await supabase.from("opportunity_validation_tasks").update(updateData).eq("id", id);
      if (upErr) throw upErr;

      return redirectSuccess({
        title,
        subtitle: task.activity || "Validation task",
      });
    }

    throw new Error("Invalid type");
  } catch (error: any) {
    console.error("Error in action-update function:", error);
    const msg = error?.message || "Unable to update this item.";
    const appUrl = Deno.env.get("APP_URL") || "https://sependo.org";
    const params = new URLSearchParams({ toast: "error", title: msg });
    return new Response(null, {
      status: 302,
      headers: { ...corsHeaders, "Location": `${appUrl}/?${params.toString()}` },
    });
  }
};

Deno.serve(handler);

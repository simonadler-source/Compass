import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation schema
const ResetMfaInputSchema = z.object({
  userId: z.string().uuid("Invalid user ID").optional(),
  factorType: z.enum(["totp", "phone", "all"]).optional().default("totp"),
});

type ResetMfaBody = {
  userId?: string;
  factorType?: "totp" | "phone" | "all";
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error("Backend is not configured");
    }

    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace("Bearer ", "").trim();
    if (!token) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Service role client for admin operations
    const adminClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false },
    });

    // Validate current user
    const { data: userData, error: userError } = await adminClient.auth.getUser(token);
    if (userError || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const requester = userData.user;

    let rawBody: unknown = {};
    try {
      rawBody = await req.json();
    } catch {
      rawBody = {};
    }

    // Validate input with zod
    const parseResult = ResetMfaInputSchema.safeParse(rawBody);
    if (!parseResult.success) {
      console.error("Input validation failed:", parseResult.error.errors);
      return new Response(
        JSON.stringify({ 
          error: "Invalid input", 
          details: parseResult.error.errors.map(e => `${e.path.join('.')}: ${e.message}`)
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { userId, factorType } = parseResult.data;
    const targetUserId = userId ?? requester.id;

    // Allow users to reset their own factors. Resetting someone else's requires admin.
    if (targetUserId !== requester.id) {
      const { data: isAdmin, error: adminCheckError } = await adminClient.rpc("is_admin", {
        _user_id: requester.id,
      });

      if (adminCheckError || isAdmin !== true) {
        return new Response(JSON.stringify({ error: "Forbidden" }), {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    const { data: factorsRes, error: listError } = await adminClient.auth.admin.mfa.listFactors({
      userId: targetUserId,
    });

    if (listError) {
      return new Response(JSON.stringify({ error: listError.message }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const factors = (factorsRes?.factors ?? []) as any[];
    const filtered = factors.filter((f) => {
      if (factorType === "all") return true;
      return f.factor_type === factorType;
    });

    const deleted: string[] = [];
    const errors: Array<{ id: string; error: string }> = [];

    for (const f of filtered) {
      const { error: delError } = await adminClient.auth.admin.mfa.deleteFactor({
        userId: targetUserId,
        id: f.id,
      });

      if (delError) {
        errors.push({ id: f.id, error: delError.message });
      } else {
        deleted.push(f.id);
      }
    }

    return new Response(
      JSON.stringify({
        ok: true,
        targetUserId,
        deleted,
        errors,
        totalFactors: factors.length,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("admin-reset-mfa error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

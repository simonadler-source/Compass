import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CoachingRule {
  id: string;
  name: string;
  description: string;
  cooldownDays: number;
  priority: 'high' | 'medium' | 'low';
}

const COACHING_RULES: CoachingRule[] = [
  {
    id: 'stale_champion',
    name: 'Stale Champion Contact',
    description: 'Champion stakeholder has not been contacted in 14+ days',
    cooldownDays: 7,
    priority: 'high',
  },
  {
    id: 'no_executive_sponsor',
    name: 'Missing Executive Sponsor',
    description: 'High-value or late-stage deal is missing an executive sponsor',
    cooldownDays: 14,
    priority: 'high',
  },
  {
    id: 'engagement_decline',
    name: 'Engagement Declining',
    description: 'Meeting frequency has dropped 50%+ compared to previous period',
    cooldownDays: 14,
    priority: 'medium',
  },
  {
    id: 'deal_velocity_slow',
    name: 'Deal Velocity Below Average',
    description: 'Deal has been in current stage 50% longer than historical average',
    cooldownDays: 14,
    priority: 'medium',
  },
  {
    id: 'competitor_mentioned',
    name: 'Competitor Recently Mentioned',
    description: 'Competitor was mentioned in a recent meeting',
    cooldownDays: 7,
    priority: 'medium',
  },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseKey);

  const stats = {
    opportunitiesProcessed: 0,
    alertsGenerated: 0,
    alertsSkippedCooldown: 0,
    ruleResults: {} as Record<string, { triggered: number; skipped: number }>,
  };

  // Initialize rule stats
  COACHING_RULES.forEach(rule => {
    stats.ruleResults[rule.id] = { triggered: 0, skipped: 0 };
  });

  try {
    console.log('[AI Coaching] Starting coaching alert evaluation...');

    // Fetch active opportunities (not archived, not closed)
    const { data: opportunities, error: oppError } = await supabase
      .from('opportunities')
      .select(`
        id,
        name,
        account_id,
        sales_stage,
        pre_sales_stage,
        stage_changed_at,
        value,
        close_date,
        owner_id,
        primary_se_email,
        created_at,
        accounts(name, owner_id, primary_se_email)
      `)
      .eq('is_archived', false)
      .not('sales_stage', 'in', '("closed_won","closed_lost","Closed Won","Closed Lost")')
      .limit(500);

    if (oppError) {
      console.error('[AI Coaching] Error fetching opportunities:', oppError);
      throw oppError;
    }

    console.log(`[AI Coaching] Found ${opportunities?.length || 0} active opportunities`);
    stats.opportunitiesProcessed = opportunities?.length || 0;

    // Fetch recent coaching NBAs to check cooldowns
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const { data: recentCoachingNBAs } = await supabase
      .from('account_nbas')
      .select('opportunity_id, notes, created_at')
      .eq('action_type', 'coaching')
      .gte('created_at', thirtyDaysAgo.toISOString());

    // Build cooldown map: opp_id -> rule_id -> last_created_at
    const cooldownMap = new Map<string, Map<string, Date>>();
    recentCoachingNBAs?.forEach((nba: any) => {
      if (!nba.opportunity_id || !nba.notes) return;
      
      // Extract rule ID from notes (format: "AI Coaching: ... (rule_id)")
      const ruleMatch = nba.notes.match(/\((\w+)\)$/);
      if (!ruleMatch) return;
      
      const ruleId = ruleMatch[1];
      const oppMap = cooldownMap.get(nba.opportunity_id) || new Map();
      const existing = oppMap.get(ruleId);
      const nbaDate = new Date(nba.created_at);
      
      if (!existing || nbaDate > existing) {
        oppMap.set(ruleId, nbaDate);
        cooldownMap.set(nba.opportunity_id, oppMap);
      }
    });

    // Fetch stakeholders for champion check
    const { data: contacts } = await supabase
      .from('account_contacts')
      .select('id, account_id, opportunity_id, champion_score, stakeholder_type')
      .gte('champion_score', 70);

    // Fetch recent meetings for engagement check
    const { data: transcripts } = await supabase
      .from('transcript_reviews')
      .select('opportunity_id, created_at')
      .eq('status', 'approved')
      .not('opportunity_id', 'is', null)
      .gte('created_at', new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString());

    // Fetch stage history for velocity check
    const { data: stageHistory } = await supabase
      .from('opportunity_stage_history')
      .select('opportunity_id, stage_type, old_value, new_value, changed_at, duration_in_previous_stage')
      .order('changed_at', { ascending: false });

    // Fetch competitor detection matches
    const { data: competitorMatches } = await supabase
      .from('detection_rule_matches')
      .select(`
        opportunity_id, 
        created_at,
        detection_rules!inner(rule_type, name)
      `)
      .eq('detection_rules.rule_type', 'competitor')
      .gte('created_at', new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString());

    // Fetch contact meeting snapshots for last contact dates
    const { data: contactSnapshots } = await supabase
      .from('contact_meeting_snapshots')
      .select('contact_id, meeting_date')
      .order('meeting_date', { ascending: false });

    // Build helper maps
    const championsByOpp = new Map<string, any[]>();
    contacts?.forEach((c: any) => {
      const oppId = c.opportunity_id;
      if (!oppId) return;
      const list = championsByOpp.get(oppId) || [];
      list.push(c);
      championsByOpp.set(oppId, list);
    });

    const meetingsByOpp = new Map<string, Date[]>();
    transcripts?.forEach((t: any) => {
      if (!t.opportunity_id) return;
      const list = meetingsByOpp.get(t.opportunity_id) || [];
      list.push(new Date(t.created_at));
      meetingsByOpp.set(t.opportunity_id, list);
    });

    const lastContactByChampion = new Map<string, Date>();
    contactSnapshots?.forEach((s: any) => {
      const existing = lastContactByChampion.get(s.contact_id);
      const meetingDate = new Date(s.meeting_date);
      if (!existing || meetingDate > existing) {
        lastContactByChampion.set(s.contact_id, meetingDate);
      }
    });

    const competitorsByOpp = new Map<string, string[]>();
    competitorMatches?.forEach((m: any) => {
      if (!m.opportunity_id) return;
      const list = competitorsByOpp.get(m.opportunity_id) || [];
      list.push(m.detection_rules?.name || 'Unknown');
      competitorsByOpp.set(m.opportunity_id, list);
    });

    // Calculate stage averages
    const stageDurations: Record<string, number[]> = {};
    stageHistory?.forEach((h: any) => {
      if (!h.duration_in_previous_stage || !h.old_value) return;
      // Parse interval to days (rough estimate)
      const intervalMatch = h.duration_in_previous_stage.match(/(\d+)\s*days?/i);
      if (intervalMatch) {
        const days = parseInt(intervalMatch[1]);
        const stage = h.old_value.toLowerCase();
        stageDurations[stage] = stageDurations[stage] || [];
        stageDurations[stage].push(days);
      }
    });

    const stageAverages: Record<string, number> = {};
    Object.entries(stageDurations).forEach(([stage, durations]) => {
      if (durations.length > 0) {
        stageAverages[stage] = durations.reduce((a, b) => a + b, 0) / durations.length;
      }
    });

    const nbasToCreate: any[] = [];

    // Check cooldown helper
    const isInCooldown = (oppId: string, ruleId: string, cooldownDays: number): boolean => {
      const oppCooldowns = cooldownMap.get(oppId);
      if (!oppCooldowns) return false;
      
      const lastCreated = oppCooldowns.get(ruleId);
      if (!lastCreated) return false;
      
      const daysSinceCreated = (Date.now() - lastCreated.getTime()) / (1000 * 60 * 60 * 24);
      return daysSinceCreated < cooldownDays;
    };

    // Process each opportunity
    for (const opp of opportunities || []) {
      const assignee = opp.primary_se_email || (opp.accounts as any)?.primary_se_email || null;

      // Rule 1: Stale Champion
      const rule1 = COACHING_RULES.find(r => r.id === 'stale_champion')!;
      const champions = championsByOpp.get(opp.id) || [];
      for (const champion of champions) {
        const lastContact = lastContactByChampion.get(champion.id);
        const daysSinceContact = lastContact 
          ? Math.floor((Date.now() - lastContact.getTime()) / (1000 * 60 * 60 * 24))
          : 999;

        if (daysSinceContact >= 14) {
          if (isInCooldown(opp.id, rule1.id, rule1.cooldownDays)) {
            stats.ruleResults[rule1.id].skipped++;
            stats.alertsSkippedCooldown++;
          } else {
            nbasToCreate.push({
              account_id: opp.account_id,
              opportunity_id: opp.id,
              action_type: 'coaching',
              action: `Re-engage champion stakeholder - ${daysSinceContact} days since last contact`,
              notes: `AI Coaching: ${rule1.name} (${rule1.id})`,
              priority: rule1.priority,
              status: 'pending',
              assigned_to: assignee,
            });
            stats.ruleResults[rule1.id].triggered++;
            break; // One alert per opportunity for this rule
          }
        }
      }

      // Rule 2: No Executive Sponsor
      const rule2 = COACHING_RULES.find(r => r.id === 'no_executive_sponsor')!;
      const isHighValue = (opp.value || 0) >= 50000;
      const isLateStage = ['evaluation', 'proposal', 'closing', 'negotiation'].includes(
        (opp.sales_stage || '').toLowerCase()
      );

      if (isHighValue || isLateStage) {
        const hasExecSponsor = contacts?.some((c: any) => 
          c.opportunity_id === opp.id && 
          ['executive_sponsor', 'economic_buyer', 'decision_maker'].includes(c.stakeholder_type?.toLowerCase())
        );

        if (!hasExecSponsor) {
          if (isInCooldown(opp.id, rule2.id, rule2.cooldownDays)) {
            stats.ruleResults[rule2.id].skipped++;
            stats.alertsSkippedCooldown++;
          } else {
            nbasToCreate.push({
              account_id: opp.account_id,
              opportunity_id: opp.id,
              action_type: 'coaching',
              action: `Identify executive sponsor - ${isHighValue ? 'High-value' : 'Late-stage'} deal missing key stakeholder`,
              notes: `AI Coaching: ${rule2.name} (${rule2.id})`,
              priority: rule2.priority,
              status: 'pending',
              assigned_to: assignee,
            });
            stats.ruleResults[rule2.id].triggered++;
          }
        }
      }

      // Rule 3: Engagement Decline
      const rule3 = COACHING_RULES.find(r => r.id === 'engagement_decline')!;
      const meetings = meetingsByOpp.get(opp.id) || [];
      const now = Date.now();
      const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
      
      const recentMeetings = meetings.filter(d => now - d.getTime() < thirtyDaysMs).length;
      const previousMeetings = meetings.filter(d => {
        const age = now - d.getTime();
        return age >= thirtyDaysMs && age < thirtyDaysMs * 2;
      }).length;

      if (previousMeetings >= 2 && recentMeetings <= previousMeetings * 0.5) {
        if (isInCooldown(opp.id, rule3.id, rule3.cooldownDays)) {
          stats.ruleResults[rule3.id].skipped++;
          stats.alertsSkippedCooldown++;
        } else {
          nbasToCreate.push({
            account_id: opp.account_id,
            opportunity_id: opp.id,
            action_type: 'coaching',
            action: `Re-engage account - Meeting frequency dropped from ${previousMeetings} to ${recentMeetings} in last 30 days`,
            notes: `AI Coaching: ${rule3.name} (${rule3.id})`,
            priority: rule3.priority,
            status: 'pending',
            assigned_to: assignee,
          });
          stats.ruleResults[rule3.id].triggered++;
        }
      }

      // Rule 4: Deal Velocity Slow
      const rule4 = COACHING_RULES.find(r => r.id === 'deal_velocity_slow')!;
      if (opp.stage_changed_at && opp.sales_stage) {
        const daysInStage = Math.floor(
          (Date.now() - new Date(opp.stage_changed_at).getTime()) / (1000 * 60 * 60 * 24)
        );
        const stageLower = opp.sales_stage.toLowerCase();
        const avgDays = stageAverages[stageLower];

        if (avgDays && daysInStage > avgDays * 1.5) {
          if (isInCooldown(opp.id, rule4.id, rule4.cooldownDays)) {
            stats.ruleResults[rule4.id].skipped++;
            stats.alertsSkippedCooldown++;
          } else {
            nbasToCreate.push({
              account_id: opp.account_id,
              opportunity_id: opp.id,
              action_type: 'coaching',
              action: `Review deal progress - ${daysInStage} days in ${opp.sales_stage} stage (avg: ${Math.round(avgDays)} days)`,
              notes: `AI Coaching: ${rule4.name} (${rule4.id})`,
              priority: rule4.priority,
              status: 'pending',
              assigned_to: assignee,
            });
            stats.ruleResults[rule4.id].triggered++;
          }
        }
      }

      // Rule 5: Competitor Mentioned
      const rule5 = COACHING_RULES.find(r => r.id === 'competitor_mentioned')!;
      const competitors = competitorsByOpp.get(opp.id) || [];
      if (competitors.length > 0) {
        if (isInCooldown(opp.id, rule5.id, rule5.cooldownDays)) {
          stats.ruleResults[rule5.id].skipped++;
          stats.alertsSkippedCooldown++;
        } else {
          const uniqueComps = [...new Set(competitors)].slice(0, 3);
          nbasToCreate.push({
            account_id: opp.account_id,
            opportunity_id: opp.id,
            action_type: 'coaching',
            action: `Prepare competitive response - ${uniqueComps.join(', ')} mentioned recently`,
            notes: `AI Coaching: ${rule5.name} (${rule5.id})`,
            priority: rule5.priority,
            status: 'pending',
            assigned_to: assignee,
          });
          stats.ruleResults[rule5.id].triggered++;
        }
      }
    }

    // Insert NBAs
    if (nbasToCreate.length > 0) {
      console.log(`[AI Coaching] Creating ${nbasToCreate.length} coaching NBAs...`);
      
      const { error: insertError } = await supabase
        .from('account_nbas')
        .insert(nbasToCreate);

      if (insertError) {
        console.error('[AI Coaching] Error inserting NBAs:', insertError);
        throw insertError;
      }
      
      stats.alertsGenerated = nbasToCreate.length;
    }

    // Log stats for observability
    console.log('[AI Coaching] Evaluation complete:', JSON.stringify(stats, null, 2));

    // Store stats in a simple log table if it exists (optional)
    try {
      await supabase.from('system_logs').insert({
        log_type: 'ai_coaching_run',
        log_data: stats,
        created_at: new Date().toISOString(),
      });
    } catch {
      // Table might not exist, that's fine
    }

    return new Response(
      JSON.stringify({
        success: true,
        stats,
        message: `Processed ${stats.opportunitiesProcessed} opportunities, generated ${stats.alertsGenerated} alerts, skipped ${stats.alertsSkippedCooldown} due to cooldown`,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('[AI Coaching] Error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        stats 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});

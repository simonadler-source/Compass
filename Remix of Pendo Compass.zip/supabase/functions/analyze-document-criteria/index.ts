import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { opportunity_id, document_content, document_name } = await req.json();
    if (!opportunity_id || !document_content) {
      return new Response(JSON.stringify({ error: "opportunity_id and document_content required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { Authorization: `Bearer ${serviceKey}`, apikey: serviceKey };

    // Fetch opportunity details + competitors + modules + milestones + existing use cases + existing criteria in parallel
    const [oppRes, competitorsRes, scorecardRes, milestonesRes, useCasesRes, modulesRes, rubricRes, existingCriteriaRes] = await Promise.all([
      fetch(`${supabaseUrl}/rest/v1/opportunities?id=eq.${opportunity_id}&select=id,name,sales_stage,pre_sales_stage,close_date,included_module_ids,account_id`, { headers }),
      fetch(`${supabaseUrl}/rest/v1/opportunity_competitive_insights?opportunity_id=eq.${opportunity_id}&select=competitor_name,technology_id`, { headers }),
      fetch(`${supabaseUrl}/rest/v1/competitive_scorecard?vendor_name=eq.Pendo&select=subcategory,category,score`, { headers }),
      fetch(`${supabaseUrl}/rest/v1/opportunity_milestones?opportunity_id=eq.${opportunity_id}&select=name,scheduled_date,status,phase&order=scheduled_date.asc`, { headers }),
      fetch(`${supabaseUrl}/rest/v1/account_use_cases?opportunity_id=eq.${opportunity_id}&select=id,use_case,functional_area,acceptance_status,business_outcome&not.acceptance_status=is.null`, { headers }),
      fetch(`${supabaseUrl}/rest/v1/module_pricing?select=id,module_name,description`, { headers }),
      fetch(`${supabaseUrl}/rest/v1/competitive_rubric?select=category,subcategory,level_1_description,level_3_description,level_5_description&order=category,subcategory`, { headers }),
      fetch(`${supabaseUrl}/rest/v1/evaluation_success_criteria?opportunity_id=eq.${opportunity_id}&select=id,criterion,status,notes,metric_name,target_value,source&order=created_at.asc`, { headers }),
    ]);

    const opportunity = (await oppRes.json())?.[0];
    if (!opportunity) {
      return new Response(JSON.stringify({ error: "Opportunity not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const competitorsRaw = await competitorsRes.json();
    const competitors = Array.isArray(competitorsRaw) ? competitorsRaw : [];
    const pendoScoresRaw = await scorecardRes.json();
    const pendoScores = Array.isArray(pendoScoresRaw) ? pendoScoresRaw : [];
    const milestonesRaw = await milestonesRes.json();
    const milestones = Array.isArray(milestonesRaw) ? milestonesRaw : [];
    const useCasesRaw = await useCasesRes.json();
    const useCases = Array.isArray(useCasesRaw) ? useCasesRaw : [];
    const allModulesRaw = await modulesRes.json();
    const allModules = Array.isArray(allModulesRaw) ? allModulesRaw : [];
    const rubricRaw = await rubricRes.json();
    const rubric = Array.isArray(rubricRaw) ? rubricRaw : [];
    const existingCriteriaRaw = await existingCriteriaRes.json();
    const existingCriteria = Array.isArray(existingCriteriaRaw) ? existingCriteriaRaw : [];

    // Fetch competitor scorecard data for detected competitors
    const competitorNames = [...new Set(competitors.map((c: any) => c.competitor_name))];
    let competitorScores: any[] = [];
    if (competitorNames.length > 0) {
      const namesFilter = competitorNames.map((n: string) => `"${n}"`).join(",");
      const compScoreRes = await fetch(
        `${supabaseUrl}/rest/v1/competitive_scorecard?vendor_name=in.(${namesFilter})&select=vendor_name,subcategory,category,score`,
        { headers }
      );
      const compScoreRaw = await compScoreRes.json();
      competitorScores = Array.isArray(compScoreRaw) ? compScoreRaw : [];
    }

    // Build differentiation analysis
    const differentiationMap: Record<string, { pendoScore: number; competitors: Record<string, number> }> = {};
    for (const ps of pendoScores) {
      differentiationMap[ps.subcategory] = { pendoScore: ps.score, competitors: {} };
    }
    for (const cs of competitorScores) {
      if (differentiationMap[cs.subcategory]) {
        differentiationMap[cs.subcategory].competitors[cs.vendor_name] = cs.score;
      }
    }

    // Find areas where Pendo leads
    const strongAreas = Object.entries(differentiationMap)
      .filter(([_, data]) => {
        const maxCompScore = Math.max(0, ...Object.values(data.competitors));
        return data.pendoScore > maxCompScore && data.pendoScore >= 3;
      })
      .map(([subcategory, data]) => ({
        subcategory,
        pendoScore: data.pendoScore,
        maxCompetitorScore: Math.max(0, ...Object.values(data.competitors)),
        advantage: data.pendoScore - Math.max(0, ...Object.values(data.competitors)),
      }))
      .sort((a, b) => b.advantage - a.advantage);

    // Find competitor weaknesses (for landmines)
    const competitorWeaknesses = Object.entries(differentiationMap)
      .filter(([_, data]) => {
        const minCompScore = Math.min(5, ...Object.values(data.competitors));
        return data.pendoScore >= 3 && minCompScore <= 2;
      })
      .map(([subcategory, data]) => ({
        subcategory,
        pendoScore: data.pendoScore,
        weakCompetitors: Object.entries(data.competitors)
          .filter(([_, score]) => score <= 2)
          .map(([name, score]) => ({ name, score })),
      }));

    // Build included modules context
    const includedModules = allModules.filter((m: any) => 
      opportunity.included_module_ids?.includes(m.id)
    );

    // Build the AI prompt
    const systemPrompt = `You are a strategic pre-sales consultant specializing in product evaluation criteria design.
Your job is to analyze evaluation documents (RFPs, eval plans, scorecards, meeting notes) and generate focused, 
achievable success criteria that maximize the evaluating vendor's competitive differentiation.

IMPORTANT RULES:
1. Group criteria into CUSTOMER JOURNEY THEMES (e.g., "Onboarding & Activation", "Operational Insights", "Scale & Governance")
2. Each theme should have 2-4 specific criteria maximum
3. Keep total criteria to 5-10 — quality over quantity
4. Each criterion should be specific and measurable, tied to a concrete deliverable
5. Prioritize criteria where the vendor has competitive advantages
6. Include 1-2 "landmine" criteria that expose competitor weaknesses without being obviously biased
7. Link criteria to existing accepted use cases where relevant
8. Consider the evaluation timeline — don't propose criteria that can't be demonstrated in the available timeframe
9. For each criterion, suggest 2-4 specific deliverables (demos, reports, configurations to build)

CRITICAL CONSOLIDATION RULES:
10. You will be given a list of EXISTING success criteria already defined for this opportunity.
11. If any criterion you would propose is semantically similar to an existing one, DO NOT create a new one.
    Instead, set "consolidates_existing_id" to the ID of the existing criterion that covers the same ground.
12. Only propose truly NEW criteria that aren't already covered by existing ones.
13. When consolidating, you may suggest an improved/merged criterion text and updated notes.

OUTPUT FORMAT: Return a JSON array of themed criteria groups.`;

    const userPrompt = `DOCUMENT TO ANALYZE:
Title: ${document_name || 'Untitled'}
Content:
${document_content.slice(0, 40000)}

OPPORTUNITY CONTEXT:
- Name: ${opportunity.name}
- Sales Stage: ${opportunity.sales_stage || 'Unknown'}
- Pre-Sales Stage: ${opportunity.pre_sales_stage || 'Unknown'}
- Close Date: ${opportunity.close_date || 'Not set'}

COMPETITORS IN THIS DEAL:
${competitorNames.length > 0 ? competitorNames.join(', ') : 'No competitors detected'}

PENDO'S COMPETITIVE STRENGTHS (areas where Pendo leads):
${strongAreas.slice(0, 15).map(a => `- ${a.subcategory}: Pendo ${a.pendoScore}/5 vs competitors max ${a.maxCompetitorScore}/5 (+${a.advantage} advantage)`).join('\n') || 'No scorecard data available'}

COMPETITOR WEAKNESSES (potential landmine areas):
${competitorWeaknesses.slice(0, 10).map(w => `- ${w.subcategory}: Pendo ${w.pendoScore}/5, weak competitors: ${w.weakCompetitors.map(c => `${c.name} ${c.score}/5`).join(', ')}`).join('\n') || 'No weakness data available'}

INCLUDED PRODUCT MODULES:
${includedModules.map((m: any) => `- ${m.module_name}: ${m.description || ''}`).join('\n') || 'No modules selected'}

EXISTING ACCEPTED USE CASES (link criteria to these where relevant):
${useCases.map((uc: any) => `- [${uc.id}] ${uc.use_case} (${uc.functional_area || 'General'}) - Outcome: ${uc.business_outcome || 'Not specified'}`).join('\n') || 'No use cases defined yet'}

EVALUATION TIMELINE / MILESTONES:
${milestones.map((m: any) => `- ${m.name}: ${m.scheduled_date || 'TBD'} (${m.status})`).join('\n') || 'No milestones set'}

RUBRIC CATEGORIES AVAILABLE:
${[...new Set(rubric.map((r: any) => r.category))].join(', ') || 'None'}

EXISTING SUCCESS CRITERIA (consolidate with these — do NOT create duplicates):
${existingCriteria.length > 0 
  ? existingCriteria.map((c: any) => `- [ID: ${c.id}] "${c.criterion}" (status: ${c.status}, source: ${c.source})`).join('\n')
  : 'None defined yet — all criteria will be new'}

Generate themed success criteria groups. For each criterion, indicate:
- Which competitive advantage it leverages (if any)
- Whether it's a "landmine" designed to expose a competitor weakness
- Which use case IDs it links to (from the list above)
- If it consolidates an existing criterion, set consolidates_existing_id to the existing ID`;

    const tools = [{
      type: "function",
      function: {
        name: "generate_criteria",
        description: "Generate themed success criteria groups from document analysis",
        parameters: {
          type: "object",
          properties: {
            themes: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  theme_name: { type: "string", description: "Customer journey theme name (e.g., 'Onboarding & Activation')" },
                  theme_description: { type: "string", description: "Brief description of the theme" },
                  criteria: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        criterion: { type: "string", description: "The success criterion statement" },
                        metric_name: { type: "string", description: "Measurable metric for this criterion" },
                        target_value: { type: "string", description: "Target value for the metric" },
                        notes: { type: "string", description: "Additional context including competitive angle" },
                        is_landmine: { type: "boolean", description: "Whether this is designed to expose competitor weaknesses" },
                        competitive_advantage: { type: "string", description: "Which Pendo strength this leverages, or empty" },
                        linked_use_case_ids: { type: "array", items: { type: "string" }, description: "IDs of linked use cases" },
                        deliverables: { type: "array", items: { type: "string" }, description: "Specific deliverables (demos, reports, configs)" },
                        consolidates_existing_id: { type: "string", description: "If this criterion consolidates/replaces an existing one, set this to the existing criterion's ID. Leave empty for truly new criteria." },
                      },
                      required: ["criterion", "deliverables"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["theme_name", "criteria"],
                additionalProperties: false,
              },
            },
          },
          required: ["themes"],
          additionalProperties: false,
        },
      },
    }];

    // Get AI config
    const aiConfig = await getAIConfig();

    // Call AI with retry
    let aiResult: any = null;
    const MAX_RETRIES = 3;
    const BACKOFF = [1000, 2000, 4000];

    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      const aiResponse = await fetch(aiConfig.endpoint, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${aiConfig.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: aiConfig.model,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          tools,
          tool_choice: { type: "function", function: { name: "generate_criteria" } },
          temperature: 0.3,
        }),
      });

      if (aiResponse.ok) {
        const data = await aiResponse.json();
        const args = data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
        if (args) {
          aiResult = JSON.parse(args);
          break;
        }
      }

      if ((aiResponse.status === 503 || aiResponse.status === 429) && attempt < MAX_RETRIES - 1) {
        await new Promise(r => setTimeout(r, BACKOFF[attempt]));
        continue;
      }

      const errorText = await aiResponse.text();
      console.error("AI error:", aiResponse.status, errorText);

      if (aiResponse.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited. Please try again in a moment." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (aiResponse.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      throw new Error(`AI API failed: ${aiResponse.status}`);
    }

    if (!aiResult?.themes) {
      throw new Error("AI did not return valid criteria");
    }

    // Insert/update criteria and deliverables
    let totalCriteria = 0;
    let totalConsolidated = 0;
    let totalDeliverables = 0;
    const existingIdSet = new Set(existingCriteria.map((c: any) => c.id));

    for (const theme of aiResult.themes) {
      for (const criterion of theme.criteria) {
        // Build notes with competitive context
        let notes = criterion.notes || '';
        if (criterion.is_landmine) {
          notes = `🎯 Landmine: ${notes}`;
        }
        if (criterion.competitive_advantage) {
          notes = `${notes}\n💪 Competitive edge: ${criterion.competitive_advantage}`;
        }
        notes = `📂 Theme: ${theme.theme_name}\n${notes}`.trim();

        // Filter linked use case IDs to only valid ones
        const validLinkedIds = (criterion.linked_use_case_ids || []).filter((id: string) => 
          useCases.some((uc: any) => uc.id === id)
        );

        const consolidateId = criterion.consolidates_existing_id;
        let criterionId: string | null = null;

        if (consolidateId && existingIdSet.has(consolidateId)) {
          // UPDATE existing criterion with enriched data
          console.log(`[Consolidation] Updating existing criterion ${consolidateId} with: "${criterion.criterion}"`);
          const updateRes = await fetch(
            `${supabaseUrl}/rest/v1/evaluation_success_criteria?id=eq.${consolidateId}`,
            {
              method: "PATCH",
              headers: { ...headers, "Content-Type": "application/json", Prefer: "return=representation" },
              body: JSON.stringify({
                criterion: criterion.criterion,
                metric_name: criterion.metric_name || null,
                target_value: criterion.target_value || null,
                notes,
                linked_use_case_ids: validLinkedIds.length > 0 ? validLinkedIds : null,
              }),
            }
          );
          if (updateRes.ok) {
            criterionId = consolidateId;
            totalConsolidated++;
          } else {
            console.error("Failed to update criterion:", await updateRes.text());
          }
        } else {
          // INSERT new criterion
          const criterionRes = await fetch(
            `${supabaseUrl}/rest/v1/evaluation_success_criteria`,
            {
              method: "POST",
              headers: { ...headers, "Content-Type": "application/json", Prefer: "return=representation" },
              body: JSON.stringify({
                opportunity_id,
                criterion: criterion.criterion,
                metric_name: criterion.metric_name || null,
                target_value: criterion.target_value || null,
                notes,
                status: "proposed",
                source: "ai_document_analysis",
                linked_use_case_ids: validLinkedIds.length > 0 ? validLinkedIds : null,
              }),
            }
          );

          if (!criterionRes.ok) {
            console.error("Failed to insert criterion:", await criterionRes.text());
            continue;
          }
          const inserted = (await criterionRes.json())?.[0];
          criterionId = inserted?.id;
          totalCriteria++;
        }

        // Insert deliverables
        if (criterionId && criterion.deliverables?.length > 0) {
          const deliverableRows = criterion.deliverables.map((title: string, i: number) => ({
            criterion_id: criterionId,
            title,
            sort_order: i,
            is_completed: false,
          }));

          const delRes = await fetch(
            `${supabaseUrl}/rest/v1/success_criteria_deliverables`,
            {
              method: "POST",
              headers: { ...headers, "Content-Type": "application/json" },
              body: JSON.stringify(deliverableRows),
            }
          );

          if (delRes.ok) {
            totalDeliverables += criterion.deliverables.length;
          } else {
            console.error("Failed to insert deliverables:", await delRes.text());
          }
        }
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        themes_count: aiResult.themes.length,
        criteria_new: totalCriteria,
        criteria_consolidated: totalConsolidated,
        deliverables_count: totalDeliverables,
        themes: aiResult.themes.map((t: any) => ({
          name: t.theme_name,
          criteria_count: t.criteria.length,
        })),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("analyze-document-criteria error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

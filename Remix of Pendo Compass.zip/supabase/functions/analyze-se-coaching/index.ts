import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";
import { getAIConfig } from "../_shared/ai-provider.ts";

// --- Inline decryption helpers ---
function deriveKeyBytes(passphrase: string): Uint8Array {
  const bytes = new TextEncoder().encode(passphrase);
  const key = new Uint8Array(32);
  for (let i = 0; i < 32; i++) key[i] = bytes[i % bytes.length];
  return key;
}

function deriveKeyBytesLegacy(passphrase: string): Uint8Array {
  const bytes = new TextEncoder().encode(passphrase);
  const key = new Uint8Array(32);
  for (let i = 0; i < bytes.length && i < 32; i++) key[i] = bytes[i];
  return key;
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function decryptContent(ciphertext: string, ivBase64: string, keyInput: string): Promise<string | null> {
  try {
    const iv = base64ToBytes(ivBase64);
    const cipherBytes = base64ToBytes(ciphertext);
    const tryWith = async (keyBytes: Uint8Array) => {
      const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["decrypt"]);
      const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: iv.buffer as ArrayBuffer }, key, cipherBytes.buffer as ArrayBuffer);
      return new TextDecoder().decode(plain);
    };
    try { return await tryWith(deriveKeyBytes(keyInput)); } catch { /* fallback */ }
    try { return await tryWith(deriveKeyBytesLegacy(keyInput)); } catch { /* fallback */ }
    return null;
  } catch { return null; }
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Dynamic weighting engine by meeting type
// All 10 dimensions are always scored. Weights determine their importance for overall score.
const ALL_DIMENSIONS = [
  'pov_challenge', 'ownership_control', 'storytelling_proof', 'reverse_demo',
  'champion_arming', 'objection_handling', 'pain_quantification', 'questioning',
  'differentiation', 'strategy_rigor', 'technical_competency', 'value_anchoring',
  'energy_inspiration',
] as const;

// Primary weights by meeting type — non-listed dimensions get a small baseline weight
const PRIMARY_WEIGHTS: Record<string, Record<string, number>> = {
  discovery: {
    pov_challenge: 0.25,
    storytelling_proof: 0.20,
    ownership_control: 0.15,
    questioning: 0.10,
    pain_quantification: 0.10,
  },
  demo: {
    pov_challenge: 0.25,
    storytelling_proof: 0.20,
    ownership_control: 0.15,
    questioning: 0.10,
    pain_quantification: 0.10,
  },
  reverse_demo: {
    questioning: 0.15,
    pain_quantification: 0.20,
    ownership_control: 0.10,
    reverse_demo: 0.15,
    champion_arming: 0.10,
  },
  evaluation_workshop: {
    ownership_control: 0.25,
    objection_handling: 0.20,
    champion_arming: 0.15,
    storytelling_proof: 0.10,
  },
  dry_run: {
    strategy_rigor: 0.30,
    differentiation: 0.20,
    objection_handling: 0.20,
  },
  technical_deep_dive: {
    ownership_control: 0.20,
    storytelling_proof: 0.20,
    questioning: 0.15,
    pov_challenge: 0.10,
    champion_arming: 0.10,
  },
};

function getWeightsForAllDimensions(meetingType: string): Record<string, number> {
  const primary = PRIMARY_WEIGHTS[meetingType] || PRIMARY_WEIGHTS.demo;
  const assignedWeight = Object.values(primary).reduce((a, b) => a + b, 0);
  const unassignedDims = ALL_DIMENSIONS.filter(d => !(d in primary));
  const remainingWeight = Math.max(0, 1 - assignedWeight);
  const baselineWeight = unassignedDims.length > 0 ? remainingWeight / unassignedDims.length : 0;
  
  const weights: Record<string, number> = {};
  for (const dim of ALL_DIMENSIONS) {
    weights[dim] = primary[dim] ?? Math.round(baselineWeight * 1000) / 1000;
  }
  return weights;
}

// Talk ratio targets by meeting type
const TALK_RATIO_TARGETS: Record<string, { min: number; max: number }> = {
  discovery: { min: 30, max: 45 },
  demo: { min: 45, max: 55 },
  reverse_demo: { min: 15, max: 25 },
  evaluation_workshop: { min: 40, max: 55 },
  dry_run: { min: 50, max: 65 },
  technical_deep_dive: { min: 40, max: 55 },
};

function getWeights(meetingType: string): Record<string, number> {
  return getWeightsForAllDimensions(meetingType);
}

function getTalkRatioTarget(meetingType: string): { min: number; max: number } {
  return TALK_RATIO_TARGETS[meetingType] || TALK_RATIO_TARGETS.demo;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { transcriptId, meetingType, seEmail: callerSeEmail } = await req.json();
    if (!transcriptId) {
      return new Response(JSON.stringify({ error: "transcriptId required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch the transcript with momentum meeting link
    const { data: transcript, error: trErr } = await supabase
      .from("transcript_reviews")
      .select("id, transcript_content, opportunity_id, final_account_id, meeting_type, created_at, momentum_meeting_id, momentum_meetings:momentum_meeting_id(start_time)")
      .eq("id", transcriptId)
      .single();

    if (trErr || !transcript) {
      console.error("[SE Coaching] Transcript lookup failed:", trErr?.message, "id:", transcriptId);
      return new Response(JSON.stringify({ error: "Transcript not found", details: trErr?.message }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Decrypt transcript if encrypted
    let transcriptText = transcript.transcript_content;
    if (!transcriptText) {
      // Try encrypted version
      const { data: encData } = await supabase
        .from("transcript_reviews")
        .select("transcript_content_encrypted, encryption_iv")
        .eq("id", transcriptId)
        .single();
      
      if (encData?.transcript_content_encrypted && encData?.encryption_iv) {
        const encKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY");
        if (!encKey) {
          return new Response(JSON.stringify({ error: "Encryption key not configured" }), {
            status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        transcriptText = await decryptContent(encData.transcript_content_encrypted, encData.encryption_iv, encKey);
        if (!transcriptText) {
          const altKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE");
          if (altKey) {
            transcriptText = await decryptContent(encData.transcript_content_encrypted, encData.encryption_iv, altKey);
          }
        }
        if (!transcriptText) {
          return new Response(JSON.stringify({ error: "Failed to decrypt transcript" }), {
            status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        console.log("[SE Coaching] Successfully decrypted transcript from transcript_reviews");
      } else if (transcript.momentum_meeting_id) {
        // Fallback: fetch content from linked momentum_meeting
        console.log("[SE Coaching] No content in transcript_reviews, trying linked momentum_meeting:", transcript.momentum_meeting_id);
        const { data: mmData } = await supabase
          .from("momentum_meetings")
          .select("transcript_content, transcript_content_encrypted, pii_encryption_iv, is_encrypted")
          .eq("id", transcript.momentum_meeting_id)
          .single();

        if (mmData?.transcript_content) {
          transcriptText = mmData.transcript_content;
          console.log("[SE Coaching] Got plaintext from momentum_meeting");
        } else if (mmData?.transcript_content_encrypted && mmData?.pii_encryption_iv) {
          const encKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY");
          if (encKey) {
            transcriptText = await decryptContent(mmData.transcript_content_encrypted, mmData.pii_encryption_iv, encKey);
            if (!transcriptText) {
              const altKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE");
              if (altKey) {
                transcriptText = await decryptContent(mmData.transcript_content_encrypted, mmData.pii_encryption_iv, altKey);
              }
            }
          }
          if (transcriptText) {
            console.log("[SE Coaching] Successfully decrypted transcript from momentum_meeting");
          }
        }

        if (!transcriptText) {
          console.error("[SE Coaching] No content in momentum_meeting either for transcript:", transcriptId);
          return new Response(JSON.stringify({ error: "No transcript content found in transcript or linked meeting." }), {
            status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
      } else {
        console.error("[SE Coaching] No transcript content found (plaintext or encrypted) for transcript:", transcriptId);
        return new Response(JSON.stringify({ error: "No transcript content found. This transcript may not have been fully imported or its content is missing." }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    const effectiveMeetingType = meetingType || transcript.meeting_type || "demo";
    
    // Try to load custom weights from ai_settings
    let weights: Record<string, number>;
    const { data: weightsSetting } = await supabase
      .from("ai_settings")
      .select("setting_value")
      .eq("setting_key", "coaching_dimension_weights")
      .single();
    
    if (weightsSetting?.setting_value) {
      try {
        const rawWeights = JSON.parse(weightsSetting.setting_value);
        // Normalize to fractions
        const total = Object.values(rawWeights).reduce((a: number, b: number) => a + b, 0) as number;
        weights = {};
        for (const dim of ALL_DIMENSIONS) {
          weights[dim] = total > 0 ? (rawWeights[dim] ?? 0) / total : 0;
        }
        console.log("[SE Coaching] Using custom weights from ai_settings");
      } catch {
        weights = getWeights(effectiveMeetingType);
        console.log("[SE Coaching] Failed to parse custom weights, using defaults for", effectiveMeetingType);
      }
    } else {
      weights = getWeights(effectiveMeetingType);
      console.log("[SE Coaching] No custom weights found, using defaults for", effectiveMeetingType);
    }
    
    const talkTarget = getTalkRatioTarget(effectiveMeetingType);
    // Get SE email — resolve through a prioritised fallback chain with full error logging
    let resolvedSeEmail: string | null = null;

    // Priority 0: explicit seEmail passed by the caller (e.g. from the UI when it already knows it)
    if (callerSeEmail) {
      resolvedSeEmail = callerSeEmail;
      console.log("[SE Coaching] Using caller-supplied SE email:", resolvedSeEmail);
    }

    // Priority 1: opportunity.primary_se_email
    if (!resolvedSeEmail && transcript.opportunity_id) {
      const { data: opp, error: oppErr } = await supabase
        .from("opportunities")
        .select("primary_se_email, account_id")
        .eq("id", transcript.opportunity_id)
        .single();
      if (oppErr) console.error("[SE Coaching] opportunity lookup error:", oppErr.message);
      resolvedSeEmail = opp?.primary_se_email ?? null;
      if (resolvedSeEmail) console.log("[SE Coaching] Resolved SE from opportunity:", resolvedSeEmail);

      // Priority 2: account.primary_se_email (via opportunity's account_id)
      if (!resolvedSeEmail && opp?.account_id) {
        const { data: acct, error: acctErr } = await supabase
          .from("accounts")
          .select("primary_se_email")
          .eq("id", opp.account_id)
          .single();
        if (acctErr) console.error("[SE Coaching] account lookup (via opp) error:", acctErr.message);
        resolvedSeEmail = acct?.primary_se_email ?? null;
        if (resolvedSeEmail) console.log("[SE Coaching] Resolved SE from opp's account:", resolvedSeEmail);
      }
    }

    // Priority 3: account.primary_se_email (directly from transcript.final_account_id)
    if (!resolvedSeEmail && transcript.final_account_id) {
      const { data: acct, error: acctErr } = await supabase
        .from("accounts")
        .select("primary_se_email")
        .eq("id", transcript.final_account_id)
        .single();
      if (acctErr) console.error("[SE Coaching] account lookup (direct) error:", acctErr.message);
      resolvedSeEmail = acct?.primary_se_email ?? null;
      if (resolvedSeEmail) console.log("[SE Coaching] Resolved SE from transcript account:", resolvedSeEmail);
    }

    // Priority 4: momentum_meeting.host_email
    if (!resolvedSeEmail && transcript.momentum_meeting_id) {
      const { data: mtg, error: mtgErr } = await supabase
        .from("momentum_meetings")
        .select("host_email, attendees")
        .eq("id", transcript.momentum_meeting_id)
        .single();
      if (mtgErr) console.error("[SE Coaching] meeting lookup error:", mtgErr.message);
      resolvedSeEmail = mtg?.host_email ?? null;
      if (resolvedSeEmail) console.log("[SE Coaching] Resolved SE from meeting host_email:", resolvedSeEmail);

      // Priority 4b: first internal attendee from the meeting
      if (!resolvedSeEmail && mtg?.attendees) {
        const attendees = Array.isArray(mtg.attendees) ? mtg.attendees : [];
        const internal = attendees.find((a: any) => a.email?.includes('@pendo.io'));
        resolvedSeEmail = internal?.email ?? null;
        if (resolvedSeEmail) console.log("[SE Coaching] Resolved SE from internal attendee:", resolvedSeEmail);
      }
    }

    // Priority 5: opportunity_team_members with role = 'se'
    if (!resolvedSeEmail && transcript.opportunity_id) {
      const { data: seMember, error: teamErr } = await supabase
        .from("opportunity_team_members")
        .select("team_member_email")
        .eq("opportunity_id", transcript.opportunity_id)
        .eq("role", "se")
        .limit(1)
        .maybeSingle();
      if (teamErr) console.error("[SE Coaching] team_members lookup error:", teamErr.message);
      resolvedSeEmail = seMember?.team_member_email ?? null;
      if (resolvedSeEmail) console.log("[SE Coaching] Resolved SE from opportunity_team_members:", resolvedSeEmail);
    }

    // Priority 6: resolve caller identity from Authorization JWT
    if (!resolvedSeEmail) {
      const authHeader = req.headers.get("Authorization");
      if (authHeader) {
        // Create a user-scoped client just to resolve the caller's email
        const userClient = createClient(supabaseUrl, supabaseKey, {
          global: { headers: { Authorization: authHeader } },
        });
        const { data: { user } } = await userClient.auth.getUser();
        resolvedSeEmail = user?.email ?? null;
        if (resolvedSeEmail) console.log("[SE Coaching] Resolved SE from JWT caller:", resolvedSeEmail);
      }
    }

    // If no SE email found, attempt auto-assignment from meeting attendees
    if (!resolvedSeEmail && transcript.momentum_meeting_id) {
      console.log("[SE Coaching] No SE resolved — attempting auto-assignment from meeting attendees");
      try {
        const { data: mtgForAssign } = await supabase
          .from("momentum_meetings")
          .select("attendees")
          .eq("id", transcript.momentum_meeting_id)
          .single();
        
        const attendees = Array.isArray(mtgForAssign?.attendees) ? mtgForAssign.attendees : [];
        const internalEmails = attendees
          .filter((a: any) => a.email?.includes('@pendo.io'))
          .map((a: any) => String(a.email).toLowerCase().trim())
          .filter(Boolean);

        if (internalEmails.length > 0) {
          // Check which internal attendees hold the 'se' role
          const { data: matchingProfiles } = await supabase
            .from("profiles")
            .select("id, email")
            .in("email", internalEmails);

          if (matchingProfiles && matchingProfiles.length > 0) {
            const profileIds = matchingProfiles.map(p => p.id);
            const { data: seRoles } = await supabase
              .from("user_roles")
              .select("user_id")
              .in("user_id", profileIds)
              .eq("role", "se");

            if (seRoles && seRoles.length > 0) {
              const seProfile = matchingProfiles.find(p => p.id === seRoles[0].user_id);
              if (seProfile?.email) {
                resolvedSeEmail = seProfile.email;
                console.log("[SE Coaching] Auto-assigned SE from attendees:", resolvedSeEmail);
                
                // Persist the assignment to the opportunity
                if (transcript.opportunity_id) {
                  await supabase
                    .from("opportunities")
                    .update({ primary_se_email: resolvedSeEmail })
                    .eq("id", transcript.opportunity_id);
                  console.log("[SE Coaching] Persisted primary_se_email to opportunity");
                }
              }
            }
          }
        }
      } catch (assignErr) {
        console.error("[SE Coaching] Auto-assignment attempt failed:", assignErr);
      }
    }

    if (!resolvedSeEmail) {
      console.error("[SE Coaching] All SE resolution strategies exhausted (including auto-assignment). opportunity_id:", transcript.opportunity_id, "account_id:", transcript.final_account_id, "meeting_id:", transcript.momentum_meeting_id);
      return new Response(JSON.stringify({ error: "No SE email found. Ensure the opportunity or account has a Primary SE assigned." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch attendee/participant data from momentum meeting if available
    let attendeesInfo = '';
    if (transcript.momentum_meeting_id) {
      const { data: meeting } = await supabase
        .from("momentum_meetings")
        .select("attendees, host_email, host_name")
        .eq("id", transcript.momentum_meeting_id)
        .single();
      
      if (meeting?.attendees) {
        const attendees = Array.isArray(meeting.attendees) ? meeting.attendees : [];
        if (attendees.length > 0) {
          attendeesInfo = `\n\nMEETING PARTICIPANTS (from calendar/meeting metadata):\n${attendees.map((a: any) => 
            `- ${a.name || 'Unknown'} (${a.email || 'no email'})`
          ).join('\n')}`;
          if (meeting.host_email) {
            attendeesInfo += `\nHost: ${meeting.host_name || ''} (${meeting.host_email})`;
          }
        }
      }
    }

    // Fetch AE/owner info from opportunity to help AI distinguish SE from AE
    let otherInternalRoles = '';
    if (transcript.opportunity_id) {
      const { data: oppInfo } = await supabase
        .from("opportunities")
        .select("owner_email")
        .eq("id", transcript.opportunity_id)
        .single();
      
      if (oppInfo?.owner_email && oppInfo.owner_email !== resolvedSeEmail) {
        // Look up the AE's full name from profiles
        const { data: aeProfile } = await supabase
          .from("profiles")
          .select("full_name")
          .eq("email", oppInfo.owner_email)
          .maybeSingle();
        const aeName = aeProfile?.full_name || oppInfo.owner_email.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, (c: string) => c.toUpperCase());
        otherInternalRoles += `\n\nOTHER INTERNAL TEAM MEMBERS (NOT the SE — do NOT quote these people as SE evidence):\n- AE (Account Executive): ${aeName} (${oppInfo.owner_email}) — This person is the salesperson, NOT the SE. Do NOT attribute their words to the SE.`;
      }

      // Also fetch opportunity team members for additional context
      const { data: teamMembers } = await supabase
        .from("opportunity_team_members")
        .select("team_member_email, role")
        .eq("opportunity_id", transcript.opportunity_id);
      
      if (teamMembers && teamMembers.length > 0) {
        const nonSEMembers = teamMembers.filter((tm: any) => tm.team_member_email !== resolvedSeEmail && tm.role !== 'se');
        if (nonSEMembers.length > 0) {
          if (!otherInternalRoles) otherInternalRoles = '\n\nOTHER INTERNAL TEAM MEMBERS (NOT the SE — do NOT quote these people as SE evidence):';
          for (const tm of nonSEMembers) {
            otherInternalRoles += `\n- ${tm.role || 'team member'}: ${tm.team_member_email}`;
          }
        }
      }
    }

    // Extract SE name from email for better speaker matching
    const seNameFromEmail = resolvedSeEmail.split('@')[0]
      .replace(/[._-]/g, ' ')
      .replace(/\b\w/g, c => c.toUpperCase());
    
    // Also look up SE's full name from profiles for more accurate matching
    let seFullName = seNameFromEmail;
    {
      const { data: seProfile } = await supabase
        .from("profiles")
        .select("full_name")
        .eq("email", resolvedSeEmail)
        .maybeSingle();
      if (seProfile?.full_name) {
        seFullName = seProfile.full_name;
      }
    }

    // Build weight description for the prompt
    const weightDesc = Object.entries(weights)
      .map(([k, v]) => `${k.replace(/_/g, ' ')}: ${Math.round(v * 100)}%`)
      .join(", ");

    const systemPrompt = `Role: You are an elite Sales Engineering Leadership Coach. Analyze this ${effectiveMeetingType.replace(/_/g, ' ')} meeting transcript to evaluate SE performance.

CRITICAL SPEAKER IDENTIFICATION:
The SE being evaluated has email "${resolvedSeEmail}" (full name: "${seFullName}").
${attendeesInfo}
${otherInternalRoles}

You MUST carefully identify which speaker label in the transcript corresponds to the SE "${seFullName}". Common transcript speaker formats include:
- Full name (e.g., "Davila Thompson")
- First name only (e.g., "Davila")
- Email prefix (e.g., "davila.thompson")
- "Speaker 1", "Speaker 2" etc.

WARNING: There may be OTHER internal team members (AEs, managers) from the same company on this call. They are NOT the SE. Only evaluate and quote the SE "${seFullName}" (${resolvedSeEmail}). If another internal colleague (e.g., the AE) is doing most of the talking, that does NOT mean they are the SE. The SE is SPECIFICALLY "${seFullName}".

BEFORE scoring, explicitly state which speaker label you identified as the SE. If the SE barely speaks or does not speak in the transcript, score all dimensions as 1 and note that the SE was not an active participant.

CRITICAL TALK RATIO CALCULATION:
To calculate the SE's talk ratio, you must count the NUMBER OF WORDS spoken by the identified SE speaker ("${seFullName}") across the ENTIRE transcript, then divide by the TOTAL WORDS spoken by ALL speakers. Express as a percentage.
- Count EVERY word in EVERY segment attributed to the SE speaker across the full transcript
- Count EVERY word in EVERY segment for ALL speakers to get the total
- se_talk_ratio = (SE_word_count / total_word_count) * 100
- Be precise — do not estimate. Count carefully across the complete transcript.
- This is a word-based ratio, not a time-based ratio.

CRITICAL ATTRIBUTION RULE: Every single quote, evidence snippet, greatness moment, "what worked well" snippet, and "what didn't work" snippet MUST be words spoken BY the SE "${seFullName}" — NEVER by prospects, customers, AEs, or other colleagues. If a quote is from someone else (like the AE), do NOT include it. Double-check every quote attribution before including it.

TIMECODE EXTRACTION: For every quote in "what_worked_well", "what_didnt_work", AND every "evidence" field (including all 5 energy_delivery_breakdown evidence fields), extract the timecode where that moment occurred. If the transcript contains explicit timestamps (e.g., "[12:34]", "00:15:23", "15:23"), use those directly. If no explicit timestamps exist, estimate the approximate time based on the position in the transcript relative to its total length (e.g., "~12 min", "~45 min"). Always include a timecode — never leave it blank. Format evidence as: "[~MM:SS] Direct quote from SE" followed by your assessment.

Meeting Category: ${effectiveMeetingType.replace(/_/g, ' ')}
Scoring Weights for this meeting type: ${weightDesc}
Target SE Talk Ratio: ${talkTarget.min}%–${talkTarget.max}%

TASK:
1. Calculate Conversational Health Metrics:
   - SE talk/listen ratio (percentage of WORDS spoken by the SE vs all speakers — count carefully across the ENTIRE transcript)
   - Average words per minute (flag if >160 wpm as rushed)
   - Count "Pause for Impact" moments (>2 second pauses after impact questions)
   - Overall prospect sentiment during technical sections

2. Score each behavior 1–5 with a DIRECT QUOTE from the SE as evidence:
   - pov_challenge (also covers: Executive Framing, Challenge Articulation): Did the SE offer a unique perspective AND open with a strong consultative frame aligned to business objectives? Did they clearly articulate the prospect's core challenge? ("Based on our experience..." or "Usually companies struggle with..." or "The challenge you're facing with X is costing you Y...")
     Score high when the SE demonstrates executive-level framing that connects the prospect's situation to broader business objectives, AND clearly articulates the problem/challenge being solved. Score low when the opening is generic or the challenge is poorly framed.
   - ownership_control (also covers: Story Flow & Structure): Did the SE define the "Path to Success" AND deliver content in a logical, structured, consultative flow? ("To ensure we hit your target, the next milestone is...")
     Score high when the conversation follows a clear narrative arc — structured, consultative, and purposeful. Score low when the flow feels disjointed, reactive, or lacks clear direction.
   - storytelling_proof (also covers: Use Case Alignment): Did the SE anchor a feature to a specific customer outcome AND demonstrate strong linkage between the prospect's stated use cases and the solution's capabilities? ("Like we did for [Customer]..." or "This maps directly to your need for...")
     Score high when features are linked to specific use cases with concrete customer examples. Score low when stories are generic or use case alignment is weak.
   - reverse_demo: Did the SE uncover negative business consequences? ("What is the cost if this manual process fails?")
   - champion_arming: Did the SE provide internal ammunition? ("Use this data to justify the ROI to your CFO")
   - objection_handling: Did the SE handle objections constructively?
   - pain_quantification (also covers: Negative Consequence): Did the SE quantify business pain in dollars, time, or risk? Did they articulate the revenue velocity impact and cost consequences of inaction? ("That's costing you X per quarter in lost revenue..." or "The manual process adds Y hours per week...")
     Score high when pain is quantified with specific numbers (dollars, hours, risk percentages) AND negative consequences of the status quo are clearly articulated. Score low when pain remains abstract or consequences are vague.
   - questioning (also covers: Discovery Quality): Quality and depth of discovery questions — not just gathering information but asking questions that help the prospect think more deeply about impact, reframe their understanding, and influence their point of view. ("How many hours does your team spend on this manually?" or "What happens to your onboarding timeline when this breaks down?")
     Score high when questions are two-sided: they help the SE understand the situation AND make the prospect reconsider their assumptions or see new implications. Score low when questions are purely informational or surface-level.
    - differentiation: Did the SE clearly differentiate from competitors? Did they articulate actionability vs analytics-only or similar concrete differentiators rather than generic claims? ("Unlike X which only shows you data, we let you act on it directly...")
    - strategy_rigor (also covers: Account Context & Business Relevance): Thoroughness of preparation, strategic approach, AND demonstration of clear understanding of the prospect's business context, industry challenges, and specific operational problems. 
      Score high when the SE shows they've done their homework — referencing specific business challenges, industry context, or operational details that prove deep account understanding. Score low when the approach feels unprepared or generic.
    - technical_competency (also covers: Confidence & Delivery): How effectively did the SE demonstrate the product? Also evaluate confidence, pacing, and naturalness of delivery. Look for these signals:
      * PROSPECT AFFIRMATIONS: "That's exactly what I was looking for", "That answers my question", "Oh wow", "Perfect" — moments confirming the demo met their needs
      * SE DEPTH EXPANSION: SE goes beyond the question — "Let me also show you how this connects to…", "Here's an edge case you might encounter"
      * CONFUSION/REWORK SIGNALS (negative): "Wait, go back", "I'm confused", "Can you show that again" — indicating poor demo execution
      * PROSPECT ENGAGEMENT QUESTIONS: Follow-up questions showing they're engaged and building on what was shown
      Score high (4-5) when multiple affirmations, deep expansions, and engaged follow-ups occur with minimal confusion. Score low (1-2) when confusion signals dominate or the SE only gives surface-level answers.
    - value_anchoring: Evaluate how effectively the SE connects each demonstrated capability or feature to the prospect's specific business needs, pain points, or stated use cases. Score based on the ratio of features that are explicitly "anchored" to customer value versus features presented in isolation (feature dumping).
      * 5 — Exceptional: Every capability shown is explicitly tied to a stated pain point, use case, or business outcome. The SE pauses after each feature to confirm relevance ("Does this address the workflow issue you mentioned?"). Zero feature dumping.
      * 4 — Strong: Most capabilities (>75%) are connected to customer context. Occasional features shown without explicit value linkage, but the overall narrative stays need-driven.
      * 3 — Adequate: Roughly half the features are anchored to customer needs. Some sequences of 2-3 features presented without connecting back to why they matter to this specific prospect.
      * 2 — Weak: Majority of the demo is feature-led. The SE shows capabilities with generic value statements ("customers love this") rather than tying to this prospect's stated problems. Limited pausing to check relevance.
      * 1 — Poor: Classic feature dump. The SE walks through a feature tour with little or no connection to the prospect's business context. No relevance checks, no "here's why this matters to you" framing.
       Evidence: Quote specific moments where the SE either successfully anchored a feature to a customer need, or dumped features without context. Note sequences where multiple capabilities were shown back-to-back without value connection. Flag any relevance-check questions the SE asked (or failed to ask) after demonstrating functionality.
    - energy_inspiration (also covers: Prospect Activation): Did the SE deliver with enthusiasm, energy, and vocal variety that inspires the prospect to feel excited about proceeding? This is specifically about DELIVERY TECHNIQUE — not just what was said but HOW it was said.

      Score this dimension using FIVE sub-techniques. Provide a sub-score (1-5) for each:

      A) PITCH VARIATION ("Staircase Technique") — Does the SE vary their vocal pitch throughout?
         * Upward inflection when introducing exciting concepts or asking questions
         * Downward inflection when stating benefits or definitive conclusions
         * FLAT SIGNALS (negative): Monotone delivery where every sentence has the same pitch contour
         Score 5 when the SE clearly uses pitch variation to emphasise key points. Score 1 when delivery is monotone throughout.

      B) VALUE WORD EMPHASIS ("Punching Value Words") — Does the SE give extra weight to the most important words?
         * Increasing volume or slowing pace on impact words (ROI, revenue, hours, risk, transform)
         * Flat delivery where "and" gets the same emphasis as "breakthrough" is a negative signal
         * Evidence: Quote sentences where value words were either emphasised or delivered flatly
         Score 5 when key value words consistently stand out from surrounding language. Score 1 when every word gets equal weight.

      C) PACE VARIATION ("BPM Control") — Does the SE vary their speaking speed strategically?
         * Speaking faster when describing tedious problems being eliminated ("sprint through the pain")
         * Slowing down significantly when revealing solutions or key insights ("slow-walk the value")
         * Consistent speed throughout is a negative signal — it's a verbal sedative
         Score 5 when pace clearly shifts between problem description (faster) and solution reveal (slower). Score 1 when speed is constant throughout.

      D) VOCAL WARMTH ("Smile Through the Mic") — Does the SE's voice convey warmth and genuine enthusiasm?
         * Bright, resonant tone that sounds welcoming and energised
         * Language that sounds genuinely excited, not scripted or robotic
         * COLD SIGNALS (negative): Clinical, detached, or flat vocal quality even when discussing exciting capabilities
         * Evidence: Quote moments where the SE sounds genuinely enthusiastic vs. moments that sound rehearsed/flat
         Score 5 when the SE consistently sounds warm and genuinely excited. Score 1 when delivery is cold/clinical throughout.

      E) VERBAL HIGHLIGHTERS — Does the SE use attention-grabbing phrases that signal importance?
         * "Now, here is the part that usually surprises people..."
         * "If you take away just one thing from today, let it be this..."
         * "This is where the magic happens"
         * "What's really interesting about this is..."
         * These phrases force a tonal shift and wake up the listener
         * ABSENCE is a negative signal — proceeding through key moments without flagging their importance
         Score 5 when the SE regularly uses verbal highlighters to signal important moments. Score 1 when no attention-grabbing phrases are used.

      Also evaluate:
      * VISION-PAINTING: Forward-looking statements that help the prospect visualise success ("Picture your team six months from now...", "What if you could...")
      * ENERGY MIRRORING: Building on prospect excitement, validating enthusiasm rather than deflating it
      * MOMENTUM LANGUAGE: Forward-leaning phrases that create urgency to act ("Let's make this happen...", "The next step to get you there...")
      * DEFLATION SIGNALS (negative): Passive/hedging language ("I guess we could...", "It's possible that...", "Maybe..."), or failing to build on prospect energy
      * PROSPECT ENERGY TRAJECTORY: Does the prospect's enthusiasm increase or decrease through the call?

      The OVERALL energy_inspiration_score should be the weighted average of the 5 sub-technique scores. Also provide each sub-score in the energy_delivery_breakdown field.
      Score 5 overall when the SE consistently uses vocal variety and delivery techniques that visibly energise the prospect. Score 1 when the SE delivers technically correct but flat, uninspiring content.

3. Generate a Managed Coaching Summary:
...
   - Reference a specific pattern observed in the transcript
    - Suggest a concrete technique or phrase the SE could use next time
    - Explain the expected impact of the improvement

IMPORTANT: Score ALL 13 dimensions listed above, regardless of meeting type. Every dimension must receive a score from 1-5 with evidence. Some dimensions are weighted more heavily for the overall score based on meeting type, but all must still be evaluated. If the transcript provides limited evidence for a dimension, score conservatively and note the lack of evidence.`;

    // Send full transcript — no truncation. Gemini models support large context windows.
    const aiConfig = await getAIConfig('standard');

    const requestBody = JSON.stringify({
        model: aiConfig.model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Analyze this transcript:\n\n${transcriptText}` },
        ],
        tools: [{
          type: "function",
          function: {
            name: "submit_coaching_analysis",
            description: "Submit the SE coaching analysis results",
            parameters: {
              type: "object",
              properties: {
                se_talk_ratio: { type: "number", description: "SE talk percentage 0-100" },
                avg_words_per_minute: { type: "number" },
                pause_for_impact_count: { type: "integer" },
                rushed_speech_detected: { type: "boolean" },
                prospect_sentiment: { type: "string", enum: ["positive", "neutral", "negative", "mixed"] },
                pov_challenge_score: { type: "number", minimum: 1, maximum: 5 },
                pov_challenge_evidence: { type: "string" },
                ownership_control_score: { type: "number", minimum: 1, maximum: 5 },
                ownership_control_evidence: { type: "string" },
                storytelling_proof_score: { type: "number", minimum: 1, maximum: 5 },
                storytelling_proof_evidence: { type: "string" },
                reverse_demo_score: { type: "number", minimum: 1, maximum: 5 },
                reverse_demo_evidence: { type: "string" },
                champion_arming_score: { type: "number", minimum: 1, maximum: 5 },
                champion_arming_evidence: { type: "string" },
                objection_handling_score: { type: "number", minimum: 1, maximum: 5 },
                objection_handling_evidence: { type: "string" },
                pain_quantification_score: { type: "number", minimum: 1, maximum: 5 },
                pain_quantification_evidence: { type: "string" },
                questioning_score: { type: "number", minimum: 1, maximum: 5 },
                questioning_evidence: { type: "string" },
                differentiation_score: { type: "number", minimum: 1, maximum: 5 },
                differentiation_evidence: { type: "string" },
                strategy_rigor_score: { type: "number", minimum: 1, maximum: 5 },
                strategy_rigor_evidence: { type: "string" },
                technical_competency_score: { type: "number", minimum: 1, maximum: 5 },
                technical_competency_evidence: { type: "string" },
                value_anchoring_score: { type: "number", minimum: 1, maximum: 5 },
                value_anchoring_evidence: { type: "string" },
                energy_inspiration_score: { type: "number", minimum: 1, maximum: 5 },
                energy_inspiration_evidence: { type: "string" },
                energy_delivery_breakdown: {
                  type: "object",
                  properties: {
                    pitch_variation_score: { type: "number", minimum: 1, maximum: 5, description: "Staircase technique — vocal pitch variety" },
                    pitch_variation_evidence: { type: "string", description: "Direct SE quote with timecode showing pitch variation (or lack of). Format: '[~MM:SS] quote — assessment'" },
                    value_word_emphasis_score: { type: "number", minimum: 1, maximum: 5, description: "Punching value words — emphasis on key terms" },
                    value_word_emphasis_evidence: { type: "string", description: "Direct SE quote with timecode showing value word emphasis (or lack of). Format: '[~MM:SS] quote — assessment'" },
                    pace_variation_score: { type: "number", minimum: 1, maximum: 5, description: "BPM control — strategic speed changes" },
                    pace_variation_evidence: { type: "string", description: "Direct SE quote with timecode showing pace variation (or lack of). Format: '[~MM:SS] quote — assessment'" },
                    vocal_warmth_score: { type: "number", minimum: 1, maximum: 5, description: "Smile through the mic — warmth and genuine enthusiasm" },
                    vocal_warmth_evidence: { type: "string", description: "Direct SE quote with timecode showing vocal warmth (or lack of). Format: '[~MM:SS] quote — assessment'" },
                    verbal_highlighters_score: { type: "number", minimum: 1, maximum: 5, description: "Attention-grabbing phrases that signal importance" },
                    verbal_highlighters_evidence: { type: "string", description: "Direct SE quote with timecode showing verbal highlighters used (or absence of). Format: '[~MM:SS] quote — assessment'" },
                  },
                  required: ["pitch_variation_score", "pitch_variation_evidence", "value_word_emphasis_score", "value_word_emphasis_evidence", "pace_variation_score", "pace_variation_evidence", "vocal_warmth_score", "vocal_warmth_evidence", "verbal_highlighters_score", "verbal_highlighters_evidence"],
                  description: "Sub-scores for each of the 5 delivery techniques, each with a direct SE quote and timecode"
                },
                greatness_moment: { type: "string" },
                opportunity_gap: { type: "string" },
                improvement_example: { type: "string" },
                actionable_next_step: { type: "string" },
                what_worked_well: { 
                  type: "array", 
                  items: { 
                    type: "object", 
                    properties: { 
                      snippet: { type: "string" }, 
                      explanation: { type: "string" },
                      timecode: { type: "string", description: "Approximate timestamp in the transcript where this moment occurred, e.g. '12:34' or '~15 min'" }
                    }, 
                    required: ["snippet", "explanation"] 
                  },
                  description: "2-4 moments where the SE excelled with direct quotes and timecodes"
                },
                what_didnt_work: { 
                  type: "array", 
                  items: { 
                    type: "object", 
                    properties: { 
                      snippet: { type: "string" }, 
                      explanation: { type: "string" },
                      timecode: { type: "string", description: "Approximate timestamp in the transcript where this moment occurred, e.g. '12:34' or '~15 min'" }
                    }, 
                    required: ["snippet", "explanation"] 
                  },
                  description: "2-4 moments where the SE could improve with timecodes"
                },
                coaching_guidance: { 
                  type: "array", 
                  items: { type: "object", properties: { pattern_observed: { type: "string" }, technique: { type: "string" }, expected_impact: { type: "string" } }, required: ["pattern_observed", "technique", "expected_impact"] },
                  description: "2-3 actionable coaching tips"
                },
              },
              required: [
                "se_talk_ratio", "avg_words_per_minute", "prospect_sentiment",
                "pov_challenge_score", "pov_challenge_evidence",
                "ownership_control_score", "ownership_control_evidence",
                "storytelling_proof_score", "storytelling_proof_evidence",
                "reverse_demo_score", "reverse_demo_evidence",
                "champion_arming_score", "champion_arming_evidence",
                "objection_handling_score", "objection_handling_evidence",
                "pain_quantification_score", "pain_quantification_evidence",
                "questioning_score", "questioning_evidence",
                "differentiation_score", "differentiation_evidence",
                "strategy_rigor_score", "strategy_rigor_evidence",
                "technical_competency_score", "technical_competency_evidence",
                "value_anchoring_score", "value_anchoring_evidence",
                "energy_inspiration_score", "energy_inspiration_evidence", "energy_delivery_breakdown",
                "greatness_moment", "opportunity_gap", "improvement_example", "actionable_next_step",
                "what_worked_well", "what_didnt_work", "coaching_guidance"
              ],
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "submit_coaching_analysis" } },
      });

    // Retry loop for transient AI failures (503, 429, timeouts)
    let response: Response | null = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      if (attempt > 0) {
        const delay = 1000 * Math.pow(2, attempt);
        console.log(`[SE Coaching] Retry attempt ${attempt + 1} after ${delay}ms`);
        await new Promise(r => setTimeout(r, delay));
      }

      try {
        response = await fetch(aiConfig.endpoint, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${aiConfig.apiKey}`,
            "Content-Type": "application/json",
          },
          body: requestBody,
        });

        if (response.ok) break;

        const status = response.status;
        if (status !== 503 && status !== 429) {
          const errText = await response.text();
          console.error("[SE Coaching] AI error:", status, errText);
          return new Response(JSON.stringify({ error: "AI analysis failed", details: errText }), {
            status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        console.warn(`[SE Coaching] AI returned ${status}, will retry...`);
      } catch (fetchErr) {
        console.error(`[SE Coaching] Fetch error on attempt ${attempt + 1}:`, fetchErr);
        if (attempt === 2) {
          return new Response(JSON.stringify({ error: "AI request failed after retries" }), {
            status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
      }
    }

    if (!response || !response.ok) {
      return new Response(JSON.stringify({ error: "AI analysis failed after retries" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiResult = await response.json();
    const toolCall = aiResult.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall?.function?.arguments) {
      return new Response(JSON.stringify({ error: "No analysis result from AI" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const analysis = JSON.parse(toolCall.function.arguments);

    // Calculate weighted overall score
    let overallScore = 0;
    let totalWeight = 0;
    const scoreFields: Record<string, string> = {
      pov_challenge: "pov_challenge_score",
      ownership_control: "ownership_control_score",
      storytelling_proof: "storytelling_proof_score",
      reverse_demo: "reverse_demo_score",
      champion_arming: "champion_arming_score",
      objection_handling: "objection_handling_score",
      pain_quantification: "pain_quantification_score",
      questioning: "questioning_score",
      differentiation: "differentiation_score",
      strategy_rigor: "strategy_rigor_score",
      technical_competency: "technical_competency_score",
      value_anchoring: "value_anchoring_score",
      energy_inspiration: "energy_inspiration_score",
    };

    for (const [dim, weight] of Object.entries(weights)) {
      const scoreKey = scoreFields[dim];
      const score = analysis[scoreKey];
      if (score != null && typeof score === "number") {
        overallScore += score * weight;
        totalWeight += weight;
      }
    }

    const normalizedOverall = totalWeight > 0 ? Math.round((overallScore / totalWeight) * 10) / 10 : null;

    // Calculate talk ratio score (how close to target)
    let talkRatioScore: number | null = null;
    if (analysis.se_talk_ratio != null) {
      const ratio = analysis.se_talk_ratio;
      if (ratio >= talkTarget.min && ratio <= talkTarget.max) {
        talkRatioScore = 5.0;
      } else {
        const distance = ratio < talkTarget.min
          ? talkTarget.min - ratio
          : ratio - talkTarget.max;
        talkRatioScore = Math.max(1, 5 - (distance / 10));
      }
      talkRatioScore = Math.round(talkRatioScore * 10) / 10;
    }

    // Upsert coaching score
    const record = {
      transcript_id: transcriptId,
      opportunity_id: transcript.opportunity_id,
      account_id: transcript.final_account_id,
      se_email: resolvedSeEmail,
      meeting_type: effectiveMeetingType,
      se_talk_ratio: analysis.se_talk_ratio,
      target_talk_ratio_min: talkTarget.min,
      target_talk_ratio_max: talkTarget.max,
      talk_ratio_score: talkRatioScore,
      avg_words_per_minute: analysis.avg_words_per_minute,
      pause_for_impact_count: analysis.pause_for_impact_count || 0,
      rushed_speech_detected: analysis.rushed_speech_detected || false,
      prospect_sentiment: analysis.prospect_sentiment,
      pov_challenge_score: analysis.pov_challenge_score,
      pov_challenge_evidence: analysis.pov_challenge_evidence,
      ownership_control_score: analysis.ownership_control_score,
      ownership_control_evidence: analysis.ownership_control_evidence,
      storytelling_proof_score: analysis.storytelling_proof_score,
      storytelling_proof_evidence: analysis.storytelling_proof_evidence,
      reverse_demo_score: analysis.reverse_demo_score,
      reverse_demo_evidence: analysis.reverse_demo_evidence,
      champion_arming_score: analysis.champion_arming_score,
      champion_arming_evidence: analysis.champion_arming_evidence,
      objection_handling_score: analysis.objection_handling_score,
      objection_handling_evidence: analysis.objection_handling_evidence,
      pain_quantification_score: analysis.pain_quantification_score,
      pain_quantification_evidence: analysis.pain_quantification_evidence,
      questioning_score: analysis.questioning_score,
      questioning_evidence: analysis.questioning_evidence,
      differentiation_score: analysis.differentiation_score,
      differentiation_evidence: analysis.differentiation_evidence,
      strategy_rigor_score: analysis.strategy_rigor_score,
      strategy_rigor_evidence: analysis.strategy_rigor_evidence,
      technical_competency_score: analysis.technical_competency_score,
      technical_competency_evidence: analysis.technical_competency_evidence,
      value_anchoring_score: analysis.value_anchoring_score,
      value_anchoring_evidence: analysis.value_anchoring_evidence,
      energy_inspiration_score: analysis.energy_inspiration_score,
      energy_inspiration_evidence: analysis.energy_inspiration_evidence,
      energy_delivery_breakdown: analysis.energy_delivery_breakdown || null,
      weights_used: weights,
      overall_score: normalizedOverall,
      greatness_moment: analysis.greatness_moment,
      opportunity_gap: analysis.opportunity_gap,
      improvement_example: analysis.improvement_example,
      actionable_next_step: analysis.actionable_next_step,
      what_worked_well: analysis.what_worked_well || [],
      what_didnt_work: analysis.what_didnt_work || [],
      coaching_guidance: analysis.coaching_guidance || [],
      analysis_model: aiConfig.model,
      analyzed_at: new Date().toISOString(),
      meeting_date: (transcript as any).momentum_meetings?.start_time || transcript.created_at,
    };

    const { error: upsertErr } = await supabase
      .from("se_coaching_scores")
      .upsert(record, { onConflict: "transcript_id,se_email" });

    if (upsertErr) {
      console.error("[SE Coaching] Save error:", upsertErr);
      return new Response(JSON.stringify({ error: "Failed to save coaching score", details: upsertErr.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`[SE Coaching] Scored transcript ${transcriptId}: overall ${normalizedOverall}/5`);

    return new Response(JSON.stringify({
      success: true,
      overall_score: normalizedOverall,
      meeting_type: effectiveMeetingType,
      talk_ratio: analysis.se_talk_ratio,
      talk_ratio_score: talkRatioScore,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("[SE Coaching] Error:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

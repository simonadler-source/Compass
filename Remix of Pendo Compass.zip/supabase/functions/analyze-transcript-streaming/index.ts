import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// === Analysis Run Logger ===
async function logPassStart(
  supabaseUrl: string, supabaseKey: string,
  transcriptId: string, passKey: string, passName: string, phase: string, retryAttempt = 0
): Promise<string | null> {
  try {
    const sb = createClient(supabaseUrl, supabaseKey);
    const { data, error } = await sb.from('analysis_run_logs').insert({
      transcript_id: transcriptId,
      pass_key: passKey,
      pass_name: passName,
      phase,
      status: 'running',
      retry_attempt: retryAttempt,
      started_at: new Date().toISOString(),
    }).select('id').single();
    if (error) { console.error('[RunLog] Insert failed:', error.message); return null; }
    return data?.id || null;
  } catch (e) { console.error('[RunLog] Error:', e); return null; }
}

async function logPassEnd(
  supabaseUrl: string, supabaseKey: string, logId: string | null,
  status: 'completed' | 'failed' | 'skipped',
  startTime: number,
  opts: { errorMessage?: string; errorCategory?: string; inputTokens?: number; outputTokens?: number; resultSummary?: any } = {}
) {
  if (!logId) return;
  try {
    const sb = createClient(supabaseUrl, supabaseKey);
    await sb.from('analysis_run_logs').update({
      status,
      completed_at: new Date().toISOString(),
      duration_ms: Date.now() - startTime,
      error_message: opts.errorMessage || null,
      error_category: opts.errorCategory || null,
      input_tokens_estimate: opts.inputTokens || null,
      output_tokens_estimate: opts.outputTokens || null,
      result_summary: opts.resultSummary || null,
    }).eq('id', logId);
  } catch (e) { console.error('[RunLog] Update failed:', e); }
}

// Input validation schema
const AnalyzeTranscriptInputSchema = z.object({
  transcript: z.string().min(1).max(500000).optional(),
  accountId: z.string().uuid().optional(),
  opportunityId: z.string().uuid().optional(),
  transcriptReviewId: z.string().uuid().optional(),
  skipEnrichment: z.boolean().optional(),
});

// SSE helper to send progress events. Safe against client disconnects:
// once the controller is closed/errored, further enqueue() calls throw
// "The stream controller cannot close or enqueue". We swallow those so the
// background work (DB persistence, logging) can continue uninterrupted.
function sendSSE(controller: ReadableStreamDefaultController, event: string, data: any): boolean {
  try {
    const message = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
    controller.enqueue(new TextEncoder().encode(message));
    return true;
  } catch (_err) {
    // Client disconnected – continue silently
    return false;
  }
}

function safeClose(controller: ReadableStreamDefaultController) {
  try { controller.close(); } catch (_err) { /* already closed */ }
}

// Pass 1 Schema: Core Analysis (technologies, people, NBAs, pain points)
const pass1CoreSchema = {
  type: "object",
  properties: {
    technologies: {
      type: "array",
      items: {
        type: "object",
        properties: {
          name: { type: "string" },
          confidence: { type: "number" },
          suggestedLayer: { type: "string", enum: ["host", "build", "adopt", "growth", "ops"] },
          context: { type: "string" },
          relationshipStatus: { type: "string", enum: ["mentioned", "experience", "in_use", "evaluating", "considering", "replaced"] },
          needsReview: { type: "boolean" }
        },
        required: ["name", "confidence", "suggestedLayer", "context", "relationshipStatus", "needsReview"]
      }
    },
    people: {
      type: "array",
      items: {
        type: "object",
        properties: {
          name: { type: "string", description: "Full name of the person" },
          role: { type: "string", description: "Job title or role" },
          email: { type: "string", description: "Email address if mentioned" },
          context: { type: "string", description: "Brief context of their involvement in the discussion" },
          stakeholderType: { 
            type: "string", 
            enum: ["champion", "economic_buyer", "decision_criteria_owner", "coach", "blocker", "end_user", "unknown"],
            description: "MEDDIC stakeholder classification based on evidence"
          },
          influenceLevel: { 
            type: "number", 
            description: "Decision-making influence 0-100. C-level/VP=80-100, Director=60-80, Manager=40-60, IC=20-40. Use null if unknown stakeholderType."
          },
          sentiment: { 
            type: "number", 
            description: "Attitude toward the product 0-100. Enthusiastic=80-100, Positive=60-80, Neutral=40-60, Skeptical=20-40, Hostile=0-20. Use null if unknown."
          },
          championScore: { 
            type: "number", 
            description: "Champion potential 0-100. Only >50 if person shows BOTH advocacy (vouching, promoting) AND info sharing (providing internal intel). Use null if no evidence."
          },
          isInternal: { type: "boolean", description: "true if this is an internal team member (e.g. @pendo.io email)" },
          advocacySignals: {
            type: "object",
            properties: {
              detected: { type: "boolean" },
              examples: { type: "array", items: { type: "string" } }
            },
            description: "Evidence of advocating for the product internally"
          },
          infoSharingSignals: {
            type: "object",
            properties: {
              detected: { type: "boolean" },
              examples: { type: "array", items: { type: "string" } }
            },
            description: "Evidence of sharing internal information (budget, timeline, competitors)"
          }
        },
        required: ["name", "context", "stakeholderType", "isInternal", "influenceLevel", "sentiment", "championScore"]
      }
    },
    nbas: {
      type: "array",
      items: {
        type: "object",
        properties: {
          action: { type: "string" },
          actionType: { type: "string", enum: ["poc_setup", "integration_review", "security_assessment", "architecture_doc", "technical_deepdive", "api_exploration", "performance_benchmark", "follow_up_meeting", "send_content", "internal_discussion"] },
          ownerType: { type: "string", enum: ["prospect", "sales_rep", "sales_engineer"] },
          ownerName: { type: "string", description: "The specific name of the person responsible from the transcript" },
          ownerEmail: { type: "string", description: "The email of the owner if available from the transcript" },
          priority: { type: "string", enum: ["high", "medium", "low"] },
          reasoning: { type: "string" }
        },
        required: ["action", "actionType", "ownerType", "priority", "reasoning"]
      }
    },
    painPoints: { 
      type: "array", 
      items: { 
        type: "object",
        properties: {
          description: { type: "string", description: "The specific pain point or challenge" },
          businessTheme: { type: "string", enum: ["operational_efficiency", "customer_experience", "revenue_growth", "cost_reduction", "compliance_risk", "digital_transformation", "data_insights", "team_productivity"], description: "The business objective this pain point relates to" },
          severity: { type: "string", enum: ["high", "medium", "low"] },
          confidence: { type: "number" }
        },
        required: ["description", "businessTheme", "severity", "confidence"]
      }
    },
    useCases: { 
      type: "array", 
      items: { 
        type: "object",
        properties: {
          description: { type: "string", description: "The specific use case or requirement" },
          businessTheme: { type: "string", enum: ["operational_efficiency", "customer_experience", "revenue_growth", "cost_reduction", "compliance_risk", "digital_transformation", "data_insights", "team_productivity"], description: "The business objective this use case supports" },
          priority: { type: "string", enum: ["high", "medium", "low"] },
          confidence: { type: "number" }
        },
        required: ["description", "businessTheme", "priority", "confidence"]
      }
    },
    competitorMentions: { type: "array", items: { type: "string" } },
    contentTypeDetection: {
      type: "object",
      properties: {
        contentType: { type: "string", enum: ["email", "meeting"] },
        emailType: { type: "string", enum: ["followup", "proposal", "introduction", "status_update", "technical", "scheduling", "other"] },
        confidence: { type: "number" }
      },
      required: ["contentType", "confidence"]
    },
    meetingPurpose: {
      type: "object",
      description: "Classify the PRIMARY purpose of this meeting based on conversation flow and content",
      properties: {
        meetingType: { 
          type: "string", 
          enum: ["discovery", "demo", "technical", "evaluation_workshop", "workshop", "dry_run", "executive", "commercial", "negotiation", "contract", "check_in", "training", "onboarding", "qbr"],
          description: "discovery=qualification/needs finding, demo=product demonstration, technical=architecture/integration deep-dive, evaluation_workshop=hands-on POC/evaluation, workshop=collaborative working session, dry_run=practice demo/rehearsal, executive=C-level briefing, commercial=pricing/terms, negotiation=contract negotiation, contract=legal review, check_in=status update, training=user training, onboarding=customer setup, qbr=quarterly business review"
        },
        confidence: { 
          type: "number", 
          description: "0-1 confidence in this classification. High (0.85+): clear single purpose. Medium (0.6-0.84): primary purpose evident but secondary activities present. Low (<0.6): ambiguous or mixed-purpose meeting." 
        },
        reasoning: { type: "string", description: "Brief explanation of why this meeting type was chosen" },
        secondaryPurposes: {
          type: "array",
          items: { type: "string", enum: ["discovery", "demo", "technical", "evaluation_workshop", "workshop", "dry_run", "executive", "commercial", "negotiation", "contract", "check_in", "training", "onboarding", "qbr"] },
          description: "Other purposes that occurred during the meeting (e.g., a demo that also included discovery)"
        }
      },
      required: ["meetingType", "confidence", "reasoning"]
    },
  },
  required: ["technologies", "people", "nbas", "painPoints", "useCases", "competitorMentions", "contentTypeDetection", "meetingPurpose"]
};

// Pass 2 Schema: Stage Assessment & Commercial Insights
const pass2StageSchema = {
  type: "object",
  properties: {
    salesStageAssessment: {
      type: "object",
      properties: {
        stage: { type: "number" },
        stageName: { type: "string" },
        phase: { type: "string", enum: ["Pipeline Generation", "Visible Opportunity", "Value Realization"] },
        confidence: { type: "number" },
        reasoning: { type: "string" },
        exitCriteriaMet: { type: "array", items: { type: "string" } },
        exitCriteriaNotMet: { type: "array", items: { type: "string" } }
      },
      required: ["stage", "stageName", "phase", "confidence", "reasoning"]
    },
    preSalesStageAssessment: {
      type: "object",
      properties: {
        stage: { type: "string", enum: ["Not Started", "Discovery", "Demo", "Proof - Scoping", "Proof", "Technical Win", "Technical Loss", "Stale / Not Active", "Unqualified"] },
        confidence: { type: "number" },
        reasoning: { type: "string" },
        evidenceForStage: { type: "array", items: { type: "string" } }
      },
      required: ["stage", "confidence", "reasoning"]
    },
    commercialInsights: {
      type: "array",
      items: {
        type: "object",
        properties: {
          insight: { type: "string" },
          type: { type: "string", enum: ["build_vs_buy", "budget_timing", "competitive_positioning", "stakeholder_dynamics"] },
          swotCategory: { type: "string", enum: ["strength", "weakness", "opportunity", "threat"] },
          importance: { type: "string", enum: ["high", "medium", "low"] },
          context: { type: "string" }
        },
        required: ["insight", "type", "swotCategory", "importance", "context"]
      }
    },
    operationalMetrics: {
      type: "array",
      description: "Extract ALL quantifiable numbers, percentages, costs, volumes, and time measurements mentioned in the transcript",
      items: {
        type: "object",
        properties: {
          metricName: { type: "string", description: "Descriptive name e.g. 'Monthly Active Users', 'Support Tickets per Month', 'Cost per User'" },
          metricValue: { type: "string", description: "The value as stated e.g. '500 users', '$50k', '2 hours'" },
          metricNumericValue: { type: "number", nullable: true, description: "IMPORTANT: Extract the raw number if possible (e.g. 500, 50000, 2). Null only if truly non-numeric." },
          metricCategory: { type: "string", description: "Category: Usage, Cost/Financial, Time/Efficiency, Performance, Support/Service, Adoption, Revenue" },
          mentionedByName: { type: "string", nullable: true, description: "Name of the person who stated this metric" },
          mentionedByType: { type: "string", enum: ["internal", "external"], description: "Whether speaker is internal (our sales/SE team) or external (customer/prospect)" },
          confidence: { type: "number", description: "0-1 confidence that this is an accurate metric from the conversation" },
          needsReview: { type: "boolean" },
          context: { type: "string", description: "Quote or context where this metric was mentioned" }
        },
        required: ["metricName", "metricValue", "metricCategory", "confidence", "needsReview", "context"]
      }
    },
    discoveryQuestions: {
      type: "array",
      items: {
        type: "object",
        properties: {
          question: { type: "string" },
          category: { type: "string" },
          functionalArea: { type: "string" },
          context: { type: "string" }
        },
        required: ["question", "category", "functionalArea", "context"]
      }
    }
  },
  required: ["salesStageAssessment", "preSalesStageAssessment", "commercialInsights", "operationalMetrics", "discoveryQuestions"]
};

const callSummarySchema = {
  type: "object",
  properties: {
    callSummary: {
      type: "object",
      properties: {
        quickRecap: { type: "string" },
        themeSections: {
          type: "array",
          items: {
            type: "object",
            properties: {
              title: { type: "string" },
              content: { type: "string" }
            },
            required: ["title", "content"]
          }
        },
        nextSteps: {
          type: "array",
          items: {
            type: "object",
            properties: {
              action: { type: "string" },
              owner: { type: "string" }
            },
            required: ["action"]
          }
        },
        suggestedActions: {
          type: "array",
          items: {
            type: "object",
            properties: {
              action: { type: "string" },
              rationale: { type: "string" }
            },
            required: ["action"]
          }
        },
        attendees: {
          type: "object",
          properties: {
            internal: { type: "array", items: { type: "object" } },
            external: { type: "array", items: { type: "object" } }
          }
        },
        durationMinutes: { type: "number" },
        opportunityContext: { type: "string" }
      },
      required: ["quickRecap", "themeSections", "nextSteps"]
    }
  },
  required: ["callSummary"]
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const rawBody = await req.json();
    const parseResult = AnalyzeTranscriptInputSchema.safeParse(rawBody);
    
    if (!parseResult.success) {
      return new Response(
        JSON.stringify({ error: "Invalid input", details: parseResult.error.errors }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let { transcript, transcriptReviewId, skipEnrichment } = parseResult.data;
    
    // If no transcript provided but transcriptReviewId given, load from DB
    if (!transcript && transcriptReviewId) {
      const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
      const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
      const primaryEncKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');
      const alternateEncKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE');
      const supabase = createClient(supabaseUrl, supabaseKey);
      
      const { data: tr, error: trErr } = await supabase
        .from('transcript_reviews')
        .select('transcript_content, transcript_content_encrypted, encryption_iv, is_encrypted, momentum_meeting_id')
        .eq('id', transcriptReviewId)
        .single();
      
      if (trErr || !tr) {
        return new Response(
          JSON.stringify({ error: `Transcript not found: ${trErr?.message || 'unknown'}` }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      // Helper to derive key bytes (matches enrich-transcript logic)
      const deriveKeyBytes = (keyInput: string): Uint8Array => {
        if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
          const bytes = new Uint8Array(32);
          for (let i = 0; i < 64; i += 2) bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
          return bytes;
        }
        const encoder = new TextEncoder();
        const data = encoder.encode(keyInput);
        const bytes = new Uint8Array(32);
        for (let i = 0; i < Math.min(data.length, 32); i++) bytes[i] = data[i];
        return bytes;
      };

      // Helper to decrypt content with a specific key
      const tryDecrypt = async (encrypted: string, iv: string, keyInput: string): Promise<string> => {
        const keyBytes = deriveKeyBytes(keyInput);
        const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['decrypt']);
        const ivBinary = atob(iv);
        const ivBytes = new Uint8Array(ivBinary.length);
        for (let i = 0; i < ivBinary.length; i++) ivBytes[i] = ivBinary.charCodeAt(i);
        const encBinary = atob(encrypted);
        const encBytes = new Uint8Array(encBinary.length);
        for (let i = 0; i < encBinary.length; i++) encBytes[i] = encBinary.charCodeAt(i);
        const decrypted = await crypto.subtle.decrypt(
          { name: 'AES-GCM', iv: ivBytes.buffer as ArrayBuffer },
          key,
          encBytes.buffer as ArrayBuffer
        );
        return new TextDecoder().decode(decrypted);
      };

      // Decrypt with fallback keys (try primary, then alternate)
      const decryptWithFallback = async (encrypted: string, iv: string): Promise<string | null> => {
        const errors: string[] = [];
        if (primaryEncKey) {
          try {
            return await tryDecrypt(encrypted, iv, primaryEncKey);
          } catch (e) {
            errors.push(`primary: ${e instanceof Error ? e.message : String(e)}`);
          }
        }
        if (alternateEncKey) {
          try {
            return await tryDecrypt(encrypted, iv, alternateEncKey);
          } catch (e) {
            errors.push(`alternate: ${e instanceof Error ? e.message : String(e)}`);
          }
        }
        if (errors.length > 0) {
          console.error(`[Streaming] Decryption failed with all keys: ${errors.join('; ')}`);
        } else {
          console.error('[Streaming] No encryption keys configured');
        }
        return null;
      };
      
      // Try transcript_reviews content first
      if (tr.transcript_content) {
        transcript = tr.transcript_content;
      } else if (tr.transcript_content_encrypted && tr.encryption_iv) {
        transcript = await decryptWithFallback(tr.transcript_content_encrypted, tr.encryption_iv) || undefined;
      }
      
      // Fall back to momentum_meetings content
      if (!transcript && tr.momentum_meeting_id) {
        const { data: mm } = await supabase
          .from('momentum_meetings')
          .select('transcript_content, transcript_content_encrypted, pii_encryption_iv, encryption_iv, is_encrypted')
          .eq('id', tr.momentum_meeting_id)
          .single();
        
        if (mm) {
          if (mm.transcript_content) {
            transcript = mm.transcript_content;
          } else if (mm.transcript_content_encrypted) {
            const mmIv = mm.pii_encryption_iv || mm.encryption_iv;
            if (mmIv) {
              transcript = await decryptWithFallback(mm.transcript_content_encrypted, mmIv) || undefined;
            }
          }
        }
      }
      
      if (!transcript) {
        return new Response(
          JSON.stringify({ error: 'No transcript content available' }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      // Guard against empty or trivially short content (decryption may have failed silently)
      if (transcript.trim().length < 100) {
        console.error(`[Streaming] Transcript content too short (${transcript.trim().length} chars) - likely a decryption or import issue`);
        return new Response(
          JSON.stringify({ error: `Transcript content too short (${transcript.trim().length} chars) - decryption may have failed` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      console.log(`[Streaming] Loaded transcript from DB for review ${transcriptReviewId} (${transcript.length} chars)`);
    }
    
    if (!transcript) {
      return new Response(
        JSON.stringify({ error: 'Either transcript or transcriptReviewId must be provided' }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiConfig = await getAIConfig();
    
    // Dynamic timeout based on transcript length - longer transcripts need more time
    const transcriptLength = transcript.length;
    const baseTimeout = 45000; // 45s base
    const extraTimePerChunk = 15000; // +15s per 20K chars over 40K
    const dynamicTimeout = transcriptLength > 40000 
      ? baseTimeout + Math.ceil((transcriptLength - 40000) / 20000) * extraTimePerChunk
      : baseTimeout;
    const maxTimeout = 120000; // Cap at 2 minutes
    const pass1Timeout = Math.min(dynamicTimeout, maxTimeout);
    
    console.log(`[Streaming] Starting analysis (${transcript.length} chars, skipEnrichment=${skipEnrichment}, timeout=${pass1Timeout}ms)`);

    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';

    // Create SSE stream
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // ========== PASS 1: Core Analysis ==========
          const pass1LogId = transcriptReviewId
            ? await logPassStart(supabaseUrl, serviceRoleKey, transcriptReviewId, 'core_extraction', 'Core Extraction', 'core')
            : null;
          const pass1StartTime = Date.now();

          sendSSE(controller, "progress", { 
            pass: 1, 
            totalPasses: skipEnrichment ? 2 : 4,
            stage: "Extracting technologies, people & actions...",
            progress: 10 
          });

          const pass1Prompt = `You are an AI analyzing sales communications. Extract:

1. Technologies mentioned (with relationship status: mentioned/in_use/evaluating/etc)

2. People - For EACH person, provide MEDDIC assessment with SCORES:
   - stakeholderType: champion/economic_buyer/decision_criteria_owner/coach/blocker/end_user/unknown
   - influenceLevel (0-100): C-level/VP=80-100, Director=60-80, Manager=40-60, IC=20-40. Use null ONLY if stakeholderType is "unknown"
   - sentiment (0-100): Based on their attitude in the conversation. Enthusiastic=80-100, Positive=60-80, Neutral=40-60, Skeptical=20-40, Hostile=0-20
   - championScore (0-100): ONLY score >50 if person shows BOTH:
     a) Advocacy signals: vouching for product, selling internally, defending against objections
     b) Info sharing: revealing budget, timeline, decision process, competitive intel
   - If only one signal type, cap at 40. If neither, use 0-20.
   - Mark internal team members (e.g. @pendo.io) with isInternal=true

3. Next Best Actions with SPECIFIC ownership:
   - For sales team actions: use the specific sales rep or SE name from the meeting
   - For prospect actions: use the specific customer contact name who committed to the action
   - Include their email if mentioned

4. Pain points - THEME each by business objective:
   - operational_efficiency, customer_experience, revenue_growth, cost_reduction
   - compliance_risk, digital_transformation, data_insights, team_productivity

5. Use cases - THEME similarly, merge duplicates, distinguish business outcomes vs implementation needs

6. Competitor mentions

7. Content type (meeting vs email)

8. Meeting Purpose Classification - Determine the PRIMARY purpose of this meeting:
   - discovery: Initial qualification, needs finding, pain point exploration
   - demo: Product demonstration, feature walkthrough, showing capabilities
   - technical: Architecture review, integration planning, API discussion
   - evaluation_workshop: Hands-on POC, evaluation session, proof of concept
   - workshop: Collaborative working session (non-evaluation)
   - dry_run: Practice demo, presentation rehearsal, internal prep
   - executive: C-level briefing, board presentation, executive sponsor meeting
   - commercial: Pricing discussion, commercial terms, proposal review
   - negotiation: Active contract negotiation, term haggling
   - contract: Legal review, redlining, MSA discussion
   - check_in: Regular status update, weekly sync
   - training: User training, enablement session
   - onboarding: Customer onboarding, setup, go-live planning
   - qbr: Quarterly business review
   
   Key signals: Who is speaking most? What topics dominate? Is there a product walkthrough (demo) vs open-ended questions (discovery)?
   Provide confidence 0-1 and list any secondary purposes.

IMPORTANT: Every external stakeholder MUST have influenceLevel, sentiment, and championScore as numbers (not null) based on evidence from the transcript. Differentiate scores based on actual behavior observed.`;


          const pass1Response = await Promise.race([
            fetch(aiConfig.endpoint, {
              method: "POST",
              headers: {
                Authorization: `Bearer ${aiConfig.apiKey}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                model: aiConfig.model,
                messages: [
                  { role: "system", content: pass1Prompt },
                  { role: "user", content: `Analyze:\n\n${transcript}` }
                ],
                tools: [{
                  type: "function",
                  function: {
                    name: "extract_core",
                    description: "Extract core analysis",
                    parameters: pass1CoreSchema
                  }
                }],
                tool_choice: { type: "function", function: { name: "extract_core" } }
              }),
            }),
            new Promise((_, reject) => setTimeout(() => reject(new Error(`Pass 1 timeout after ${pass1Timeout}ms`)), pass1Timeout))
          ]) as Response;

          if (!pass1Response.ok) {
            const errText = await pass1Response.text().catch(() => "");
            console.error("[Streaming] Pass 1 upstream error:", errText?.slice(0, 2000));
            const errMsg = `Pass 1 failed: ${pass1Response.status}${errText ? ` - ${errText.slice(0, 200)}` : ''}`;
            await logPassEnd(supabaseUrl, serviceRoleKey, pass1LogId, 'failed', pass1StartTime, { 
              errorMessage: errMsg, 
              errorCategory: pass1Response.status === 400 ? 'schema_explosion' : 'ai_error' 
            });
            throw new Error(errMsg);
          }

          const pass1Data = await pass1Response.json();
          const pass1Result = JSON.parse(pass1Data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}");

          const pass1Tokens = pass1Data.usage;
          await logPassEnd(supabaseUrl, serviceRoleKey, pass1LogId, 'completed', pass1StartTime, {
            inputTokens: pass1Tokens?.prompt_tokens,
            outputTokens: pass1Tokens?.completion_tokens,
            resultSummary: { 
              technologies: pass1Result.technologies?.length || 0,
              people: pass1Result.people?.length || 0,
              nbas: pass1Result.nextBestActions?.length || 0,
            },
          });

          // Persist meeting_type + call_summary to transcript_reviews if we have a transcriptReviewId
          if (transcriptReviewId) {
            try {
              const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
              const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
              const supabase = createClient(supabaseUrl, supabaseKey);
              
              const updatePayload: Record<string, unknown> = {
                meeting_type: pass1Result.meetingPurpose?.meetingType ?? null,
                meeting_type_confidence: pass1Result.meetingPurpose?.confidence ?? null,
              };

              if (pass1Result.callSummary?.quickRecap) {
                updatePayload.call_summary = pass1Result.callSummary;
              }

              const { error: mtError } = await supabase
                .from('transcript_reviews')
                .update(updatePayload)
                .eq('id', transcriptReviewId);
              
              if (mtError) {
                console.error(`[Streaming] Failed to persist meeting_type/call_summary: ${mtError.message}`);
              } else {
                console.log(`[Streaming] Persisted meeting_type="${pass1Result.meetingPurpose?.meetingType ?? 'unknown'}" and call_summary=${Boolean(pass1Result.callSummary?.quickRecap)} for transcript ${transcriptReviewId}`);
              }
            } catch (persistErr) {
              console.error(`[Streaming] Error persisting meeting_type/call_summary:`, persistErr);
            }
          }

          sendSSE(controller, "pass_complete", { 
            pass: 1, 
            result: pass1Result,
            progress: 35 
          });

          // ========== PASS 2: Stage Assessment & Commercial Insights ==========
          const pass2LogId = transcriptReviewId
            ? await logPassStart(supabaseUrl, serviceRoleKey, transcriptReviewId, 'call_summary', 'Stage & Commercial', 'core')
            : null;
          const pass2StartTime = Date.now();

          sendSSE(controller, "progress", { 
            pass: 2, 
            totalPasses: skipEnrichment ? 2 : 4,
            stage: "Assessing sales stage & commercial insights...",
            progress: 40 
          });

          const pass2Context = `Context from initial analysis:
- Pain points: ${pass1Result.painPoints?.join(', ') || 'None'}
- Use cases: ${pass1Result.useCases?.join(', ') || 'None'}  
- Competitors: ${pass1Result.competitorMentions?.join(', ') || 'None'}`;

          const pass2Prompt = `Analyze this sales transcript for:
1. Sales Stage (0-6): 0=Initial contact, 1=Info sharing, 2=Problem discussion, 3=Solution benefits, 4=Procurement access, 5=Purchase ready, 6=Active user
2. Pre-Sales Stage: Not Started, Discovery, Demo, Proof-Scoping, Proof, Technical Win/Loss, Stale, Unqualified
3. Commercial Insights (SWOT): Strengths, Weaknesses, Opportunities, Threats
4. Operational Metrics - IMPORTANT: Extract ALL quantifiable numbers, percentages, and measurements mentioned. Examples:
   - User counts: "500 users", "10,000 MAU", "50 developers"
   - Volumes: "2000 tickets/month", "500 support cases", "100 deployments/week"
   - Costs: "$50k budget", "cost per ticket", "$200/user", "saved $1M"
   - Time metrics: "2 hours saved per ticket", "30 min onboarding", "3 week implementation"
   - Percentages: "40% churn", "20% adoption", "80% reduction"
   - Performance: "99.9% uptime", "3 second load time"
   For EACH metric, capture the actual number in metricNumericValue if available.
5. Discovery Questions asked

${pass2Context}`;

          let pass2Result: any = {};
          try {
            const pass2Response = await Promise.race([
              fetch(aiConfig.endpoint, {
                method: "POST",
                headers: {
                  Authorization: `Bearer ${aiConfig.apiKey}`,
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  model: aiConfig.model,
                  messages: [
                    { role: "system", content: pass2Prompt },
                    { role: "user", content: `Analyze:\n\n${transcript}` }
                  ],
                  tools: [{
                    type: "function",
                    function: {
                      name: "assess_stage",
                      description: "Assess stage and commercial insights",
                      parameters: pass2StageSchema
                    }
                  }],
                  tool_choice: { type: "function", function: { name: "assess_stage" } }
                }),
              }),
              new Promise((_, reject) => setTimeout(() => reject(new Error(`Pass 2 timeout after ${pass1Timeout}ms`)), pass1Timeout))
            ]) as Response;

            if (pass2Response.ok) {
              const pass2Data = await pass2Response.json();
              pass2Result = JSON.parse(pass2Data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}");
              await logPassEnd(supabaseUrl, serviceRoleKey, pass2LogId, 'completed', pass2StartTime, {
                inputTokens: pass2Data.usage?.prompt_tokens,
                outputTokens: pass2Data.usage?.completion_tokens,
              });
            } else {
              console.error("Pass 2 failed, continuing with partial results");
              await logPassEnd(supabaseUrl, serviceRoleKey, pass2LogId, 'failed', pass2StartTime, {
                errorMessage: `Pass 2 HTTP ${pass2Response.status}`,
                errorCategory: 'ai_error',
              });
            }
          } catch (err) {
            console.error("Pass 2 error, continuing with partial results:", err);
            await logPassEnd(supabaseUrl, serviceRoleKey, pass2LogId, 'failed', pass2StartTime, {
              errorMessage: err instanceof Error ? err.message : 'Unknown error',
              errorCategory: err instanceof Error && err.message.includes('timeout') ? 'timeout' : 'ai_error',
            });
            pass2Result = {};
          }

          sendSSE(controller, "pass_complete", { 
            pass: 2, 
            result: pass2Result,
            progress: 65 
          });

          // Combine core results (Pass 1 + 2)
          const coreResult = {
            ...pass1Result,
            ...pass2Result,
            insights: {
              painPoints: pass1Result.painPoints || [],
              useCases: pass1Result.useCases || [],
              competitorMentions: pass1Result.competitorMentions || [],
            }
          };

          // If skipEnrichment, we're done - queue enrichment for background processing
          if (skipEnrichment) {
            sendSSE(controller, "core_complete", { 
              result: coreResult,
              enrichmentQueued: true,
              progress: 100 
            });
            sendSSE(controller, "done", { success: true });
            safeClose(controller);
            return;
          }

          // ========== PASS 3 & 4 would go here for immediate enrichment ==========
          // For now, we always use async enrichment for better UX
          sendSSE(controller, "core_complete", { 
            result: coreResult,
            enrichmentQueued: true,
            progress: 100 
          });
          sendSSE(controller, "done", { success: true });
          safeClose(controller);

        } catch (error) {
          console.error("Streaming analysis error:", error);
          sendSSE(controller, "error", { 
            message: error instanceof Error ? error.message : "Unknown error" 
          });
          safeClose(controller);
        }
      }
    });

    return new Response(stream, {
      headers: {
        ...corsHeaders,
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
      },
    });

  } catch (error) {
    console.error("analyze-transcript-streaming error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

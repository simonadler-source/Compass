import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-session-token',
};

// ==================== RESILIENCE / TIMEOUTS ====================
// Fail-fast for DB/network stalls to avoid tying up limited connections/workers.
const DB_QUERY_TIMEOUT_MS = 10000;
// PostgREST URLs can become huge with `.in()`; chunk large lists to avoid request failures.
const MAX_IN_FILTER_VALUES = 50;

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isTransientDbError(err: any): boolean {
  const msg = String(err?.message ?? err ?? '').toLowerCase();
  return (
    msg.includes('error sending request') ||
    msg.includes('failed to fetch') ||
    msg.includes('timeout') ||
    msg.includes('timed out') ||
    msg.includes('connection terminated') ||
    msg.includes('connection reset') ||
    msg.includes('could not query the database') ||
    msg.includes('service unavailable') ||
    msg.includes('cloudflare') ||
    msg.includes('522') ||
    msg.includes('504')
  );
}

function withGatewayTimeout<T>(promise: Promise<T>, ms: number, errorMessage: string): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => {
      setTimeout(() => reject(new Error(errorMessage)), ms);
    }),
  ]);
}

function makeServiceUnavailableError(message: string) {
  return { message, code: 'SERVICE_UNAVAILABLE' };
}

// ==================== ENCRYPTION HELPERS ====================
// Primary key derivation - handles hex keys
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < Math.min(raw.length, 32); i++) key[i] = raw[i];
  return key;
}

// Legacy key derivation - always uses raw text (for backward compatibility)
function deriveKeyBytesLegacy(keyInput: string): Uint8Array {
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < Math.min(raw.length, 32); i++) key[i] = raw[i];
  return key;
}

// Some older utilities derived keys by hashing the input.
async function deriveKeyBytesHashed(keyInput: string): Promise<Uint8Array> {
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const digest = await crypto.subtle.digest('SHA-256', raw);
  return new Uint8Array(digest);
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function encrypt(plaintext: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plainBytes = new TextEncoder().encode(plaintext);
  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv.buffer as ArrayBuffer }, key, plainBytes);
  return { ciphertext: bytesToBase64(new Uint8Array(cipherBytes)), iv: bytesToBase64(iv) };
}

async function decryptWithKey(ciphertext: string, iv: Uint8Array, cipherBytes: Uint8Array, keyInput: string): Promise<string | null> {
  const tryDecryptWith = async (keyBytes: Uint8Array) => {
    const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["decrypt"]);
    const plainBytes = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv.buffer as ArrayBuffer },
      key,
      cipherBytes.buffer as ArrayBuffer
    );
    return new TextDecoder().decode(plainBytes);
  };

  // Try current derivation, then legacy, then hashed.
  try {
    return await tryDecryptWith(deriveKeyBytes(keyInput));
  } catch {
    try {
      return await tryDecryptWith(deriveKeyBytesLegacy(keyInput));
    } catch {
      try {
        return await tryDecryptWith(await deriveKeyBytesHashed(keyInput));
      } catch {
        return null;
      }
    }
  }
}

async function decrypt(ciphertext: string, ivBase64: string, keyInput: string, suppressLogging: boolean = false): Promise<string | null> {
  try {
    const iv = base64ToBytes(ivBase64);
    const cipherBytes = base64ToBytes(ciphertext);

    // Try primary key first
    const result = await decryptWithKey(ciphertext, iv, cipherBytes, keyInput);
    if (result !== null) {
      return result;
    }

    // Fallback to alternate key if primary failed
    const alternateKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE");
    if (alternateKey) {
      const altResult = await decryptWithKey(ciphertext, iv, cipherBytes, alternateKey);
      if (altResult !== null) {
        return altResult;
      }
    }

    // All decryption methods failed
    return null;
  } catch (e) {
    // Handle any parsing errors (invalid base64, etc.)
    if (!suppressLogging) {
      console.error(`[Gateway] Decrypt parsing error:`, e);
    }
    return null;
  }
}

// ==================== TABLE CONFIGURATIONS ====================
// Tables that require encryption
const ENCRYPTED_TABLES: Record<string, { fields: string[]; ivField: string; directEncryptOnly?: boolean }> = {
  // account_contacts: plaintext columns (name, email, phone, role, notes) were dropped.
  // The table now only has *_encrypted columns, so we use directEncryptOnly mode.
  'account_contacts': { 
    fields: ['name', 'email', 'phone', 'role', 'notes'], 
    ivField: 'encryption_iv',
    directEncryptOnly: true,  // No plaintext columns to null out
  },
  'account_nbas': { 
    fields: ['action', 'notes'], 
    ivField: 'encryption_iv',
    directEncryptOnly: true,
  },
  'account_pain_points': { 
    fields: ['pain_point', 'business_impact'], 
    ivField: 'encryption_iv',
    directEncryptOnly: true,
  },
  'account_use_cases': { 
    fields: ['use_case', 'description'], 
    ivField: 'encryption_iv',
    directEncryptOnly: true,
  },
  'account_metrics': { 
    fields: ['metric_value', 'context', 'mentioned_by_name', 'mentioned_by_email'], 
    ivField: 'encryption_iv',
    directEncryptOnly: true,
  },
  'account_strategic_themes': { 
    fields: ['theme_name', 'description', 'supporting_evidence'], 
    ivField: 'encryption_iv',
    directEncryptOnly: true,
  },
  'account_exec_summaries': { 
    fields: ['summary_narrative', 'key_risks', 'key_opportunities', 'health_indicators', 'engagement_summary'], 
    ivField: 'encryption_iv' 
  },
  'account_team_members': { 
    fields: ['team_member_email'], 
    ivField: 'encryption_iv' 
  },
  'account_captured_insights': { 
    fields: ['value', 'value_json'], 
    ivField: 'encryption_iv' 
  },
  'contact_meeting_snapshots': { 
    fields: ['notes', 'key_quotes', 'topics_discussed', 'concerns_raised', 'action_items'], 
    ivField: 'encryption_iv' 
  },
  'customer_stories': { 
    fields: ['situation', 'behavior', 'impact', 'impact_metrics'], 
    ivField: 'encryption_iv' 
  },
  'competitor_scores': { 
    fields: ['rationale'], 
    ivField: 'encryption_iv' 
  },
  'competitors': { 
    fields: ['description', 'relationship_notes'], 
    ivField: 'encryption_iv' 
  },
  'account_technologies': { 
    fields: ['owner_name', 'owner_email', 'notes', 'context'], 
    ivField: 'encryption_iv' 
  },
  'account_documents': { 
    fields: ['content', 'name', 'description', 'owner_email'], 
    ivField: 'encryption_iv' 
  },
  'transcript_reviews': { 
    fields: ['transcript_content'], 
    ivField: 'encryption_iv' 
  },
  'momentum_meetings': { 
    fields: ['title', 'host_email', 'host_name', 'attendees', 'transcript_content'], 
    ivField: 'pii_encryption_iv' 
  },
  'opportunity_readiness_answers': { 
    fields: ['answer', 'notes'], 
    ivField: 'encryption_iv' 
  },
};

// Tables that are allowed through the gateway
const ALLOWED_TABLES = new Set([
  // Core entities
  'accounts', 'opportunities', 'profiles', 'team_members', 'account_documents',
  // Deletion tombstones (prevents auto-recreate after intentional deletes)
  'opportunity_deletion_tombstones',
  // Encrypted tables
  ...Object.keys(ENCRYPTED_TABLES),
  // Reference/config tables
  'functional_areas', 'technology_repository', 'technology_relationships', 'account_technologies',
  'layers', 'activity_types', 'deployment_types', 'use_case_templates',
  'competitors', 'competitive_categories', 'competitive_features',
  'detection_rules', 'detection_rule_trees', 'detection_rule_matches',
  'detection_rule_capture_fields', 'detection_rule_questions', 
  'detection_rule_nba_templates', 'detection_rule_readiness_mappings',
  'detection_rule_actions',  // Unified actions table
  'readiness_template_questions', 'readiness_template_categories', 'readiness_sub_questions', 'validation_task_templates',
  'opportunity_deployment_types',
  'milestone_templates', 'discovery_questions',
  'opportunity_milestones', 'opportunity_validation_tasks', 'opportunity_activities',
  'opportunity_team_members', 'architecture_versions',
  'notifications', 'system_notifications', 'user_roles', 'custom_roles',
  'ai_settings', 'ai_provider_settings',
  // Analysis pipeline
  'analysis_pipelines', 'analysis_passes', 'analysis_pass_dependencies', 'analysis_pass_versions',
  // Team/hierarchy
  'team_hierarchy', 'page_role_access',
  // Momentum
  'momentum_meetings', 'momentum_sync_state',
  // Product analytics
  'product_mentions',
  // CEP/Stage tracking
  'pre_sales_stage_mapping', 'opportunity_stage_history',
  // Metric history
  'account_metric_history', 'opportunity_metric_history',
  // Pricing
  'module_pricing', 'pricing_settings',
  // Use case template mappings
  'use_case_template_products',
  // NBA due date tracking
  'nba_due_date_changes',
  // Signal occurrences for history tracking
  'signal_occurrences',
  // Email notifications
  'notification_preferences', 'email_templates', 'notification_types', 'email_queue', 'email_log',
  // Auth/login tracking
  'login_history', 'user_sessions',
  // Readiness history for pending changes
  'technical_readiness_history',
  // Stakeholder history for sentiment tracking
  'stakeholder_history',
  // Additional history tables
  'validation_task_history', 'nba_completion_history', 'milestone_history',

  // Product mention suppression
  'suppressed_product_mentions',

  // Opportunity alert rules
  'opportunity_alert_rules',
  'opportunity_alert_history',

  // Technology extraction suppression/rejection
  'suppressed_extracted_technologies',
  'rejected_technology_detections',
  'rejected_competitor_mentions',

  // Competitive intelligence
  'competitive_rubric', 'competitive_scorecard', 'competitive_sources', 'competitive_audit_log',
  'competitive_plays', 'opportunity_competitive_insights', 'competitive_play_suggestions',

  // MCP service
  'mcp_api_keys', 'mcp_access_logs',

  // Opportunity sharing
  'opportunity_share_links',

  // SE opportunity updates
  'opportunity_se_updates',

  // SE coaching scores
  'se_coaching_scores',

  // Readiness apps (per-application tracking)
  'opportunity_readiness_apps',

  // Evaluation deck
  'evaluation_success_criteria', 'evaluation_technical_risks', 'success_criteria_deliverables',

  // Manual meetings
  'manual_meetings',

  // AI opportunity summaries
  'opportunity_summaries',
]);

// Tables where only admins can perform mutations (select is allowed for authenticated users)
const ADMIN_ONLY_MUTATION_TABLES = new Set([
  'opportunity_alert_rules',
  'opportunity_alert_history',
]);

async function isAdminUser(supabase: any, userId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', userId)
      .in('role', ['admin', 'super_admin'])
      .limit(1);

    if (error) return false;
    return Array.isArray(data) && data.length > 0;
  } catch {
    return false;
  }
}

// ==================== SESSION VALIDATION ====================
// Timeout for session validation to fail fast
const SESSION_VALIDATION_TIMEOUT_MS = 8000;
const SESSION_VALIDATION_CACHE_TTL_MS = 30_000;
const SESSION_VALIDATION_STALE_GRACE_MS = 90_000;
const SESSION_VALIDATION_DEGRADED_TTL_MS = 10_000;
const SESSION_VALIDATION_CACHE_MAX_ENTRIES = 2000;
const SESSION_VALIDATION_MAX_RETRIES = 3;
const SESSION_VALIDATION_RETRY_BASE_MS = 200;

type SessionValidationResult = { valid: boolean; userId?: string; error?: string };
type SessionCacheEntry = {
  userId: string;
  expiresAt: number;
  staleUntil: number;
  touchedAt: number;
};

const sessionValidationCache = new Map<string, SessionCacheEntry>();
const sessionValidationInflight = new Map<string, Promise<SessionValidationResult>>();

function pruneSessionValidationCache(now: number) {
  // Remove entries that are well beyond their stale grace period first.
  for (const [token, entry] of sessionValidationCache.entries()) {
    if (entry.staleUntil <= now) {
      sessionValidationCache.delete(token);
    }
  }

  if (sessionValidationCache.size <= SESSION_VALIDATION_CACHE_MAX_ENTRIES) return;

  const sortedByTouch = [...sessionValidationCache.entries()].sort((a, b) => a[1].touchedAt - b[1].touchedAt);
  const toRemove = sortedByTouch.slice(0, sessionValidationCache.size - SESSION_VALIDATION_CACHE_MAX_ENTRIES);
  for (const [token] of toRemove) {
    sessionValidationCache.delete(token);
  }
}

function writeSessionValidationCache(sessionToken: string, userId: string, ttlMs: number = SESSION_VALIDATION_CACHE_TTL_MS) {
  const now = Date.now();
  sessionValidationCache.set(sessionToken, {
    userId,
    expiresAt: now + ttlMs,
    staleUntil: now + ttlMs + SESSION_VALIDATION_STALE_GRACE_MS,
    touchedAt: now,
  });
  pruneSessionValidationCache(now);
}

function readSessionValidationCache(sessionToken: string): { fresh?: SessionCacheEntry; stale?: SessionCacheEntry } {
  const entry = sessionValidationCache.get(sessionToken);
  if (!entry) return {};

  const now = Date.now();
  entry.touchedAt = now;

  if (entry.expiresAt > now) {
    return { fresh: entry };
  }
  if (entry.staleUntil > now) {
    return { stale: entry };
  }

  sessionValidationCache.delete(sessionToken);
  return {};
}

async function runValidateSessionRpc(supabase: any, sessionToken: string): Promise<{ data: any; error: any }> {
  let lastTransientError: any = null;

  for (let attempt = 0; attempt < SESSION_VALIDATION_MAX_RETRIES; attempt++) {
    try {
      const { data, error } = await withGatewayTimeout(
        supabase.rpc('validate_session', { _token: sessionToken }),
        SESSION_VALIDATION_TIMEOUT_MS,
        'Session validation timed out'
      );

      if (!error) {
        return { data, error: null };
      }

      if (isTransientDbError(error) && attempt < SESSION_VALIDATION_MAX_RETRIES - 1) {
        lastTransientError = error;
        const backoffMs = SESSION_VALIDATION_RETRY_BASE_MS * (attempt + 1) + Math.floor(Math.random() * 150);
        console.warn(`[Gateway] Session validation transient RPC error (attempt ${attempt + 1}/${SESSION_VALIDATION_MAX_RETRIES}), retrying in ${backoffMs}ms`);
        await sleep(backoffMs);
        continue;
      }

      return { data, error };
    } catch (error) {
      if (isTransientDbError(error) && attempt < SESSION_VALIDATION_MAX_RETRIES - 1) {
        lastTransientError = error;
        const backoffMs = SESSION_VALIDATION_RETRY_BASE_MS * (attempt + 1) + Math.floor(Math.random() * 150);
        console.warn(`[Gateway] Session validation transient exception (attempt ${attempt + 1}/${SESSION_VALIDATION_MAX_RETRIES}), retrying in ${backoffMs}ms`);
        await sleep(backoffMs);
        continue;
      }
      throw error;
    }
  }

  return { data: null, error: lastTransientError ?? new Error('Session validation failed') };
}

async function validateSession(supabase: any, sessionToken: string): Promise<SessionValidationResult> {
  if (!sessionToken) {
    return { valid: false, error: 'No session token provided' };
  }

  const cached = readSessionValidationCache(sessionToken);
  if (cached.fresh) {
    return { valid: true, userId: cached.fresh.userId };
  }

  const inflight = sessionValidationInflight.get(sessionToken);
  if (inflight) {
    return await inflight;
  }

  const validationPromise = (async (): Promise<SessionValidationResult> => {
    try {
      const { data, error } = await runValidateSessionRpc(supabase, sessionToken);

      if (error) {
        // On transient auth-store pressure, allow a short stale-cache grace fallback.
        if (isTransientDbError(error)) {
          if (cached.stale) {
            console.warn('[Gateway] Session validation transient error, using stale session cache fallback');
            writeSessionValidationCache(sessionToken, cached.stale.userId, SESSION_VALIDATION_DEGRADED_TTL_MS);
            return { valid: true, userId: cached.stale.userId };
          }
          console.error('[Gateway] Transient error during session validation:', error.message);
          return { valid: false, error: 'SERVICE_UNAVAILABLE:' + error.message };
        }

        sessionValidationCache.delete(sessionToken);
        return { valid: false, error: error.message || 'Invalid or expired session' };
      }

      if (!data || data.length === 0) {
        sessionValidationCache.delete(sessionToken);
        return { valid: false, error: 'Invalid or expired session' };
      }

      const session = data[0];
      if (session.status !== 'active') {
        sessionValidationCache.delete(sessionToken);
        return { valid: false, error: 'User account is not active' };
      }

      writeSessionValidationCache(sessionToken, session.user_id);
      return { valid: true, userId: session.user_id };
    } catch (timeoutError: any) {
      if (isTransientDbError(timeoutError)) {
        if (cached.stale) {
          console.warn('[Gateway] Session validation timeout, using stale session cache fallback');
          writeSessionValidationCache(sessionToken, cached.stale.userId, SESSION_VALIDATION_DEGRADED_TTL_MS);
          return { valid: true, userId: cached.stale.userId };
        }
        console.error('[Gateway] Transient error during session validation:', timeoutError?.message);
        return { valid: false, error: 'SERVICE_UNAVAILABLE:' + (timeoutError?.message || 'Connection error') };
      }

      console.error('[Gateway] Session validation timeout:', timeoutError?.message);
      return { valid: false, error: 'SERVICE_UNAVAILABLE:Session validation timed out' };
    }
  })();

  sessionValidationInflight.set(sessionToken, validationPromise);
  try {
    return await validationPromise;
  } finally {
    sessionValidationInflight.delete(sessionToken);
  }
}

function chunkArray<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function safeCompare(a: any, b: any) {
  if (a == null && b == null) return 0;
  if (a == null) return -1;
  if (b == null) return 1;
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b));
}

// ==================== ENCRYPTION/DECRYPTION HANDLERS ====================
async function encryptWithIv(plaintext: string, ivBytes: Uint8Array, keyInput: string): Promise<string> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt"]);
  const plainBytes = new TextEncoder().encode(plaintext);
  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv: ivBytes.buffer as ArrayBuffer }, key, plainBytes);
  return bytesToBase64(new Uint8Array(cipherBytes));
}

async function encryptRecord(
  table: string, 
  record: Record<string, any>, 
  encryptionKey: string
): Promise<Record<string, any>> {
  const config = ENCRYPTED_TABLES[table];
  if (!config) return record;

  const result = { ...record };
  
  // Generate ONE IV for all fields in this record
  const ivBytes = crypto.getRandomValues(new Uint8Array(12));
  const ivBase64 = bytesToBase64(ivBytes);
  let hasEncryptedFields = false;

  for (const field of config.fields) {
    const value = record[field];
    if (value !== null && value !== undefined) {
      const stringValue = typeof value === 'object' ? JSON.stringify(value) : String(value);
      result[`${field}_encrypted`] = await encryptWithIv(stringValue, ivBytes, encryptionKey);
      
      // For directEncryptOnly tables, the plaintext columns no longer exist in the DB
      // so we just remove them from the result instead of setting to null
      if (config.directEncryptOnly) {
        delete result[field];
      } else if (table === 'account_documents' && field === 'name') {
        // For fields with NOT NULL constraints, keep a placeholder instead of nulling them
        result[field] = '[Encrypted]';
      } else {
        result[field] = null; // Clear plaintext
      }
      hasEncryptedFields = true;
    }
  }

  if (hasEncryptedFields) {
    result[config.ivField] = ivBase64;
    result.is_encrypted = true;
  }

  return result;
}

async function decryptRecord(
  table: string, 
  record: Record<string, any>, 
  encryptionKey: string,
  suppressLogging: boolean = false
): Promise<Record<string, any>> {
  const config = ENCRYPTED_TABLES[table];
  if (!config || !record.is_encrypted) return record;

  const result = { ...record };
  const iv = record[config.ivField];

  if (!iv) {
    if (!suppressLogging) {
      console.warn(`[Gateway] No IV found for encrypted record in ${table}, field: ${config.ivField}`);
    }
    return result;
  }

  if (!encryptionKey) {
    if (!suppressLogging) {
      console.error(`[Gateway] No encryption key provided for decrypting ${table}`);
    }
    return result;
  }

  let decryptedCount = 0;
  let failedCount = 0;

  for (const field of config.fields) {
    const encryptedField = `${field}_encrypted`;
    const encryptedValue = record[encryptedField];
    
    if (encryptedValue) {
      const decrypted = await decrypt(encryptedValue, iv, encryptionKey, suppressLogging);
      if (decrypted === null) {
        // Important: if legacy plaintext exists, DO NOT overwrite it with null.
        // This prevents blank UI when encryption flags are inconsistent or keys rotated.
        result[field] = record[field] ?? null;
        failedCount++;
      } else if (decrypted.startsWith('{') || decrypted.startsWith('[')) {
        // Try to parse as JSON if it looks like JSON
        try {
          result[field] = JSON.parse(decrypted);
        } catch {
          result[field] = decrypted;
        }
        decryptedCount++;
      } else {
        result[field] = decrypted;
        decryptedCount++;
      }
    }
  }

  // Only log summary if there were failures and logging is not suppressed
  if (failedCount > 0 && !suppressLogging) {
    console.warn(`[Gateway] ${table}: ${failedCount} field(s) failed decryption`);
  }

  return result;
}

// Maximum records to decrypt in a single batch to prevent memory exhaustion
const DECRYPT_BATCH_SIZE = 25;

// Limit concurrent decrypt operations to avoid memory spikes (Promise.all on large batches is expensive)
const DECRYPT_CONCURRENCY = 5;

async function mapWithConcurrency<T, R>(
  items: T[],
  concurrency: number,
  mapper: (item: T, index: number) => Promise<R>
): Promise<R[]> {
  if (items.length === 0) return [];
  const limit = Math.max(1, Math.min(concurrency, items.length));
  const results = new Array<R>(items.length);
  let nextIndex = 0;

  const workers = Array.from({ length: limit }, async () => {
    while (true) {
      const i = nextIndex++;
      if (i >= items.length) break;
      results[i] = await mapper(items[i], i);
    }
  });

  await Promise.all(workers);
  return results;
}

async function decryptRecords(
  table: string, 
  records: Record<string, any>[], 
  encryptionKey: string,
  skipLargeBlobs: boolean = false
): Promise<Record<string, any>[]> {
  if (records.length === 0) return [];

  // For bulk queries, skip decrypting large blob fields to prevent memory issues
  const blobExclusions = skipLargeBlobs ? (LARGE_BLOB_EXCLUSIONS[table] || []) : [];
  
  // Suppress per-record logging for bulk operations to reduce memory usage
  const suppressLogging = records.length > 5;
  
  // Process in batches to prevent memory exhaustion
  const results: Record<string, any>[] = [];
  
  for (let i = 0; i < records.length; i += DECRYPT_BATCH_SIZE) {
    const batch = records.slice(i, i + DECRYPT_BATCH_SIZE);

    const batchResults = await mapWithConcurrency(batch, DECRYPT_CONCURRENCY, async (r) => {
      // CRITICAL: Remove large blob fields BEFORE decryption to prevent memory exhaustion
      // This avoids loading and processing megabytes of encrypted data that will be discarded anyway
      if (blobExclusions.length > 0) {
        for (const field of blobExclusions) {
          delete r[field];
          delete r[`${field}_encrypted`];
        }
      }

      return await decryptRecord(table, r, encryptionKey, suppressLogging);
    });
    
    results.push(...batchResults);
  }
  
  // Log summary for bulk operations
  if (suppressLogging && records.length > 0) {
    console.log(`[Gateway] Decrypted ${results.length} ${table} records`);
  }
  
  return results;
}

// ==================== UUID VALIDATION ====================
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const SALESFORCE_ID_COLUMNS = new Set([
  'salesforce_account_id',
  'salesforce_opportunity_id',
  'salesforce_contact_id',
]);

function isUuidColumn(column: string): boolean {
  if (SALESFORCE_ID_COLUMNS.has(column)) return false;
  return column === 'id' || column.endsWith('_id');
}

function validateUuidFilters(filters: Array<{ column: string; operator: string; value: any }> | undefined): string | null {
  if (!filters) return null;
  for (const filter of filters) {
    if (!isUuidColumn(filter.column)) continue;
    if (filter.operator === 'is' || filter.operator === 'not.is') continue; // NULL checks are fine
    if (filter.operator === 'in') {
      if (Array.isArray(filter.value)) {
        for (const v of filter.value) {
          if (typeof v === 'string' && !UUID_REGEX.test(v)) {
            return `Invalid UUID value "${v}" for column "${filter.column}"`;
          }
        }
      }
      continue;
    }
    if (typeof filter.value === 'string' && !UUID_REGEX.test(filter.value)) {
      return `Invalid UUID value "${filter.value}" for column "${filter.column}"`;
    }
  }
  return null;
}

// ==================== QUERY BUILDER ====================
interface QueryParams {
  select?: string;
  filters?: Array<{ column: string; operator: string; value: any }>;
  order?: { column: string; ascending?: boolean };
  limit?: number;
  offset?: number;
  single?: boolean;
  maybeSingle?: boolean;
  onConflict?: string;
  countOnly?: boolean;
}

// Tables with large blob fields that should be excluded from bulk queries (select *)
// These fields cause memory/timeout issues when decrypting many records
const LARGE_BLOB_EXCLUSIONS: Record<string, string[]> = {
  'transcript_reviews': ['transcript_content', 'transcript_content_encrypted'],
  'momentum_meetings': ['transcript_content', 'transcript_content_encrypted'],
};

// Build a safe select clause that excludes large blobs for bulk queries
function buildSafeSelectClause(table: string, selectClause?: string, isSingleRecord?: boolean): string {
  const base = (selectClause && selectClause.trim().length > 0) ? selectClause.trim() : '*';
  
  // If it's a single record query, allow full select (user explicitly wants one record)
  if (isSingleRecord) return base;
  
  // If not using wildcard, the caller knows what they want
  if (base !== '*') return base;
  
  // Check if this table has large blob exclusions
  const exclusions = LARGE_BLOB_EXCLUSIONS[table];
  if (!exclusions) return base;
  
  // For bulk queries with *, we need to explicitly list columns excluding blobs
  // This is a safety net - frontend should already be selecting specific columns
  console.log(`[Gateway] WARNING: Bulk query on ${table} with select(*) - excluding large blob fields for performance`);
  
  // Return * but the decryptRecords function will skip blob fields for bulk queries
  return base;
}

function augmentSelectForEncryptedTable(table: string, selectClause?: string, isSingleRecord?: boolean): string {
  const config = ENCRYPTED_TABLES[table];
  
  // First apply blob exclusions for bulk queries
  const safeBase = buildSafeSelectClause(table, selectClause, isSingleRecord);
  
  if (!config) return safeBase;

  const base = safeBase;
  if (base === '*') return '*';

  // For directEncryptOnly tables, plaintext columns don't exist in DB - replace with encrypted versions
  let augmented = base;
  if (config.directEncryptOnly) {
    // Replace plaintext field names with their encrypted counterparts,
    // but only at the top level — skip fields inside relation parentheses like accounts:account_id(name)
    // Strategy: split select into top-level segments and relation segments, only transform top-level
    const relationPattern = /([a-zA-Z_]+:[a-zA-Z_]+\([^)]*\))/g;
    const relations: string[] = [];
    const topLevel = augmented.replace(relationPattern, (match) => {
      relations.push(match);
      return `__REL_${relations.length - 1}__`;
    });

    let transformed = topLevel;
    for (const field of config.fields) {
      const regex = new RegExp(`\\b${field}\\b(?!_encrypted)`, 'g');
      transformed = transformed.replace(regex, `${field}_encrypted`);
    }

    // Restore relation segments untouched
    for (let i = 0; i < relations.length; i++) {
      transformed = transformed.replace(`__REL_${i}__`, relations[i]);
    }
    augmented = transformed;
  }

  // Ensure we always fetch the fields needed to decrypt
  const required = ['is_encrypted', config.ivField, ...config.fields.map((f) => `${f}_encrypted`)];

  for (const col of required) {
    // Use a simple string check; safe enough for our select strings (top-level columns + relations).
    if (!augmented.includes(col)) {
      augmented += `,${col}`;
    }
  }
  return augmented;
}

function normalizeColumnForEncryptedTable(table: string, column: string): string {
  const config = ENCRYPTED_TABLES[table];
  if (!config?.directEncryptOnly) return column;
  if (column.endsWith('_encrypted')) return column;
  if (config.fields.includes(column)) return `${column}_encrypted`;
  return column;
}

function buildQuery(supabase: any, table: string, params: QueryParams) {
  const selectClause = augmentSelectForEncryptedTable(table, params.select);
  let query = supabase.from(table).select(selectClause);

  if (params.filters) {
    for (const filter of params.filters) {
      // Note: for directEncryptOnly tables, plaintext columns don't exist.
      // We map supported filter columns to their *_encrypted counterparts to avoid DB errors.
      const col = normalizeColumnForEncryptedTable(table, filter.column);

      switch (filter.operator) {
        case 'eq': query = query.eq(col, filter.value); break;
        case 'neq': query = query.neq(col, filter.value); break;
        case 'gt': query = query.gt(col, filter.value); break;
        case 'gte': query = query.gte(col, filter.value); break;
        case 'lt': query = query.lt(col, filter.value); break;
        case 'lte': query = query.lte(col, filter.value); break;
        case 'like': query = query.like(col, filter.value); break;
        case 'ilike': query = query.ilike(col, filter.value); break;
        case 'is': query = query.is(col, filter.value); break;
        case 'in': query = query.in(col, filter.value); break;
        case 'contains': query = query.contains(col, filter.value); break;
        case 'containedBy': query = query.containedBy(col, filter.value); break;
        case 'not.is': query = query.not(col, 'is', filter.value); break;
        case 'or': {
          // Client sends OR conditions as a raw PostgREST filter string (e.g. "a.eq.1,b.eq.2")
          // We do not rewrite columns inside this string.
          if (typeof filter.value !== 'string') {
            throw new Error('Invalid or filter: value must be a string');
          }
          query = query.or(filter.value);
          break;
        }
        default: query = query.eq(col, filter.value);
      }
    }
  }

  // Apply ordering
  if (params.order) {
    const orderColumn = normalizeColumnForEncryptedTable(table, params.order.column);
    query = query.order(orderColumn, { ascending: params.order.ascending ?? true });
  }

  // Apply limit
  if (params.limit) {
    query = query.limit(params.limit);
  }

  // Apply offset for pagination
  if (params.offset) {
    query = query.range(params.offset, params.offset + (params.limit || 1000) - 1);
  }

  return query;
}

async function runQueryWithRetry<T>(queryPromise: Promise<T>, label: string): Promise<T> {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      return await withGatewayTimeout(Promise.resolve(queryPromise), DB_QUERY_TIMEOUT_MS, `${label} timed out`);
    } catch (e: any) {
      if (attempt < 1 && isTransientDbError(e)) {
        console.warn(`[Gateway] Transient error during ${label}. Retrying…`, e?.message ?? e);
        await sleep(250);
        continue;
      }
      throw e;
    }
  }
  // Unreachable
  return await queryPromise;
}

// ==================== OPERATION HANDLERS ====================
interface GatewayRequest {
  action: 'select' | 'insert' | 'update' | 'upsert' | 'delete';
  table: string;
  data?: Record<string, any> | Record<string, any>[];
  params?: QueryParams;
  returning?: boolean;
}

async function handleSelect(
  supabase: any, 
  table: string, 
  params: QueryParams,
  encryptionKey: string
): Promise<{ data: any; error: any }> {
  // Count-only mode: return just the count without fetching data
  if (params.countOnly) {
    let query = supabase.from(table).select('id', { count: 'exact', head: true });
    // Apply filters
    if (params.filters) {
      for (const filter of params.filters) {
        if (filter.operator === 'eq') query = query.eq(filter.column, filter.value);
        else if (filter.operator === 'neq') query = query.neq(filter.column, filter.value);
        else if (filter.operator === 'gt') query = query.gt(filter.column, filter.value);
        else if (filter.operator === 'gte') query = query.gte(filter.column, filter.value);
        else if (filter.operator === 'lt') query = query.lt(filter.column, filter.value);
        else if (filter.operator === 'lte') query = query.lte(filter.column, filter.value);
        else if (filter.operator === 'in') query = query.in(filter.column, filter.value);
        else if (filter.operator === 'is') query = query.is(filter.column, filter.value);
        else if (filter.operator === 'not.is') query = query.not(filter.column, 'is', filter.value);
      }
    }
    const { count, error } = await query;
    if (error) return { data: null, error };
    return { data: { count: count || 0 }, error: null };
  }

  const isSingleRecord = params.single || params.maybeSingle;

  // ==================== SAFETY LIMITS ====================
  // transcript_reviews can grow large (hundreds/thousands of rows). Even with blob exclusions,
  // decrypting and returning huge arrays can exceed worker memory/CPU limits.
  // Apply a conservative default limit unless the caller explicitly paginates.
  if (!isSingleRecord && table === 'transcript_reviews') {
    const DEFAULT_TRANSCRIPT_REVIEWS_LIMIT = 200;
    const MAX_TRANSCRIPT_REVIEWS_LIMIT = 300;

    if (params.limit == null) {
      params.limit = DEFAULT_TRANSCRIPT_REVIEWS_LIMIT;
      console.log(`[Gateway] transcript_reviews: applying default limit=${params.limit}`);
    } else if (params.limit > MAX_TRANSCRIPT_REVIEWS_LIMIT) {
      params.limit = MAX_TRANSCRIPT_REVIEWS_LIMIT;
      console.log(`[Gateway] transcript_reviews: clamping limit to ${params.limit}`);
    }
  }

  // If we have a large `.in()` filter, chunk it to avoid oversized URLs / request failures.
  const largeInFilter = params.filters?.find(
    (f) =>
      f.operator === 'in' &&
      Array.isArray(f.value) &&
      f.value.length > MAX_IN_FILTER_VALUES
  ) as any | undefined;

  if (!isSingleRecord && largeInFilter && Array.isArray(largeInFilter.value)) {
    const chunks = chunkArray(largeInFilter.value, MAX_IN_FILTER_VALUES);
    const baseParams: QueryParams = {
      ...params,
      // We'll apply ordering/paging after merging to avoid per-chunk semantics.
      order: undefined,
      limit: undefined,
      offset: undefined,
    };

    const merged: any[] = [];
    for (const chunk of chunks) {
      const chunkParams: QueryParams = {
        ...baseParams,
        filters: (baseParams.filters || []).map((f: any) =>
          f === largeInFilter ? { ...f, value: chunk } : f
        ),
      };

      try {
        const q = buildQuery(supabase, table, chunkParams);
        const { data, error } = await runQueryWithRetry(Promise.resolve(q), `SELECT ${table} (chunked)`);
        if (error) {
          if (isTransientDbError(error)) {
            return { data: null, error: makeServiceUnavailableError(error.message || 'Service temporarily unavailable') };
          }
          return { data: null, error };
        }
        if (Array.isArray(data)) merged.push(...data);
      } catch (e: any) {
        if (isTransientDbError(e)) {
          return { data: null, error: makeServiceUnavailableError(e?.message || 'Service temporarily unavailable') };
        }
        return { data: null, error: { message: e?.message || String(e) } };
      }
    }

    // Apply ordering/pagination in-memory.
    let final = merged;
    if (params.order?.column) {
      const col = normalizeColumnForEncryptedTable(table, params.order.column);
      const asc = params.order.ascending ?? true;
      final = [...final].sort((a, b) => {
        const cmp = safeCompare(a?.[col], b?.[col]);
        return asc ? cmp : -cmp;
      });
    }
    const offset = params.offset ?? 0;
    const limit = params.limit;
    if (offset || limit != null) {
      final = final.slice(offset, limit != null ? offset + limit : undefined);
    }

    // Decrypt if needed
    if (ENCRYPTED_TABLES[table]) {
      const skipLargeBlobs = LARGE_BLOB_EXCLUSIONS[table];
      return { data: await decryptRecords(table, final, encryptionKey, !!skipLargeBlobs), error: null };
    }
    return { data: final, error: null };
  }

  // Normal path (non-chunked)
  try {
    let query = buildQuery(supabase, table, params);

    // Always use maybeSingle() instead of single() to avoid PGRST116 errors
    // when no rows are found. The caller can handle null data appropriately.
    if (isSingleRecord) {
      query = query.maybeSingle();
    }

    const { data, error } = await runQueryWithRetry(Promise.resolve(query), `SELECT ${table}`);

    if (error) {
      if (isTransientDbError(error)) {
        return { data: null, error: makeServiceUnavailableError(error.message || 'Service temporarily unavailable') };
      }
      return { data, error };
    }

    // If single was requested but no data found, return null (not an error)
    if (!data) {
      return { data: null, error: null };
    }

    // Decrypt if needed
    if (ENCRYPTED_TABLES[table]) {
      if (Array.isArray(data)) {
        const skipLargeBlobs = !isSingleRecord && LARGE_BLOB_EXCLUSIONS[table];
        return { data: await decryptRecords(table, data, encryptionKey, !!skipLargeBlobs), error: null };
      } else {
        return { data: await decryptRecord(table, data, encryptionKey), error: null };
      }
    }

    return { data, error };
  } catch (e: any) {
    if (isTransientDbError(e)) {
      return { data: null, error: makeServiceUnavailableError(e?.message || 'Service temporarily unavailable') };
    }
    return { data: null, error: { message: e?.message || String(e) } };
  }
}

async function handleInsert(
  supabase: any,
  table: string,
  data: Record<string, any> | Record<string, any>[],
  params: QueryParams,
  encryptionKey: string,
  returning: boolean = true
): Promise<{ data: any; error: any }> {
  // Encrypt data if needed
  let processedData: Record<string, any> | Record<string, any>[];

  if (ENCRYPTED_TABLES[table]) {
    if (Array.isArray(data)) {
      processedData = await Promise.all(data.map(r => encryptRecord(table, r, encryptionKey)));
    } else {
      processedData = await encryptRecord(table, data, encryptionKey);
    }
  } else {
    processedData = data;
  }

  let query = supabase.from(table).insert(processedData as any);

  if (returning) {
    const selectClause = augmentSelectForEncryptedTable(table, params?.select);
    query = query.select(selectClause);

    const isBulk = Array.isArray(data);
    if (!isBulk) {
      if (params?.single) {
        query = query.single();
      } else if (params?.maybeSingle) {
        query = query.maybeSingle();
      }
    } else if (params?.single || params?.maybeSingle) {
      console.warn(`[Gateway] Ignoring single/maybeSingle for bulk insert into ${table}`);
    }
  }

  const result = await query;

  // Decrypt returned data if needed
  if (result.data && ENCRYPTED_TABLES[table]) {
    if (Array.isArray(result.data)) {
      result.data = await decryptRecords(table, result.data, encryptionKey);
    } else {
      result.data = await decryptRecord(table, result.data, encryptionKey);
    }
  }

  return result;
}

async function handleUpdate(
  supabase: any, 
  table: string, 
  data: Record<string, any>,
  params: QueryParams,
  encryptionKey: string,
  returning: boolean = true
): Promise<{ data: any; error: any }> {
  // Encrypt data if needed
  let processedData = data;
  
  if (ENCRYPTED_TABLES[table]) {
    processedData = await encryptRecord(table, data, encryptionKey);
  }

  let query = supabase.from(table).update(processedData as any);

  // Apply filters
  if (params?.filters) {
    for (const filter of params.filters) {
      switch (filter.operator) {
        case 'eq': query = query.eq(filter.column, filter.value); break;
        case 'neq': query = query.neq(filter.column, filter.value); break;
        case 'is': query = query.is(filter.column, filter.value); break;
        case 'in': query = query.in(filter.column, filter.value); break;
        default: query = query.eq(filter.column, filter.value);
      }
    }
  }

  if (returning) {
    const selectClause = augmentSelectForEncryptedTable(table, params?.select);
    query = query.select(selectClause);

    if (params?.single) {
      query = query.single();
    } else if (params?.maybeSingle) {
      query = query.maybeSingle();
    }
  }

  const result = await query;

  // Decrypt returned data if needed
  if (result.data && ENCRYPTED_TABLES[table]) {
    if (Array.isArray(result.data)) {
      result.data = await decryptRecords(table, result.data, encryptionKey);
    } else {
      result.data = await decryptRecord(table, result.data, encryptionKey);
    }
  }

  return result;
}

async function handleUpsert(
  supabase: any,
  table: string,
  data: Record<string, any> | Record<string, any>[],
  params: QueryParams,
  encryptionKey: string,
  returning: boolean = true
): Promise<{ data: any; error: any }> {
  // Encrypt data if needed
  let processedData: Record<string, any> | Record<string, any>[];

  if (ENCRYPTED_TABLES[table]) {
    if (Array.isArray(data)) {
      processedData = await Promise.all(data.map(r => encryptRecord(table, r, encryptionKey)));
    } else {
      processedData = await encryptRecord(table, data, encryptionKey);
    }
  } else {
    processedData = data;
  }

  const upsertOptions: any = {};
  if (params?.onConflict) {
    upsertOptions.onConflict = params.onConflict;
  }

  let query = supabase.from(table).upsert(processedData as any, upsertOptions);

  if (returning) {
    const selectClause = augmentSelectForEncryptedTable(table, params?.select);
    query = query.select(selectClause);

    const isBulk = Array.isArray(data);
    if (!isBulk) {
      if (params?.single) {
        query = query.single();
      } else if (params?.maybeSingle) {
        query = query.maybeSingle();
      }
    } else if (params?.single || params?.maybeSingle) {
      console.warn(`[Gateway] Ignoring single/maybeSingle for bulk upsert into ${table}`);
    }
  }

  const result = await query;

  // Decrypt returned data if needed
  if (result.data && ENCRYPTED_TABLES[table]) {
    if (Array.isArray(result.data)) {
      result.data = await decryptRecords(table, result.data, encryptionKey);
    } else {
      result.data = await decryptRecord(table, result.data, encryptionKey);
    }
  }

  return result;
}

async function handleDelete(
  supabase: any, 
  table: string, 
  params: QueryParams
): Promise<{ data: any; error: any }> {
  let query = supabase.from(table).delete();

  // Apply filters (required for delete)
  if (params?.filters) {
    for (const filter of params.filters) {
      switch (filter.operator) {
        case 'eq': query = query.eq(filter.column, filter.value); break;
        case 'neq': query = query.neq(filter.column, filter.value); break;
        case 'is': query = query.is(filter.column, filter.value); break;
        case 'in': query = query.in(filter.column, filter.value); break;
        default: query = query.eq(filter.column, filter.value);
      }
    }
  }

  return await query;
}

// ==================== MAIN HANDLER ====================
serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  
  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const ENCRYPTION_KEY = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || "";
    
    if (!ENCRYPTION_KEY) {
      console.warn("[Gateway] WARNING: TRANSCRIPT_ENCRYPTION_KEY is not set - encrypted data will not be decrypted");
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Get session token from header
    const sessionToken = req.headers.get('x-session-token');
    
    // Validate session
    const sessionResult = await validateSession(supabase, sessionToken || '');
    if (!sessionResult.valid) {
      // Check if this is a service unavailability issue vs actual auth failure
      if (sessionResult.error?.startsWith('SERVICE_UNAVAILABLE:')) {
        console.error(`[Gateway] Service unavailable: ${sessionResult.error}`);
        return new Response(JSON.stringify({ 
          error: 'Service Unavailable', 
          message: 'Backend temporarily unavailable. Please try again.',
          code: 'SERVICE_UNAVAILABLE'
        }), {
          status: 503,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      
      console.log(`[Gateway] Auth failed: ${sessionResult.error}`);
      return new Response(JSON.stringify({ 
        error: 'Unauthorized', 
        message: sessionResult.error 
      }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Parse request body
    const body: GatewayRequest = await req.json();
    const { action, data, params } = body;
    const table = (typeof body.table === 'string' ? body.table : '')
      .trim()
      .replace(/^public\./i, '')
      .toLowerCase();

    if (!table) {
      return new Response(JSON.stringify({
        error: 'Bad Request',
        message: 'Table name is required'
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Validate table access
    if (!ALLOWED_TABLES.has(table)) {
      console.log(`[Gateway] Blocked access to table: '${table}'`);
      return new Response(JSON.stringify({ 
        error: 'Forbidden', 
        message: `Access to table '${table}' is not allowed` 
      }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Log operation
    console.log(`[Gateway] ${action.toUpperCase()} ${table} by user ${sessionResult.userId}`);

    // Enforce admin-only mutations for certain config tables
    if (action !== 'select' && ADMIN_ONLY_MUTATION_TABLES.has(table)) {
      const userId = sessionResult.userId as string;
      const admin = await isAdminUser(supabase, userId);
      if (!admin) {
        return new Response(JSON.stringify({
          error: 'Forbidden',
          message: 'You do not have permission to modify this configuration.'
        }), {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // Validate UUID filter values before executing any query
    const uuidError = validateUuidFilters(params?.filters);
    if (uuidError) {
      // For read operations, return empty results instead of 400
      // (a malformed UUID will never match any row)
      if (action === 'select') {
        console.warn(`[UUID-Validation] Malformed UUID in SELECT filter, returning empty: ${uuidError}`);
        return new Response(JSON.stringify({ data: [], count: 0 }), {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      return new Response(JSON.stringify({
        error: 'Bad Request',
        message: uuidError
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    let result: { data: any; error: any };

    switch (action) {
      case 'select':
        result = await handleSelect(supabase, table, params || {}, ENCRYPTION_KEY);
        break;
      case 'insert':
        if (!data) throw new Error('Insert requires data');
        result = await handleInsert(supabase, table, data, params || {}, ENCRYPTION_KEY, body.returning ?? true);
        break;
      case 'update':
        if (!data) throw new Error('Update requires data');
        result = await handleUpdate(supabase, table, data as Record<string, any>, params || {}, ENCRYPTION_KEY, body.returning ?? true);
        break;
      case 'upsert':
        if (!data) throw new Error('Upsert requires data');
        result = await handleUpsert(supabase, table, data, params || {}, ENCRYPTION_KEY, body.returning ?? true);
        break;
      case 'delete':
        result = await handleDelete(supabase, table, params || {});
        break;
      default:
        return new Response(JSON.stringify({
          error: 'Bad Request',
          message: `Unknown action: ${action}`
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
    }

    const duration = Date.now() - startTime;
    console.log(`[Gateway] ${action.toUpperCase()} ${table} completed in ${duration}ms`);

    if (result.error) {
      // Handle duplicate key violations gracefully (e.g., for deduplication indexes)
      if (result.error.code === '23505') {
        console.log(`[Gateway] Duplicate key detected, skipping: ${result.error.message}`);
        return new Response(JSON.stringify({ 
          data: null,
          success: true,
          skipped: true,
          message: 'Record already exists (duplicate)'
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Transient DB/network failures should be 503 (not 500) so the client can retry.
      if (result.error.code === 'SERVICE_UNAVAILABLE' || isTransientDbError(result.error)) {
        console.error(`[Gateway] Service unavailable during ${action.toUpperCase()} ${table}:`, result.error);
        return new Response(JSON.stringify({
          error: 'Service Unavailable',
          message: 'Backend temporarily unavailable. Please try again.',
          code: 'SERVICE_UNAVAILABLE',
        }), {
          status: 503,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      
      console.error(`[Gateway] DB Error:`, result.error);
      return new Response(JSON.stringify({ 
        error: 'Database Error', 
        message: result.error.message,
        code: result.error.code 
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ 
      data: result.data,
      success: true 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[Gateway] Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal Server Error', 
      message: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

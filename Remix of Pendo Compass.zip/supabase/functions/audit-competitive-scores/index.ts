import { createClient } from "npm:@supabase/supabase-js@2";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AuditProposal {
  vendor_name: string;
  subcategory: string;
  category: string;
  current_score: number;
  proposed_score: number;
  proposed_score_term: string;
  rationale: string;
  evidence_sources: string[];
  confidence: string;
}

interface RubricEntry {
  id: string;
  category: string;
  subcategory: string;
  level_1_description: string;
  level_2_description: string;
  level_3_description: string;
  level_4_description: string;
  level_5_description: string;
}

const SCORE_TERMS: Record<number, string> = {
  1: 'Fragmented & Reactive',
  2: 'Consolidating & Proving',
  3: 'Scaling & Systematic',
  4: 'Integrated & Governed',
  5: 'Predictive & Strategic',
};

// ─── Prompt builder ───────────────────────────────────────────────

function buildAuditPrompt(
  vendorName: string,
  sourceUrls: { url: string; description: string; alignment: string }[],
  rubric: RubricEntry[],
  currentScores: { subcategory: string; category: string; score: number }[],
  internalEvidence: { type: string; detail: string }[],
): string {
  // Build the rubric section grouped by category
  const rubricByCategory = rubric.reduce((acc, r) => {
    if (!acc[r.category]) acc[r.category] = [];
    acc[r.category].push(r);
    return acc;
  }, {} as Record<string, RubricEntry[]>);

  const rubricText = Object.entries(rubricByCategory)
    .map(([category, entries]) => {
      const subcatText = entries.map(e => {
        const currentScore = currentScores.find(
          s => s.subcategory === e.subcategory && s.category === e.category
        )?.score ?? 0;
        return `  "${e.subcategory}" (Current: ${currentScore}/5)
    L1: ${e.level_1_description || 'N/A'}
    L2: ${e.level_2_description || 'N/A'}
    L3: ${e.level_3_description || 'N/A'}
    L4: ${e.level_4_description || 'N/A'}
    L5: ${e.level_5_description || 'N/A'}`;
      }).join('\n\n');
      return `### ${category}\n${subcatText}`;
    }).join('\n\n');

  const sourcesText = sourceUrls.length > 0
    ? sourceUrls.map((s, i) => `  ${i + 1}. ${s.url}\n     ${s.description} | Covers: ${s.alignment}`).join('\n')
    : '  No vendor-specific sources. Use your general knowledge and open web.';

  const evidenceText = internalEvidence.length > 0
    ? internalEvidence.map((e, i) => `  ${i + 1}. [${e.type}] ${e.detail}`).join('\n')
    : '  No internal evidence available.';

  return `You are a competitive intelligence analyst evaluating "${vendorName}" against a structured maturity rubric.

## RESEARCH SOURCES
Visit these URLs to gather evidence about "${vendorName}":

${sourcesText}

You may also search the open web to fill gaps, but prioritize the curated sources above. Clearly mark supplementary findings.

## INTERNAL FIELD INTELLIGENCE

${evidenceText}

## SCORING RUBRIC

${rubricText}

## INSTRUCTIONS

1. Research each subcategory using the source URLs and gather specific evidence.
2. Cross-reference evidence against the 5 maturity level descriptions. Score at the HIGHEST level where "${vendorName}" demonstrably meets ALL criteria.
3. Weight evidence: Customer transcripts > Internal Slack intel > Vendor docs > Third-party reviews (G2, Gartner) > Blogs/PR > General knowledge.
4. Score conservatively — under-scoring is preferred over over-scoring based on marketing claims.
5. If insufficient evidence exists, keep current score and mark confidence "low".
6. Rationale must cite specific evidence with URLs or source types.

## OUTPUT FORMAT

Return ONLY a JSON array. Include ONLY subcategories where you propose a score CHANGE (different from the current score). If no scores need changing, return an empty array \`[]\`.

Each entry:
{
  "subcategory": "exact subcategory name",
  "category": "exact category name",
  "proposed_score": 4,
  "proposed_score_term": "Integrated & Governed",
  "rationale": "Specific evidence citing URLs or sources...",
  "evidence_sources": ["https://...", "field_intel"],
  "confidence": "high"
}

Score terms: 1="${SCORE_TERMS[1]}", 2="${SCORE_TERMS[2]}", 3="${SCORE_TERMS[3]}", 4="${SCORE_TERMS[4]}", 5="${SCORE_TERMS[5]}"
Confidence: "high" (multiple sources), "medium" (single source), "low" (insufficient evidence)

Return ONLY the JSON array. No markdown fences, no commentary.`;
}

// ─── Response parser with robust recovery ─────────────────────────

function parseAuditResponse(
  responseText: string,
  vendorName: string,
  currentScores: { subcategory: string; category: string; score: number }[],
): AuditProposal[] {
  let jsonStr = responseText.trim();
  
  // Log raw response length for debugging
  console.log(`Raw response length: ${jsonStr.length} chars`);

  // Strip markdown code fences if present
  const fenceMatch = jsonStr.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenceMatch) {
    jsonStr = fenceMatch[1].trim();
  }

  // Try to find JSON array
  const arrayStart = jsonStr.indexOf('[');
  if (arrayStart === -1) {
    console.error('No JSON array start found in response');
    console.log('Response preview:', jsonStr.substring(0, 500));
    return [];
  }
  
  // Get everything from [ onwards
  jsonStr = jsonStr.substring(arrayStart);

  // Try direct parse first
  try {
    const parsed = JSON.parse(jsonStr);
    if (Array.isArray(parsed)) {
      return mapProposals(parsed, vendorName, currentScores);
    }
  } catch (_directErr) {
    console.log('Direct JSON parse failed, attempting recovery...');
  }

  // Recovery: try to find the last complete object and close the array
  // This handles truncated responses from the model
  let recovered = false;
  let attempts = 0;
  let workingStr = jsonStr;
  
  while (!recovered && attempts < 10) {
    attempts++;
    // Find the last complete "}" in the string
    const lastBrace = workingStr.lastIndexOf('}');
    if (lastBrace === -1) break;
    
    // Try closing the array after the last complete object
    const candidate = workingStr.substring(0, lastBrace + 1) + ']';
    
    // Clean up trailing commas before the closing bracket
    const cleaned = candidate.replace(/,\s*\]$/, ']');
    
    try {
      const parsed = JSON.parse(cleaned);
      if (Array.isArray(parsed) && parsed.length > 0) {
        console.log(`JSON recovery succeeded on attempt ${attempts}: extracted ${parsed.length} entries`);
        recovered = true;
        return mapProposals(parsed, vendorName, currentScores);
      }
    } catch (_) {
      // Trim back further
      workingStr = workingStr.substring(0, lastBrace);
    }
  }

  // Last resort: try to extract individual JSON objects with regex
  console.log('Attempting regex-based object extraction...');
  const objectPattern = /\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}/g;
  const objects: any[] = [];
  let match;
  
  while ((match = objectPattern.exec(jsonStr)) !== null) {
    try {
      const obj = JSON.parse(match[0]);
      if (obj.subcategory && obj.proposed_score != null) {
        objects.push(obj);
      }
    } catch (_) {
      // Skip malformed objects
    }
  }

  if (objects.length > 0) {
    console.log(`Regex extraction recovered ${objects.length} valid proposals`);
    return mapProposals(objects, vendorName, currentScores);
  }

  console.error('All JSON parsing attempts failed');
  console.log('Response first 1000 chars:', jsonStr.substring(0, 1000));
  console.log('Response last 500 chars:', jsonStr.substring(Math.max(0, jsonStr.length - 500)));
  return [];
}

function mapProposals(
  entries: any[],
  vendorName: string,
  currentScores: { subcategory: string; category: string; score: number }[],
): AuditProposal[] {
  // Deduplicate by subcategory+category — keep the first (usually higher quality) entry
  const seen = new Set<string>();
  const deduped = entries.filter((entry: any) => {
    const key = `${entry.category}::${entry.subcategory}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const duplicatesRemoved = entries.length - deduped.length;
  if (duplicatesRemoved > 0) {
    console.log(`Removed ${duplicatesRemoved} duplicate entries`);
  }

  return deduped
    .filter((entry: any) => {
      // Must have required fields
      if (entry.proposed_score == null || !entry.subcategory) return false;
      // Respect explicit "changed: false" from the model
      if (entry.changed === false) return false;
      // Filter out entries where rationale says "current score maintained"
      if (typeof entry.rationale === 'string' && 
          entry.rationale.toLowerCase().includes('current score maintained')) return false;
      return true;
    })
    .map((entry: any) => {
      const current = currentScores.find(
        s => s.subcategory === entry.subcategory && s.category === entry.category
      );
      const proposedScore = Math.min(5, Math.max(1, Math.round(entry.proposed_score)));
      return {
        vendor_name: vendorName,
        subcategory: entry.subcategory,
        category: entry.category,
        current_score: current?.score ?? 0,
        proposed_score: proposedScore,
        proposed_score_term: entry.proposed_score_term || SCORE_TERMS[proposedScore] || '',
        rationale: entry.rationale || '',
        evidence_sources: Array.isArray(entry.evidence_sources) ? entry.evidence_sources : [],
        confidence: entry.confidence || 'medium',
      };
    })
    // Final filter: only keep actual score changes vs database
    .filter((p: AuditProposal) => p.proposed_score !== p.current_score);
}

// ─── Single-vendor audit ──────────────────────────────────────────

async function auditVendor(
  supabase: any,
  vendorName: string,
  aiConfig: { endpoint: string; apiKey: string; model: string },
): Promise<{ proposals: AuditProposal[]; error?: string }> {
  console.log(`Starting audit for vendor: ${vendorName}`);

  // 1. Fetch source URLs for this vendor + "All Vendors" sources
  const { data: sources } = await supabase
    .from('competitive_sources')
    .select('source_url, source_description, subcategory_alignment, source_name')
    .or(`source_name.ilike.%${vendorName}%,source_name.eq.All Vendors,source_name.ilike.%Multiple%`);

  const sourceUrls = (sources || [])
    .filter((s: any) => s.source_url && s.source_url.startsWith('http'))
    .map((s: any) => ({
      url: s.source_url,
      description: s.source_description || s.source_name || '',
      alignment: s.subcategory_alignment || '[All Categories]',
    }));

  console.log(`Found ${sourceUrls.length} source URLs for ${vendorName}`);

  // 2. Fetch full rubric
  const { data: rubric, error: rubricError } = await supabase
    .from('competitive_rubric')
    .select('id, category, subcategory, level_1_description, level_2_description, level_3_description, level_4_description, level_5_description')
    .order('category', { ascending: true })
    .order('subcategory', { ascending: true });

  if (rubricError || !rubric?.length) {
    return { proposals: [], error: `Failed to fetch rubric: ${rubricError?.message}` };
  }

  // 3. Fetch current scores for this vendor
  const { data: scores } = await supabase
    .from('competitive_scorecard')
    .select('subcategory, category, score')
    .eq('vendor_name', vendorName);

  const currentScores = (scores || []).map((s: any) => ({
    subcategory: s.subcategory,
    category: s.category,
    score: s.score ?? 0,
  }));

  // 4. Fetch internal evidence — transcript insights
  const { data: transcriptInsights } = await supabase
    .from('opportunity_competitive_insights')
    .select('feature_discussed, pendo_position, comparison_notes, sentiment, detected_at')
    .eq('competitor_name', vendorName)
    .order('detected_at', { ascending: false })
    .limit(30);

  // 5. Fetch internal evidence — recent approved audits
  const { data: recentAudits } = await supabase
    .from('competitive_audit_log')
    .select('subcategory, rationale, validated_score, evidence_source, source_type')
    .eq('vendor_name', vendorName)
    .eq('status', 'approved')
    .order('audit_datetime', { ascending: false })
    .limit(30);

  // 5b. Fetch Slack intel evidence (high-weight internal signals)
  const { data: slackIntel } = await supabase
    .from('competitive_audit_log')
    .select('subcategory, rationale, evidence_source, evidence_confidence_weight, type')
    .eq('vendor_name', vendorName)
    .eq('source_type', 'slack_intel')
    .order('audit_datetime', { ascending: false })
    .limit(20);

  // Build internal evidence array
  const internalEvidence: { type: string; detail: string }[] = [];

  for (const insight of (transcriptInsights || [])) {
    internalEvidence.push({
      type: 'transcript',
      detail: `Feature: "${insight.feature_discussed}" — Pendo position: ${insight.pendo_position || 'N/A'}, Sentiment: ${insight.sentiment || 'N/A'}, Notes: ${insight.comparison_notes || 'N/A'}`,
    });
  }

  for (const audit of (recentAudits || [])) {
    internalEvidence.push({
      type: audit.source_type || 'previous_audit',
      detail: `Subcategory: "${audit.subcategory}" — Validated score: ${audit.validated_score}, Source: ${audit.evidence_source || 'N/A'}, Rationale: ${audit.rationale || 'N/A'}`,
    });
  }

  for (const slack of (slackIntel || [])) {
    internalEvidence.push({
      type: 'slack_intel',
      detail: `[Slack] ${slack.type || 'general'}: ${slack.rationale || 'N/A'} (Source: ${slack.evidence_source || 'N/A'}, Weight: ${slack.evidence_confidence_weight})`,
    });
  }

  console.log(`Internal evidence: ${internalEvidence.length} items (${transcriptInsights?.length || 0} transcripts, ${recentAudits?.length || 0} audits, ${slackIntel?.length || 0} slack)`);

  // 6. Build the prompt
  const prompt = buildAuditPrompt(vendorName, sourceUrls, rubric, currentScores, internalEvidence);
  console.log(`Prompt built: ~${Math.round(prompt.length / 4)} tokens estimated`);

  // 7. Call AI
  try {
    const response = await fetch(aiConfig.endpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${aiConfig.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: aiConfig.model,
        messages: [
          {
            role: 'system',
            content: 'You are a competitive intelligence analyst. You evaluate software vendors against a structured maturity rubric using provided source URLs and evidence. You MUST return valid JSON arrays only — no commentary, no markdown fences. If no scores need changing, return [].',
          },
          { role: 'user', content: prompt },
        ],
        temperature: 0.2,
        max_tokens: 32000,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error(`AI call failed for ${vendorName}: ${response.status} ${errText}`);
      return { proposals: [], error: `AI call failed: ${response.status}` };
    }

    const result = await response.json();
    const responseText = result.choices?.[0]?.message?.content || '';

    if (!responseText) {
      console.error('Empty AI response');
      return { proposals: [], error: 'Empty AI response' };
    }

    console.log(`AI response received: ${responseText.length} chars, finish_reason: ${result.choices?.[0]?.finish_reason || 'unknown'}`);

    // Warn if response was truncated
    if (result.choices?.[0]?.finish_reason === 'length') {
      console.warn('⚠️ AI response was truncated (hit max_tokens). Some proposals may be lost.');
    }

    // 8. Parse response
    const proposals = parseAuditResponse(responseText, vendorName, currentScores);
    console.log(`Vendor ${vendorName}: ${proposals.length} score change proposals`);

    // 9. Update last_audited_at for this vendor (regardless of proposal count)
    const { error: updateErr } = await supabase
      .from('competitive_scorecard')
      .update({ last_audited_at: new Date().toISOString() })
      .eq('vendor_name', vendorName);

    if (updateErr) {
      console.error(`Failed to update last_audited_at for ${vendorName}:`, updateErr.message);
    }

    return { proposals };
  } catch (err) {
    console.error(`AI audit error for ${vendorName}:`, err);
    return { proposals: [], error: `AI error: ${err.message}` };
  }
}

// ─── Main handler ─────────────────────────────────────────────────

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { vendorName, fullAudit, dryRun, batchSize } = await req.json();

    // Get AI configuration
    const aiConfig = await getAIConfig('standard');
    console.log(`AI provider: ${aiConfig.model}`);

    // Determine which vendors to audit
    let vendorsToAudit: string[] = [];

    if (vendorName) {
      vendorsToAudit = [vendorName];
    } else if (fullAudit) {
      // Get all vendors, prioritizing those not recently audited
      const { data: allVendors } = await supabase
        .from('competitive_scorecard')
        .select('vendor_name')
        .order('vendor_name');

      vendorsToAudit = [...new Set((allVendors || []).map((v: any) => v.vendor_name))];
    } else {
      // Batch mode: pick the next N competitors that haven't been audited recently
      // Source from technology_repository (the canonical list of competitors)
      const limit = Math.max(1, Math.min(batchSize || 7, 15)); // Default 7, cap at 15
      const { data: competitors } = await supabase
        .from('technology_repository')
        .select('name')
        .eq('is_competitor', true)
        .order('name');

      const competitorNames = (competitors || []).map((c: any) => c.name as string);
      
      if (competitorNames.length === 0) {
        console.log('No competitors found in technology_repository');
        vendorsToAudit = [];
      } else {
        // Get the most recent audit date per vendor from scorecard
        const { data: scorecardDates } = await supabase
          .from('competitive_scorecard')
          .select('vendor_name, last_audited_at')
          .in('vendor_name', competitorNames);

        // Build a map of vendor -> most recent last_audited_at
        const vendorAuditDates = new Map<string, string | null>();
        for (const name of competitorNames) {
          vendorAuditDates.set(name, null); // ensure all competitors are included
        }
        for (const row of (scorecardDates || [])) {
          const existing = vendorAuditDates.get(row.vendor_name);
          if (row.last_audited_at && (!existing || row.last_audited_at > existing)) {
            vendorAuditDates.set(row.vendor_name, row.last_audited_at);
          }
        }

        // Sort: never-audited first, then oldest-audited first
        const sorted = [...vendorAuditDates.entries()].sort((a, b) => {
          const aDate = a[1] || '1970-01-01';
          const bDate = b[1] || '1970-01-01';
          return aDate.localeCompare(bDate);
        });

        vendorsToAudit = sorted.slice(0, limit).map(([name]) => name);
        console.log(`Competitor rotation: ${competitorNames.length} total competitors, selecting ${vendorsToAudit.length} least-recently audited`);
      }
    }

    if (vendorsToAudit.length === 0) {
      return new Response(JSON.stringify({ success: true, audited: 0, message: 'No vendors to audit' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Auditing ${vendorsToAudit.length} vendor(s): ${vendorsToAudit.join(', ')}`);

    // Process vendors — for fullAudit, use background task
    if (vendorsToAudit.length > 1) {
      const processAll = async () => {
        let totalProposals = 0;
        for (const vendor of vendorsToAudit) {
          const { proposals, error } = await auditVendor(supabase, vendor, aiConfig);
          if (error) {
            console.error(`Vendor ${vendor} audit error: ${error}`);
            continue;
          }

          if (!dryRun && proposals.length > 0) {
            await insertProposals(supabase, proposals);
          }
          totalProposals += proposals.length;

          // Rate limit: 2-second delay between vendors
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
        console.log(`Batch audit complete: ${vendorsToAudit.length} vendors, ${totalProposals} proposals`);
      };

      EdgeRuntime.waitUntil(processAll());

      return new Response(JSON.stringify({
        success: true,
        message: `Audit started for ${vendorsToAudit.length} vendors (processing in background)`,
        vendors: vendorsToAudit,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Single vendor — process inline
    const vendor = vendorsToAudit[0];
    const { proposals, error } = await auditVendor(supabase, vendor, aiConfig);

    if (error) {
      return new Response(JSON.stringify({ success: false, error, vendor }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Insert proposals unless dry run
    if (!dryRun && proposals.length > 0) {
      await insertProposals(supabase, proposals);
    }

    return new Response(JSON.stringify({
      success: true,
      vendor,
      audited_subcategories: 93,
      proposals_count: proposals.length,
      proposals: dryRun ? proposals : proposals.map(p => ({
        subcategory: p.subcategory,
        category: p.category,
        current_score: p.current_score,
        proposed_score: p.proposed_score,
        confidence: p.confidence,
      })),
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Audit error:', error);
    return new Response(JSON.stringify({ success: false, error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

// ─── Insert proposals into audit log ──────────────────────────────

async function insertProposals(supabase: any, proposals: AuditProposal[]) {
  const rows = proposals.map(p => ({
    vendor_name: p.vendor_name,
    subcategory: p.subcategory,
    current_score: p.current_score,
    file_score: p.proposed_score,
    file_score_term: p.proposed_score_term,
    rationale: p.rationale,
    evidence_source: p.evidence_sources.join(', '),
    evidence_confidence_weight: p.confidence === 'high' ? 1.0 : p.confidence === 'medium' ? 0.7 : 0.4,
    status: 'pending',
    source_type: 'ai_audit',
    type: 'score_change',
  }));

  // Batch insert in chunks of 20
  for (let i = 0; i < rows.length; i += 20) {
    const batch = rows.slice(i, i + 20);
    const { error } = await supabase.from('competitive_audit_log').insert(batch);
    if (error) {
      console.error(`Failed to insert audit batch ${i / 20 + 1}:`, error.message);
    }
  }

  console.log(`Inserted ${rows.length} audit proposals`);
}

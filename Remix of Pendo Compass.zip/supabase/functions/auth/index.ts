import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { encode as encodeBase64, decode as decodeBase64 } from "https://deno.land/std@0.190.0/encoding/base64.ts";
import { encode as encodeBase32, decode as decodeBase32 } from "https://deno.land/std@0.190.0/encoding/base32.ts";

// ─── CORS ────────────────────────────────────────────────────────────────────
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// ─── CONSTANTS ───────────────────────────────────────────────────────────────
const DB_QUERY_TIMEOUT_MS = 10_000;
const SESSION_DURATION_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
const PENDO_EMAIL_DOMAIN = "@pendo.io";
const PASSWORD_MIN_LENGTH = 12;
const PASSWORD_REQUIREMENTS = {
  minLength: PASSWORD_MIN_LENGTH,
  requireUppercase: true,
  requireLowercase: true,
  requireNumber: true,
  requireSpecial: true,
  specialChars: '!@#$%^&*()_+-=[]{}|;:,.<>?',
};

// ─── UTILITY HELPERS ─────────────────────────────────────────────────────────
function withTimeout<T>(promise: Promise<T>, ms: number, errorMessage: string): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error(errorMessage)), ms)),
  ]);
}

function isTransientDbError(err: any): boolean {
  const msg = String(err?.message ?? err ?? '').toLowerCase();
  return msg.includes('schema cache') || msg.includes('connection terminated') ||
    msg.includes('timeout') || msg.includes('timed out') ||
    msg.includes('could not query the database') || msg.includes('service unavailable') ||
    msg.includes('522') || msg.includes('504') || msg.includes('cloudflare') ||
    msg.includes('connection timed out') || msg.includes('database query timed out');
}

function jsonResponse(body: unknown, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function serviceUnavailableResponse(msg?: string) {
  return jsonResponse(
    { success: false, error: msg || "Service temporarily unavailable. Please try again.", code: "SERVICE_UNAVAILABLE" },
    503,
  );
}

// ─── PASSWORD HASHING (PBKDF2 – OWASP 2023: 310 000 iterations) ────────────
async function hashPassword(password: string, iterations = 310_000): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const hash = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, keyMaterial, 256);
  const hashArray = new Uint8Array(hash);
  const combined = new Uint8Array(salt.length + hashArray.length);
  combined.set(salt);
  combined.set(hashArray, salt.length);
  return encodeBase64(combined.buffer.slice(combined.byteOffset, combined.byteOffset + combined.byteLength));
}

async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
  try {
    const combined = decodeBase64(storedHash);
    const salt = combined.slice(0, 16);
    const storedHashBytes = combined.slice(16);
    const keyMaterial = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);

    // Try 310k first (new standard), then fallback to 100k (legacy)
    for (const iterations of [310_000, 100_000]) {
      const hash = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, keyMaterial, 256);
      const hashArray = new Uint8Array(hash);
      if (hashArray.length === storedHashBytes.length) {
        let result = 0;
        for (let i = 0; i < hashArray.length; i++) result |= hashArray[i] ^ storedHashBytes[i];
        if (result === 0) return true;
      }
    }
    return false;
  } catch (error) {
    console.error("Password verification error:", error);
    return false;
  }
}

// ─── PASSWORD VALIDATION ─────────────────────────────────────────────────────
function validatePasswordComplexity(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  if (password.length < PASSWORD_REQUIREMENTS.minLength) errors.push(`Password must be at least ${PASSWORD_REQUIREMENTS.minLength} characters`);
  if (PASSWORD_REQUIREMENTS.requireUppercase && !/[A-Z]/.test(password)) errors.push('Password must contain at least one uppercase letter');
  if (PASSWORD_REQUIREMENTS.requireLowercase && !/[a-z]/.test(password)) errors.push('Password must contain at least one lowercase letter');
  if (PASSWORD_REQUIREMENTS.requireNumber && !/[0-9]/.test(password)) errors.push('Password must contain at least one number');
  if (PASSWORD_REQUIREMENTS.requireSpecial) {
    const specialRegex = new RegExp(`[${PASSWORD_REQUIREMENTS.specialChars.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&')}]`);
    if (!specialRegex.test(password)) errors.push('Password must contain at least one special character');
  }
  const weakPatterns = [/^(.)\1+$/, /password/i, /qwerty/i, /letmein/i];
  for (const pattern of weakPatterns) { if (pattern.test(password)) { errors.push('Password contains a common weak pattern'); break; } }
  return { valid: errors.length === 0, errors };
}

// ─── TOTP (2FA) ──────────────────────────────────────────────────────────────
async function generateTotp(secretBytes: Uint8Array, timeStep: number): Promise<string> {
  const timeBuffer = new ArrayBuffer(8);
  new DataView(timeBuffer).setBigUint64(0, BigInt(timeStep), false);
  const key = await crypto.subtle.importKey("raw", secretBytes.buffer as ArrayBuffer, { name: "HMAC", hash: "SHA-1" }, false, ["sign"]);
  const hmac = new Uint8Array(await crypto.subtle.sign("HMAC", key, timeBuffer));
  const offset = hmac[hmac.length - 1] & 0x0f;
  const binary = ((hmac[offset] & 0x7f) << 24) | ((hmac[offset + 1] & 0xff) << 16) | ((hmac[offset + 2] & 0xff) << 8) | (hmac[offset + 3] & 0xff);
  return (binary % 1_000_000).toString().padStart(6, '0');
}

async function verifyTotp(secret: string, token: string, window = 1): Promise<boolean> {
  try {
    const secretBytes = decodeBase32(secret);
    const now = Math.floor(Date.now() / 1000);
    for (let i = -window; i <= window; i++) {
      if ((await generateTotp(secretBytes, Math.floor(now / 30) + i)) === token.padStart(6, '0')) return true;
    }
    return false;
  } catch { return false; }
}

// ─── TOKEN / SESSION GENERATORS ──────────────────────────────────────────────
function generateSessionToken(): string {
  const a = new Uint8Array(48); crypto.getRandomValues(a);
  return Array.from(a, b => b.toString(16).padStart(2, '0')).join('');
}

function generateToken(): string {
  const a = new Uint8Array(32); crypto.getRandomValues(a);
  return Array.from(a, b => b.toString(16).padStart(2, '0')).join('');
}

function generateTempPassword(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%';
  const a = new Uint8Array(12); crypto.getRandomValues(a);
  return Array.from(a, b => chars[b % chars.length]).join('');
}

async function generateSessionFingerprint(userAgent: string, ipAddress: string): Promise<string> {
  const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`${userAgent}:${ipAddress}`));
  return Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, '0')).join('');
}

// ─── SESSION VALIDATION HELPER ───────────────────────────────────────────────
async function validateSessionFromHeader(supabaseAdmin: any, req: Request) {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new Error("Unauthorized");
  const sessionToken = authHeader.replace("Bearer ", "");
  const { data, error } = await supabaseAdmin.rpc("validate_session", { _token: sessionToken });
  if (error || !data || data.length === 0) throw new Error("Unauthorized - invalid session");
  return { userId: data[0].user_id, email: data[0].email, fullName: data[0].full_name, sessionToken };
}

// ─── ADMIN CHECK HELPER ─────────────────────────────────────────────────────
async function requireAdmin(supabaseAdmin: any, userId: string) {
  const { data: roles } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", userId);
  if (!roles?.some((r: any) => r.role === "admin")) throw new Error("Only admins can perform this action");
}

// ═══════════════════════════════════════════════════════════════════════════════
// ACTION HANDLERS
// ═══════════════════════════════════════════════════════════════════════════════

async function handleLogin(supabaseAdmin: any, body: any, req: Request) {
  const { email, password, totpCode } = body;
  if (!email || !password) throw new Error("Email and password are required");

  const userAgent = req.headers.get("user-agent") || "";
  const forwarded = req.headers.get("x-forwarded-for");
  const ipAddress = forwarded ? forwarded.split(",")[0].trim() : "unknown";

  let userResult: any;
  try {
    userResult = await withTimeout(
      Promise.resolve(supabaseAdmin.from("profiles")
        .select("id, email, full_name, password_hash, email_verified, status, mfa_enabled, temp_password, totp_secret, failed_login_attempts, locked_until")
        .eq("email", email.toLowerCase()).single()),
      DB_QUERY_TIMEOUT_MS, "Database query timed out - please try again",
    );
  } catch (e: any) {
    if (e?.message?.includes('timed out')) return serviceUnavailableResponse();
    throw e;
  }

  const { data: user, error: userError } = userResult;
  if (userError) {
    if (isTransientDbError(userError)) return serviceUnavailableResponse();
    throw new Error("Invalid email or password");
  }
  if (!user) throw new Error("Invalid email or password");

  // Account locked?
  if (user.locked_until) {
    const lockedUntil = new Date(user.locked_until);
    if (lockedUntil > new Date()) {
      const mins = Math.ceil((lockedUntil.getTime() - Date.now()) / 60000);
      throw new Error(`Account is temporarily locked. Please try again in ${mins} minute${mins > 1 ? 's' : ''}.`);
    }
  }

  if (!user.email_verified) throw new Error("Please verify your email before logging in");
  if (!user.password_hash) throw new Error("Account not properly set up. Please contact an administrator.");

  const isValidPassword = await verifyPassword(password, user.password_hash);
  if (!isValidPassword) {
    await supabaseAdmin.from("login_history").insert({ user_id: user.id, ip_address: ipAddress, user_agent: userAgent, success: false, failure_reason: "invalid_password" });
    const { data: lockoutData, error: lockoutError } = await supabaseAdmin.rpc('increment_failed_login', { _user_id: user.id });
    if (lockoutError && isTransientDbError(lockoutError)) return serviceUnavailableResponse();
    const attempts = lockoutData?.[0]?.attempts || (user.failed_login_attempts || 0) + 1;
    const lockoutUntil = lockoutData?.[0]?.lockout_until;
    if (lockoutUntil) {
      const mins = Math.ceil((new Date(lockoutUntil).getTime() - Date.now()) / 60000);
      throw new Error(`Too many failed attempts. Account locked for ${mins} minute${mins > 1 ? 's' : ''}.`);
    }
    const remaining = 5 - attempts;
    if (remaining > 0) throw new Error(`Invalid email or password. ${remaining} attempt${remaining > 1 ? 's' : ''} remaining.`);
    throw new Error("Invalid email or password");
  }

  // MFA check
  if (user.mfa_enabled && !totpCode) {
    return jsonResponse({ success: false, requiresMfa: true, message: "2FA code required" }, 200);
  }
  if (user.mfa_enabled && totpCode && user.totp_secret) {
    if (!(await verifyTotp(user.totp_secret, totpCode))) throw new Error("Invalid 2FA code. Please try again.");
  }

  if (user.status === "suspended") throw new Error("Your account has been suspended. Please contact an administrator.");

  // Reset failed attempts (non-blocking)
  try { await withTimeout(Promise.resolve(supabaseAdmin.rpc('reset_failed_login_attempts', { _user_id: user.id })), DB_QUERY_TIMEOUT_MS, "timeout"); } catch { /* non-critical */ }

  // Create session
  const fingerprintHash = await generateSessionFingerprint(userAgent, ipAddress);
  const sessionToken = generateSessionToken();
  const expiresAt = new Date(Date.now() + SESSION_DURATION_MS);

  try {
    const { error: sessionError } = await withTimeout(
      Promise.resolve(supabaseAdmin.from("user_sessions").insert({ user_id: user.id, token: sessionToken, expires_at: expiresAt.toISOString(), user_agent: userAgent, ip_address: ipAddress, fingerprint_hash: fingerprintHash })),
      DB_QUERY_TIMEOUT_MS, "Session creation timed out",
    );
    if (sessionError) { if (isTransientDbError(sessionError)) return serviceUnavailableResponse(); throw new Error("Failed to create session"); }
  } catch (e: any) { if (e?.message?.includes('timed out')) return serviceUnavailableResponse(); throw e; }

  // Fetch roles
  let roles: any[] = [];
  try { const r = await withTimeout(Promise.resolve(supabaseAdmin.from("user_roles").select("role").eq("user_id", user.id)), DB_QUERY_TIMEOUT_MS, "timeout"); roles = r.data || []; } catch { /* non-critical */ }

  // Background tasks (fire-and-forget)
  (async () => {
    try { await supabaseAdmin.from("profiles").update({ last_login_at: new Date().toISOString() }).eq("id", user.id); } catch {}
    try { await supabaseAdmin.from("login_history").insert({ user_id: user.id, login_at: new Date().toISOString(), ip_address: ipAddress, user_agent: userAgent, success: true }); } catch {}
    try { await supabaseAdmin.rpc("cleanup_expired_sessions"); } catch {}
  })().catch(() => {});

  return jsonResponse({
    success: true,
    session: { token: sessionToken, expiresAt: expiresAt.toISOString() },
    user: { id: user.id, email: user.email, fullName: user.full_name, status: user.status, mfaEnabled: user.mfa_enabled, tempPassword: user.temp_password, roles: roles?.map((r: any) => r.role) || [] },
  }, 200);
}

async function handleLogout(supabaseAdmin: any, _body: any, req: Request) {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) return jsonResponse({ success: true, message: "Logged out" }, 200);
  const sessionToken = authHeader.replace("Bearer ", "");
  await supabaseAdmin.from("user_sessions").delete().eq("token", sessionToken);
  return jsonResponse({ success: true, message: "Logged out successfully" }, 200);
}

async function handleValidateSession(supabaseAdmin: any, _body: any, req: Request) {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new Error("No session token provided");
  const sessionToken = authHeader.replace("Bearer ", "");

  let sessionData: any;
  let sessionError: any;
  try {
    const result = await withTimeout(
      Promise.resolve(supabaseAdmin.rpc("validate_session", { _token: sessionToken })),
      DB_QUERY_TIMEOUT_MS, "Session validation timed out",
    );
    sessionData = result.data;
    sessionError = result.error;
  } catch (e: any) {
    if (e?.message?.includes('timed out') || isTransientDbError(e)) return serviceUnavailableResponse();
    throw e;
  }
  if (sessionError) {
    if (isTransientDbError(sessionError)) return serviceUnavailableResponse();
    // Expected outcome for expired/invalid tokens — return 200 so clients don't treat it as a hard error
    return jsonResponse({ success: false, error: "Invalid or expired session" }, 200);
  }
  if (!sessionData || sessionData.length === 0) {
    return jsonResponse({ success: false, error: "Invalid or expired session" }, 200);
  }
  const session = sessionData[0];

  // Fingerprint check
  const userAgent = req.headers.get("user-agent") || "";
  const forwarded = req.headers.get("x-forwarded-for");
  const ipAddress = forwarded ? forwarded.split(",")[0].trim() : "unknown";
  const { data: sessionDetails } = await supabaseAdmin.from("user_sessions").select("fingerprint_hash").eq("token", sessionToken).single();
  if (sessionDetails?.fingerprint_hash) {
    const currentFp = await generateSessionFingerprint(userAgent, ipAddress);
    if (sessionDetails.fingerprint_hash !== currentFp) {
      console.warn("Session fingerprint mismatch", { userId: session.user_id, ipAddress });
    }
  }

  const { data: roles } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", session.user_id);

  // auth_provider is now returned directly from validate_session RPC
  const authProvider = session.auth_provider || 'email';

  return jsonResponse({
    success: true,
    user: { id: session.user_id, email: session.email, fullName: session.full_name, status: session.status, mfaEnabled: session.mfa_enabled, authProvider, roles: roles?.map((r: any) => r.role) || [] },
  }, 200);
}

async function handleRegister(supabaseAdmin: any, body: any) {
  const { email, password, fullName } = body;
  if (!email || !password) throw new Error("Email and password are required");
  if (!email.toLowerCase().endsWith(PENDO_EMAIL_DOMAIN)) throw new Error("Registration is restricted to @pendo.io email addresses only");

  const pv = validatePasswordComplexity(password);
  if (!pv.valid) throw new Error(pv.errors.join('. '));

  const { data: existing } = await supabaseAdmin.from("profiles").select("id").eq("email", email.toLowerCase()).single();
  if (existing) throw new Error("An account with this email already exists");

  const passwordHash = await hashPassword(password);
  const verificationToken = generateToken();
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
  const userId = crypto.randomUUID();

  const { error: insertError } = await supabaseAdmin.from("profiles").insert({
    id: userId, email: email.toLowerCase(), full_name: fullName || email.split("@")[0],
    password_hash: passwordHash, email_verification_token: verificationToken,
    email_verification_expires_at: expiresAt.toISOString(), email_verified: false,
    status: "pending", temp_password: false, failed_login_attempts: 0,
  });
  if (insertError) { console.error("Register insert error:", insertError); throw new Error("Failed to create account"); }

  // Send verification email
  const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
  const verifyUrl = `https://sependo.org/auth?action=verify&token=${verificationToken}`;
  await resend.emails.send({
    from: "Pendo TechMap <noreply@sependo.org>", to: [email],
    subject: "Verify your Pendo TechMap account",
    html: `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:600px;margin:0 auto;padding:20px"><h1 style="color:#ec407a;margin-bottom:24px">Welcome to Pendo TechMap!</h1><p style="color:#333;font-size:16px;line-height:1.6">Hi ${fullName || email.split("@")[0]},</p><p style="color:#333;font-size:16px;line-height:1.6">Please verify your email address by clicking the button below:</p><div style="text-align:center;margin:32px 0"><a href="${verifyUrl}" style="background-color:#ec407a;color:white;padding:14px 28px;text-decoration:none;border-radius:8px;font-weight:600;display:inline-block">Verify Email Address</a></div><p style="color:#666;font-size:14px">This link will expire in 24 hours.</p></div>`,
  });

  return jsonResponse({ success: true, message: "Account created! Please check your email to verify your account." }, 200);
}

async function handleVerifyEmail(supabaseAdmin: any, body: any) {
  const { token } = body;
  if (!token) throw new Error("Verification token is required");

  const { data: user, error: userError } = await supabaseAdmin.from("profiles").select("id, email, email_verification_expires_at").eq("email_verification_token", token).single();
  if (userError || !user) throw new Error("Invalid or expired verification link");
  if (new Date(user.email_verification_expires_at) < new Date()) throw new Error("Verification link has expired. Please request a new one.");

  const { error: updateError } = await supabaseAdmin.from("profiles").update({ email_verified: true, email_verification_token: null, email_verification_expires_at: null }).eq("id", user.id);
  if (updateError) throw new Error("Failed to verify email");

  console.log(`Email verified for user: ${user.email}`);
  return jsonResponse({ success: true, message: "Email verified successfully! You can now set up 2FA and log in." }, 200);
}

async function handleForgotPassword(supabaseAdmin: any, body: any) {
  const { email } = body;
  if (!email) throw new Error("Email is required");
  const safeMsg = "If an account exists with this email, you will receive a password reset link.";

  // Retry DB lookup up to 3 times to handle transient timeouts
  let user = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const { data, error } = await withTimeout(
        supabaseAdmin.from("profiles").select("id, email, full_name").eq("email", email.toLowerCase()).single(),
        DB_QUERY_TIMEOUT_MS,
        "Database query timed out"
      );
      if (error && !isTransientDbError(error)) break;
      if (data) { user = data; break; }
      if (!error) break; // no error, no data = user not found
    } catch (err) {
      console.error(`[Auth] forgot-password DB attempt ${attempt + 1} failed:`, err);
      if (!isTransientDbError(err) || attempt === 2) break;
      await new Promise(r => setTimeout(r, 500 * (attempt + 1)));
    }
  }
  if (!user) return jsonResponse({ success: true, message: safeMsg }, 200);

  const resetToken = generateToken();
  const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

  // Retry token update with timeout
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      await withTimeout(
        supabaseAdmin.from("profiles").update({ password_reset_token: resetToken, password_reset_expires_at: expiresAt.toISOString() }).eq("id", user.id),
        DB_QUERY_TIMEOUT_MS,
        "Database update timed out"
      );
      break;
    } catch (err) {
      console.error(`[Auth] forgot-password update attempt ${attempt + 1} failed:`, err);
      if (!isTransientDbError(err) || attempt === 2) throw err;
      await new Promise(r => setTimeout(r, 500 * (attempt + 1)));
    }
  }

  const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
  const resetUrl = `https://sependo.org/auth?action=reset&token=${resetToken}`;
  await resend.emails.send({
    from: "Pendo Compass <noreply@sependo.org>", to: [user.email],
    subject: "Reset your Pendo Compass password",
    html: `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:600px;margin:0 auto;padding:20px"><h1 style="color:#ec407a;margin-bottom:24px">Password Reset Request</h1><p style="color:#333;font-size:16px;line-height:1.6">Hi ${user.full_name || user.email.split("@")[0]},</p><p style="color:#333;font-size:16px;line-height:1.6">Click the button below to set a new password:</p><div style="text-align:center;margin:32px 0"><a href="${resetUrl}" style="background-color:#ec407a;color:white;padding:14px 28px;text-decoration:none;border-radius:8px;font-weight:600;display:inline-block">Reset Password</a></div><p style="color:#666;font-size:14px">This link will expire in 1 hour.</p></div>`,
  });

  return jsonResponse({ success: true, message: safeMsg }, 200);
}

async function handleResetPassword(supabaseAdmin: any, body: any) {
  const { token, newPassword } = body;
  if (!token || !newPassword) throw new Error("Token and new password are required");
  if (newPassword.length < 8) throw new Error("Password must be at least 8 characters");

  const { data: user, error } = await supabaseAdmin.from("profiles").select("id, email, password_reset_expires_at").eq("password_reset_token", token).single();
  if (error || !user) throw new Error("Invalid or expired reset link");
  if (new Date(user.password_reset_expires_at) < new Date()) throw new Error("Reset link has expired. Please request a new one.");

  const passwordHash = await hashPassword(newPassword);
  await supabaseAdmin.from("profiles").update({ password_hash: passwordHash, password_reset_token: null, password_reset_expires_at: null, temp_password: false }).eq("id", user.id);
  await supabaseAdmin.from("user_sessions").delete().eq("user_id", user.id);

  return jsonResponse({ success: true, message: "Password updated successfully! You can now log in with your new password." }, 200);
}

async function handleChangePassword(supabaseAdmin: any, body: any, req: Request) {
  const { userId } = await validateSessionFromHeader(supabaseAdmin, req);
  const { currentPassword, newPassword, skipCurrentCheck } = body;
  if (!newPassword) throw new Error("New password is required");
  if (newPassword.length < 8) throw new Error("Password must be at least 8 characters");

  const { data: user, error } = await supabaseAdmin.from("profiles").select("id, password_hash, temp_password").eq("id", userId).single();
  if (error || !user) throw new Error("User not found");

  if (!user.temp_password && !skipCurrentCheck) {
    if (!currentPassword) throw new Error("Current password is required");
    if (!(await verifyPassword(currentPassword, user.password_hash))) throw new Error("Current password is incorrect");
  }

  const passwordHash = await hashPassword(newPassword);
  await supabaseAdmin.from("profiles").update({ password_hash: passwordHash, temp_password: false }).eq("id", userId);
  return jsonResponse({ success: true, message: "Password updated successfully" }, 200);
}

async function handleInviteUser(supabaseAdmin: any, body: any, req: Request) {
  const { userId: adminUserId } = await validateSessionFromHeader(supabaseAdmin, req);
  await requireAdmin(supabaseAdmin, adminUserId);

  const { email, name } = body;
  if (!email) throw new Error("Email is required");
  if (!email.toLowerCase().endsWith(PENDO_EMAIL_DOMAIN)) throw new Error("Can only invite @pendo.io email addresses");

  const { data: existing } = await supabaseAdmin.from("profiles").select("id, status").eq("email", email.toLowerCase()).single();
  
  // If user exists and is already active/pending with a password, skip
  if (existing && existing.status !== 'identified') {
    return jsonResponse({ success: false, existing: true, message: "User already exists" }, 200);
  }

  // If user exists as 'identified' (captured from meetings), upgrade them to invited
  const isUpgrade = !!existing;
  const userId = isUpgrade ? existing.id : crypto.randomUUID();

  const tempPassword = generateTempPassword();
  const passwordHash = await hashPassword(tempPassword, 100_000); // legacy iterations for invited users

  if (isUpgrade) {
    // Upgrade identified user to active with credentials
    const { error: updateError } = await supabaseAdmin.from("profiles").update({
      full_name: name || existing.id ? undefined : email.split("@")[0],
      password_hash: passwordHash, email_verified: true, status: "active",
      temp_password: true, invited_by: adminUserId, invited_at: new Date().toISOString(),
    }).eq("id", userId);
    if (updateError) { console.error("Invite upgrade error:", updateError); throw new Error("Failed to upgrade user"); }
  } else {
    const { error: insertError } = await supabaseAdmin.from("profiles").insert({
      id: userId, email: email.toLowerCase(), full_name: name || email.split("@")[0],
      password_hash: passwordHash, email_verified: true, status: "active",
      temp_password: true, invited_by: adminUserId, invited_at: new Date().toISOString(),
    });
    if (insertError) { console.error("Invite insert error:", insertError); throw new Error("Failed to create user"); }
  }

  const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
  const loginUrl = "https://sependo.org/auth";
  await resend.emails.send({
    from: "Pendo Compass <noreply@sependo.org>", to: [email],
    subject: "You've been invited to Pendo Compass",
    html: `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:600px;margin:0 auto;padding:20px"><h1 style="color:#ec407a;margin-bottom:24px">Welcome to Pendo Compass!</h1><p style="color:#333;font-size:16px;line-height:1.6">Hi ${name || email.split("@")[0]},</p><p style="color:#333;font-size:16px;line-height:1.6">You've been invited to join Pendo Compass. Here are your login credentials:</p><div style="background:#f8f9fa;padding:20px;border-radius:8px;margin:24px 0"><p style="margin:0 0 8px 0;color:#666;font-size:14px">Email:</p><p style="margin:0 0 16px 0;color:#333;font-size:16px;font-weight:600">${email}</p><p style="margin:0 0 8px 0;color:#666;font-size:14px">Temporary Password:</p><p style="margin:0;color:#333;font-size:18px;font-family:monospace;background:#fff;padding:8px 12px;border-radius:4px;border:1px solid #ddd">${tempPassword}</p></div><div style="text-align:center;margin:32px 0"><a href="${loginUrl}" style="background-color:#ec407a;color:white;padding:14px 28px;text-decoration:none;border-radius:8px;font-weight:600;display:inline-block">Log In Now</a></div><p style="color:#e53935;font-size:14px;font-weight:600">⚠️ You will be required to change your password and set up 2FA on first login.</p></div>`,
  });

  return jsonResponse({ success: true, message: `Invitation sent to ${email}` }, 200);
}

async function handleSetup2FA(supabaseAdmin: any, _body: any, req: Request) {
  const { userId, email } = await validateSessionFromHeader(supabaseAdmin, req);

  const { data: user, error } = await supabaseAdmin.from("profiles").select("mfa_enabled, totp_secret").eq("id", userId).single();
  if (error || !user) throw new Error("User not found");
  if (user.mfa_enabled && user.totp_secret) throw new Error("2FA is already enabled for this account");

  let secret: string;
  if (user.totp_secret) {
    secret = user.totp_secret;
  } else {
    secret = encodeBase32(crypto.getRandomValues(new Uint8Array(20)));
    const { error: updateError } = await supabaseAdmin.from("profiles").update({ totp_secret: secret }).eq("id", userId);
    if (updateError) throw new Error("Failed to set up 2FA");
  }

  const issuer = encodeURIComponent("Pendo Compass");
  const encodedEmail = encodeURIComponent(email);
  const otpAuthUri = `otpauth://totp/${issuer}:${encodedEmail}?secret=${secret}&issuer=${issuer}&algorithm=SHA1&digits=6&period=30`;

  return jsonResponse({ success: true, secret, otpAuthUri, message: "Scan the QR code with your authenticator app, then verify with a code" }, 200);
}

async function handleVerify2FA(supabaseAdmin: any, body: any, req: Request) {
  const { userId } = await validateSessionFromHeader(supabaseAdmin, req);
  const { code } = body;
  if (!code || code.length !== 6) throw new Error("Please enter a valid 6-digit code");

  const { data: user, error } = await supabaseAdmin.from("profiles").select("email, totp_secret, mfa_enabled").eq("id", userId).single();
  if (error || !user) throw new Error("User not found");
  if (!user.totp_secret) throw new Error("2FA setup not initiated. Please start the setup process first.");
  if (!(await verifyTotp(user.totp_secret, code))) throw new Error("Invalid verification code. Please try again.");

  await supabaseAdmin.from("profiles").update({ mfa_enabled: true, totp_verified_at: new Date().toISOString() }).eq("id", userId);
  console.log(`2FA enabled for user: ${user.email}`);
  return jsonResponse({ success: true, message: "2FA has been enabled successfully!" }, 200);
}

async function handleAdminResetPassword(supabaseAdmin: any, body: any, req: Request) {
  const { userId: adminUserId } = await validateSessionFromHeader(supabaseAdmin, req);
  await requireAdmin(supabaseAdmin, adminUserId);

  const { userId } = body;
  if (!userId) throw new Error("User ID is required");

  const { data: targetUser, error } = await supabaseAdmin.from("profiles").select("id, email, full_name").eq("id", userId).single();
  if (error || !targetUser) throw new Error("User not found");

  const tempPassword = generateTempPassword();
  const passwordHash = await hashPassword(tempPassword, 100_000);
  await supabaseAdmin.from("profiles").update({ password_hash: passwordHash, temp_password: true }).eq("id", userId);
  await supabaseAdmin.from("user_sessions").delete().eq("user_id", userId);

  const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
  const loginUrl = "https://sependo.org/auth";
  await resend.emails.send({
    from: "Pendo TechMap <noreply@sependo.org>", to: [targetUser.email],
    subject: "Your Pendo TechMap password has been reset",
    html: `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:600px;margin:0 auto;padding:20px"><h1 style="color:#ec407a;margin-bottom:24px">Password Reset</h1><p style="color:#333;font-size:16px;line-height:1.6">Hi ${targetUser.full_name || targetUser.email.split("@")[0]},</p><p style="color:#333;font-size:16px;line-height:1.6">An administrator has reset your password. Here is your new temporary password:</p><div style="background:#f8f9fa;padding:20px;border-radius:8px;margin:24px 0"><p style="margin:0 0 8px 0;color:#666;font-size:14px">Temporary Password:</p><p style="margin:0;color:#333;font-size:18px;font-family:monospace;background:#fff;padding:8px 12px;border-radius:4px;border:1px solid #ddd">${tempPassword}</p></div><div style="text-align:center;margin:32px 0"><a href="${loginUrl}" style="background-color:#ec407a;color:white;padding:14px 28px;text-decoration:none;border-radius:8px;font-weight:600;display:inline-block">Log In Now</a></div><p style="color:#e53935;font-size:14px;font-weight:600">⚠️ You will be required to change your password on your next login.</p></div>`,
  });

  return jsonResponse({ success: true, message: `Password reset for ${targetUser.email}. They will receive an email with their new temporary password.` }, 200);
}

// ─── GOOGLE SSO LOGIN ────────────────────────────────────────────────────────
async function handleGoogleLogin(supabaseAdmin: any, body: any, req: Request) {
  const { email, fullName, googleId } = body;
  if (!email) throw new Error("Email is required for Google login");

  const normalizedEmail = email.toLowerCase().trim();

  // Restrict Google SSO to @pendo.io domain
  if (!normalizedEmail.endsWith(PENDO_EMAIL_DOMAIN)) {
    throw new Error("Google SSO is restricted to @pendo.io accounts only");
  }

  const userAgent = req.headers.get("user-agent") || "";
  const forwarded = req.headers.get("x-forwarded-for");
  const ipAddress = forwarded ? forwarded.split(",")[0].trim() : "unknown";

  // Check if profile exists
  let { data: user } = await supabaseAdmin.from("profiles")
    .select("id, email, full_name, status, mfa_enabled, google_linked, auth_provider")
    .eq("email", normalizedEmail)
    .single();

  if (user) {
    // Existing user - check if suspended
    if (user.status === "suspended") throw new Error("Your account has been suspended. Please contact an administrator.");

    // Build profile updates
    const profileUpdates: Record<string, any> = {};

    // Link Google if not already linked
    if (!user.google_linked) {
      profileUpdates.google_linked = true;
      profileUpdates.google_email = normalizedEmail;
    }

    // Always ensure auth_provider is 'google' when logging in via Google SSO
    if (user.auth_provider !== 'google') {
      profileUpdates.auth_provider = 'google';
    }

    // Auto-activate identified/pending profiles on Google SSO login
    if (user.status === 'identified' || user.status === 'pending') {
      profileUpdates.status = 'active';
      profileUpdates.email_verified = true;
      user.status = 'active';
      if (fullName && !user.full_name) profileUpdates.full_name = fullName;

      // Ensure user has a role
      const { data: existingRoles } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", user.id);
      if (!existingRoles || existingRoles.length === 0) {
        await supabaseAdmin.from("user_roles").insert({ user_id: user.id, role: "ae" });
      }
    }

    if (Object.keys(profileUpdates).length > 0) {
      await supabaseAdmin.from("profiles").update(profileUpdates).eq("id", user.id);
    }
  } else {
    // New user via Google SSO - auto-create with active status
    const userId = crypto.randomUUID();
    const { error: insertError } = await supabaseAdmin.from("profiles").insert({
      id: userId,
      email: normalizedEmail,
      full_name: fullName || normalizedEmail.split("@")[0],
      email_verified: true,
      status: "active",
      auth_provider: "google",
      google_linked: true,
      google_email: normalizedEmail,
      mfa_enabled: false,
      temp_password: false,
      failed_login_attempts: 0,
    });
    if (insertError) {
      console.error("Google SSO profile creation error:", insertError);
      throw new Error("Failed to create account");
    }

    // Assign default 'ae' role
    await supabaseAdmin.from("user_roles").insert({ user_id: userId, role: "ae" });

    user = { id: userId, email: normalizedEmail, full_name: fullName, status: "active", mfa_enabled: false, google_linked: true, auth_provider: "google" };
  }

  // Create session (skip 2FA for Google SSO)
  const fingerprintHash = await generateSessionFingerprint(userAgent, ipAddress);
  const sessionToken = generateSessionToken();
  const expiresAt = new Date(Date.now() + SESSION_DURATION_MS);

  const { error: sessionError } = await supabaseAdmin.from("user_sessions").insert({
    user_id: user.id, token: sessionToken, expires_at: expiresAt.toISOString(),
    user_agent: userAgent, ip_address: ipAddress, fingerprint_hash: fingerprintHash,
  });
  if (sessionError) throw new Error("Failed to create session");

  // Fetch roles
  const { data: roles } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", user.id);

  // Background tasks
  (async () => {
    try { await supabaseAdmin.from("profiles").update({ last_login_at: new Date().toISOString() }).eq("id", user.id); } catch {}
    try { await supabaseAdmin.from("login_history").insert({ user_id: user.id, login_at: new Date().toISOString(), ip_address: ipAddress, user_agent: userAgent, success: true, login_method: "google_sso" }); } catch {}
  })().catch(() => {});

  return jsonResponse({
    success: true,
    session: { token: sessionToken, expiresAt: expiresAt.toISOString() },
    user: {
      id: user.id, email: user.email, fullName: user.full_name,
      status: user.status, mfaEnabled: false, tempPassword: false,
      authProvider: 'google',
      roles: roles?.map((r: any) => r.role) || [],
    },
  }, 200);
}

// ─── GOOGLE LINK/UNLINK ──────────────────────────────────────────────────────
async function handleToggleGoogleLink(supabaseAdmin: any, body: any, req: Request) {
  const { userId } = await validateSessionFromHeader(supabaseAdmin, req);
  const { linked, googleEmail } = body;

  const update: any = { google_linked: !!linked };
  if (linked && googleEmail) {
    update.google_email = googleEmail.toLowerCase();
  } else if (!linked) {
    update.google_email = null;
    // If they unlink Google but have no password, they need to set one
    const { data: profile } = await supabaseAdmin.from("profiles").select("password_hash, auth_provider").eq("id", userId).single();
    if (!profile?.password_hash) {
      throw new Error("You must set a password before unlinking Google SSO. Use 'Change Password' first.");
    }
    update.auth_provider = 'email';
  }

  await supabaseAdmin.from("profiles").update(update).eq("id", userId);
  return jsonResponse({ success: true, message: linked ? "Google account linked" : "Google account unlinked" }, 200);
}

// ─── ROUTE DISPATCH ──────────────────────────────────────────────────────────
const ACTIONS: Record<string, (admin: any, body: any, req: Request) => Promise<Response>> = {
  'login': handleLogin,
  'logout': handleLogout,
  'validate-session': handleValidateSession,
  'register': handleRegister,
  'verify-email': handleVerifyEmail,
  'forgot-password': handleForgotPassword,
  'reset-password': handleResetPassword,
  'change-password': handleChangePassword,
  'invite-user': handleInviteUser,
  'setup-2fa': handleSetup2FA,
  'verify-2fa': handleVerify2FA,
  'admin-reset-password': handleAdminResetPassword,
  'google-login': handleGoogleLogin,
  'toggle-google-link': handleToggleGoogleLink,
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } },
    );

    const body = await req.json().catch(() => ({}));
    const action = body?.action;
    if (!action || !ACTIONS[action]) {
      return jsonResponse({ success: false, error: `Unknown auth action: ${action}` }, 400);
    }

    console.log(`[Auth] ${action} request`);
    return await ACTIONS[action](supabaseAdmin, body, req);
  } catch (error: any) {
    const isUnauth = error?.message?.includes("Unauthorized");
    const status = isTransientDbError(error) ? 503 : isUnauth ? 401 : 400;
    if (status === 503) return serviceUnavailableResponse();
    console.error(`[Auth] Error:`, error);
    return jsonResponse({ success: false, error: error.message }, status);
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Encryption helpers
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const data = encoder.encode(keyInput);
  const bytes = new Uint8Array(32);
  for (let i = 0; i < Math.min(data.length, 32); i++) {
    bytes[i] = data[i];
  }
  return bytes;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

async function encryptWithIv(plaintext: string, ivBytes: Uint8Array, encryptionKey: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plaintext);
  const keyBytes = deriveKeyBytes(encryptionKey);
  const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['encrypt']);
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: ivBytes.buffer as ArrayBuffer }, key, data);
  return bytesToBase64(new Uint8Array(encrypted));
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');
    
    if (!encryptionKey) {
      return new Response(JSON.stringify({ error: 'TRANSCRIPT_ENCRYPTION_KEY not configured' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const body = await req.json().catch(() => ({}));
    const dryRun = body.dryRun !== false; // Default to dry run
    const batchSize = body.batchSize || 50;

    const supabase = createClient(supabaseUrl, serviceRoleKey);

    console.log(`[Backfill] Starting document encryption backfill (dryRun: ${dryRun})`);

    // Find all unencrypted documents
    const { data: unencryptedDocs, error } = await supabase
      .from('account_documents')
      .select('id, name, content')
      .eq('type', 'transcript')
      .or('is_encrypted.is.null,is_encrypted.eq.false')
      .not('content', 'is', null)
      .limit(batchSize);

    if (error) {
      throw new Error(`Failed to fetch documents: ${error.message}`);
    }

    console.log(`[Backfill] Found ${unencryptedDocs?.length || 0} unencrypted documents`);

    let encrypted = 0;
    let failed = 0;

    for (const doc of unencryptedDocs || []) {
      try {
        const ivBytes = crypto.getRandomValues(new Uint8Array(12));
        const ivBase64 = bytesToBase64(ivBytes);

        const updateData: Record<string, any> = {
          encryption_iv: ivBase64,
          is_encrypted: true,
        };

        // Encrypt content
        if (doc.content) {
          updateData.content_encrypted = await encryptWithIv(doc.content, ivBytes, encryptionKey);
          updateData.content = null;
        }

        // Encrypt name (but keep placeholder for NOT NULL constraint)
        if (doc.name) {
          updateData.name_encrypted = await encryptWithIv(doc.name, ivBytes, encryptionKey);
          updateData.name = '[Encrypted]';
        }

        if (!dryRun) {
          const { error: updateError } = await supabase
            .from('account_documents')
            .update(updateData)
            .eq('id', doc.id);

          if (updateError) {
            console.error(`[Backfill] Failed to update ${doc.id}: ${updateError.message}`);
            failed++;
            continue;
          }
        }

        encrypted++;
        console.log(`[Backfill] ${dryRun ? 'Would encrypt' : 'Encrypted'} document ${doc.id}`);
      } catch (err) {
        console.error(`[Backfill] Error processing ${doc.id}:`, err);
        failed++;
      }
    }

    // Get remaining count
    const { count: remaining } = await supabase
      .from('account_documents')
      .select('id', { count: 'exact', head: true })
      .eq('type', 'transcript')
      .or('is_encrypted.is.null,is_encrypted.eq.false')
      .not('content', 'is', null);

    return new Response(JSON.stringify({
      success: true,
      dryRun,
      processed: encrypted,
      failed,
      remaining: (remaining || 0) - (dryRun ? 0 : encrypted),
      message: dryRun 
        ? `Would encrypt ${encrypted} documents. Run with dryRun: false to apply.`
        : `Encrypted ${encrypted} documents. ${remaining ? remaining - encrypted : 0} remaining.`,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[Backfill] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

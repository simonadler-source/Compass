import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Convert key to proper format - supports hex string or raw string
function deriveKeyBytes(keyInput: string): Uint8Array {
  // If it looks like a hex string (all hex chars, even length >= 64), parse as hex
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  
  // Otherwise, hash the input to get a consistent 256-bit key
  const encoder = new TextEncoder();
  const data = encoder.encode(keyInput);
  // Use first 32 bytes, pad with zeros if needed
  const bytes = new Uint8Array(32);
  for (let i = 0; i < Math.min(data.length, 32); i++) {
    bytes[i] = data[i];
  }
  return bytes;
}

// AES-256-GCM encryption using Web Crypto API
async function encrypt(plaintext: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plaintext);
  
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey(
    'raw',
    keyBytes.buffer as ArrayBuffer,
    { name: 'AES-GCM' },
    false,
    ['encrypt']
  );
  
  const iv = crypto.getRandomValues(new Uint8Array(12));
  
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv.buffer as ArrayBuffer },
    key,
    data
  );
  
  return {
    ciphertext: bytesToBase64(new Uint8Array(encrypted)),
    iv: bytesToBase64(iv),
  };
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');

    if (!encryptionKey) {
      throw new Error('TRANSCRIPT_ENCRYPTION_KEY not configured');
    }

    console.log(`[backfill-encryption] Key length: ${encryptionKey.length} chars`);

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    const { batchSize = 10, table = 'transcript_reviews' } = await req.json();
    
    console.log(`[backfill-encryption] Starting backfill for ${table}, batch size: ${batchSize}`);
    
    // Fetch unencrypted records
    const { data: records, error: fetchError } = await supabase
      .from(table)
      .select('id, transcript_content')
      .eq('is_encrypted', false)
      .not('transcript_content', 'is', null)
      .limit(batchSize);
    
    if (fetchError) throw fetchError;
    
    if (!records || records.length === 0) {
      console.log(`[backfill-encryption] No unencrypted records found in ${table}`);
      return new Response(JSON.stringify({ 
        success: true,
        processed: 0,
        message: `No unencrypted records found in ${table}`,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    
    console.log(`[backfill-encryption] Found ${records.length} records to encrypt in ${table}`);
    
    let processed = 0;
    let failed = 0;
    const errors: string[] = [];
    
    for (const record of records) {
      try {
        if (!record.transcript_content) continue;
        
        console.log(`[backfill-encryption] Encrypting ${record.id}, content length: ${record.transcript_content.length}`);
        
        const { ciphertext, iv } = await encrypt(record.transcript_content, encryptionKey);
        
        console.log(`[backfill-encryption] Encrypted ${record.id}, ciphertext length: ${ciphertext.length}`);
        
        const { error: updateError } = await supabase
          .from(table)
          .update({
            transcript_content_encrypted: ciphertext,
            encryption_iv: iv,
            is_encrypted: true,
            transcript_content: null, // Clear plaintext after encryption
          })
          .eq('id', record.id);
        
        if (updateError) {
          throw updateError;
        }
        
        processed++;
        console.log(`[backfill-encryption] Saved ${table}:${record.id} (${processed}/${records.length})`);
        
      } catch (err: unknown) {
        failed++;
        let errMsg = 'Unknown error';
        if (err instanceof Error) {
          errMsg = err.message;
          console.error(`[backfill-encryption] Error stack: ${err.stack}`);
        } else if (typeof err === 'object' && err !== null) {
          errMsg = JSON.stringify(err);
        }
        const msg = `Failed to encrypt ${record.id}: ${errMsg}`;
        errors.push(msg);
        console.error(`[backfill-encryption] ${msg}`);
      }
    }
    
    // Check remaining count
    const { count: remaining } = await supabase
      .from(table)
      .select('id', { count: 'exact', head: true })
      .eq('is_encrypted', false)
      .not('transcript_content', 'is', null);
    
    console.log(`[backfill-encryption] Completed batch. Processed: ${processed}, Failed: ${failed}, Remaining: ${remaining}`);
    
    return new Response(JSON.stringify({ 
      success: true,
      processed,
      failed,
      remaining: remaining || 0,
      errors: errors.length > 0 ? errors : undefined,
      message: `Encrypted ${processed} records in ${table}. ${remaining || 0} remaining.`,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
    
  } catch (error: unknown) {
    let message = 'Unknown error';
    if (error instanceof Error) {
      message = error.message;
      console.error('[backfill-encryption] Stack:', error.stack);
    }
    console.error('[backfill-encryption] Error:', message);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const PENDO_PRODUCTS_TREE_ID = 'b0000001-0001-4000-8000-000000000001';

// Product name mapping to detection rule names (case-insensitive)
const PRODUCT_NAME_MAPPING: Record<string, string> = {
  'analytics': 'Analytics',
  'web analytics': 'Web Analytics',
  'pendo analytics': 'Analytics',
  'guides': 'Guides',
  'in-app guides': 'Guides',
  'pendo guides': 'Guides',
  'roadmap': 'Roadmaps',
  'roadmaps': 'Roadmaps',
  'pendo roadmap': 'Roadmaps',
  'pendo roadmaps': 'Roadmaps',
  'session replay': 'Session Replay',
  'replay': 'Session Replay',
  'pendo session replay': 'Session Replay',
  'orchestrate': 'Orchestrate',
  'pendo orchestrate': 'Orchestrate',
  'listen': 'Listen',
  'pendo listen': 'Listen',
  'segments': 'Segments',
  'pendo segments': 'Segments',
  'nps': 'Polls / Surveys',
  'nps module': 'Polls / Surveys',
  'polls': 'Polls / Surveys',
  'surveys': 'Polls / Surveys',
  'sentiment': 'Sentiment',
  'pendo sentiment': 'Sentiment',
  'datasync': 'DataSync',
  'data sync': 'DataSync',
  'pendo datasync': 'DataSync',
  'mcp': 'MCP',
  'mind the product': 'Mind the Product',
  'agent mode': 'Agent Mode',
  'agent analytics': 'Agent Analytics',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('Starting Pendo products backfill...');

    // Get all Pendo product detection rules
    const { data: rules, error: rulesError } = await supabase
      .from('detection_rules')
      .select('id, name')
      .eq('tree_id', PENDO_PRODUCTS_TREE_ID)
      .eq('is_active', true);

    if (rulesError) {
      throw new Error(`Failed to fetch rules: ${rulesError.message}`);
    }

    console.log(`Found ${rules?.length || 0} Pendo product rules`);

    // Create a map of product name to rule
    const ruleMap = new Map<string, { id: string; name: string }>();
    for (const rule of rules || []) {
      ruleMap.set(rule.name.toLowerCase().trim(), rule);
    }

    // Also add mappings from aliases
    for (const [alias, productName] of Object.entries(PRODUCT_NAME_MAPPING)) {
      const rule = ruleMap.get(productName.toLowerCase().trim());
      if (rule) {
        ruleMap.set(alias.toLowerCase().trim(), rule);
      }
    }
    
    console.log('Rule map keys:', Array.from(ruleMap.keys()).join(', '));

    // Get existing product mentions from product_mentions table
    const { data: productMentions, error: mentionsError } = await supabase
      .from('product_mentions')
      .select(`
        id,
        transcript_id,
        account_id,
        opportunity_id,
        product_name,
        mention_count,
        context_snippet,
        confidence_score,
        created_at,
        transcript_reviews!product_mentions_transcript_id_fkey(
          id,
          opportunity_id,
          final_account_id
        )
      `)
      .order('created_at', { ascending: true });

    if (mentionsError) {
      throw new Error(`Failed to fetch product mentions: ${mentionsError.message}`);
    }

    console.log(`Found ${productMentions?.length || 0} product mentions to process`);

    let matchesCreated = 0;
    let insightsCreated = 0;
    let skipped = 0;

    // Get capture field IDs for Pendo rules
    const { data: captureFields, error: fieldsError } = await supabase
      .from('detection_rule_capture_fields')
      .select('id, rule_id, field_name')
      .in('rule_id', rules?.map(r => r.id) || []);

    if (fieldsError) {
      console.error('Failed to fetch capture fields:', fieldsError.message);
    }

    // Create a map of rule_id -> field_name -> field_id
    const captureFieldMap = new Map<string, Map<string, string>>();
    for (const field of captureFields || []) {
      if (!captureFieldMap.has(field.rule_id)) {
        captureFieldMap.set(field.rule_id, new Map());
      }
      captureFieldMap.get(field.rule_id)!.set(field.field_name, field.id);
    }

    for (const mention of productMentions || []) {
      const productName = mention.product_name?.toLowerCase().trim();
      if (!productName) {
        skipped++;
        continue;
      }

      let rule = ruleMap.get(productName);
      
      // If not found, try partial matching for Pendo products
      if (!rule) {
        // Check if any rule name is contained in the product name or vice versa
        for (const [key, r] of ruleMap.entries()) {
          if (productName.includes(key) || key.includes(productName)) {
            rule = r;
            break;
          }
        }
      }
      
      if (!rule) {
        console.log(`No rule found for product: ${mention.product_name}`);
        skipped++;
        continue;
      }

      const transcriptReview = mention.transcript_reviews as any;
      if (!transcriptReview) {
        skipped++;
        continue;
      }

      // Check if match already exists
      const { data: existingMatch } = await supabase
        .from('detection_rule_matches')
        .select('id')
        .eq('rule_id', rule.id)
        .eq('transcript_id', mention.transcript_id)
        .maybeSingle();

      if (existingMatch) {
        skipped++;
        continue;
      }

      // Create detection rule match
      const { data: newMatch, error: matchError } = await supabase
        .from('detection_rule_matches')
        .insert({
          rule_id: rule.id,
          transcript_id: mention.transcript_id,
          opportunity_id: transcriptReview.opportunity_id,
          confidence_score: mention.confidence_score || 0.8,
          matched_phrases: [mention.product_name],
          occurrence_count: mention.mention_count || 1,
          first_detected_at: mention.created_at,
          speaker_type: 'unknown',
        })
        .select('id')
        .single();

      if (matchError) {
        console.error(`Failed to create match for ${mention.product_name}:`, matchError.message);
        continue;
      }

      matchesCreated++;

      // Create captured insights for this match
      const accountId = transcriptReview.final_account_id;
      if (!accountId) continue;

      const fieldMap = captureFieldMap.get(rule.id);
      if (!fieldMap) continue;

      const insightsToCreate = [];

      // mention_count field
      const mentionCountFieldId = fieldMap.get('mention_count');
      if (mentionCountFieldId) {
        insightsToCreate.push({
          account_id: accountId,
          capture_field_id: mentionCountFieldId,
          rule_match_id: newMatch.id,
          opportunity_id: transcriptReview.opportunity_id,
          source_transcript_id: mention.transcript_id,
          value: String(mention.mention_count || 1),
          confidence_score: mention.confidence_score || 0.8,
        });
      }

      // context_quotes field
      const contextQuotesFieldId = fieldMap.get('context_quotes');
      if (contextQuotesFieldId && mention.context_snippet) {
        insightsToCreate.push({
          account_id: accountId,
          capture_field_id: contextQuotesFieldId,
          rule_match_id: newMatch.id,
          opportunity_id: transcriptReview.opportunity_id,
          source_transcript_id: mention.transcript_id,
          value_json: [mention.context_snippet],
          confidence_score: mention.confidence_score || 0.8,
        });
      }

      // interest_level field (infer from mention count)
      const interestLevelFieldId = fieldMap.get('interest_level');
      if (interestLevelFieldId) {
        const mentionCount = mention.mention_count || 1;
        let interestLevel = 'low';
        if (mentionCount >= 5) interestLevel = 'high';
        else if (mentionCount >= 2) interestLevel = 'medium';

        insightsToCreate.push({
          account_id: accountId,
          capture_field_id: interestLevelFieldId,
          rule_match_id: newMatch.id,
          opportunity_id: transcriptReview.opportunity_id,
          source_transcript_id: mention.transcript_id,
          value: interestLevel,
          confidence_score: mention.confidence_score || 0.8,
        });
      }

      if (insightsToCreate.length > 0) {
        const { error: insightsError } = await supabase
          .from('account_captured_insights')
          .insert(insightsToCreate);

        if (insightsError) {
          console.error('Failed to create insights:', insightsError.message);
        } else {
          insightsCreated += insightsToCreate.length;
        }
      }
    }

    console.log(`Backfill complete: ${matchesCreated} matches created, ${insightsCreated} insights created, ${skipped} skipped`);

    return new Response(
      JSON.stringify({
        success: true,
        matchesCreated,
        insightsCreated,
        skipped,
        totalProcessed: productMentions?.length || 0,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error('Backfill error:', message);
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

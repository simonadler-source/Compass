import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const data = encoder.encode(keyInput);
  const bytes = new Uint8Array(32);
  for (let i = 0; i < Math.min(data.length, 32); i++) {
    bytes[i] = data[i];
  }
  return bytes;
}

async function encrypt(plaintext: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plaintext);
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['encrypt']);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv.buffer as ArrayBuffer }, key, data);
  return { ciphertext: bytesToBase64(new Uint8Array(encrypted)), iv: bytesToBase64(iv) };
}

// Encrypt with a pre-generated IV (for sharing IV across fields in a record)
async function encryptWithIv(plaintext: string, ivBytes: Uint8Array, keyInput: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plaintext);
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['encrypt']);
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: ivBytes.buffer as ArrayBuffer }, key, data);
  return bytesToBase64(new Uint8Array(encrypted));
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

interface TableConfig {
  table: string;
  selectFields: string[];
  plaintextFields: string[];
  encryptedFields: string[];
  ivField: string;
  isEncryptedField: string;
  keepPlaintext?: string[];
}

const TABLE_CONFIGS: TableConfig[] = [
  // PII Tables
  {
    table: 'momentum_meetings',
    selectFields: ['id', 'title', 'host_email', 'host_name', 'attendees', 'is_encrypted'],
    plaintextFields: ['title', 'host_email', 'host_name', 'attendees'],
    encryptedFields: ['title_encrypted', 'host_email_encrypted', 'host_name_encrypted', 'attendees_encrypted'],
    ivField: 'pii_encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  // account_contacts: plaintext columns (name, email, phone, role, notes) have been dropped
  // Backfill is no longer needed/possible for this table - all data is now encrypted-only
  {
    table: 'profiles',
    selectFields: ['id', 'email', 'full_name', 'is_encrypted'],
    plaintextFields: ['email', 'full_name'],
    encryptedFields: ['email_encrypted', 'full_name_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
    keepPlaintext: ['email', 'full_name'],
  },
  {
    table: 'account_team_members',
    selectFields: ['id', 'team_member_email', 'is_encrypted'],
    plaintextFields: ['team_member_email'],
    encryptedFields: ['team_member_email_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'opportunity_team_members',
    selectFields: ['id', 'team_member_email', 'is_encrypted'],
    plaintextFields: ['team_member_email'],
    encryptedFields: ['team_member_email_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  // Commercially Sensitive Tables
  {
    table: 'account_pain_points',
    selectFields: ['id', 'pain_point', 'business_impact', 'is_encrypted'],
    plaintextFields: ['pain_point', 'business_impact'],
    encryptedFields: ['pain_point_encrypted', 'business_impact_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'account_use_cases',
    selectFields: ['id', 'use_case', 'description', 'is_encrypted'],
    plaintextFields: ['use_case', 'description'],
    encryptedFields: ['use_case_encrypted', 'description_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'account_nbas',
    selectFields: ['id', 'action', 'notes', 'is_encrypted'],
    plaintextFields: ['action', 'notes'],
    encryptedFields: ['action_encrypted', 'notes_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'account_metrics',
    selectFields: ['id', 'metric_value', 'context', 'is_encrypted'],
    plaintextFields: ['metric_value', 'context'],
    encryptedFields: ['metric_value_encrypted', 'context_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'account_strategic_themes',
    selectFields: ['id', 'theme_name', 'description', 'supporting_evidence', 'is_encrypted'],
    plaintextFields: ['theme_name', 'description', 'supporting_evidence'],
    encryptedFields: ['theme_name_encrypted', 'description_encrypted', 'supporting_evidence_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'account_exec_summaries',
    selectFields: ['id', 'summary_narrative', 'engagement_summary', 'key_risks', 'key_opportunities', 'health_indicators', 'is_encrypted'],
    plaintextFields: ['summary_narrative', 'engagement_summary', 'key_risks', 'key_opportunities', 'health_indicators'],
    encryptedFields: ['summary_narrative_encrypted', 'engagement_summary_encrypted', 'key_risks_encrypted', 'key_opportunities_encrypted', 'health_indicators_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'customer_stories',
    selectFields: ['id', 'situation', 'behavior', 'impact', 'impact_metrics', 'is_encrypted'],
    plaintextFields: ['situation', 'behavior', 'impact', 'impact_metrics'],
    encryptedFields: ['situation_encrypted', 'behavior_encrypted', 'impact_encrypted', 'impact_metrics_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'contact_meeting_snapshots',
    selectFields: ['id', 'key_quotes', 'concerns_raised', 'action_items', 'topics_discussed', 'notes', 'is_encrypted'],
    plaintextFields: ['key_quotes', 'concerns_raised', 'action_items', 'topics_discussed', 'notes'],
    encryptedFields: ['key_quotes_encrypted', 'concerns_raised_encrypted', 'action_items_encrypted', 'topics_discussed_encrypted', 'notes_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'account_captured_insights',
    selectFields: ['id', 'value', 'value_json', 'is_encrypted'],
    plaintextFields: ['value', 'value_json'],
    encryptedFields: ['value_encrypted', 'value_json_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'opportunity_milestones',
    selectFields: ['id', 'description', 'notes', 'is_encrypted'],
    plaintextFields: ['description', 'notes'],
    encryptedFields: ['description_encrypted', 'notes_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'opportunity_validation_tasks',
    selectFields: ['id', 'notes', 'is_encrypted'],
    plaintextFields: ['notes'],
    encryptedFields: ['notes_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'opportunity_readiness_answers',
    selectFields: ['id', 'answer', 'notes', 'is_encrypted'],
    plaintextFields: ['answer', 'notes'],
    encryptedFields: ['answer_encrypted', 'notes_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'competitor_scores',
    selectFields: ['id', 'rationale', 'is_encrypted'],
    plaintextFields: ['rationale'],
    encryptedFields: ['rationale_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  // Newly added tables
  {
    table: 'detection_rule_matches',
    selectFields: ['id', 'matched_phrases', 'speaker_email', 'speaker_name', 'signal_occurrences', 'is_encrypted'],
    plaintextFields: ['matched_phrases', 'speaker_email', 'speaker_name', 'signal_occurrences'],
    encryptedFields: ['matched_phrases_encrypted', 'speaker_email_encrypted', 'speaker_name_encrypted', 'signal_occurrences_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'login_history',
    selectFields: ['id', 'ip_address', 'user_agent', 'is_encrypted'],
    plaintextFields: ['ip_address', 'user_agent'],
    encryptedFields: ['ip_address_encrypted', 'user_agent_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'milestone_history',
    selectFields: ['id', 'notes', 'new_value', 'old_value', 'is_encrypted'],
    plaintextFields: ['notes', 'new_value', 'old_value'],
    encryptedFields: ['notes_encrypted', 'new_value_encrypted', 'old_value_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'account_technologies',
    selectFields: ['id', 'context', 'notes', 'owner_email', 'owner_name', 'is_encrypted'],
    plaintextFields: ['context', 'notes', 'owner_email', 'owner_name'],
    encryptedFields: ['context_encrypted', 'notes_encrypted', 'owner_email_encrypted', 'owner_name_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'account_documents',
    selectFields: ['id', 'name', 'content', 'is_encrypted'],
    plaintextFields: ['name', 'content'],
    encryptedFields: ['name_encrypted', 'content_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
  {
    table: 'competitors',
    selectFields: ['id', 'description', 'relationship_notes', 'is_encrypted'],
    plaintextFields: ['description', 'relationship_notes'],
    encryptedFields: ['description_encrypted', 'relationship_notes_encrypted'],
    ivField: 'encryption_iv',
    isEncryptedField: 'is_encrypted',
  },
];

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');

    if (!encryptionKey) throw new Error('TRANSCRIPT_ENCRYPTION_KEY not configured');

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { batchSize = 100, table: targetTable } = await req.json();
    
    const configsToProcess = targetTable 
      ? TABLE_CONFIGS.filter(c => c.table === targetTable)
      : TABLE_CONFIGS;
    
    if (targetTable && configsToProcess.length === 0) {
      throw new Error(`Unknown table: ${targetTable}`);
    }
    
    const results: Record<string, { processed: number; failed: number; remaining: number }> = {};
    
    for (const config of configsToProcess) {
      console.log(`[backfill-pii] Processing ${config.table}...`);
      
      const { data: records, error: fetchError } = await supabase
        .from(config.table)
        .select(config.selectFields.join(', '))
        .or(`${config.isEncryptedField}.eq.false,${config.isEncryptedField}.is.null`)
        .limit(batchSize);
      
      if (fetchError) {
        console.error(`[backfill-pii] Fetch error for ${config.table}:`, fetchError);
        results[config.table] = { processed: 0, failed: 0, remaining: -1 };
        continue;
      }
      
      if (!records || records.length === 0) {
        console.log(`[backfill-pii] No unencrypted records in ${config.table}`);
        results[config.table] = { processed: 0, failed: 0, remaining: 0 };
        continue;
      }
      
      console.log(`[backfill-pii] Found ${records.length} records to encrypt in ${config.table}`);
      
      let processed = 0;
      let failed = 0;
      
      for (const record of records) {
        try {
          const rec = record as unknown as Record<string, unknown>;
          const recordId = rec.id as string;
          
          const ivBytes = crypto.getRandomValues(new Uint8Array(12));
          const ivBase64 = bytesToBase64(ivBytes);
          
          const updateData: Record<string, unknown> = {
            [config.ivField]: ivBase64,
            [config.isEncryptedField]: true,
          };
          
          for (let i = 0; i < config.plaintextFields.length; i++) {
            const plaintextField = config.plaintextFields[i];
            const encryptedField = config.encryptedFields[i];
            const value = rec[plaintextField];
            
            if (value !== null && value !== undefined) {
              const plaintext = typeof value === 'object' ? JSON.stringify(value) : String(value);
              // Use encryptWithIv to ensure we use the SAME IV for all fields
              const ciphertext = await encryptWithIv(plaintext, ivBytes, encryptionKey);
              updateData[encryptedField] = ciphertext;
              if (!config.keepPlaintext?.includes(plaintextField)) {
                updateData[plaintextField] = null;
              }
            }
          }
          
          const { error: updateError } = await supabase
            .from(config.table)
            .update(updateData)
            .eq('id', recordId);
          
          if (updateError) throw updateError;
          processed++;
          
        } catch (err) {
          failed++;
          const rec = record as unknown as Record<string, unknown>;
          console.error(`[backfill-pii] Error encrypting ${config.table}:${rec.id}:`, err);
        }
      }
      
      const { count: remaining } = await supabase
        .from(config.table)
        .select('id', { count: 'exact', head: true })
        .or(`${config.isEncryptedField}.eq.false,${config.isEncryptedField}.is.null`);
      
      results[config.table] = { processed, failed, remaining: remaining || 0 };
      console.log(`[backfill-pii] ${config.table}: processed=${processed}, failed=${failed}, remaining=${remaining}`);
    }
    
    return new Response(JSON.stringify({ success: true, results }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
    
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    console.error('[backfill-pii] Error:', message);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

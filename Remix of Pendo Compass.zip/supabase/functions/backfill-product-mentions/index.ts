import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.0";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ProductMention {
  productName: string;
  mentionType: 'owned' | 'complementary' | 'competitive';
  sentimentScore: number | null;
  sentimentLabel: 'positive' | 'neutral' | 'negative' | 'mixed';
  contextSnippet: string;
  mentionCount: number;
  confidence: number;
  integrationContext: string | null;
}

interface TranscriptMetadata {
  id: string;
  final_account_id: string | null;
  opportunity_id: string | null;
  created_at: string;
}

async function extractProductMentions(
  transcript: string,
  pendoProducts: string[],
  competitorProducts: string[],
  aiConfig: { endpoint: string; apiKey: string; model: string }
): Promise<ProductMention[]> {
  const pendoProductsList = pendoProducts.join(', ') || 'Pendo, Pendo Guides, Pendo Analytics, Pendo Feedback, Pendo Roadmaps, Pendo Adopt, Pendo Listen';
  const competitorProductsList = competitorProducts.join(', ') || 'WalkMe, Whatfix, Userlane, Appcues, Intercom, Gainsight PX, Mixpanel, Amplitude, FullStory, Heap';

  const systemPrompt = `You are an AI assistant that extracts product mentions from sales call transcripts.

Your task is to identify all product mentions and categorize them:

PENDO PRODUCTS (mark as "owned"):
${pendoProductsList}

KNOWN COMPETITOR PRODUCTS (mark as "competitive"):
${competitorProductsList}

COMPLEMENTARY PRODUCTS: Any product mentioned as an integration partner, used alongside Pendo, or as a data source/destination (e.g., Salesforce, Segment, Snowflake, Jira, Slack, etc.)

For each product mention:
1. Determine the mention type:
   - "owned": Pendo products
   - "competitive": Competitor products  
   - "complementary": Integration partners or complementary technologies
   
2. Extract sentiment (how they feel about the product):
   - Score 0-100 (0=very negative, 50=neutral, 100=very positive)
   - Label: "positive", "neutral", "negative", or "mixed"
   
3. Capture context:
   - The exact quote or paraphrased context where mentioned
   - Integration context if applicable (e.g., "want to integrate with", "replacing", "using alongside")
    
4. Count how many times each product is mentioned in the transcript

5. CRITICAL: Only include products that are ACTUALLY mentioned in the transcript.
   - If a product from the lists above is NOT mentioned at all, DO NOT include it in the results.
   - Never return entries with mentionCount of 0.
   - Never return entries with context like "X was not mentioned" or "X was not discussed".
   - Only report genuine, real mentions that appear in the transcript text.

6. Be careful to distinguish actual product mentions from false positives

Return a JSON object with this structure:
{
  "productMentions": [
    {
      "productName": "string",
      "mentionType": "owned" | "complementary" | "competitive",
      "sentimentScore": number | null,
      "sentimentLabel": "positive" | "neutral" | "negative" | "mixed",
      "contextSnippet": "string",
      "mentionCount": number,
      "confidence": number (0-1),
      "integrationContext": "string" | null
    }
  ]
}`;

  // Limit transcript to prevent token overflow and ensure complete responses
  const userPrompt = `Extract all product mentions from this transcript. Be concise with context snippets (max 100 chars each):\n\n${transcript.slice(0, 50000)}`;

  try {
    const response = await fetch(aiConfig.endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${aiConfig.apiKey}`,
      },
      body: JSON.stringify({
        model: aiConfig.model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.1,
        max_tokens: 8000,
      }),
    });

    if (!response.ok) {
      console.error("AI API error:", await response.text());
      return [];
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    
    if (!content) {
      console.error("No content in AI response");
      return [];
    }

    // Extract JSON from response (handle markdown code blocks)
    let jsonStr = content;
    const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (jsonMatch) {
      jsonStr = jsonMatch[1].trim();
    } else {
      // Try to find JSON object directly
      const objMatch = content.match(/\{[\s\S]*\}/);
      if (objMatch) {
        jsonStr = objMatch[0];
      }
    }

    try {
      const parsed = JSON.parse(jsonStr);
      const mentions = parsed.productMentions || [];
      // Filter out false mentions: zero count or "not mentioned/discussed" context
      const notMentionedPattern = /not mentioned|not discussed|no mention|no direct mention|not explicitly/i;
      return mentions.filter((m: ProductMention) => 
        m.mentionCount > 0 && 
        !(m.contextSnippet && notMentionedPattern.test(m.contextSnippet))
      );
    } catch (parseError) {
      console.error("JSON parse error, raw content:", content.slice(0, 500));
      return [];
    }
  } catch (error) {
    console.error("Failed to extract product mentions:", error);
    return [];
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(supabaseUrl, supabaseKey);

  try {
    const { limit = 10, transcriptIds } = await req.json().catch(() => ({}));

    // Get AI config
    const aiConfig = await getAIConfig();
    console.log(`Using AI provider: ${aiConfig.endpoint}`);

    // Fetch Pendo products
    const { data: pendoProducts } = await supabase
      .from('technology_repository')
      .select('name')
      .eq('is_customer', true);
    
    const pendoProductNames = pendoProducts?.map(p => p.name) || [];

    // Fetch competitor products
    const { data: competitorProducts } = await supabase
      .from('technology_repository')
      .select('name')
      .eq('is_competitor', true);
    
    const competitorProductNames = competitorProducts?.map(p => p.name) || [];

    // Find transcripts that need processing - fetch IDs first without content
    let query = supabase
      .from('transcript_reviews')
      .select('id, final_account_id, opportunity_id, created_at')
      .not('final_account_id', 'is', null);

    if (transcriptIds && transcriptIds.length > 0) {
      query = query.in('id', transcriptIds);
    }

    // Exclude transcripts that already have product mentions
    const { data: existingMentions } = await supabase
      .from('product_mentions')
      .select('transcript_id')
      .limit(1000);
    
    const processedTranscriptIds = new Set(existingMentions?.map(m => m.transcript_id) || []);

    const { data: transcripts, error: fetchError } = await query
      .order('created_at', { ascending: false })
      .limit(limit);

    if (fetchError) {
      throw new Error(`Failed to fetch transcripts: ${fetchError.message}`);
    }

    // Filter out already processed
    const transcriptsToProcess = (transcripts as TranscriptMetadata[])?.filter(
      t => !processedTranscriptIds.has(t.id)
    ) || [];

    if (transcriptsToProcess.length === 0) {
      return new Response(
        JSON.stringify({ message: "No transcripts to process", processed: 0 }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Processing ${transcriptsToProcess.length} transcripts for product mentions`);

    let totalMentions = 0;
    const results: Array<{ transcriptId: string; mentionCount: number; error?: string }> = [];

    for (const transcript of transcriptsToProcess) {
      try {
        console.log(`Processing transcript ${transcript.id}`);
        
        // Fetch transcript content on-demand to avoid bulk memory/timeout issues
        const { data: fullTranscript, error: contentError } = await supabase
          .from('transcript_reviews')
          .select('transcript_content')
          .eq('id', transcript.id)
          .single();

        if (contentError || !fullTranscript?.transcript_content) {
          console.log(`Skipping transcript ${transcript.id} - no content available`);
          results.push({ transcriptId: transcript.id, mentionCount: 0, error: 'No content' });
          continue;
        }

        const productMentions = await extractProductMentions(
          fullTranscript.transcript_content,
          pendoProductNames,
          competitorProductNames,
          aiConfig
        );

        if (productMentions.length > 0) {
          // Transform to database format
          const dbMentions = productMentions.map(mention => ({
            transcript_id: transcript.id,
            account_id: transcript.final_account_id,
            opportunity_id: transcript.opportunity_id,
            product_name: mention.productName,
            mention_type: mention.mentionType,
            sentiment_score: mention.sentimentScore,
            sentiment_label: mention.sentimentLabel,
            context_snippet: mention.contextSnippet,
            mention_count: mention.mentionCount,
            confidence_score: mention.confidence,
            integration_context: mention.integrationContext,
            transcript_date: transcript.created_at,
          }));

          const { error: insertError } = await supabase
            .from('product_mentions')
            .insert(dbMentions);

          if (insertError) {
            console.error(`Failed to insert mentions for ${transcript.id}:`, insertError);
            results.push({ transcriptId: transcript.id, mentionCount: 0, error: insertError.message });
          } else {
            totalMentions += productMentions.length;
            results.push({ transcriptId: transcript.id, mentionCount: productMentions.length });
            console.log(`Saved ${productMentions.length} product mentions for transcript ${transcript.id}`);
          }
        } else {
          results.push({ transcriptId: transcript.id, mentionCount: 0 });
        }

        // Small delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        console.error(`Error processing transcript ${transcript.id}:`, error);
        results.push({ transcriptId: transcript.id, mentionCount: 0, error: String(error) });
      }
    }

    return new Response(
      JSON.stringify({
        message: `Backfill complete`,
        processed: transcriptsToProcess.length,
        totalMentions,
        results
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Backfill error:", error);
    return new Response(
      JSON.stringify({ error: String(error) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Encryption helpers
function deriveKeyBytes(keyInput: string): Uint8Array {
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < raw.length && i < 32; i++) key[i] = raw[i];
  return key;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

async function encryptValue(value: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey(
    "raw", 
    keyBytes.buffer as ArrayBuffer, 
    "AES-GCM", 
    false, 
    ["encrypt"]
  );
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plainBytes = new TextEncoder().encode(value);
  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plainBytes);
  return { ciphertext: bytesToBase64(new Uint8Array(cipherBytes)), iv: bytesToBase64(iv) };
}

interface MomentumAttendee {
  name: string;
  email: string;
  isInternal: boolean;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

    console.log('[Backfill] Starting team member backfill from existing meetings...');

    // Get all team members from both team_members table and profiles
    const { data: allTeamMembers } = await supabase
      .from('team_members')
      .select('member_email')
      .eq('is_active', true);

    const { data: allProfiles } = await supabase
      .from('profiles')
      .select('email')
      .in('status', ['active', 'pending', 'identified']);

    // Build combined set of internal emails (team members OR profiles with @pendo.io domain)
    const teamEmails = new Set<string>();
    for (const t of allTeamMembers || []) {
      if (t.member_email) teamEmails.add(t.member_email.toLowerCase());
    }
    for (const p of allProfiles || []) {
      if (p.email) teamEmails.add(p.email.toLowerCase());
    }

    if (teamEmails.size === 0) {
      return new Response(JSON.stringify({ 
        success: true, 
        message: 'No team members configured',
        processed: 0 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`[Backfill] Found ${teamEmails.size} internal emails to match`);

    // Get all imported meetings with attendees
    const { data: meetings, error: meetingsError } = await supabase
      .from('momentum_meetings')
      .select('id, attendees, matched_account_id')
      .eq('status', 'imported')
      .not('matched_account_id', 'is', null);

    if (meetingsError) throw meetingsError;

    console.log(`[Backfill] Found ${meetings?.length || 0} imported meetings to process`);

    // Get opportunities for matched accounts
    const accountIds = [...new Set(meetings?.map(m => m.matched_account_id).filter(Boolean) || [])];
    const { data: opportunities } = await supabase
      .from('opportunities')
      .select('id, account_id')
      .in('account_id', accountIds);

    const oppByAccount: Record<string, string> = {};
    for (const opp of opportunities || []) {
      if (!oppByAccount[opp.account_id]) {
        oppByAccount[opp.account_id] = opp.id;
      }
    }

    let accountAssignments = 0;
    let opportunityAssignments = 0;

    for (const meeting of meetings || []) {
      const attendees = (meeting.attendees as MomentumAttendee[]) || [];
      const accountId = meeting.matched_account_id;
      const opportunityId = oppByAccount[accountId];

      // Find internal attendees - match by @pendo.io domain OR being in teamEmails set
      const internalTeamAttendees = attendees
        .filter(a => {
          const emailLower = a.email.toLowerCase();
          return a.isInternal || teamEmails.has(emailLower) || emailLower.endsWith('@pendo.io');
        })
        .map(a => a.email.toLowerCase());

      if (internalTeamAttendees.length === 0) continue;

      const encryptionKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || "";

      // Add to account team with encryption - check for THIS specific email
      for (const email of internalTeamAttendees) {
        const { ciphertext, iv } = await encryptValue(email, encryptionKey);
        
        // Use upsert to handle existing records properly
        // First check if this specific email already exists
        const { data: existing } = await supabase
          .from('account_team_members')
          .select('id, team_member_email')
          .eq('account_id', accountId)
          .eq('team_member_email', email)
          .maybeSingle();
        
        if (!existing) {
          // Try encrypted lookup as fallback - can't easily match encrypted values
          // so just insert and let DB handle duplicates
          const { error: accError } = await supabase
            .from('account_team_members')
            .insert({
              account_id: accountId,
              team_member_email: email, // Store plaintext for easier lookups
              team_member_email_encrypted: ciphertext,
              role: 'contributor',
              added_from_meeting_id: meeting.id,
              encryption_iv: iv,
              is_encrypted: true,
            });

          if (!accError) accountAssignments++;
        }
      }

      // Add to opportunity team (opportunity_team_members is not an encrypted table)
      if (opportunityId) {
        for (const email of internalTeamAttendees) {
          const { error: oppError } = await supabase
            .from('opportunity_team_members')
            .upsert({
              opportunity_id: opportunityId,
              team_member_email: email,
              role: 'contributor',
              added_from_meeting_id: meeting.id,
            }, { onConflict: 'opportunity_id,team_member_email' });

          if (!oppError) opportunityAssignments++;
        }
      }
    }

    console.log(`[Backfill] Completed: ${accountAssignments} account assignments, ${opportunityAssignments} opportunity assignments`);

    return new Response(JSON.stringify({
      success: true,
      meetingsProcessed: meetings?.length || 0,
      accountAssignments,
      opportunityAssignments,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('[Backfill] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

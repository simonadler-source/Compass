import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Encryption helpers - consistent with api-gateway
function deriveKeyBytes(keyInput: string): Uint8Array {
  // If it looks like a hex string (all hex chars, length >= 64), parse as hex
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  // Fallback: use raw text encoding
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < raw.length && i < 32; i++) key[i] = raw[i];
  return key;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

async function encryptValue(value: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey(
    "raw", 
    keyBytes.buffer as ArrayBuffer, 
    "AES-GCM", 
    false, 
    ["encrypt"]
  );
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plainBytes = new TextEncoder().encode(value);
  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plainBytes);
  return { ciphertext: bytesToBase64(new Uint8Array(cipherBytes)), iv: bytesToBase64(iv) };
}

interface TranscriptToProcess {
  id: string;
  file_name: string;
  transcript_content: string;
  final_account_id: string;
  opportunity_id: string | null;
}

async function processTranscript(
  supabaseUrl: string,
  serviceRoleKey: string,
  transcript: TranscriptToProcess
): Promise<{ id: string; success: boolean; error?: string }> {
  console.log(`[Backfill] Processing transcript ${transcript.id} (${transcript.file_name})`);
  
  const supabase = createClient(supabaseUrl, serviceRoleKey);
  
  try {
    // Call analyze-transcript-streaming function with generous timeout (AI can be slow)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 240000); // 4 minute timeout
    
    console.log(`[Backfill] Calling analyze-transcript-streaming for ${transcript.file_name}...`);
    
    const analysisResponse = await fetch(`${supabaseUrl}/functions/v1/analyze-transcript-streaming`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${serviceRoleKey}`,
      },
      body: JSON.stringify({ 
        transcript: transcript.transcript_content.slice(0, 120000),
        skipEnrichment: false,
      }),
      signal: controller.signal,
    });
    
    clearTimeout(timeoutId);
    
    console.log(`[Backfill] analyze-transcript-streaming response status: ${analysisResponse.status}`);

    if (!analysisResponse.ok) {
      const errorText = await analysisResponse.text();
      console.error(`[Backfill] Analysis failed for ${transcript.id}: Status ${analysisResponse.status}, Error: ${errorText}`);
      return { id: transcript.id, success: false, error: `HTTP ${analysisResponse.status}: ${errorText.slice(0, 200)}` };
    }

    // Parse SSE stream to get final result
    const reader = analysisResponse.body?.getReader();
    if (!reader) {
      return { id: transcript.id, success: false, error: 'No response body' };
    }

    const decoder = new TextDecoder();
    let buffer = '';
    let analysis: any = null;
    let lastError: string | null = null;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const chunks = buffer.split('\n\n');
      buffer = chunks.pop() || '';

      for (const chunk of chunks) {
        if (!chunk.trim()) continue;

        const match = chunk.match(/^event: (\w+)\ndata: (.+)$/s);
        if (!match) continue;

        const [, eventType, dataStr] = match;

        try {
          const data = JSON.parse(dataStr);

          if (eventType === 'core_complete') {
            analysis = data.result;
            console.log(`[Backfill] Got core_complete for ${transcript.file_name}`);
          } else if (eventType === 'error') {
            lastError = data.message || 'Unknown error';
            console.error(`[Backfill] Stream error for ${transcript.id}: ${lastError}`);
          } else if (eventType === 'progress') {
            console.log(`[Backfill] Progress for ${transcript.file_name}: ${data.stage}`);
          }
        } catch {
          // Ignore malformed/partial events
        }
      }
    }

    // Process trailing buffer
    if (buffer.trim() && !analysis) {
      const match = buffer.match(/^event: (\w+)\ndata: (.+)$/s);
      if (match) {
        const [, eventType, dataStr] = match;
        try {
          const data = JSON.parse(dataStr);
          if (eventType === 'core_complete') analysis = data.result;
          if (eventType === 'error') lastError = data.message || 'Unknown error';
        } catch {
          // ignore
        }
      }
    }

    if (!analysis) {
      return { id: transcript.id, success: false, error: lastError || 'No analysis result in stream' };
    }
    
    console.log(`[Backfill] AI analysis completed for ${transcript.file_name}`);

    // Update transcript_reviews with insights
    const { error: updateError } = await supabase
      .from('transcript_reviews')
      .update({
        extracted_technologies: analysis.technologies,
        extracted_insights: {
          ...analysis.insights,
          commercialInsights: analysis.commercialInsights,
          nextBestActions: analysis.nbas ?? analysis.nextBestActions,
          people: analysis.people,
          useCases: analysis.useCases,
          operationalMetrics: analysis.operationalMetrics,
          competitorMentions: analysis.competitorMentions,
          discoveryQuestions: analysis.discoveryQuestions,
        },
      })
      .eq('id', transcript.id);

    if (updateError) {
      console.error(`[Backfill] Failed to update transcript ${transcript.id}: ${updateError.message}`);
      return { id: transcript.id, success: false, error: updateError.message };
    }

    // If we have an account, add technologies and NBAs with encryption
    if (transcript.final_account_id) {
      const encryptionKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || "";

      // Add technologies
      if (analysis.technologies?.length > 0) {
        for (const tech of analysis.technologies) {
          await supabase
            .from('account_technologies')
            .upsert({
              account_id: transcript.final_account_id,
              name: tech.name,
              category: tech.category || 'Other',
              layer: tech.suggestedLayer || tech.layer || 'adopt',
              status: 'pending',
              notes: `Backfill-extracted from: ${transcript.file_name}`,
              needs_review: tech.needsReview ?? true,
            }, { onConflict: 'account_id,name' });
        }
        console.log(`[Backfill] Added ${analysis.technologies.length} technologies for account`);
      }

      // Add NBAs with encryption
      const extractedNBAs = analysis.nbas ?? analysis.nextBestActions ?? [];
      if (extractedNBAs.length > 0) {
        for (const nba of extractedNBAs) {
          const actionText = nba.action;
          const notesText = nba.reasoning || null;
          
          const { ciphertext: actionCipher, iv } = await encryptValue(actionText, encryptionKey);
          let notesCipher: string | null = null;
          if (notesText) {
            const notesEnc = await encryptValue(notesText, encryptionKey);
            notesCipher = notesEnc.ciphertext;
          }
          
          await supabase.from('account_nbas').insert({
            account_id: transcript.final_account_id,
            action: null,
            action_encrypted: actionCipher,
            action_type: nba.actionType || 'follow_up',
            priority: nba.priority || 'medium',
            delivery_method: nba.deliveryMethod || 'email',
            notes: null,
            notes_encrypted: notesCipher,
            status: 'pending',
            source_transcript_id: transcript.id,
            encryption_iv: iv,
            is_encrypted: true,
          });
        }
        console.log(`[Backfill] Added ${extractedNBAs.length} NBAs for account`);
      }

      // Add use cases with encryption
      if (analysis.useCases?.length > 0) {
        for (const useCase of analysis.useCases) {
          const useCaseText = typeof useCase === 'string' ? useCase : useCase.description || String(useCase);
          const { ciphertext, iv } = await encryptValue(useCaseText, encryptionKey);
          
          await supabase.from('account_use_cases').insert({
            account_id: transcript.final_account_id,
            use_case: null,
            use_case_encrypted: ciphertext,
            functional_area: 'General',
            status: 'identified',
            source: 'transcript_backfill',
            source_transcript_id: transcript.id,
            encryption_iv: iv,
            is_encrypted: true,
          });
        }
        console.log(`[Backfill] Added ${analysis.useCases.length} use cases for account`);
      }
    }

    return { id: transcript.id, success: true };
  } catch (error) {
    console.error(`[Backfill] Error processing transcript ${transcript.id}:`, error);
    return { id: transcript.id, success: false, error: String(error) };
  }
}

interface MeetingData {
  id: string;
  momentum_id: string;
  title: string;
  start_time: string;
  transcript_content: string;
  matched_account_id: string;
}

async function processMeetingWithStatusUpdates(
  supabase: any,
  supabaseUrl: string,
  serviceRoleKey: string,
  meeting: MeetingData,
  existingTranscriptReviewId: string | null
): Promise<{ success: boolean; error?: string }> {
  const meetingId = meeting.id;
  
  try {
    // Mark as processing
    await supabase
      .from('momentum_meetings')
      .update({ status: 'processing' } as any)
      .eq('id', meetingId);
    
    console.log(`[Backfill] Processing meeting: ${meeting.title} (reanalyze: ${!!existingTranscriptReviewId})`);

    let transcriptToProcess: TranscriptToProcess;

    if (existingTranscriptReviewId) {
      // Re-analyzing existing transcript - fetch it
      const { data: existingTranscript, error: fetchError } = await supabase
        .from('transcript_reviews')
        .select('id, file_name, transcript_content, final_account_id, opportunity_id')
        .eq('id', existingTranscriptReviewId)
        .single();
      
      if (fetchError || !existingTranscript) {
        console.error(`[Backfill] Failed to fetch transcript_review ${existingTranscriptReviewId}: ${fetchError?.message}`);
        await supabase.from('momentum_meetings').update({ status: 'imported' } as any).eq('id', meetingId);
        return { success: false, error: fetchError?.message || 'Transcript not found' };
      }
      
      transcriptToProcess = existingTranscript as TranscriptToProcess;
    } else {
      // Creating new transcript_review
      const { data: newTranscript, error: insertError } = await supabase
        .from('transcript_reviews')
        .insert({
          file_name: `momentum_${meeting.momentum_id}`,
          transcript_content: meeting.transcript_content,
          final_account_id: meeting.matched_account_id,
          status: 'approved',
        } as any)
        .select('id, file_name, transcript_content, final_account_id, opportunity_id')
        .single();

      if (insertError) {
        console.error(`[Backfill] Failed to create transcript_review for ${meeting.title}: ${insertError.message}`);
        await supabase.from('momentum_meetings').update({ status: 'imported' } as any).eq('id', meetingId);
        return { success: false, error: insertError.message };
      }
      
      transcriptToProcess = newTranscript as TranscriptToProcess;
    }

    // Process the transcript
    const result = await processTranscript(supabaseUrl, serviceRoleKey, transcriptToProcess);
    
    if (!result.success) {
      await supabase.from('momentum_meetings').update({ status: 'imported' } as any).eq('id', meetingId);
      return { success: false, error: result.error };
    }

    // Mark as analyzed
    await supabase.from('momentum_meetings').update({ status: 'imported' } as any).eq('id', meetingId);
    
    return { success: true };
  } catch (error) {
    console.error(`[Backfill] Error processing ${meeting.title}:`, error);
    await supabase.from('momentum_meetings').update({ status: 'imported' } as any).eq('id', meetingId);
    return { success: false, error: String(error) };
  }
}

async function runBackfillInBackground(
  supabaseUrl: string,
  serviceRoleKey: string,
  workItems: { type: string; meeting: MeetingData; transcriptReviewId: string | null }[],
  limit: number
) {
  const supabase = createClient(supabaseUrl, serviceRoleKey);
  
  const toProcess = workItems.slice(0, limit);
  console.log(`[Backfill Background] Starting SEQUENTIAL processing of ${toProcess.length} items`);
  
  const results: { id: string; title: string; success: boolean; error?: string }[] = [];
  
  for (let i = 0; i < toProcess.length; i++) {
    const work = toProcess[i];
    const meeting = work.meeting;
    console.log(`[Backfill Background] Processing ${i + 1}/${toProcess.length}: ${meeting.title} (${work.type})`);
    
    try {
      const result = await processMeetingWithStatusUpdates(
        supabase, 
        supabaseUrl, 
        serviceRoleKey, 
        meeting,
        work.transcriptReviewId
      );
      results.push({ id: meeting.id, title: meeting.title, ...result });
      
      if (result.success) {
        console.log(`[Backfill Background] ✓ Successfully processed: ${meeting.title}`);
      } else {
        console.log(`[Backfill Background] ✗ Failed to process: ${meeting.title} - ${result.error}`);
      }
    } catch (error) {
      console.error(`[Backfill Background] Exception processing ${meeting.title}:`, error);
      results.push({ id: meeting.id, title: meeting.title, success: false, error: String(error) });
      
      await supabase
        .from('momentum_meetings')
        .update({ status: 'imported' })
        .eq('id', meeting.id);
    }
    
    // Delay between meetings
    if (i < toProcess.length - 1) {
      console.log(`[Backfill Background] Waiting 5 seconds before next item...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
  
  const successCount = results.filter(r => r.success).length;
  const failCount = results.filter(r => !r.success).length;
  console.log(`[Backfill Background] Completed processing. Success: ${successCount}, Failed: ${failCount}`);
  
  if (failCount > 0) {
    console.log('[Backfill Background] Failed items:', 
      results.filter(r => !r.success).map(r => ({ title: r.title, error: r.error }))
    );
  }
}

declare const EdgeRuntime: {
  waitUntil: (promise: Promise<void>) => void;
} | undefined;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    let body: { limit?: number; meetingIds?: string[] } = {};
    try {
      body = await req.json();
    } catch {
      // No body provided
    }

    const limit = body.limit || 20;
    const specificMeetingIds = body.meetingIds;

    let query = supabase
      .from('momentum_meetings')
      .select('id, momentum_id, title, start_time, transcript_content, matched_account_id')
      .eq('status', 'imported')
      .not('transcript_content', 'is', null)
      .not('matched_account_id', 'is', null);
    
    if (specificMeetingIds?.length) {
      query = query.in('id', specificMeetingIds);
    }
    
    const { data: candidateMeetings, error: meetingsError } = await query
      .order('imported_at', { ascending: false })
      .limit(100);

    if (meetingsError) throw meetingsError;

    const meetingsToProcess: MeetingData[] = [];
    const existingTranscriptsToReanalyze: { meeting: MeetingData; transcriptReviewId: string }[] = [];
    
    for (const meeting of candidateMeetings || []) {
      const { data: existing } = await supabase
        .from('transcript_reviews')
        .select('id, extracted_insights')
        .eq('file_name', `momentum_${meeting.momentum_id}`)
        .maybeSingle();

      if (!existing) {
        meetingsToProcess.push(meeting as MeetingData);
      } else if (existing.extracted_insights === null) {
        existingTranscriptsToReanalyze.push({
          meeting: meeting as MeetingData,
          transcriptReviewId: existing.id,
        });
      }
    }

    console.log(`[Backfill] Found ${meetingsToProcess.length} meetings without transcripts, ${existingTranscriptsToReanalyze.length} transcripts needing re-analysis`);

    const allWork: { type: string; meeting: MeetingData; transcriptReviewId: string | null }[] = [
      ...meetingsToProcess.map(m => ({ type: 'new', meeting: m, transcriptReviewId: null })),
      ...existingTranscriptsToReanalyze.map(e => ({ type: 'reanalyze', meeting: e.meeting, transcriptReviewId: e.transcriptReviewId })),
    ];

    if (allWork.length > 0) {
      const idsToProcess = allWork.slice(0, limit).map(w => w.meeting.id);
      await supabase
        .from('momentum_meetings')
        .update({ status: 'processing' })
        .in('id', idsToProcess);

      if (typeof EdgeRuntime !== 'undefined') {
        EdgeRuntime.waitUntil(
          runBackfillInBackground(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, allWork.slice(0, limit), limit)
        );
        
        return new Response(JSON.stringify({
          success: true,
          message: `Started background processing of ${Math.min(allWork.length, limit)} meetings`,
          queued: Math.min(allWork.length, limit),
          queuedIds: idsToProcess,
          totalFound: allWork.length,
          newTranscripts: meetingsToProcess.length,
          reanalyzing: existingTranscriptsToReanalyze.length,
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      } else {
        const results = [];
        for (const work of allWork.slice(0, 3)) {
          const result = await processMeetingWithStatusUpdates(
            supabase, 
            SUPABASE_URL, 
            SUPABASE_SERVICE_ROLE_KEY, 
            work.meeting,
            work.transcriptReviewId
          );
          results.push({ id: work.meeting.id, title: work.meeting.title, ...result });
        }
        
        return new Response(JSON.stringify({
          success: true,
          processed: results.length,
          remaining: allWork.length - results.length,
          results,
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    return new Response(JSON.stringify({
      success: true,
      message: 'No meetings need processing',
      processed: 0,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('[Backfill] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

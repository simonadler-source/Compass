import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const authHeader = req.headers.get("Authorization") || `Bearer ${supabaseKey}`;
    const apiKey = req.headers.get("apikey") || Deno.env.get("SUPABASE_ANON_KEY") || "";

    const body = await req.json().catch(() => ({}));
    const batchSize = body.batchSize || 10;
    const offset = body.offset || 0;

    // Fetch coaching scores to re-analyze
    const { data: existingScores, error } = await supabase
      .from("se_coaching_scores")
      .select("id, transcript_id, meeting_type, se_email, overall_score")
      .order("created_at", { ascending: true })
      .range(offset, offset + batchSize - 1);

    if (error) {
      return new Response(JSON.stringify({ error: "Failed to fetch scores", details: error.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!existingScores?.length) {
      return new Response(JSON.stringify({ message: "No more coaching scores to process", processed: 0 }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fire-and-forget: trigger all analyses without waiting for responses
    // This avoids edge function timeout since each AI call takes 30-60s
    const triggered: string[] = [];
    for (const score of existingScores) {
      console.log(`[Batch Coaching] Firing analysis for ${score.se_email} transcript ${score.transcript_id}`);
      
      fetch(`${supabaseUrl}/functions/v1/analyze-se-coaching`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": authHeader,
          "apikey": apiKey,
        },
        body: JSON.stringify({
          transcriptId: score.transcript_id,
          meetingType: score.meeting_type,
        }),
      }).catch(err => {
        console.error(`[Batch Coaching] Fire-and-forget error for ${score.transcript_id}:`, err);
      });

      triggered.push(score.transcript_id);
    }

    return new Response(JSON.stringify({
      message: `Triggered ${triggered.length} re-analyses (fire-and-forget). Check analyze-se-coaching logs for results.`,
      triggered: triggered.length,
      offset,
      nextOffset: offset + batchSize,
      transcriptIds: triggered,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("[Batch Coaching] Error:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

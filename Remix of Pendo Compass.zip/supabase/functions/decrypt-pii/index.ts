import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const data = encoder.encode(keyInput);
  const bytes = new Uint8Array(32);
  for (let i = 0; i < Math.min(data.length, 32); i++) {
    bytes[i] = data[i];
  }
  return bytes;
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

async function decrypt(ciphertext: string, ivBase64: string, keyInput: string): Promise<string> {
  const decoder = new TextDecoder();
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['decrypt']);
  const iv = base64ToBytes(ivBase64);
  const encryptedData = base64ToBytes(ciphertext);
  const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv.buffer as ArrayBuffer }, key, encryptedData.buffer as ArrayBuffer);
  return decoder.decode(decrypted);
}

// Map of table names to their IV field and encrypted field suffixes
const TABLE_CONFIG: Record<string, { ivField: string; encryptedSuffix: string }> = {
  momentum_meetings: { ivField: 'pii_encryption_iv', encryptedSuffix: '_encrypted' },
  account_contacts: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  profiles: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_team_members: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  opportunity_team_members: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_pain_points: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_use_cases: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_nbas: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_metrics: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_strategic_themes: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_exec_summaries: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  customer_stories: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  contact_meeting_snapshots: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_captured_insights: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  opportunity_milestones: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  opportunity_validation_tasks: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  opportunity_readiness_answers: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  competitor_scores: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  transcript_reviews: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  // Newly added tables
  detection_rule_matches: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  login_history: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  milestone_history: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_technologies: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_documents: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  competitors: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');

    if (!encryptionKey) throw new Error('TRANSCRIPT_ENCRYPTION_KEY not configured');

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { recordId, table, fields } = await req.json();

    if (!recordId || !table || !fields || !Array.isArray(fields)) {
      throw new Error('recordId, table, and fields array are required');
    }

    const config = TABLE_CONFIG[table];
    if (!config) {
      throw new Error(`Unknown table: ${table}`);
    }

    // Build select query for encrypted fields and IV
    const encryptedFieldNames = fields.map(f => `${f}${config.encryptedSuffix}`);
    const selectFields = ['id', config.ivField, 'is_encrypted', ...encryptedFieldNames].join(', ');

    console.log(`[decrypt-pii] Fetching ${table}:${recordId} fields: ${fields.join(', ')}`);

    const { data, error } = await supabase
      .from(table)
      .select(selectFields)
      .eq('id', recordId)
      .single();

    if (error) throw error;
    if (!data) throw new Error('Record not found');

    const record = data as unknown as Record<string, unknown>;
    const decrypted: Record<string, string | null> = {};

    if (!record.is_encrypted || !record[config.ivField]) {
      // Not encrypted, return empty (caller should use plaintext if available)
      console.log(`[decrypt-pii] Record ${table}:${recordId} is not encrypted`);
      for (const field of fields) {
        decrypted[field] = null;
      }
      return new Response(JSON.stringify({ success: true, decrypted, encrypted: false }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const iv = record[config.ivField] as string;

    for (const field of fields) {
      const encryptedField = `${field}${config.encryptedSuffix}`;
      const encryptedValue = record[encryptedField] as string | null;

      if (!encryptedValue) {
        decrypted[field] = null;
        continue;
      }

      try {
        decrypted[field] = await decrypt(encryptedValue, iv, encryptionKey);
      } catch (err) {
        console.error(`[decrypt-pii] Failed to decrypt ${field}:`, err);
        decrypted[field] = null;
      }
    }

    console.log(`[decrypt-pii] Successfully decrypted ${Object.keys(decrypted).length} fields for ${table}:${recordId}`);

    return new Response(JSON.stringify({ success: true, decrypted, encrypted: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    console.error('[decrypt-pii] Error:', message);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

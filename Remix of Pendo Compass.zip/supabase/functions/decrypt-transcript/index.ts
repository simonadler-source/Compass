import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ==================== ENCRYPTION HELPERS (same as api-gateway) ====================
// Primary key derivation - handles hex keys
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < Math.min(raw.length, 32); i++) key[i] = raw[i];
  return key;
}

// Legacy key derivation - always uses raw text (for backward compatibility)
function deriveKeyBytesLegacy(keyInput: string): Uint8Array {
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < Math.min(raw.length, 32); i++) key[i] = raw[i];
  return key;
}

// Some older utilities derived keys by hashing the input.
async function deriveKeyBytesHashed(keyInput: string): Promise<Uint8Array> {
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const digest = await crypto.subtle.digest('SHA-256', raw);
  return new Uint8Array(digest);
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function decrypt(ciphertext: string, ivBase64: string, keyInput: string): Promise<string | null> {
  try {
    const iv = base64ToBytes(ivBase64);
    const cipherBytes = base64ToBytes(ciphertext);

    const tryDecryptWith = async (keyBytes: Uint8Array) => {
      const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["decrypt"]);
      const plainBytes = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: iv.buffer as ArrayBuffer },
        key,
        cipherBytes.buffer as ArrayBuffer
      );
      return new TextDecoder().decode(plainBytes);
    };

    // Try current derivation, then legacy, then hashed (same order as api-gateway)
    try {
      return await tryDecryptWith(deriveKeyBytes(keyInput));
    } catch {
      try {
        return await tryDecryptWith(deriveKeyBytesLegacy(keyInput));
      } catch {
        try {
          return await tryDecryptWith(await deriveKeyBytesHashed(keyInput));
        } catch {
          return null;
        }
      }
    }
  } catch (e) {
    console.error(`[decrypt-transcript] Decrypt parsing error:`, e);
    return null;
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');
    const alternateKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE');

    if (!encryptionKey) {
      throw new Error('TRANSCRIPT_ENCRYPTION_KEY not configured');
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    const { transcriptId, table = 'transcript_reviews' } = await req.json();
    
    if (!transcriptId) {
      throw new Error('transcriptId is required');
    }

    console.log(`[decrypt-transcript] Decrypting ${table}:${transcriptId}`);
    
    let data: any;
    let error: any;
    
    if (table === 'transcript_reviews') {
      // For transcript_reviews, check if there's a linked momentum_meeting
      const result = await supabase
        .from('transcript_reviews')
        .select(`
          transcript_content, 
          transcript_content_encrypted, 
          encryption_iv, 
          is_encrypted,
          momentum_meeting_id,
          momentum_meetings (
            transcript_content,
            transcript_content_encrypted,
            pii_encryption_iv,
            is_encrypted
          )
        `)
        .eq('id', transcriptId)
        .single();
      
      data = result.data;
      error = result.error;
      
      // If linked to momentum_meeting and no local content, use momentum_meeting content
      if (data?.momentum_meeting_id && data?.momentum_meetings && 
          !data.transcript_content && !data.transcript_content_encrypted) {
        console.log(`[decrypt-transcript] Following link to momentum_meeting ${data.momentum_meeting_id}`);
        data = {
          transcript_content: data.momentum_meetings.transcript_content,
          transcript_content_encrypted: data.momentum_meetings.transcript_content_encrypted,
          encryption_iv: data.momentum_meetings.pii_encryption_iv,
          is_encrypted: data.momentum_meetings.is_encrypted,
        };
      }
    } else {
      // For other tables (momentum_meetings), fetch directly
      const ivField = table === 'momentum_meetings' ? 'pii_encryption_iv' : 'encryption_iv';
      const isEncryptedField = 'is_encrypted';
      
      const result = await supabase
        .from(table)
        .select(`transcript_content, transcript_content_encrypted, ${ivField}, ${isEncryptedField}`)
        .eq('id', transcriptId)
        .single();
      
      data = result.data;
      error = result.error;
      
      // Normalize field names for momentum_meetings
      if (data && table === 'momentum_meetings') {
        data.encryption_iv = data.pii_encryption_iv;
      }
    }
    
    if (error) {
      console.error(`[decrypt-transcript] DB error: ${error.message}`);
      throw new Error(`Database error: ${error.message}`);
    }
    if (!data) {
      throw new Error('Record not found');
    }
    
    let content: string | null = null;
    
    if (data.is_encrypted && data.transcript_content_encrypted && data.encryption_iv) {
      // Try primary key first
      content = await decrypt(data.transcript_content_encrypted, data.encryption_iv, encryptionKey);
      
      // If primary failed and alternate exists, try alternate
      if (content === null && alternateKey) {
        console.log(`[decrypt-transcript] Primary key failed, trying alternate key`);
        content = await decrypt(data.transcript_content_encrypted, data.encryption_iv, alternateKey);
      }
      
      if (content !== null) {
        console.log(`[decrypt-transcript] Successfully decrypted ${table}:${transcriptId}`);
      } else {
        console.error(`[decrypt-transcript] All decryption methods failed for ${table}:${transcriptId}`);
        throw new Error('Decryption failed with all available keys');
      }
    } else if (data.transcript_content) {
      // Return plaintext if not encrypted
      content = data.transcript_content;
      console.log(`[decrypt-transcript] Returning plaintext for ${table}:${transcriptId}`);
    } else {
      console.error(`[decrypt-transcript] No content: is_encrypted=${data.is_encrypted}, has_encrypted=${!!data.transcript_content_encrypted}, has_iv=${!!data.encryption_iv}`);
      throw new Error('No transcript content found');
    }
    
    return new Response(JSON.stringify({ 
      success: true,
      content,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
    
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    console.error('[decrypt-transcript] Error:', message);
    return new Response(JSON.stringify({ 
      success: false,
      error: message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

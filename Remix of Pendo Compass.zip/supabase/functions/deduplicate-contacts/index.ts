import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Levenshtein distance for fuzzy name matching
function levenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];
  const aLen = a.length;
  const bLen = b.length;
  
  if (aLen === 0) return bLen;
  if (bLen === 0) return aLen;

  for (let i = 0; i <= bLen; i++) matrix[i] = [i];
  for (let j = 0; j <= aLen; j++) matrix[0][j] = j;

  for (let i = 1; i <= bLen; i++) {
    for (let j = 1; j <= aLen; j++) {
      const cost = a[j - 1] === b[i - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost
      );
    }
  }
  return matrix[bLen][aLen];
}

function normalizeString(s: string): string {
  return s.toLowerCase().trim().replace(/[^a-z0-9]/g, '');
}

function findDuplicates(contacts: any[]): Map<string, any[]> {
  const groups = new Map<string, any[]>();
  const processed = new Set<string>();

  for (const contact of contacts) {
    if (processed.has(contact.id)) continue;
    
    const group = [contact];
    processed.add(contact.id);
    
    for (const other of contacts) {
      if (processed.has(other.id)) continue;
      
      // Check email match first
      if (contact.email && other.email && 
          contact.email.toLowerCase() === other.email.toLowerCase()) {
        group.push(other);
        processed.add(other.id);
        continue;
      }
      
      // Fuzzy name match
      const name1 = normalizeString(contact.name || '');
      const name2 = normalizeString(other.name || '');
      
      if (!name1 || !name2) continue;
      
      // Check if one is prefix of other (e.g., "Ruba" vs "Ruba Zarour")
      if (name1.startsWith(name2) || name2.startsWith(name1)) {
        group.push(other);
        processed.add(other.id);
        continue;
      }
      
      // Levenshtein similarity
      const distance = levenshteinDistance(name1, name2);
      const maxLen = Math.max(name1.length, name2.length);
      const similarity = 1 - (distance / maxLen);
      
      if (similarity > 0.8) {
        group.push(other);
        processed.add(other.id);
      }
    }
    
    if (group.length > 1) {
      groups.set(contact.id, group);
    }
  }
  
  return groups;
}

function selectBestRecord(group: any[]): { keep: any; merge: any[] } {
  // Sort by completeness: prefer records with the most data
  const sorted = [...group].sort((a, b) => {
    let scoreA = 0, scoreB = 0;
    
    // Core identity fields (highest priority)
    if (a.email && a.email.trim()) scoreA += 20;
    if (b.email && b.email.trim()) scoreB += 20;
    
    // Name completeness (longer = more complete, likely full name)
    if (a.name) scoreA += Math.min(a.name.length * 2, 30); // Cap at 30
    if (b.name) scoreB += Math.min(b.name.length * 2, 30);
    
    // Role/title (important context)
    if (a.role && a.role.trim()) scoreA += 15;
    if (b.role && b.role.trim()) scoreB += 15;
    
    // Phone number
    if (a.phone && a.phone.trim()) scoreA += 10;
    if (b.phone && b.phone.trim()) scoreB += 10;
    
    // Assessment scores (prefer records with actual assessments)
    if (a.influence_level != null && a.influence_level > 0) scoreA += 8;
    if (b.influence_level != null && b.influence_level > 0) scoreB += 8;
    if (a.sentiment != null && a.sentiment > 0) scoreA += 8;
    if (b.sentiment != null && b.sentiment > 0) scoreB += 8;
    if (a.champion_score != null && a.champion_score > 0) scoreA += 8;
    if (b.champion_score != null && b.champion_score > 0) scoreB += 8;
    
    // Stakeholder type classification
    if (a.stakeholder_type && a.stakeholder_type !== 'unknown') scoreA += 10;
    if (b.stakeholder_type && b.stakeholder_type !== 'unknown') scoreB += 10;
    
    // Notes (valuable context)
    if (a.notes && a.notes.trim()) scoreA += 5;
    if (b.notes && b.notes.trim()) scoreB += 5;
    
    // Prefer records with advocacy/info sharing signals
    if (a.advocacy_signals && Object.keys(a.advocacy_signals).length > 0) scoreA += 5;
    if (b.advocacy_signals && Object.keys(b.advocacy_signals).length > 0) scoreB += 5;
    if (a.info_sharing_signals && Object.keys(a.info_sharing_signals).length > 0) scoreA += 5;
    if (b.info_sharing_signals && Object.keys(b.info_sharing_signals).length > 0) scoreB += 5;
    
    // Prefer manually sourced over AI-extracted (often more accurate)
    if (a.source === 'manual') scoreA += 3;
    if (b.source === 'manual') scoreB += 3;
    
    return scoreB - scoreA; // Higher score = better record
  });
  
  return { keep: sorted[0], merge: sorted.slice(1) };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { account_id, contact_ids, dry_run = true, generate_snapshots = false } = await req.json();
    
    if (!account_id) {
      return new Response(JSON.stringify({ error: "account_id required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const encryptionKey =
      Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") ??
      Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE");

    if (!encryptionKey) {
      throw new Error("TRANSCRIPT_ENCRYPTION_KEY not configured");
    }
    const supabase = createClient(supabaseUrl, serviceKey);
    
    // Fetch contacts with decryption - if specific IDs provided, only fetch those
    let query = supabase.from('account_contacts').select('*').eq('account_id', account_id);
    
    if (contact_ids && Array.isArray(contact_ids) && contact_ids.length > 0) {
      query = query.in('id', contact_ids);
    }
    
    const { data: contacts, error: fetchError } = await query;
    
    if (fetchError) throw fetchError;
    
    // Decrypt fields for matching (account_contacts stores PII only in *_encrypted columns)
    const decryptedContacts = await Promise.all(
      contacts.map(async (c) => {
        let name = '';
        let email = '';
        let role = '';

        if (c.is_encrypted && c.encryption_iv) {
          try {
            if (c.name_encrypted) {
              name = await decryptField(c.name_encrypted, c.encryption_iv, encryptionKey);
            }
            if (c.email_encrypted) {
              email = await decryptField(c.email_encrypted, c.encryption_iv, encryptionKey);
            }
            if (c.role_encrypted) {
              role = await decryptField(c.role_encrypted, c.encryption_iv, encryptionKey);
            }
          } catch (e) {
            console.error('Decryption error for contact', c.id, e);
          }
        }

      return { ...c, name, email, role };
      })
    );
    
    // If specific contact_ids were provided, treat them as a single group to merge
    // Otherwise, use automatic duplicate detection
    let duplicateGroups: Map<string, any[]>;
    
    if (contact_ids && Array.isArray(contact_ids) && contact_ids.length >= 2) {
      // Manual merge: treat all provided contacts as one group
      duplicateGroups = new Map();
      duplicateGroups.set(decryptedContacts[0]?.id || 'manual', decryptedContacts);
    } else {
      // Automatic detection
      duplicateGroups = findDuplicates(decryptedContacts);
    }
    
    const report = {
      account_id,
      total_contacts: contacts.length,
      duplicate_groups: duplicateGroups.size,
      groups: [] as any[],
      actions_taken: [] as string[],
    };
    
    for (const [_, group] of duplicateGroups) {
      const { keep, merge } = selectBestRecord(group);
      report.groups.push({
        keep: { id: keep.id, name: keep.name, email: keep.email },
        merge: merge.map((m: any) => ({ id: m.id, name: m.name, email: m.email })),
      });
      
      if (!dry_run) {
        const mergeIds = merge.map((m: any) => m.id);

        // 1) Re-point dependent records so we can safely delete duplicates
        const snapshotsUpdate = await supabase
          .from('contact_meeting_snapshots')
          .update({ contact_id: keep.id })
          .in('contact_id', mergeIds);
        if (snapshotsUpdate.error) throw snapshotsUpdate.error;

        const insightsUpdate = await supabase
          .from('account_insight_snapshots')
          .update({ contact_id: keep.id })
          .in('contact_id', mergeIds);
        if (insightsUpdate.error) throw insightsUpdate.error;

        const historyUpdate = await supabase
          .from('stakeholder_history')
          .update({ contact_id: keep.id })
          .in('contact_id', mergeIds);
        if (historyUpdate.error) throw historyUpdate.error;

        // 2) Merge ALL fields into keep record - combine best data from all records
        const allRecords = [keep, ...merge];
        
        // Helper to get the best non-empty value from all records
        const getBestValue = (field: string) => {
          for (const rec of allRecords) {
            if (rec[field] && (typeof rec[field] !== 'string' || rec[field].trim())) {
              return rec[field];
            }
          }
          return null;
        };
        
        // Helper to get max numeric value (only if > 0)
        const getMaxValue = (field: string) => {
          const values = allRecords.map((r: any) => r[field] || 0).filter((v: number) => v > 0);
          return values.length > 0 ? Math.max(...values) : null;
        };
        
        // Helper to get best stakeholder type (prefer non-unknown)
        const getBestStakeholderType = () => {
          for (const rec of allRecords) {
            if (rec.stakeholder_type && rec.stakeholder_type !== 'unknown') {
              return rec.stakeholder_type;
            }
          }
          return keep.stakeholder_type || 'unknown';
        };
        
        // Helper to concatenate all unique notes from all records
        const mergeNotes = () => {
          const allNotes = allRecords
            .map((r: any) => r.notes?.trim())
            .filter((n: string | undefined) => n && n.length > 0);
          // Dedupe notes that are identical
          const uniqueNotes = [...new Set(allNotes)];
          return uniqueNotes.length > 0 ? uniqueNotes.join('\n---\n') : null;
        };
        
        // Helper to get longest/most complete string (for names)
        const getLongestString = (field: string) => {
          const values = allRecords
            .map((r: any) => r[field]?.trim())
            .filter((v: string | undefined) => v && v.length > 0);
          if (values.length === 0) return null;
          return values.sort((a: string, b: string) => b.length - a.length)[0];
        };
        
        const mergedData: any = {
          // Numeric scores: use max value to preserve highest assessments
          influence_level: getMaxValue('influence_level'),
          sentiment: getMaxValue('sentiment'),
          champion_score: getMaxValue('champion_score'),
          
          // Stakeholder classification: prefer non-unknown
          stakeholder_type: getBestStakeholderType(),
          
          // Opportunity: prefer existing link
          opportunity_id: getBestValue('opportunity_id'),
          
          // Source: prefer manual over AI-extracted
          source: allRecords.some((r: any) => r.source === 'manual') ? 'manual' : getBestValue('source'),
          
          // Advocacy/info signals: merge ALL objects to preserve every signal
          advocacy_signals: allRecords.reduce((acc: any, rec: any) => {
            if (rec.advocacy_signals && typeof rec.advocacy_signals === 'object') {
              return { ...acc, ...rec.advocacy_signals };
            }
            return acc;
          }, {}),
          info_sharing_signals: allRecords.reduce((acc: any, rec: any) => {
            if (rec.info_sharing_signals && typeof rec.info_sharing_signals === 'object') {
              return { ...acc, ...rec.info_sharing_signals };
            }
            return acc;
          }, {}),
          
          // Assessment metadata: prefer most recent
          last_assessed_at: allRecords
            .filter((r: any) => r.last_assessed_at)
            .sort((a: any, b: any) => new Date(b.last_assessed_at).getTime() - new Date(a.last_assessed_at).getTime())[0]?.last_assessed_at || null,
        };
        
        // Handle encrypted PII fields separately - need to encrypt best values
        const bestName = getLongestString('name');
        const bestEmail = getBestValue('email');
        const bestPhone = getBestValue('phone');
        const bestRole = getLongestString('role');
        const mergedNotes = mergeNotes();
        
        // Check if any PII field from non-primary records is better than keep's
        const needsPiiUpdate = 
          (bestName && bestName !== keep.name) ||
          (bestEmail && bestEmail !== keep.email) ||
          (bestPhone && bestPhone !== keep.phone) ||
          (bestRole && bestRole !== keep.role) ||
          (mergedNotes && mergedNotes !== keep.notes);
        
        if (needsPiiUpdate) {
          // Generate new IV for encryption
          const iv = crypto.getRandomValues(new Uint8Array(12));
          const ivBase64 = btoa(String.fromCharCode(...iv));
          
          const encryptedPii: any = {
            encryption_iv: ivBase64,
            is_encrypted: true,
          };
          
          if (bestName) {
            encryptedPii.name_encrypted = await encryptField(bestName, ivBase64, encryptionKey);
          }
          if (bestEmail) {
            encryptedPii.email_encrypted = await encryptField(bestEmail, ivBase64, encryptionKey);
          }
          if (bestPhone) {
            encryptedPii.phone_encrypted = await encryptField(bestPhone, ivBase64, encryptionKey);
          }
          if (bestRole) {
            encryptedPii.role_encrypted = await encryptField(bestRole, ivBase64, encryptionKey);
          }
          if (mergedNotes) {
            encryptedPii.notes_encrypted = await encryptField(mergedNotes, ivBase64, encryptionKey);
          }
          
          Object.assign(mergedData, encryptedPii);
        }
        
        // Remove null values to avoid overwriting existing data with nulls
        Object.keys(mergedData).forEach(key => {
          if (mergedData[key] === null) delete mergedData[key];
        });

        const keepUpdate = await supabase.from('account_contacts').update(mergedData).eq('id', keep.id);
        if (keepUpdate.error) throw keepUpdate.error;

        // 3) Delete merged records
        for (const m of merge) {
          const del = await supabase.from('account_contacts').delete().eq('id', m.id);
          if (del.error) throw del.error;
          report.actions_taken.push(`Deleted duplicate: ${m.name} (${m.id})`);
        }

        report.actions_taken.push(`Kept: ${keep.name} (merged ${merge.length} duplicates)`);
      }
    }
    
    // Generate mock snapshots for testing sparklines
    if (generate_snapshots && !dry_run) {
      const remainingContacts = dry_run ? decryptedContacts : 
        decryptedContacts.filter(c => !Array.from(duplicateGroups.values()).flat().find((m: any) => m.id === c.id && m.id !== duplicateGroups.get(c.id)?.[0]?.id));
      
      // Get transcripts for this account to link snapshots
      const { data: transcripts } = await supabase
        .from('transcript_reviews')
        .select('id, meeting_date')
        .eq('account_id', account_id)
        .order('meeting_date', { ascending: true })
        .limit(10);
      
      if (transcripts && transcripts.length > 0) {
        for (const contact of decryptedContacts.slice(0, 5)) {
          // Generate 3-5 snapshots per contact with varying scores
          const numSnapshots = Math.min(transcripts.length, Math.floor(Math.random() * 3) + 2);
          
          for (let i = 0; i < numSnapshots; i++) {
            const transcript = transcripts[i % transcripts.length];
            const baseInfluence = 30 + Math.random() * 40;
            const baseSentiment = 40 + Math.random() * 30;
            const baseChampion = 20 + Math.random() * 50;
            
            // Add some trend (scores increase over time)
            const trend = i * 5;
            
            await supabase
              .from('contact_meeting_snapshots')
              .upsert({
                contact_id: contact.id,
                transcript_id: transcript.id,
                meeting_date: transcript.meeting_date,
                meeting_type: ['discovery', 'demo', 'technical'][i % 3],
                influence_level: Math.min(100, Math.round(baseInfluence + trend)),
                sentiment: Math.min(100, Math.round(baseSentiment + trend)),
                champion_score: Math.min(100, Math.round(baseChampion + trend)),
                engagement_score: Math.round(50 + Math.random() * 30),
              }, { onConflict: 'contact_id,transcript_id' });
          }
          report.actions_taken.push(`Generated ${numSnapshots} snapshots for ${contact.name}`);
        }
      }
    }

    return new Response(JSON.stringify(report), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: unknown) {
    console.error("Error:", error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

function deriveKeyBytes(keyInput: string): Uint8Array {
  // Accept either a 32-byte hex key or an arbitrary passphrase
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const data = encoder.encode(keyInput);
  const bytes = new Uint8Array(32);
  for (let i = 0; i < Math.min(data.length, 32); i++) {
    bytes[i] = data[i];
  }
  return bytes;
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function decryptField(ciphertextBase64: string, ivBase64: string, keyInput: string): Promise<string> {
  try {
    const keyBytes = deriveKeyBytes(keyInput);
    const key = await crypto.subtle.importKey(
      'raw',
      keyBytes.buffer as ArrayBuffer,
      { name: 'AES-GCM' },
      false,
      ['decrypt']
    );

    const iv = base64ToBytes(ivBase64);
    const encrypted = base64ToBytes(ciphertextBase64);

    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: iv.buffer as ArrayBuffer },
      key,
      encrypted.buffer as ArrayBuffer
    );
    return new TextDecoder().decode(decrypted);
  } catch (e) {
    console.error('Decryption failed:', e);
    return '';
  }
}

async function encryptField(plaintext: string, ivBase64: string, keyInput: string): Promise<string> {
  try {
    const keyBytes = deriveKeyBytes(keyInput);
    const key = await crypto.subtle.importKey(
      'raw',
      keyBytes.buffer as ArrayBuffer,
      { name: 'AES-GCM' },
      false,
      ['encrypt']
    );

    const iv = base64ToBytes(ivBase64);
    const encoded = new TextEncoder().encode(plaintext);

    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv: iv.buffer as ArrayBuffer },
      key,
      encoded.buffer as ArrayBuffer
    );
    
    // Convert to base64
    const bytes = new Uint8Array(encrypted);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  } catch (e) {
    console.error('Encryption failed:', e);
    return '';
  }
}
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { getAIConfig } from '../_shared/ai-provider.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Encryption helpers
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]{64}$/.test(keyInput)) {
    const arr = new Uint8Array(32);
    for (let i = 0; i < 32; i++) {
      arr[i] = parseInt(keyInput.slice(i * 2, i * 2 + 2), 16);
    }
    return arr;
  }
  const encoder = new TextEncoder();
  const keyBytes = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < key.length; i++) {
    key[i] = keyBytes[i % keyBytes.length];
  }
  return key;
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

async function decrypt(ciphertext: string, ivBase64: string, keyInput: string): Promise<string> {
  try {
    const keyBytes = deriveKeyBytes(keyInput);
    const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['decrypt']);
    const iv = base64ToBytes(ivBase64);
    const encryptedData = base64ToBytes(ciphertext);
    const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv.buffer as ArrayBuffer }, key, encryptedData.buffer as ArrayBuffer);
    return new TextDecoder().decode(decrypted);
  } catch (_e) {
    return '';
  }
}

interface NBA {
  id: string;
  action: string | null;
  account_id: string;
  opportunity_id: string | null;
  status: string;
  created_at: string;
  source_transcript_id: string | null;
  action_type: string;
  due_date: string | null;
}

interface DuplicateGroup {
  keepId: string;
  removeIds: string[];
  reason: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY') || '';

    const body = await req.json().catch(() => ({}));
    const { 
      accountId, 
      opportunityId,
      dryRun = true,
      keepStrategy = 'oldest',
      bulkAll = false,
      staleDays = 60,
      autoCompleteStale = true,
      deduplicateNBAs = true,
    } = body;

    console.log(`NBA cleanup: dryRun=${dryRun}, bulkAll=${bulkAll}, staleDays=${staleDays}, autoCompleteStale=${autoCompleteStale}, dedup=${deduplicateNBAs}`);

    const results = {
      staleCompleted: 0,
      staleCandidates: 0,
      duplicatesRemoved: 0,
      duplicateCandidates: 0,
      accountsProcessed: 0,
      errors: [] as string[],
      duplicateGroups: [] as any[],
      staleItems: [] as any[],
    };

    // ---- STEP 1: Auto-complete stale NBAs (by age OR overdue) ----
    if (autoCompleteStale) {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - staleDays);
      const cutoffISO = cutoffDate.toISOString();

      // Also auto-cancel NBAs with due_date more than 14 days in the past
      const overdueCutoff = new Date();
      overdueCutoff.setDate(overdueCutoff.getDate() - 14);
      const overdueCutoffISO = overdueCutoff.toISOString().split('T')[0]; // date only for due_date comparison

      // Fetch stale by creation date
      let staleQuery = supabase
        .from('account_nbas')
        .select('id, action, action_encrypted, encryption_iv, is_encrypted, account_id, status, created_at, action_type, due_date')
        .eq('status', 'pending')
        .lt('created_at', cutoffISO)
        .order('created_at', { ascending: true })
        .limit(1000);

      if (accountId && !bulkAll) {
        staleQuery = staleQuery.eq('account_id', accountId);
      }
      if (opportunityId) {
        staleQuery = staleQuery.eq('opportunity_id', opportunityId);
      }

      const { data: staleNBAs, error: staleError } = await staleQuery;

      // Fetch overdue NBAs (due_date < 14 days ago)
      let overdueQuery = supabase
        .from('account_nbas')
        .select('id, action, action_encrypted, encryption_iv, is_encrypted, account_id, status, created_at, action_type, due_date')
        .eq('status', 'pending')
        .not('due_date', 'is', null)
        .lt('due_date', overdueCutoffISO)
        .order('due_date', { ascending: true })
        .limit(500);

      if (accountId && !bulkAll) {
        overdueQuery = overdueQuery.eq('account_id', accountId);
      }
      if (opportunityId) {
        overdueQuery = overdueQuery.eq('opportunity_id', opportunityId);
      }

      const { data: overdueNBAs } = await overdueQuery;

      // Merge and deduplicate by ID
      const allStaleIds = new Set<string>();
      const combinedStale: any[] = [];
      
      for (const nba of [...(staleNBAs || []), ...(overdueNBAs || [])]) {
        if (!allStaleIds.has(nba.id)) {
          allStaleIds.add(nba.id);
          combinedStale.push(nba);
        }
      }

      if (staleError) {
        results.errors.push(`Stale fetch error: ${staleError.message}`);
      }
      
      if (combinedStale.length > 0) {
        results.staleCandidates = combinedStale.length;
        console.log(`Found ${staleNBAs?.length || 0} age-stale + ${overdueNBAs?.length || 0} overdue NBAs (${combinedStale.length} unique)`);

        // Decrypt for reporting
        const staleDecrypted = [];
        for (const raw of combinedStale.slice(0, 20)) {
          let actionText = raw.action;
          if (raw.is_encrypted && raw.action_encrypted && raw.encryption_iv && encryptionKey) {
            const decrypted = await decrypt(raw.action_encrypted, raw.encryption_iv, encryptionKey);
            if (decrypted) actionText = decrypted;
          }
          staleDecrypted.push({ id: raw.id, action: actionText, created_at: raw.created_at, due_date: raw.due_date, account_id: raw.account_id });
        }

        results.staleItems = staleDecrypted;

        if (!dryRun) {
          const staleIds = combinedStale.map(n => n.id);
          // Process in batches of 100 to avoid query size limits
          for (let i = 0; i < staleIds.length; i += 100) {
            const batch = staleIds.slice(i, i + 100);
            const { error: updateError } = await supabase
              .from('account_nbas')
              .update({ status: 'cancelled' })
              .in('id', batch);

            if (updateError) {
              results.errors.push(`Stale update error: ${updateError.message}`);
            } else {
              results.staleCompleted += batch.length;
            }
          }
        }
      }
      console.log(`Stale/overdue NBAs: ${results.staleCandidates} found`);
    }

    // ---- STEP 2: AI-powered deduplication ----
    if (deduplicateNBAs) {
      let accountIds: string[] = [];
      const countMap = new Map<string, number>();

      if (bulkAll) {
        // Get distinct account_ids that have >1 pending NBA
        const { data: rawAccounts } = await supabase
          .from('account_nbas')
          .select('account_id')
          .in('status', ['pending', 'in_progress'])
          .limit(2000);

        for (const row of rawAccounts || []) {
          countMap.set(row.account_id, (countMap.get(row.account_id) || 0) + 1);
        }
        accountIds = [...countMap.entries()]
          .filter(([_, c]) => c > 1)
          .sort((a, b) => b[1] - a[1])
          .map(([id]) => id);
      } else if (accountId) {
        accountIds = [accountId];
      }

      console.log(`Deduplicating NBAs across ${accountIds.length} accounts`);

      if (dryRun) {
        // For dry run, skip AI calls entirely - just estimate counts for speed
        results.accountsProcessed = accountIds.length;
        for (const accId of accountIds) {
          const c = countMap.get(accId) || 0;
          results.duplicateCandidates += Math.max(0, c - 1);
        }
        console.log(`Dry run: estimated ${results.duplicateCandidates} potential duplicates across ${accountIds.length} accounts`);
      } else {
        // Execute mode: use AI to find real duplicates (limit accounts per run)
        const maxAccountsPerRun = bulkAll ? 5 : 1;
        const accountsToProcess = accountIds.slice(0, maxAccountsPerRun);

        for (const accId of accountsToProcess) {
          try {
            let query = supabase
              .from('account_nbas')
              .select('id, action, action_encrypted, encryption_iv, is_encrypted, account_id, opportunity_id, status, created_at, source_transcript_id, action_type, due_date')
              .in('status', ['pending', 'in_progress'])
              .eq('account_id', accId)
              .order('created_at', { ascending: true })
              .limit(100);

            if (opportunityId) {
              query = query.eq('opportunity_id', opportunityId);
            }

            const { data: rawNbas, error: fetchError } = await query;
            if (fetchError || !rawNbas || rawNbas.length < 2) continue;

            const nbas: NBA[] = [];
            for (const raw of rawNbas) {
              let actionText = raw.action;
              if (raw.is_encrypted && raw.action_encrypted && raw.encryption_iv && encryptionKey) {
                const decrypted = await decrypt(raw.action_encrypted, raw.encryption_iv, encryptionKey);
                if (decrypted) actionText = decrypted;
              }
              nbas.push({
                id: raw.id, action: actionText, account_id: raw.account_id,
                opportunity_id: raw.opportunity_id, status: raw.status,
                created_at: raw.created_at, source_transcript_id: raw.source_transcript_id,
                action_type: raw.action_type || 'unknown', due_date: raw.due_date,
              });
            }

            const validNbas = nbas.filter(n => n.action && n.action.trim().length > 0);
            if (validNbas.length < 2) continue;

            const nbaList = validNbas.map((n, idx) => ({
              index: idx, id: n.id, action: n.action, status: n.status,
              action_type: n.action_type, created_at: n.created_at,
            }));

            const aiConfig = await getAIConfig('standard');

            const systemPrompt = `You are an expert at identifying duplicate or semantically equivalent action items. Given a list of NBAs, identify groups of duplicates. Keep strategy: "${keepStrategy}". Only group actions that are truly the same intent.`;

            const llmResponse = await fetch(aiConfig.endpoint, {
              method: 'POST',
              headers: { 'Authorization': `Bearer ${aiConfig.apiKey}`, 'Content-Type': 'application/json' },
              body: JSON.stringify({
                model: aiConfig.model,
                messages: [
                  { role: 'system', content: systemPrompt },
                  { role: 'user', content: `Analyze these ${nbaList.length} NBAs:\n${JSON.stringify(nbaList, null, 2)}\nUse identify_duplicates tool.` },
                ],
                tools: [{ type: 'function', function: {
                  name: 'identify_duplicates', description: 'Identify duplicate NBA groups',
                  parameters: { type: 'object', properties: {
                    duplicate_groups: { type: 'array', items: { type: 'object', properties: {
                      keep_index: { type: 'number' }, remove_indices: { type: 'array', items: { type: 'number' } },
                      reason: { type: 'string' },
                    }, required: ['keep_index', 'remove_indices', 'reason'] } },
                  }, required: ['duplicate_groups'] },
                }}],
                tool_choice: { type: 'function', function: { name: 'identify_duplicates' } },
              }),
            });

            if (!llmResponse.ok) {
              if (llmResponse.status === 429 || llmResponse.status === 402) {
                results.errors.push(`AI rate/credit limit hit - stopping dedup`);
                break;
              }
              continue;
            }

            const llmData = await llmResponse.json();
            const toolCall = llmData.choices?.[0]?.message?.tool_calls?.[0];
            if (!toolCall || toolCall.function.name !== 'identify_duplicates') continue;

            const analysis = JSON.parse(toolCall.function.arguments);

            for (const group of analysis.duplicate_groups || []) {
              const keepNba = nbaList[group.keep_index];
              const removeNbas = group.remove_indices.map((idx: number) => nbaList[idx]).filter(Boolean);
              if (keepNba && removeNbas.length > 0) {
                const allRemoveIds = removeNbas.map((n: any) => n.id);
                const { error: deleteError, count } = await supabase
                  .from('account_nbas').delete({ count: 'exact' }).in('id', allRemoveIds);
                if (deleteError) {
                  results.errors.push(`Delete error (${accId}): ${deleteError.message}`);
                } else {
                  results.duplicatesRemoved += count || allRemoveIds.length;
                }
                results.duplicateGroups.push({
                  keep: { id: keepNba.id, action: keepNba.action, status: keepNba.status },
                  remove: removeNbas.map((n: any) => ({ id: n.id, action: n.action, status: n.status })),
                  reason: group.reason,
                });
              }
            }
            results.accountsProcessed++;
          } catch (accError: any) {
            results.errors.push(`Account ${accId}: ${accError.message}`);
          }
        }

        if (accountIds.length > (bulkAll ? 5 : 1)) {
          results.errors.push(`Processed ${Math.min(bulkAll ? 5 : 1, accountIds.length)} of ${accountIds.length} accounts. Run again for more.`);
        }
      }
    }

    const summary = dryRun
      ? `Dry run: ${results.staleCandidates} stale NBAs to cancel, ${results.duplicateCandidates} duplicates to remove across ${results.accountsProcessed} accounts`
      : `Cleaned up: ${results.staleCompleted} stale NBAs cancelled, ${results.duplicatesRemoved} duplicates removed across ${results.accountsProcessed} accounts`;

    console.log(summary);

    return new Response(JSON.stringify({
      success: true,
      dryRun,
      message: summary,
      stats: {
        staleCandidates: results.staleCandidates,
        staleCompleted: results.staleCompleted,
        duplicateCandidates: results.duplicateCandidates,
        duplicatesRemoved: results.duplicatesRemoved,
        accountsProcessed: results.accountsProcessed,
      },
      duplicateGroups: results.duplicateGroups.slice(0, 50),
      staleItems: results.staleItems,
      errors: results.errors,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in deduplicate-nbas:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation schema - action can be null if encrypted data wasn't decrypted
const NBASchema = z.object({
  id: z.string().min(1).max(100),
  action: z.string().max(2000).nullable().optional(),
  action_type: z.string().max(100),
  notes: z.string().max(5000).nullable().optional(),
});

const DetectNbaCompletionInputSchema = z.object({
  transcript_content: z.string().min(1, "Transcript content is required").max(500000, "Transcript too long (max 500k chars)"),
  nbas: z.array(NBASchema).min(1, "At least one NBA is required").max(200),
  account_name: z.string().max(500).optional(),
});

interface NBA {
  id: string;
  action?: string | null;
  action_type: string;
  notes?: string | null;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const rawBody = await req.json();

    // Validate input with zod
    const parseResult = DetectNbaCompletionInputSchema.safeParse(rawBody);
    if (!parseResult.success) {
      console.error("Input validation failed:", parseResult.error.errors);
      return new Response(
        JSON.stringify({ 
          error: "Invalid input", 
          details: parseResult.error.errors.map(e => `${e.path.join('.')}: ${e.message}`)
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { transcript_content, nbas, account_name } = parseResult.data;

    // Filter out NBAs without a valid action (e.g., encrypted but not decrypted)
    const validNbas = nbas.filter((nba): nba is NBA & { action: string } => 
      typeof nba.action === 'string' && nba.action.length > 0
    );

    if (validNbas.length === 0) {
      console.log('No NBAs with valid action text to analyze');
      return new Response(
        JSON.stringify({ completions: [] }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get AI configuration (provider-agnostic)
    const aiConfig = await getAIConfig();
    console.log(`Using AI provider at: ${aiConfig.endpoint}`);

    const nbaList = validNbas.map((nba, i: number) => 
      `${i + 1}. [ID: ${nba.id}] ${nba.action} (Type: ${nba.action_type})`
    ).join("\n");

    const systemPrompt = `You are an AI assistant that analyzes meeting transcripts to detect if Next Best Actions (NBAs) have been addressed or completed.

For each NBA, determine if the transcript shows evidence that:
1. The topic was discussed
2. The question was asked and answered
3. The action was taken or agreed upon
4. Information was gathered that addresses the NBA

Return your analysis as a JSON array using the suggest_completions function.`;

    const userPrompt = `Account: ${account_name || 'Unknown'}

Pending NBAs to check:
${nbaList}

Transcript content:
${transcript_content.substring(0, 15000)}

Analyze the transcript and identify which NBAs appear to have been addressed. For each completed NBA, provide a confidence score (0.0-1.0) and explanation.`;

    const response = await fetch(aiConfig.endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${aiConfig.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: aiConfig.model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "suggest_completions",
              description: "Return NBAs that appear to have been addressed in the transcript",
              parameters: {
                type: "object",
                properties: {
                  completions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        nba_id: { type: "string", description: "The ID of the NBA" },
                        confidence: { type: "number", description: "Confidence score 0.0-1.0" },
                        reason: { type: "string", description: "Brief explanation of why this NBA appears completed" },
                        evidence: { type: "string", description: "Quote or paraphrase from transcript supporting completion" }
                      },
                      required: ["nba_id", "confidence", "reason"],
                      additionalProperties: false
                    }
                  }
                },
                required: ["completions"],
                additionalProperties: false
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "suggest_completions" } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded, please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Payment required for AI features." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 503) {
        console.error("AI gateway temporarily unavailable (503)");
        return new Response(
          JSON.stringify({ error: "AI service temporarily unavailable, please try again in a moment." }),
          { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(
        JSON.stringify({ error: `AI gateway error: ${response.status}` }),
        { status: response.status >= 500 ? 503 : 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    
    if (!toolCall || toolCall.function.name !== "suggest_completions") {
      return new Response(
        JSON.stringify({ completions: [] }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const completions = JSON.parse(toolCall.function.arguments);

    return new Response(
      JSON.stringify(completions),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in detect-nba-completion:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const data = encoder.encode(keyInput);
  const bytes = new Uint8Array(32);
  for (let i = 0; i < Math.min(data.length, 32); i++) {
    bytes[i] = data[i];
  }
  return bytes;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

async function encrypt(plaintext: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plaintext);
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['encrypt']);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv.buffer as ArrayBuffer }, key, data);
  return { ciphertext: bytesToBase64(new Uint8Array(encrypted)), iv: bytesToBase64(iv) };
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function decrypt(ciphertext: string, ivBase64: string, keyInput: string): Promise<string | null> {
  try {
    const iv = base64ToBytes(ivBase64);
    const cipherBytes = base64ToBytes(ciphertext);
    const keyBytes = deriveKeyBytes(keyInput);
    const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['decrypt']);
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: iv.buffer as ArrayBuffer },
      key,
      cipherBytes.buffer as ArrayBuffer
    );
    return new TextDecoder().decode(decrypted);
  } catch (e) {
    console.error('[encrypt-pii] Decrypt error:', e);
    return null;
  }
}

// =============================================
// FUZZY NAME MATCHING UTILITIES
// =============================================

/**
 * Normalize a name for comparison: lowercase, trim, remove extra spaces
 */
function normalizeName(name: string | null | undefined): string {
  if (!name) return '';
  return name.toLowerCase().trim().replace(/\s+/g, ' ');
}

/**
 * Calculate Levenshtein distance between two strings
 */
function levenshteinDistance(a: string, b: string): number {
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;

  const matrix: number[][] = [];
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1,     // insertion
          matrix[i - 1][j] + 1      // deletion
        );
      }
    }
  }
  return matrix[b.length][a.length];
}

/**
 * Calculate name similarity score (0-1, where 1 is exact match)
 */
function nameSimilarity(name1: string, name2: string): number {
  const n1 = normalizeName(name1);
  const n2 = normalizeName(name2);
  
  if (!n1 || !n2) return 0;
  if (n1 === n2) return 1;
  
  // Check if one is a prefix/suffix of the other (e.g., "Ruba" vs "Ruba Zarour")
  if (n1.startsWith(n2) || n2.startsWith(n1)) {
    const shorter = n1.length < n2.length ? n1 : n2;
    const longer = n1.length < n2.length ? n2 : n1;
    // High similarity if shorter is a significant portion of longer
    if (shorter.length >= 3 && shorter.length / longer.length > 0.3) {
      return 0.85;
    }
  }
  
  // Check if first name matches
  const parts1 = n1.split(' ');
  const parts2 = n2.split(' ');
  if (parts1[0] === parts2[0] && parts1[0].length >= 3) {
    // Same first name - high similarity
    return 0.8;
  }
  
  // Levenshtein-based similarity
  const maxLen = Math.max(n1.length, n2.length);
  const distance = levenshteinDistance(n1, n2);
  const similarity = 1 - distance / maxLen;
  
  return similarity;
}

/**
 * Check if a name is likely a role/title rather than a person's name
 */
function isRoleBasedName(name: string): boolean {
  const rolePhrases = [
    'ceo', 'cto', 'coo', 'cfo', 'cio', 'cmo', 'cpo', 'cro',
    'vp', 'vice president', 'director', 'head of', 'manager',
    'chief', 'president', 'owner', 'founder', 'partner',
    'lead', 'senior', 'principal', 'architect'
  ];
  const normalized = normalizeName(name);
  return rolePhrases.some(role => normalized === role || normalized.startsWith(role + ' '));
}

/**
 * Extract role keywords from a role-based name
 */
function extractRoleKeywords(name: string): string[] {
  const normalized = normalizeName(name);
  const keywords: string[] = [];
  
  // C-level roles
  if (/\b(ceo|chief executive)\b/.test(normalized)) keywords.push('ceo');
  if (/\b(cto|chief technology|chief tech)\b/.test(normalized)) keywords.push('cto');
  if (/\b(coo|chief operating|chief ops)\b/.test(normalized)) keywords.push('coo');
  if (/\b(cfo|chief financial)\b/.test(normalized)) keywords.push('cfo');
  if (/\b(cio|chief information)\b/.test(normalized)) keywords.push('cio');
  if (/\b(cmo|chief marketing)\b/.test(normalized)) keywords.push('cmo');
  if (/\b(cpo|chief product)\b/.test(normalized)) keywords.push('cpo');
  
  // Department heads
  if (/\bhead of product\b/.test(normalized)) keywords.push('head_product');
  if (/\bhead of engineering\b/.test(normalized)) keywords.push('head_engineering');
  if (/\bhead of data\b/.test(normalized)) keywords.push('head_data');
  if (/\bhead of sales\b/.test(normalized)) keywords.push('head_sales');
  if (/\bhead of marketing\b/.test(normalized)) keywords.push('head_marketing');
  
  // Generic leadership terms
  if (/\b(vp|vice president)\b/.test(normalized)) keywords.push('vp');
  if (/\bdirector\b/.test(normalized)) keywords.push('director');
  
  return keywords;
}

interface ContactMatch {
  contactId: string;
  matchType: 'email' | 'name_exact' | 'name_fuzzy' | 'role_match';
  confidence: number;
  decryptedName?: string | undefined;
  decryptedRole?: string | undefined;
}

/**
 * Find best matching contact from existing contacts
 */
async function findBestContactMatch(
  targetName: string | null,
  targetEmail: string | null,
  targetRole: string | null,
  existingContacts: Array<{
    id: string;
    name_encrypted: string | null;
    email_encrypted: string | null;
    role_encrypted: string | null;
    encryption_iv: string | null;
    is_encrypted: boolean | null;
  }>,
  encryptionKey: string
): Promise<ContactMatch | null> {
  const matches: ContactMatch[] = [];
  
  for (const contact of existingContacts) {
    if (!contact.is_encrypted || !contact.encryption_iv) continue;
    
    let decryptedEmail: string | undefined = undefined;
    let decryptedName: string | undefined = undefined;
    let decryptedRole: string | undefined = undefined;
    
    // Decrypt fields
    try {
      if (contact.email_encrypted) {
        decryptedEmail = (await decrypt(contact.email_encrypted, contact.encryption_iv, encryptionKey)) || undefined;
      }
      if (contact.name_encrypted) {
        decryptedName = (await decrypt(contact.name_encrypted, contact.encryption_iv, encryptionKey)) || undefined;
      }
      if (contact.role_encrypted) {
        decryptedRole = (await decrypt(contact.role_encrypted, contact.encryption_iv, encryptionKey)) || undefined;
      }
    } catch (e) {
      console.warn(`[encrypt-pii] Failed to decrypt contact ${contact.id}:`, e);
      continue;
    }
    
    // 1. Email match (highest priority)
    if (targetEmail && decryptedEmail) {
      if (decryptedEmail.toLowerCase().trim() === targetEmail.toLowerCase().trim()) {
        matches.push({
          contactId: contact.id,
          matchType: 'email',
          confidence: 1.0,
          decryptedName,
          decryptedRole,
        });
        continue; // Email match is definitive
      }
    }
    
    // 2. Name matching
    if (targetName && decryptedName) {
      const similarity = nameSimilarity(targetName, decryptedName);
      
      // Exact name match
      if (similarity === 1) {
        matches.push({
          contactId: contact.id,
          matchType: 'name_exact',
          confidence: 0.95,
          decryptedName,
          decryptedRole,
        });
        continue;
      }
      
      // Fuzzy name match (e.g., "Ruba" vs "Ruba Zarour")
      if (similarity >= 0.75) {
        matches.push({
          contactId: contact.id,
          matchType: 'name_fuzzy',
          confidence: similarity,
          decryptedName,
          decryptedRole,
        });
        continue;
      }
    }
    
    // 3. Role-based matching (e.g., "CEO" matches later "John Smith" with role "CEO")
    if (targetName && isRoleBasedName(targetName) && decryptedRole) {
      const targetRoleKeywords = extractRoleKeywords(targetName);
      const contactRoleKeywords = extractRoleKeywords(decryptedRole);
      
      const hasOverlap = targetRoleKeywords.some(k => contactRoleKeywords.includes(k));
      if (hasOverlap) {
        matches.push({
          contactId: contact.id,
          matchType: 'role_match',
          confidence: 0.7,
          decryptedName,
          decryptedRole,
        });
        continue;
      }
    }
    
    // 4. Reverse role matching (incoming person has a role that matches existing role-only entry)
    if (targetRole && decryptedName && isRoleBasedName(decryptedName)) {
      const existingRoleKeywords = extractRoleKeywords(decryptedName);
      const incomingRoleKeywords = extractRoleKeywords(targetRole);
      
      const hasOverlap = existingRoleKeywords.some(k => incomingRoleKeywords.includes(k));
      if (hasOverlap) {
        matches.push({
          contactId: contact.id,
          matchType: 'role_match',
          confidence: 0.7,
          decryptedName,
          decryptedRole,
        });
        continue;
      }
    }
  }
  
  if (matches.length === 0) return null;
  
  // Sort by confidence and return best match
  matches.sort((a, b) => b.confidence - a.confidence);
  const best = matches[0];
  
  // Only auto-merge if confidence is high enough
  if (best.confidence >= 0.75) {
    console.log(`[encrypt-pii] Found match: ${best.matchType} with confidence ${best.confidence.toFixed(2)}`);
    return best;
  }
  
  return null;
}

// Encrypt with a pre-generated IV (for sharing IV across fields in a record)
async function encryptWithIv(plaintext: string, ivBytes: Uint8Array, keyInput: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plaintext);
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['encrypt']);
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: ivBytes.buffer as ArrayBuffer }, key, data);
  return bytesToBase64(new Uint8Array(encrypted));
}

// Map of table names to their configuration
const TABLE_CONFIG: Record<string, { ivField: string; encryptedSuffix: string }> = {
  momentum_meetings: { ivField: 'pii_encryption_iv', encryptedSuffix: '_encrypted' },
  account_contacts: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  profiles: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_team_members: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  opportunity_team_members: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_pain_points: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_use_cases: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_nbas: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_metrics: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_strategic_themes: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_exec_summaries: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  customer_stories: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  contact_meeting_snapshots: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_captured_insights: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  opportunity_milestones: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  opportunity_validation_tasks: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  opportunity_readiness_answers: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  competitor_scores: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  transcript_reviews: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  // Newly added tables
  detection_rule_matches: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  login_history: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  milestone_history: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_technologies: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  account_documents: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
  competitors: { ivField: 'encryption_iv', encryptedSuffix: '_encrypted' },
};

// Map of tables to their unique constraint columns for upsert (non-PK constraints)
const UPSERT_CONFLICT_COLUMNS: Record<string, string> = {
  account_exec_summaries: 'account_id',
  opportunity_readiness_answers: 'opportunity_id,question_id',
  detection_rule_matches: 'transcript_id,rule_id',
  contact_meeting_snapshots: 'contact_id,transcript_id',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');

    if (!encryptionKey) throw new Error('TRANSCRIPT_ENCRYPTION_KEY not configured');

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { recordId, table, data: recordData, operation = 'update' } = await req.json();

    if (!table || !recordData || typeof recordData !== 'object') {
      throw new Error('table and data object are required');
    }

    const config = TABLE_CONFIG[table];
    if (!config) {
      throw new Error(`Unknown table: ${table}`);
    }

    console.log(`[encrypt-pii] ${operation} ${table}:${recordId || 'new'}`);

    // Identify which fields need encryption based on the config
    const ENCRYPTED_FIELDS: Record<string, string[]> = {
      momentum_meetings: ['title', 'host_email', 'host_name', 'attendees', 'transcript_content'],
      account_contacts: ['name', 'email', 'phone', 'role', 'notes'],
      profiles: ['email', 'full_name'],
      account_team_members: ['team_member_email'],
      opportunity_team_members: ['team_member_email'],
      account_pain_points: ['pain_point', 'business_impact'],
      account_use_cases: ['use_case', 'description'],
      account_nbas: ['action', 'notes'],
      account_metrics: ['metric_value', 'context'],
      account_strategic_themes: ['theme_name', 'description', 'supporting_evidence'],
      account_exec_summaries: ['summary_narrative', 'engagement_summary', 'key_risks', 'key_opportunities', 'health_indicators'],
      customer_stories: ['situation', 'behavior', 'impact', 'impact_metrics'],
      contact_meeting_snapshots: ['key_quotes', 'concerns_raised', 'action_items', 'topics_discussed', 'notes'],
      account_captured_insights: ['value', 'value_json'],
      opportunity_milestones: ['description', 'notes'],
      opportunity_validation_tasks: ['notes'],
      opportunity_readiness_answers: ['answer', 'notes'],
      competitor_scores: ['rationale'],
      transcript_reviews: ['transcript_content', 'extracted_insights'],
      // Newly added tables
      detection_rule_matches: ['matched_phrases', 'speaker_email', 'speaker_name', 'signal_occurrences'],
      login_history: ['ip_address', 'user_agent'],
      milestone_history: ['notes', 'new_value', 'old_value'],
      account_technologies: ['context', 'notes', 'owner_email', 'owner_name'],
      account_documents: ['name', 'content'],
      competitors: ['description', 'relationship_notes'],
    };

    // Tables where plaintext columns have been dropped (only encrypted versions exist)
    const DIRECT_ENCRYPT_ONLY_TABLES = new Set(['account_contacts']);

    const fieldsToEncrypt = ENCRYPTED_FIELDS[table] || [];
    const updateData: Record<string, unknown> = {};
    const isDirectEncryptOnly = DIRECT_ENCRYPT_ONLY_TABLES.has(table);
    
    // Generate ONE IV for all fields in this record
    const ivBytes = crypto.getRandomValues(new Uint8Array(12));
    const ivBase64 = bytesToBase64(ivBytes);
    let hasEncryptedFields = false;

    // Process each field
    for (const [key, value] of Object.entries(recordData)) {
      if (fieldsToEncrypt.includes(key) && value !== null && value !== undefined) {
        // Encrypt this field using the SHARED IV
        const plaintext = typeof value === 'object' ? JSON.stringify(value) : String(value);
        const ciphertext = await encryptWithIv(plaintext, ivBytes, encryptionKey);
        updateData[`${key}${config.encryptedSuffix}`] = ciphertext;
        hasEncryptedFields = true;
        
        // For directEncryptOnly tables, don't set the plaintext column at all (it doesn't exist)
        if (isDirectEncryptOnly) {
          // Skip - the plaintext column doesn't exist in the DB
        } else if (table !== 'profiles' || (key !== 'email' && key !== 'full_name')) {
          // Clear plaintext (except for profiles which needs email/full_name)
          updateData[key] = null;
        } else {
          updateData[key] = value; // Keep plaintext for profiles
        }
      } else {
        // Pass through non-encrypted fields
        updateData[key] = value;
      }
    }

    if (hasEncryptedFields) {
      updateData[config.ivField] = ivBase64;
      updateData.is_encrypted = true;
    }

    let result;
    if (operation === 'insert') {
      const { data, error } = await supabase
        .from(table)
        .insert(updateData)
        .select()
        .single();
      if (error && (error as any).code === '23505') {
        // Duplicate key - try to find and update the existing record instead
        console.warn(`[encrypt-pii] Duplicate on insert to ${table}, falling back to update`);
        if (table === 'account_metrics' && recordData.account_id && recordData.metric_name) {
          let fallbackQuery = supabase
            .from('account_metrics')
            .select('id')
            .eq('account_id', recordData.account_id)
            .eq('metric_name', recordData.metric_name);
          if (recordData.opportunity_id) {
            fallbackQuery = fallbackQuery.eq('opportunity_id', recordData.opportunity_id);
          } else {
            fallbackQuery = fallbackQuery.is('opportunity_id', null);
          }
          if (recordData.source_transcript_id) {
            fallbackQuery = fallbackQuery.eq('source_transcript_id', recordData.source_transcript_id);
          } else {
            fallbackQuery = fallbackQuery.is('source_transcript_id', null);
          }
          const { data: existing } = await fallbackQuery.limit(1).maybeSingle();
          if (existing) {
            const { id: _removeId, ...updateOnly } = updateData;
            const { data: updated, error: updateErr } = await supabase
              .from(table)
              .update(updateOnly)
              .eq('id', existing.id)
              .select()
              .single();
            if (updateErr) throw updateErr;
            result = updated;
          } else {
            console.warn(`[encrypt-pii] Could not find existing record to update, skipping duplicate`);
            result = { id: 'skipped-duplicate' };
          }
        } else {
          // For other tables, just skip the duplicate
          console.warn(`[encrypt-pii] Skipping duplicate insert for ${table}`);
          result = { id: 'skipped-duplicate' };
        }
      } else if (error) {
        throw error;
      } else {
        result = data;
      }
    } else if (operation === 'update' && recordId) {
      const { data, error } = await supabase
        .from(table)
        .update(updateData)
        .eq('id', recordId)
        .select()
        .single();
      if (error) throw error;
      result = data;
    } else if (operation === 'upsert') {
      // Special handling for tables where unique constraint includes encrypted fields
      // For account_team_members: unique on (account_id, team_member_email) but we null team_member_email
      // So we need to check existence BEFORE encrypting the lookup value
      if (table === 'account_team_members' && recordData.team_member_email && recordData.account_id) {
        // Check if record exists using the ORIGINAL (plaintext) email
        const { data: existing } = await supabase
          .from('account_team_members')
          .select('id')
          .eq('account_id', recordData.account_id)
          .eq('team_member_email', recordData.team_member_email)
          .maybeSingle();
        
        if (existing) {
          // Update existing record
          const { data, error } = await supabase
            .from(table)
            .update(updateData)
            .eq('id', existing.id)
            .select()
            .single();
          if (error) throw error;
          result = data;
        } else {
          // Insert new record - keep plaintext email for the unique constraint
          // The encrypted value is stored in team_member_email_encrypted
          updateData.team_member_email = recordData.team_member_email;
          const { data, error } = await supabase
            .from(table)
            .insert(updateData)
            .select()
            .single();
          if (error) throw error;
          result = data;
        }
      } else if (table === 'opportunity_team_members' && recordData.team_member_email && recordData.opportunity_id) {
        // Same logic for opportunity_team_members
        const { data: existing } = await supabase
          .from('opportunity_team_members')
          .select('id')
          .eq('opportunity_id', recordData.opportunity_id)
          .eq('team_member_email', recordData.team_member_email)
          .maybeSingle();
        
        if (existing) {
          const { data, error } = await supabase
            .from(table)
            .update(updateData)
            .eq('id', existing.id)
            .select()
            .single();
          if (error) throw error;
          result = data;
        } else {
          updateData.team_member_email = recordData.team_member_email;
          const { data, error } = await supabase
            .from(table)
            .insert(updateData)
            .select()
            .single();
          if (error) throw error;
          result = data;
        }
      } else if (table === 'account_metrics' && recordData.account_id && recordData.metric_name) {
        // account_metrics has a complex unique index: (account_id, opportunity_id, source_transcript_id, md5(metric_name || metric_value))
        // We must check for existing records BEFORE plaintext is nulled, and also handle race conditions.
        let query = supabase
          .from('account_metrics')
          .select('id')
          .eq('account_id', recordData.account_id)
          .eq('metric_name', recordData.metric_name);
        
        if (recordData.opportunity_id) {
          query = query.eq('opportunity_id', recordData.opportunity_id);
        } else {
          query = query.is('opportunity_id', null);
        }
        
        if (recordData.source_transcript_id) {
          query = query.eq('source_transcript_id', recordData.source_transcript_id);
        } else {
          query = query.is('source_transcript_id', null);
        }
        
        // Check both the original plaintext value AND null (already-encrypted records)
        if (recordData.metric_value) {
          const { data: exactMatch } = await query.eq('metric_value', recordData.metric_value).maybeSingle();
          if (exactMatch) {
            const { data, error } = await supabase
              .from(table)
              .update(updateData)
              .eq('id', exactMatch.id)
              .select()
              .single();
            if (error) throw error;
            result = data;
          } else {
            // Also check for already-encrypted version (metric_value is null)
            let nullQuery = supabase
              .from('account_metrics')
              .select('id')
              .eq('account_id', recordData.account_id)
              .eq('metric_name', recordData.metric_name)
              .is('metric_value', null);
            if (recordData.opportunity_id) {
              nullQuery = nullQuery.eq('opportunity_id', recordData.opportunity_id);
            } else {
              nullQuery = nullQuery.is('opportunity_id', null);
            }
            if (recordData.source_transcript_id) {
              nullQuery = nullQuery.eq('source_transcript_id', recordData.source_transcript_id);
            } else {
              nullQuery = nullQuery.is('source_transcript_id', null);
            }
            const { data: nullMatch } = await nullQuery.maybeSingle();
            
            if (nullMatch) {
              const { data, error } = await supabase
                .from(table)
                .update(updateData)
                .eq('id', nullMatch.id)
                .select()
                .single();
              if (error) throw error;
              result = data;
            } else {
              // Try insert, but gracefully handle duplicate key race condition
              const { data, error } = await supabase
                .from(table)
                .insert(updateData)
                .select()
                .single();
              if (error && (error as any).code === '23505') {
                console.warn(`[encrypt-pii] Duplicate detected on insert, skipping: ${recordData.metric_name}`);
                result = { id: 'skipped-duplicate' };
              } else if (error) {
                throw error;
              } else {
                result = data;
              }
            }
          }
        } else {
          // No metric_value provided - check for null metric_value match
          query = query.is('metric_value', null);
          const { data: existing } = await query.maybeSingle();
          
          if (existing) {
            const { data, error } = await supabase
              .from(table)
              .update(updateData)
              .eq('id', existing.id)
              .select()
              .single();
            if (error) throw error;
            result = data;
          } else {
            const { data, error } = await supabase
              .from(table)
              .insert(updateData)
              .select()
              .single();
            if (error && (error as any).code === '23505') {
              console.warn(`[encrypt-pii] Duplicate detected on insert, skipping: ${recordData.metric_name}`);
              result = { id: 'skipped-duplicate' };
            } else if (error) {
              throw error;
            } else {
              result = data;
            }
          }
        }
      } else if (table === 'account_contacts' && recordData.account_id) {
        // account_contacts: use fuzzy name matching + email matching + role matching
        const targetName = recordData.name ? String(recordData.name) : null;
        const targetEmail = recordData.email ? String(recordData.email).toLowerCase().trim() : null;
        const targetRole = recordData.role ? String(recordData.role) : null;
        
        // Fetch all contacts for this account to check for duplicates
        const { data: existingContacts } = await supabase
          .from('account_contacts')
          .select('id, name_encrypted, email_encrypted, role_encrypted, encryption_iv, is_encrypted')
          .eq('account_id', recordData.account_id);
        
        // Use the new fuzzy matching function
        const match = existingContacts && existingContacts.length > 0
          ? await findBestContactMatch(targetName, targetEmail, targetRole, existingContacts, encryptionKey)
          : null;
        
        if (match) {
          // Update existing contact - prefer fuller name if we matched on fuzzy/role
          console.log(`[encrypt-pii] Found duplicate contact via ${match.matchType} (confidence: ${match.confidence.toFixed(2)}), updating ${match.contactId}`);
          
          // If incoming name is longer/fuller than existing, update the name
          if (match.matchType === 'name_fuzzy' && targetName && match.decryptedName) {
            if (targetName.length > match.decryptedName.length) {
              console.log(`[encrypt-pii] Using fuller name: "${targetName}" over "${match.decryptedName}"`);
              // updateData already has the encrypted name
            }
          }
          
          const { data, error } = await supabase
            .from(table)
            .update(updateData)
            .eq('id', match.contactId)
            .select()
            .single();
          if (error) throw error;
          result = data;
        } else {
          // Insert new contact
          const { data, error } = await supabase
            .from(table)
            .insert(updateData)
            .select()
            .single();
          if (error) throw error;
          result = data;
        }
      } else {
        // Default upsert for tables without encrypted unique columns
        const conflictColumns = UPSERT_CONFLICT_COLUMNS[table];
        const upsertOptions = conflictColumns ? { onConflict: conflictColumns } : {};
        const { data, error } = await supabase
          .from(table)
          .upsert(updateData, upsertOptions)
          .select()
          .single();
        if (error) throw error;
        result = data;
      }
    } else {
      throw new Error('Invalid operation or missing recordId for update');
    }

    console.log(`[encrypt-pii] Successfully ${operation}d ${table}:${result?.id}`);

    return new Response(JSON.stringify({ success: true, data: result }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    let message = 'Unknown error';
    if (error instanceof Error) {
      message = error.message;
    } else if (error && typeof error === 'object') {
      // Handle Supabase/Postgres errors which may not be Error instances
      const pgError = error as { message?: string; details?: string; code?: string };
      message = pgError.message || pgError.details || JSON.stringify(error);
      if (pgError.code) message = `[${pgError.code}] ${message}`;
    }
    console.error('[encrypt-pii] Error:', message);
    console.error('[encrypt-pii] Full error:', JSON.stringify(error, null, 2));
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// AES-256-GCM encryption using Web Crypto API
async function encrypt(plaintext: string, keyHex: string): Promise<{ ciphertext: string; iv: string }> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plaintext);
  
  // Derive a 256-bit key from the hex key
  const keyBytes = hexToBytes(keyHex.substring(0, 64)); // Use first 64 hex chars = 32 bytes = 256 bits
  const key = await crypto.subtle.importKey(
    'raw',
    keyBytes.buffer as ArrayBuffer,
    { name: 'AES-GCM' },
    false,
    ['encrypt']
  );
  
  // Generate random IV (12 bytes for AES-GCM)
  const iv = crypto.getRandomValues(new Uint8Array(12));
  
  // Encrypt
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv.buffer as ArrayBuffer },
    key,
    data
  );
  
  return {
    ciphertext: bytesToBase64(new Uint8Array(encrypted)),
    iv: bytesToBase64(iv),
  };
}

function hexToBytes(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');

    if (!encryptionKey) {
      throw new Error('TRANSCRIPT_ENCRYPTION_KEY not configured');
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    const { transcriptId, content, table = 'transcript_reviews' } = await req.json();
    
    if (!content) {
      throw new Error('No content provided to encrypt');
    }

    console.log(`[encrypt-transcript] Encrypting content for ${table}:${transcriptId || 'new'}`);
    
    // Encrypt the content
    const { ciphertext, iv } = await encrypt(content, encryptionKey);
    
    if (transcriptId) {
      // Update existing record
      const updateData = {
        transcript_content_encrypted: ciphertext,
        encryption_iv: iv,
        is_encrypted: true,
        transcript_content: null, // Clear plaintext
      };
      
      const { error } = await supabase
        .from(table)
        .update(updateData)
        .eq('id', transcriptId);
      
      if (error) throw error;
      
      console.log(`[encrypt-transcript] Successfully encrypted ${table}:${transcriptId}`);
    }
    
    return new Response(JSON.stringify({ 
      success: true,
      ciphertext,
      iv,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
    
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    console.error('[encrypt-transcript] Error:', message);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

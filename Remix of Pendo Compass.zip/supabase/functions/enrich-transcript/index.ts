import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";
import { getAIConfig, computeContentHash, smartTruncate } from "../_shared/ai-provider.ts";
import { fetchScorecardDifferentials, formatScorecardContext, fetchUseCasesForCompetitive, formatUseCaseContext } from "../_shared/context-builder.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// === Analysis Run Logger ===
async function logPassStart(
  supabase: any,
  transcriptId: string, passKey: string, passName: string, phase: string, retryAttempt = 0
): Promise<string | null> {
  try {
    const { data, error } = await supabase.from('analysis_run_logs').insert({
      transcript_id: transcriptId,
      pass_key: passKey,
      pass_name: passName,
      phase,
      status: 'running',
      retry_attempt: retryAttempt,
      started_at: new Date().toISOString(),
    }).select('id').single();
    if (error) { console.error('[RunLog] Insert failed:', error.message); return null; }
    return data?.id || null;
  } catch (e) { console.error('[RunLog] Error:', e); return null; }
}

async function logPassEnd(
  supabase: any, logId: string | null,
  status: 'completed' | 'failed' | 'skipped',
  startTime: number,
  opts: { errorMessage?: string; errorCategory?: string; inputTokens?: number; outputTokens?: number; resultSummary?: any; metadata?: any } = {}
) {
  if (!logId) return;
  try {
    const durationMs = Date.now() - startTime;
    await supabase.from('analysis_run_logs').update({
      status,
      completed_at: new Date().toISOString(),
      duration_ms: durationMs,
      error_message: opts.errorMessage || null,
      error_category: opts.errorCategory || null,
      input_tokens_estimate: opts.inputTokens || null,
      output_tokens_estimate: opts.outputTokens || null,
      result_summary: opts.resultSummary || null,
      metadata: opts.metadata || null,
    }).eq('id', logId);
  } catch (e) { console.error('[RunLog] Update failed:', e); }
}

// Key derivation that matches encrypt-pii - handles both hex and non-hex keys
function deriveKeyBytes(keyInput: string): Uint8Array {
  // Check if it's a valid hex string of at least 64 chars (32 bytes = 256 bits)
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  // Otherwise treat as raw passphrase
  const encoder = new TextEncoder();
  const data = encoder.encode(keyInput);
  const bytes = new Uint8Array(32);
  for (let i = 0; i < Math.min(data.length, 32); i++) {
    bytes[i] = data[i];
  }
  return bytes;
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

async function decryptContent(ciphertext: string, ivBase64: string, keyInput: string): Promise<string> {
  const decoder = new TextDecoder();
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey(
    'raw',
    keyBytes.buffer as ArrayBuffer,
    { name: 'AES-GCM' },
    false,
    ['decrypt']
  );
  
  const iv = base64ToBytes(ivBase64);
  const encryptedData = base64ToBytes(ciphertext);
  
  const decrypted = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: iv.buffer as ArrayBuffer },
    key,
    encryptedData.buffer as ArrayBuffer
  );
  
  return decoder.decode(decrypted);
}

async function decryptWithFallbackKeys(ciphertext: string, ivBase64: string): Promise<string> {
  const primaryKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');
  const alternateKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE');

  if (!primaryKey && !alternateKey) {
    throw new Error('No encryption keys configured');
  }

  const errors: string[] = [];

  if (primaryKey) {
    try {
      return await decryptContent(ciphertext, ivBase64, primaryKey);
    } catch (e) {
      errors.push(`primary_failed:${e instanceof Error ? e.message : String(e)}`);
    }
  }

  if (alternateKey) {
    try {
      return await decryptContent(ciphertext, ivBase64, alternateKey);
    } catch (e) {
      errors.push(`alternate_failed:${e instanceof Error ? e.message : String(e)}`);
    }
  }

  throw new Error(`Decryption failed (${errors.join(', ')})`);
}

// Pass 3 Schema: Detection Rules
const pass3DetectionSchema = {
  type: "object",
  properties: {
    detectionRuleMatches: {
      type: "array",
      items: {
        type: "object",
        properties: {
          ruleId: { type: "string" },
          ruleName: { type: "string" },
          matchedPhrases: { type: "array", items: { type: "string" } },
          confidence: { type: "number" },
          context: { type: "string" },
          speakerType: { type: "string", enum: ["internal", "external", "unknown"], description: "internal=Pendo employee, external=customer/prospect" },
          speakerName: { type: "string", nullable: true, description: "Name of the person who said the key phrase" },
          speakerEmail: { type: "string", nullable: true, description: "Email of the speaker if identifiable from transcript" }
        },
        required: ["ruleId", "ruleName", "matchedPhrases", "confidence", "context", "speakerType"]
      }
    },
    detectedDeploymentTypes: {
      type: "array",
      items: {
        type: "object",
        properties: {
          deploymentTypeId: { type: "string" },
          deploymentTypeName: { type: "string" },
          confidence: { type: "number" },
          reasoning: { type: "string" }
        },
        required: ["deploymentTypeId", "deploymentTypeName", "confidence", "reasoning"]
      }
    }
  },
  required: ["detectionRuleMatches", "detectedDeploymentTypes"]
};

// Pass 4 Schema: Readiness Only (product mentions handled by Pass 3b trigger)
const pass4ReadinessSchema = {
  type: "object",
  properties: {
    readinessAnswers: {
      type: "array",
      items: {
        type: "object",
        properties: {
          questionId: { type: "string" },
          answer: { type: "string" },
          confidence: { type: "number" },
          context: { type: "string" }
        },
        required: ["questionId", "answer", "confidence", "context"]
      }
    }
  },
  required: ["readinessAnswers"]
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(supabaseUrl, supabaseKey);

  try {
    const { transcriptReviewId } = await req.json();
    
    if (!transcriptReviewId) {
      return new Response(
        JSON.stringify({ error: "transcriptReviewId is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[Enrichment] Starting for transcript: ${transcriptReviewId}`);

    // Mark as in_progress
    await supabase
      .from("transcript_reviews")
      .update({ 
        enrichment_status: "in_progress",
        enrichment_started_at: new Date().toISOString()
      })
      .eq("id", transcriptReviewId);

    // Fetch transcript - check for linked momentum_meeting for content and meeting date
    // Include encrypted fields for decryption support
    const { data: transcript, error: fetchError } = await supabase
      .from("transcript_reviews")
      .select(`
        transcript_content, 
        transcript_content_encrypted,
        encryption_iv,
        is_encrypted,
        extracted_insights, 
        opportunity_id,
        momentum_meeting_id,
        file_name,
        content_hash,
        last_enriched_hash,
        enrichment_status,
        created_at,
        meeting_type,
        opportunities (
          account_id
        ),
        momentum_meetings (
          transcript_content,
          transcript_content_encrypted,
          pii_encryption_iv,
          encryption_iv,
          is_encrypted,
          start_time,
          created_at
        )
      `)
      .eq("id", transcriptReviewId)
      .single();

    if (fetchError || !transcript) {
      throw new Error(`Failed to fetch transcript: ${fetchError?.message}`);
    }

    // Auto-link orphaned transcript_reviews to momentum_meetings by file_name
    if (!transcript.momentum_meeting_id && transcript.file_name?.startsWith('momentum_')) {
      const momentumId = transcript.file_name.replace('momentum_', '');
      const { data: matchedMeeting } = await supabase
        .from("momentum_meetings")
        .select("id, transcript_content, transcript_content_encrypted, pii_encryption_iv, encryption_iv, is_encrypted, start_time, created_at")
        .eq("momentum_id", momentumId)
        .maybeSingle();

      if (matchedMeeting) {
        console.log(`[Enrichment] Auto-linked orphaned transcript to momentum_meeting ${matchedMeeting.id}`);
        // Update the link in the database
        await supabase
          .from("transcript_reviews")
          .update({ momentum_meeting_id: matchedMeeting.id })
          .eq("id", transcriptReviewId);

        // Use this meeting's content as a linked meeting
        (transcript as any).momentum_meeting_id = matchedMeeting.id;
        (transcript as any).momentum_meetings = matchedMeeting;
      }
    }

    // Get transcript content from momentum_meetings if linked, otherwise from transcript_reviews
    // Handle both encrypted and plaintext content
    const linkedMeeting = transcript.momentum_meetings as unknown as { 
      transcript_content: string | null; 
      transcript_content_encrypted: string | null;
      pii_encryption_iv: string | null;
      encryption_iv: string | null;
      is_encrypted: boolean | null;
      start_time: string; 
      created_at: string 
    } | null;
    
    let transcriptContent: string | null = null;
    
    // Try linked momentum_meeting first
    if (transcript.momentum_meeting_id && linkedMeeting) {
      const meetingIv = linkedMeeting.pii_encryption_iv || linkedMeeting.encryption_iv;
      if (linkedMeeting.is_encrypted && linkedMeeting.transcript_content_encrypted && meetingIv) {
        // Decrypt momentum_meeting content
        try {
          transcriptContent = await decryptWithFallbackKeys(
            linkedMeeting.transcript_content_encrypted,
            meetingIv
          );
          console.log(`[Enrichment] Decrypted momentum_meeting content (${transcriptContent.length} chars)`);
        } catch (decryptError) {
          console.error('[Enrichment] Failed to decrypt momentum_meeting:', decryptError);
        }
      } else if (linkedMeeting.transcript_content) {
        transcriptContent = linkedMeeting.transcript_content;
      }
    }
    
    // Fall back to transcript_reviews content
    if (!transcriptContent) {
      if (transcript.is_encrypted && transcript.transcript_content_encrypted && transcript.encryption_iv) {
        // Decrypt transcript_reviews content
        try {
          transcriptContent = await decryptWithFallbackKeys(
            transcript.transcript_content_encrypted,
            transcript.encryption_iv
          );
          console.log(`[Enrichment] Decrypted transcript_reviews content (${transcriptContent.length} chars)`);
        } catch (decryptError) {
          console.error('[Enrichment] Failed to decrypt transcript_reviews:', decryptError);
        }
      } else if (transcript.transcript_content) {
        transcriptContent = transcript.transcript_content;
      }
    }
    
    // Derive the "event occurred at" timestamp: prefer meeting start_time, fallback to created_at
    const eventOccurredAt = linkedMeeting?.start_time
      || linkedMeeting?.created_at
      || transcript.created_at
      || new Date().toISOString();
    
    if (!transcriptContent) {
      throw new Error("No transcript content available - encryption key may be missing or content not found");
    }
    
    // Guard against empty or trivially short content that would produce no insights
    if (transcriptContent.trim().length < 100) {
      console.error(`[Enrichment] Transcript content too short (${transcriptContent.trim().length} chars) - likely a decryption or import issue`);
      throw new Error(`Transcript content too short (${transcriptContent.trim().length} chars) - decryption may have failed silently`);
    }
    
    console.log(`[Enrichment] Transcript content ready (${transcriptContent.length} chars, encrypted=${transcript.is_encrypted})`)
    
    // Compute content hash for cache detection
    const currentHash = computeContentHash(transcriptContent);
    
    // Check if we can skip enrichment (same content, already enriched AND completed successfully)
    const enrichmentCompleted = transcript.enrichment_status === 'completed';
    if (transcript.last_enriched_hash === currentHash && transcript.extracted_insights?.detectionRuleMatches && enrichmentCompleted) {
      console.log(`[Enrichment] Skipping - transcript unchanged (hash: ${currentHash})`);
      return new Response(
        JSON.stringify({ 
          success: true, 
          skipped: true, 
          reason: "Content unchanged since last enrichment" 
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    const existingInsights = transcript.extracted_insights || {};
    const opportunityId = transcript.opportunity_id;
    const accountId = (transcript.opportunities as any)?.account_id || null;

    // ========== TRIAGE: Check which rule trees should be skipped ==========
    const skippedTreeIds = new Set<string>();
    const triageResults: Record<string, { skipped: boolean; reason: string }> = {};
    
    // Fetch triage configs for gated trees
    const { data: triageConfigs } = await supabase
      .from("detection_tree_config")
      .select("tree_id, name, triage_enabled, triage_keywords, triage_prompt, triage_context_field")
      .eq("triage_enabled", true);
    
    if (triageConfigs && triageConfigs.length > 0) {
      const transcriptLower = transcriptContent.toLowerCase();
      const aiConfigTriage = await getAIConfig('lite');
      
      for (const config of triageConfigs) {
        const treeId = config.tree_id;
        const treeName = config.name;
        
        // Phase 1: Fast keyword pre-scan
        const keywords = config.triage_keywords || [];
        const keywordHits = keywords.filter((kw: string) => transcriptLower.includes(kw.toLowerCase()));
        
        if (keywordHits.length === 0) {
          // No keywords found — skip this tree entirely
          skippedTreeIds.add(treeId);
          triageResults[treeId] = { skipped: true, reason: `No triage keywords found (checked ${keywords.length} keywords)` };
          console.log(`[Triage] SKIP "${treeName}" — no keywords matched (${keywords.length} checked)`);
          continue;
        }
        
        console.log(`[Triage] "${treeName}" — ${keywordHits.length}/${keywords.length} keywords matched: ${keywordHits.join(', ')}`);
        
        // Phase 2: AI triage confirmation (cheap single-sentence call)
        if (config.triage_prompt) {
          try {
            // Take a small sample of the transcript for triage (first 3000 chars + keyword-surrounding context)
            const triageSample = transcriptContent.substring(0, 3000);
            
            const triageResponse = await Promise.race([
              fetch(aiConfigTriage.endpoint, {
                method: "POST",
                headers: {
                  Authorization: `Bearer ${aiConfigTriage.apiKey}`,
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  model: aiConfigTriage.model,
                  messages: [
                    { role: "system", content: config.triage_prompt },
                    { role: "user", content: triageSample }
                  ],
                  max_tokens: 100,
                }),
              }),
              new Promise((_, reject) => setTimeout(() => reject(new Error("Triage timeout")), 10000))
            ]) as Response;

            if (triageResponse.ok) {
              const triageData = await triageResponse.json();
              const triageAnswer = (triageData.choices?.[0]?.message?.content || '').toLowerCase();
              const isRelevant = triageAnswer.startsWith('yes') || triageAnswer.includes('yes,') || triageAnswer.includes('yes.');
              
              if (!isRelevant) {
                skippedTreeIds.add(treeId);
                triageResults[treeId] = { skipped: true, reason: `AI triage said NO: ${triageData.choices?.[0]?.message?.content?.substring(0, 100)}` };
                console.log(`[Triage] SKIP "${treeName}" — AI confirmed not relevant`);
              } else {
                triageResults[treeId] = { skipped: false, reason: `AI triage confirmed relevant` };
                console.log(`[Triage] KEEP "${treeName}" — AI confirmed relevant`);
              }
            } else {
              // If triage fails, keep the tree (safe default)
              triageResults[treeId] = { skipped: false, reason: `Triage API failed, keeping tree as safe default` };
              console.log(`[Triage] KEEP "${treeName}" — triage API failed, defaulting to include`);
            }
          } catch (triageErr) {
            triageResults[treeId] = { skipped: false, reason: `Triage error, keeping as safe default` };
            console.log(`[Triage] KEEP "${treeName}" — triage error:`, triageErr);
          }
        } else {
          // Keywords matched but no AI prompt configured — keep
          triageResults[treeId] = { skipped: false, reason: `Keywords matched, no AI prompt configured` };
          console.log(`[Triage] KEEP "${treeName}" — keywords matched, no AI triage configured`);
        }
      }
      
      console.log(`[Triage] Summary: ${skippedTreeIds.size} trees skipped, ${triageConfigs.length - skippedTreeIds.size} kept`);
    }

    // Map tree IDs to deployment type IDs for readiness question filtering
    const TREE_TO_DEPLOYMENT_TYPE: Record<string, string> = {
      'd0000001-0001-4000-8000-000000000001': 'aa321c94-a43d-4b94-8247-2d2e84b824c0', // Listen
      'e0000001-0001-4000-8000-000000000001': 'b1e2f3a4-5678-4abc-9def-0a1b2c3d4e5f', // Orchestrate
    };
    const VALIDATION_TREE_ID = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890';
    
    // Build set of deployment type IDs to skip based on skipped trees
    const skippedDeploymentTypeIds = new Set<string>();
    for (const [treeId, deploymentTypeId] of Object.entries(TREE_TO_DEPLOYMENT_TYPE)) {
      if (skippedTreeIds.has(treeId)) {
        skippedDeploymentTypeIds.add(deploymentTypeId);
      }
    }

    // Fetch detection rules, readiness questions, deployment types
    const ACTIVITY_SIGNALS_TREE_ID = 'f5e4d3c2-b1a0-9876-5432-fedcba098765';
    const PENDO_PRODUCTS_TREE_ID = 'b0000001-0001-4000-8000-000000000001';
    const COMPETITORS_TREE_ID = 'c0000001-0001-4000-8000-000000000001';
    
    const [activityRulesRes, pendoProductRulesRes, competitorRulesRes, allRulesRes, deploymentRes, readinessRes, pendoRes, competitorRes] = await Promise.all([
      // Activity signal rules only (for Pass 3)
      supabase.from("detection_rules")
        .select("id,name,trigger_phrases,context_qualifiers,exclusion_phrases,confirmation_patterns,detection_intent,speaker_context")
        .eq("is_active", true)
        .eq("tree_id", ACTIVITY_SIGNALS_TREE_ID),
      // Pendo Products detection rules
      supabase.from("detection_rules")
        .select("id,name,trigger_phrases,context_qualifiers,exclusion_phrases")
        .eq("is_active", true)
        .eq("tree_id", PENDO_PRODUCTS_TREE_ID),
      // Competitors detection rules
      supabase.from("detection_rules")
        .select("id,name,trigger_phrases,context_qualifiers,exclusion_phrases")
        .eq("is_active", true)
        .eq("tree_id", COMPETITORS_TREE_ID),
      // All rules (for other purposes if needed)
      supabase.from("detection_rules")
        .select("id,name,trigger_phrases,context_qualifiers,exclusion_phrases,confirmation_patterns,detection_intent,speaker_context")
        .eq("is_active", true),
      supabase.from("deployment_types").select("id,name,description").order("sort_order"),
      supabase.from("readiness_template_questions").select("id,question,category_id,readiness_template_categories(name,deployment_type_id)"),
      supabase.from("technology_repository").select("id,name,functional_area").eq("is_pendo_product", true),
      supabase.from("technology_repository").select("id,name,functional_area").eq("is_competitor", true)
    ]);

    // Use only activity signal rules for Pass 3 detection
    const activitySignalRules = activityRulesRes.data || [];
    const pendoProductRules = pendoProductRulesRes.data || [];
    const competitorDetectionRules = competitorRulesRes.data || [];
    const allDetectionRules = allRulesRes.data || [];
    const deploymentTypes = deploymentRes.data || [];
    const pendoProducts = pendoRes.data || [];
    const competitorProducts = competitorRes.data || [];
    
    // Filter readiness questions based on triage results
    const allReadinessQuestions = readinessRes.data || [];
    let readinessQuestions = allReadinessQuestions.filter((q: any) => {
      const deploymentTypeId = q.readiness_template_categories?.deployment_type_id;
      if (deploymentTypeId && skippedDeploymentTypeIds.has(deploymentTypeId)) {
        return false; // Skip questions from gated deployment types
      }
      return true;
    });
    
    const skippedQuestionCount = allReadinessQuestions.length - readinessQuestions.length;
    console.log(`[Enrichment] Loaded ${activitySignalRules.length} activity signal rules, ${pendoProductRules.length} Pendo product rules, ${competitorDetectionRules.length} competitor rules, ${readinessQuestions.length} questions (${skippedQuestionCount} skipped by triage)`);

    // Use 'lite' model tier for enrichment passes (cheaper, faster)
    const aiConfigLite = await getAIConfig('lite');

    // Context from core analysis
    const coreContext = `
CONTEXT FROM CORE ANALYSIS:
- Pain points: ${existingInsights.painPoints?.join(', ') || 'None'}
- Use cases: ${existingInsights.useCases?.join(', ') || 'None'}
- Technologies: ${existingInsights.technologies?.map((t: any) => t.name).join(', ') || 'None'}
`;

    let pass3Result: any = { detectionRuleMatches: [], detectedDeploymentTypes: [] };
    let pass3bResult: any = { detectionRuleMatches: [] }; // Product detection results
    let pass4Result: any = { readinessAnswers: [] };

    // Build keyword list for smart truncation from detection rules
    const pass3Keywords = activitySignalRules.flatMap((rule: any) => [
      ...(rule.trigger_phrases || []),
      ...(rule.context_qualifiers || [])
    ]).filter(Boolean);
    
    // Smart truncation: reduce transcript to 30K chars focused on relevant keywords
    const truncatedForPass3 = smartTruncate(transcriptContent, 30000, pass3Keywords);
    console.log(`[Enrichment] Truncated transcript from ${transcriptContent.length} to ${truncatedForPass3.length} chars for Pass 3`);

    // ========== PASS 3: Activity Signal Detection (90s timeout) ==========
    if (activitySignalRules.length > 0 || deploymentTypes.length > 0) {
      console.log(`[Enrichment] Pass 3: Detecting activity signals (${activitySignalRules.length} rules)...`);
      
      // Build enhanced rules section with speaker context and detection intent
      const rulesSection = activitySignalRules.map((rule: any) => {
        const speakerLabel = rule.speaker_context === 'external_only' ? 'CUSTOMER/PROSPECT must say' 
          : rule.speaker_context === 'internal_only' ? 'PENDO EMPLOYEE must say'
          : 'Anyone can say';
        const intentLabel = rule.detection_intent === 'implemented' ? 'IMPLEMENTED (customer confirms completion)'
          : rule.detection_intent === 'planned' ? 'PLANNED (future intent)'
          : rule.detection_intent === 'blocked' ? 'BLOCKED (obstacle identified)'
          : 'DISCUSSED (any mention)';
        const confirmPatterns = rule.confirmation_patterns?.length > 0 
          ? `\n  Confirmation required from customer: ${rule.confirmation_patterns.join(', ')}`
          : '';
        
        return `Rule "${rule.name}" (ID: ${rule.id}):
  Intent: ${intentLabel}
  Speaker: ${speakerLabel}
  Triggers: ${rule.trigger_phrases?.join(', ') || 'None'}
  Context qualifiers: ${rule.context_qualifiers?.join(', ') || 'None'}
  Exclusions: ${rule.exclusion_phrases?.join(', ') || 'None'}${confirmPatterns}`;
      }).join('\n\n');

      const deploymentSection = deploymentTypes.map((dt: any) => 
        `${dt.name} (ID: ${dt.id}): ${dt.description || 'No description'}`
      ).join('\n');

      const pass3Prompt = `Match detection rules and deployment types in this transcript.

CRITICAL MATCHING INSTRUCTIONS:
1. For rules with intent "IMPLEMENTED": Only match when the CUSTOMER/PROSPECT CONFIRMS they have COMPLETED the action.
   - Look for past tense or confirmation language: "we have", "yes", "it's working", "we deployed", "we set up"
   - If confirmation_patterns are specified, the customer must use one of those phrases
   - EXCLUDE: Questions from Pendo ("have you?"), planning statements ("we will"), general discussion
   
2. For rules with speaker context "external_only": The trigger phrase must be spoken by the customer/prospect, NOT by a Pendo employee asking about it.

3. For rules with intent "PLANNED": Match when discussing future intent ("we plan to", "we will", "next quarter")

4. For rules with intent "DISCUSSED": Match any substantive mention of the topic

${coreContext}

DETECTION RULES:
${rulesSection}

DEPLOYMENT TYPES:
${deploymentSection}

For each match, include:
- The exact rule/deployment ID
- The matched phrases (what was said)
- speakerType: "external" if customer/prospect said it, "internal" if Pendo employee, "unknown" if unclear
- speakerName: The name of the person who said the key triggering phrase (extract from transcript speaker labels like "John Smith:" or "[Customer Name]")
- speakerEmail: The email if identifiable from the transcript
- Supporting context explaining why this qualifies as the specified intent (implemented vs discussed vs planned)`;


      const pass3LogId = await logPassStart(supabase, transcriptReviewId, 'activity_detection', 'Activity Signal Detection', 'enrichment');
      const pass3Start = Date.now();
      try {
        const pass3Response = await Promise.race([
          fetch(aiConfigLite.endpoint, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${aiConfigLite.apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: aiConfigLite.model,
              messages: [
                { role: "system", content: pass3Prompt },
                { role: "user", content: `Analyze:\n\n${truncatedForPass3}` }
              ],
              tools: [{
                type: "function",
                function: {
                  name: "match_rules",
                  description: "Match detection rules and deployment types",
                  parameters: pass3DetectionSchema
                }
              }],
              tool_choice: { type: "function", function: { name: "match_rules" } }
            }),
          }),
          new Promise((_, reject) => setTimeout(() => reject(new Error("Pass 3 timeout")), 90000))
        ]) as Response;

        if (pass3Response.ok) {
          const pass3Data = await pass3Response.json();
          pass3Result = JSON.parse(pass3Data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}");
          console.log(`[Enrichment] Pass 3 complete: ${pass3Result.detectionRuleMatches?.length || 0} rule matches`);
          await logPassEnd(supabase, pass3LogId, 'completed', pass3Start, {
            resultSummary: { ruleMatches: pass3Result.detectionRuleMatches?.length || 0, deploymentTypes: pass3Result.detectedDeploymentTypes?.length || 0 },
          });
        } else {
          const errText = await pass3Response.text().catch(() => '');
          await logPassEnd(supabase, pass3LogId, 'failed', pass3Start, { errorMessage: `HTTP ${pass3Response.status}: ${errText.substring(0, 500)}`, errorCategory: 'ai_error' });
        }
      } catch (err) {
        console.error("[Enrichment] Pass 3 failed:", err);
        await logPassEnd(supabase, pass3LogId, 'failed', pass3Start, {
          errorMessage: err instanceof Error ? err.message : String(err),
          errorCategory: (err instanceof Error && err.message.includes('timeout')) ? 'timeout' : 'ai_error',
        });
      }
    } else {
      console.log("[Enrichment] Skipping Pass 3 - no detection rules or deployment types configured");
    }

    // ========== PASS 3b: Product Detection (Pendo Products & Competitors) ==========
    const allProductRules = [...pendoProductRules, ...competitorDetectionRules];
    if (allProductRules.length > 0) {
      console.log(`[Enrichment] Pass 3b: Detecting Pendo products and competitors (${allProductRules.length} rules)...`);
      
      // Build keyword list for product detection
      const pass3bKeywords = allProductRules.flatMap((rule: any) => [
        ...(rule.trigger_phrases || []),
        ...(rule.context_qualifiers || [])
      ]).filter(Boolean);
      
      const truncatedForPass3b = smartTruncate(transcriptContent, 25000, pass3bKeywords);
      console.log(`[Enrichment] Truncated transcript to ${truncatedForPass3b.length} chars for Pass 3b`);
      
      // Build product rules section - simpler format for product detection
      const productRulesSection = allProductRules.map((rule: any) => {
        const isPendo = pendoProductRules.some((pr: any) => pr.id === rule.id);
        return `"${rule.name}" (ID: ${rule.id}, Type: ${isPendo ? 'PENDO PRODUCT' : 'COMPETITOR'}):
  Triggers: ${rule.trigger_phrases?.join(', ') || 'None'}
  Context: ${rule.context_qualifiers?.join(', ') || 'None'}
  Exclusions: ${rule.exclusion_phrases?.join(', ') || 'None'}`;
      }).join('\n\n');
      
      const pass3bPrompt = `Detect mentions of Pendo products and competitor products in this transcript.

For each product mentioned:
1. Match the detection rule if any trigger phrase is mentioned in context
2. Count how many distinct times it's mentioned (different conversation moments, not repeated phrases)
3. Extract a representative quote showing the mention

PRODUCT DETECTION RULES:
${productRulesSection}

IMPORTANT:
- Match based on semantic meaning, not just exact words
- "analytics", "dashboards", "usage data" should match the Analytics rule
- "guides", "walkthroughs", "tooltips", "in-app messaging" should match the Guides rule  
- "session replay", "replay", "recordings" should match Session Replay rule
- Count each distinct conversational mention, not duplicates of the same point
- For each mention, assess sentiment: how positively/negatively is the product being discussed?
  - sentimentScore: 0-100 (0=very negative, 50=neutral, 100=very positive)
  - sentimentLabel: positive/neutral/negative/mixed`;

      const pass3bSchema = {
        type: "object",
        properties: {
          detectionRuleMatches: {
            type: "array",
            items: {
              type: "object",
              properties: {
                ruleId: { type: "string" },
                matchedPhrases: { type: "array", items: { type: "string" } },
                occurrenceCount: { type: "number" },
                speakerType: { type: "string", enum: ["external", "internal", "unknown"] },
                speakerName: { type: "string" },
                speakerEmail: { type: "string" },
                context: { type: "string" },
                sentimentScore: { type: "number", description: "0-100 sentiment score (50=neutral, 100=very positive, 0=very negative)" },
                sentimentLabel: { type: "string", enum: ["positive", "neutral", "negative", "mixed"] }
              },
              required: ["ruleId", "occurrenceCount"]
            }
          }
        },
        required: ["detectionRuleMatches"]
      };

      const pass3bLogId = await logPassStart(supabase, transcriptReviewId, 'product_detection', 'Product Detection', 'enrichment');
      const pass3bStart = Date.now();
      try {
        const pass3bResponse = await Promise.race([
          fetch(aiConfigLite.endpoint, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${aiConfigLite.apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: aiConfigLite.model,
              messages: [
                { role: "system", content: pass3bPrompt },
                { role: "user", content: `Analyze for product mentions:\n\n${truncatedForPass3b}` }
              ],
              tools: [{
                type: "function",
                function: {
                  name: "detect_products",
                  description: "Detect Pendo product and competitor mentions",
                  parameters: pass3bSchema
                }
              }],
              tool_choice: { type: "function", function: { name: "detect_products" } }
            }),
          }),
          new Promise((_, reject) => setTimeout(() => reject(new Error("Pass 3b timeout")), 60000))
        ]) as Response;

        if (pass3bResponse.ok) {
          const pass3bData = await pass3bResponse.json();
          pass3bResult = JSON.parse(pass3bData.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}");
          console.log(`[Enrichment] Pass 3b complete: ${pass3bResult.detectionRuleMatches?.length || 0} product matches`);
          await logPassEnd(supabase, pass3bLogId, 'completed', pass3bStart, {
            resultSummary: { productMatches: pass3bResult.detectionRuleMatches?.length || 0 },
          });
        } else {
          const errText = await pass3bResponse.text().catch(() => '');
          await logPassEnd(supabase, pass3bLogId, 'failed', pass3bStart, { errorMessage: `HTTP ${pass3bResponse.status}: ${errText.substring(0, 500)}`, errorCategory: 'ai_error' });
        }
      } catch (err) {
        console.error("[Enrichment] Pass 3b failed:", err);
        await logPassEnd(supabase, pass3bLogId, 'failed', pass3bStart, {
          errorMessage: err instanceof Error ? err.message : String(err),
          errorCategory: (err instanceof Error && err.message.includes('timeout')) ? 'timeout' : 'ai_error',
        });
      }

      // Fallback: deterministic keyword matching when AI returns no product matches
      if (!Array.isArray(pass3bResult.detectionRuleMatches) || pass3bResult.detectionRuleMatches.length === 0) {
        const text = (transcriptContent || '').toLowerCase();
        const fallbackMatches: any[] = [];

        for (const rule of allProductRules) {
          const candidates = [
            ...(rule.trigger_phrases || []),
            ...(rule.context_qualifiers || []),
            rule.name,
          ]
            .map((p: string) => (p || '').toLowerCase().trim())
            .filter((p: string) => p.length >= 3);

          const matched = Array.from(new Set(candidates.filter((p: string) => text.includes(p))));
          if (matched.length === 0) continue;

          fallbackMatches.push({
            ruleId: rule.id,
            matchedPhrases: matched.slice(0, 5),
            occurrenceCount: matched.length,
            speakerType: 'unknown',
            context: 'Keyword fallback detection',
            sentimentScore: null,
            sentimentLabel: null,
          });
        }

        if (fallbackMatches.length > 0) {
          pass3bResult = { detectionRuleMatches: fallbackMatches };
          console.log(`[Enrichment] Pass 3b fallback produced ${fallbackMatches.length} product matches`);
        }
      }
    } else {
      console.log("[Enrichment] Skipping Pass 3b - no product detection rules configured");
    }

    // ========== PERSIST DETECTED DEPLOYMENT TYPES & EXPAND READINESS QUESTIONS ==========
    const detectedDTs = pass3Result.detectedDeploymentTypes || [];
    if (detectedDTs.length > 0 && opportunityId) {
      console.log(`[Enrichment] Persisting ${detectedDTs.length} detected deployment types for opportunity ${opportunityId}`);
      for (const dt of detectedDTs) {
        if (dt.deploymentTypeId && dt.confidence >= 0.5) {
          const { error: dtErr } = await supabase
            .from('opportunity_deployment_types')
            .upsert({
              opportunity_id: opportunityId,
              deployment_type_id: dt.deploymentTypeId,
            }, { onConflict: 'opportunity_id,deployment_type_id' });
          if (dtErr) {
            console.error(`[Enrichment] Failed to persist deployment type ${dt.deploymentTypeName}:`, dtErr.message);
          } else {
            console.log(`[Enrichment] Persisted deployment type: ${dt.deploymentTypeName} (confidence: ${dt.confidence})`);
          }
        }
      }

      // Expand readiness questions: re-include questions from newly detected deployment types
      // that were originally excluded by triage
      const newlyDetectedDTIds = new Set(
        detectedDTs
          .filter((dt: any) => dt.confidence >= 0.5 && dt.deploymentTypeId)
          .map((dt: any) => dt.deploymentTypeId)
      );
      const previouslySkipped = allReadinessQuestions.filter((q: any) => {
        const dtId = q.readiness_template_categories?.deployment_type_id;
        return dtId && skippedDeploymentTypeIds.has(dtId) && newlyDetectedDTIds.has(dtId);
      });
      if (previouslySkipped.length > 0) {
        console.log(`[Enrichment] Re-including ${previouslySkipped.length} readiness questions from detected deployment types`);
        readinessQuestions.push(...previouslySkipped);
        // Remove from skipped set so downstream logic is consistent
        for (const dtId of newlyDetectedDTIds) {
          skippedDeploymentTypeIds.delete(dtId as string);
        }
      }
    }

    // ========== PASSES 4, 5, 6: Run in parallel for performance ==========
    // These passes are independent of each other, so we can run them concurrently
    // to avoid edge function timeouts on long transcripts.
    
    // Extract competitor names from core analysis AND detection rule matches (needed for Pass 5)
    const coreCompetitors: string[] = existingInsights.competitorMentions || [];
    let detectionRuleCompetitors: string[] = [];
    if (transcriptReviewId) {
      const { data: competitiveMentions } = await supabase
        .from('product_mentions')
        .select('product_name')
        .eq('transcript_id', transcriptReviewId)
        .eq('mention_type', 'competitive');
      if (competitiveMentions?.length) {
        detectionRuleCompetitors = [...new Set(competitiveMentions.map((m: any) => m.product_name))];
      }
    }
    const seen = new Set<string>();
    const detectedCompetitors: string[] = [];
    for (const name of [...coreCompetitors, ...detectionRuleCompetitors]) {
      const lower = name.toLowerCase();
      if (!seen.has(lower)) {
        seen.add(lower);
        detectedCompetitors.push(name);
      }
    }

    // --- Define Pass 4 (Readiness) as an async function ---
    const runPass4 = async (): Promise<any> => {
      if (readinessQuestions.length === 0) {
        console.log("[Enrichment] Skipping Pass 4 - no readiness questions configured");
        return { readinessAnswers: [] };
      }
      console.log("[Enrichment] Pass 4: Technical readiness...");
      
      const readinessSection = readinessQuestions.slice(0, 50).map((q: any) => 
        `Q (ID: ${q.id}): ${q.question}`
      ).join('\n');

      const pass4Keywords = [
        'readiness', 'ready', 'prepared', 'requirement', 'integration',
        'security', 'compliance', 'architecture', 'infrastructure'
      ];
      const truncatedForPass4 = smartTruncate(transcriptContent, 30000, pass4Keywords);
      console.log(`[Enrichment] Truncated transcript to ${truncatedForPass4.length} chars for Pass 4`);

      const pass4Prompt = `Extract technical readiness answers from this transcript.

${coreContext}

READINESS QUESTIONS (answer if discussed):
${readinessSection}

For each question that is addressed in the transcript, extract the answer with supporting context.
Only include questions where the transcript contains a substantive answer or relevant discussion.`;

      try {
        const pass4Response = await Promise.race([
          fetch(aiConfigLite.endpoint, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${aiConfigLite.apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: aiConfigLite.model,
              messages: [
                { role: "system", content: pass4Prompt },
                { role: "user", content: `Analyze:\n\n${truncatedForPass4}` }
              ],
              tools: [{
                type: "function",
                function: {
                  name: "extract_readiness",
                  description: "Extract readiness answers and product mentions",
                  parameters: pass4ReadinessSchema
                }
              }],
              tool_choice: { type: "function", function: { name: "extract_readiness" } }
            }),
          }),
          new Promise((_, reject) => setTimeout(() => reject(new Error("Pass 4 timeout")), 180000))
        ]) as Response;

        if (pass4Response.ok) {
          const pass4Data = await pass4Response.json();
          const result = JSON.parse(pass4Data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}");
          console.log(`[Enrichment] Pass 4 complete: ${result.readinessAnswers?.length || 0} readiness answers`);
          return result;
        }
      } catch (err) {
        console.error("[Enrichment] Pass 4 failed:", err);
      }
      return { readinessAnswers: [] };
    };

    // --- Define Pass 5 (Competitive) as an async function ---
    const runPass5 = async (): Promise<any> => {
      const emptyResult = { competitorInsights: [], objections: [], winLossSignals: [], threatAssessment: null, competitivePlays: [] };
      if (detectedCompetitors.length === 0 || !opportunityId) {
        console.log("[Enrichment] Skipping Pass 5 - no competitors detected or no opportunity linked");
        return emptyResult;
      }
      console.log(`[Enrichment] Pass 5: Competitive analysis for ${detectedCompetitors.length} competitors: ${detectedCompetitors.join(', ')}`);
      
      let scorecardContext = '';
      let useCaseCtx = '';
      let differentials: any[] = [];
      try {
        differentials = await fetchScorecardDifferentials(supabaseUrl, supabaseKey, detectedCompetitors);
        scorecardContext = formatScorecardContext(differentials);
        console.log(`[Enrichment] Scorecard context: ${scorecardContext.length} chars for ${differentials.length} competitors`);
        const useCases = await fetchUseCasesForCompetitive(supabaseUrl, supabaseKey, accountId, opportunityId, differentials);
        useCaseCtx = formatUseCaseContext(useCases);
        console.log(`[Enrichment] Use case context: ${useCaseCtx.length} chars for ${useCases.length} use cases`);
      } catch (err) {
        console.error('[Enrichment] Failed to fetch competitive context:', err);
      }
      
      const { data: compPass } = await supabase
        .from('analysis_passes')
        .select('system_prompt, output_schema')
        .eq('pass_key', 'competitive_analysis')
        .eq('status', 'active')
        .single();
      
      const compPrompt = compPass?.system_prompt || `Analyze this transcript for competitive intelligence.
Extract competitor mentions, objections, win/loss signals, and recommend competitive plays.`;
      
      const pass5Schema = {
        type: "object",
        properties: {
          competitorInsights: {
            type: "array",
            items: {
              type: "object",
              properties: {
                competitorName: { type: "string" },
                mentionType: { type: "string", enum: ["evaluation", "incumbent", "risk", "replacement_target", "comparison"] },
                speakerType: { type: "string", enum: ["internal", "external", "unknown"] },
                speakerName: { type: "string" },
                sentiment: { type: "string", enum: ["positive", "neutral", "negative", "mixed"] },
                context: { type: "string" },
                featureDiscussed: { type: "string" },
                pendoPosition: { type: "string", enum: ["stronger", "weaker", "equal", "unknown"] },
                comparisonNotes: { type: "string" }
              },
              required: ["competitorName", "mentionType", "speakerType", "sentiment", "context"]
            }
          },
          objections: {
            type: "array",
            items: {
              type: "object",
              properties: {
                objectionType: { type: "string", enum: ["pricing", "feature_gap", "integration", "support", "security", "scalability", "implementation", "other"] },
                severity: { type: "string", enum: ["high", "medium", "low"] },
                objectionText: { type: "string" },
                relatedCompetitor: { type: "string" },
                speakerType: { type: "string", enum: ["internal", "external", "unknown"] }
              },
              required: ["objectionType", "severity", "objectionText"]
            }
          },
          winLossSignals: {
            type: "array",
            items: {
              type: "object",
              properties: {
                signalType: { type: "string", enum: ["win", "loss"] },
                indicator: { type: "string" },
                relatedCompetitor: { type: "string" },
                confidence: { type: "number" }
              },
              required: ["signalType", "indicator", "confidence"]
            }
          },
          threatAssessment: {
            type: "object",
            properties: {
              overallThreatLevel: { type: "string", enum: ["high", "medium", "low", "none"] },
              threatScore: { type: "number" },
              primaryThreat: { type: "string" }
            },
            required: ["overallThreatLevel", "threatScore"]
          },
          competitivePlays: {
            type: "array",
            items: {
              type: "object",
              properties: {
                competitorName: { type: "string" },
                playType: { type: "string", enum: ["landmine", "differentiation", "objection_handler", "feature_highlight", "case_study"] },
                playStrategy: { type: "string", enum: ["attack", "defend"] },
                playTitle: { type: "string" },
                playDescription: { type: "string" },
                talkingPoints: { type: "array", items: { type: "string" } },
                relevantCategories: { type: "array", items: { type: "string" } },
                linkedUseCaseIds: { type: "array", items: { type: "string" } },
                pendoAdvantageScore: { type: "number" },
                competitorWeaknessScore: { type: "number" },
                confidenceScore: { type: "number" }
              },
              required: ["competitorName", "playType", "playStrategy", "playTitle", "playDescription", "talkingPoints", "confidenceScore"]
            }
          }
        },
        required: ["competitorInsights", "objections", "winLossSignals", "threatAssessment", "competitivePlays"]
      };
      
      let enhancedCompPrompt = compPrompt;
      if (scorecardContext) enhancedCompPrompt += `\n\n${scorecardContext}`;
      if (useCaseCtx) enhancedCompPrompt += `\n\n${useCaseCtx}`;
      if (scorecardContext || useCaseCtx) {
        enhancedCompPrompt += `\n\nIMPORTANT: Generate competitive plays informed by BOTH scorecard differentials AND customer use cases:
- ATTACK plays: For use cases where Pendo is stronger — create "landmine" and "differentiation" plays to expand the conversation
- DEFEND plays: For use cases where competitor is stronger — create "objection_handler" plays that build a moat, reframe the narrative, and redirect to Pendo strengths
- Link each play to relevant use case IDs via "linkedUseCaseIds"
- Set "playStrategy" to "attack" or "defend" based on alignment
- Include the relevant subcategory names in "relevantCategories"
- Set pendoAdvantageScore and competitorWeaknessScore from the scorecard data where applicable
- Generate at least one play per detected competitor with scorecard data`;
      }
      
      const compKeywords = [...detectedCompetitors, 'competitor', 'versus', 'compared', 'alternative', 'evaluate', 'objection', 'concern', 'pricing', 'feature'];
      const truncatedForComp = smartTruncate(transcriptContent, 25000, compKeywords);
      
      try {
        const pass5Response = await Promise.race([
          fetch(aiConfigLite.endpoint, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${aiConfigLite.apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: aiConfigLite.model,
              messages: [
                { role: "system", content: enhancedCompPrompt },
                { role: "user", content: `${coreContext}\n\nDetected competitors: ${detectedCompetitors.join(', ')}\n\nAnalyze:\n\n${truncatedForComp}` }
              ],
              tools: [{
                type: "function",
                function: {
                  name: "extract_competitive",
                  description: "Extract competitive intelligence and generate plays",
                  parameters: pass5Schema
                }
              }],
              tool_choice: { type: "function", function: { name: "extract_competitive" } }
            }),
          }),
          new Promise((_, reject) => setTimeout(() => reject(new Error("Pass 5 timeout")), 90000))
        ]) as Response;

        if (pass5Response.ok) {
          const pass5Data = await pass5Response.json();
          const result = JSON.parse(pass5Data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}");
          console.log(`[Enrichment] Pass 5 complete: ${result.competitorInsights?.length || 0} insights, ${result.objections?.length || 0} objections, ${result.competitivePlays?.length || 0} plays`);
          return result;
        }
      } catch (err) {
        console.error("[Enrichment] Pass 5 failed:", err);
      }
      return emptyResult;
    };

    // --- Define Pass 6 (Success Criteria) as an async function ---
    const runPass6 = async (): Promise<any> => {
      if (!opportunityId) return { successCriteria: [] };
      console.log(`[Enrichment] Pass 6: Success criteria extraction...`);
      
      const { data: existingUseCases } = await supabase
        .from('account_use_cases')
        .select('id, use_case, functional_area, acceptance_status')
        .eq('opportunity_id', opportunityId);
      
      const ucContext = (existingUseCases || []).map((uc: any) => 
        `UC (ID: ${uc.id}): ${uc.use_case} [Area: ${uc.functional_area || 'unset'}]`
      ).join('\n');
      
      const { data: existingCriteria } = await supabase
        .from('evaluation_success_criteria')
        .select('id, criterion, status, source')
        .eq('opportunity_id', opportunityId);
      
      const existingCriteriaList = (existingCriteria || []);
      const existingCriteriaNames = existingCriteriaList.map((c: any) => c.criterion.toLowerCase());
      const existingCriteriaContext = existingCriteriaList.map((c: any) => 
        `- [ID: ${c.id}] "${c.criterion}" (status: ${c.status})`
      ).join('\n');
      
      const pass6Schema = {
        type: "object",
        properties: {
          successCriteria: {
            type: "array",
            items: {
              type: "object",
              properties: {
                criterion: { type: "string", description: "High-level success criterion title (e.g. 'Analytics coverage vs. WhatFix/PowerBI gaps')" },
                metricName: { type: "string", description: "Optional measurable metric" },
                targetValue: { type: "string", description: "Optional target for the metric" },
                linkedUseCaseIds: { type: "array", items: { type: "string" }, description: "IDs of related use cases from the provided list" },
                deliverables: {
                  type: "array",
                  items: { type: "string" },
                  description: "Specific measurable tasks/demos/proofs needed to satisfy this criterion"
                },
                notes: { type: "string", description: "Context from the conversation explaining why this is important" },
                consolidatesExistingId: { type: "string", description: "If this criterion consolidates an existing one, set this to the existing criterion's ID. Leave empty for new criteria." }
              },
              required: ["criterion", "deliverables"]
            }
          }
        },
        required: ["successCriteria"]
      };
      
      const pass6Prompt = `Extract evaluation success criteria and their specific deliverables from this transcript.

SUCCESS CRITERIA are high-level measurable outcomes the customer needs to see proven during an evaluation/trial/POC.
DELIVERABLES are the specific demonstrations, reports, configurations, or proofs needed to satisfy each criterion.

Examples:
- Criterion: "Analytics coverage vs. WhatFix gaps"
  Deliverables: ["Track feature usage at user and segment level", "Demonstrate funnel/path analysis for core workflows", "Show ability to segment by region and role"]
- Criterion: "Time-to-value measurement"
  Deliverables: ["Measure time between key events for users", "Show how UI changes correlate to completion rate changes"]

EXISTING USE CASES (link criteria to these where relevant):
${ucContext || 'None defined yet'}

EXISTING CRITERIA (do NOT create duplicates — if a new criterion is semantically similar to one below, set consolidates_existing_id to its ID instead):
${existingCriteriaContext || 'None yet'}

IMPORTANT:
- Only extract criteria that are explicitly discussed or implied as evaluation goals
- Each criterion should have at least 1-2 specific deliverables
- Link to existing use case IDs where the criterion maps to a known use case
- Include context notes explaining the customer's motivation
- If the conversation reinforces an existing criterion, consolidate by setting consolidates_existing_id
- Only create new criteria for genuinely new evaluation goals not covered above`;
      
      const criteriaKeywords = ['success', 'criteria', 'evaluate', 'prove', 'demonstrate', 'show', 'track', 'measure', 'goal', 'outcome', 'requirement', 'deliverable', 'acceptance'];
      const truncatedForPass6 = smartTruncate(transcriptContent, 30000, criteriaKeywords);
      
      try {
        const pass6Response = await Promise.race([
          fetch(aiConfigLite.endpoint, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${aiConfigLite.apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: aiConfigLite.model,
              messages: [
                { role: "system", content: pass6Prompt },
                { role: "user", content: `${coreContext}\n\nExtract success criteria:\n\n${truncatedForPass6}` }
              ],
              tools: [{
                type: "function",
                function: {
                  name: "extract_criteria",
                  description: "Extract success criteria with deliverables",
                  parameters: pass6Schema
                }
              }],
              tool_choice: { type: "function", function: { name: "extract_criteria" } }
            }),
          }),
          new Promise((_, reject) => setTimeout(() => reject(new Error("Pass 6 timeout")), 90000))
        ]) as Response;

        if (pass6Response.ok) {
          const pass6Data = await pass6Response.json();
          const result = JSON.parse(pass6Data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}");
          console.log(`[Enrichment] Pass 6 complete: ${result.successCriteria?.length || 0} success criteria extracted`);
          return result;
        }
      } catch (err) {
        console.error("[Enrichment] Pass 6 failed:", err);
      }
      return { successCriteria: [] };
    };

    // ========== Run Passes 4, 5, 6 in PARALLEL with logging ==========
    console.log("[Enrichment] Running Passes 4, 5, 6 in parallel...");
    
    const runPassWithLog = async (
      passKey: string, passName: string, fn: () => Promise<any>, summaryExtractor: (r: any) => any
    ) => {
      const logId = await logPassStart(supabase, transcriptReviewId, passKey, passName, 'enrichment');
      const startTime = Date.now();
      try {
        const result = await fn();
        await logPassEnd(supabase, logId, 'completed', startTime, { resultSummary: summaryExtractor(result) });
        return result;
      } catch (err) {
        await logPassEnd(supabase, logId, 'failed', startTime, {
          errorMessage: err instanceof Error ? err.message : String(err),
          errorCategory: (err instanceof Error && err.message.includes('timeout')) ? 'timeout' : 'ai_error',
        });
        throw err;
      }
    };
    
    const [pass4Settled, pass5Settled, pass6Settled] = await Promise.allSettled([
      runPassWithLog('readiness_extraction', 'Technical Readiness', runPass4, (r) => ({ answers: r.readinessAnswers?.length || 0 })),
      runPassWithLog('competitive_analysis', 'Competitive Analysis', runPass5, (r) => ({ insights: r.competitorInsights?.length || 0, plays: r.competitivePlays?.length || 0 })),
      runPassWithLog('success_criteria', 'Success Criteria', runPass6, (r) => ({ criteria: r.successCriteria?.length || 0 })),
    ]);
    
    pass4Result = pass4Settled.status === 'fulfilled' ? pass4Settled.value : { readinessAnswers: [] };
    const pass5Result = pass5Settled.status === 'fulfilled' ? pass5Settled.value : { competitorInsights: [], objections: [], winLossSignals: [], threatAssessment: null, competitivePlays: [] };
    const pass6Result = pass6Settled.status === 'fulfilled' ? pass6Settled.value : { successCriteria: [] };
    
    console.log(`[Enrichment] Parallel passes complete - P4: ${pass4Result.readinessAnswers?.length || 0} readiness, P5: ${pass5Result.competitorInsights?.length || 0} competitive, P6: ${pass6Result.successCriteria?.length || 0} criteria`);

    // Combine Pass 3 and Pass 3b detection rule matches, deduplicating by ruleId
    const rawDetectionMatches = [
      ...(pass3Result.detectionRuleMatches || []),
      ...(pass3bResult.detectionRuleMatches || [])
    ];
    const seenRuleIds = new Set<string>();
    const allDetectionMatches = rawDetectionMatches.filter((m: any) => {
      if (seenRuleIds.has(m.ruleId)) return false;
      seenRuleIds.add(m.ruleId);
      return true;
    });

    // Merge enrichment results into existing insights
    const enrichedInsights = {
      ...existingInsights,
      detectionRuleMatches: allDetectionMatches,
      detectedDeploymentTypes: pass3Result.detectedDeploymentTypes || [],
      readinessAnswers: pass4Result.readinessAnswers || [],
      productMentions: pass4Result.productMentions || [],
      triageResults: Object.keys(triageResults).length > 0 ? triageResults : undefined,
      competitiveAnalysis: {
        competitorInsights: pass5Result.competitorInsights || [],
        objections: pass5Result.objections || [],
        winLossSignals: pass5Result.winLossSignals || [],
        threatAssessment: pass5Result.threatAssessment,
        competitivePlays: pass5Result.competitivePlays || [],
      }
    };

    // Update transcript with enrichment results and cache hash
    const { error: updateError } = await supabase
      .from("transcript_reviews")
      .update({
        extracted_insights: enrichedInsights,
        enrichment_status: "complete",
        enrichment_completed_at: new Date().toISOString(),
        enrichment_error: null,
        content_hash: currentHash,
        last_enriched_hash: currentHash
      })
      .eq("id", transcriptReviewId);

    if (updateError) {
      throw updateError;
    }

    // Save detection rule matches to dedicated table (includes both activity signals and product detections)
    if (allDetectionMatches.length > 0) {
      console.log(`[Enrichment] Saving ${allDetectionMatches.length} detection rule matches (activity + products)`);
      
      // Fetch opportunity stage info for context capture
      let crmStage: number | null = null;
      let preSalesStage: number | null = null;
      
      if (opportunityId) {
        const { data: oppData } = await supabase
          .from("opportunities")
          .select("sales_stage, pre_sales_stage")
          .eq("id", opportunityId)
          .single();
        
        if (oppData) {
          // Map sales_stage to CEP stage number
          const stageMapping: Record<string, number> = {
            stage_0: 0, stage_1: 1, stage_2: 2, stage_3: 3, 
            stage_4: 4, stage_5: 5, stage_5_sales_won: 5, 
            stage_6: 6, stage_6_closed_won: 6
          };
          crmStage = stageMapping[oppData.sales_stage] ?? null;
          preSalesStage = stageMapping[oppData.pre_sales_stage] ?? null;
        }
      }
      
      for (const match of allDetectionMatches) {
        // First, upsert the main detection match record
        // Use the meeting date (eventOccurredAt) for first_detected_at, not the analysis time
        const { data: matchData, error: matchError } = await supabase
          .from("detection_rule_matches")
          .upsert({
            transcript_id: transcriptReviewId,
            rule_id: match.ruleId,
            confidence_score: match.confidence,
            matched_phrases: match.matchedPhrases,
            opportunity_id: opportunityId,
            first_detected_at: eventOccurredAt,
            crm_stage_at_detection: crmStage,
            pre_sales_stage_at_detection: preSalesStage,
            speaker_type: match.speakerType || 'unknown',
            speaker_name: match.speakerName || null,
            speaker_email: match.speakerEmail || null,
            sentiment_score: match.sentimentScore ?? null,
            sentiment_label: match.sentimentLabel ?? null,
            occurrence_count: match.occurrenceCount ?? 1,
          }, {
            onConflict: "transcript_id,rule_id",
            ignoreDuplicates: false
          })
          .select("id")
          .single();
        
        if (matchError) {
          console.error(`[Enrichment] Failed to save match for rule ${match.ruleId}:`, matchError);
          continue;
        }
        
        // Also record this as a signal occurrence for historical tracking
        // Use the meeting date (eventOccurredAt) for detected_at
        if (matchData?.id) {
          const { error: occurrenceError } = await supabase
            .from("signal_occurrences")
            .insert({
              match_id: matchData.id,
              transcript_id: transcriptReviewId,
              detected_at: eventOccurredAt,
              crm_stage: crmStage,
              pre_sales_stage: preSalesStage,
              matched_phrases: match.matchedPhrases,
              speaker_type: match.speakerType || 'unknown',
              speaker_name: match.speakerName || null,
              confidence_score: match.confidence
            });
          
          if (occurrenceError) {
            console.error(`[Enrichment] Failed to save signal occurrence:`, occurrenceError);
          }
        }
        
        // Process unified rule actions for this match
        const { data: ruleActions } = await supabase
          .from('detection_rule_actions')
          .select('id, action_type, action_config, target_entity, is_active, legacy_capture_field_id')
          .eq('rule_id', match.ruleId)
          .eq('is_active', true)
          .order('sort_order');
        
        for (const action of ruleActions || []) {
          const config = (action as any).action_config as Record<string, any>;
          
          switch ((action as any).action_type) {
            case 'create_task': {
              // Create or update validation task from template
              if (config.template_id && opportunityId) {
                const { data: template } = await supabase
                  .from('validation_task_templates')
                  .select('*')
                  .eq('id', config.template_id)
                  .single();
                
                if (template) {
                  const { data: existingTask } = await supabase
                    .from('opportunity_validation_tasks')
                    .select('id, status')
                    .eq('opportunity_id', opportunityId)
                    .eq('template_id', (template as any).id)
                    .maybeSingle();
                  
                  if (!existingTask) {
                    // Create new task
                    const initialStatus = config.auto_update_status || 'not_started';
                    await supabase.from('opportunity_validation_tasks').insert({
                      opportunity_id: opportunityId,
                      template_id: (template as any).id,
                      module: (template as any).module,
                      sub_module: (template as any).sub_module,
                      activity: (template as any).activity,
                      status: initialStatus,
                      owner: (template as any).default_owner,
                      sort_order: (template as any).sort_order,
                      completed_at: initialStatus === 'completed' ? new Date().toISOString() : null,
                    });
                    console.log(`[Enrichment] Created validation task: ${(template as any).activity} (status: ${initialStatus})`);
                  } else if (config.auto_update_status && (existingTask as any).status !== config.auto_update_status) {
                    // Update existing task status if auto_update_status is configured
                    const updateData: Record<string, any> = { status: config.auto_update_status };
                    if (config.auto_update_status === 'completed') {
                      updateData.completed_at = new Date().toISOString();
                    }
                    await supabase.from('opportunity_validation_tasks')
                      .update(updateData)
                      .eq('id', (existingTask as any).id);
                    console.log(`[Enrichment] Updated validation task status: ${(template as any).activity} → ${config.auto_update_status}`);
                  }
                }
              }
              break;
            }
            
            case 'answer_question': {
              // Auto-populate readiness answers
              // If auto_answer is provided, use it; otherwise mark question as needing AI extraction
              if (config.question_id && opportunityId) {
                // Check if existing answer is confirmed (locked)
                const { data: existingAnswer } = await supabase
                  .from('opportunity_readiness_answers')
                  .select('id, answer, last_confirmed_at, confidence_score')
                  .eq('opportunity_id', opportunityId)
                  .eq('question_id', config.question_id)
                  .maybeSingle();
                
                const newAnswer = config.auto_answer || `Detected: ${match.ruleName}`;
                const newConfidence = match.confidence || 70;
                
                if (existingAnswer?.last_confirmed_at) {
                  // Answer is confirmed/locked - check if new value differs and queue for review
                  if (existingAnswer.answer !== newAnswer) {
                    // Record pending change for review
                    await supabase.from('technical_readiness_history').insert({
                      opportunity_id: opportunityId,
                      question_id: config.question_id,
                      old_answer: { answer: existingAnswer.answer, confidence: existingAnswer.confidence_score },
                      new_answer: { answer: newAnswer, confidence: newConfidence },
                      old_score: existingAnswer.confidence_score,
                      new_score: newConfidence,
                      change_source: 'detection_rule',
                      source_transcript_id: transcriptReviewId,
                    });
                    console.log(`[Enrichment] Queued readiness change for review (locked answer): ${match.ruleName}`);
                  }
                } else if (existingAnswer && newConfidence <= (existingAnswer.confidence_score || 0)) {
                  // Existing answer with higher or equal confidence - skip
                  console.log(`[Enrichment] Skipping readiness answer (existing confidence higher): ${match.ruleName}`);
                } else {
                  // No existing answer OR new confidence is higher - upsert
                  // First record history if updating existing
                  if (existingAnswer) {
                    await supabase.from('technical_readiness_history').insert({
                      opportunity_id: opportunityId,
                      question_id: config.question_id,
                      old_answer: { answer: existingAnswer.answer, confidence: existingAnswer.confidence_score },
                      new_answer: { answer: newAnswer, confidence: newConfidence },
                      old_score: existingAnswer.confidence_score,
                      new_score: newConfidence,
                      change_source: 'detection_rule',
                      source_transcript_id: transcriptReviewId,
                    });
                  }
                  
                  await supabase.from('opportunity_readiness_answers').upsert({
                    opportunity_id: opportunityId,
                    question_id: config.question_id,
                    answer: newAnswer,
                    answer_json: config.auto_answer_json,
                    confidence_score: newConfidence,
                    source: 'detection_rule',
                    source_transcript_id: transcriptReviewId,
                    notes: `Auto-populated from rule match: ${match.ruleName}`,
                  }, { onConflict: 'opportunity_id,question_id' });
                  console.log(`[Enrichment] Auto-answered readiness question from rule: ${match.ruleName}`);
                }
              }
              break;
            }
            
            case 'extract_data': {
              // Save captured insights from AI extraction
              const fieldName = config.field_name;
              const capturedValue = (match as any).capturedFields?.[fieldName];
              if (capturedValue && accountId) {
                const captureFieldId = (action as any).legacy_capture_field_id || (action as any).id;
                const insightData = {
                  account_id: accountId,
                  opportunity_id: opportunityId,
                  capture_field_id: captureFieldId,
                  rule_match_id: matchId,
                  source_transcript_id: transcriptReviewId,
                  value: typeof capturedValue === 'string' ? capturedValue : null,
                  value_json: typeof capturedValue === 'object' ? capturedValue : null,
                  confidence_score: match.confidence || 0.7,
                };
                const insResult = await supabase.from('account_captured_insights').insert(insightData as any);
                if (insResult.error) {
                  console.error(`[Enrichment] Failed to save captured insight:`, insResult.error.message);
                } else {
                  console.log(`[Enrichment] Captured insight: ${fieldName}`);
                }
              }
              break;
            }
          }
        }
      }
      console.log("[Enrichment] Detection rule matches and actions saved successfully");
    }

    // Save readiness answers (enrichment logic: only update if higher confidence AND not confirmed)
    if (pass4Result.readinessAnswers?.length > 0 && opportunityId) {
      const questionIds = pass4Result.readinessAnswers.map((a: any) => a.questionId);
      
      // Fetch existing answers to compare confidence and check confirmation status
      const { data: existingAnswers } = await supabase
        .from("opportunity_readiness_answers")
        .select("question_id, answer, confidence_score, last_confirmed_at")
        .eq("opportunity_id", opportunityId)
        .in("question_id", questionIds);
      
      const existingMap = new Map(
        (existingAnswers || []).map((a: any) => [a.question_id, a])
      );
      
      for (const answer of pass4Result.readinessAnswers) {
        const existing = existingMap.get(answer.questionId);
        const existingConfidence = existing?.confidence_score ?? -1;
        const newConfidence = answer.confidence ?? 0;
        const isConfirmed = !!existing?.last_confirmed_at;
        
        if (isConfirmed && existing?.answer !== answer.answer) {
          // Answer is confirmed/locked and value differs - queue for review (don't overwrite)
          await supabase.from("technical_readiness_history").insert({
            opportunity_id: opportunityId,
            question_id: answer.questionId,
            old_answer: { answer: existing.answer, confidence: existingConfidence },
            new_answer: { answer: answer.answer, confidence: newConfidence, context: answer.context },
            old_score: existingConfidence,
            new_score: newConfidence,
            change_source: "ai_enrichment",
            source_transcript_id: transcriptReviewId,
          });
          console.log(`[Enrichment] Queued readiness change for review (locked): ${answer.questionId}`);
        } else if (existingConfidence < 0) {
          // No existing answer - insert new (don't auto-confirm)
          await supabase.from("opportunity_readiness_answers").insert({
            opportunity_id: opportunityId,
            question_id: answer.questionId,
            answer: answer.answer,
            confidence_score: newConfidence,
            source: "ai_enrichment",
            source_transcript_id: transcriptReviewId,
            notes: `AI extracted (${newConfidence}% confidence): "${answer.context?.substring(0, 200) || ''}"`,
          });
        } else if (newConfidence > existingConfidence) {
          // Higher confidence - record history then overwrite
          await supabase.from("technical_readiness_history").insert({
            opportunity_id: opportunityId,
            question_id: answer.questionId,
            old_answer: { answer: existing.answer, confidence: existingConfidence },
            new_answer: { answer: answer.answer, confidence: newConfidence, context: answer.context },
            old_score: existingConfidence,
            new_score: newConfidence,
            change_source: "ai_enrichment",
            source_transcript_id: transcriptReviewId,
          });
          
          await supabase
            .from("opportunity_readiness_answers")
            .update({
              answer: answer.answer,
              confidence_score: newConfidence,
              source: "ai_enrichment",
              source_transcript_id: transcriptReviewId,
              notes: `AI extracted (${newConfidence}% confidence): "${answer.context?.substring(0, 200) || ''}"`,
            })
            .eq("opportunity_id", opportunityId)
            .eq("question_id", answer.questionId);
        }
        // If same or lower confidence, skip update entirely
      }
      
      console.log(`[Enrichment] Processed ${pass4Result.readinessAnswers.length} readiness answers with confidence-based enrichment`);
    }

    // Product mentions are now handled exclusively by Pass 3b → detection_rule_matches trigger
    // (sync_detection_match_to_product_mention) which deduplicates per transcript+technology_id

    // ========== Save competitive insights and plays (from Pass 5) ==========
    if (pass5Result.competitorInsights?.length > 0 && opportunityId && accountId) {
      console.log(`[Enrichment] Saving ${pass5Result.competitorInsights.length} competitive insights`);
      
      // Fetch existing insights for this transcript to prevent duplicates
      const { data: existingInsights } = await supabase
        .from('opportunity_competitive_insights')
        .select('competitor_name, mention_type, objection_text')
        .eq('opportunity_id', opportunityId)
        .eq('transcript_id', transcriptReviewId);
      
      const existingInsightKeys = new Set(
        (existingInsights || []).map((e: any) => `${e.competitor_name}|${e.mention_type}|${e.objection_text || ''}`)
      );
      
      // Look up competitor IDs from technology_repository
      const competitorNamesList = [...new Set(pass5Result.competitorInsights.map((ci: any) => ci.competitorName))];
      const { data: competitorLookup } = await supabase
        .from('technology_repository')
        .select('id, name')
        .eq('is_competitor', true)
        .in('name', competitorNamesList);
      
      const competitorIdMap = new Map(
        (competitorLookup || []).map((c: any) => [c.name.toLowerCase(), c.id])
      );
      
      for (const insight of pass5Result.competitorInsights) {
        const competitorId = competitorIdMap.get(insight.competitorName?.toLowerCase()) || null;
        
        // Find related objection for this competitor
        const relatedObjection = pass5Result.objections?.find(
          (o: any) => o.relatedCompetitor?.toLowerCase() === insight.competitorName?.toLowerCase()
        );
        
        // Dedup check
        const insightKey = `${insight.competitorName}|${insight.mentionType || 'comparison'}|${relatedObjection?.objectionText || ''}`;
        if (existingInsightKeys.has(insightKey)) {
          console.log(`[Enrichment] Skipping duplicate insight: ${insightKey}`);
          continue;
        }
        existingInsightKeys.add(insightKey);
        
        // Find related win/loss signals
        const relatedWinSignal = pass5Result.winLossSignals?.find(
          (s: any) => s.signalType === 'win' && s.relatedCompetitor?.toLowerCase() === insight.competitorName?.toLowerCase()
        );
        const relatedLossSignal = pass5Result.winLossSignals?.find(
          (s: any) => s.signalType === 'loss' && s.relatedCompetitor?.toLowerCase() === insight.competitorName?.toLowerCase()
        );
        
        await supabase.from('opportunity_competitive_insights').insert({
          opportunity_id: opportunityId,
          account_id: accountId,
          transcript_id: transcriptReviewId,
          competitor_id: competitorId,
          competitor_name: insight.competitorName,
          mention_context: insight.context,
          mention_type: insight.mentionType || 'comparison',
          speaker_type: insight.speakerType || 'unknown',
          speaker_name: insight.speakerName || null,
          sentiment: insight.sentiment || 'neutral',
          feature_discussed: insight.featureDiscussed || null,
          pendo_position: insight.pendoPosition || null,
          comparison_notes: insight.comparisonNotes || null,
          is_objection: !!relatedObjection,
          objection_type: relatedObjection?.objectionType || null,
          objection_severity: relatedObjection?.severity || null,
          objection_text: relatedObjection?.objectionText || null,
          win_signal: !!relatedWinSignal,
          loss_signal: !!relatedLossSignal,
          signal_indicator: relatedWinSignal?.indicator || relatedLossSignal?.indicator || null,
          confidence_score: 0.7,
          evidence_source: 'transcript_analysis',
          evidence_confidence_weight: 1.0,
        });
      }
      console.log(`[Enrichment] Saved ${pass5Result.competitorInsights.length} competitive insights`);
    }
    
    // Save competitive plays
    if (pass5Result.competitivePlays?.length > 0 && opportunityId) {
      console.log(`[Enrichment] Saving ${pass5Result.competitivePlays.length} competitive plays`);
      
      // Fetch existing plays for dedup
      const { data: existingPlays } = await supabase
        .from('competitive_plays')
        .select('competitor_name, play_type, play_title')
        .eq('opportunity_id', opportunityId);
      
      const existingPlayKeys = new Set(
        (existingPlays || []).map((e: any) => `${e.competitor_name}|${e.play_type}|${e.play_title}`)
      );
      
      const competitorNamesList = [...new Set(pass5Result.competitivePlays.map((p: any) => p.competitorName))];
      const { data: competitorLookup } = await supabase
        .from('technology_repository')
        .select('id, name')
        .eq('is_competitor', true)
        .in('name', competitorNamesList);
      
      const competitorIdMap = new Map(
        (competitorLookup || []).map((c: any) => [c.name.toLowerCase(), c.id])
      );
      
      for (const play of pass5Result.competitivePlays) {
        const competitorId = competitorIdMap.get(play.competitorName?.toLowerCase()) || null;
        
        // Dedup check
        const playKey = `${play.competitorName}|${play.playType}|${play.playTitle}`;
        if (existingPlayKeys.has(playKey)) {
          console.log(`[Enrichment] Skipping duplicate play: ${playKey}`);
          continue;
        }
        existingPlayKeys.add(playKey);
        
        const { error: playInsertError } = await supabase.from('competitive_plays').insert({
          opportunity_id: opportunityId,
          account_id: accountId,
          competitor_id: competitorId,
          competitor_name: play.competitorName,
          play_type: play.playType,
          play_title: play.playTitle,
          play_description: play.playDescription || null,
          talking_points: play.talkingPoints || [],
          relevant_categories: play.relevantCategories || [],
          linked_use_case_ids: play.linkedUseCaseIds || [],
          pendo_advantage_score: play.pendoAdvantageScore || null,
          competitor_weakness_score: play.competitorWeaknessScore || null,
          confidence_score: play.confidenceScore || 0.7,
          play_strategy: play.playStrategy || 'attack',
          status: 'suggested',
          source_transcript_id: transcriptReviewId,
        });
        if (playInsertError) {
          console.error(`[Enrichment] Failed to save play "${play.playTitle}":`, playInsertError);
        }
      }
      console.log(`[Enrichment] Saved ${pass5Result.competitivePlays.length} competitive plays`);
    }

    // ========== Save AI-proposed success criteria (from Pass 6) ==========
    if (pass6Result.successCriteria?.length > 0 && opportunityId) {
      console.log(`[Enrichment] Saving ${pass6Result.successCriteria.length} proposed success criteria`);
      
      // Re-fetch existing criteria (may have changed since Pass 6 prompt was built)
      const { data: refreshedCriteria } = await supabase
        .from('evaluation_success_criteria')
        .select('id, criterion, status, source')
        .eq('opportunity_id', opportunityId);
      const latestCriteriaList = refreshedCriteria || existingCriteriaList;
      const existingIdSet = new Set(latestCriteriaList.map((c: any) => c.id));
      const existingNames = new Set(
        latestCriteriaList.map((c: any) => c.criterion.toLowerCase().trim())
      );
      
      for (const sc of pass6Result.successCriteria) {
        const consolidateId = sc.consolidatesExistingId;
        let criterionId: string | null = null;

        if (consolidateId && existingIdSet.has(consolidateId)) {
          // UPDATE existing criterion with enriched notes
          console.log(`[Enrichment] Consolidating into existing criterion ${consolidateId}: "${sc.criterion}"`);
          const { error: updateError } = await supabase
            .from('evaluation_success_criteria')
            .update({
              criterion: sc.criterion,
              metric_name: sc.metricName || undefined,
              target_value: sc.targetValue || undefined,
              notes: sc.notes || undefined,
              linked_use_case_ids: sc.linkedUseCaseIds?.length > 0 ? sc.linkedUseCaseIds : undefined,
            })
            .eq('id', consolidateId);
          
          if (updateError) {
            console.error(`[Enrichment] Failed to consolidate criterion "${sc.criterion}":`, updateError);
          } else {
            criterionId = consolidateId;
          }
        } else {
          // Exact-match dedup check (fallback)
          if (existingNames.has(sc.criterion?.toLowerCase()?.trim())) {
            console.log(`[Enrichment] Skipping exact duplicate criterion: ${sc.criterion}`);
            continue;
          }
          existingNames.add(sc.criterion?.toLowerCase()?.trim());
          
          // Insert criterion as 'proposed' status
          const { data: inserted, error: scError } = await supabase
            .from('evaluation_success_criteria')
            .insert({
              opportunity_id: opportunityId,
              criterion: sc.criterion,
              metric_name: sc.metricName || null,
              target_value: sc.targetValue || null,
              status: 'proposed',
              source: 'ai_proposed',
              source_transcript_id: transcriptReviewId,
              linked_use_case_ids: sc.linkedUseCaseIds?.length > 0 ? sc.linkedUseCaseIds : null,
              notes: sc.notes || null,
            })
            .select('id')
            .single();
          
          if (scError) {
            console.error(`[Enrichment] Failed to save criterion "${sc.criterion}":`, scError);
            continue;
          }
          criterionId = inserted?.id;
        }
        
        // Insert deliverables
        if (criterionId && sc.deliverables?.length > 0) {
          const deliverableRows = sc.deliverables.map((title: string, i: number) => ({
            criterion_id: criterionId,
            title,
            sort_order: i,
            is_completed: false,
          }));
          const { error: delError } = await supabase
            .from('success_criteria_deliverables')
            .insert(deliverableRows);
          if (delError) {
            console.error(`[Enrichment] Failed to save deliverables for "${sc.criterion}":`, delError);
          }
        }
      }
      console.log(`[Enrichment] Saved proposed success criteria`);
    }

    // ========== MATERIALIZE USE CASES & PAIN POINTS from core analysis ==========
    // The core analysis (stored in existingInsights) extracts use cases and pain points,
    // but they were only being saved to extracted_insights JSON, not to the actual tables.
    const coreUseCases = existingInsights.useCases || existingInsights.insights?.useCases || [];
    const corePainPoints = existingInsights.painPoints || existingInsights.insights?.painPoints || [];
    const encryptionKeyForInsights = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY') || '';

    if ((coreUseCases.length > 0 || corePainPoints.length > 0) && accountId) {
      console.log(`[Enrichment] Materializing ${coreUseCases.length} use cases, ${corePainPoints.length} pain points to tables`);

      // Helper to encrypt a string value
      async function encryptValueForInsight(value: string, key: string): Promise<{ ciphertext: string; iv: string }> {
        const keyBytes = deriveKeyBytes(key);
        const cryptoKey = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt"]);
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const plainBytes = new TextEncoder().encode(value);
        const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, cryptoKey, plainBytes);
        const toBinary = (bytes: Uint8Array) => { let b = ""; for (let i = 0; i < bytes.length; i++) b += String.fromCharCode(bytes[i]); return btoa(b); };
        return { ciphertext: toBinary(new Uint8Array(cipherBytes)), iv: toBinary(iv) };
      }

      // Save use cases
      for (const uc of coreUseCases) {
        const ucText = typeof uc === 'string' ? uc : (uc.description || uc.name || uc.useCase || String(uc));
        if (!ucText || ucText.length < 5) continue;

        const functionalArea = typeof uc === 'object' ? (uc.functionalArea || 'General') : 'General';
        const priority = typeof uc === 'object' ? (uc.priority || 'medium') : 'medium';
        const businessTheme = typeof uc === 'object' ? uc.businessTheme : null;
        const confidence = typeof uc === 'object' ? uc.confidence : null;

        if (encryptionKeyForInsights) {
          const { ciphertext, iv } = await encryptValueForInsight(ucText, encryptionKeyForInsights);
          await supabase.from("account_use_cases").insert({
            account_id: accountId,
            opportunity_id: opportunityId || null,
            use_case: null,
            use_case_encrypted: ciphertext,
            encryption_iv: iv,
            is_encrypted: true,
            functional_area: functionalArea,
            business_theme: businessTheme,
            status: 'identified',
            priority,
            confidence_score: confidence,
            source: 'transcript_analysis',
            source_transcript_id: transcriptReviewId,
            created_at: eventOccurredAt,
          });
        } else {
          await supabase.from("account_use_cases").insert({
            account_id: accountId,
            opportunity_id: opportunityId || null,
            use_case: ucText,
            functional_area: functionalArea,
            business_theme: businessTheme,
            status: 'identified',
            priority,
            confidence_score: confidence,
            source: 'transcript_analysis',
            source_transcript_id: transcriptReviewId,
            created_at: eventOccurredAt,
          });
        }
      }

      // Save pain points
      for (const pp of corePainPoints) {
        const ppText = typeof pp === 'string' ? pp : (pp.description || pp.pain_point || String(pp));
        if (!ppText || ppText.length < 5) continue;

        const painCategory = typeof pp === 'object' ? (pp.painCategory || 'operational_friction') : 'operational_friction';
        const severity = typeof pp === 'object' ? (pp.severity || 'medium') : 'medium';
        const businessTheme = typeof pp === 'object' ? pp.businessTheme : null;
        const confidence = typeof pp === 'object' ? pp.confidence : null;

        if (encryptionKeyForInsights) {
          const { ciphertext, iv } = await encryptValueForInsight(ppText, encryptionKeyForInsights);
          await supabase.from("account_pain_points").insert({
            account_id: accountId,
            opportunity_id: opportunityId || null,
            pain_point: null,
            pain_point_encrypted: ciphertext,
            encryption_iv: iv,
            is_encrypted: true,
            pain_category: painCategory,
            severity,
            business_theme: businessTheme,
            confidence_score: confidence,
            source: 'transcript_analysis',
            source_transcript_id: transcriptReviewId,
            created_at: eventOccurredAt,
          });
        } else {
          await supabase.from("account_pain_points").insert({
            account_id: accountId,
            opportunity_id: opportunityId || null,
            pain_point: ppText,
            pain_category: painCategory,
            severity,
            business_theme: businessTheme,
            confidence_score: confidence,
            source: 'transcript_analysis',
            source_transcript_id: transcriptReviewId,
            created_at: eventOccurredAt,
          });
        }
      }

      console.log(`[Enrichment] Materialized use cases and pain points to tables`);
    }

    // ========== STAKEHOLDER SCORING: Create meeting snapshots & update contacts ==========
    const coreAnalysisPeople = existingInsights.people || [];
    if (coreAnalysisPeople.length > 0 && accountId) {
      console.log(`[Enrichment] Processing ${coreAnalysisPeople.length} stakeholders for scoring...`);
      
      const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');
      
      // Fetch existing contacts with encrypted fields for matching
      const { data: existingContacts } = await supabase
        .from('account_contacts')
        .select('id, name_encrypted, email_encrypted, encryption_iv, is_encrypted, is_internal, champion_score, sentiment, influence_level, stakeholder_type')
        .eq('account_id', accountId)
        .eq('is_ignored', false);
      
      // Decrypt contact names/emails for matching
      const decryptedContacts: Array<{ id: string; name: string; email: string; isInternal: boolean; championScore: number | null; sentiment: number | null; influenceLevel: number | null; stakeholderType: string | null }> = [];
      
      for (const contact of (existingContacts || [])) {
        let name = '';
        let email = '';
        
        if (contact.is_encrypted && contact.encryption_iv && encryptionKey) {
          try {
            if (contact.name_encrypted) {
              name = await decryptWithFallbackKeys(contact.name_encrypted, contact.encryption_iv);
            }
            if (contact.email_encrypted) {
              email = await decryptWithFallbackKeys(contact.email_encrypted, contact.encryption_iv);
            }
          } catch (decErr) {
            console.warn(`[Enrichment] Failed to decrypt contact ${contact.id}:`, decErr);
          }
        }
        
        decryptedContacts.push({
          id: contact.id,
          name: name.toLowerCase().trim(),
          email: email.toLowerCase().trim(),
          isInternal: contact.is_internal || false,
          championScore: contact.champion_score,
          sentiment: contact.sentiment,
          influenceLevel: contact.influence_level,
          stakeholderType: contact.stakeholder_type,
        });
      }
      
      let snapshotsCreated = 0;
      let contactsUpdated = 0;
      
      for (const person of coreAnalysisPeople) {
        if (person.isInternal) continue; // Skip internal team members
        
        const personName = (person.name || '').toLowerCase().trim();
        const personEmail = (person.email || '').toLowerCase().trim();
        
        if (!personName && !personEmail) continue;
        
        // Match contact: email first (exact), then name (fuzzy)
        let matchedContact = decryptedContacts.find(c => 
          !c.isInternal && personEmail && c.email && c.email === personEmail
        );
        
        if (!matchedContact && personName) {
          // Fuzzy name match: check if names share significant overlap
          matchedContact = decryptedContacts.find(c => {
            if (c.isInternal || !c.name) return false;
            // Exact name match
            if (c.name === personName) return true;
            // First+last name match (handle "Aleksandra S" vs "Aleksandra Smith")
            const cParts = c.name.split(/\s+/);
            const pParts = personName.split(/\s+/);
            if (cParts[0] === pParts[0] && cParts.length > 1 && pParts.length > 1) {
              // First names match, check if last names start the same
              return cParts[cParts.length - 1].startsWith(pParts[pParts.length - 1].substring(0, 3)) ||
                     pParts[pParts.length - 1].startsWith(cParts[cParts.length - 1].substring(0, 3));
            }
            return false;
          });
        }
        
        if (!matchedContact) {
          console.log(`[Enrichment] No contact match for "${person.name}" — skipping snapshot`);
          continue;
        }
        
        // Extract scores from AI analysis
        const newSentiment = typeof person.sentiment === 'number' ? person.sentiment : null;
        const newInfluence = typeof person.influenceLevel === 'number' ? person.influenceLevel : null;
        const newChampion = typeof person.championScore === 'number' ? person.championScore : null;
        const newEngagement = typeof person.engagementScore === 'number' ? person.engagementScore : null;
        
        // Skip if no meaningful scores extracted
        if (newSentiment === null && newInfluence === null && newChampion === null) {
          console.log(`[Enrichment] No scores for "${person.name}" — skipping`);
          continue;
        }
        
        // Create meeting snapshot for trajectory tracking
        const snapshotData: Record<string, any> = {
          contact_id: matchedContact.id,
          transcript_id: transcriptReviewId,
          meeting_date: eventOccurredAt,
          opportunity_id: opportunityId || null,
          champion_score: newChampion,
          sentiment: newSentiment,
          influence_level: newInfluence,
          engagement_score: newEngagement,
          meeting_type: transcript.meeting_type || 'call',
          topics_discussed: person.topicsDiscussed || null,
          key_quotes: person.advocacySignals?.examples || null,
          concerns_raised: person.concerns || null,
          notes: person.context || null,
        };
        
        // Encrypt sensitive fields if key available
        if (encryptionKey) {
          const fieldsToEncrypt = ['key_quotes', 'concerns_raised', 'topics_discussed', 'notes'];
          for (const field of fieldsToEncrypt) {
            if (snapshotData[field]) {
              try {
                const valueStr = typeof snapshotData[field] === 'string' 
                  ? snapshotData[field] 
                  : JSON.stringify(snapshotData[field]);
                const { ciphertext, iv } = await (async (val: string) => {
                  const keyBytes = deriveKeyBytes(encryptionKey);
                  const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt"]);
                  const ivBytes = crypto.getRandomValues(new Uint8Array(12));
                  const plainBytes = new TextEncoder().encode(val);
                  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv: ivBytes }, key, plainBytes);
                  const binary = Array.from(new Uint8Array(cipherBytes)).map(b => String.fromCharCode(b)).join('');
                  const ivBinary = Array.from(ivBytes).map(b => String.fromCharCode(b)).join('');
                  return { ciphertext: btoa(binary), iv: btoa(ivBinary) };
                })(valueStr);
                snapshotData[`${field}_encrypted`] = ciphertext;
                snapshotData.encryption_iv = snapshotData.encryption_iv || iv;
                snapshotData.is_encrypted = true;
                snapshotData[field] = null; // Clear plaintext
              } catch (encErr) {
                console.warn(`[Enrichment] Failed to encrypt ${field}:`, encErr);
              }
            }
          }
        }
        
        // Check for existing snapshot for same contact + transcript (dedup)
        const { data: existingSnapshot } = await supabase
          .from('contact_meeting_snapshots')
          .select('id')
          .eq('contact_id', matchedContact.id)
          .eq('transcript_id', transcriptReviewId)
          .maybeSingle();
        
        if (existingSnapshot) {
          // Update existing snapshot
          const { error: snapUpdateErr } = await supabase
            .from('contact_meeting_snapshots')
            .update(snapshotData)
            .eq('id', existingSnapshot.id);
          if (snapUpdateErr) {
            console.error(`[Enrichment] Failed to update snapshot for "${person.name}":`, snapUpdateErr);
          } else {
            snapshotsCreated++;
          }
        } else {
          // Insert new snapshot
          const { error: snapInsertErr } = await supabase
            .from('contact_meeting_snapshots')
            .insert(snapshotData);
          if (snapInsertErr) {
            console.error(`[Enrichment] Failed to create snapshot for "${person.name}":`, snapInsertErr);
          } else {
            snapshotsCreated++;
          }
        }
        
        // Update current contact record with latest scores (progressive enrichment)
        const updateData: Record<string, any> = {
          updated_at: new Date().toISOString(),
          last_assessed_at: new Date().toISOString(),
          assessment_source: 'ai_analysis',
        };
        
        // Only update scores if they improve or were previously unset
        if (newChampion !== null && (matchedContact.championScore === null || newChampion > matchedContact.championScore)) {
          updateData.champion_score = newChampion;
        }
        if (newSentiment !== null) {
          // Sentiment always reflects the latest reading (not highest-wins)
          updateData.sentiment = newSentiment;
        }
        if (newInfluence !== null && (matchedContact.influenceLevel === null || newInfluence > matchedContact.influenceLevel)) {
          updateData.influence_level = newInfluence;
        }
        if (person.stakeholderType && person.stakeholderType !== 'unknown') {
          updateData.stakeholder_type = person.stakeholderType;
        }
        
        // Update advocacy signals
        if (person.advocacySignals) {
          updateData.advocacy_signals = person.advocacySignals;
        }
        if (person.infoSharingSignals) {
          updateData.info_sharing_signals = person.infoSharingSignals;
        }
        
        const { error: contactUpdateErr } = await supabase
          .from('account_contacts')
          .update(updateData)
          .eq('id', matchedContact.id);
        
        if (contactUpdateErr) {
          console.error(`[Enrichment] Failed to update contact scores for "${person.name}":`, contactUpdateErr);
        } else {
          contactsUpdated++;
          console.log(`[Enrichment] Updated "${person.name}": sentiment=${newSentiment}, influence=${newInfluence}, champion=${newChampion}`);
        }
      }
      
      console.log(`[Enrichment] Stakeholder scoring complete: ${snapshotsCreated} snapshots, ${contactsUpdated} contacts updated`);
    }

    console.log(`[Enrichment] Complete for ${transcriptReviewId}`);

    // Trigger real-time alert evaluation for this opportunity (non-blocking)
    if (opportunityId) {
      console.log(`[Enrichment] Triggering alert evaluation for opportunity ${opportunityId}`);
      fetch(`${supabaseUrl}/functions/v1/evaluate-opportunity-alerts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
        },
        body: JSON.stringify({ opportunityId }),
      }).catch(err => console.error('[Enrichment] Alert evaluation trigger failed:', err));

      // Classify meeting type if not already set (e.g. manual imports that skipped unified-transcript-analysis)
      let currentMeetingType = transcript.meeting_type;
      if (!currentMeetingType && transcriptContent) {
        console.log(`[Enrichment] meeting_type is null — running lightweight classification...`);
        try {
          const classifyConfig = await getAIConfig('lite');
          const classifySample = transcriptContent.substring(0, 4000);
          const classifyResponse = await Promise.race([
            fetch(classifyConfig.endpoint, {
              method: "POST",
              headers: {
                Authorization: `Bearer ${classifyConfig.apiKey}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                model: classifyConfig.model,
                messages: [
                  { role: "system", content: `Classify this meeting transcript into exactly one of these types: Discovery, Demo, POC, Technical Deep-Dive, Business Review, Kickoff, Training, Check-in, Negotiation, Executive Briefing, Workshop, Integration Review, Renewal, Support. Respond with ONLY the type name, nothing else.` },
                  { role: "user", content: classifySample }
                ],
                max_tokens: 20,
              }),
            }),
            new Promise((_, reject) => setTimeout(() => reject(new Error("Classification timeout")), 15000))
          ]) as Response;

          if (classifyResponse.ok) {
            const classifyData = await classifyResponse.json();
            const classified = classifyData.choices?.[0]?.message?.content?.trim();
            if (classified) {
              currentMeetingType = classified;
              // Persist to DB
              await supabase
                .from('transcript_reviews')
                .update({ meeting_type: classified, meeting_type_confidence: 0.8 })
                .eq('id', transcriptReviewId);
              console.log(`[Enrichment] Classified meeting as "${classified}" and persisted`);
            }
          }
        } catch (classifyErr) {
          console.error('[Enrichment] Meeting classification failed:', classifyErr);
        }
      }

      // Auto-trigger SE coaching analysis if a coaching pass exists in the pipeline with matching meeting type
      const { data: coachingPass } = await supabase
        .from('analysis_passes')
        .select('id, condition_config')
        .eq('pass_key', 'se_coaching')
        .eq('status', 'active')
        .single();
      
      if (coachingPass) {
        const allowedTypes: string[] = (coachingPass.condition_config as any)?.meeting_types || [];
        
        if (currentMeetingType && allowedTypes.includes(currentMeetingType)) {
          console.log(`[Enrichment] Auto-triggering SE coaching for ${currentMeetingType} meeting (pass condition met)`);
          fetch(`${supabaseUrl}/functions/v1/analyze-se-coaching`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${supabaseKey}` },
            body: JSON.stringify({ transcriptId: transcriptReviewId, meetingType: currentMeetingType }),
          }).catch(err => console.error('[Enrichment] SE coaching trigger failed:', err));
        } else {
          console.log(`[Enrichment] Skipping SE coaching — meeting_type="${currentMeetingType}" not in allowed: ${allowedTypes.join(', ')}`);
        }
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        detectionRuleMatches: pass3Result.detectionRuleMatches?.length || 0,
        readinessAnswers: pass4Result.readinessAnswers?.length || 0,
        productMentions: pass4Result.productMentions?.length || 0,
        competitiveInsights: pass5Result.competitorInsights?.length || 0,
        competitivePlays: pass5Result.competitivePlays?.length || 0,
        successCriteria: pass6Result.successCriteria?.length || 0,
        stakeholderSnapshots: coreAnalysisPeople.length > 0 ? coreAnalysisPeople.filter((p: any) => !p.isInternal).length : 0,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("[Enrichment] Error:", error);

    // Try to mark as failed
    try {
      const { transcriptReviewId } = await req.clone().json();
      if (transcriptReviewId) {
        await supabase
          .from("transcript_reviews")
          .update({
            enrichment_status: "failed",
            enrichment_error: error instanceof Error ? error.message : "Unknown error"
          })
          .eq("id", transcriptReviewId);
      }
    } catch {}

    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

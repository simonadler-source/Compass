import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface AlertRule {
  id: string;
  name: string;
  rule_type: string;
  threshold_config: Record<string, any>;
  nba_action_text: string;
  nba_priority: string;
  nba_delivery_method: string;
  assigned_to_type: string;
  cooldown_days: number;
  is_active: boolean;
  owner_id: string | null;
}

interface Opportunity {
  id: string;
  name: string;
  account_id: string;
  readiness_score: number | null;
  stage: string | null;
  stage_changed_at: string | null;
  primary_se_email: string | null;
  owner_email: string | null;
  value: number | null;
  competitive_threat_score: number | null;
  competitive_threat_level: string | null;
  pre_sales_stage: string | null;
  sales_stage: string | null;
  account_se_email?: string | null;
  account_owner_id?: string | null;
}

interface EvaluationResult {
  opportunityId: string;
  opportunityName: string;
  ruleId: string;
  ruleName: string;
  triggered: boolean;
  reason?: string;
  nbaCreated?: boolean;
  signalDetails?: any[];
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    const body = await req.json().catch(() => ({}));
    const { opportunityId, dryRun = false } = body;

    console.log(`Starting alert evaluation. OpportunityId: ${opportunityId || 'all'}, DryRun: ${dryRun}`);

    // Fetch active alert rules
    const { data: rules, error: rulesError } = await supabase
      .from('opportunity_alert_rules')
      .select('*')
      .eq('is_active', true)
      .order('sort_order', { ascending: true });

    if (rulesError) {
      console.error('Error fetching rules:', rulesError);
      throw new Error(`Failed to fetch rules: ${rulesError.message}`);
    }

    console.log(`Found ${rules?.length || 0} active rules`);

    // Fetch opportunities with account info - EXCLUDE archived opportunities
    let oppsQuery = supabase
      .from('opportunities')
      .select(`
        id, name, account_id, readiness_score, stage, stage_changed_at, 
        primary_se_email, owner_email, is_archived, value,
        competitive_threat_score, competitive_threat_level,
        pre_sales_stage, sales_stage,
        accounts!inner(id, name, primary_se_email, owner_id, relationship_status)
      `)
      .or('is_archived.is.null,is_archived.eq.false'); // Only evaluate non-archived opportunities

    if (opportunityId) {
      oppsQuery = oppsQuery.eq('id', opportunityId);
    }

    const { data: opportunities, error: oppsError } = await oppsQuery;

    if (oppsError) {
      console.error('Error fetching opportunities:', oppsError);
      throw new Error(`Failed to fetch opportunities: ${oppsError.message}`);
    }

    // Filter out opportunities from whitespace_only accounts (unless it's a whitespace-specific rule)
    const activeOpportunities = (opportunities || []).filter((opp: any) => {
      const account = opp.accounts as any;
      // Skip opportunities from whitespace_only accounts for non-whitespace rules
      if (account?.relationship_status === 'whitespace_only') {
        return false;
      }
      return true;
    });

    console.log(`Evaluating ${activeOpportunities.length} active opportunities (excluded ${(opportunities?.length || 0) - activeOpportunities.length} archived/whitespace-only)`);

    const results: EvaluationResult[] = [];
    const nbasToCreate: any[] = [];
    const historyToCreate: any[] = [];

    for (const opp of activeOpportunities) {
      const account = opp.accounts as any;
      const enrichedOpp: Opportunity = {
        ...opp,
        account_se_email: account?.primary_se_email,
        account_owner_id: account?.owner_id,
      };

      for (const rule of rules || []) {
        // Check if rule should exclude archived (default true)
        const excludeArchived = rule.exclude_archived !== false;
        if (excludeArchived && opp.is_archived) {
          continue; // Skip archived opportunities for this rule
        }

        const result = await evaluateRule(supabase, rule, enrichedOpp);
        
        if (result.triggered) {
          // Check cooldown
          const cooldownDate = new Date();
          cooldownDate.setDate(cooldownDate.getDate() - rule.cooldown_days);

          const { data: recentAlert } = await supabase
            .from('opportunity_alert_history')
            .select('id')
            .eq('rule_id', rule.id)
            .eq('opportunity_id', opp.id)
            .gte('triggered_at', cooldownDate.toISOString())
            .limit(1);

          if (recentAlert && recentAlert.length > 0) {
            console.log(`Rule ${rule.name} for ${opp.name} is in cooldown period`);
            results.push({
              ...result,
              triggered: false,
              reason: `In cooldown (last triggered within ${rule.cooldown_days} days)`,
            });
            continue;
          }

          // Determine assignee
          const assignee = getAssignee(enrichedOpp, rule.assigned_to_type, rule.owner_id);

          // Only create NBA if nba_action_text is defined and not empty
          const hasNbaAction = rule.nba_action_text && rule.nba_action_text.trim().length > 0;
          
          if (!dryRun) {
            // Only create NBA when action text is defined
            if (hasNbaAction) {
              nbasToCreate.push({
                account_id: opp.account_id,
                opportunity_id: opp.id,
                action: rule.nba_action_text,
                action_type: 'alert',
                priority: rule.nba_priority,
                delivery_method: rule.nba_delivery_method,
                assigned_to: assignee,
                status: 'pending',
                notes: `Auto-generated by alert rule: ${rule.name}`,
              });
            }

            // Always create history for triggered alerts (for email digest, tracking, etc.)
            historyToCreate.push({
              rule_id: rule.id,
              opportunity_id: opp.id,
              trigger_data: {
                reason: result.reason || null,
                rule_type: rule.rule_type,
                rule_name: rule.name,
                signalDetails: (result as any).signalDetails || null,
              },
            });
          }

          results.push({
            ...result,
            nbaCreated: !dryRun && hasNbaAction,
          });
        } else {
          results.push(result);
        }
      }
    }

    // Batch insert NBAs (if any)
    if (!dryRun && nbasToCreate.length > 0) {
      console.log(`Creating ${nbasToCreate.length} NBAs...`);
      
      // Insert one-by-one to skip duplicates (unique constraint on action text)
      let createdCount = 0;
      for (const nba of nbasToCreate) {
        const { error: nbaError } = await supabase
          .from('account_nbas')
          .insert(nba)
          .select('id');

        if (nbaError) {
          if (nbaError.message?.includes('idx_account_nbas_no_duplicates') || nbaError.code === '23505') {
            console.log(`Skipping duplicate NBA: ${nba.action?.substring(0, 60)}`);
          } else {
            console.error('Error creating NBA:', nbaError);
          }
        } else {
          createdCount++;
        }
      }

      console.log(`Created ${createdCount} NBAs (${nbasToCreate.length - createdCount} duplicates skipped)`);
    }

    // Batch insert history records (even without NBAs - for email digest, etc.)
    if (!dryRun && historyToCreate.length > 0) {
      console.log(`Creating ${historyToCreate.length} alert history records...`);

      const { error: historyError } = await supabase
        .from('opportunity_alert_history')
        .insert(historyToCreate);

      if (historyError) {
        console.error('Error creating history:', historyError);
        // Don't throw - history is for tracking
      }

      console.log(`Created ${historyToCreate.length} history records`);
    }

    const triggeredCount = results.filter(r => r.triggered).length;
    console.log(`Evaluation complete. ${triggeredCount} alerts triggered.`);

    return new Response(JSON.stringify({
      success: true,
      dryRun,
      opportunitiesEvaluated: opportunities?.length || 0,
      rulesEvaluated: rules?.length || 0,
      alertsTriggered: triggeredCount,
      nbasCreated: dryRun ? 0 : nbasToCreate.length,
      results: results.filter(r => r.triggered),
    }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });

  } catch (error: any) {
    console.error("Error in evaluate-opportunity-alerts:", error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: error.message 
    }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  }
};

async function evaluateRule(
  supabase: any, 
  rule: AlertRule, 
  opp: Opportunity
): Promise<EvaluationResult> {
  const baseResult = {
    opportunityId: opp.id,
    opportunityName: opp.name,
    ruleId: rule.id,
    ruleName: rule.name,
    triggered: false,
  };

  const config = rule.threshold_config;

  switch (rule.rule_type) {
    case 'readiness_below_threshold': {
      const minScore = config.minScore || 30;
      const score = opp.readiness_score ?? 0;
      if (score < minScore) {
        return {
          ...baseResult,
          triggered: true,
          reason: `Readiness score ${score}% is below threshold ${minScore}%`,
        };
      }
      break;
    }

    case 'stalled_stage': {
      const maxDays = config.maxDays || 30;
      if (opp.stage_changed_at) {
        const stageDate = new Date(opp.stage_changed_at);
        const daysSinceChange = Math.floor((Date.now() - stageDate.getTime()) / (1000 * 60 * 60 * 24));
        if (daysSinceChange >= maxDays) {
          return {
            ...baseResult,
            triggered: true,
            reason: `Stage unchanged for ${daysSinceChange} days (threshold: ${maxDays})`,
          };
        }
      }
      break;
    }

    case 'missing_stakeholders': {
      const requiredRoles: string[] = config.requiredRoles || [];
      if (requiredRoles.length > 0) {
        const { data: contacts } = await supabase
          .from('account_contacts')
          .select('stakeholder_type')
          .eq('opportunity_id', opp.id)
          .in('stakeholder_type', requiredRoles);

        const foundRoles = new Set((contacts || []).map((c: any) => c.stakeholder_type));
        const missingRoles = requiredRoles.filter(role => !foundRoles.has(role));

        if (missingRoles.length > 0) {
          return {
            ...baseResult,
            triggered: true,
            reason: `Missing stakeholder roles: ${missingRoles.join(', ')}`,
          };
        }
      }
      break;
    }

    case 'unanswered_questions_count': {
      const category = config.category;
      const maxUnanswered = config.maxUnanswered || 3;

      // Get readiness questions for this category
      let questionsQuery = supabase
        .from('readiness_questions')
        .select('id')
        .eq('is_active', true);

      if (category) {
        questionsQuery = questionsQuery.eq('category', category);
      }

      const { data: questions } = await questionsQuery;
      const questionIds = (questions || []).map((q: any) => q.id);

      if (questionIds.length > 0) {
        // Get answered questions for this opportunity
        const { data: answers } = await supabase
          .from('opportunity_readiness_answers')
          .select('question_id, answer, answer_encrypted')
          .eq('opportunity_id', opp.id)
          .in('question_id', questionIds);

        const answeredIds = new Set(
          (answers || [])
            .filter((a: any) => a.answer || a.answer_encrypted)
            .map((a: any) => a.question_id)
        );

        const unansweredCount = questionIds.length - answeredIds.size;

        if (unansweredCount > maxUnanswered) {
          return {
            ...baseResult,
            triggered: true,
            reason: `${unansweredCount} unanswered ${category || ''} questions (threshold: ${maxUnanswered})`,
          };
        }
      }
      break;
    }

    case 'stale_readiness': {
      const maxDays = config.maxDays || 14;
      
      // Check last readiness answer update
      const { data: recentAnswer } = await supabase
        .from('opportunity_readiness_answers')
        .select('updated_at')
        .eq('opportunity_id', opp.id)
        .order('updated_at', { ascending: false })
        .limit(1);

      if (!recentAnswer || recentAnswer.length === 0) {
        return {
          ...baseResult,
          triggered: true,
          reason: `No readiness answers recorded`,
        };
      }

      const lastUpdate = new Date(recentAnswer[0].updated_at);
      const daysSinceUpdate = Math.floor((Date.now() - lastUpdate.getTime()) / (1000 * 60 * 60 * 24));

      if (daysSinceUpdate >= maxDays) {
        return {
          ...baseResult,
          triggered: true,
          reason: `Readiness not updated for ${daysSinceUpdate} days (threshold: ${maxDays})`,
        };
      }
      break;
    }

    case 'no_recent_meetings': {
      const maxDays = config.maxDays || 21;
      
      // Check last meeting for this account via momentum_meetings or transcript created_at
      const { data: recentMeeting } = await supabase
        .from('momentum_meetings')
        .select('start_time')
        .eq('matched_account_id', opp.account_id)
        .not('start_time', 'is', null)
        .order('start_time', { ascending: false })
        .limit(1);

      // If no momentum meetings, fall back to transcript_reviews created_at
      let lastMeetingDate: Date | null = null;
      
      if (recentMeeting && recentMeeting.length > 0 && recentMeeting[0].start_time) {
        lastMeetingDate = new Date(recentMeeting[0].start_time);
      } else {
        // Fallback: check transcript_reviews by final_account_id
        const { data: recentTranscript } = await supabase
          .from('transcript_reviews')
          .select('created_at')
          .eq('final_account_id', opp.account_id)
          .order('created_at', { ascending: false })
          .limit(1);
        
        if (recentTranscript && recentTranscript.length > 0) {
          lastMeetingDate = new Date(recentTranscript[0].created_at);
        }
      }

      if (!lastMeetingDate) {
        return {
          ...baseResult,
          triggered: true,
          reason: `No meetings recorded for this account`,
        };
      }

      const daysSinceMeeting = Math.floor((Date.now() - lastMeetingDate.getTime()) / (1000 * 60 * 60 * 24));

      if (daysSinceMeeting >= maxDays) {
        return {
          ...baseResult,
          triggered: true,
          reason: `No meetings for ${daysSinceMeeting} days (threshold: ${maxDays})`,
        };
      }
      break;
    }

    case 'advanced': {
      // Advanced rules use the visual condition builder
      const conditions = config.conditions;
      if (!conditions?.groups || conditions.groups.length === 0) {
        break;
      }

      const groupResults: boolean[] = [];
      const triggerReasons: string[] = [];

      for (const group of conditions.groups) {
        const conditionResults: boolean[] = [];
        
        for (const cond of group.conditions || []) {
          const result = await evaluateAdvancedCondition(supabase, opp, cond);
          conditionResults.push(result.triggered);
          if (result.triggered && result.reason) {
            triggerReasons.push(result.reason);
          }
        }

        // Apply group operator (AND/OR)
        const groupResult = group.operator === 'OR'
          ? conditionResults.some(r => r)
          : conditionResults.every(r => r);
        
        groupResults.push(groupResult);
        
        // Collect signal details from condition results
        for (const cond of group.conditions || []) {
          const condResult = await evaluateAdvancedCondition(supabase, opp, cond);
          if (condResult.signalDetails) {
            (baseResult as any).signalDetails = condResult.signalDetails;
          }
        }
      }

      // Apply groupOperator across all groups
      const finalResult = conditions.groupOperator === 'OR'
        ? groupResults.some(r => r)
        : groupResults.every(r => r);

      if (finalResult) {
        return {
          ...baseResult,
          triggered: true,
          reason: triggerReasons.join('; ') || 'Advanced conditions met',
        };
      }
      break;
    }

    default:
      console.log(`Unknown rule type: ${rule.rule_type}`);
  }

  return baseResult;
}

async function evaluateAdvancedCondition(
  supabase: any,
  opp: Opportunity,
  condition: any
): Promise<{ triggered: boolean; reason?: string; signalDetails?: any[] }> {
  const { field, operator, value, dateRangeConfig } = condition;

  switch (field) {
    case 'readiness_score': {
      const score = opp.readiness_score ?? 0;
      const threshold = Number(value) || 0;
      
      if (operator === 'less_than' && score < threshold) {
        return { triggered: true, reason: `Readiness ${score}% < ${threshold}%` };
      }
      if (operator === 'greater_than' && score > threshold) {
        return { triggered: true, reason: `Readiness ${score}% > ${threshold}%` };
      }
      if (operator === 'equals' && score === threshold) {
        return { triggered: true, reason: `Readiness equals ${threshold}%` };
      }
      break;
    }

    case 'days_in_stage': {
      if (opp.stage_changed_at) {
        const stageDate = new Date(opp.stage_changed_at);
        const days = Math.floor((Date.now() - stageDate.getTime()) / (1000 * 60 * 60 * 24));
        const threshold = Number(value) || 0;
        
        if (operator === 'greater_than' && days > threshold) {
          return { triggered: true, reason: `In stage for ${days} days (>${threshold})` };
        }
        if (operator === 'less_than' && days < threshold) {
          return { triggered: true, reason: `In stage for ${days} days (<${threshold})` };
        }
      }
      break;
    }

    case 'any_signal_detected_since': {
      // Check for detection rule matches within the specified date range
      let sinceDate: Date | null = null;

      if (dateRangeConfig?.type === 'rolling_days') {
        const days = dateRangeConfig.days || 7;
        sinceDate = new Date();
        sinceDate.setDate(sinceDate.getDate() - days);
      } else if (dateRangeConfig?.type === 'calendar_range') {
        sinceDate = dateRangeConfig.start ? new Date(dateRangeConfig.start) : null;
      } else if (dateRangeConfig?.type === 'since_last_digest') {
        // Default to 24 hours ago for daily digest
        sinceDate = new Date();
        sinceDate.setHours(sinceDate.getHours() - 24);
      }

      if (sinceDate) {
        const { data: matches, error } = await supabase
          .from('detection_rule_matches')
          .select('id, created_at, transcript_id, detection_rules!inner(name, signal_field_name)')
          .eq('opportunity_id', opp.id)
          .gte('created_at', sinceDate.toISOString())
          .limit(10);

        if (!error && matches && matches.length > 0) {
          // Build detailed signal information
          const signalDetails: any[] = matches.map((m: any) => ({
            name: m.detection_rules?.name || m.detection_rules?.signal_field_name,
            detected_at: m.created_at,
            transcript_id: m.transcript_id,
          }));
          const signalNames = [...new Set(signalDetails.map((s: any) => s.name))];
          return { 
            triggered: true, 
            reason: `${matches.length} signal(s) detected: ${signalNames.slice(0, 3).join(', ')}${signalNames.length > 3 ? '...' : ''}`,
            signalDetails, // Include detailed signal info for email
          };
        }
      }
      break;
    }

    case 'signal_detected': {
      // Check for specific signal type
      const signalField = value;
      if (signalField) {
        const { data: matches } = await supabase
          .from('detection_rule_matches')
          .select('id, detection_rules!inner(signal_field_name)')
          .eq('opportunity_id', opp.id)
          .eq('detection_rules.signal_field_name', signalField)
          .limit(1);

        if (matches && matches.length > 0) {
          return { triggered: true, reason: `Signal "${signalField}" detected` };
        }
      }
      break;
    }

    case 'pre_sales_stage':
    case 'sales_stage': {
      const stageField = field === 'pre_sales_stage' ? opp.pre_sales_stage : opp.sales_stage;
      if (operator === 'equals' && stageField === value) {
        return { triggered: true, reason: `${field === 'pre_sales_stage' ? 'Pre-sales' : 'Sales'} stage is ${value}` };
      }
      if (operator === 'not_equals' && stageField !== value) {
        return { triggered: true, reason: `${field === 'pre_sales_stage' ? 'Pre-sales' : 'Sales'} stage is not ${value}` };
      }
      break;
    }

    case 'deal_value': {
      const dealVal = opp.value ?? 0;
      const threshold = Number(value) || 0;
      const triggered = compareNumeric(dealVal, operator, threshold);
      if (triggered) {
        return { triggered: true, reason: `Deal value $${dealVal.toLocaleString()} ${operatorLabel(operator)} $${threshold.toLocaleString()}` };
      }
      break;
    }

    case 'competitive_threat_score': {
      const threatScore = opp.competitive_threat_score ?? 0;
      const threshold = Number(value) || 0;
      const triggered = compareNumeric(threatScore, operator, threshold);
      if (triggered) {
        return { triggered: true, reason: `Competitive threat ${threatScore} ${operatorLabel(operator)} ${threshold}` };
      }
      break;
    }

    case 'competitor_count': {
      const { data: competitors } = await supabase
        .from('opportunity_competitive_insights')
        .select('competitor_name')
        .eq('opportunity_id', opp.id)
        .eq('insight_type', 'competitor_mention');

      const uniqueCompetitors = new Set((competitors || []).map((c: any) => c.competitor_name));
      const count = uniqueCompetitors.size;
      const threshold = Number(value) || 0;
      const triggered = compareNumeric(count, operator, threshold);
      if (triggered) {
        return { triggered: true, reason: `${count} competitor(s) detected ${operatorLabel(operator)} ${threshold}` };
      }
      break;
    }

    case 'new_competitive_insight': {
      let sinceDate: Date | null = null;
      if (dateRangeConfig?.type === 'rolling_days') {
        const days = dateRangeConfig.days || 7;
        sinceDate = new Date();
        sinceDate.setDate(sinceDate.getDate() - days);
      } else if (dateRangeConfig?.type === 'calendar_range') {
        sinceDate = dateRangeConfig.start ? new Date(dateRangeConfig.start) : null;
      } else if (dateRangeConfig?.type === 'since_last_digest') {
        sinceDate = new Date();
        sinceDate.setHours(sinceDate.getHours() - 24);
      }

      if (sinceDate) {
        const { data: insights } = await supabase
          .from('opportunity_competitive_insights')
          .select('id, insight_type, competitor_name, created_at')
          .eq('opportunity_id', opp.id)
          .gte('created_at', sinceDate.toISOString())
          .limit(10);

        if (insights && insights.length > 0) {
          const competitors = [...new Set(insights.map((i: any) => i.competitor_name).filter(Boolean))];
          return {
            triggered: true,
            reason: `${insights.length} new competitive insight(s)${competitors.length > 0 ? ` re: ${competitors.slice(0, 3).join(', ')}` : ''}`,
            signalDetails: insights.map((i: any) => ({
              name: `${i.insight_type}: ${i.competitor_name || 'Unknown'}`,
              detected_at: i.created_at,
            })),
          };
        }
      }
      break;
    }
  }

  return { triggered: false };
}

function getAssignee(opp: Opportunity, assignedToType: string, ruleOwnerId?: string): string | null {
  switch (assignedToType) {
    case 'primary_se':
      return opp.primary_se_email || opp.account_se_email || null;
    case 'opportunity_owner':
      return opp.owner_email || null;
    case 'account_owner':
      return opp.owner_email || null;
    case 'rule_creator':
      return ruleOwnerId || null;
    case 'team_manager':
      // Would need to look up manager in hierarchy - for now return null
      return null;
    default:
      return null;
  }
}

function compareNumeric(actual: number, operator: string, threshold: number): boolean {
  switch (operator) {
    case 'greater_than': return actual > threshold;
    case 'greater_than_or_equal': return actual >= threshold;
    case 'less_than': return actual < threshold;
    case 'less_than_or_equal': return actual <= threshold;
    case 'equals': return actual === threshold;
    case 'not_equals': return actual !== threshold;
    default: return false;
  }
}

function operatorLabel(operator: string): string {
  const labels: Record<string, string> = {
    greater_than: '>',
    greater_than_or_equal: '≥',
    less_than: '<',
    less_than_or_equal: '≤',
    equals: '=',
    not_equals: '≠',
  };
  return labels[operator] || operator;
}

serve(handler);

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.89.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation schema - includes parent context for hierarchical questions
const ReadinessQuestionSchema = z.object({
  id: z.string().min(1).max(100),
  question: z.string().min(1).max(2000),
  category_name: z.string().max(200),
  parent_question_id: z.string().uuid().nullable().optional(),
  trigger_condition: z.object({
    type: z.enum(['any', 'equals', 'contains', 'not_equals', 'not_contains']).optional(),
    value: z.string().optional(),
  }).nullable().optional(),
});

const ExtractReadinessInputSchema = z.object({
  transcript: z.string().min(1, "Transcript is required").max(500000, "Transcript too long (max 500k chars)"),
  opportunityId: z.string().uuid("Invalid opportunity ID"),
  questions: z.array(ReadinessQuestionSchema).max(500).optional().default([]),
});

interface ReadinessQuestion {
  id: string;
  question: string;
  category_name: string;
  parent_question_id?: string | null;
  trigger_condition?: {
    type?: 'any' | 'equals' | 'contains' | 'not_equals' | 'not_contains';
    value?: string;
  } | null;
}

interface ExtractedAnswer {
  question_id: string;
  answer: string;
  confidence: number;
  context: string;
}

interface DetectedDeploymentType {
  type: string;
  confidence: number;
  reasoning: string;
  rule_id?: string;
  tree_id?: string;
}

interface DetectionRule {
  id: string;
  name: string;
  trigger_phrases: string[];
  context_qualifiers: string[] | null;
  exclusion_phrases: string[] | null;
  confidence_threshold: number | null;
  tree_id: string;
  deployment_type_id: string | null;
  deployment_type_name: string | null;
}

// Check if any phrase matches in the transcript (case-insensitive)
function matchesPhrases(transcript: string, phrases: string[] | null): { matched: boolean; matchedPhrases: string[] } {
  if (!phrases || phrases.length === 0) return { matched: false, matchedPhrases: [] };
  
  const lowerTranscript = transcript.toLowerCase();
  const matchedPhrases: string[] = [];
  
  for (const phrase of phrases) {
    if (lowerTranscript.includes(phrase.toLowerCase())) {
      matchedPhrases.push(phrase);
    }
  }
  
  return { matched: matchedPhrases.length > 0, matchedPhrases };
}

// Apply detection rules to determine deployment types
function applyDetectionRules(transcript: string, rules: DetectionRule[]): DetectedDeploymentType[] {
  const detectedTypes: Map<string, DetectedDeploymentType> = new Map();
  
  for (const rule of rules) {
    const triggerMatch = matchesPhrases(transcript, rule.trigger_phrases);
    if (!triggerMatch.matched) continue;
    
    const exclusionMatch = matchesPhrases(transcript, rule.exclusion_phrases);
    if (exclusionMatch.matched) {
      console.log(`Rule "${rule.name}" excluded due to phrases: ${exclusionMatch.matchedPhrases.join(', ')}`);
      continue;
    }
    
    if (rule.context_qualifiers && rule.context_qualifiers.length > 0) {
      const contextMatch = matchesPhrases(transcript, rule.context_qualifiers);
      if (!contextMatch.matched) {
        console.log(`Rule "${rule.name}" skipped - no context qualifiers matched`);
        continue;
      }
    }
    
    const deploymentType = rule.deployment_type_name || 'unknown';
    const confidence = rule.confidence_threshold || 70;
    
    const existing = detectedTypes.get(deploymentType);
    if (!existing || existing.confidence < confidence) {
      detectedTypes.set(deploymentType, {
        type: deploymentType,
        confidence,
        reasoning: `Matched rule "${rule.name}" with phrases: ${triggerMatch.matchedPhrases.slice(0, 3).join(', ')}`,
        rule_id: rule.id,
        tree_id: rule.tree_id,
      });
    }
  }
  
  return Array.from(detectedTypes.values());
}

// Build a hierarchical prompt that shows parent-child relationships clearly
function buildHierarchicalQuestionsList(questions: ReadinessQuestion[]): string {
  const questionMap = new Map<string, ReadinessQuestion>();
  questions.forEach(q => questionMap.set(q.id, q));
  
  // Separate parent and child questions
  const parentQuestions = questions.filter(q => !q.parent_question_id);
  const childQuestions = questions.filter(q => q.parent_question_id);
  
  // Group children by parent
  const childrenByParent = new Map<string, ReadinessQuestion[]>();
  childQuestions.forEach(child => {
    const parentId = child.parent_question_id!;
    if (!childrenByParent.has(parentId)) {
      childrenByParent.set(parentId, []);
    }
    childrenByParent.get(parentId)!.push(child);
  });
  
  // Build hierarchical list
  const lines: string[] = [];
  let questionNumber = 1;
  
  for (const parent of parentQuestions) {
    // Add parent question
    lines.push(`${questionNumber}. [ID: ${parent.id}] [Category: ${parent.category_name}] ${parent.question}`);
    
    // Add child questions with context
    const children = childrenByParent.get(parent.id) || [];
    for (const child of children) {
      const trigger = child.trigger_condition;
      let contextNote = '';
      
      if (trigger?.type === 'equals' && trigger.value) {
        contextNote = `ONLY answer if Q${questionNumber} answer = "${trigger.value}"`;
      } else if (trigger?.type === 'contains' && trigger.value) {
        contextNote = `ONLY answer if Q${questionNumber} answer contains "${trigger.value}"`;
      } else if (trigger?.type === 'not_equals' && trigger.value) {
        contextNote = `ONLY answer if Q${questionNumber} answer ≠ "${trigger.value}"`;
      } else if (trigger?.type === 'not_contains' && trigger.value) {
        contextNote = `ONLY answer if Q${questionNumber} answer does NOT contain "${trigger.value}"`;
      } else {
        contextNote = `Follow-up to Q${questionNumber} - answer ONLY in context of "${parent.question}"`;
      }
      
      lines.push(`   ${questionNumber}a. [ID: ${child.id}] [Category: ${child.category_name}] [${contextNote}] ${child.question}`);
    }
    
    questionNumber++;
  }
  
  // Add any orphan child questions (parent not in list)
  const orphanChildren = childQuestions.filter(c => !questionMap.has(c.parent_question_id!));
  for (const orphan of orphanChildren) {
    lines.push(`${questionNumber}. [ID: ${orphan.id}] [Category: ${orphan.category_name}] ${orphan.question}`);
    questionNumber++;
  }
  
  return lines.join('\n');
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const rawBody = await req.json();
    
    const parseResult = ExtractReadinessInputSchema.safeParse(rawBody);
    if (!parseResult.success) {
      console.error("Input validation failed:", parseResult.error.errors);
      return new Response(
        JSON.stringify({ 
          error: "Invalid input", 
          details: parseResult.error.errors.map(e => `${e.path.join('.')}: ${e.message}`)
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    const { transcript, opportunityId, questions } = parseResult.data;
    
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    
    if (!supabaseUrl || !supabaseKey) {
      throw new Error("Supabase configuration missing");
    }
    
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Fetch active detection rules
    const { data: rulesData, error: rulesError } = await supabase
      .from('detection_rules')
      .select(`
        id,
        name,
        trigger_phrases,
        context_qualifiers,
        exclusion_phrases,
        confidence_threshold,
        tree_id,
        detection_rule_trees(
          id,
          deployment_type_id,
          deployment_types(
            id,
            name
          )
        )
      `)
      .eq('is_active', true);
    
    if (rulesError) {
      console.error("Error fetching detection rules:", rulesError);
    }
    
    const rules: DetectionRule[] = (rulesData || []).map((r: any) => ({
      id: r.id,
      name: r.name,
      trigger_phrases: r.trigger_phrases || [],
      context_qualifiers: r.context_qualifiers,
      exclusion_phrases: r.exclusion_phrases,
      confidence_threshold: r.confidence_threshold,
      tree_id: r.tree_id,
      deployment_type_id: r.detection_rule_trees?.deployment_type_id,
      deployment_type_name: r.detection_rule_trees?.deployment_types?.name,
    }));
    
    console.log(`Loaded ${rules.length} active detection rules`);
    
    const ruleBasedDeploymentTypes = applyDetectionRules(transcript, rules);
    console.log(`Rule-based detection found ${ruleBasedDeploymentTypes.length} deployment types`);
    
    const aiConfig = await getAIConfig();
    console.log(`Using AI provider at: ${aiConfig.endpoint}`);

    // Build hierarchical questions list with parent-child context
    const hierarchicalQuestionsList = buildHierarchicalQuestionsList(questions);
    const hasChildQuestions = questions.some(q => q.parent_question_id);
    
    console.log(`Processing ${questions.length} questions (hierarchical: ${hasChildQuestions})`);

    const systemPrompt = `You are an AI assistant specialized in extracting technical readiness information from sales call transcripts for Pendo (a product analytics platform).

Your job is to identify answers to specific technical readiness questions from the transcript.

READINESS QUESTION GUIDELINES:
- Only extract answers that are EXPLICITLY mentioned or strongly implied
- Assign confidence score (0-100): 70+ for explicit, 30-60 for inferred
- If a question cannot be answered, DO NOT include it

${hasChildQuestions ? `HIERARCHICAL QUESTION RULES (CRITICAL):
- Some questions are FOLLOW-UP questions (indented with "a" suffix like "1a", "2a")
- Follow-up questions have CONDITIONS in brackets like [ONLY answer if Q1 = "yes"]
- You MUST respect these conditions:
  - If Q1 asks "Do you use iFrames?" and Q1a says [ONLY answer if Q1 = "yes"], then:
    - First determine if Q1's answer is "yes" (or affirmative)
    - Only then look for Q1a's answer IN THE SAME CONTEXT as Q1
  - A "yes" elsewhere in the transcript does NOT count - it must be contextually about the parent question
- When extracting follow-up answers, the context quote MUST show the connection to the parent topic
` : ''}
QUESTIONS TO ANSWER:
${hierarchicalQuestionsList}

Extract answers ONLY for questions where the transcript provides relevant (and contextually appropriate) information.`;

    const response = await fetch(aiConfig.endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${aiConfig.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: aiConfig.model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Extract answers to the technical readiness questions from this transcript:\n\n${transcript}` }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "extract_readiness_answers",
              description: "Extract answers to technical readiness questions from the transcript",
              parameters: {
                type: "object",
                properties: {
                  extracted_answers: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        question_id: { 
                          type: "string", 
                          description: "The ID of the question being answered" 
                        },
                        answer: { 
                          type: "string", 
                          description: "The extracted answer (keep concise but complete)" 
                        },
                        confidence: { 
                          type: "number", 
                          description: "Confidence score 0-100. Use 70+ for explicitly stated info, 30-60 for inferred. For follow-up questions, reduce confidence if context linkage is weak" 
                        },
                        context: { 
                          type: "string", 
                          description: "Quote or paraphrase from transcript. For follow-up questions, include context showing connection to parent topic" 
                        }
                      },
                      required: ["question_id", "answer", "confidence", "context"]
                    },
                    description: "Array of extracted answers - only include questions where answers were found with proper context"
                  },
                  unanswered_question_ids: {
                    type: "array",
                    items: { type: "string" },
                    description: "IDs of questions that could not be answered (including follow-ups where parent condition was not met)"
                  }
                },
                required: ["extracted_answers", "unanswered_question_ids"]
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "extract_readiness_answers" } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded, please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required, please add credits." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log("AI response for readiness extraction:", JSON.stringify(data, null, 2));

    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall?.function?.arguments) {
      throw new Error("No extraction result from AI");
    }

    const extraction = JSON.parse(toolCall.function.arguments);
    const extractedAnswers: ExtractedAnswer[] = extraction.extracted_answers || [];
    const unansweredQuestionIds: string[] = extraction.unanswered_question_ids || [];

    // Save deployment types
    for (const dt of ruleBasedDeploymentTypes.filter(d => d.confidence >= 50 && d.type !== 'unknown')) {
      const { data: deploymentType } = await supabase
        .from('deployment_types')
        .select('id')
        .ilike('name', dt.type)
        .single();
      
      if (deploymentType) {
        const { error } = await supabase
          .from('opportunity_deployment_types')
          .upsert({
            opportunity_id: opportunityId,
            deployment_type_id: deploymentType.id,
          }, { 
            onConflict: 'opportunity_id,deployment_type_id',
          });
        
        if (error) {
          console.error("Error saving deployment type:", error);
        } else {
          console.log(`Saved deployment type "${dt.type}" for opportunity ${opportunityId}`);
        }
      }
    }
    
    const deploymentIndependentMatches = ruleBasedDeploymentTypes.filter(d => d.type === 'unknown');
    if (deploymentIndependentMatches.length > 0) {
      console.log(`Found ${deploymentIndependentMatches.length} deployment-independent rule matches`);
    }
    
    // Save extracted answers with confidence-based enrichment
    const existingQuestionIds = extractedAnswers.map(a => a.question_id);
    const { data: existingAnswers } = await supabase
      .from('opportunity_readiness_answers')
      .select('question_id, confidence_score')
      .eq('opportunity_id', opportunityId)
      .in('question_id', existingQuestionIds.length > 0 ? existingQuestionIds : ['__none__']);
    
    const existingMap = new Map(
      (existingAnswers || []).map((a: any) => [a.question_id, a.confidence_score || 0])
    );
    
    for (const answer of extractedAnswers) {
      const existingConfidence = existingMap.get(answer.question_id) ?? -1;
      const newConfidence = answer.confidence ?? 0;
      
      if (existingConfidence < 0) {
        const { error } = await supabase
          .from('opportunity_readiness_answers')
          .insert({
            opportunity_id: opportunityId,
            question_id: answer.question_id,
            answer: answer.answer,
            confidence_score: newConfidence,
            source: 'transcript_ai',
            notes: `AI extracted (${answer.confidence}% confidence): "${answer.context}"`,
          });
        
        if (error) {
          console.error("Error inserting answer:", error);
        }
      } else if (newConfidence > existingConfidence) {
        const { error } = await supabase
          .from('opportunity_readiness_answers')
          .update({
            answer: answer.answer,
            confidence_score: newConfidence,
            source: 'transcript_ai',
            notes: `AI extracted (${answer.confidence}% confidence): "${answer.context}"`,
          })
          .eq('opportunity_id', opportunityId)
          .eq('question_id', answer.question_id);
        
        if (error) {
          console.error("Error updating answer:", error);
        }
      } else {
        const { error } = await supabase
          .from('opportunity_readiness_answers')
          .update({
            last_confirmed_transcript_id: null,
            last_confirmed_at: new Date().toISOString()
          })
          .eq('opportunity_id', opportunityId)
          .eq('question_id', answer.question_id);
        
        if (error) {
          console.error("Error updating confirmation:", error);
        }
      }
    }
    
    console.log(`Processed ${extractedAnswers.length} readiness answers with hierarchical context`);

    return new Response(JSON.stringify({
      success: true,
      detected_deployment_types: ruleBasedDeploymentTypes,
      extracted_count: extractedAnswers.length,
      extracted_answers: extractedAnswers,
      unanswered_count: unansweredQuestionIds.length,
      unanswered_question_ids: unansweredQuestionIds,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("extract-readiness-answers error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), 
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface FixResult {
  meetingsFixed: number;
  transcriptsFixed: number;
  meetingsOrphaned: number;
  errors: string[];
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { dryRun = true, limit = 100 } = await req.json().catch(() => ({}));

    console.log(`Starting account mismatch fix (dryRun: ${dryRun}, limit: ${limit})`);

    const result: FixResult = {
      meetingsFixed: 0,
      transcriptsFixed: 0,
      meetingsOrphaned: 0,
      errors: [],
    };

    // Step 1: Find mismatched momentum_meetings
    const { data: mismatchedMeetings, error: fetchError } = await supabase
      .from('momentum_meetings')
      .select(`
        id,
        momentum_id,
        salesforce_account_id,
        matched_account_id,
        matched_account:accounts!matched_account_id(id, name, salesforce_account_id)
      `)
      .not('salesforce_account_id', 'is', null)
      .not('matched_account_id', 'is', null)
      .limit(limit);

    if (fetchError) {
      throw new Error(`Failed to fetch meetings: ${fetchError.message}`);
    }

    console.log(`Found ${mismatchedMeetings?.length || 0} meetings to check`);

    // Build a map of salesforce_account_id -> correct account
    const sfAccountIds = [...new Set(mismatchedMeetings?.map(m => m.salesforce_account_id).filter(Boolean))];
    
    const { data: correctAccounts, error: accountsError } = await supabase
      .from('accounts')
      .select('id, name, salesforce_account_id')
      .in('salesforce_account_id', sfAccountIds);

    if (accountsError) {
      throw new Error(`Failed to fetch accounts: ${accountsError.message}`);
    }

    const sfToAccountMap = new Map(
      correctAccounts?.map(a => [a.salesforce_account_id, a]) || []
    );

    const meetingsToFix: { id: string; correctAccountId: string; currentAccountId: string }[] = [];
    const meetingsToOrphan: string[] = [];

    for (const meeting of mismatchedMeetings || []) {
      const matchedAccount = meeting.matched_account as any;
      
      // Check if there's a mismatch
      if (matchedAccount?.salesforce_account_id !== meeting.salesforce_account_id) {
        const correctAccount = sfToAccountMap.get(meeting.salesforce_account_id);
        
        if (correctAccount) {
          meetingsToFix.push({
            id: meeting.id,
            correctAccountId: correctAccount.id,
            currentAccountId: meeting.matched_account_id,
          });
        } else {
          // No matching account found - orphan this meeting
          meetingsToOrphan.push(meeting.id);
        }
      }
    }

    console.log(`Meetings to fix: ${meetingsToFix.length}, to orphan: ${meetingsToOrphan.length}`);

    if (!dryRun) {
      // Fix mismatched meetings
      for (const fix of meetingsToFix) {
        const { error: updateError } = await supabase
          .from('momentum_meetings')
          .update({ matched_account_id: fix.correctAccountId })
          .eq('id', fix.id);

        if (updateError) {
          result.errors.push(`Failed to fix meeting ${fix.id}: ${updateError.message}`);
        } else {
          result.meetingsFixed++;
        }
      }

      // Orphan meetings with no matching account
      for (const meetingId of meetingsToOrphan) {
        const { error: orphanError } = await supabase
          .from('momentum_meetings')
          .update({ matched_account_id: null })
          .eq('id', meetingId);

        if (orphanError) {
          result.errors.push(`Failed to orphan meeting ${meetingId}: ${orphanError.message}`);
        } else {
          result.meetingsOrphaned++;
        }
      }

      // Step 2: Fix transcript_reviews based on their momentum_meeting
      const { error: transcriptError } = await supabase.rpc('fix_transcript_account_ids');
      
      if (transcriptError) {
        // Fallback: do it manually
        console.log('RPC not available, fixing transcripts manually');
        
        const { data: transcriptsToFix, error: trFetchError } = await supabase
          .from('transcript_reviews')
          .select(`
            id,
            final_account_id,
            momentum_meeting_id,
            momentum_meetings!inner(matched_account_id)
          `)
          .not('momentum_meeting_id', 'is', null)
          .limit(500);

        if (!trFetchError && transcriptsToFix) {
          for (const tr of transcriptsToFix) {
            const mmAccount = (tr.momentum_meetings as any)?.matched_account_id;
            if (mmAccount && tr.final_account_id !== mmAccount) {
              const { error: trUpdateError } = await supabase
                .from('transcript_reviews')
                .update({ final_account_id: mmAccount })
                .eq('id', tr.id);

              if (!trUpdateError) {
                result.transcriptsFixed++;
              }
            }
          }
        }
      }
    } else {
      result.meetingsFixed = meetingsToFix.length;
      result.meetingsOrphaned = meetingsToOrphan.length;
    }

    console.log(`Fix complete: ${JSON.stringify(result)}`);

    return new Response(JSON.stringify({
      success: true,
      dryRun,
      result,
      details: dryRun ? {
        meetingsToFix: meetingsToFix.slice(0, 10),
        meetingsToOrphan: meetingsToOrphan.slice(0, 10),
      } : undefined,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error('Error:', errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage,
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Extract company name from opportunity name patterns
function extractCompanyName(oppName: string): string | null {
  if (!oppName) return null;
  
  // Pattern: "CompanyName / Pendo: description" or "CompanyName // Pendo description"
  const slashPattern = /^([A-Za-z0-9\s&\-\.]+?)\s*[/]+\s*Pendo/i;
  let match = oppName.match(slashPattern);
  if (match) return match[1].trim();
  
  // Pattern: "Pendo / CompanyName: description" or "Pendo // CompanyName description"
  const pendoFirstSlashPattern = /^Pendo\s*[/]+\s*([A-Za-z0-9\s&\-\.]+?)(?:\s*[:|\-]|$)/i;
  match = oppName.match(pendoFirstSlashPattern);
  if (match) return match[1].trim();
  
  // Pattern: "CompanyName + Pendo" or "Pendo + CompanyName"
  const plusPattern = /^([A-Za-z0-9\s&\-\.]+?)\s*[+]\s*Pendo/i;
  match = oppName.match(plusPattern);
  if (match) return match[1].trim();
  
  const pendoFirstPlusPattern = /^Pendo\s*[+]\s*([A-Za-z0-9\s&\-\.]+?)(?:\s*[:|\-]|$)/i;
  match = oppName.match(pendoFirstPlusPattern);
  if (match) return match[1].trim();
  
  // Pattern: "CompanyName x Pendo" or "Pendo x CompanyName"
  const xPattern = /^([A-Za-z0-9\s&\-\.]+?)\s+x\s+Pendo/i;
  match = oppName.match(xPattern);
  if (match) return match[1].trim();
  
  const pendoFirstXPattern = /^Pendo\s+x\s+([A-Za-z0-9\s&\-\.]+?)(?:\s*[:|\-]|$)/i;
  match = oppName.match(pendoFirstXPattern);
  if (match) return match[1].trim();
  
  // Pattern: "CompanyName | Pendo" or "Pendo | CompanyName"
  const pipePattern = /^([A-Za-z0-9\s&\-\.]+?)\s*\|\s*Pendo/i;
  match = oppName.match(pipePattern);
  if (match) return match[1].trim();
  
  const pendoFirstPipePattern = /^Pendo\s*\|\s*([A-Za-z0-9\s&\-\.]+?)(?:\s*[:|\-]|$)/i;
  match = oppName.match(pendoFirstPipePattern);
  if (match) return match[1].trim();
  
  // Pattern: "CompanyName <> Pendo" or "Pendo <> CompanyName"
  const arrowPattern = /^([A-Za-z0-9\s&\-\.]+?)\s*<>\s*Pendo/i;
  match = oppName.match(arrowPattern);
  if (match) return match[1].trim();
  
  const pendoFirstArrowPattern = /^Pendo\s*<>\s*([A-Za-z0-9\s&\-\.]+?)(?:\s*[:|\-]|$)/i;
  match = oppName.match(pendoFirstArrowPattern);
  if (match) return match[1].trim();
  
  // Pattern: "CompanyName - Pendo" (dash separator)
  const dashPattern = /^([A-Za-z0-9\s&\-\.]+?)\s+-\s+Pendo/i;
  match = oppName.match(dashPattern);
  if (match) return match[1].trim();
  
  const pendoFirstDashPattern = /^Pendo\s+-\s+([A-Za-z0-9\s&\-\.]+?)(?:\s*[:|\-]|$)/i;
  match = oppName.match(pendoFirstDashPattern);
  if (match) return match[1].trim();
  
  // Pattern: Just first word that's capitalized and not "Pendo"
  const firstWordPattern = /^([A-Z][a-zA-Z0-9]+)/;
  match = oppName.match(firstWordPattern);
  if (match && match[1].toLowerCase() !== 'pendo') return match[1].trim();
  
  return null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const { dryRun = true } = await req.json().catch(() => ({ dryRun: true }));
    
    console.log(`[Fix Resource] Starting ${dryRun ? 'DRY RUN' : 'LIVE FIX'}...`);

    // Step 1: Get the Resource account
    const { data: resourceAccount, error: raErr } = await supabase
      .from("accounts")
      .select("id, salesforce_account_id")
      .eq("name", "Resource")
      .single();

    if (raErr || !resourceAccount) {
      throw new Error("Resource account not found");
    }

    console.log(`[Fix Resource] Found Resource account: ${resourceAccount.id}, SF ID: ${resourceAccount.salesforce_account_id}`);

    // Step 2: Get all opportunities on Resource that have SF IDs
    const { data: misassignedOpps, error: oppErr } = await supabase
      .from("opportunities")
      .select("id, name, salesforce_opportunity_id, account_id")
      .eq("account_id", resourceAccount.id)
      .not("salesforce_opportunity_id", "is", null);

    if (oppErr) throw oppErr;

    console.log(`[Fix Resource] Found ${misassignedOpps?.length || 0} opportunities with SF IDs on Resource`);

    // Step 3: Get momentum_meetings that are matched to Resource but have different SF Account IDs
    const { data: mismatchedMeetings, error: mmErr } = await supabase
      .from("momentum_meetings")
      .select("id, salesforce_account_id, salesforce_opportunity_id, title")
      .eq("matched_account_id", resourceAccount.id)
      .not("salesforce_account_id", "is", null)
      .neq("salesforce_account_id", resourceAccount.salesforce_account_id);

    if (mmErr) throw mmErr;

    console.log(`[Fix Resource] Found ${mismatchedMeetings?.length || 0} meetings with different SF Account IDs`);

    // Step 4: Build a map of SF Opportunity ID -> SF Account ID
    const oppToAccountMap = new Map<string, string>();
    for (const meeting of mismatchedMeetings || []) {
      if (meeting.salesforce_opportunity_id && meeting.salesforce_account_id) {
        oppToAccountMap.set(meeting.salesforce_opportunity_id, meeting.salesforce_account_id);
      }
    }

    // Step 5: Get existing accounts by SF Account ID
    const { data: existingAccounts, error: eaErr } = await supabase
      .from("accounts")
      .select("id, name, salesforce_account_id");
    
    if (eaErr) throw eaErr;

    const sfIdToAccount = new Map<string, { id: string; name: string }>();
    for (const acc of existingAccounts || []) {
      if (acc.salesforce_account_id) {
        sfIdToAccount.set(acc.salesforce_account_id, { id: acc.id, name: acc.name });
      }
    }

    // Step 6: Process each misassigned opportunity
    const results = {
      accountsCreated: [] as { id: string; name: string; sfAccountId: string }[],
      opportunitiesReassigned: [] as { id: string; name: string; fromAccount: string; toAccount: string }[],
      transcriptsUpdated: 0,
      nbasUpdated: 0,
      painPointsUpdated: 0,
      useCasesUpdated: 0,
      metricsUpdated: 0,
      contactsUpdated: 0,
      meetingsUpdated: 0,
      skipped: [] as { oppName: string; reason: string }[],
    };

    for (const opp of misassignedOpps || []) {
      const sfAccountId = oppToAccountMap.get(opp.salesforce_opportunity_id);
      
      if (!sfAccountId) {
        results.skipped.push({ oppName: opp.name, reason: "No SF Account ID found in meetings" });
        continue;
      }

      // Check if we need to create an account or if one exists
      let targetAccount = sfIdToAccount.get(sfAccountId);

      if (!targetAccount) {
        // Create new account
        const companyName = extractCompanyName(opp.name) || `Account (${sfAccountId.slice(-8)})`;
        
        if (!dryRun) {
          const { data: newAccount, error: createErr } = await supabase
            .from("accounts")
            .insert({
              name: companyName,
              salesforce_account_id: sfAccountId,
              status: "active",
              auto_import_transcripts: true,
            })
            .select("id, name")
            .single();

          if (createErr) {
            console.error(`[Fix Resource] Failed to create account ${companyName}: ${createErr.message}`);
            results.skipped.push({ oppName: opp.name, reason: `Account creation failed: ${createErr.message}` });
            continue;
          }

          targetAccount = { id: newAccount.id, name: newAccount.name };
          sfIdToAccount.set(sfAccountId, targetAccount);
        } else {
          targetAccount = { id: `DRY-RUN-${sfAccountId.slice(-8)}`, name: companyName };
        }
        
        results.accountsCreated.push({ id: targetAccount.id, name: targetAccount.name, sfAccountId });
      }

      // Now reassign the opportunity
      if (!dryRun) {
        // Update opportunity
        const { error: updateOppErr } = await supabase
          .from("opportunities")
          .update({ account_id: targetAccount.id })
          .eq("id", opp.id);

        if (updateOppErr) {
          console.error(`[Fix Resource] Failed to update opportunity ${opp.name}: ${updateOppErr.message}`);
          results.skipped.push({ oppName: opp.name, reason: `Opportunity update failed: ${updateOppErr.message}` });
          continue;
        }

        // Update related records
        const { data: nbaData } = await supabase
          .from("account_nbas")
          .update({ account_id: targetAccount.id })
          .eq("opportunity_id", opp.id)
          .select("id");
        results.nbasUpdated += nbaData?.length || 0;

        const { data: painData } = await supabase
          .from("account_pain_points")
          .update({ account_id: targetAccount.id })
          .eq("opportunity_id", opp.id)
          .select("id");
        results.painPointsUpdated += painData?.length || 0;

        const { data: ucData } = await supabase
          .from("account_use_cases")
          .update({ account_id: targetAccount.id })
          .eq("opportunity_id", opp.id)
          .select("id");
        results.useCasesUpdated += ucData?.length || 0;

        const { data: metricData } = await supabase
          .from("account_metrics")
          .update({ account_id: targetAccount.id })
          .eq("opportunity_id", opp.id)
          .select("id");
        results.metricsUpdated += metricData?.length || 0;

        const { data: contactData } = await supabase
          .from("account_contacts")
          .update({ account_id: targetAccount.id })
          .eq("opportunity_id", opp.id)
          .select("id");
        results.contactsUpdated += contactData?.length || 0;

        // Update transcript_reviews to point to new account
        const { data: trData } = await supabase
          .from("transcript_reviews")
          .update({ final_account_id: targetAccount.id })
          .eq("opportunity_id", opp.id)
          .select("id");
        results.transcriptsUpdated += trData?.length || 0;

        // Update momentum_meetings matched_account_id
        const { data: meetingData } = await supabase
          .from("momentum_meetings")
          .update({ matched_account_id: targetAccount.id })
          .eq("salesforce_account_id", sfAccountId)
          .select("id");
        results.meetingsUpdated += meetingData?.length || 0;
      }

      results.opportunitiesReassigned.push({
        id: opp.id,
        name: opp.name,
        fromAccount: "Resource",
        toAccount: targetAccount.name,
      });
    }

    console.log(`[Fix Resource] Completed. Accounts created: ${results.accountsCreated.length}, Opportunities reassigned: ${results.opportunitiesReassigned.length}`);

    return new Response(
      JSON.stringify({
        success: true,
        dryRun,
        results,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("[Fix Resource] Error:", error);
    return new Response(
      JSON.stringify({ success: false, error: error?.message || String(error) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation schema
const AccountDataSchema = z.object({
  name: z.string().min(1).max(500),
  industry: z.string().max(200).nullable().optional(),
  technologies: z.array(z.object({
    name: z.string().max(200),
    layer: z.string().max(100),
    category: z.string().max(100),
    notes: z.string().max(2000).nullable().optional(),
  })).max(500).optional().default([]),
  useCases: z.array(z.object({
    use_case: z.string().max(500),
    functional_area: z.string().max(200),
    description: z.string().max(2000).nullable().optional(),
    status: z.string().max(50),
  })).max(200).optional().default([]),
  transcripts: z.array(z.object({
    content: z.string().max(200000).optional(),
    insights: z.any().optional(),
  })).max(100).optional().default([]),
  nbas: z.array(z.object({
    action: z.string().max(1000),
    action_type: z.string().max(100),
    status: z.string().max(50),
  })).max(500).optional().default([]),
  contacts: z.array(z.object({
    name: z.string().max(200),
    role: z.string().max(200).nullable().optional(),
  })).max(500).optional().default([]),
});

const GenerateCustomerStoryInputSchema = z.object({
  accountData: AccountDataSchema,
});

interface AccountData {
  name: string;
  industry: string | null;
  technologies: { name: string; layer: string; category: string; notes: string | null }[];
  useCases: { use_case: string; functional_area: string; description: string | null; status: string }[];
  transcripts: { content: string; insights: any }[];
  nbas: { action: string; action_type: string; status: string }[];
  contacts: { name: string; role: string | null }[];
}

interface CustomerStory {
  title: string;
  situation: string;
  situationMetrics: string;
  behavior: string;
  technologiesUsed: string[];
  useCases: string[];
  impact: string;
  impactMetrics: { metric: string; before: string; after: string }[];
  tags: string[];
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const rawBody = await req.json();
    
    // Validate input with zod
    const parseResult = GenerateCustomerStoryInputSchema.safeParse(rawBody);
    if (!parseResult.success) {
      console.error("Input validation failed:", parseResult.error.errors);
      return new Response(
        JSON.stringify({ 
          error: "Invalid input", 
          details: parseResult.error.errors.map(e => `${e.path.join('.')}: ${e.message}`)
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    const { accountData } = parseResult.data;

    // Get AI configuration (provider-agnostic)
    const aiConfig = await getAIConfig();
    console.log(`Using AI provider at: ${aiConfig.endpoint}`);

    // Build context from account data
    const technologiesContext = accountData.technologies
      .map(t => `- ${t.name} (${t.layer}/${t.category})${t.notes ? `: ${t.notes}` : ''}`)
      .join('\n') || 'No technologies documented';

    const useCasesContext = accountData.useCases
      .map(uc => `- ${uc.use_case} (${uc.functional_area}): ${uc.description || 'No description'} [${uc.status}]`)
      .join('\n') || 'No use cases documented';

    const transcriptsContext = accountData.transcripts
      .map(t => {
        const insights = t.insights || {};
        const painPoints = insights.painPoints?.join(', ') || '';
        const useCases = insights.useCases?.join(', ') || '';
        return `Transcript insights - Pain points: ${painPoints}. Use cases: ${useCases}. Content snippet: ${t.content?.substring(0, 500)}...`;
      })
      .join('\n\n') || 'No transcripts available';

    const nbasContext = accountData.nbas
      .map(n => `- ${n.action} (${n.action_type}) [${n.status}]`)
      .join('\n') || 'No NBAs documented';

    const contactsContext = accountData.contacts
      .map(c => `- ${c.name}${c.role ? ` (${c.role})` : ''}`)
      .join('\n') || 'No contacts documented';

    const systemPrompt = `You are a Solutions Engineer creating a compelling customer story. Your goal is to synthesize all available account information into a structured story following the Situation-Behavior-Impact (SBI) framework.

The story should:
1. **Situation**: Describe the customer's context, challenges, and pain points BEFORE the solution. Include specific metrics about their initial state (e.g., "spending 20+ hours per week on manual processes").
2. **Behavior**: Explain what the customer did - the solution implemented, technologies adopted, and use cases addressed.
3. **Impact**: Quantify the results and business value achieved. Include before/after metrics where possible.

Focus on:
- Making the story relatable and compelling for similar prospects
- Including specific, quantifiable metrics where available
- Highlighting the technical architecture and integrations
- Emphasizing business outcomes, not just features

Generate a professional customer story that could be used for sales enablement and marketing.`;

    const userPrompt = `Create a customer story for ${accountData.name} (Industry: ${accountData.industry || 'Not specified'}).

## Available Account Data:

### Technologies in Use:
${technologiesContext}

### Use Cases:
${useCasesContext}

### Key Contacts:
${contactsContext}

### Next Best Actions (showing priorities):
${nbasContext}

### Transcript Insights:
${transcriptsContext}

Based on this information, generate a structured customer story.`;

    console.log("Generating customer story for:", accountData.name);

    const response = await fetch(aiConfig.endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${aiConfig.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: aiConfig.model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "create_customer_story",
              description: "Create a structured customer story",
              parameters: {
                type: "object",
                properties: {
                  title: { 
                    type: "string", 
                    description: "Compelling story title that captures the main outcome (e.g., 'How Acme Corp Reduced Onboarding Time by 60%')"
                  },
                  situation: { 
                    type: "string", 
                    description: "2-3 paragraphs describing the customer's initial context, challenges, and pain points BEFORE the solution"
                  },
                  situationMetrics: {
                    type: "string",
                    description: "Key metrics about their state before (e.g., '20+ hours/week on manual processes, 45% churn rate')"
                  },
                  behavior: { 
                    type: "string", 
                    description: "2-3 paragraphs describing what they did - the solution, technologies adopted, and implementation approach"
                  },
                  technologiesUsed: {
                    type: "array",
                    items: { type: "string" },
                    description: "List of key technologies involved in the solution"
                  },
                  useCases: {
                    type: "array",
                    items: { type: "string" },
                    description: "List of use cases addressed"
                  },
                  impact: { 
                    type: "string", 
                    description: "2-3 paragraphs describing the results, business value, and transformation achieved"
                  },
                  impactMetrics: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        metric: { type: "string", description: "What was measured" },
                        before: { type: "string", description: "Value before" },
                        after: { type: "string", description: "Value after" }
                      },
                      required: ["metric", "before", "after"]
                    },
                    description: "Quantifiable before/after metrics"
                  },
                  tags: {
                    type: "array",
                    items: { type: "string" },
                    description: "Tags for categorizing this story (e.g., 'onboarding', 'enterprise', 'SaaS')"
                  }
                },
                required: ["title", "situation", "situationMetrics", "behavior", "technologiesUsed", "useCases", "impact", "impactMetrics", "tags"]
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "create_customer_story" } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded, please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required, please add credits." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log("AI response received");

    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall?.function?.arguments) {
      throw new Error("No story generated from AI");
    }

    const story = JSON.parse(toolCall.function.arguments) as CustomerStory;

    return new Response(JSON.stringify(story), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("generate-customer-story error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), 
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

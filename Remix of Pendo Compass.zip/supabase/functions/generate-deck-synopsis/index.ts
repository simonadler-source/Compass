import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-session-token",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { accountName, opportunityName, painPoints, useCases, strategicChallenges, strategicInitiatives, operationalMetrics } = await req.json();

    if (!accountName) {
      return new Response(JSON.stringify({ error: "accountName is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiConfig = await getAIConfig("lite");

    const painPointsList = (painPoints || []).slice(0, 6).map((p: any) => `- ${p.pain_point}`).join("\n");
    const useCasesList = (useCases || []).slice(0, 6).map((u: any) => `- ${u.use_case || u.functional_area}`).join("\n");
    const challengesList = (strategicChallenges || []).slice(0, 4).map((t: any) => `- ${t.theme_name}: ${t.description || ""}`).join("\n");
    const initiativesList = (strategicInitiatives || []).slice(0, 4).map((t: any) => `- ${t.theme_name}: ${t.description || ""}`).join("\n");
    const metricsList = (operationalMetrics || []).slice(0, 8).map((m: any) => `- ${m.metric_name}: ${m.metric_value}${m.context ? ` (${m.context})` : ''}`).join("\n");

    const prompt = `You are writing a customer-facing executive synopsis for an evaluation deck being shared with ${accountName}. This is NOT an internal document — the customer will read this.

Write a concise 2-3 sentence synopsis that:
1. Describes what ${accountName} is looking to accomplish (based on their strategic initiatives and use cases)
2. Connects their challenges to the potential outcomes Pendo can deliver
3. Where operational metrics are available, weave in the scale of opportunity (e.g., "across X MAUs" or "streamlining workflows for Y teams")

Tone: Professional, collaborative, forward-looking, opportunity-focused. Do NOT mention internal health scores, risk assessments, or anything that sounds like an internal sales assessment. Frame the evaluation as a partnership to solve real business challenges.

Context:
Account: ${accountName}
Opportunity: ${opportunityName}

Strategic Challenges:
${challengesList || "None provided"}

Strategic Initiatives:
${initiativesList || "None provided"}

Key Pain Points:
${painPointsList || "None provided"}

Evaluation Use Cases:
${useCasesList || "None provided"}

Discovered Operational Metrics:
${metricsList || "None available"}

Return ONLY the synopsis text, no quotes, no labels, no markdown.`;

    // Retry up to 3 times on transient errors (503, 429)
    let response: Response | null = null;
    let lastError = "";
    for (let attempt = 0; attempt < 3; attempt++) {
      if (attempt > 0) {
        await new Promise(r => setTimeout(r, 1000 * Math.pow(2, attempt))); // exponential backoff
      }
      response = await fetch(aiConfig.endpoint, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${aiConfig.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: aiConfig.model,
          messages: [
            { role: "system", content: "You write concise, customer-facing executive summaries for technology evaluation decks. Be professional and collaborative in tone." },
            { role: "user", content: prompt },
          ],
          max_tokens: 300,
          temperature: 0.7,
        }),
      });

      if (response.ok) break;

      lastError = await response.text();
      console.error(`AI API attempt ${attempt + 1} failed (${response.status}):`, lastError);

      // Only retry on transient errors
      if (response.status !== 503 && response.status !== 429) {
        throw new Error(`AI API returned ${response.status}`);
      }
    }

    if (!response || !response.ok) {
      throw new Error(`AI API returned ${response?.status || 'unknown'} after 3 retries`);
    }

    const result = await response.json();
    const synopsis = result.choices?.[0]?.message?.content?.trim() || "";

    return new Response(JSON.stringify({ synopsis }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error generating synopsis:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Failed to generate synopsis" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Encryption helpers
function deriveKeyBytes(keyInput: string): Uint8Array {
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < raw.length && i < 32; i++) key[i] = raw[i];
  return key;
}
function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}
async function decryptValue(ciphertext: string, keyInput: string, ivBase64: string): Promise<string> {
  try {
    const keyBytes = deriveKeyBytes(keyInput);
    const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["decrypt"]);
    const iv = base64ToBytes(ivBase64);
    const encryptedBytes = base64ToBytes(ciphertext);
    const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv: new Uint8Array(iv).buffer as ArrayBuffer }, key, new Uint8Array(encryptedBytes));
    return new TextDecoder().decode(decrypted);
  } catch { return ""; }
}

const summarySchema = {
  type: "object",
  properties: {
    oneLiner: {
      type: "string",
      description: "2-3 sentence executive summary: current situation, key risk/blocker, and next critical action with timeline. Include deal value and close date if known. Written for a sales leader scanning a list of deals."
    },
    structuredBrief: {
      type: "object",
      properties: {
        status: { type: "string", description: "One sentence: where the deal stands right now" },
        keyRisks: { type: "array", items: { type: "string" }, description: "Top 2-3 risks or blockers" },
        nextSteps: { type: "array", items: { type: "string" }, description: "Top 2-3 next actions needed" },
        closeTimeline: { type: "string", description: "Expected close date and confidence assessment" },
        competitiveLandscape: { type: "string", description: "Brief competitive situation if any competitors detected, otherwise null" }
      },
      required: ["status", "keyRisks", "nextSteps", "closeTimeline"]
    },
    nextCriticalAction: {
      type: "string",
      description: "Single most important next step in under 15 words"
    }
  },
  required: ["oneLiner", "structuredBrief", "nextCriticalAction"]
};

async function buildOpportunityContext(supabase: any, opp: any, encryptionKey: string): Promise<{ context: string; transcriptIds: string[] }> {
  const transcriptIds: string[] = [];

  // Fetch related data in parallel
  const [
    { data: account },
    { data: painPoints },
    { data: useCases },
    { data: nbas },
    { data: seUpdate },
    { data: transcripts },
    { data: milestones },
    { data: competitors },
    { data: contacts },
  ] = await Promise.all([
    supabase.from("accounts").select("name, industry, stage, status").eq("id", opp.account_id).single(),
    supabase.from("account_pain_points").select("pain_point, pain_point_encrypted, severity, pain_category, encryption_iv").eq("opportunity_id", opp.id).limit(20),
    supabase.from("account_use_cases").select("use_case, use_case_encrypted, status, priority, encryption_iv").eq("opportunity_id", opp.id).limit(20),
    supabase.from("account_nbas").select("action, action_encrypted, status, priority, due_date, encryption_iv").eq("opportunity_id", opp.id).in("status", ["pending", "in_progress"]).limit(10),
    supabase.from("opportunity_se_updates").select("weekly_update, potential_risks, updated_at").eq("opportunity_id", opp.id).order("updated_at", { ascending: false }).limit(1).maybeSingle(),
    supabase.from("transcript_reviews").select("id, extracted_insights, created_at, momentum_meeting_id").eq("opportunity_id", opp.id).eq("status", "approved").order("created_at", { ascending: false }).limit(5),
    supabase.from("opportunity_milestones").select("name, scheduled_date, completed_date, status, phase").eq("opportunity_id", opp.id).order("scheduled_date", { ascending: true }),
    supabase.from("competitive_plays").select("competitor_name, play_title, play_type, status").eq("opportunity_id", opp.id).in("status", ["active", "suggested"]).limit(5),
    supabase.from("account_contacts").select("name_encrypted, role_encrypted, stakeholder_type, champion_score, sentiment, encryption_iv").eq("opportunity_id", opp.id).not("is_ignored", "eq", true).limit(10),
  ]);

  if (transcripts) {
    transcripts.forEach((t: any) => transcriptIds.push(t.id));
  }

  // Decrypt pain points
  const decryptedPains: string[] = [];
  if (painPoints) {
    for (const p of painPoints) {
      let text = p.pain_point;
      if (p.pain_point_encrypted && p.encryption_iv && encryptionKey) {
        text = await decryptValue(p.pain_point_encrypted, encryptionKey, p.encryption_iv);
      }
      if (text) decryptedPains.push(`[${p.severity || 'medium'}] ${text}`);
    }
  }

  // Decrypt use cases
  const decryptedUseCases: string[] = [];
  if (useCases) {
    for (const u of useCases) {
      let text = u.use_case;
      if (u.use_case_encrypted && u.encryption_iv && encryptionKey) {
        text = await decryptValue(u.use_case_encrypted, encryptionKey, u.encryption_iv);
      }
      if (text) decryptedUseCases.push(`[${u.status}/${u.priority}] ${text}`);
    }
  }

  // Decrypt NBAs
  const decryptedNBAs: string[] = [];
  if (nbas) {
    for (const n of nbas) {
      let text = n.action;
      if (n.action_encrypted && n.encryption_iv && encryptionKey) {
        text = await decryptValue(n.action_encrypted, encryptionKey, n.encryption_iv);
      }
      if (text) decryptedNBAs.push(`[${n.priority}${n.due_date ? ` due ${n.due_date}` : ''}] ${text}`);
    }
  }

  // Decrypt contacts
  const contactSummaries: string[] = [];
  if (contacts) {
    for (const c of contacts) {
      let name = 'Unknown';
      let role = '';
      if (c.name_encrypted && c.encryption_iv && encryptionKey) {
        name = await decryptValue(c.name_encrypted, encryptionKey, c.encryption_iv);
      }
      if (c.role_encrypted && c.encryption_iv && encryptionKey) {
        role = await decryptValue(c.role_encrypted, encryptionKey, c.encryption_iv);
      }
      contactSummaries.push(`${name} (${role || c.stakeholder_type || 'contact'}) - Champion: ${c.champion_score ?? '?'}, Sentiment: ${c.sentiment ?? '?'}`);
    }
  }

  // Extract recent insights from transcripts
  const recentInsightsSummary: string[] = [];
  if (transcripts) {
    for (const t of transcripts.slice(0, 3)) {
      if (t.extracted_insights) {
        const insights = typeof t.extracted_insights === 'string' ? JSON.parse(t.extracted_insights) : t.extracted_insights;
        if (insights.summary) recentInsightsSummary.push(insights.summary);
        if (insights.nextBestActions) {
          const actions = Array.isArray(insights.nextBestActions) ? insights.nextBestActions : [];
          actions.slice(0, 2).forEach((a: any) => {
            if (a.action) recentInsightsSummary.push(`NBA: ${a.action}`);
          });
        }
      }
    }
  }

  const milestoneSummary = milestones?.map((m: any) =>
    `${m.name}: ${m.status}${m.scheduled_date ? ` (${m.scheduled_date})` : ''}${m.completed_date ? ` ✓${m.completed_date}` : ''}`
  ).join('\n') || 'No milestones';

  const competitorSummary = competitors?.map((c: any) =>
    `${c.competitor_name}: ${c.play_title} (${c.play_type})`
  ).join('\n') || 'No competitors detected';

  const value = opp.value ? `$${(opp.value / 1000).toFixed(0)}k` : 'Unknown';

  const context = `
OPPORTUNITY: ${opp.name}
ACCOUNT: ${account?.name || 'Unknown'} (${account?.industry || 'Unknown industry'})
VALUE: ${value}
CLOSE DATE: ${opp.close_date || 'Not set'}
SALES STAGE: ${opp.sales_stage || opp.stage || 'Unknown'}
PRE-SALES STAGE: ${opp.pre_sales_stage || 'Unknown'}
RELATIONSHIP STATUS: ${opp.relationship_status || 'Unknown'}

SE WEEKLY UPDATE (most recent):
${seUpdate?.weekly_update || 'No SE update available'}

SE IDENTIFIED RISKS:
${seUpdate?.potential_risks || 'None noted'}

KEY STAKEHOLDERS:
${contactSummaries.join('\n') || 'No stakeholders mapped'}

PAIN POINTS (${decryptedPains.length}):
${decryptedPains.join('\n') || 'None identified'}

USE CASES (${decryptedUseCases.length}):
${decryptedUseCases.join('\n') || 'None identified'}

PENDING ACTIONS:
${decryptedNBAs.join('\n') || 'No pending actions'}

MILESTONES:
${milestoneSummary}

COMPETITIVE LANDSCAPE:
${competitorSummary}

RECENT MEETING INSIGHTS:
${recentInsightsSummary.join('\n') || 'No recent transcripts analyzed'}
`.trim();

  return { context, transcriptIds };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);
  const encryptionKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || "";

  try {
    const body = await req.json().catch(() => ({}));
    const singleOpportunityId = body.opportunityId;

    // Fetch opportunities to process
    let query = supabase
      .from("opportunities")
      .select("id, name, value, close_date, stage, sales_stage, pre_sales_stage, relationship_status, account_id, engagement_score, updated_at")
      .eq("is_archived", false);

    if (singleOpportunityId) {
      query = query.eq("id", singleOpportunityId);
    }

    const { data: opportunities, error: oppError } = await query;

    if (oppError) throw oppError;
    if (!opportunities?.length) {
      return new Response(JSON.stringify({ processed: 0, message: "No opportunities to process" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`[OppSummary] Processing ${opportunities.length} opportunities`);

    const aiConfig = await getAIConfig('standard');
    let processed = 0;
    let skipped = 0;
    let errors = 0;

    for (const opp of opportunities) {
      try {
        // Build context for this opportunity
        const { context, transcriptIds } = await buildOpportunityContext(supabase, opp, encryptionKey);

        // Simple content hash to skip unchanged opportunities
        let hash = 0;
        for (let i = 0; i < context.length; i++) {
          hash = ((hash << 5) - hash) + context.charCodeAt(i);
          hash = hash & hash;
        }
        const contentHash = hash.toString(16);

        // Check if we already have a summary with the same hash
        if (!singleOpportunityId) {
          const { data: existing } = await supabase
            .from("opportunity_summaries")
            .select("content_hash")
            .eq("opportunity_id", opp.id)
            .maybeSingle();

          if (existing?.content_hash === contentHash) {
            skipped++;
            continue;
          }
        }

        // Call AI
        const response = await fetch(aiConfig.endpoint, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${aiConfig.apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: aiConfig.model,
            messages: [
              {
                role: "system",
                content: `You are an expert Pre-Sales/SE leader creating concise deal situation reports. 
Your summaries help sales leaders quickly understand where each deal stands and what needs attention.
Be specific: use names, dates, values, and concrete actions. Avoid generic language.
Write the one-liner as if briefing a VP of Sales in a pipeline review — they need the critical facts fast.`
              },
              { role: "user", content: context }
            ],
            tools: [{
              type: "function",
              function: {
                name: "generate_opportunity_summary",
                description: "Generate a concise opportunity situation report",
                parameters: summarySchema
              }
            }],
            tool_choice: { type: "function", function: { name: "generate_opportunity_summary" } }
          }),
        });

        if (!response.ok) {
          const errText = await response.text();
          console.error(`[OppSummary] AI error for ${opp.id}: ${response.status} ${errText}`);
          if (response.status === 429) {
            // Rate limited — wait and continue
            await new Promise(r => setTimeout(r, 5000));
          }
          errors++;
          continue;
        }

        const data = await response.json();
        const result = JSON.parse(data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}");

        if (!result.oneLiner) {
          console.error(`[OppSummary] Empty result for ${opp.id}`);
          errors++;
          continue;
        }

        // Upsert the summary
        const { error: upsertError } = await supabase
          .from("opportunity_summaries")
          .upsert({
            opportunity_id: opp.id,
            one_liner: result.oneLiner,
            structured_brief: result.structuredBrief || {},
            key_risks: result.structuredBrief?.keyRisks || [],
            next_critical_action: result.nextCriticalAction || null,
            source_transcript_ids: transcriptIds,
            content_hash: contentHash,
            generated_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }, { onConflict: "opportunity_id" });

        if (upsertError) {
          console.error(`[OppSummary] Upsert error for ${opp.id}:`, upsertError);
          errors++;
          continue;
        }

        processed++;
        console.log(`[OppSummary] Generated summary for: ${opp.name}`);

        // Small delay between API calls to avoid rate limits
        if (!singleOpportunityId && opportunities.length > 1) {
          await new Promise(r => setTimeout(r, 1000));
        }
      } catch (e) {
        console.error(`[OppSummary] Error processing ${opp.id}:`, e);
        errors++;
      }
    }

    return new Response(JSON.stringify({ processed, skipped, errors, total: opportunities.length }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("[OppSummary] Fatal error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

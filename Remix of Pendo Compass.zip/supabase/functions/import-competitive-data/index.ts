import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface RubricRow {
  category: string;
  subcategory: string;
  level_1_description: string;
  level_2_description: string;
  level_3_description: string;
  level_4_description: string;
  level_5_description: string;
}

interface ScorecardRow {
  vendor_name: string;
  category: string;
  subcategory: string;
  score: number;
}

interface SourceRow {
  reference_number: string;
  source_name: string;
  source_description: string;
  subcategory_alignment: string;
  source_url: string;
  status: string;
  added_by: string;
  date_added: string;
  last_used_date: string;
  key_takeaways: string;
}

function parseCSV(csvText: string): string[][] {
  const lines: string[][] = [];
  let currentLine: string[] = [];
  let currentField = '';
  let inQuotes = false;
  
  for (let i = 0; i < csvText.length; i++) {
    const char = csvText[i];
    const nextChar = csvText[i + 1];
    
    if (inQuotes) {
      if (char === '"' && nextChar === '"') {
        currentField += '"';
        i++;
      } else if (char === '"') {
        inQuotes = false;
      } else {
        currentField += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        currentLine.push(currentField.trim());
        currentField = '';
      } else if (char === '\n' || (char === '\r' && nextChar === '\n')) {
        currentLine.push(currentField.trim());
        if (currentLine.some(f => f !== '')) {
          lines.push(currentLine);
        }
        currentLine = [];
        currentField = '';
        if (char === '\r') i++;
      } else {
        currentField += char;
      }
    }
  }
  
  if (currentField || currentLine.length > 0) {
    currentLine.push(currentField.trim());
    if (currentLine.some(f => f !== '')) {
      lines.push(currentLine);
    }
  }
  
  return lines;
}

function parseRubric(csvText: string): RubricRow[] {
  const lines = parseCSV(csvText);
  if (lines.length < 2) return [];
  
  const rows: RubricRow[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (line.length >= 7 && line[0] && line[1]) {
      rows.push({
        category: line[0],
        subcategory: line[1],
        level_1_description: line[2] || '',
        level_2_description: line[3] || '',
        level_3_description: line[4] || '',
        level_4_description: line[5] || '',
        level_5_description: line[6] || '',
      });
    }
  }
  
  return rows;
}

function parseScorecard(csvText: string): ScorecardRow[] {
  const lines = parseCSV(csvText);
  if (lines.length < 2) return [];
  
  const headers = lines[0];
  const vendorNames = headers.slice(2); // Skip Category, Subcategory
  const rows: ScorecardRow[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    const category = line[0];
    const subcategory = line[1];
    
    // Skip total/average rows and empty rows
    if (!category || !subcategory || subcategory === 'Category Average' || subcategory === 'Product Totals' || subcategory.includes('Average')) {
      continue;
    }
    
    for (let j = 2; j < line.length && j - 2 < vendorNames.length; j++) {
      const vendorName = vendorNames[j - 2];
      const scoreStr = line[j];
      const score = parseFloat(scoreStr) || 0;
      
      if (vendorName && vendorName.trim()) {
        rows.push({
          vendor_name: vendorName.trim(),
          category,
          subcategory,
          score,
        });
      }
    }
  }
  
  return rows;
}

function parseSources(csvText: string): SourceRow[] {
  const lines = parseCSV(csvText);
  if (lines.length < 2) return [];
  
  const rows: SourceRow[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (line.length >= 5 && line[0]) {
      rows.push({
        reference_number: line[0] || '',
        source_name: line[1] || '',
        source_description: line[2] || '',
        subcategory_alignment: line[3] || '',
        source_url: line[4] || '',
        status: line[5] || 'active',
        added_by: line[6] || '',
        date_added: line[7] || '',
        last_used_date: line[8] || '',
        key_takeaways: line[9] || '',
      });
    }
  }
  
  return rows;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { action, rubricCsv, scorecardCsv, sourcesCsv } = await req.json();

    const results: any = { success: true, imported: {} };

    // Import rubric data
    if (rubricCsv) {
      const rubricRows = parseRubric(rubricCsv);
      console.log(`Parsed ${rubricRows.length} rubric rows`);
      
      if (rubricRows.length > 0) {
        // Clear existing and insert new
        await supabase.from('competitive_rubric').delete().neq('id', '00000000-0000-0000-0000-000000000000');
        
        const { error } = await supabase.from('competitive_rubric').upsert(
          rubricRows.map(r => ({
            category: r.category,
            subcategory: r.subcategory,
            level_1_description: r.level_1_description,
            level_2_description: r.level_2_description,
            level_3_description: r.level_3_description,
            level_4_description: r.level_4_description,
            level_5_description: r.level_5_description,
          })),
          { onConflict: 'category,subcategory' }
        );
        
        if (error) {
          console.error('Rubric import error:', error);
          results.imported.rubric = { error: error.message };
        } else {
          results.imported.rubric = { count: rubricRows.length };
        }
      }
    }

    // Import scorecard data
    if (scorecardCsv) {
      const scorecardRows = parseScorecard(scorecardCsv);
      console.log(`Parsed ${scorecardRows.length} scorecard rows`);
      
      if (scorecardRows.length > 0) {
        // Get rubric IDs for linking
        const { data: rubrics } = await supabase.from('competitive_rubric').select('id, category, subcategory');
        const rubricMap = new Map(
          (rubrics || []).map(r => [`${r.category}|${r.subcategory}`, r.id])
        );
        
        // Clear existing scores
        await supabase.from('competitive_scorecard').delete().neq('id', '00000000-0000-0000-0000-000000000000');
        
        // Batch insert in chunks
        const chunkSize = 500;
        let insertedCount = 0;
        
        for (let i = 0; i < scorecardRows.length; i += chunkSize) {
          const chunk = scorecardRows.slice(i, i + chunkSize);
          const { error } = await supabase.from('competitive_scorecard').insert(
            chunk.map(r => ({
              vendor_name: r.vendor_name,
              category: r.category,
              subcategory: r.subcategory,
              score: r.score,
              rubric_id: rubricMap.get(`${r.category}|${r.subcategory}`) || null,
            }))
          );
          
          if (error) {
            console.error('Scorecard chunk error:', error);
          } else {
            insertedCount += chunk.length;
          }
        }
        
        results.imported.scorecard = { count: insertedCount, total: scorecardRows.length };
      }
    }

    // Import sources data
    if (sourcesCsv) {
      const sourceRows = parseSources(sourcesCsv);
      console.log(`Parsed ${sourceRows.length} source rows`);
      
      if (sourceRows.length > 0) {
        // Clear existing
        await supabase.from('competitive_sources').delete().neq('id', '00000000-0000-0000-0000-000000000000');
        
        const parseDate = (dateStr: string): string | null => {
          if (!dateStr) return null;
          try {
            const d = new Date(dateStr);
            return isNaN(d.getTime()) ? null : d.toISOString().split('T')[0];
          } catch {
            return null;
          }
        };
        
        const { error } = await supabase.from('competitive_sources').insert(
          sourceRows.map(r => ({
            reference_number: r.reference_number,
            source_name: r.source_name,
            source_description: r.source_description,
            subcategory_alignment: r.subcategory_alignment,
            source_url: r.source_url,
            status: r.status || 'active',
            added_by: r.added_by,
            date_added: parseDate(r.date_added),
            last_used_date: parseDate(r.last_used_date),
            key_takeaways: r.key_takeaways,
          }))
        );
        
        if (error) {
          console.error('Sources import error:', error);
          results.imported.sources = { error: error.message };
        } else {
          results.imported.sources = { count: sourceRows.length };
        }
      }
    }

    // Get summary statistics
    const { count: rubricCount } = await supabase.from('competitive_rubric').select('*', { count: 'exact', head: true });
    const { count: scorecardCount } = await supabase.from('competitive_scorecard').select('*', { count: 'exact', head: true });
    const { count: sourcesCount } = await supabase.from('competitive_sources').select('*', { count: 'exact', head: true });
    
    const { data: uniqueVendors } = await supabase.from('competitive_scorecard').select('vendor_name').limit(100);
    const vendorSet = new Set((uniqueVendors || []).map(v => v.vendor_name));

    results.summary = {
      rubricCategories: rubricCount,
      scorecardEntries: scorecardCount,
      sources: sourcesCount,
      uniqueVendors: vendorSet.size,
    };

    return new Response(JSON.stringify(results), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Import error:', error);
    return new Response(JSON.stringify({ success: false, error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

import { createClient } from "npm:@supabase/supabase-js@2";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

const GATEWAY_URL = 'https://connector-gateway.lovable.dev/slack/api';

interface ExtractedIntel {
  competitor_name: string;
  subcategories: string[];
  signals: {
    type: 'pricing' | 'weakness' | 'strength' | 'win_story' | 'loss_story' | 'feature_gap' | 'market_position' | 'partnership' | 'general';
    detail: string;
    confidence: 'high' | 'medium' | 'low';
  }[];
  key_takeaways: string;
}

// ─── Slack API helpers ────────────────────────────────────────────

async function getSlackHeaders(): Promise<Record<string, string>> {
  const lovableKey = Deno.env.get('LOVABLE_API_KEY');
  const slackKey = Deno.env.get('SLACK_API_KEY');
  if (!lovableKey) throw new Error('LOVABLE_API_KEY is not configured');
  if (!slackKey) throw new Error('SLACK_API_KEY is not configured');
  return {
    'Authorization': `Bearer ${lovableKey}`,
    'X-Connection-Api-Key': slackKey,
    'Content-Type': 'application/json',
  };
}

async function fetchChannelHistory(
  channelId: string,
  oldest?: string,
  limit = 100,
): Promise<any[]> {
  const headers = await getSlackHeaders();
  const params = new URLSearchParams({ channel: channelId, limit: String(limit) });
  if (oldest) params.set('oldest', oldest);

  const resp = await fetch(`${GATEWAY_URL}/conversations.history?${params}`, { headers });
  const data = await resp.json();
  if (!data.ok) {
    if (data.error === 'not_in_channel') {
      throw new Error(`Slack channel access error: bot is not in channel ${channelId}. Invite the Lovable App to this channel or reconnect Slack with channels:join scope.`);
    }
    throw new Error(`Slack API error: ${data.error}`);
  }
  return data.messages || [];
}

async function fetchThreadReplies(
  channelId: string,
  threadTs: string,
): Promise<any[]> {
  const headers = await getSlackHeaders();
  const params = new URLSearchParams({ channel: channelId, ts: threadTs, limit: '200' });
  const resp = await fetch(`${GATEWAY_URL}/conversations.replies?${params}`, { headers });
  const data = await resp.json();
  if (!data.ok) throw new Error(`Slack thread error: ${data.error}`);
  return data.messages || [];
}

async function resolveUserName(userId: string): Promise<string> {
  try {
    const headers = await getSlackHeaders();
    const resp = await fetch(`${GATEWAY_URL}/users.info?user=${userId}`, { headers });
    const data = await resp.json();
    if (data.ok) {
      return data.user?.real_name || data.user?.name || userId;
    }
  } catch (_) { /* fallback */ }
  return userId;
}

// ─── AI extraction ────────────────────────────────────────────────

interface AccountIntel {
  pain_points: { pain_point: string; severity: string; confidence: string }[];
  use_cases: { use_case: string; status: string; confidence: string }[];
  stakeholder_signals: { name: string; role: string; sentiment: string; signal: string }[];
  key_takeaways: string;
}

function buildPromptForPurpose(
  purpose: string,
  messageText: string,
  competitorNames: string[],
): string {
  if (purpose === 'account' || purpose === 'opportunity') {
    return `You are a sales intelligence analyst. Extract actionable signals from this internal Slack message about a customer account/opportunity.

Message:
${messageText}

Instructions:
1. Extract pain points mentioned (with severity: critical/high/medium/low and confidence: high/medium/low).
2. Extract use cases or requirements discussed (with status: identified/validated/committed and confidence).
3. Extract stakeholder signals: who was mentioned, their role, sentiment (positive/neutral/negative), and what signal was shared.
4. Summarize key takeaways in 1-2 sentences.

Return ONLY valid JSON:
{
  "pain_points": [{ "pain_point": "...", "severity": "high", "confidence": "high" }],
  "use_cases": [{ "use_case": "...", "status": "identified", "confidence": "medium" }],
  "stakeholder_signals": [{ "name": "...", "role": "...", "sentiment": "positive", "signal": "..." }],
  "key_takeaways": "..."
}

If no relevant signals found, return empty arrays.`;
  }

  // Default: competitive intel
  return `You are a competitive intelligence analyst. Extract competitive signals from this internal Slack message.

Known competitors: ${competitorNames.join(', ')}

Message:
${messageText}

Instructions:
1. Identify ALL competitors mentioned (including ones not in the known list).
2. For each competitor, extract signals: pricing changes, weaknesses, strengths, win/loss stories, feature gaps, market positioning, partnerships.
3. Map signals to relevant scorecard subcategories where possible.
4. Rate confidence: "high" (specific data/quote), "medium" (general observation), "low" (hearsay/rumor).

Return ONLY a JSON array:
[{
  "competitor_name": "Exact name",
  "subcategories": ["Analytics", "Guides"],
  "signals": [{ "type": "weakness", "detail": "Cannot target announcements to multiple segments simultaneously", "confidence": "high" }],
  "key_takeaways": "Brief summary of intel about this competitor"
}]

If no competitive intel found, return [].`;
}

async function extractIntel(
  messageText: string,
  purpose: string,
  competitorNames: string[],
  aiConfig: { endpoint: string; apiKey: string; model: string },
): Promise<any> {
  const prompt = buildPromptForPurpose(purpose, messageText, competitorNames);

  const resp = await fetch(aiConfig.endpoint, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${aiConfig.apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: aiConfig.model,
      messages: [
        { role: 'system', content: 'Extract intelligence from internal communications. Return valid JSON only.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.1,
      max_tokens: 4000,
    }),
  });

  if (!resp.ok) throw new Error(`AI error: ${resp.status}`);
  const result = await resp.json();
  const text = result.choices?.[0]?.message?.content || (purpose === 'competitive' || purpose === 'general' ? '[]' : '{}');

  try {
    let jsonStr = text.trim();
    const fenceMatch = jsonStr.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (fenceMatch) jsonStr = fenceMatch[1].trim();
    // Find first [ or {
    const arrStart = jsonStr.indexOf('[');
    const objStart = jsonStr.indexOf('{');
    if (purpose === 'competitive' || purpose === 'general') {
      if (arrStart >= 0) jsonStr = jsonStr.substring(arrStart);
    } else {
      if (objStart >= 0) jsonStr = jsonStr.substring(objStart);
    }
    return JSON.parse(jsonStr);
  } catch (_) {
    console.error('Failed to parse AI extraction:', text.substring(0, 500));
    return purpose === 'competitive' || purpose === 'general' ? [] : { pain_points: [], use_cases: [], stakeholder_signals: [], key_takeaways: '' };
  }
}

// ─── Main handler ─────────────────────────────────────────────────

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const body = await req.json();
    const {
      channelId,                // Required — passed per-channel from the frontend
      channelPurpose = 'competitive', // 'competitive' | 'account' | 'opportunity' | 'general'
      linkedAccountId,          // For account/opportunity purpose
      linkedOpportunityId,      // For opportunity purpose
      manualText,               // For manual paste mode
      authorName,               // Manual paste author
      lookbackHours = 24,
    } = body;

    if (!channelId && !manualText) {
      return new Response(JSON.stringify({ error: 'channelId is required for live pull mode' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const aiConfig = await getAIConfig('standard');

    // Fetch known competitors
    const { data: competitors } = await supabase
      .from('technology_repository')
      .select('name')
      .eq('is_competitor', true);
    const competitorNames = (competitors || []).map((c: any) => c.name);

    let messagesToProcess: { text: string; author: string; ts: string; threadTs?: string }[] = [];

    if (manualText) {
      // Manual paste mode
      messagesToProcess = [{
        text: manualText,
        author: authorName || 'Manual Import',
        ts: String(Date.now() / 1000),
      }];
    } else {
      // Live Slack pull mode
      const oldest = String(Math.floor(Date.now() / 1000) - lookbackHours * 3600);
      const messages = await fetchChannelHistory(channelId, oldest);

      // Filter to messages that are substantial (>50 chars) and have threads or mentions
      const relevantMessages = messages.filter((m: any) =>
        m.text && m.text.length > 50 && !m.bot_id
      );

      console.log(`Found ${messages.length} messages, ${relevantMessages.length} relevant`);

      // Resolve usernames and collect thread replies
      const userCache = new Map<string, string>();

      for (const msg of relevantMessages) {
        // Resolve author
        if (msg.user && !userCache.has(msg.user)) {
          userCache.set(msg.user, await resolveUserName(msg.user));
        }
        const author = userCache.get(msg.user) || msg.user || 'Unknown';

        let fullText = msg.text;

        // If message has a thread, fetch replies and concatenate
        if (msg.reply_count && msg.reply_count > 0) {
          try {
            const replies = await fetchThreadReplies(channelId, msg.ts);
            for (const reply of replies) {
              if (reply.ts === msg.ts) continue; // skip parent
              if (reply.user && !userCache.has(reply.user)) {
                userCache.set(reply.user, await resolveUserName(reply.user));
              }
              const replyAuthor = userCache.get(reply.user) || reply.user || 'Unknown';
              fullText += `\n\n${replyAuthor}: ${reply.text}`;
            }
          } catch (e) {
            console.warn(`Failed to fetch thread ${msg.ts}:`, e.message);
          }
        }

        messagesToProcess.push({
          text: fullText,
          author,
          ts: msg.ts,
          threadTs: msg.thread_ts,
        });
      }
    }

    if (messagesToProcess.length === 0) {
      return new Response(JSON.stringify({ success: true, processed: 0, message: 'No messages to process' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Processing ${messagesToProcess.length} messages (purpose: ${channelPurpose})`);

    let totalInserted = 0;

    for (const msg of messagesToProcess) {
      const intel = await extractIntel(msg.text, channelPurpose, competitorNames, aiConfig);

      if (channelPurpose === 'competitive' || channelPurpose === 'general') {
        // Competitive intel: array of ExtractedIntel
        const entries = Array.isArray(intel) ? intel : [];
        for (const entry of entries) {
          if (!entry.competitor_name || !entry.signals?.length) continue;

          const rows = entry.signals.map((signal: any) => ({
            vendor_name: entry.competitor_name,
            subcategory: entry.subcategories?.[0] || 'General',
            current_score: null,
            file_score: null,
            file_score_term: null,
            rationale: signal.detail,
            evidence_source: `Slack — ${msg.author}`,
            evidence_confidence_weight: signal.confidence === 'high' ? 0.9 : signal.confidence === 'medium' ? 0.7 : 0.4,
            status: 'pending',
            source_type: 'slack_intel',
            type: signal.type,
            evidence_url: manualText ? null : `slack://channel/${channelId}/message/${msg.ts}`,
          }));

          const { error } = await supabase.from('competitive_audit_log').insert(rows);
          if (error) {
            console.error(`Insert error for ${entry.competitor_name}:`, error.message);
          } else {
            totalInserted += rows.length;
          }
        }
      } else if ((channelPurpose === 'account' || channelPurpose === 'opportunity') && (linkedAccountId || linkedOpportunityId)) {
        // Account/Opportunity intel: insert pain points, use cases, stakeholder signals
        const accountIntel = intel as AccountIntel;
        const targetAccountId = linkedAccountId;
        const targetOppId = linkedOpportunityId;

        // Insert pain points
        if (accountIntel.pain_points?.length > 0 && targetAccountId) {
          for (const pp of accountIntel.pain_points) {
            const { error } = await supabase.from('account_pain_points').insert({
              account_id: targetAccountId,
              opportunity_id: targetOppId || null,
              pain_point: pp.pain_point,
              severity: pp.severity,
              confidence_score: pp.confidence === 'high' ? 0.9 : pp.confidence === 'medium' ? 0.7 : 0.4,
              source: 'slack',
            });
            if (!error) totalInserted++;
            else console.error('Pain point insert error:', error.message);
          }
        }

        // Insert use cases
        if (accountIntel.use_cases?.length > 0 && targetAccountId) {
          for (const uc of accountIntel.use_cases) {
            const { error } = await supabase.from('account_use_cases').insert({
              account_id: targetAccountId,
              opportunity_id: targetOppId || null,
              use_case: uc.use_case,
              status: uc.status || 'identified',
              confidence_score: uc.confidence === 'high' ? 0.9 : uc.confidence === 'medium' ? 0.7 : 0.4,
              source: 'slack',
            });
            if (!error) totalInserted++;
            else console.error('Use case insert error:', error.message);
          }
        }

        // Log stakeholder signals as activity signals or insight snapshots
        if (accountIntel.stakeholder_signals?.length > 0 && targetAccountId) {
          for (const ss of accountIntel.stakeholder_signals) {
            await supabase.from('account_insight_snapshots').insert({
              account_id: targetAccountId,
              opportunity_id: targetOppId || null,
              insight_type: 'stakeholder_signal',
              change_source: 'slack',
              data_cleartext: { name: ss.name, role: ss.role, sentiment: ss.sentiment, signal: ss.signal },
              change_reason: `Slack signal: ${ss.signal?.substring(0, 100)}`,
            });
            totalInserted++;
          }
        }
      }

      // Rate limit between messages
      if (messagesToProcess.length > 1) {
        await new Promise(r => setTimeout(r, 1000));
      }
    }

    console.log(`Competitive intel ingestion complete: ${totalInserted} signals from ${messagesToProcess.length} messages`);

    return new Response(JSON.stringify({
      success: true,
      processed: messagesToProcess.length,
      signals_inserted: totalInserted,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Ingest error:', error);
    return new Response(JSON.stringify({ success: false, error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

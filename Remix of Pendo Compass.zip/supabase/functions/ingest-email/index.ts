import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ResendWebhookEvent {
  type: string;
  created_at: string;
  data: {
    email_id: string;
    created_at: string;
    from: string;
    to: string[];
    cc?: string[];
    bcc?: string[];
    subject: string;
    attachments?: Array<{ filename: string; content_type: string }>;
  };
}

function normalizeEmail(e: string): string {
  const match = e.match(/<([^>]+)>/);
  return (match ? match[1] : e).trim().toLowerCase();
}

function parseEmails(field: string | string[] | undefined | null): string[] {
  if (!field) return [];
  if (Array.isArray(field)) return field.map(normalizeEmail).filter(Boolean);
  return field.split(",").map(normalizeEmail).filter(Boolean);
}

/** Extract all email addresses from forwarded email body text */
function extractEmailsFromBody(text: string): string[] {
  if (!text) return [];
  const emailRegex = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
  const matches = text.match(emailRegex) || [];
  return [...new Set(matches.map(e => e.toLowerCase()))];
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  const supabase = createClient(supabaseUrl, supabaseKey);

  try {
    const event: ResendWebhookEvent = await req.json();
    
    // Validate event type
    if (event.type !== "email.received") {
      console.log("[ingest-email] Ignoring non-receive event:", event.type);
      return new Response(JSON.stringify({ success: true, skipped: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const emailData = event.data;
    console.log("[ingest-email] Received email from:", emailData.from, "subject:", emailData.subject);

    const fromEmail = normalizeEmail(emailData.from);
    const toEmails = parseEmails(emailData.to);
    const ccEmails = parseEmails(emailData.cc);
    const bccEmails = parseEmails(emailData.bcc);
    const allExternalEmails = [...new Set([fromEmail, ...toEmails, ...ccEmails, ...bccEmails])];

    // --- Fetch email body via Resend API ---
    let textBody: string | null = null;
    let htmlBody: string | null = null;
    let emailHeaders: Record<string, string>[] | null = null;
    let emailSentAt: string | null = null;

    if (resendApiKey && emailData.email_id) {
      try {
        const res = await fetch(`https://api.resend.com/emails/receiving/${emailData.email_id}`, {
          headers: { Authorization: `Bearer ${resendApiKey}` },
        });
        if (res.ok) {
          const fullEmail = await res.json();
          textBody = fullEmail.text || null;
          htmlBody = fullEmail.html || null;
          emailHeaders = fullEmail.headers || null;
          // Try to extract sent date from headers (may be object or array)
          if (emailHeaders) {
            let dateVal: string | null = null;
            if (Array.isArray(emailHeaders)) {
              const dateHeader = emailHeaders.find((h: any) => 
                (h.name || Object.keys(h)[0])?.toLowerCase() === "date"
              );
              if (dateHeader) dateVal = dateHeader.value || Object.values(dateHeader)[0] as string;
            } else if (typeof emailHeaders === 'object') {
              // Object format: { "date": "...", "from": "...", ... }
              dateVal = emailHeaders["date"] || emailHeaders["Date"] || null;
            }
            if (dateVal) {
              const parsed = Date.parse(dateVal);
              emailSentAt = Number.isNaN(parsed) ? null : new Date(parsed).toISOString();
            }
          }
          console.log("[ingest-email] Headers type:", typeof emailHeaders, Array.isArray(emailHeaders) ? "array" : "");
          console.log("[ingest-email] Fetched email body, text length:", textBody?.length || 0);
        } else {
          console.error("[ingest-email] Failed to fetch email body:", res.status, await res.text());
        }
      } catch (fetchErr) {
        console.error("[ingest-email] Error fetching email body:", fetchErr);
      }
    }

    // Use webhook created_at as fallback for sent date
    if (!emailSentAt) {
      emailSentAt = emailData.created_at || event.created_at || null;
    }

    // --- Extract emails from the forwarded body for better matching ---
    const bodyEmails = extractEmailsFromBody(textBody || "");
    const allCandidateEmails = [...new Set([...allExternalEmails, ...bodyEmails])];

    // --- Step 1: Identify internal team emails to exclude ---
    const { data: teamProfiles } = await supabase
      .from("profiles")
      .select("email")
      .in("email", allCandidateEmails);

    const internalEmails = new Set((teamProfiles || []).map(p => p.email?.toLowerCase()).filter(Boolean));
    // Also exclude known forwarding/system addresses
    const systemDomains = ["sependo.org", "resend.dev"];
    const externalEmails = allCandidateEmails.filter(e => 
      !internalEmails.has(e) && !systemDomains.some(d => e.endsWith(`@${d}`))
    );

    console.log("[ingest-email] External emails to match:", externalEmails, "(from body:", bodyEmails.length, ")");

    // --- Step 2: Match external emails against account_contacts ---
    let matchedAccountId: string | null = null;
    let matchedOpportunityId: string | null = null;
    let matchConfidence = 0;
    let matchMethod: string | null = null;
    const matchDetails: Record<string, unknown> = {};

    if (externalEmails.length > 0) {
      // Try matching via account_contacts (encrypted emails need decryption - check cleartext first)
      // account_contacts email is encrypted, so we check account_team_members and opportunity contacts
      
      // Try matching via team_members email lookups first
      const { data: teamMembers } = await supabase
        .from("account_team_members")
        .select("account_id, team_member_email")
        .in("team_member_email", externalEmails);

      if (teamMembers && teamMembers.length > 0) {
        matchedAccountId = teamMembers[0].account_id;
        matchConfidence = 0.7;
        matchMethod = "team_member_match";
        matchDetails.matched_email = teamMembers[0].team_member_email;
        matchDetails.matched_external_emails = externalEmails;
      }

      // Try opportunities that have primary_se_email matching
      if (!matchedAccountId) {
        const { data: oppMatches } = await supabase
          .from("opportunities")
          .select("id, account_id, name, primary_se_email")
          .in("primary_se_email", externalEmails)
          .limit(5);

        if (oppMatches && oppMatches.length > 0) {
          matchedAccountId = oppMatches[0].account_id;
          matchedOpportunityId = oppMatches[0].id;
          matchConfidence = 0.75;
          matchMethod = "opportunity_se_match";
          matchDetails.matched_opportunity = oppMatches[0].name;
        }
      }
    }

    // --- Step 3: Subject-based matching ---
    if (!matchedAccountId && emailData.subject) {
      const { data: accounts } = await supabase
        .from("accounts")
        .select("id, name")
        .limit(500);

      if (accounts) {
        const subjectLower = emailData.subject.toLowerCase();
        for (const account of accounts) {
          if (account.name && subjectLower.includes(account.name.toLowerCase())) {
            matchedAccountId = account.id;
            matchConfidence = 0.5;
            matchMethod = "subject_match";
            matchDetails.matched_term = account.name;
            break;
          }
        }
      }
    }

    // --- Step 4: AI fallback for matching ---
    if (!matchedAccountId && (textBody || emailData.subject)) {
      try {
        const { data: accounts } = await supabase
          .from("accounts")
          .select("id, name, industry")
          .limit(200);

        if (accounts && accounts.length > 0) {
          const aiConfig = await getAIConfig("lite");
          const accountList = accounts.map(a => `${a.id}|${a.name}${a.industry ? ` (${a.industry})` : ""}`).join("\n");
          const emailSnippet = (textBody || "").slice(0, 2000);

          const aiResponse = await fetch(aiConfig.endpoint, {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${aiConfig.apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: aiConfig.model,
              messages: [
                {
                  role: "system",
                  content: `You match emails to accounts. Given an email subject and snippet, return the best matching account ID from the list, or "NONE" if no match. Reply with ONLY the account UUID or "NONE".`,
                },
                {
                  role: "user",
                  content: `Subject: ${emailData.subject}\n\nEmail snippet:\n${emailSnippet}\n\nAccounts:\n${accountList}`,
                },
              ],
              max_tokens: 100,
              temperature: 0,
            }),
          });

          if (aiResponse.ok) {
            const aiData = await aiResponse.json();
            const aiResult = aiData.choices?.[0]?.message?.content?.trim();
            if (aiResult && aiResult !== "NONE" && aiResult.match(/^[0-9a-f-]{36}$/i)) {
              const validAccount = accounts.find(a => a.id === aiResult);
              if (validAccount) {
                matchedAccountId = aiResult;
                matchConfidence = 0.4;
                matchMethod = "ai_fallback";
                matchDetails.ai_matched_account = validAccount.name;
              }
            }
          }
        }
      } catch (aiError) {
        console.error("[ingest-email] AI matching failed:", aiError);
      }
    }

    // --- Step 5: If matched, try to find the best opportunity ---
    if (matchedAccountId && !matchedOpportunityId) {
      const { data: opps } = await supabase
        .from("opportunities")
        .select("id, name")
        .eq("account_id", matchedAccountId)
        .eq("is_archived", false)
        .order("updated_at", { ascending: false })
        .limit(1);

      if (opps && opps.length > 0) {
        matchedOpportunityId = opps[0].id;
        matchDetails.auto_linked_opportunity = opps[0].name;
      }
    }

    // Match if we have body-extracted contacts (high confidence) or good AI match
    const matchStatus = matchedAccountId && (matchConfidence >= 0.5 || (bodyEmails.length > 0 && matchConfidence >= 0.35)) ? "matched" : "review";

    // --- Step 6: Insert into inbound_emails ---
    const fromName = emailData.from?.match(/^([^<]+)/)?.[1]?.trim() || null;
    
    const { data: emailRecord, error: insertError } = await supabase
      .from("inbound_emails")
      .insert({
        resend_message_id: emailData.email_id,
        from_email: fromEmail,
        from_name: fromName !== fromEmail ? fromName : null,
        to_emails: toEmails,
        cc_emails: ccEmails,
        bcc_emails: bccEmails,
        subject: emailData.subject,
        text_body: textBody,
        html_body: htmlBody,
        raw_headers: emailHeaders ? JSON.parse(JSON.stringify(emailHeaders)) : null,
        email_sent_at: emailSentAt,
        match_status: matchStatus,
        matched_account_id: matchedAccountId,
        matched_opportunity_id: matchedOpportunityId,
        match_confidence: matchConfidence,
        match_method: matchMethod,
        match_details: matchDetails,
      })
      .select("id")
      .single();

    if (insertError) {
      console.error("[ingest-email] Insert error:", insertError);
      throw new Error(`Failed to store email: ${insertError.message}`);
    }

    console.log("[ingest-email] Stored email:", emailRecord.id, "status:", matchStatus, "account:", matchedAccountId, "opportunity:", matchedOpportunityId);

    // --- Step 7: If matched, create transcript_review for analysis ---
    if (matchStatus === "matched" && matchedAccountId && textBody) {
      try {
        const { data: review, error: reviewError } = await supabase
          .from("transcript_reviews")
          .insert({
            transcript_content: textBody,
            file_name: `Email: ${emailData.subject || "No Subject"}`,
            suggested_account_id: matchedAccountId,
            suggested_account_confidence: matchConfidence,
            final_account_id: matchedAccountId,
            opportunity_id: matchedOpportunityId,
            status: "approved",
            meeting_type: "email",
            meeting_context: JSON.stringify({
              source: "inbound_email",
              inbound_email_id: emailRecord.id,
              from: fromEmail,
              subject: emailData.subject,
              email_sent_at: emailSentAt,
              external_contacts: externalEmails,
            }),
          })
          .select("id")
          .single();

        if (reviewError) {
          console.error("[ingest-email] Review creation error:", reviewError);
        } else {
          // Update inbound_emails with the transcript link
          await supabase
            .from("inbound_emails")
            .update({
              transcript_review_id: review.id,
              match_status: "processed",
              processed_at: new Date().toISOString(),
            })
            .eq("id", emailRecord.id);

          console.log("[ingest-email] Created transcript review:", review.id);

          // Create a system notification for the new email ingestion
          try {
            const { data: acct } = await supabase
              .from("accounts")
              .select("name")
              .eq("id", matchedAccountId)
              .single();
            const accountName = acct?.name || "Unknown Account";

            let oppName: string | null = null;
            if (matchedOpportunityId) {
              const { data: opp } = await supabase
                .from("opportunities")
                .select("name")
                .eq("id", matchedOpportunityId)
                .single();
              oppName = opp?.name || null;
            }

            const notifTitle = `New Email Detected: ${accountName}`;
            const notifMessage = oppName
              ? `"${emailData.subject}" from ${fromEmail} matched to opportunity "${oppName}".`
              : `"${emailData.subject}" from ${fromEmail} matched to account "${accountName}".`;

            await supabase.from("system_notifications").insert({
              type: "email_ingested",
              title: notifTitle,
              message: notifMessage,
              data: {
                inbound_email_id: emailRecord.id,
                transcript_review_id: review.id,
                account_id: matchedAccountId,
                opportunity_id: matchedOpportunityId,
                subject: emailData.subject,
                from_email: fromEmail,
              },
            });
            console.log("[ingest-email] System notification created for email ingestion");
          } catch (notifErr) {
            console.error("[ingest-email] Failed to create notification:", notifErr);
          }

          // Trigger enrichment/analysis by calling the enrich-transcript function
          try {
            const enrichRes = await fetch(`${supabaseUrl}/functions/v1/enrich-transcript`, {
              method: "POST",
              headers: {
                "Authorization": `Bearer ${supabaseKey}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ transcriptReviewId: review.id }),
            });
            console.log("[ingest-email] Enrichment triggered, status:", enrichRes.status);
          } catch (enrichErr) {
            console.error("[ingest-email] Failed to trigger enrichment:", enrichErr);
          }
        }
      } catch (reviewErr) {
        console.error("[ingest-email] Failed to create transcript review:", reviewErr);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        emailId: emailRecord.id,
        matchStatus,
        matchedAccountId,
        matchedOpportunityId,
        matchConfidence,
        matchMethod,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("[ingest-email] Error:", error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

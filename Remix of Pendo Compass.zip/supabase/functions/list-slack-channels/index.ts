import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

const GATEWAY_URL = 'https://connector-gateway.lovable.dev/slack/api';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: 'LOVABLE_API_KEY is not configured' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const SLACK_API_KEY = Deno.env.get('SLACK_API_KEY');
    if (!SLACK_API_KEY) {
      return new Response(JSON.stringify({ error: 'SLACK_API_KEY is not configured — Slack connector not linked' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Optional auth check — don't block if token is missing/invalid
    // The function is already gated by LOVABLE_API_KEY + SLACK_API_KEY
    const authHeader = req.headers.get('Authorization');
    if (authHeader?.startsWith('Bearer ')) {
      const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
      const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
      const supabase = createClient(supabaseUrl, anonKey, {
        global: { headers: { Authorization: authHeader } },
      });
      const token = authHeader.replace('Bearer ', '');
      const { data, error } = await supabase.auth.getClaims(token);
      // Log but don't block — allow the request to proceed
      if (error) {
        console.warn('Auth warning (non-blocking):', error.message);
      }
    }

    const url = new URL(req.url);
    const search = url.searchParams.get('search') || '';

    // Fetch channels from Slack (public channels)
    const allChannels: any[] = [];
    let cursor: string | undefined;

    // Paginate to get all channels (up to 500 for safety)
    for (let page = 0; page < 5; page++) {
      const params = new URLSearchParams({
        types: 'public_channel',
        limit: '100',
        exclude_archived: 'true',
      });
      if (cursor) params.set('cursor', cursor);

      const resp = await fetch(`${GATEWAY_URL}/conversations.list?${params}`, {
        headers: {
          'Authorization': `Bearer ${LOVABLE_API_KEY}`,
          'X-Connection-Api-Key': SLACK_API_KEY,
          'Content-Type': 'application/json',
        },
      });

      const data = await resp.json();
      if (!data.ok) {
        throw new Error(`Slack API error [conversations.list]: ${data.error}`);
      }

      allChannels.push(...(data.channels || []));

      cursor = data.response_metadata?.next_cursor;
      if (!cursor) break;
    }

    // Filter and map
    let channels = allChannels.map((ch: any) => ({
      id: ch.id,
      name: ch.name,
      topic: ch.topic?.value || '',
      purpose: ch.purpose?.value || '',
      num_members: ch.num_members || 0,
      is_member: !!ch.is_member,
    }));

    if (search) {
      const q = search.toLowerCase();
      channels = channels.filter(ch =>
        ch.name.toLowerCase().includes(q) ||
        ch.topic.toLowerCase().includes(q) ||
        ch.purpose.toLowerCase().includes(q)
      );
    }

    // Sort by member count descending (most active first)
    channels.sort((a, b) => b.num_members - a.num_members);

    return new Response(JSON.stringify({ channels }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: any) {
    console.error('list-slack-channels error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

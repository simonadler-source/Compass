import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-mcp-api-key, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

// ==================== ENCRYPTION HELPERS ====================
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    return bytes;
  }
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < Math.min(raw.length, 32); i++) key[i] = raw[i];
  return key;
}

function deriveKeyBytesLegacy(keyInput: string): Uint8Array {
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < Math.min(raw.length, 32); i++) key[i] = raw[i];
  return key;
}

async function deriveKeyBytesHashed(keyInput: string): Promise<Uint8Array> {
  const raw = new TextEncoder().encode(keyInput);
  const digest = await crypto.subtle.digest('SHA-256', raw);
  return new Uint8Array(digest);
}

function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

async function decryptField(ciphertext: string, ivBase64: string, keyInput: string): Promise<string | null> {
  try {
    const iv = base64ToBytes(ivBase64);
    const cipherBytes = base64ToBytes(ciphertext);

    const tryWith = async (kb: Uint8Array) => {
      const key = await crypto.subtle.importKey("raw", kb.buffer as ArrayBuffer, "AES-GCM", false, ["decrypt"]);
      const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: iv.buffer as ArrayBuffer }, key, cipherBytes.buffer as ArrayBuffer);
      return new TextDecoder().decode(plain);
    };

    try { return await tryWith(deriveKeyBytes(keyInput)); } catch {}
    try { return await tryWith(deriveKeyBytesLegacy(keyInput)); } catch {}
    try { return await tryWith(await deriveKeyBytesHashed(keyInput)); } catch {}

    const alt = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE");
    if (alt) {
      try { return await tryWith(deriveKeyBytes(alt)); } catch {}
      try { return await tryWith(deriveKeyBytesLegacy(alt)); } catch {}
    }
    return null;
  } catch { return null; }
}

// Encrypted field mappings (subset of api-gateway)
const ENCRYPTED_FIELDS: Record<string, { fields: string[]; ivField: string }> = {
  'account_contacts': { fields: ['name', 'email', 'phone', 'role', 'notes'], ivField: 'encryption_iv' },
  'account_nbas': { fields: ['action', 'notes'], ivField: 'encryption_iv' },
  'account_pain_points': { fields: ['pain_point', 'business_impact'], ivField: 'encryption_iv' },
  'account_use_cases': { fields: ['use_case', 'description'], ivField: 'encryption_iv' },
  'account_metrics': { fields: ['metric_value', 'context', 'mentioned_by_name', 'mentioned_by_email'], ivField: 'encryption_iv' },
  'account_strategic_themes': { fields: ['theme_name', 'description', 'supporting_evidence'], ivField: 'encryption_iv' },
  'account_technologies': { fields: ['owner_name', 'owner_email', 'notes', 'context'], ivField: 'encryption_iv' },
  'account_documents': { fields: ['content', 'name', 'description', 'owner_email'], ivField: 'encryption_iv' },
  'account_exec_summaries': { fields: ['summary_narrative', 'key_risks', 'key_opportunities', 'health_indicators', 'engagement_summary'], ivField: 'encryption_iv' },
  'opportunity_readiness_answers': { fields: ['answer', 'notes'], ivField: 'encryption_iv' },
  'transcript_reviews': { fields: ['transcript_content'], ivField: 'encryption_iv' },
  'customer_stories': { fields: ['situation', 'behavior', 'impact', 'impact_metrics'], ivField: 'encryption_iv' },
};

async function decryptRecords(table: string, records: any[], encKey: string): Promise<any[]> {
  const config = ENCRYPTED_FIELDS[table];
  if (!config) return records;

  return Promise.all(records.map(async (record: any) => {
    if (!record.is_encrypted) return record;
    const iv = record[config.ivField];
    if (!iv) return record;

    const result = { ...record };
    for (const field of config.fields) {
      const encField = `${field}_encrypted`;
      if (result[encField]) {
        const decrypted = await decryptField(result[encField], iv, encKey);
        if (decrypted !== null) {
          // Try JSON parse for object fields
          try {
            result[field] = JSON.parse(decrypted);
          } catch {
            result[field] = decrypted;
          }
        }
      }
    }
    return result;
  }));
}

// ==================== API KEY VALIDATION ====================
async function validateApiKey(supabase: any, apiKey: string): Promise<{ valid: boolean; keyId?: string; keyName?: string; permissions?: any; allowedTools?: string[] | null }> {
  // Hash the key with SHA-256
  const encoder = new TextEncoder();
  const data = encoder.encode(apiKey);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const keyHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

  const { data: keyData, error } = await supabase
    .from('mcp_api_keys')
    .select('id, name, permissions, allowed_tools, is_active, expires_at')
    .eq('key_hash', keyHash)
    .eq('is_active', true)
    .limit(1)
    .single();

  if (error || !keyData) return { valid: false };

  // Check expiry
  if (keyData.expires_at && new Date(keyData.expires_at) < new Date()) {
    return { valid: false };
  }

  // Update last_used_at and request_count
  await supabase
    .from('mcp_api_keys')
    .update({ last_used_at: new Date().toISOString(), request_count: keyData.request_count + 1 })
    .eq('id', keyData.id);

  return {
    valid: true,
    keyId: keyData.id,
    keyName: keyData.name,
    permissions: keyData.permissions,
    allowedTools: keyData.allowed_tools,
  };
}

async function logAccess(supabase: any, keyId: string, keyName: string, toolName: string, params: any, status: string, error?: string, execMs?: number) {
  try {
    await supabase.from('mcp_access_logs').insert({
      api_key_id: keyId,
      api_key_name: keyName,
      tool_name: toolName,
      request_params: params ? JSON.stringify(params).substring(0, 5000) : null,
      response_status: status,
      error_message: error || null,
      execution_time_ms: execMs || null,
    });
  } catch (e) {
    console.error('[MCP] Failed to log access:', e);
  }
}

// ==================== MCP TOOL DEFINITIONS ====================
interface ToolDef {
  name: string;
  description: string;
  inputSchema: any;
  handler: (params: any, supabase: any, encKey: string) => Promise<any>;
  requiresWrite?: boolean;
  requiresCoaching?: boolean;
}

const tools: ToolDef[] = [
  // ==================== ACCOUNTS ====================
  {
    name: 'list_accounts',
    description: 'List all accounts with optional filters. Returns account name, industry, status, ARR, engagement score, and more.',
    inputSchema: {
      type: 'object',
      properties: {
        status: { type: 'string', description: 'Filter by status (e.g. active, prospect, churned)' },
        industry: { type: 'string', description: 'Filter by industry' },
        search: { type: 'string', description: 'Search by account name (case-insensitive)' },
        limit: { type: 'number', description: 'Max results (default 50)' },
        offset: { type: 'number', description: 'Offset for pagination' },
      },
    },
    handler: async (params, supabase) => {
      let query = supabase.from('accounts').select('*');
      if (params.status) query = query.eq('status', params.status);
      if (params.industry) query = query.eq('industry', params.industry);
      if (params.search) query = query.ilike('name', `%${params.search}%`);
      query = query.order('name').limit(params.limit || 50);
      if (params.offset) query = query.range(params.offset, params.offset + (params.limit || 50) - 1);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },
  {
    name: 'get_account',
    description: 'Get detailed information about a specific account by ID.',
    inputSchema: {
      type: 'object',
      properties: { account_id: { type: 'string', description: 'Account UUID' } },
      required: ['account_id'],
    },
    handler: async (params, supabase) => {
      const { data, error } = await supabase.from('accounts').select('*').eq('id', params.account_id).single();
      if (error) throw new Error(error.message);
      return data;
    },
  },
  {
    name: 'create_account',
    description: 'Create a new account.',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string' },
        industry: { type: 'string' },
        status: { type: 'string' },
        arr: { type: 'number' },
        employee_count: { type: 'number' },
      },
      required: ['name'],
    },
    requiresWrite: true,
    handler: async (params, supabase) => {
      const { data, error } = await supabase.from('accounts').insert(params).select().single();
      if (error) throw new Error(error.message);
      return data;
    },
  },
  {
    name: 'update_account',
    description: 'Update an existing account.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        name: { type: 'string' },
        industry: { type: 'string' },
        status: { type: 'string' },
        arr: { type: 'number' },
        employee_count: { type: 'number' },
        stage: { type: 'string' },
      },
      required: ['account_id'],
    },
    requiresWrite: true,
    handler: async (params, supabase) => {
      const { account_id, ...updates } = params;
      const { data, error } = await supabase.from('accounts').update(updates).eq('id', account_id).select().single();
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== OPPORTUNITIES ====================
  {
    name: 'list_opportunities',
    description: 'List opportunities, optionally filtered by account.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        is_archived: { type: 'boolean', description: 'Filter by archived status (default false)' },
        limit: { type: 'number' },
        offset: { type: 'number' },
      },
    },
    handler: async (params, supabase) => {
      let query = supabase.from('opportunities').select('*');
      if (params.account_id) query = query.eq('account_id', params.account_id);
      if (params.is_archived !== undefined) query = query.eq('is_archived', params.is_archived);
      else query = query.eq('is_archived', false);
      query = query.order('created_at', { ascending: false }).limit(params.limit || 50);
      if (params.offset) query = query.range(params.offset, params.offset + (params.limit || 50) - 1);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },
  {
    name: 'get_opportunity',
    description: 'Get detailed information about a specific opportunity.',
    inputSchema: {
      type: 'object',
      properties: { opportunity_id: { type: 'string' } },
      required: ['opportunity_id'],
    },
    handler: async (params, supabase) => {
      const { data, error } = await supabase.from('opportunities').select('*').eq('id', params.opportunity_id).single();
      if (error) throw new Error(error.message);
      return data;
    },
  },
  {
    name: 'update_opportunity',
    description: 'Update an opportunity (stage, status, scores, etc.).',
    inputSchema: {
      type: 'object',
      properties: {
        opportunity_id: { type: 'string' },
        sales_stage: { type: 'string' },
        pre_sales_stage: { type: 'string' },
        relationship_status: { type: 'string' },
        name: { type: 'string' },
      },
      required: ['opportunity_id'],
    },
    requiresWrite: true,
    handler: async (params, supabase) => {
      const { opportunity_id, ...updates } = params;
      const { data, error } = await supabase.from('opportunities').update(updates).eq('id', opportunity_id).select().single();
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== CONTACTS / STAKEHOLDERS ====================
  {
    name: 'list_contacts',
    description: 'List contacts/stakeholders for an account or opportunity. Returns decrypted PII (name, email, role).',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        include_ignored: { type: 'boolean', description: 'Include ignored contacts (default false)' },
        limit: { type: 'number' },
      },
    },
    handler: async (params, supabase, encKey) => {
      let query = supabase.from('account_contacts').select('*');
      if (params.account_id) query = query.eq('account_id', params.account_id);
      if (params.opportunity_id) query = query.eq('opportunity_id', params.opportunity_id);
      if (!params.include_ignored) query = query.or('is_ignored.is.null,is_ignored.eq.false');
      query = query.order('champion_score', { ascending: false, nullsFirst: false }).limit(params.limit || 100);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return await decryptRecords('account_contacts', data || [], encKey);
    },
  },

  // ==================== USE CASES ====================
  {
    name: 'list_use_cases',
    description: 'List use cases for an account or opportunity.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        limit: { type: 'number' },
      },
    },
    handler: async (params, supabase, encKey) => {
      let query = supabase.from('account_use_cases').select('*');
      if (params.account_id) query = query.eq('account_id', params.account_id);
      if (params.opportunity_id) query = query.eq('opportunity_id', params.opportunity_id);
      query = query.order('created_at', { ascending: false }).limit(params.limit || 100);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return await decryptRecords('account_use_cases', data || [], encKey);
    },
  },

  // ==================== PAIN POINTS ====================
  {
    name: 'list_pain_points',
    description: 'List pain points for an account or opportunity.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        limit: { type: 'number' },
      },
    },
    handler: async (params, supabase, encKey) => {
      let query = supabase.from('account_pain_points').select('*');
      if (params.account_id) query = query.eq('account_id', params.account_id);
      if (params.opportunity_id) query = query.eq('opportunity_id', params.opportunity_id);
      query = query.order('created_at', { ascending: false }).limit(params.limit || 100);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return await decryptRecords('account_pain_points', data || [], encKey);
    },
  },

  // ==================== NBAs ====================
  {
    name: 'list_nbas',
    description: 'List Next Best Actions for an account or opportunity.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        status: { type: 'string', description: 'Filter by status (pending, in_progress, completed, dismissed)' },
        limit: { type: 'number' },
      },
    },
    handler: async (params, supabase, encKey) => {
      let query = supabase.from('account_nbas').select('*');
      if (params.account_id) query = query.eq('account_id', params.account_id);
      if (params.opportunity_id) query = query.eq('opportunity_id', params.opportunity_id);
      if (params.status) query = query.eq('status', params.status);
      query = query.order('created_at', { ascending: false }).limit(params.limit || 100);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return await decryptRecords('account_nbas', data || [], encKey);
    },
  },
  {
    name: 'create_nba',
    description: 'Create a new Next Best Action.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        action: { type: 'string', description: 'The action description' },
        action_type: { type: 'string' },
        priority: { type: 'string', enum: ['high', 'medium', 'low'] },
        due_date: { type: 'string', description: 'ISO date string' },
        assigned_to: { type: 'string', description: 'Email of assignee' },
      },
      required: ['account_id', 'action'],
    },
    requiresWrite: true,
    handler: async (params, supabase) => {
      const { data, error } = await supabase.from('account_nbas').insert({
        ...params,
        status: 'pending',
        action_type: params.action_type || 'follow_up_meeting',
      }).select().single();
      if (error) throw new Error(error.message);
      return data;
    },
  },
  {
    name: 'update_nba_status',
    description: 'Update the status of an NBA (pending, in_progress, completed, dismissed).',
    inputSchema: {
      type: 'object',
      properties: {
        nba_id: { type: 'string' },
        status: { type: 'string', enum: ['pending', 'in_progress', 'completed', 'dismissed'] },
        notes: { type: 'string' },
      },
      required: ['nba_id', 'status'],
    },
    requiresWrite: true,
    handler: async (params, supabase) => {
      const updates: any = { status: params.status };
      if (params.notes) updates.notes = params.notes;
      const { data, error } = await supabase.from('account_nbas').update(updates).eq('id', params.nba_id).select().single();
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== TECHNOLOGIES ====================
  {
    name: 'list_technologies',
    description: 'List technologies in an account\'s architecture.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        layer: { type: 'string' },
        limit: { type: 'number' },
      },
      required: ['account_id'],
    },
    handler: async (params, supabase, encKey) => {
      let query = supabase.from('account_technologies').select('*').eq('account_id', params.account_id);
      if (params.layer) query = query.eq('layer', params.layer);
      query = query.order('name').limit(params.limit || 200);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return await decryptRecords('account_technologies', data || [], encKey);
    },
  },

  // ==================== COMPETITIVE INTELLIGENCE ====================
  {
    name: 'list_competitive_insights',
    description: 'List competitive insights for an opportunity (competitor mentions, objections, win/loss signals).',
    inputSchema: {
      type: 'object',
      properties: {
        opportunity_id: { type: 'string' },
        competitor_name: { type: 'string' },
        limit: { type: 'number' },
      },
      required: ['opportunity_id'],
    },
    handler: async (params, supabase) => {
      let query = supabase.from('opportunity_competitive_insights').select('*').eq('opportunity_id', params.opportunity_id);
      if (params.competitor_name) query = query.eq('competitor_name', params.competitor_name);
      query = query.order('created_at', { ascending: false }).limit(params.limit || 50);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },
  {
    name: 'list_competitive_plays',
    description: 'List competitive plays (attack/defend strategies) for an opportunity.',
    inputSchema: {
      type: 'object',
      properties: {
        opportunity_id: { type: 'string' },
        competitor_name: { type: 'string' },
        play_type: { type: 'string', description: 'Filter by play type (landmine, differentiation, objection_handler, case_study)' },
        limit: { type: 'number' },
      },
      required: ['opportunity_id'],
    },
    handler: async (params, supabase) => {
      let query = supabase.from('competitive_plays').select('*').eq('opportunity_id', params.opportunity_id);
      if (params.competitor_name) query = query.eq('competitor_name', params.competitor_name);
      if (params.play_type) query = query.eq('play_type', params.play_type);
      query = query.order('relevance_score', { ascending: false }).limit(params.limit || 50);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },
  {
    name: 'get_competitive_scorecard',
    description: 'Get the competitive maturity scorecard for one or more vendors.',
    inputSchema: {
      type: 'object',
      properties: {
        vendor_names: { type: 'array', items: { type: 'string' }, description: 'Vendor names to compare' },
        category: { type: 'string', description: 'Filter by category' },
      },
    },
    handler: async (params, supabase) => {
      let query = supabase.from('competitive_scorecard').select('*');
      if (params.vendor_names?.length) query = query.in('vendor_name', params.vendor_names);
      if (params.category) query = query.eq('category', params.category);
      query = query.order('category').order('subcategory').limit(5000);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== METRICS ====================
  {
    name: 'list_metrics',
    description: 'List operational metrics extracted from account conversations.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        metric_category: { type: 'string' },
        limit: { type: 'number' },
      },
    },
    handler: async (params, supabase, encKey) => {
      let query = supabase.from('account_metrics').select('*');
      if (params.account_id) query = query.eq('account_id', params.account_id);
      if (params.opportunity_id) query = query.eq('opportunity_id', params.opportunity_id);
      if (params.metric_category) query = query.eq('metric_category', params.metric_category);
      query = query.order('created_at', { ascending: false }).limit(params.limit || 100);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return await decryptRecords('account_metrics', data || [], encKey);
    },
  },

  // ==================== STRATEGIC THEMES ====================
  {
    name: 'list_strategic_themes',
    description: 'List strategic themes synthesized for an account.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        theme_type: { type: 'string', description: 'pain, use_case, or priority' },
      },
      required: ['account_id'],
    },
    handler: async (params, supabase, encKey) => {
      let query = supabase.from('account_strategic_themes').select('*').eq('account_id', params.account_id);
      if (params.theme_type) query = query.eq('theme_type', params.theme_type);
      query = query.order('impact_level').limit(50);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return await decryptRecords('account_strategic_themes', data || [], encKey);
    },
  },

  // ==================== TRANSCRIPTS ====================
  {
    name: 'list_transcripts',
    description: 'List transcript reviews (meeting analyses) for an account or opportunity.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        status: { type: 'string', description: 'Filter by status (pending, approved, rejected)' },
        limit: { type: 'number' },
      },
    },
    handler: async (params, supabase) => {
      let query = supabase.from('transcript_reviews').select('id, file_name, meeting_title, status, sales_stage, pre_sales_stage, content_type, extracted_insights, created_at, opportunity_id, final_account_id');
      if (params.account_id) query = query.eq('final_account_id', params.account_id);
      if (params.opportunity_id) query = query.eq('opportunity_id', params.opportunity_id);
      if (params.status) query = query.eq('status', params.status);
      query = query.order('created_at', { ascending: false }).limit(params.limit || 50);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== READINESS ====================
  {
    name: 'get_readiness_answers',
    description: 'Get technical readiness answers for an opportunity.',
    inputSchema: {
      type: 'object',
      properties: { opportunity_id: { type: 'string' } },
      required: ['opportunity_id'],
    },
    handler: async (params, supabase, encKey) => {
      const { data, error } = await supabase
        .from('opportunity_readiness_answers')
        .select('*, readiness_template_questions(question, category_id, readiness_template_categories(name))')
        .eq('opportunity_id', params.opportunity_id);
      if (error) throw new Error(error.message);
      return await decryptRecords('opportunity_readiness_answers', data || [], encKey);
    },
  },

  // ==================== MILESTONES ====================
  {
    name: 'list_milestones',
    description: 'List milestones for an opportunity.',
    inputSchema: {
      type: 'object',
      properties: {
        opportunity_id: { type: 'string' },
        status: { type: 'string' },
      },
      required: ['opportunity_id'],
    },
    handler: async (params, supabase) => {
      let query = supabase.from('opportunity_milestones').select('*').eq('opportunity_id', params.opportunity_id);
      if (params.status) query = query.eq('status', params.status);
      query = query.order('target_date');
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== ACTIVITY SIGNALS ====================
  {
    name: 'list_activity_signals',
    description: 'List detection rule matches (activity signals) for an opportunity.',
    inputSchema: {
      type: 'object',
      properties: {
        opportunity_id: { type: 'string' },
        limit: { type: 'number' },
      },
      required: ['opportunity_id'],
    },
    handler: async (params, supabase) => {
      const { data, error } = await supabase
        .from('detection_rule_matches')
        .select('*, detection_rules(name, rule_type)')
        .eq('opportunity_id', params.opportunity_id)
        .order('matched_at', { ascending: false })
        .limit(params.limit || 100);
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== EXEC SUMMARY ====================
  {
    name: 'get_account_summary',
    description: 'Get the AI-generated executive summary for an account.',
    inputSchema: {
      type: 'object',
      properties: { account_id: { type: 'string' } },
      required: ['account_id'],
    },
    handler: async (params, supabase, encKey) => {
      const { data, error } = await supabase
        .from('account_exec_summaries')
        .select('*')
        .eq('account_id', params.account_id)
        .maybeSingle();
      if (error) throw new Error(error.message);
      if (!data) return null;
      const [decrypted] = await decryptRecords('account_exec_summaries', [data], encKey);
      return decrypted;
    },
  },

  // ==================== PRODUCT MENTIONS ====================
  {
    name: 'list_product_mentions',
    description: 'List product/competitor mentions across transcripts.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        product_name: { type: 'string' },
        limit: { type: 'number' },
      },
    },
    handler: async (params, supabase) => {
      let query = supabase.from('product_mentions').select('*');
      if (params.account_id) query = query.eq('account_id', params.account_id);
      if (params.opportunity_id) query = query.eq('opportunity_id', params.opportunity_id);
      if (params.product_name) query = query.ilike('product_name', `%${params.product_name}%`);
      query = query.order('transcript_date', { ascending: false }).limit(params.limit || 100);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== VALIDATION TASKS ====================
  {
    name: 'list_validation_tasks',
    description: 'List validation tasks for an opportunity.',
    inputSchema: {
      type: 'object',
      properties: {
        opportunity_id: { type: 'string' },
        status: { type: 'string', description: 'Filter by status (pending, in_progress, completed, blocked)' },
        limit: { type: 'number' },
      },
      required: ['opportunity_id'],
    },
    handler: async (params, supabase) => {
      let query = supabase.from('opportunity_validation_tasks').select('*').eq('opportunity_id', params.opportunity_id);
      if (params.status) query = query.eq('status', params.status);
      query = query.order('sort_order').limit(params.limit || 100);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== DOCUMENTS ====================
  {
    name: 'list_documents',
    description: 'List documents for an account or opportunity.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        type: { type: 'string', description: 'Filter by document type' },
        limit: { type: 'number' },
      },
    },
    handler: async (params, supabase, encKey) => {
      let query = supabase.from('account_documents').select('*');
      if (params.account_id) query = query.eq('account_id', params.account_id);
      if (params.opportunity_id) query = query.eq('opportunity_id', params.opportunity_id);
      if (params.type) query = query.eq('type', params.type);
      query = query.order('created_at', { ascending: false }).limit(params.limit || 50);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return await decryptRecords('account_documents', data || [], encKey);
    },
  },

  // ==================== SE UPDATES ====================
  {
    name: 'get_se_updates',
    description: 'Get the latest SE weekly updates and risk assessments for an opportunity.',
    inputSchema: {
      type: 'object',
      properties: { opportunity_id: { type: 'string' } },
      required: ['opportunity_id'],
    },
    handler: async (params, supabase) => {
      const { data, error } = await supabase
        .from('opportunity_se_updates')
        .select('*')
        .eq('opportunity_id', params.opportunity_id)
        .order('created_at', { ascending: false })
        .limit(10);
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== CUSTOMER STORIES ====================
  {
    name: 'list_customer_stories',
    description: 'List customer stories (situation-behavior-impact narratives).',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        limit: { type: 'number' },
      },
    },
    handler: async (params, supabase, encKey) => {
      let query = supabase.from('customer_stories').select('*');
      if (params.account_id) query = query.eq('account_id', params.account_id);
      if (params.opportunity_id) query = query.eq('opportunity_id', params.opportunity_id);
      query = query.order('created_at', { ascending: false }).limit(params.limit || 20);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return await decryptRecords('customer_stories', data || [], encKey);
    },
  },

  // ==================== STAGE HISTORY ====================
  {
    name: 'list_stage_history',
    description: 'List stage change history for an opportunity (sales_stage and pre_sales_stage transitions).',
    inputSchema: {
      type: 'object',
      properties: {
        opportunity_id: { type: 'string' },
        stage_type: { type: 'string', description: 'Filter by stage_type (sales_stage or pre_sales_stage)' },
        limit: { type: 'number' },
      },
      required: ['opportunity_id'],
    },
    handler: async (params, supabase) => {
      let query = supabase.from('opportunity_stage_history').select('*').eq('opportunity_id', params.opportunity_id);
      if (params.stage_type) query = query.eq('stage_type', params.stage_type);
      query = query.order('changed_at', { ascending: false }).limit(params.limit || 50);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== SE COACHING (SENSITIVE - requires coaching permission) ====================
  {
    name: 'list_coaching_scores',
    description: 'List SE coaching scores across transcripts. SENSITIVE: requires coaching permission on API key.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        opportunity_id: { type: 'string' },
        se_email: { type: 'string', description: 'Filter by SE email' },
        limit: { type: 'number' },
      },
    },
    requiresCoaching: true,
    handler: async (params, supabase) => {
      let query = supabase.from('se_coaching_scores').select('*');
      if (params.account_id) query = query.eq('account_id', params.account_id);
      if (params.opportunity_id) query = query.eq('opportunity_id', params.opportunity_id);
      if (params.se_email) query = query.eq('se_email', params.se_email);
      query = query.order('analyzed_at', { ascending: false }).limit(params.limit || 50);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data;
    },
  },
  {
    name: 'get_coaching_score',
    description: 'Get detailed coaching score for a specific transcript. SENSITIVE: requires coaching permission on API key.',
    inputSchema: {
      type: 'object',
      properties: { transcript_id: { type: 'string' } },
      required: ['transcript_id'],
    },
    requiresCoaching: true,
    handler: async (params, supabase) => {
      const { data, error } = await supabase
        .from('se_coaching_scores')
        .select('*')
        .eq('transcript_id', params.transcript_id)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data;
    },
  },

  // ==================== TRIGGER ANALYSIS ====================
  {
    name: 'trigger_reanalysis',
    description: 'Queue a transcript for re-analysis / enrichment.',
    inputSchema: {
      type: 'object',
      properties: { transcript_id: { type: 'string' } },
      required: ['transcript_id'],
    },
    requiresWrite: true,
    handler: async (params, supabase) => {
      // Reset the enrichment hash to trigger re-processing
      const { error } = await supabase
        .from('transcript_reviews')
        .update({ last_enriched_hash: null })
        .eq('id', params.transcript_id);
      if (error) throw new Error(error.message);

      // Invoke enrichment
      const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
      const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
      const resp = await fetch(`${supabaseUrl}/functions/v1/enrich-transcript`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${serviceKey}` },
        body: JSON.stringify({ transcriptReviewId: params.transcript_id }),
      });

      return { queued: true, status: resp.status };
    },
  },
];

// Build tool map for quick lookup
const toolMap = new Map(tools.map(t => [t.name, t]));

// ==================== MAIN HANDLER ====================
serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY') || '';

  const supabase = createClient(supabaseUrl, serviceRoleKey);

  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/mcp-server\/?/, '/');

  // ==================== MCP PROTOCOL ENDPOINTS ====================

  // SSE endpoint for MCP Streamable HTTP transport
  if (req.method === 'POST' && (path === '/' || path === '/mcp' || path === '')) {
    // Validate API key
    const apiKey = req.headers.get('x-mcp-api-key') || req.headers.get('authorization')?.replace('Bearer ', '');
    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'Missing API key. Provide x-mcp-api-key header or Bearer token.' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const auth = await validateApiKey(supabase, apiKey);
    if (!auth.valid) {
      return new Response(JSON.stringify({ error: 'Invalid or expired API key.' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Parse JSON-RPC request
    let body: any;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ jsonrpc: '2.0', error: { code: -32700, message: 'Parse error' }, id: null }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { method, params, id } = body;

    // Handle JSON-RPC methods
    if (method === 'initialize') {
      return new Response(JSON.stringify({
        jsonrpc: '2.0',
        result: {
          protocolVersion: '2024-11-05',
          capabilities: { tools: { listChanged: false } },
          serverInfo: { name: 'searchitecture-mcp', version: '1.0.0' },
        },
        id,
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    if (method === 'notifications/initialized') {
      return new Response(JSON.stringify({ jsonrpc: '2.0', result: {}, id }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (method === 'tools/list') {
      const availableTools = tools
        .filter(t => !auth.allowedTools || auth.allowedTools.includes(t.name))
        .filter(t => !t.requiresCoaching || auth.permissions?.coaching)
        .map(t => ({
          name: t.name,
          description: t.description,
          inputSchema: t.inputSchema,
        }));

      return new Response(JSON.stringify({
        jsonrpc: '2.0',
        result: { tools: availableTools },
        id,
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    if (method === 'tools/call') {
      const toolName = params?.name;
      const toolArgs = params?.arguments || {};
      const tool = toolMap.get(toolName);

      if (!tool) {
        await logAccess(supabase, auth.keyId!, auth.keyName!, toolName || 'unknown', toolArgs, 'error', 'Tool not found');
        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          error: { code: -32601, message: `Tool '${toolName}' not found` },
          id,
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      // Check tool-level permissions
      if (auth.allowedTools && !auth.allowedTools.includes(toolName)) {
        await logAccess(supabase, auth.keyId!, auth.keyName!, toolName, toolArgs, 'denied', 'Tool not allowed for this key');
        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          error: { code: -32600, message: `Tool '${toolName}' is not allowed for this API key` },
          id,
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      // Check write permissions
      if (tool.requiresWrite && !auth.permissions?.write) {
        await logAccess(supabase, auth.keyId!, auth.keyName!, toolName, toolArgs, 'denied', 'Write permission required');
        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          error: { code: -32600, message: 'This API key does not have write permissions' },
          id,
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      // Check coaching permissions
      if (tool.requiresCoaching && !auth.permissions?.coaching) {
        await logAccess(supabase, auth.keyId!, auth.keyName!, toolName, toolArgs, 'denied', 'Coaching permission required');
        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          error: { code: -32600, message: 'This API key does not have coaching data access. Enable the coaching permission on this key to access SE coaching scores.' },
          id,
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }


      try {
        const result = await tool.handler(toolArgs, supabase, encryptionKey);
        const execMs = Date.now() - startTime;
        await logAccess(supabase, auth.keyId!, auth.keyName!, toolName, toolArgs, 'success', undefined, execMs);

        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          result: {
            content: [{ type: 'text', text: JSON.stringify(result, null, 2) }],
          },
          id,
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      } catch (err: any) {
        const execMs = Date.now() - startTime;
        await logAccess(supabase, auth.keyId!, auth.keyName!, toolName, toolArgs, 'error', err.message, execMs);

        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          error: { code: -32603, message: err.message || 'Internal error' },
          id,
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }
    }

    // Unknown method
    return new Response(JSON.stringify({
      jsonrpc: '2.0',
      error: { code: -32601, message: `Method '${method}' not found` },
      id,
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }

  // Health check
  if (req.method === 'GET') {
    return new Response(JSON.stringify({
      status: 'ok',
      server: 'searchitecture-mcp',
      version: '1.0.0',
      tools: tools.length,
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }

  return new Response(JSON.stringify({ error: 'Method not allowed' }), {
    status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
});

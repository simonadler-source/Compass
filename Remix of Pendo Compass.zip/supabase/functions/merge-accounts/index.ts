import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface MergeResult {
  table: string;
  updated: number;
  skipped: number;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    
    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error("Missing Supabase configuration");
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const body = await req.json();
    
    const { primaryAccountId, secondaryAccountId, dryRun = false } = body;
    
    if (!primaryAccountId || !secondaryAccountId) {
      return new Response(JSON.stringify({ 
        error: "Both primaryAccountId and secondaryAccountId are required" 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (primaryAccountId === secondaryAccountId) {
      return new Response(JSON.stringify({ 
        error: "Primary and secondary account IDs must be different" 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`[Merge] Starting merge: secondary ${secondaryAccountId} → primary ${primaryAccountId} (dryRun: ${dryRun})`);

    // Verify both accounts exist
    const { data: primaryAccount, error: primaryErr } = await supabase
      .from('accounts')
      .select('id, name, salesforce_account_id, arr, primary_se_email, owner_id, industry, employee_count, status, stage, created_at')
      .eq('id', primaryAccountId)
      .single();

    const { data: secondaryAccount, error: secondaryErr } = await supabase
      .from('accounts')
      .select('id, name, salesforce_account_id, arr, primary_se_email, owner_id, industry, employee_count, status, stage, created_at')
      .eq('id', secondaryAccountId)
      .single();

    if (primaryErr || !primaryAccount) {
      return new Response(JSON.stringify({ error: `Primary account not found: ${primaryAccountId}` }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (secondaryErr || !secondaryAccount) {
      return new Response(JSON.stringify({ error: `Secondary account not found: ${secondaryAccountId}` }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`[Merge] Primary: "${primaryAccount.name}" (created: ${primaryAccount.created_at})`);
    console.log(`[Merge] Secondary: "${secondaryAccount.name}" (created: ${secondaryAccount.created_at})`);

    const results: MergeResult[] = [];

    // Helper to migrate records from one account to another
    async function migrateRecords(table: string, accountColumn: string = 'account_id') {
      const { count } = await supabase
        .from(table)
        .select('*', { count: 'exact', head: true })
        .eq(accountColumn, secondaryAccountId);

      const recordCount = count || 0;
      
      if (recordCount > 0 && !dryRun) {
        const { error } = await supabase
          .from(table)
          .update({ [accountColumn]: primaryAccountId } as any)
          .eq(accountColumn, secondaryAccountId);
        
        if (error) {
          console.error(`[Merge] Error migrating ${table}: ${error.message}`);
          results.push({ table, updated: 0, skipped: recordCount });
        } else {
          console.log(`[Merge] Migrated ${recordCount} records from ${table}`);
          results.push({ table, updated: recordCount, skipped: 0 });
        }
      } else {
        results.push({ table, updated: dryRun ? 0 : 0, skipped: dryRun ? recordCount : 0 });
        if (recordCount > 0) {
          console.log(`[Merge] Would migrate ${recordCount} records from ${table}`);
        }
      }
    }

    // Migrate all related records
    // Order matters for foreign key constraints
    await migrateRecords('opportunities');
    await migrateRecords('account_contacts');
    await migrateRecords('account_nbas');
    await migrateRecords('account_pain_points');
    await migrateRecords('account_use_cases');
    await migrateRecords('account_metrics');
    await migrateRecords('account_technologies');
    await migrateRecords('account_team_members');
    await migrateRecords('account_documents');
    await migrateRecords('account_strategic_themes');
    await migrateRecords('account_exec_summaries');
    await migrateRecords('account_metric_history');
    await migrateRecords('account_insight_snapshots');
    await migrateRecords('account_captured_insights');
    
    // Migrate momentum meetings (uses matched_account_id column)
    await migrateRecords('momentum_meetings', 'matched_account_id');
    
    // Migrate transcript_reviews that reference final_account_id
    const { count: transcriptCount } = await supabase
      .from('transcript_reviews')
      .select('*', { count: 'exact', head: true })
      .eq('final_account_id', secondaryAccountId);

    if ((transcriptCount || 0) > 0 && !dryRun) {
      const { error } = await supabase
        .from('transcript_reviews')
        .update({ final_account_id: primaryAccountId } as any)
        .eq('final_account_id', secondaryAccountId);
      
      if (error) {
        console.error(`[Merge] Error migrating transcript_reviews: ${error.message}`);
        results.push({ table: 'transcript_reviews', updated: 0, skipped: transcriptCount || 0 });
      } else {
        console.log(`[Merge] Migrated ${transcriptCount} transcript_reviews`);
        results.push({ table: 'transcript_reviews', updated: transcriptCount || 0, skipped: 0 });
      }
    } else {
      results.push({ table: 'transcript_reviews', updated: 0, skipped: dryRun ? (transcriptCount || 0) : 0 });
    }

    // Merge account-level fields: keep non-null values from secondary if primary is null
    if (!dryRun) {
      const updates: Record<string, any> = {};
      
      // Merge ARR (keep higher value)
      if (secondaryAccount.arr && (!primaryAccount.arr || secondaryAccount.arr > primaryAccount.arr)) {
        updates.arr = secondaryAccount.arr;
      }
      
      // Merge fields if primary is null
      if (!primaryAccount.primary_se_email && secondaryAccount.primary_se_email) {
        updates.primary_se_email = secondaryAccount.primary_se_email;
      }
      if (!primaryAccount.owner_id && secondaryAccount.owner_id) {
        updates.owner_id = secondaryAccount.owner_id;
      }
      if (!primaryAccount.industry && secondaryAccount.industry) {
        updates.industry = secondaryAccount.industry;
      }
      if (!primaryAccount.employee_count && secondaryAccount.employee_count) {
        updates.employee_count = secondaryAccount.employee_count;
      }
      
      if (Object.keys(updates).length > 0) {
        await supabase
          .from('accounts')
          .update(updates as any)
          .eq('id', primaryAccountId);
        console.log(`[Merge] Updated primary account with merged fields:`, Object.keys(updates));
      }
    }

    // Delete the secondary account (only if not dry run)
    if (!dryRun) {
      const { error: deleteErr } = await supabase
        .from('accounts')
        .delete()
        .eq('id', secondaryAccountId);

      if (deleteErr) {
        console.error(`[Merge] Error deleting secondary account: ${deleteErr.message}`);
        return new Response(JSON.stringify({
          success: false,
          error: `Failed to delete secondary account: ${deleteErr.message}`,
          results,
        }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      console.log(`[Merge] Deleted secondary account ${secondaryAccountId}`);
    }

    const totalMigrated = results.reduce((sum, r) => sum + r.updated, 0);
    
    return new Response(JSON.stringify({
      success: true,
      dryRun,
      primaryAccount: { id: primaryAccountId, name: primaryAccount.name },
      secondaryAccount: { id: secondaryAccountId, name: secondaryAccount.name },
      totalMigrated,
      results,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[Merge] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

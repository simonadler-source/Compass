import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface MergeResult {
  table: string;
  updated: number;
  skipped: number;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    
    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error("Missing Supabase configuration");
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const body = await req.json();
    
    const { primaryOpportunityId, secondaryOpportunityId, dryRun = false } = body;
    
    if (!primaryOpportunityId || !secondaryOpportunityId) {
      return new Response(JSON.stringify({ 
        error: "Both primaryOpportunityId and secondaryOpportunityId are required" 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (primaryOpportunityId === secondaryOpportunityId) {
      return new Response(JSON.stringify({ 
        error: "Primary and secondary opportunity IDs must be different" 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`[Merge Opportunities] Starting merge: secondary ${secondaryOpportunityId} → primary ${primaryOpportunityId} (dryRun: ${dryRun})`);

    // Verify both opportunities exist and get their details
    const { data: primaryOpp, error: primaryErr } = await supabase
      .from('opportunities')
      .select('id, name, account_id, salesforce_opportunity_id, stage, sales_stage, pre_sales_stage, owner_id, primary_se_email, created_at')
      .eq('id', primaryOpportunityId)
      .single();

    const { data: secondaryOpp, error: secondaryErr } = await supabase
      .from('opportunities')
      .select('id, name, account_id, salesforce_opportunity_id, stage, sales_stage, pre_sales_stage, owner_id, primary_se_email, created_at')
      .eq('id', secondaryOpportunityId)
      .single();

    if (primaryErr || !primaryOpp) {
      return new Response(JSON.stringify({ error: `Primary opportunity not found: ${primaryOpportunityId}` }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (secondaryErr || !secondaryOpp) {
      return new Response(JSON.stringify({ error: `Secondary opportunity not found: ${secondaryOpportunityId}` }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Cross-account merges are allowed (for consolidating misassigned opportunities)
    // But we log when this happens
    if (primaryOpp.account_id !== secondaryOpp.account_id) {
      console.log(`[Merge Opportunities] CROSS-ACCOUNT MERGE: ${secondaryOpp.account_id} → ${primaryOpp.account_id}`);
    }

    console.log(`[Merge Opportunities] Primary: "${primaryOpp.name}" (created: ${primaryOpp.created_at})`);
    console.log(`[Merge Opportunities] Secondary: "${secondaryOpp.name}" (created: ${secondaryOpp.created_at})`);

    const results: MergeResult[] = [];

    // Helper to migrate records from one opportunity to another
    // For cross-account merges, also update account_id if the table has one
    const isCrossAccount = primaryOpp.account_id !== secondaryOpp.account_id;
    
    async function migrateRecords(table: string, opportunityColumn: string = 'opportunity_id', hasAccountId: boolean = false) {
      const { count } = await supabase
        .from(table)
        .select('*', { count: 'exact', head: true })
        .eq(opportunityColumn, secondaryOpportunityId);

      const recordCount = count || 0;
      
      if (recordCount > 0 && !dryRun) {
        const updateData: Record<string, any> = { [opportunityColumn]: primaryOpportunityId };
        
        // For cross-account merges, also update account_id
        if (isCrossAccount && hasAccountId && primaryOpp) {
          updateData.account_id = primaryOpp.account_id;
        }
        
        const { error } = await supabase
          .from(table)
          .update(updateData as any)
          .eq(opportunityColumn, secondaryOpportunityId);
        
        if (error) {
          console.error(`[Merge Opportunities] Error migrating ${table}: ${error.message}`);
          results.push({ table, updated: 0, skipped: recordCount });
        } else {
          console.log(`[Merge Opportunities] Migrated ${recordCount} records from ${table}`);
          results.push({ table, updated: recordCount, skipped: 0 });
        }
      } else {
        results.push({ table, updated: dryRun ? 0 : 0, skipped: dryRun ? recordCount : 0 });
        if (recordCount > 0) {
          console.log(`[Merge Opportunities] Would migrate ${recordCount} records from ${table}`);
        }
      }
    }

    // Migrate all related records
    // Tables with opportunity_id column - specify hasAccountId=true for tables that also have account_id
    await migrateRecords('account_contacts', 'opportunity_id', true);
    await migrateRecords('account_nbas', 'opportunity_id', true);
    await migrateRecords('account_pain_points', 'opportunity_id', true);
    await migrateRecords('account_use_cases', 'opportunity_id', true);
    await migrateRecords('account_metrics', 'opportunity_id', true);
    await migrateRecords('account_captured_insights', 'opportunity_id', true);
    await migrateRecords('account_insight_snapshots', 'opportunity_id', true);
    await migrateRecords('contact_meeting_snapshots', 'opportunity_id', false); // no account_id
    await migrateRecords('detection_rule_matches', 'opportunity_id', false);
    await migrateRecords('opportunity_activities', 'opportunity_id', false);
    await migrateRecords('opportunity_deployment_types', 'opportunity_id', false);
    await migrateRecords('opportunity_milestones', 'opportunity_id', false);
    await migrateRecords('opportunity_readiness_answers', 'opportunity_id', false);
    await migrateRecords('opportunity_team_members', 'opportunity_id', false);
    await migrateRecords('opportunity_validation_tasks', 'opportunity_id', false);
    await migrateRecords('product_mentions', 'opportunity_id', true);
    await migrateRecords('transcript_reviews', 'opportunity_id', false); // has final_account_id, handled separately
    await migrateRecords('transcript_reanalysis_queue', 'opportunity_id', true);
    await migrateRecords('transcript_full_reanalysis_queue', 'opportunity_id', true);
    
    // Update momentum_meetings that reference this opportunity
    const { count: meetingsCount } = await supabase
      .from('momentum_meetings')
      .select('*', { count: 'exact', head: true })
      .eq('matched_opportunity_id', secondaryOpportunityId);

    if ((meetingsCount || 0) > 0 && !dryRun) {
      const { error } = await supabase
        .from('momentum_meetings')
        .update({ matched_opportunity_id: primaryOpportunityId } as any)
        .eq('matched_opportunity_id', secondaryOpportunityId);
      
      if (error) {
        console.error(`[Merge Opportunities] Error migrating momentum_meetings: ${error.message}`);
        results.push({ table: 'momentum_meetings', updated: 0, skipped: meetingsCount || 0 });
      } else {
        console.log(`[Merge Opportunities] Migrated ${meetingsCount} momentum_meetings`);
        results.push({ table: 'momentum_meetings', updated: meetingsCount || 0, skipped: 0 });
      }
    } else {
      results.push({ table: 'momentum_meetings', updated: 0, skipped: dryRun ? (meetingsCount || 0) : 0 });
    }

    // Merge opportunity-level fields: keep non-null values from secondary if primary is null
    if (!dryRun) {
      const updates: Record<string, any> = {};
      
      // Merge owner if primary is null
      if (!primaryOpp.owner_id && secondaryOpp.owner_id) {
        updates.owner_id = secondaryOpp.owner_id;
      }
      if (!primaryOpp.primary_se_email && secondaryOpp.primary_se_email) {
        updates.primary_se_email = secondaryOpp.primary_se_email;
      }
      
      // Keep more advanced stage
      const stageOrder = ['identified', 'qualifying', 'discovery', 'proof', 'pending_compliance', 'negotiation', 'closed_won', 'closed_lost'];
      const primaryStageIdx = stageOrder.indexOf(primaryOpp.stage || '');
      const secondaryStageIdx = stageOrder.indexOf(secondaryOpp.stage || '');
      if (secondaryStageIdx > primaryStageIdx && secondaryOpp.stage) {
        updates.stage = secondaryOpp.stage;
      }
      
      if (Object.keys(updates).length > 0) {
        await supabase
          .from('opportunities')
          .update(updates as any)
          .eq('id', primaryOpportunityId);
        console.log(`[Merge Opportunities] Updated primary opportunity with merged fields:`, Object.keys(updates));
      }
    }

    // Delete the secondary opportunity (only if not dry run)
    if (!dryRun) {
      const { error: deleteErr } = await supabase
        .from('opportunities')
        .delete()
        .eq('id', secondaryOpportunityId);

      if (deleteErr) {
        console.error(`[Merge Opportunities] Error deleting secondary opportunity: ${deleteErr.message}`);
        return new Response(JSON.stringify({
          success: false,
          error: `Failed to delete secondary opportunity: ${deleteErr.message}`,
          results,
        }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      console.log(`[Merge Opportunities] Deleted secondary opportunity ${secondaryOpportunityId}`);
    }

    const totalMigrated = results.reduce((sum, r) => sum + r.updated, 0);
    
    return new Response(JSON.stringify({
      success: true,
      dryRun,
      primaryOpportunity: { id: primaryOpportunityId, name: primaryOpp.name },
      secondaryOpportunity: { id: secondaryOpportunityId, name: secondaryOpp.name },
      totalMigrated,
      results,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[Merge Opportunities] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

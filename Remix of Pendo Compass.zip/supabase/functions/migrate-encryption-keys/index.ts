import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ==================== KEY DERIVATION METHODS ====================
// Primary: hex-aware derivation
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < Math.min(raw.length, 32); i++) key[i] = raw[i];
  return key;
}

// Legacy: always raw text
function deriveKeyBytesLegacy(keyInput: string): Uint8Array {
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < Math.min(raw.length, 32); i++) key[i] = raw[i];
  return key;
}

// Hashed derivation
async function deriveKeyBytesHashed(keyInput: string): Promise<Uint8Array> {
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const digest = await crypto.subtle.digest('SHA-256', raw);
  return new Uint8Array(digest);
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

// ==================== ENCRYPTION/DECRYPTION ====================
async function tryDecrypt(
  ciphertext: string, 
  ivBase64: string, 
  keyInput: string
): Promise<{ success: boolean; plaintext: string | null; method: string }> {
  try {
    const iv = base64ToBytes(ivBase64);
    const cipherBytes = base64ToBytes(ciphertext);

    const tryWith = async (keyBytes: Uint8Array, method: string) => {
      const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["decrypt"]);
      const plainBytes = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: iv.buffer as ArrayBuffer },
        key,
        cipherBytes.buffer as ArrayBuffer
      );
      return { success: true, plaintext: new TextDecoder().decode(plainBytes), method };
    };

    // Try all derivation methods
    try {
      return await tryWith(deriveKeyBytes(keyInput), 'primary');
    } catch {
      try {
        return await tryWith(deriveKeyBytesLegacy(keyInput), 'legacy');
      } catch {
        try {
          return await tryWith(await deriveKeyBytesHashed(keyInput), 'hashed');
        } catch {
          return { success: false, plaintext: null, method: 'none' };
        }
      }
    }
  } catch {
    return { success: false, plaintext: null, method: 'parse_error' };
  }
}

async function encrypt(plaintext: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plainBytes = new TextEncoder().encode(plaintext);
  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv.buffer as ArrayBuffer }, key, plainBytes);
  return { ciphertext: bytesToBase64(new Uint8Array(cipherBytes)), iv: bytesToBase64(iv) };
}

async function encryptWithIv(plaintext: string, ivBytes: Uint8Array, keyInput: string): Promise<string> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt"]);
  const plainBytes = new TextEncoder().encode(plaintext);
  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv: ivBytes.buffer as ArrayBuffer }, key, plainBytes);
  return bytesToBase64(new Uint8Array(cipherBytes));
}

// ==================== TABLE CONFIGURATIONS ====================
const ENCRYPTED_TABLES: Record<string, { fields: string[]; ivField: string }> = {
  'account_contacts': { fields: ['name', 'email', 'phone', 'role', 'notes'], ivField: 'encryption_iv' },
  'account_nbas': { fields: ['action', 'notes'], ivField: 'encryption_iv' },
  'account_pain_points': { fields: ['pain_point', 'business_impact'], ivField: 'encryption_iv' },
  'account_use_cases': { fields: ['use_case', 'description'], ivField: 'encryption_iv' },
  'account_metrics': { fields: ['metric_value', 'context'], ivField: 'encryption_iv' },
  'account_strategic_themes': { fields: ['theme_name', 'description', 'supporting_evidence'], ivField: 'encryption_iv' },
  'account_exec_summaries': { fields: ['summary_narrative', 'key_risks', 'key_opportunities', 'health_indicators', 'engagement_summary'], ivField: 'encryption_iv' },
  'account_team_members': { fields: ['team_member_email'], ivField: 'encryption_iv' },
  'account_captured_insights': { fields: ['value', 'value_json'], ivField: 'encryption_iv' },
  'contact_meeting_snapshots': { fields: ['notes', 'key_quotes', 'topics_discussed', 'concerns_raised', 'action_items'], ivField: 'encryption_iv' },
  'customer_stories': { fields: ['situation', 'behavior', 'impact', 'impact_metrics'], ivField: 'encryption_iv' },
  'competitor_scores': { fields: ['rationale'], ivField: 'encryption_iv' },
  'competitors': { fields: ['description', 'relationship_notes'], ivField: 'encryption_iv' },
  'account_technologies': { fields: ['owner_name', 'owner_email', 'notes', 'context'], ivField: 'encryption_iv' },
  'account_documents': { fields: ['content', 'name'], ivField: 'encryption_iv' },
  'transcript_reviews': { fields: ['transcript_content'], ivField: 'encryption_iv' },
  'momentum_meetings': { fields: ['title', 'host_email', 'host_name', 'attendees', 'transcript_content'], ivField: 'pii_encryption_iv' },
  'opportunity_readiness_answers': { fields: ['answer', 'notes', 'evidence'], ivField: 'encryption_iv' },
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  const logs: string[] = [];
  const log = (msg: string) => {
    console.log(msg);
    logs.push(msg);
  };

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const KEY_PRIMARY = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || "";
    const KEY_ALTERNATE = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE") || "";

    if (!KEY_PRIMARY || !KEY_ALTERNATE) {
      throw new Error("Both TRANSCRIPT_ENCRYPTION_KEY and TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE must be set");
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { dryRun = true, tables } = await req.json();
    const tablesToProcess = tables || Object.keys(ENCRYPTED_TABLES);

    log(`[migrate] Starting migration (dryRun=${dryRun})`);
    log(`[migrate] Tables to process: ${tablesToProcess.join(', ')}`);

    const stats = {
      tablesProcessed: 0,
      recordsScanned: 0,
      decryptedWithPrimary: 0,
      decryptedWithAlternate: 0,
      reEncrypted: 0,
      deleted: 0,
      unrecoverable: 0,
      errors: [] as string[],
    };

    // Determine which key decrypts the most recent data
    let primaryKeyWins = 0;
    let alternateKeyWins = 0;

    for (const tableName of tablesToProcess) {
      const config = ENCRYPTED_TABLES[tableName];
      if (!config) {
        log(`[migrate] Skipping unknown table: ${tableName}`);
        continue;
      }

      stats.tablesProcessed++;
      log(`[migrate] Processing ${tableName}...`);

      // Fetch encrypted records
      const selectFields = ['id', 'is_encrypted', config.ivField, 'created_at'];
      for (const field of config.fields) {
        selectFields.push(`${field}_encrypted`);
        selectFields.push(field);
      }

      const { data: records, error } = await supabase
        .from(tableName)
        .select(selectFields.join(','))
        .eq('is_encrypted', true)
        .order('created_at', { ascending: false })
        .limit(1000);

      if (error) {
        stats.errors.push(`${tableName}: ${error.message}`);
        log(`[migrate] Error fetching ${tableName}: ${error.message}`);
        continue;
      }

      if (!records || records.length === 0) {
        log(`[migrate] No encrypted records in ${tableName}`);
        continue;
      }

      log(`[migrate] Found ${records.length} encrypted records in ${tableName}`);
      stats.recordsScanned += records.length;

      for (const rec of records) {
        const record = rec as unknown as Record<string, unknown>;
        const recordId = String(record.id);
        const iv = String(record[config.ivField] || '');
        if (!iv) {
          log(`[migrate] Record ${recordId} in ${tableName} has no IV - skipping`);
          continue;
        }

        // Find a field to test decryption
        let testField: string | null = null;
        let testCiphertext: string | null = null;
        for (const field of config.fields) {
          const encVal = record[`${field}_encrypted`];
          if (encVal && typeof encVal === 'string') {
            testField = field;
            testCiphertext = encVal;
            break;
          }
        }

        if (!testCiphertext) {
          log(`[migrate] Record ${recordId} in ${tableName} has no encrypted fields - skipping`);
          continue;
        }

        // Try primary key first
        const primaryResult = await tryDecrypt(testCiphertext, iv, KEY_PRIMARY);
        if (primaryResult.success) {
          stats.decryptedWithPrimary++;
          primaryKeyWins++;
          // Already using primary key - no migration needed
          continue;
        }

        // Try alternate key
        const alternateResult = await tryDecrypt(testCiphertext, iv, KEY_ALTERNATE);
        if (alternateResult.success) {
          stats.decryptedWithAlternate++;
          alternateKeyWins++;

          if (!dryRun) {
            // Re-encrypt with primary key
            try {
              const ivBytes = crypto.getRandomValues(new Uint8Array(12));
              const newIv = bytesToBase64(ivBytes);
              const updateData: Record<string, unknown> = {
                [config.ivField]: newIv,
                is_encrypted: true,
              };

              for (const field of config.fields) {
                const encVal = record[`${field}_encrypted`];
                if (encVal && typeof encVal === 'string') {
                  const decResult = await tryDecrypt(encVal, iv, KEY_ALTERNATE);
                  if (decResult.success && decResult.plaintext) {
                    updateData[`${field}_encrypted`] = await encryptWithIv(decResult.plaintext, ivBytes, KEY_PRIMARY);
                  }
                }
              }

              const { error: updateError } = await supabase
                .from(tableName)
                .update(updateData)
                .eq('id', recordId);

              if (updateError) {
                stats.errors.push(`${tableName}:${recordId} update failed: ${updateError.message}`);
              } else {
                stats.reEncrypted++;
              }
            } catch (e) {
              stats.errors.push(`${tableName}:${recordId} re-encrypt failed: ${e}`);
            }
          } else {
            log(`[migrate] Would re-encrypt ${tableName}:${recordId}`);
          }
          continue;
        }

        // Neither key works - unrecoverable
        stats.unrecoverable++;
        log(`[migrate] UNRECOVERABLE: ${tableName}:${recordId}`);

        if (!dryRun) {
          // Delete unrecoverable record
          const { error: deleteError } = await supabase
            .from(tableName)
            .delete()
            .eq('id', recordId);

          if (deleteError) {
            stats.errors.push(`${tableName}:${recordId} delete failed: ${deleteError.message}`);
          } else {
            stats.deleted++;
          }
        } else {
          log(`[migrate] Would delete unrecoverable ${tableName}:${recordId}`);
        }
      }
    }

    const duration = Date.now() - startTime;
    log(`[migrate] Completed in ${duration}ms`);
    log(`[migrate] Primary key decrypted: ${stats.decryptedWithPrimary}`);
    log(`[migrate] Alternate key decrypted: ${stats.decryptedWithAlternate}`);
    log(`[migrate] Re-encrypted: ${stats.reEncrypted}`);
    log(`[migrate] Deleted: ${stats.deleted}`);
    log(`[migrate] Unrecoverable: ${stats.unrecoverable}`);

    const recommendation = primaryKeyWins >= alternateKeyWins 
      ? "Primary key (TRANSCRIPT_ENCRYPTION_KEY) is decrypting most data - keep it as the standard."
      : "Alternate key (TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE) decrypts more data - consider swapping them.";

    return new Response(JSON.stringify({
      success: true,
      dryRun,
      stats,
      recommendation,
      logs,
      duration,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[migrate] Error:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      logs,
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

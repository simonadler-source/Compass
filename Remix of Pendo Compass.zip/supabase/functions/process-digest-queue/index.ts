import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// This function is called by a cron job to process digest emails
// It includes catch-up logic to handle missed digest windows (e.g., due to outages)
const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { frequency } = await req.json().catch(() => ({ frequency: 'daily' }));

    const now = new Date();
    const currentHour = now.getUTCHours();
    const currentDay = now.getUTCDay();
    const todayDateStr = now.toISOString().split('T')[0]; // YYYY-MM-DD
    
    // Calculate the end of the current hour window for matching
    const nextHour = (currentHour + 1) % 24;
    const currentTimeStr = `${currentHour.toString().padStart(2, '0')}:00:00`;
    const nextTimeStr = `${nextHour.toString().padStart(2, '0')}:00:00`;

    console.log(`Processing ${frequency} digests at ${currentTimeStr} (day: ${currentDay})`);

    // For daily digests: Find users whose digest_time is <= current hour
    // but who haven't received a digest today (catch-up logic)
    let query;
    
    if (frequency === 'daily') {
      // Get all users who should have received digest by now today
      // Their digest_time is <= current hour, and they haven't been sent today
      query = supabase
        .from('notification_preferences')
        .select('user_id, digest_time')
        .eq('email_enabled', true)
        .eq('frequency', 'daily')
        .lte('digest_time', nextTimeStr); // digest_time <= current hour end
    } else if (frequency === 'weekly') {
      // Weekly: only on the correct day, catch up missed hours
      query = supabase
        .from('notification_preferences')
        .select('user_id, digest_time')
        .eq('email_enabled', true)
        .eq('frequency', 'weekly')
        .eq('digest_day', currentDay)
        .lte('digest_time', nextTimeStr);
    } else {
      // Realtime doesn't use scheduled digests
      return new Response(JSON.stringify({ 
        success: true, 
        processed: 0,
        message: 'Realtime frequency does not use scheduled digests'
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const { data: eligibleUsers, error: usersError } = await query;

    if (usersError) {
      console.error('Error fetching eligible users:', usersError);
      throw usersError;
    }

    console.log(`Found ${eligibleUsers?.length || 0} eligible users for ${frequency} digest`);

    if (!eligibleUsers || eligibleUsers.length === 0) {
      return new Response(JSON.stringify({ 
        success: true, 
        processed: 0,
        message: 'No eligible users found'
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Check which of these users have already received a digest today
    const userIds = eligibleUsers.map(u => u.user_id);
    
    // Get today's midnight in UTC for the date filter
    const todayStart = new Date(todayDateStr + 'T00:00:00Z');
    
    const { data: sentToday, error: sentError } = await supabase
      .from('email_log')
      .select('recipient_user_id')
      .in('recipient_user_id', userIds)
      .eq('template_key', 'action_digest')
      .gte('created_at', todayStart.toISOString());

    if (sentError) {
      console.error('Error checking sent emails:', sentError);
      throw sentError;
    }

    const alreadySentUserIds = new Set((sentToday || []).map(s => s.recipient_user_id));
    
    // Filter to users who haven't received digest today
    const usersToNotify = eligibleUsers.filter(u => !alreadySentUserIds.has(u.user_id));

    console.log(`After filtering already-sent: ${usersToNotify.length} users to notify (${alreadySentUserIds.size} already received today)`);

    const results = [];

    // Process each user
    for (const user of usersToNotify) {
      try {
        console.log(`Sending ${frequency} digest to user ${user.user_id} (scheduled for ${user.digest_time})`);
        
        // Call the send-action-digest function for each user
        const response = await supabase.functions.invoke('send-action-digest', {
          body: { userId: user.user_id, frequency },
        });

        results.push({
          userId: user.user_id,
          scheduledTime: user.digest_time,
          success: !response.error,
          error: response.error?.message,
        });
      } catch (err: any) {
        console.error(`Error sending digest to ${user.user_id}:`, err.message);
        results.push({
          userId: user.user_id,
          scheduledTime: user.digest_time,
          success: false,
          error: err.message,
        });
      }
    }

    const successCount = results.filter(r => r.success).length;
    console.log(`Digest processing complete: ${successCount}/${results.length} successful`);

    return new Response(JSON.stringify({ 
      success: true, 
      processed: usersToNotify.length,
      alreadySentToday: alreadySentUserIds.size,
      results 
    }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });

  } catch (error: any) {
    console.error("Error in process-digest-queue function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);

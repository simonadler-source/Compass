import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-session-token',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Validate session
    const sessionToken = req.headers.get('x-session-token');
    if (!sessionToken) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: sessionData, error: sessionError } = await supabase.rpc('validate_session', { _token: sessionToken });
    if (sessionError || !sessionData || sessionData.length === 0 || sessionData[0].status !== 'active') {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const body = await req.json();
    const { type, from, to, meetingContext } = body;

    console.log(`[ProductAnalytics] ${type} query from=${from} to=${to} meetingContext=${meetingContext || 'all'}`);

    if (!from || !to) {
      return new Response(JSON.stringify({ error: 'Missing from/to date parameters' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Build RPC params — pass null for meetingContext to get all
    const rpcParams: Record<string, any> = {
      p_from: from,
      p_to: to,
    };
    if (meetingContext) {
      rpcParams.p_meeting_context = meetingContext;
    }

    let result;

    if (type === 'trends') {
      const { data, error } = await supabase.rpc('get_product_mention_trends', rpcParams);

      if (error) {
        console.error('[ProductAnalytics] Trends RPC error:', error);
        throw error;
      }

      console.log(`[ProductAnalytics] Trends returned ${data?.length || 0} rows`);
      result = data;

    } else if (type === 'stats') {
      const { data, error } = await supabase.rpc('get_product_mention_stats', rpcParams);

      if (error) {
        console.error('[ProductAnalytics] Stats RPC error:', error);
        throw error;
      }

      console.log(`[ProductAnalytics] Stats returned ${data?.length || 0} rows`);
      result = data;

    } else {
      return new Response(JSON.stringify({ error: `Unknown type: ${type}` }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ data: result }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (e) {
    console.error('[ProductAnalytics] Error:', e);
    return new Response(JSON.stringify({ error: e.message || 'Internal error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

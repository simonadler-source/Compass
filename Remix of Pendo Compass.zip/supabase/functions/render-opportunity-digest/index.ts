import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ==================== ENCRYPTION HELPERS ====================
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < Math.min(raw.length, 32); i++) key[i] = raw[i];
  return key;
}

function base64ToBytes(b64: string): Uint8Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function decryptField(ciphertext: string, ivBase64: string, keyInput: string): Promise<string | null> {
  try {
    const iv = base64ToBytes(ivBase64);
    const cipherBytes = base64ToBytes(ciphertext);
    const keyBytes = deriveKeyBytes(keyInput);
    const cryptoKey = await crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['decrypt']);
    const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, cryptoKey, cipherBytes);
    return new TextDecoder().decode(decrypted);
  } catch {
    const altKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY_ALTERNATE");
    if (altKey) {
      try {
        const iv = base64ToBytes(ivBase64);
        const cipherBytes = base64ToBytes(ciphertext);
        const keyBytes = deriveKeyBytes(altKey);
        const cryptoKey = await crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['decrypt']);
        const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, cryptoKey, cipherBytes);
        return new TextDecoder().decode(decrypted);
      } catch { return null; }
    }
    return null;
  }
}

async function decryptRow(row: any, fields: string[], ivField: string, encKey: string) {
  if (!row || !row[ivField]) return row;
  for (const field of fields) {
    const encField = `${field}_encrypted`;
    if (row[encField]) {
      const decrypted = await decryptField(row[encField], row[ivField], encKey);
      if (decrypted !== null) row[field] = decrypted;
    }
  }
  return row;
}

async function decryptRows(rows: any[], fields: string[], ivField: string, encKey: string) {
  return Promise.all(rows.map(r => decryptRow(r, fields, ivField, encKey)));
}

// ==================== HTML HELPERS ====================
function escapeHtml(text: string | null | undefined): string {
  if (!text) return '';
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function formatDate(dateStr: string | null): string {
  if (!dateStr) return 'N/A';
  try { return new Date(dateStr).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }); }
  catch { return dateStr; }
}

function formatCurrency(val: number | null): string {
  if (val == null) return 'N/A';
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const token = url.searchParams.get('token');

  if (!token) {
    return new Response('<html><body><h1>Missing share token</h1><p>Append ?token=YOUR_TOKEN to the URL.</p></body></html>', {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'text/html; charset=utf-8' },
    });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const encKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || '';
  const supabase = createClient(supabaseUrl, serviceKey);

  // 1. Validate share token
  const { data: shareLink, error: linkErr } = await supabase
    .from('opportunity_share_links')
    .select('*')
    .eq('share_token', token)
    .single();

  if (linkErr || !shareLink) {
    return new Response('<html><body><h1>Invalid or expired share link</h1></body></html>', {
      status: 404, headers: { ...corsHeaders, 'Content-Type': 'text/html; charset=utf-8' },
    });
  }

  if (shareLink.revoked_at) {
    return new Response('<html><body><h1>This share link has been revoked</h1></body></html>', {
      status: 403, headers: { ...corsHeaders, 'Content-Type': 'text/html; charset=utf-8' },
    });
  }

  // Update access tracking
  await supabase.from('opportunity_share_links').update({
    last_accessed_at: new Date().toISOString(),
    access_count: (shareLink.access_count || 0) + 1,
  }).eq('id', shareLink.id);

  const opportunityId = shareLink.opportunity_id;

  // 2. Fetch all opportunity data in parallel
  const [
    oppResult, contactsResult, useCasesResult, painPointsResult,
    nbasResult, milestonesResult, metricsResult, readinessResult,
    readinessQuestionsResult, competitiveInsightsResult, themesResult, teamResult,
    validationTasksResult, documentsResult,
    competitivePlaysResult, detectionMatchesResult, technologiesResult,
    profilesResult,
  ] = await Promise.all([
    supabase.from('opportunities').select('*').eq('id', opportunityId).single(),
    supabase.from('account_contacts').select('*').eq('opportunity_id', opportunityId),
    supabase.from('account_use_cases').select('*').eq('opportunity_id', opportunityId),
    supabase.from('account_pain_points').select('*').eq('opportunity_id', opportunityId),
    supabase.from('account_nbas').select('*').eq('opportunity_id', opportunityId),
    supabase.from('opportunity_milestones').select('*').eq('opportunity_id', opportunityId).order('scheduled_date', { ascending: true }),
    supabase.from('account_metrics').select('*').eq('opportunity_id', opportunityId),
    supabase.from('opportunity_readiness_answers').select('*').eq('opportunity_id', opportunityId),
    supabase.from('readiness_template_questions').select('*, category:readiness_template_categories(name)'),
    supabase.from('opportunity_competitive_insights').select('*').eq('opportunity_id', opportunityId),
    supabase.from('account_strategic_themes').select('*'),
    supabase.from('opportunity_team_members').select('*').eq('opportunity_id', opportunityId),
    supabase.from('opportunity_validation_tasks').select('*').eq('opportunity_id', opportunityId),
    supabase.from('account_documents').select('*').eq('opportunity_id', opportunityId),
    // NEW: Competitive plays
    supabase.from('competitive_plays').select('*').eq('opportunity_id', opportunityId),
    // NEW: Detection signal matches with history
    supabase.from('detection_rule_matches').select('*, rule:detection_rules(name, tree_id)').eq('opportunity_id', opportunityId).order('first_detected_at', { ascending: true }),
    // NEW: Account technologies (current state architecture) - fetched after account known
    supabase.from('account_technologies').select('*').limit(0), // placeholder
    // NEW: Profiles for NBA assignees
    supabase.from('profiles').select('id, email, full_name'),
  ]);

  const opp = oppResult.data;
  if (!opp) {
    return new Response('<html><body><h1>Opportunity not found</h1></body></html>', {
      status: 404, headers: { ...corsHeaders, 'Content-Type': 'text/html; charset=utf-8' },
    });
  }

  // Fetch account and related data that depends on account_id
  const [accountRes, execSummaryRes, technologiesRes] = await Promise.all([
    supabase.from('accounts').select('*').eq('id', opp.account_id).single(),
    supabase.from('account_exec_summaries').select('*').eq('account_id', opp.account_id).maybeSingle(),
    supabase.from('account_technologies').select('*').eq('account_id', opp.account_id),
  ]);

  const account = accountRes.data;
  const execSummary = execSummaryRes.data;

  // Filter themes to this account
  const themes = (themesResult.data || []).filter((t: any) => t.account_id === opp.account_id);

  // Build a profile lookup for NBA assignees
  const profileMap = new Map((profilesResult.data || []).map((p: any) => [p.id, p]));
  const profileByEmail = new Map((profilesResult.data || []).map((p: any) => [p.email?.toLowerCase(), p]));

  // 3. Decrypt encrypted fields
  const contacts = await decryptRows(contactsResult.data || [], ['name', 'email', 'phone', 'role', 'notes'], 'encryption_iv', encKey);
  const useCases = await decryptRows(useCasesResult.data || [], ['use_case', 'description'], 'encryption_iv', encKey);
  const painPoints = await decryptRows(painPointsResult.data || [], ['pain_point', 'business_impact'], 'encryption_iv', encKey);
  const nbas = await decryptRows(nbasResult.data || [], ['action', 'notes'], 'encryption_iv', encKey);
  const metrics = await decryptRows(metricsResult.data || [], ['metric_value', 'context', 'mentioned_by_name', 'mentioned_by_email'], 'encryption_iv', encKey);
  const decryptedThemes = await decryptRows(themes, ['theme_name', 'description', 'supporting_evidence'], 'encryption_iv', encKey);
  const milestones = await decryptRows(milestonesResult.data || [], ['name', 'description', 'notes'], 'encryption_iv', encKey);
  const readinessAnswers = await decryptRows(readinessResult.data || [], ['answer'], 'encryption_iv', encKey);
  const validationTasks = await decryptRows(validationTasksResult.data || [], ['task_name', 'notes', 'outcome_notes'], 'encryption_iv', encKey);
  const documents = await decryptRows(documentsResult.data || [], ['name', 'description', 'content'], 'encryption_iv', encKey);
  const competitiveInsights = competitiveInsightsResult.data || [];
  const competitivePlays = await decryptRows(competitivePlaysResult.data || [], ['play_title', 'play_description', 'play_strategy'], 'encryption_iv', encKey);
  const detectionMatches = detectionMatchesResult.data || [];
  const technologies = await decryptRows(technologiesRes.data || [], ['context', 'notes', 'owner_name', 'owner_email'], 'encryption_iv', encKey);

  let decryptedExecSummary: any = null;
  if (execSummary) {
    decryptedExecSummary = await decryptRow(execSummary, ['summary_narrative', 'key_risks', 'key_opportunities', 'health_indicators', 'engagement_summary'], 'encryption_iv', encKey);
  }

  const readinessQuestions = readinessQuestionsResult.data || [];
  const teamMembers = teamResult.data || [];

  // Helper: resolve NBA assignee name
  function resolveAssignee(nba: any): string {
    if (nba.assigned_to) {
      const profile = profileMap.get(nba.assigned_to);
      if (profile) return profile.full_name || profile.email || 'Unknown';
      // Try by email
      const byEmail = profileByEmail.get(nba.assigned_to?.toLowerCase());
      if (byEmail) return byEmail.full_name || byEmail.email || 'Unknown';
      return nba.assigned_to; // might be an email string
    }
    return 'Unassigned';
  }

  // 4. Build the HTML digest
  const stageLabel = opp.sales_stage || opp.stage || 'Unknown';
  const preSalesLabel = opp.pre_sales_stage || '';

  const sections: string[] = [];

  // --- HEADER ---
  sections.push(`
    <header>
      <h1>${escapeHtml(opp.name)}</h1>
      <p class="meta">Account: <strong>${escapeHtml(account?.name)}</strong> | Industry: ${escapeHtml(account?.industry)} | Employees: ${account?.employee_count || 'N/A'}</p>
      <p class="meta">Sales Stage: <strong>${escapeHtml(stageLabel)}</strong>${preSalesLabel ? ` | Pre-Sales: <strong>${escapeHtml(preSalesLabel)}</strong>` : ''}</p>
      <p class="meta">Value: ${formatCurrency(opp.value)} | Close Date: ${formatDate(opp.close_date)} | Priority: ${escapeHtml(opp.priority)}</p>
      ${opp.readiness_score != null ? `<p class="meta">Technical Readiness Score: <strong>${opp.readiness_score}%</strong></p>` : ''}
      ${opp.description ? `<p class="description">${escapeHtml(opp.description)}</p>` : ''}
      <p class="meta generated">Generated: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
    </header>
  `);

  // --- EXECUTIVE SUMMARY ---
  if (decryptedExecSummary?.summary_narrative) {
    let risksHtml = '';
    let oppsHtml = '';
    try {
      const risks = typeof decryptedExecSummary.key_risks === 'string' ? JSON.parse(decryptedExecSummary.key_risks) : decryptedExecSummary.key_risks;
      if (Array.isArray(risks) && risks.length > 0) {
        risksHtml = `<h3>Key Risks</h3><ul>${risks.map((r: any) => `<li>${escapeHtml(typeof r === 'string' ? r : r.risk || r.description || JSON.stringify(r))}</li>`).join('')}</ul>`;
      }
    } catch {}
    try {
      const opps = typeof decryptedExecSummary.key_opportunities === 'string' ? JSON.parse(decryptedExecSummary.key_opportunities) : decryptedExecSummary.key_opportunities;
      if (Array.isArray(opps) && opps.length > 0) {
        oppsHtml = `<h3>Key Opportunities</h3><ul>${opps.map((o: any) => `<li>${escapeHtml(typeof o === 'string' ? o : o.opportunity || o.description || JSON.stringify(o))}</li>`).join('')}</ul>`;
      }
    } catch {}

    sections.push(`
      <section>
        <h2>Executive Summary</h2>
        <p>${escapeHtml(decryptedExecSummary.summary_narrative)}</p>
        ${risksHtml}
        ${oppsHtml}
      </section>
    `);
  }

  // --- STRATEGIC CHALLENGES & INITIATIVES ---
  const challenges = decryptedThemes.filter((t: any) => t.theme_type === 'challenge' || t.theme_type === 'risk');
  const initiatives = decryptedThemes.filter((t: any) => t.theme_type === 'initiative' || t.theme_type === 'opportunity' || t.theme_type === 'goal');
  const otherThemes = decryptedThemes.filter((t: any) => !['challenge', 'risk', 'initiative', 'opportunity', 'goal'].includes(t.theme_type));

  if (challenges.length > 0) {
    sections.push(`
      <section>
        <h2>Strategic Challenges (${challenges.length})</h2>
        <table><thead><tr><th>Challenge</th><th>Impact</th><th>Description</th><th>Supporting Evidence</th></tr></thead>
        <tbody>${challenges.map((t: any) => {
          let evidence = t.supporting_evidence;
          if (typeof evidence === 'string') { try { evidence = JSON.parse(evidence); } catch {} }
          const evidenceStr = Array.isArray(evidence) ? evidence.map((e: any) => typeof e === 'string' ? e : e.text || e.evidence || JSON.stringify(e)).join('; ') : (typeof evidence === 'string' ? evidence : '');
          return `<tr><td>${escapeHtml(t.theme_name)}</td><td>${escapeHtml(t.impact_level)}</td><td>${escapeHtml(t.description)}</td><td>${escapeHtml(evidenceStr)}</td></tr>`;
        }).join('')}</tbody></table>
      </section>
    `);
  }

  if (initiatives.length > 0) {
    sections.push(`
      <section>
        <h2>Strategic Initiatives (${initiatives.length})</h2>
        <table><thead><tr><th>Initiative</th><th>Impact</th><th>Description</th><th>Supporting Evidence</th></tr></thead>
        <tbody>${initiatives.map((t: any) => {
          let evidence = t.supporting_evidence;
          if (typeof evidence === 'string') { try { evidence = JSON.parse(evidence); } catch {} }
          const evidenceStr = Array.isArray(evidence) ? evidence.map((e: any) => typeof e === 'string' ? e : e.text || e.evidence || JSON.stringify(e)).join('; ') : (typeof evidence === 'string' ? evidence : '');
          return `<tr><td>${escapeHtml(t.theme_name)}</td><td>${escapeHtml(t.impact_level)}</td><td>${escapeHtml(t.description)}</td><td>${escapeHtml(evidenceStr)}</td></tr>`;
        }).join('')}</tbody></table>
      </section>
    `);
  }

  if (otherThemes.length > 0) {
    sections.push(`
      <section>
        <h2>Other Strategic Themes (${otherThemes.length})</h2>
        <table><thead><tr><th>Theme</th><th>Type</th><th>Impact</th><th>Description</th></tr></thead>
        <tbody>${otherThemes.map((t: any) => `<tr><td>${escapeHtml(t.theme_name)}</td><td>${escapeHtml(t.theme_type)}</td><td>${escapeHtml(t.impact_level)}</td><td>${escapeHtml(t.description)}</td></tr>`).join('')}</tbody></table>
      </section>
    `);
  }

  // --- STAKEHOLDERS WITH SCORES ---
  if (contacts.length > 0) {
    const externalContacts = contacts.filter((c: any) => !c.is_internal && !c.is_ignored);
    if (externalContacts.length > 0) {
      // Sort by influence descending
      externalContacts.sort((a: any, b: any) => (b.influence_level || 0) - (a.influence_level || 0));
      sections.push(`
        <section>
          <h2>Stakeholders (${externalContacts.length})</h2>
          <table><thead><tr><th>Name</th><th>Role</th><th>Type</th><th>Influence (0-100)</th><th>Sentiment (0-100)</th><th>Champion Score (0-100)</th><th>Assessment Source</th></tr></thead>
          <tbody>${externalContacts.map((c: any) => {
            const sentimentLabel = c.sentiment != null ? (c.sentiment >= 70 ? '🟢' : c.sentiment >= 40 ? '🟡' : '🔴') : '';
            const influenceLabel = c.influence_level != null ? (c.influence_level >= 70 ? '🟢' : c.influence_level >= 40 ? '🟡' : '🔴') : '';
            const championLabel = c.champion_score != null ? (c.champion_score >= 70 ? '🟢' : c.champion_score >= 40 ? '🟡' : '🔴') : '';
            return `<tr>
              <td>${escapeHtml(c.name)}</td><td>${escapeHtml(c.role)}</td><td>${escapeHtml(c.stakeholder_type)}</td>
              <td>${c.influence_level ?? 'N/A'} ${influenceLabel}</td>
              <td>${c.sentiment ?? 'N/A'} ${sentimentLabel}</td>
              <td>${c.champion_score ?? 'N/A'} ${championLabel}</td>
              <td>${escapeHtml(c.assessment_source || 'N/A')}</td>
            </tr>`;
          }).join('')}</tbody></table>
        </section>
      `);
    }
  }

  // --- CURRENT STATE ARCHITECTURE ---
  if (technologies.length > 0) {
    // Group by layer
    const layerGroups: Record<string, any[]> = {};
    for (const tech of technologies) {
      const layer = tech.layer || 'Other';
      if (!layerGroups[layer]) layerGroups[layer] = [];
      layerGroups[layer].push(tech);
    }

    let techHtml = '';
    for (const [layer, techs] of Object.entries(layerGroups)) {
      techHtml += `<h3>${escapeHtml(layer)}</h3>
        <table><thead><tr><th>Technology</th><th>Category</th><th>Status</th><th>Priority</th><th>Owner</th><th>Notes</th></tr></thead>
        <tbody>${techs.map((t: any) => `<tr>
          <td>${escapeHtml(t.name)}</td><td>${escapeHtml(t.category)}</td><td>${escapeHtml(t.status)}</td>
          <td>${escapeHtml(t.priority)}</td><td>${escapeHtml(t.owner_name || t.owner_email || '')}</td>
          <td>${escapeHtml(t.notes || t.context || '')}</td>
        </tr>`).join('')}</tbody></table>`;
    }

    sections.push(`
      <section>
        <h2>Current State Architecture (${technologies.length} technologies)</h2>
        ${techHtml}
      </section>
    `);
  }

  // --- FUTURE STATE / USE CASES ---
  if (useCases.length > 0) {
    sections.push(`
      <section>
        <h2>Future State – Use Cases (${useCases.length})</h2>
        <table><thead><tr><th>Use Case</th><th>Status</th><th>Priority</th><th>Functional Area</th><th>Business Theme</th><th>Description</th></tr></thead>
        <tbody>${useCases.map((u: any) => `<tr>
          <td>${escapeHtml(u.use_case)}</td><td>${escapeHtml(u.status)}</td><td>${escapeHtml(u.priority)}</td>
          <td>${escapeHtml(u.functional_area)}</td><td>${escapeHtml(u.business_theme)}</td><td>${escapeHtml(u.description)}</td>
        </tr>`).join('')}</tbody></table>
      </section>
    `);
  }

  // --- PAIN POINTS ---
  if (painPoints.length > 0) {
    sections.push(`
      <section>
        <h2>Pain Points (${painPoints.length})</h2>
        <table><thead><tr><th>Pain Point</th><th>Severity</th><th>Category</th><th>Business Impact</th></tr></thead>
        <tbody>${painPoints.map((p: any) => {
          let impact = p.business_impact;
          if (Array.isArray(impact)) impact = impact.join(', ');
          return `<tr><td>${escapeHtml(p.pain_point)}</td><td>${escapeHtml(p.severity)}</td><td>${escapeHtml(p.pain_category)}</td><td>${escapeHtml(impact)}</td></tr>`;
        }).join('')}</tbody></table>
      </section>
    `);
  }

  // --- NEXT BEST ACTIONS (with ownership) ---
  const activeNbas = nbas.filter((n: any) => n.status !== 'completed');
  const completedNbas = nbas.filter((n: any) => n.status === 'completed');
  if (nbas.length > 0) {
    sections.push(`
      <section>
        <h2>Next Best Actions (${activeNbas.length} active, ${completedNbas.length} completed)</h2>
        <h3>Outstanding Actions</h3>
        ${activeNbas.length > 0 ? `
        <table><thead><tr><th>Action</th><th>Type</th><th>Priority</th><th>Status</th><th>Assigned To</th><th>Due Date</th><th>Notes</th></tr></thead>
        <tbody>${activeNbas.map((n: any) => `<tr>
          <td>${escapeHtml(n.action)}</td><td>${escapeHtml(n.action_type)}</td><td>${escapeHtml(n.priority)}</td>
          <td>${escapeHtml(n.status)}</td><td><strong>${escapeHtml(resolveAssignee(n))}</strong></td>
          <td>${formatDate(n.due_date)}</td><td>${escapeHtml(n.notes)}</td>
        </tr>`).join('')}</tbody></table>` : '<p>No outstanding actions.</p>'}
        ${completedNbas.length > 0 ? `
        <h3>Completed Actions</h3>
        <table><thead><tr><th>Action</th><th>Type</th><th>Assigned To</th><th>Completed</th><th>Notes</th></tr></thead>
        <tbody>${completedNbas.map((n: any) => `<tr>
          <td>${escapeHtml(n.action)}</td><td>${escapeHtml(n.action_type)}</td>
          <td>${escapeHtml(resolveAssignee(n))}</td><td>${formatDate(n.completed_at)}</td><td>${escapeHtml(n.notes)}</td>
        </tr>`).join('')}</tbody></table>` : ''}
      </section>
    `);
  }

  // --- MILESTONES ---
  if (milestones.length > 0) {
    sections.push(`
      <section>
        <h2>Milestones (${milestones.length})</h2>
        <table><thead><tr><th>Milestone</th><th>Status</th><th>Target Date</th><th>Actual Date</th><th>Owner</th><th>Notes</th></tr></thead>
        <tbody>${milestones.map((m: any) => `<tr>
          <td>${escapeHtml(m.name)}</td><td>${escapeHtml(m.status)}</td><td>${formatDate(m.scheduled_date || m.target_date)}</td>
          <td>${formatDate(m.actual_date)}</td><td>${escapeHtml(m.owner_name || m.owner_email)}</td><td>${escapeHtml(m.notes)}</td>
        </tr>`).join('')}</tbody></table>
      </section>
    `);
  }

  // --- DETECTION SIGNALS & HISTORY ---
  if (detectionMatches.length > 0) {
    // Group by rule name
    const signalGroups: Record<string, any[]> = {};
    for (const match of detectionMatches) {
      const ruleName = match.rule?.name || 'Unknown Signal';
      if (!signalGroups[ruleName]) signalGroups[ruleName] = [];
      signalGroups[ruleName].push(match);
    }

    let signalHtml = '';
    for (const [ruleName, matches] of Object.entries(signalGroups)) {
      const latestMatch = matches[matches.length - 1];
      signalHtml += `
        <div class="signal-group">
          <h3>${escapeHtml(ruleName)} (${matches.length} occurrence${matches.length !== 1 ? 's' : ''})</h3>
          <p class="meta">First detected: ${formatDate(matches[0].first_detected_at)} | Latest: ${formatDate(latestMatch.created_at)} | Confidence: ${latestMatch.confidence_score != null ? `${Math.round(latestMatch.confidence_score * 100)}%` : 'N/A'}</p>
          <table><thead><tr><th>Detected At</th><th>Confidence</th><th>Speaker</th><th>Occurrences</th></tr></thead>
          <tbody>${matches.map((m: any) => `<tr>
            <td>${formatDate(m.created_at)}</td>
            <td>${m.confidence_score != null ? `${Math.round(m.confidence_score * 100)}%` : 'N/A'}</td>
            <td>${escapeHtml(m.speaker_type || '')}</td>
            <td>${m.occurrence_count || 1}</td>
          </tr>`).join('')}</tbody></table>
        </div>`;
    }

    sections.push(`
      <section>
        <h2>Detection Signals & History (${detectionMatches.length} total detections)</h2>
        ${signalHtml}
      </section>
    `);
  }

  // --- TECHNICAL READINESS ---
  if (readinessAnswers.length > 0) {
    const questionMap = new Map(readinessQuestions.map((q: any) => [q.id, q]));
    const answeredQuestions = readinessAnswers.filter((a: any) => a.answer || a.answer_encrypted);

    if (answeredQuestions.length > 0) {
      sections.push(`
        <section>
          <h2>Technical Readiness (${answeredQuestions.length} answers)</h2>
          <table><thead><tr><th>Question</th><th>Answer</th><th>Confidence</th><th>Status</th></tr></thead>
          <tbody>${answeredQuestions.map((a: any) => {
            const q = questionMap.get(a.question_id);
            const flag = a.manual_flag_status || (a.confidence_score >= 85 ? 'green' : a.confidence_score >= 60 ? 'amber' : 'red');
            const flagEmoji = flag === 'green' ? '🟢' : flag === 'amber' ? '🟡' : '🔴';
            return `<tr>
              <td>${escapeHtml(q?.question_text || a.question_id)}</td>
              <td>${escapeHtml(a.answer)}</td>
              <td>${a.confidence_score != null ? `${a.confidence_score}%` : 'N/A'}</td>
              <td>${flagEmoji} ${escapeHtml(flag)}</td>
            </tr>`;
          }).join('')}</tbody></table>
        </section>
      `);
    }
  }

  // --- VALIDATION TASKS ---
  if (validationTasks.length > 0) {
    sections.push(`
      <section>
        <h2>Validation Tasks (${validationTasks.length})</h2>
        <table><thead><tr><th>Task</th><th>Status</th><th>Completed</th><th>Outcome</th></tr></thead>
        <tbody>${validationTasks.map((t: any) => `<tr>
          <td>${escapeHtml(t.task_name)}</td><td>${escapeHtml(t.status)}</td>
          <td>${formatDate(t.completed_at)}</td><td>${escapeHtml(t.outcome_notes)}</td>
        </tr>`).join('')}</tbody></table>
      </section>
    `);
  }

  // --- COMPETITIVE LANDSCAPE ---
  if (competitiveInsights.length > 0) {
    sections.push(`
      <section>
        <h2>Competitive Intelligence (${competitiveInsights.length})</h2>
        <table><thead><tr><th>Competitor</th><th>Positioning</th><th>Strengths</th><th>Weaknesses</th><th>Win Strategy</th></tr></thead>
        <tbody>${competitiveInsights.map((ci: any) => `<tr>
          <td>${escapeHtml(ci.competitor_name)}</td><td>${escapeHtml(ci.positioning)}</td>
          <td>${escapeHtml(Array.isArray(ci.strengths) ? ci.strengths.join(', ') : ci.strengths)}</td>
          <td>${escapeHtml(Array.isArray(ci.weaknesses) ? ci.weaknesses.join(', ') : ci.weaknesses)}</td>
          <td>${escapeHtml(ci.win_strategy)}</td>
        </tr>`).join('')}</tbody></table>
      </section>
    `);
  }

  // --- COMPETITIVE PLAYS ---
  if (competitivePlays.length > 0) {
    const attackPlays = competitivePlays.filter((p: any) => p.play_type === 'attack' || p.play_type === 'Attack');
    const defendPlays = competitivePlays.filter((p: any) => p.play_type === 'defend' || p.play_type === 'Defend');
    const otherPlays = competitivePlays.filter((p: any) => !['attack', 'Attack', 'defend', 'Defend'].includes(p.play_type));

    let playsHtml = '';
    const renderPlays = (plays: any[], label: string) => {
      if (plays.length === 0) return '';
      return `<h3>${label} (${plays.length})</h3>
        <table><thead><tr><th>Play</th><th>Competitor</th><th>Strategy</th><th>Description</th><th>Talking Points</th></tr></thead>
        <tbody>${plays.map((p: any) => {
          let talkingPoints = p.talking_points;
          if (typeof talkingPoints === 'string') { try { talkingPoints = JSON.parse(talkingPoints); } catch {} }
          const tpStr = Array.isArray(talkingPoints) ? talkingPoints.map((tp: any) => typeof tp === 'string' ? tp : tp.point || JSON.stringify(tp)).join('; ') : '';
          return `<tr>
            <td>${escapeHtml(p.play_title)}</td><td>${escapeHtml(p.competitor_name)}</td>
            <td>${escapeHtml(p.play_strategy)}</td><td>${escapeHtml(p.play_description)}</td>
            <td>${escapeHtml(tpStr)}</td>
          </tr>`;
        }).join('')}</tbody></table>`;
    };

    playsHtml += renderPlays(attackPlays, '🗡️ Attack Plays');
    playsHtml += renderPlays(defendPlays, '🛡️ Defend Plays');
    playsHtml += renderPlays(otherPlays, 'Other Plays');

    sections.push(`
      <section>
        <h2>Competitive Plays (${competitivePlays.length})</h2>
        ${playsHtml}
      </section>
    `);
  }

  // --- METRICS ---
  if (metrics.length > 0) {
    sections.push(`
      <section>
        <h2>Key Metrics (${metrics.length})</h2>
        <table><thead><tr><th>Metric</th><th>Value</th><th>Category</th><th>Context</th><th>Mentioned By</th></tr></thead>
        <tbody>${metrics.map((m: any) => `<tr>
          <td>${escapeHtml(m.metric_name)}</td><td>${escapeHtml(m.metric_value)}</td><td>${escapeHtml(m.metric_category)}</td>
          <td>${escapeHtml(m.context)}</td><td>${escapeHtml(m.mentioned_by_name)}</td>
        </tr>`).join('')}</tbody></table>
      </section>
    `);
  }

  // --- TEAM ---
  if (teamMembers.length > 0) {
    sections.push(`
      <section>
        <h2>Internal Team (${teamMembers.length})</h2>
        <ul>${teamMembers.map((t: any) => `<li>${escapeHtml(t.member_name || t.member_email)} – ${escapeHtml(t.role)}</li>`).join('')}</ul>
      </section>
    `);
  }

  // --- DOCUMENTS ---
  if (documents.length > 0) {
    sections.push(`
      <section>
        <h2>Documents (${documents.length})</h2>
        <ul>${documents.map((d: any) => `<li><strong>${escapeHtml(d.name)}</strong> (${escapeHtml(d.type)}) – ${escapeHtml(d.description)}</li>`).join('')}</ul>
      </section>
    `);
  }

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(opp.name)} – Opportunity Digest</title>
  <meta name="description" content="Opportunity digest for ${escapeHtml(opp.name)} at ${escapeHtml(account?.name)}">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 960px; margin: 0 auto; padding: 2rem; color: #1a1a2e; background: #fafafa; line-height: 1.6; }
    header { border-bottom: 2px solid #e0e0e0; padding-bottom: 1.5rem; margin-bottom: 2rem; }
    h1 { font-size: 1.8rem; margin-bottom: 0.5rem; color: #0f0f23; }
    h2 { font-size: 1.3rem; color: #1a1a3e; border-bottom: 1px solid #e8e8e8; padding-bottom: 0.3rem; margin-top: 2rem; }
    h3 { font-size: 1.1rem; color: #333; margin-top: 1rem; }
    .meta { color: #555; font-size: 0.9rem; margin: 0.2rem 0; }
    .generated { font-style: italic; color: #888; margin-top: 0.8rem; }
    .description { background: #f0f4f8; padding: 0.8rem 1rem; border-radius: 6px; margin-top: 0.8rem; }
    table { width: 100%; border-collapse: collapse; margin: 1rem 0; font-size: 0.85rem; }
    th, td { padding: 0.5rem 0.7rem; border: 1px solid #ddd; text-align: left; vertical-align: top; }
    th { background: #f5f5f5; font-weight: 600; }
    tr:nth-child(even) { background: #fafafa; }
    ul { padding-left: 1.5rem; }
    li { margin-bottom: 0.3rem; }
    section { margin-bottom: 1.5rem; }
    .signal-group { margin-bottom: 1rem; padding: 0.5rem; background: #f8f9fa; border-radius: 4px; }
    @media print { body { padding: 0; } }
  </style>
</head>
<body>
  ${sections.join('\n')}
  <footer style="margin-top: 3rem; padding-top: 1rem; border-top: 1px solid #e0e0e0; font-size: 0.8rem; color: #999;">
    <p>This digest was generated from Searchitecture. It represents a point-in-time snapshot of opportunity intelligence.</p>
  </footer>
</body>
</html>`;

  return new Response(html, {
    headers: { ...corsHeaders, 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' },
  });
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const MAX_RETRIES = 2;
const MAX_PASS_RETRIES = 2; // Max auto-retries per failed analysis pass
const STUCK_THRESHOLD_MINUTES = 5;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(supabaseUrl, supabaseKey);

  try {
    const thirtyMinutesAgo = new Date(Date.now() - 30 * 60 * 1000).toISOString();
    const fiveMinutesAgo = new Date(Date.now() - STUCK_THRESHOLD_MINUTES * 60 * 1000).toISOString();
    const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000).toISOString();

    // ============================================================
    // PHASE 1: STUCK ANALYSIS_RUN_LOGS RECOVERY
    // Mark any analysis_run_logs stuck in 'running' for >5 min as 'failed'
    // ============================================================
    let stuckRecoveredCount = 0;
    try {
      const { data: stuckRunLogs, error: stuckRunErr } = await supabase
        .from('analysis_run_logs')
        .select('id, pass_key, transcript_id')
        .eq('status', 'running')
        .lt('started_at', fiveMinutesAgo)
        .limit(200);
      
      if (stuckRunErr) {
        console.error('[RetryEnrichment] Stuck run logs query error:', stuckRunErr.message);
      } else if (stuckRunLogs && stuckRunLogs.length > 0) {
        stuckRecoveredCount = stuckRunLogs.length;
        console.log(`[RetryEnrichment] Found ${stuckRunLogs.length} analysis_run_logs stuck in 'running', marking as failed`);
        const stuckIds = stuckRunLogs.map((l: any) => l.id);
        await supabase
          .from('analysis_run_logs')
          .update({
            status: 'failed',
            completed_at: new Date().toISOString(),
            error_message: 'Pass was stuck in running state for >5 minutes (edge function crash/timeout). Auto-recovered by cron.',
            error_category: 'timeout',
          })
          .in('id', stuckIds);
      }
    } catch (e) {
      console.error('[RetryEnrichment] Stuck run logs recovery error:', e);
    }

    // ============================================================
    // PHASE 2: AUTO-RETRY FAILED ANALYSIS PASSES
    // Find transcripts with failed passes that haven't been retried too many times
    // Only retry passes that failed >10 min ago (avoid racing with in-progress retries)
    // ============================================================
    let passRetryCount = 0;
    try {
      // Find distinct transcripts with recent failed passes
      const { data: failedPasses, error: failedErr } = await supabase
        .from('analysis_run_logs')
        .select('transcript_id, pass_key, retry_attempt, error_category, started_at')
        .eq('status', 'failed')
        .lt('started_at', tenMinutesAgo)
        .order('started_at', { ascending: false })
        .limit(500);
      
      if (failedErr) {
        console.error('[RetryEnrichment] Failed passes query error:', failedErr.message);
      } else if (failedPasses && failedPasses.length > 0) {
        // Group by transcript_id, collect unique failed pass_keys
        const transcriptFailures = new Map<string, { passKeys: Set<string>; maxAttempt: number }>();
        
        for (const fp of failedPasses) {
          const existing = transcriptFailures.get(fp.transcript_id);
          if (existing) {
            existing.passKeys.add(fp.pass_key);
            existing.maxAttempt = Math.max(existing.maxAttempt, fp.retry_attempt);
          } else {
            transcriptFailures.set(fp.transcript_id, {
              passKeys: new Set([fp.pass_key]),
              maxAttempt: fp.retry_attempt,
            });
          }
        }

        // Filter: only retry if there's no subsequent 'completed' log for the same pass
        // and max retry_attempt < MAX_PASS_RETRIES
        const retryTargets: { transcriptId: string; passKeys: string[] }[] = [];

        for (const [transcriptId, info] of transcriptFailures.entries()) {
          if (info.maxAttempt >= MAX_PASS_RETRIES) continue;

          // Check which of these passes have already been completed (don't re-retry those)
          const { data: completedLogs } = await supabase
            .from('analysis_run_logs')
            .select('pass_key')
            .eq('transcript_id', transcriptId)
            .eq('status', 'completed')
            .in('pass_key', Array.from(info.passKeys));

          const completedKeys = new Set((completedLogs || []).map((l: any) => l.pass_key));
          const stillFailed = Array.from(info.passKeys).filter(k => !completedKeys.has(k));

          // Also check there's no currently running pass for this transcript
          const { data: runningLogs } = await supabase
            .from('analysis_run_logs')
            .select('id')
            .eq('transcript_id', transcriptId)
            .eq('status', 'running')
            .limit(1);

          if (stillFailed.length > 0 && (!runningLogs || runningLogs.length === 0)) {
            retryTargets.push({ transcriptId, passKeys: stillFailed });
          }
        }

        console.log(`[RetryEnrichment] Found ${retryTargets.length} transcripts with failed passes to auto-retry`);

        // Process up to 5 transcripts per cycle to avoid overloading
        const RETRY_BATCH = 5;
        for (const target of retryTargets.slice(0, RETRY_BATCH)) {
          try {
            // Fetch transcript content
            const { data: tr, error: trErr } = await supabase
              .from('transcript_reviews')
              .select('transcript_content, final_account_id, opportunity_id, is_encrypted')
              .eq('id', target.transcriptId)
              .maybeSingle();

            if (trErr || !tr) {
              console.error(`[RetryEnrichment] Cannot fetch transcript ${target.transcriptId}:`, trErr?.message);
              continue;
            }

            let content = tr.transcript_content;

            // If encrypted, decrypt via edge function
            if (tr.is_encrypted || !content) {
              try {
                const decryptResp = await fetch(`${supabaseUrl}/functions/v1/decrypt-transcript`, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${supabaseKey}`,
                  },
                  body: JSON.stringify({ transcriptId: target.transcriptId, tableName: 'transcript_reviews' }),
                });
                if (decryptResp.ok) {
                  const decryptData = await decryptResp.json();
                  content = decryptData.transcript || decryptData.content;
                }
              } catch (decErr) {
                console.error(`[RetryEnrichment] Decrypt failed for ${target.transcriptId}:`, decErr);
              }
            }

            if (!content?.trim()) {
              console.warn(`[RetryEnrichment] Empty transcript content for ${target.transcriptId}, skipping`);
              continue;
            }

            console.log(`[RetryEnrichment] Auto-retrying ${target.passKeys.join(', ')} for transcript ${target.transcriptId}`);

            // Fire the analysis with only the failed pass keys
            const analysisResp = await fetch(`${supabaseUrl}/functions/v1/unified-transcript-analysis`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${supabaseKey}`,
              },
              body: JSON.stringify({
                transcript: content.slice(0, 120000),
                transcriptReviewId: target.transcriptId,
                accountId: tr.final_account_id || undefined,
                opportunityId: tr.opportunity_id || undefined,
                retryPassKeys: target.passKeys,
                streaming: false,
              }),
            });

            if (analysisResp.ok) {
              passRetryCount++;
              console.log(`[RetryEnrichment] Successfully triggered retry for ${target.passKeys.join(', ')} on ${target.transcriptId}`);
            } else {
              const errText = await analysisResp.text().catch(() => '');
              console.error(`[RetryEnrichment] Retry failed for ${target.transcriptId}: ${analysisResp.status} ${errText.slice(0, 200)}`);
            }
            // Consume response body
            await analysisResp.text().catch(() => {});

            // Stagger between retries
            await new Promise(r => setTimeout(r, 2000));
          } catch (retryErr) {
            console.error(`[RetryEnrichment] Error retrying transcript ${target.transcriptId}:`, retryErr);
          }
        }
      }
    } catch (e) {
      console.error('[RetryEnrichment] Failed pass retry error:', e);
    }

    // ============================================================
    // PHASE 2b: PERMANENTLY-PENDING STAGE RECOVERY
    // Find transcripts that have at least one completed stage but are missing
    // log entries for other canonical stages (they were never started due to
    // edge function crashes or timeouts mid-pipeline)
    // ============================================================
    let pendingStageRetryCount = 0;
    const CANONICAL_PASS_KEYS = [
      'core_extraction', 'call_summary', 'stage_assessment',
      'enrichment_detection', 'enrichment_readiness',
      'account_synthesis', 'competitive_analysis', 'se_coaching'
    ];
    try {
      // Get transcripts that have at least one completed log in the last 24 hours
      const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const { data: recentCompleted, error: rcErr } = await supabase
        .from('analysis_run_logs')
        .select('transcript_id')
        .eq('status', 'completed')
        .gte('started_at', oneDayAgo)
        .order('started_at', { ascending: false })
        .limit(500);

      if (!rcErr && recentCompleted && recentCompleted.length > 0) {
        // Deduplicate transcript IDs
        const uniqueTranscriptIds = [...new Set(recentCompleted.map((l: any) => l.transcript_id))].slice(0, 50);

        for (const tid of uniqueTranscriptIds) {
          // Get all logs for this transcript
          const { data: allLogs } = await supabase
            .from('analysis_run_logs')
            .select('pass_key, status')
            .eq('transcript_id', tid);

          if (!allLogs || allLogs.length === 0) continue;

          // Check if core_extraction completed (prerequisite)
          const coreCompleted = allLogs.some((l: any) => 
            (l.pass_key === 'core_extraction' || l.pass_key === 'core_analysis') && l.status === 'completed'
          );
          if (!coreCompleted) continue;

          // Check if any stages are still running (skip if so)
          const hasRunning = allLogs.some((l: any) => l.status === 'running');
          if (hasRunning) continue;

          // Find which canonical stages have NO log entry at all
          const loggedKeys = new Set(allLogs.map((l: any) => l.pass_key));
          // Map aliases: enrichment_detection covers activity_detection
          const missingKeys = CANONICAL_PASS_KEYS.filter(k => {
            if (loggedKeys.has(k)) return false;
            // Check for skipped status too
            return true;
          });

          if (missingKeys.length > 0 && missingKeys.length < CANONICAL_PASS_KEYS.length) {
            // This transcript has gaps - trigger retry for missing stages
            console.log(`[RetryEnrichment] Transcript ${tid} has ${missingKeys.length} permanently-pending stages: ${missingKeys.join(', ')}`);

            // Fetch transcript and trigger retry (same logic as Phase 2)
            const { data: tr } = await supabase
              .from('transcript_reviews')
              .select('transcript_content, final_account_id, opportunity_id, is_encrypted')
              .eq('id', tid)
              .maybeSingle();

            if (!tr) continue;

            let content = tr.transcript_content;
            if (tr.is_encrypted || !content) {
              try {
                const decryptResp = await fetch(`${supabaseUrl}/functions/v1/decrypt-transcript`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${supabaseKey}` },
                  body: JSON.stringify({ transcriptId: tid, tableName: 'transcript_reviews' }),
                });
                if (decryptResp.ok) {
                  const decryptData = await decryptResp.json();
                  content = decryptData.transcript || decryptData.content;
                }
              } catch (decErr) {
                console.error(`[RetryEnrichment] Decrypt failed for pending recovery ${tid}:`, decErr);
              }
            }

            if (!content?.trim()) continue;

            const analysisResp = await fetch(`${supabaseUrl}/functions/v1/unified-transcript-analysis`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${supabaseKey}` },
              body: JSON.stringify({
                transcript: content.slice(0, 120000),
                transcriptReviewId: tid,
                accountId: tr.final_account_id || undefined,
                opportunityId: tr.opportunity_id || undefined,
                retryPassKeys: missingKeys,
                streaming: false,
              }),
            });

            if (analysisResp.ok) {
              pendingStageRetryCount++;
              console.log(`[RetryEnrichment] Successfully triggered pending-stage retry for ${missingKeys.join(', ')} on ${tid}`);
            } else {
              const errText = await analysisResp.text().catch(() => '');
              console.error(`[RetryEnrichment] Pending-stage retry failed for ${tid}: ${analysisResp.status} ${errText.slice(0, 200)}`);
            }
            await analysisResp.text().catch(() => {});
            await new Promise(r => setTimeout(r, 2000));

            // Limit to 3 transcripts per cycle
            if (pendingStageRetryCount >= 3) break;
          }
        }
      }
    } catch (e) {
      console.error('[RetryEnrichment] Pending stage recovery error:', e);
    }

    // ============================================================
    // PHASE 3: STUCK ENRICHMENT STATUS RECOVERY (original logic)
    // ============================================================

    // Parse batch size from request body (default 50, max 100)
    let batchSize = 50;
    try {
      const body = await req.json();
      if (body?.batchSize && typeof body.batchSize === 'number') {
        batchSize = Math.min(Math.max(body.batchSize, 1), 100);
      }
    } catch { /* no body is fine */ }

    // Find transcripts that are approved, linked to an opportunity, but enrichment is stuck
    const { data: stuckPending, error: pendingError } = await supabase
      .from("transcript_reviews")
      .select("id, file_name, meeting_title, opportunity_id, enrichment_retry_count")
      .eq("status", "approved")
      .not("opportunity_id", "is", null)
      .eq("enrichment_status", "pending")
      .lt("created_at", thirtyMinutesAgo)
      .order("created_at", { ascending: false })
      .limit(batchSize);

    // Catch in_progress records where enrichment_started_at is stale
    const { data: stuckInProgress, error: inProgressError } = await supabase
      .from("transcript_reviews")
      .select("id, file_name, meeting_title, opportunity_id, enrichment_retry_count")
      .eq("status", "approved")
      .not("opportunity_id", "is", null)
      .eq("enrichment_status", "in_progress")
      .or(`enrichment_started_at.lt.${thirtyMinutesAgo},enrichment_started_at.is.null`)
      .order("created_at", { ascending: false })
      .limit(batchSize);

    if (pendingError) console.error("[RetryEnrichment] Pending query error:", pendingError.message);
    if (inProgressError) console.error("[RetryEnrichment] InProgress query error:", inProgressError.message);

    const allStuck = [
      ...(stuckPending || []),
      ...(stuckInProgress || []),
    ];

    // Separate into retryable vs exhausted
    const retryable: typeof allStuck = [];
    const exhausted: typeof allStuck = [];

    for (const t of allStuck) {
      const retryCount = t.enrichment_retry_count ?? 0;
      if (retryCount >= MAX_RETRIES) {
        exhausted.push(t);
      } else {
        retryable.push(t);
      }
    }

    // Mark exhausted transcripts as 'failed' so they stop looping
    if (exhausted.length > 0) {
      const exhaustedIds = exhausted.map(t => t.id);
      console.log(`[RetryEnrichment] Marking ${exhausted.length} transcripts as 'failed' after ${MAX_RETRIES} retries`);
      await supabase
        .from("transcript_reviews")
        .update({
          enrichment_status: "failed",
          enrichment_error: `Exceeded ${MAX_RETRIES} retry attempts`,
        })
        .in("id", exhaustedIds);
    }

    if (retryable.length === 0 && passRetryCount === 0 && pendingStageRetryCount === 0) {
      console.log(`[RetryEnrichment] No retryable transcripts found (${exhausted.length} marked failed, ${stuckRecoveredCount} stuck logs recovered, ${passRetryCount} pass retries, ${pendingStageRetryCount} pending-stage recoveries)`);
      return new Response(
        JSON.stringify({ success: true, retriedCount: 0, failedCount: exhausted.length, stuckRecoveredCount, passRetryCount, pendingStageRetryCount }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[RetryEnrichment] Found ${retryable.length} retryable, ${exhausted.length} exhausted`);

    let retriedCount = 0;
    const CONCURRENCY = 5;

    // Process in parallel batches of CONCURRENCY
    for (let i = 0; i < retryable.length; i += CONCURRENCY) {
      const chunk = retryable.slice(i, i + CONCURRENCY);
      const results = await Promise.allSettled(chunk.map(async (transcript) => {
        const newRetryCount = (transcript.enrichment_retry_count ?? 0) + 1;

        // Reset enrichment status and increment retry count
        await supabase
          .from("transcript_reviews")
          .update({
            enrichment_status: "pending",
            enrichment_started_at: null,
            enrichment_retry_count: newRetryCount,
          })
          .eq("id", transcript.id);

        console.log(`[RetryEnrichment] Retry ${newRetryCount}/${MAX_RETRIES} for "${transcript.meeting_title || transcript.file_name}" (${transcript.id})`);

        const analysisResp = await fetch(`${supabaseUrl}/functions/v1/enrich-transcript`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${supabaseKey}`,
          },
          body: JSON.stringify({ transcriptReviewId: transcript.id }),
        });

        if (!analysisResp.ok) {
          const errText = await analysisResp.text();
          if (newRetryCount >= MAX_RETRIES) {
            await supabase
              .from("transcript_reviews")
              .update({
                enrichment_status: "failed",
                enrichment_error: errText.slice(0, 500),
              })
              .eq("id", transcript.id);
          }
          throw new Error(`${analysisResp.status}: ${errText.slice(0, 200)}`);
        }
        await analysisResp.text();
        console.log(`[RetryEnrichment] Successfully triggered enrichment for "${transcript.meeting_title || transcript.file_name}"`);
      }));

      for (const r of results) {
        if (r.status === 'fulfilled') retriedCount++;
        else console.error(`[RetryEnrichment] Chunk error:`, r.reason);
      }

      if (i + CONCURRENCY < retryable.length) {
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
    }

    console.log(`[RetryEnrichment] Completed: ${retriedCount}/${retryable.length} enrichment retried, ${exhausted.length} marked failed, ${stuckRecoveredCount} stuck logs recovered, ${passRetryCount} pass retries, ${pendingStageRetryCount} pending-stage recoveries`);

    return new Response(
      JSON.stringify({ success: true, retriedCount, totalRetryable: retryable.length, failedCount: exhausted.length, stuckRecoveredCount, passRetryCount, pendingStageRetryCount }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("[RetryEnrichment] Fatal error:", error.message || error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const data = encoder.encode(keyInput);
  const bytes = new Uint8Array(32);
  for (let i = 0; i < Math.min(data.length, 32); i++) bytes[i] = data[i];
  return bytes;
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function decryptValue(encrypted: string, cryptoKey: CryptoKey, iv: string): Promise<string> {
  try {
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: base64ToBytes(iv) },
      cryptoKey,
      base64ToBytes(encrypted)
    );
    return new TextDecoder().decode(decrypted);
  } catch {
    return '';
  }
}

interface SearchFilters {
  searchQuery?: string;
  attendeeFilter?: string;
  dateFrom?: string;
  dateTo?: string;
  myMeetingsOnly?: boolean;
  userEmail?: string;
  statuses?: string[];
  limit?: number;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const ENCRYPTION_KEY = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || '';

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const filters: SearchFilters = await req.json();
    const {
      searchQuery, attendeeFilter, dateFrom, dateTo,
      myMeetingsOnly, userEmail, statuses, limit = 500,
    } = filters;

    const cryptoKey = await crypto.subtle.importKey(
      'raw', deriveKeyBytes(ENCRYPTION_KEY), { name: 'AES-GCM' }, false, ['decrypt']
    );

    // Smaller pages = less CPU spike per iteration
    const PAGE_SIZE = 100;
    const maxResults = Math.min(limit, 500); // cap at 500, not 1000
    const HARD_CAP = 2000; // never scan more than 2000 rows total

    const results: any[] = [];
    let offset = 0;
    let totalFetched = 0;

    const searchQueryLower = searchQuery?.toLowerCase() || '';
    const attendeeFilterLower = attendeeFilter?.toLowerCase() || '';
    const userEmailLower = userEmail?.toLowerCase() || '';
    const needsTextSearch = !!(searchQueryLower || attendeeFilterLower || (myMeetingsOnly && userEmailLower));

    while (results.length < maxResults && totalFetched < HARD_CAP) {
      let query = supabase
        .from('momentum_meetings')
        .select(`
          id, title, title_encrypted,
          host_name, host_name_encrypted,
          host_email, host_email_encrypted,
          attendees, attendees_encrypted,
          start_time, end_time, status,
          matched_account_id, salesforce_account_id, salesforce_opportunity_id,
          is_encrypted, pii_encryption_iv
        `)
        .order('start_time', { ascending: false })
        .range(offset, offset + PAGE_SIZE - 1);

      if (statuses && statuses.length > 0) {
        query = statuses.length === 1
          ? query.eq('status', statuses[0])
          : query.in('status', statuses);
      } else {
        query = query.neq('status', 'imported');
      }

      if (dateFrom) query = query.gte('start_time', dateFrom);
      if (dateTo) {
        const endDate = new Date(dateTo);
        endDate.setHours(23, 59, 59, 999);
        query = query.lte('start_time', endDate.toISOString());
      }

      const { data: pageMeetings, error: fetchError } = await query;

      if (fetchError) {
        console.warn(`[search-meetings] DB error at offset ${offset}: ${fetchError.message}`);
        break;
      }
      if (!pageMeetings || pageMeetings.length === 0) break;

      totalFetched += pageMeetings.length;

      for (const meeting of pageMeetings) {
        if (results.length >= maxResults) break;

        let title = meeting.title;
        let hostName = meeting.host_name;
        let hostEmail = meeting.host_email;
        let attendees = meeting.attendees;

        // Only decrypt when the meeting is encrypted AND we need it
        if (meeting.is_encrypted && meeting.pii_encryption_iv) {
          const iv = meeting.pii_encryption_iv;

          // Always decrypt title (low cost, needed for output)
          if (meeting.title_encrypted) {
            title = await decryptValue(meeting.title_encrypted, cryptoKey, iv);
          }

          // Only decrypt host/attendees if we need them for filtering or output display
          if (needsTextSearch || !hostName) {
            if (meeting.host_name_encrypted) {
              hostName = await decryptValue(meeting.host_name_encrypted, cryptoKey, iv);
            }
            if (meeting.host_email_encrypted) {
              hostEmail = await decryptValue(meeting.host_email_encrypted, cryptoKey, iv);
            }
          }

          // Only decrypt attendees when needed for filtering/output
          if (needsTextSearch || !attendees) {
            if (meeting.attendees_encrypted) {
              const raw = await decryptValue(meeting.attendees_encrypted, cryptoKey, iv);
              try { attendees = JSON.parse(raw); } catch { attendees = []; }
            }
          }
        }

        const attendeeList = Array.isArray(attendees) ? attendees : [];
        const externalCount = attendeeList.filter((a: any) => !a.isInternal).length;

        // Skip internal-only meetings
        if (externalCount === 0) continue;

        // Apply text filters
        if (searchQueryLower) {
          const titleMatch = title?.toLowerCase().includes(searchQueryLower);
          const hostMatch = hostName?.toLowerCase().includes(searchQueryLower) ||
                            hostEmail?.toLowerCase().includes(searchQueryLower);
          if (!titleMatch && !hostMatch) continue;
        }

        if (attendeeFilterLower) {
          const names = attendeeList.map((a: any) => (a.name || a.email || '').toLowerCase());
          if (!names.some((n: string) => n.includes(attendeeFilterLower))) continue;
        }

        if (myMeetingsOnly && userEmailLower) {
          const isHost = hostEmail?.toLowerCase() === userEmailLower;
          const isAttendee = attendeeList.some((a: any) => a.email?.toLowerCase() === userEmailLower);
          if (!isHost && !isAttendee) continue;
        }

        results.push({
          meeting_id: meeting.id,
          title,
          host_name: hostName,
          host_email: hostEmail,
          attendee_names: attendeeList.map((a: any) => a.name || a.email),
          attendee_emails: attendeeList.map((a: any) => a.email).filter(Boolean),
          internal_attendee_count: attendeeList.filter((a: any) => a.isInternal).length,
          external_attendee_count: externalCount,
          start_time: meeting.start_time,
          end_time: meeting.end_time,
          status: meeting.status,
          matched_account_id: meeting.matched_account_id,
          salesforce_account_id: meeting.salesforce_account_id,
          salesforce_opportunity_id: meeting.salesforce_opportunity_id,
        });
      }

      if (pageMeetings.length < PAGE_SIZE) break;
      offset += PAGE_SIZE;
    }

    console.log(`[search-meetings] Scanned ${totalFetched}, returning ${results.length}`);

    return new Response(JSON.stringify({
      success: true,
      results,
      totalFetched,
      totalMatched: results.length,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[search-meetings] Fatal error:', error);
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

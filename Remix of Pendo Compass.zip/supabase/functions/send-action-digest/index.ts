import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

interface ActionItem {
  id: string;
  action: string | null;
  action_type: string | null;
  due_date: string | null;
  priority: string;
  status: string;
  account_name: string;
  account_id: string;
  opportunity_name: string | null;
  opportunity_id: string | null;
  assigned_to: string | null;
}

// Human-readable labels for action types
const ACTION_TYPE_LABELS: Record<string, string> = {
  follow_up_meeting: "Schedule follow-up meeting",
  send_content: "Send content/materials",
  poc_setup: "Set up POC",
  technical_deepdive: "Technical deep dive",
  security_assessment: "Security assessment",
  architecture_doc: "Architecture documentation",
  integration_review: "Integration review",
  api_exploration: "API exploration",
  performance_benchmark: "Performance benchmark",
  internal_discussion: "Internal discussion",
  follow_up: "Follow up",
};

function getActionDisplayText(action: string | null, actionType: string | null): string {
  if (action && action.trim()) return action;
  if (actionType && ACTION_TYPE_LABELS[actionType]) return ACTION_TYPE_LABELS[actionType];
  if (actionType) return actionType.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
  return "Action item";
}

interface TimelineItem {
  id: string;
  name: string;
  scheduled_date: string;
  status: string;
  phase: string;
  account_name: string;
  account_id: string;
  opportunity_name: string;
  opportunity_id: string;
}

interface AlertItem {
  id: string;
  rule_name: string;
  opportunity_name: string | null;
  opportunity_id: string;
  account_name: string;
  account_id: string;
  triggered_at: string;
  trigger_data: Record<string, any> | null;
}

interface GroupedActions {
  overdue: ActionItem[];
  dueToday: ActionItem[];
  upcoming: ActionItem[];
}

interface GroupedTimeline {
  overdue: TimelineItem[];
  dueToday: TimelineItem[];
  upcoming: TimelineItem[];
}

function parseDateOnly(d: string): Date {
  const dt = new Date(d);
  return new Date(dt.getFullYear(), dt.getMonth(), dt.getDate());
}

function groupActionsByUrgency(actions: ActionItem[]): GroupedActions {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);

  const overdue: ActionItem[] = [];
  const dueToday: ActionItem[] = [];
  const upcoming: ActionItem[] = [];

  actions.forEach((action) => {
    if (!action.due_date) {
      upcoming.push(action);
      return;
    }

    const dueOnly = parseDateOnly(action.due_date);

    if (dueOnly < today) overdue.push(action);
    else if (dueOnly.getTime() === today.getTime()) dueToday.push(action);
    else if (dueOnly <= weekFromNow) upcoming.push(action);
  });

  return { overdue, dueToday, upcoming };
}

function groupTimelineByUrgency(items: TimelineItem[]): GroupedTimeline {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);

  const overdue: TimelineItem[] = [];
  const dueToday: TimelineItem[] = [];
  const upcoming: TimelineItem[] = [];

  items.forEach((item) => {
    const dueOnly = parseDateOnly(item.scheduled_date);
    if (dueOnly < today) overdue.push(item);
    else if (dueOnly.getTime() === today.getTime()) dueToday.push(item);
    else if (dueOnly <= weekFromNow) upcoming.push(item);
  });

  return { overdue, dueToday, upcoming };
}

function groupByAccountAndOpportunity<T extends { account_id: string; opportunity_id: string | null }>(
  items: T[]
): Map<string, Map<string, T[]>> {
  const grouped = new Map<string, Map<string, T[]>>();

  items.forEach((item) => {
    const accountKey = item.account_id;
    if (!grouped.has(accountKey)) grouped.set(accountKey, new Map());

    const accountGroup = grouped.get(accountKey)!;
    const oppKey = item.opportunity_id || "no-opportunity";
    if (!accountGroup.has(oppKey)) accountGroup.set(oppKey, []);

    accountGroup.get(oppKey)!.push(item);
  });

  return grouped;
}

function formatDueDate(dueDate: string | null): { text: string; color: string } {
  if (!dueDate) return { text: "No due date", color: "#64748b" };

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const due = new Date(dueDate);
  const dueOnly = new Date(due.getFullYear(), due.getMonth(), due.getDate());
  const diffDays = Math.floor((dueOnly.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  const dateLabel = due.toLocaleDateString("en-US", { month: "short", day: "numeric" });

  if (diffDays < 0) {
    return { text: `${dateLabel} (${Math.abs(diffDays)}d overdue)`, color: "#ef4444" };
  }
  if (diffDays === 0) return { text: "Today", color: "#f59e0b" };
  if (diffDays === 1) return { text: "Tomorrow", color: "#16a34a" };
  return { text: dateLabel, color: "#16a34a" };
}

function getEdgeFunctionUrl(): string {
  const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
  // Extract project ref from URL like https://xyz.supabase.co
  const match = supabaseUrl.match(/https:\/\/([^.]+)\.supabase\.co/);
  const projectRef = match ? match[1] : "uxqugehmbqojblirttdy";
  return `https://${projectRef}.supabase.co/functions/v1/action-update`;
}

function button(href: string, label: string, bg: string, textColor: string, border?: string): string {
  const borderStyle = border ? `border:1px solid ${border};` : "";
  return `<a href="${href}" style="display:inline-block;padding:8px 14px;background:${bg};color:${textColor};text-decoration:none;border-radius:6px;font-size:13px;font-weight:600;${borderStyle}">${label}</a>`;
}

function mobileButton(href: string, icon: string, label: string, bg: string, textColor: string, border?: string): string {
  const borderStyle = border ? `border:1px solid ${border};` : "";
  return `
    <a href="${href}" style="display:inline-block;text-align:center;padding:10px 8px;background:${bg};color:${textColor};text-decoration:none;border-radius:8px;min-width:52px;${borderStyle}">
      <span style="display:block;font-size:18px;line-height:1;">${icon}</span>
      <span style="display:block;font-size:11px;font-weight:600;margin-top:4px;">${label}</span>
    </a>
  `;
}

function generateActionHtml(action: ActionItem, appUrl: string): string {
  const { text: dueText, color: dueColor } = formatDueDate(action.due_date);
  const fnUrl = getEdgeFunctionUrl();

  const doneUrl = `${fnUrl}?id=${action.id}&action=complete`;
  const cancelUrl = `${fnUrl}?id=${action.id}&action=cancel`;
  const delay1Url = `${fnUrl}?id=${action.id}&action=delay&days=1`;
  const delay2Url = `${fnUrl}?id=${action.id}&action=delay&days=2`;

  return `
    <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#ffffff;border-radius:8px;border:1px solid #e2e8f0;margin-bottom:8px;">
      <tr>
        <td style="padding:14px 16px;">
          <!-- Action text -->
          <p style="margin:0 0 6px 0;font-weight:600;color:#0f172a;font-size:15px;line-height:1.4;">${getActionDisplayText(action.action, action.action_type)}</p>
          <p style="margin:0 0 12px 0;font-size:13px;color:${dueColor};">Due: ${dueText}</p>
          <!-- Mobile-friendly button row -->
          <table cellpadding="0" cellspacing="0" border="0" width="100%">
            <tr>
              <td align="center" style="padding:0;">
                <table cellpadding="0" cellspacing="0" border="0">
                  <tr>
                    <td style="padding-right:8px;">
                      ${mobileButton(doneUrl, "✓", "Done", "#22c55e", "#ffffff")}
                    </td>
                    <td style="padding-right:8px;">
                      ${mobileButton(cancelUrl, "✕", "Skip", "#ef4444", "#ffffff")}
                    </td>
                    <td style="padding-right:8px;">
                      ${mobileButton(delay1Url, "⏱", "+1 Day", "#f1f5f9", "#475569", "#e2e8f0")}
                    </td>
                    <td>
                      ${mobileButton(delay2Url, "⏱", "+2 Days", "#f1f5f9", "#475569", "#e2e8f0")}
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  `;
}

function generateTimelineItemHtml(item: TimelineItem, appUrl: string): string {
  const { text: dueText, color: dueColor } = formatDueDate(item.scheduled_date);
  const fnUrl = getEdgeFunctionUrl();

  const doneUrl = `${fnUrl}?type=milestone&id=${item.id}&action=complete`;
  const inProgressUrl = `${fnUrl}?type=milestone&id=${item.id}&action=in_progress`;
  const skipUrl = `${fnUrl}?type=milestone&id=${item.id}&action=skip`;

  return `
    <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#ffffff;border-radius:8px;border:1px solid #e2e8f0;margin-bottom:8px;">
      <tr>
        <td style="padding:14px 16px;">
          <!-- Timeline item text -->
          <p style="margin:0 0 6px 0;font-weight:600;color:#0f172a;font-size:15px;line-height:1.4;">${item.name || "Timeline item"}</p>
          <p style="margin:0 0 12px 0;font-size:13px;color:${dueColor};">Target: ${dueText}</p>
          <!-- Mobile-friendly button row -->
          <table cellpadding="0" cellspacing="0" border="0" width="100%">
            <tr>
              <td align="center" style="padding:0;">
                <table cellpadding="0" cellspacing="0" border="0">
                  <tr>
                    <td style="padding-right:8px;">
                      ${mobileButton(doneUrl, "✓", "Done", "#22c55e", "#ffffff")}
                    </td>
                    <td style="padding-right:8px;">
                      ${mobileButton(inProgressUrl, "▶", "In Progress", "#0ea5e9", "#ffffff")}
                    </td>
                    <td>
                      ${mobileButton(skipUrl, "→", "Skip", "#f1f5f9", "#475569", "#e2e8f0")}
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  `;
}

// Map alert rule types/names to specific opportunity tabs for deep linking
function getAlertDeepLinkTab(ruleName: string, triggerData: Record<string, any> | null): string {
  const ruleNameLower = ruleName.toLowerCase();
  const ruleType = triggerData?.rule_type?.toLowerCase() || '';
  
  // Stakeholder-related alerts
  if (ruleNameLower.includes('champion') || 
      ruleNameLower.includes('economic buyer') || 
      ruleNameLower.includes('stakeholder') ||
      ruleType === 'missing_stakeholders') {
    return 'stakeholders';
  }
  
  // Signal-related alerts
  if (ruleNameLower.includes('signal') || 
      ruleNameLower.includes('detection') ||
      triggerData?.signalDetails) {
   return 'overview';
  }
  
  // Readiness alerts
  if (ruleNameLower.includes('readiness') || 
      ruleType === 'readiness_below_threshold' ||
      ruleType === 'stale_readiness' ||
      ruleType === 'unanswered_questions_count') {
    return 'readiness';
  }
  
  // Meeting/engagement alerts
  if (ruleNameLower.includes('meeting') || 
      ruleType === 'no_recent_meetings') {
    return 'transcripts';
  }
  
  // Default to overview
  return 'overview';
}

function formatSignalDetails(triggerData: Record<string, any> | null): string {
  if (!triggerData?.signalDetails || !Array.isArray(triggerData.signalDetails)) {
    return '';
  }
  
  const signals = triggerData.signalDetails.slice(0, 5); // Show max 5 signals
  if (signals.length === 0) return '';
  
  const signalRows = signals.map((s: any) => {
    const name = s.name || 'Unknown Signal';
    const date = s.detected_at 
      ? new Date(s.detected_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
      : '';
    return `<tr><td style="padding:4px 8px;font-size:12px;color:#334155;">• ${name}</td><td style="padding:4px 8px;font-size:12px;color:#64748b;">${date}</td></tr>`;
  }).join('');
  
  return `
    <table cellpadding="0" cellspacing="0" border="0" style="margin-top:8px;margin-bottom:4px;background:#f8fafc;border-radius:6px;width:100%;">
      <tr><td colspan="2" style="padding:8px 8px 4px;font-size:11px;font-weight:600;color:#64748b;text-transform:uppercase;">Detected Signals:</td></tr>
      ${signalRows}
    </table>
  `;
}

function getAlertButtonLabel(targetTab: string): string {
  switch (targetTab) {
    case 'stakeholders': return 'View Stakeholders →';
   case 'overview': return 'View Activity Timeline →';
    case 'readiness': return 'View Readiness →';
    case 'transcripts': return 'View Meetings →';
    default: return 'View Opportunity →';
  }
}

function generateAlertItemHtml(alert: AlertItem, appUrl: string): string {
  const triggeredDate = new Date(alert.triggered_at).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  // Determine which tab to link to based on alert type
  const targetTab = getAlertDeepLinkTab(alert.rule_name, alert.trigger_data);
  const oppLink = `${appUrl}/accounts/${alert.account_id}?opportunityId=${alert.opportunity_id}&oppTab=${targetTab}`;
  
  // Get signal details HTML if this is a signal alert
  const signalDetailsHtml = formatSignalDetails(alert.trigger_data);
  
  // Get the reason text for display
  const reasonText = alert.trigger_data?.reason || '';
  
  // Get contextual button label
  const buttonLabel = getAlertButtonLabel(targetTab);

  return `
    <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#ffffff;border-radius:8px;border:1px solid #e2e8f0;margin-bottom:8px;">
      <tr>
        <td style="padding:14px 16px;">
          <table cellpadding="0" cellspacing="0" border="0" width="100%">
            <tr>
              <td style="vertical-align:middle;">
                <p style="margin:0 0 4px 0;font-weight:600;color:#0f172a;font-size:15px;">🔔 ${alert.rule_name}</p>
                <p style="margin:0;font-size:13px;color:#64748b;">Triggered: ${triggeredDate}${reasonText ? ` — ${reasonText}` : ''}</p>
                ${signalDetailsHtml}
              </td>
              <td align="right" style="vertical-align:top;white-space:nowrap;padding-left:12px;">
                ${button(oppLink, buttonLabel, "#ec4899", "#ffffff")}
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  `;
}

function generateSectionHtml<T extends { account_id: string; opportunity_id: string | null; account_name: string; opportunity_name: string | null }>(
  title: string,
  icon: string,
  items: T[],
  bgColor: string,
  borderColor: string,
  baseUrl: string,
  renderItem: (item: T, baseUrl: string) => string
): string {
  if (items.length === 0) return "";

  const grouped = groupByAccountAndOpportunity(items);
  let html = `
    <table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:24px;">
      <tr>
        <td>
          <h2 style="color:#1e293b;font-size:16px;font-weight:700;margin:0 0 14px 0;">${icon} ${title} (${items.length})</h2>
        </td>
      </tr>
  `;

  grouped.forEach((opportunities, accountId) => {
    const firstItem = items.find((a) => a.account_id === accountId);
    const accountName = firstItem?.account_name || "Unknown Account";

    html += `
      <tr>
        <td style="padding-bottom:14px;">
          <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${bgColor};border:1px solid ${borderColor};border-radius:10px;">
            <tr>
              <td style="padding:16px;">
                <table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:12px;">
                  <tr>
                    <td>
                      <span style="font-weight:700;color:#1e293b;font-size:15px;">${accountName}</span>
                      <a href="${baseUrl}/accounts/${accountId}" style="color:#ec4899;font-size:13px;text-decoration:none;margin-left:12px;">View Account →</a>
                    </td>
                  </tr>
                </table>
    `;

    opportunities.forEach((oppItems, oppId) => {
      const oppName = oppItems[0]?.opportunity_name || "General";
      html += `
                <table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:8px;">
                  <tr>
                    <td style="padding-left:4px;padding-bottom:8px;">
                      <span style="font-size:13px;color:#64748b;font-weight:500;">${oppName}</span>
                    </td>
                  </tr>
                  <tr>
                    <td style="padding-left:8px;">
                      ${oppItems.map((it) => renderItem(it, baseUrl)).join("")}
                    </td>
                  </tr>
                </table>
      `;
    });

    html += `
              </td>
            </tr>
          </table>
        </td>
      </tr>
    `;
  });

  html += `</table>`;
  return html;
}

function generateEmailContent(actions: GroupedActions, timeline: GroupedTimeline, alerts: AlertItem[], baseUrl: string): string {
  let content = "";

  content += generateSectionHtml(
    "Overdue Actions",
    "⚠️",
    actions.overdue,
    "#fef2f2",
    "#fecaca",
    baseUrl,
    (a, u) => generateActionHtml(a, u)
  );

  content += generateSectionHtml(
    "Due Today",
    "📋",
    actions.dueToday,
    "#fffbeb",
    "#fde68a",
    baseUrl,
    (a, u) => generateActionHtml(a, u)
  );

  content += generateSectionHtml(
    "Upcoming This Week",
    "📅",
    actions.upcoming,
    "#f0fdf4",
    "#bbf7d0",
    baseUrl,
    (a, u) => generateActionHtml(a, u)
  );

  const timelineItems: (TimelineItem & { opportunity_name: string | null })[] = [
    ...timeline.overdue,
    ...timeline.dueToday,
    ...timeline.upcoming,
  ].map((t) => ({ ...t, opportunity_name: t.opportunity_name }));

  // Timeline sections (only if there are any)
  if (timelineItems.length > 0) {
    content += generateSectionHtml(
      "Timeline Tasks",
      "🗓",
      timelineItems,
      "#eff6ff",
      "#bfdbfe",
      baseUrl,
      (t, u) => generateTimelineItemHtml(t, u)
    );
  }

  // Alerts section (only if there are any)
  if (alerts.length > 0) {
    content += generateSectionHtml(
      "Recent Alerts",
      "🔔",
      alerts,
      "#fdf4ff",
      "#e9d5ff",
      baseUrl,
      (a, u) => generateAlertItemHtml(a, u)
    );
  }

  if (content === "") {
    content = `
      <div style="text-align:center;padding:40px;color:#64748b;">
        <p style="font-size:48px;margin:0;">🎉</p>
        <p style="font-size:18px;margin:16px 0 0 0;">You're all caught up!</p>
        <p style="margin:8px 0 0 0;">No pending actions at this time.</p>
      </div>
    `;
  }

  return content;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { userId, frequency } = await req.json();

    // Skip preference check for test emails
    if (frequency !== "test") {
      const { data: prefs } = await supabase
        .from("notification_preferences")
        .select("*")
        .eq("user_id", userId)
        .single();

      if (!prefs?.email_enabled) {
        return new Response(JSON.stringify({ success: false, reason: "Notifications disabled" }), {
          status: 200,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
      }
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("email, full_name")
      .eq("id", userId)
      .single();

    if (!profile?.email) throw new Error("User email not found");

    // -------------------------
    // 1) NBA action items
    // -------------------------
    const { data: actions, error: actionsError } = await supabase
      .from("account_nbas")
      .select(
        `
        id,
        action,
        action_type,
        due_date,
        priority,
        status,
        account_id,
        opportunity_id,
        assigned_to,
        accounts!inner(name),
        opportunities(name)
      `
      )
      .eq("assigned_to", profile.email)
      .in("status", ["pending", "in_progress"])
      .order("due_date", { ascending: true });

    if (actionsError) {
      console.error("Error fetching actions:", actionsError);
      throw actionsError;
    }

    const transformedActions: ActionItem[] = (actions || []).map((a: any) => ({
      id: a.id,
      action: a.action,
      action_type: a.action_type,
      due_date: a.due_date,
      priority: a.priority || "medium",
      status: a.status,
      account_name: a.accounts?.name || "Unknown Account",
      account_id: a.account_id,
      opportunity_name: a.opportunities?.name || null,
      opportunity_id: a.opportunity_id,
      assigned_to: a.assigned_to,
    }));

    // -------------------------
    // 2) Build team scope from user's personal alert rules
    // -------------------------
    // First, get user's personal alert rules to find team scope configuration
    const { data: userRules } = await supabase
      .from("opportunity_alert_rules")
      .select("threshold_config")
      .eq("owner_id", userId)
      .eq("is_active", true);

    // Extract team scope from rules - default to user-only unless explicitly configured
    let teamLeaderIds: string[] = [userId]; // Always include the user
    let includeMyTeam = false; // Default: only show user's own items
    let hasExplicitTeamScope = false;

    for (const rule of (userRules || [])) {
      const config = rule.threshold_config as any;
      if (config?.conditions?.teamScope) {
        hasExplicitTeamScope = true;
        const teamScope = config.conditions.teamScope;
        includeMyTeam = teamScope.includeMyTeam !== false;
        if (teamScope.additionalUserIds?.length) {
          teamLeaderIds = [...teamLeaderIds, ...teamScope.additionalUserIds];
        }
        break; // Use first rule with team scope
      }
    }

    // Dedupe leader IDs
    teamLeaderIds = [...new Set(teamLeaderIds)];
    console.log(`Team scope: ${teamLeaderIds.length} leaders, includeMyTeam: ${includeMyTeam}`);

    // Get all team member emails from the hierarchy for each leader
    const teamMemberEmails: Set<string> = new Set();
    teamMemberEmails.add(profile.email.toLowerCase()); // Always include the user

    // Only expand to team members if user has explicitly configured team scope
    if (hasExplicitTeamScope && includeMyTeam) {
      for (const leaderId of teamLeaderIds) {
        // Get leader's email
        const { data: leaderProfile } = await supabase
          .from("profiles")
          .select("email")
          .eq("id", leaderId)
          .single();
        
        if (leaderProfile?.email) {
          teamMemberEmails.add(leaderProfile.email.toLowerCase());
        }

        // Get team members using the database function
        const { data: teamMembers, error: teamErr } = await supabase
          .rpc("get_team_members", { _manager_id: leaderId });
        
        if (teamErr) {
          console.error(`Error fetching team for ${leaderId}:`, teamErr);
          continue;
        }

        // Get emails for all team members
        if (teamMembers?.length) {
          const memberIds = teamMembers.map((m: any) => m.user_id);
          const { data: memberProfiles } = await supabase
            .from("profiles")
            .select("email")
            .in("id", memberIds);
          
          (memberProfiles || []).forEach((p: any) => {
            if (p.email) teamMemberEmails.add(p.email.toLowerCase());
          });
        }
      }
    }

    console.log(`Found ${teamMemberEmails.size} team member emails for alert scope`);

    // Get opportunities where any team member is owner or SE
    const emailArray = Array.from(teamMemberEmails);
    const { data: ownedOpps, error: oppErr } = await supabase
      .from("opportunities")
      .select("id, name, account_id, accounts(name), owner_email, primary_se_email")
      .in("owner_email", emailArray);

    const { data: seOpps, error: seOppErr } = await supabase
      .from("opportunities")
      .select("id, name, account_id, accounts(name), owner_email, primary_se_email")
      .in("primary_se_email", emailArray);

    if (oppErr) {
      console.error("Error fetching owned opportunities:", oppErr);
      throw oppErr;
    }
    if (seOppErr) {
      console.error("Error fetching SE opportunities:", seOppErr);
      // Non-fatal, continue with owned opps
    }

    // Merge both lists (deduped by id)
    const oppMap = new Map<string, { opportunity_name: string; account_id: string; account_name: string }>();
    [...(ownedOpps || []), ...(seOpps || [])].forEach((o: any) => {
      if (!o?.id) return;
      if (!oppMap.has(o.id)) {
        oppMap.set(o.id, {
          opportunity_name: o.name || "Opportunity",
          account_id: o.account_id,
          account_name: o.accounts?.name || "Account",
        });
      }
    });

    console.log(`Found ${oppMap.size} opportunities in team scope`);

    const oppIds = Array.from(oppMap.keys());
    let timelineItems: TimelineItem[] = [];

    if (oppIds.length > 0) {
      // Batch opportunity IDs to avoid URL length limits (PostgREST .in() limit)
      const BATCH_SIZE = 100;
      const allMilestones: any[] = [];
      
      for (let i = 0; i < oppIds.length; i += BATCH_SIZE) {
        const batchIds = oppIds.slice(i, i + BATCH_SIZE);
        const { data: milestones, error: msErr } = await supabase
          .from("opportunity_milestones")
          .select("id, name, scheduled_date, status, phase, opportunity_id")
          .in("opportunity_id", batchIds)
          .not("scheduled_date", "is", null)
          .in("status", ["scheduled", "in_progress"])
          .order("scheduled_date", { ascending: true });

        if (msErr) {
          console.error(`Error fetching milestones batch ${i / BATCH_SIZE + 1}:`, msErr);
          // Continue with other batches instead of failing completely
          continue;
        }
        if (milestones) allMilestones.push(...milestones);
      }
      
      const milestones = allMilestones;

      timelineItems = (milestones || [])
        .map((m: any): TimelineItem | null => {
          const info = oppMap.get(m.opportunity_id);
          if (!info || !m.scheduled_date) return null;
          return {
            id: m.id,
            name: m.name || m.phase || "Milestone",
            scheduled_date: m.scheduled_date,
            status: m.status,
            phase: m.phase,
            account_id: info.account_id,
            account_name: info.account_name,
            opportunity_id: m.opportunity_id,
            opportunity_name: info.opportunity_name,
          };
        })
        .filter(Boolean) as TimelineItem[];
    }

    const groupedActions = groupActionsByUrgency(transformedActions);
    const groupedTimeline = groupTimelineByUrgency(timelineItems);

    // -------------------------
    // 3) Recent Alerts for user's opportunities (if notify_alerts is enabled)
    // -------------------------
    let alertItems: AlertItem[] = [];
    
    // Get user's notification preferences to check if alerts are enabled
    const { data: prefs } = await supabase
      .from("notification_preferences")
      .select("notify_alerts")
      .eq("user_id", userId)
      .maybeSingle();
    
    const shouldIncludeAlerts = prefs?.notify_alerts !== false; // Default to true if not set

    if (shouldIncludeAlerts && oppIds.length > 0) {
      // Get alerts from the last 24 hours (for daily digest) or 7 days (for weekly)
      const lookbackHours = frequency === 'weekly' ? 168 : 24;
      const lookbackDate = new Date(Date.now() - lookbackHours * 60 * 60 * 1000).toISOString();

      // Batch opportunity IDs to avoid URL length limits
      const ALERT_BATCH_SIZE = 100;
      const allAlerts: any[] = [];
      
      for (let i = 0; i < oppIds.length; i += ALERT_BATCH_SIZE) {
        const batchIds = oppIds.slice(i, i + ALERT_BATCH_SIZE);
        const { data: alerts, error: alertsErr } = await supabase
          .from("opportunity_alert_history")
          .select(`
            id,
            triggered_at,
            trigger_data,
            opportunity_id,
            opportunity_alert_rules!inner(name)
          `)
          .in("opportunity_id", batchIds)
          .gte("triggered_at", lookbackDate)
          .order("triggered_at", { ascending: false })
          .limit(20);

        if (alertsErr) {
          console.error(`Error fetching alerts batch ${i / ALERT_BATCH_SIZE + 1}:`, alertsErr);
          // Non-fatal - continue with other batches
        } else if (alerts) {
          allAlerts.push(...alerts);
        }
      }

      // Sort all alerts by triggered_at descending and limit to 20
      const sortedAlerts = allAlerts
        .sort((a, b) => new Date(b.triggered_at).getTime() - new Date(a.triggered_at).getTime())
        .slice(0, 20);

      alertItems = sortedAlerts.map((a: any): AlertItem => {
        const oppInfo = oppMap.get(a.opportunity_id);
        return {
          id: a.id,
          rule_name: a.opportunity_alert_rules?.name || "Alert",
          opportunity_name: oppInfo?.opportunity_name || "Opportunity",
          opportunity_id: a.opportunity_id,
          account_name: oppInfo?.account_name || "Account",
          account_id: oppInfo?.account_id || "",
          triggered_at: a.triggered_at,
          trigger_data: a.trigger_data,
        };
      });
    }

    const baseUrl = Deno.env.get("APP_URL") || "https://sependo.org";

    // -------------------------
    // 4) AI Situation Reports for active opportunities
    // -------------------------
    let situationReportHtml = "";
    if (oppIds.length > 0) {
      const SUMMARY_BATCH_SIZE = 100;
      const allSummaries: any[] = [];
      
      for (let i = 0; i < oppIds.length; i += SUMMARY_BATCH_SIZE) {
        const batchIds = oppIds.slice(i, i + SUMMARY_BATCH_SIZE);
        const { data: summaries } = await supabase
          .from("opportunity_summaries")
          .select("opportunity_id, one_liner, next_critical_action, generated_at")
          .in("opportunity_id", batchIds)
          .order("generated_at", { ascending: false });
        
        if (summaries) allSummaries.push(...summaries);
      }

      if (allSummaries.length > 0) {
        const summaryItems = allSummaries.map((s: any) => {
          const oppInfo = oppMap.get(s.opportunity_id);
          return { ...s, account_name: oppInfo?.account_name || "Account", account_id: oppInfo?.account_id || "", opportunity_name: oppInfo?.opportunity_name || "Opportunity" };
        });

        situationReportHtml = `
          <table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:24px;">
            <tr><td><h2 style="color:#1e293b;font-size:16px;font-weight:700;margin:0 0 14px 0;">🤖 AI Situation Reports (${summaryItems.length})</h2></td></tr>
        `;

        for (const item of summaryItems) {
          const oppLink = `${baseUrl}/accounts/${item.account_id}?opportunityId=${item.opportunity_id}&oppTab=overview`;
          situationReportHtml += `
            <tr><td style="padding-bottom:10px;">
              <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
                <tr><td style="padding:14px 16px;">
                  <p style="margin:0 0 4px 0;font-weight:600;color:#1e293b;font-size:14px;">
                    <a href="${oppLink}" style="color:#3b82f6;text-decoration:none;">${item.opportunity_name}</a>
                    <span style="color:#94a3b8;font-weight:400;font-size:12px;margin-left:8px;">${item.account_name}</span>
                  </p>
                  <p style="margin:0 0 6px 0;font-size:13px;color:#334155;line-height:1.5;">${item.one_liner}</p>
                  ${item.next_critical_action ? `<p style="margin:0;font-size:12px;color:#d97706;font-weight:600;">⚡ ${item.next_critical_action}</p>` : ''}
                </td></tr>
              </table>
            </td></tr>
          `;
        }
        situationReportHtml += `</table>`;
      }
    }

    if (
      transformedActions.length === 0 &&
      timelineItems.length === 0 &&
      alertItems.length === 0 &&
      situationReportHtml === "" &&
      frequency !== "test"
    ) {
      return new Response(JSON.stringify({ success: false, reason: "No pending items" }), {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Email template
    const { data: template } = await supabase
      .from("email_templates")
      .select("*")
      .eq("template_key", "action_digest")
      .eq("is_active", true)
      .single();

    if (!template) throw new Error("Email template not found");

    const content = generateEmailContent(groupedActions, groupedTimeline, alertItems, baseUrl) + situationReportHtml;

    const hour = new Date().getHours();
    let greeting = "Good morning";
    if (hour >= 12 && hour < 17) greeting = "Good afternoon";
    else if (hour >= 17) greeting = "Good evening";

    const userName = profile.full_name || profile.email.split("@")[0];
    greeting = `${greeting}, ${userName}!`;

    let html = template.html_template
      .replace(/{{greeting}}/g, greeting)
      .replace(/{{content}}/g, content)
      .replace(
        /{{date}}/g,
        new Date().toLocaleDateString("en-US", {
          weekday: "long",
          year: "numeric",
          month: "long",
          day: "numeric",
        })
      );

    const subject = template.subject.replace(
      /{{date}}/g,
      new Date().toLocaleDateString("en-US", {
        month: "long",
        day: "numeric",
        year: "numeric",
      })
    );

    console.log("Attempting to send email to:", profile.email, "Subject:", subject);
    console.log("Resend API key present:", !!Deno.env.get("RESEND_API_KEY"));
    
    const emailResponse = await resend.emails.send({
      from: "Pendo Compass <noreply@sependo.org>",
      to: [profile.email],
      subject,
      html,
    });

    console.log("Email sent successfully:", JSON.stringify(emailResponse));

    await supabase.from("email_log").insert({
      recipient_email: profile.email,
      recipient_user_id: userId,
      template_key: "action_digest",
      subject,
      resend_id: emailResponse.data?.id || null,
      status: "sent",
    });

    return new Response(JSON.stringify({ success: true, emailId: emailResponse.data?.id }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error in send-action-digest function:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  }
};

serve(handler);

import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

interface WeeklyKPI {
  label: string;
  value: number;
  previousValue: number;
  fourWeekAvg: number;
  unit?: string;
  trend: 'up' | 'down' | 'flat';
  trendIsPositive: boolean;
}

interface EvalPhaseCounts {
  planning: number;
  deploying: number;
  running: number;
  completed: number;
}

interface DealMovement {
  opportunityName: string;
  accountName: string;
  oldStage: string | null;
  newStage: string | null;
  value: number | null;
}

interface SummaryData {
  weekLabel: string;
  kpis: WeeklyKPI[];
  evalPhaseCounts: EvalPhaseCounts;
  dealMovements: DealMovement[];
  totalRevenueInMotion: number;
  topCoachingImprovers: { name: string; delta: number }[];
  situationReports?: { opportunityName: string; accountName: string; oneLiner: string; nextCriticalAction: string | null }[];
  bestCall?: {
    seEmail: string;
    overallScore: number;
    meetingDate: string | null;
    opportunityName: string | null;
    accountName: string | null;
    greatnessMoment: string | null;
    whatWorkedWell: string[];
    topDimensions: { name: string; score: number; evidence: string | null }[];
  } | null;
}

function buildEmailHtml(data: SummaryData): string {
  const kpiRows = data.kpis.map(kpi => {
    const delta = kpi.previousValue > 0
      ? Math.round(((kpi.value - kpi.previousValue) / kpi.previousValue) * 100)
      : kpi.value > 0 ? 100 : 0;
    const trendColor = kpi.trendIsPositive && kpi.trend === 'up' ? '#22c55e' :
      !kpi.trendIsPositive && kpi.trend === 'up' ? '#ef4444' :
      kpi.trendIsPositive && kpi.trend === 'down' ? '#ef4444' :
      '#22c55e';
    const arrow = kpi.trend === 'up' ? '↑' : kpi.trend === 'down' ? '↓' : '→';
    
    return `
      <td style="padding:12px 16px;text-align:center;border-right:1px solid #1e293b;">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#94a3b8;margin-bottom:4px;">${kpi.label}</div>
        <div style="font-size:28px;font-weight:700;color:#f8fafc;">${kpi.value}${kpi.unit || ''}</div>
        <div style="font-size:13px;color:${trendColor};font-weight:600;margin-top:2px;">${arrow} ${delta > 0 ? '+' : ''}${delta}% WoW</div>
        ${kpi.fourWeekAvg > 0 ? `<div style="font-size:11px;color:#64748b;margin-top:2px;">4wk avg: ${kpi.fourWeekAvg}${kpi.unit || ''}</div>` : ''}
      </td>
    `;
  }).join('');

  const evalTotal = data.evalPhaseCounts.planning + data.evalPhaseCounts.deploying + data.evalPhaseCounts.running + data.evalPhaseCounts.completed;
  
  const phases = [
    { label: 'Planning', count: data.evalPhaseCounts.planning, color: '#3b82f6' },
    { label: 'Deploying', count: data.evalPhaseCounts.deploying, color: '#f59e0b' },
    { label: 'Running', count: data.evalPhaseCounts.running, color: '#a855f7' },
    { label: 'Completed', count: data.evalPhaseCounts.completed, color: '#22c55e' },
  ];

  const evalBar = evalTotal > 0 ? phases.map(p => 
    p.count > 0 ? `<td style="background:${p.color};color:white;font-weight:700;font-size:14px;text-align:center;padding:8px 0;width:${(p.count / evalTotal) * 100}%;">${p.count}</td>` : ''
  ).join('') : '<td style="color:#64748b;padding:8px;text-align:center;">No active evaluations</td>';

  const dealRows = data.dealMovements.slice(0, 8).map(deal => `
    <tr>
      <td style="padding:8px 12px;border-bottom:1px solid #1e293b;">
        <div style="font-weight:600;color:#f8fafc;font-size:13px;">${deal.opportunityName}</div>
        <div style="color:#94a3b8;font-size:11px;">${deal.accountName}</div>
      </td>
      <td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:center;">
        <span style="color:#94a3b8;font-size:12px;">${deal.oldStage || '—'}</span>
        <span style="color:#64748b;margin:0 4px;">→</span>
        <span style="color:#3b82f6;font-weight:600;font-size:12px;">${deal.newStage || '—'}</span>
      </td>
      <td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;color:#f8fafc;font-weight:600;font-size:13px;">
        ${deal.value ? '$' + (deal.value / 1000).toFixed(0) + 'k' : '—'}
      </td>
    </tr>
  `).join('');

  const improverRows = data.topCoachingImprovers.map((imp, i) => `
    <tr>
      <td style="padding:6px 12px;border-bottom:1px solid #1e293b;">
        <span style="display:inline-block;width:24px;height:24px;border-radius:50%;background:${i === 0 ? '#f59e0b33' : '#1e293b'};color:${i === 0 ? '#f59e0b' : '#94a3b8'};text-align:center;line-height:24px;font-weight:700;font-size:12px;margin-right:8px;">${i + 1}</span>
        <span style="color:#f8fafc;font-size:13px;">${imp.name}</span>
      </td>
      <td style="padding:6px 12px;border-bottom:1px solid #1e293b;text-align:right;color:#22c55e;font-weight:600;font-size:13px;">↑ +${imp.delta} pts</td>
    </tr>
  `).join('');

  return `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>
<body style="margin:0;padding:0;background:#0f172a;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
  <div style="max-width:680px;margin:0 auto;padding:32px 16px;">
    
    <!-- Header -->
    <div style="text-align:center;padding:32px 0 24px;">
      <div style="font-size:13px;text-transform:uppercase;letter-spacing:2px;color:#3b82f6;font-weight:700;margin-bottom:8px;">YOUR WEEK IN REVIEW</div>
      <div style="font-size:22px;font-weight:700;color:#f8fafc;">${data.weekLabel}</div>
    </div>

    <!-- KPI Strip -->
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#1e293b;border-radius:12px;margin-bottom:24px;">
      <tr>${kpiRows}</tr>
    </table>

    <!-- Revenue & Eval Row -->
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
      <tr>
        <td width="40%" style="vertical-align:top;padding-right:12px;">
          <div style="background:linear-gradient(135deg,#1e293b,#0f172a);border:1px solid #334155;border-radius:12px;padding:24px;text-align:center;">
            <div style="font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#3b82f6;margin-bottom:8px;">Revenue in Motion</div>
            <div style="font-size:36px;font-weight:800;color:#f8fafc;">$${(data.totalRevenueInMotion / 1000).toFixed(0)}k</div>
            <div style="font-size:12px;color:#94a3b8;margin-top:4px;">${evalTotal} active evaluation${evalTotal !== 1 ? 's' : ''}</div>
          </div>
        </td>
        <td width="60%" style="vertical-align:top;padding-left:12px;">
          <div style="background:#1e293b;border:1px solid #334155;border-radius:12px;padding:24px;">
            <div style="font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#94a3b8;margin-bottom:12px;">Evaluation Pipeline</div>
            <table width="100%" cellpadding="0" cellspacing="0" style="border-radius:8px;overflow:hidden;">
              <tr>${evalBar}</tr>
            </table>
            <div style="margin-top:12px;">
              ${phases.map(p => `<span style="display:inline-block;margin-right:12px;font-size:11px;color:#94a3b8;"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${p.color};margin-right:4px;vertical-align:middle;"></span>${p.label}: <strong style="color:#f8fafc;">${p.count}</strong></span>`).join('')}
            </div>
          </div>
        </td>
      </tr>
    </table>

    <!-- Deal Movements -->
    ${data.dealMovements.length > 0 ? `
    <div style="background:#1e293b;border:1px solid #334155;border-radius:12px;padding:20px;margin-bottom:24px;">
      <div style="font-size:14px;font-weight:700;color:#f8fafc;margin-bottom:12px;">📊 Stage Movements</div>
      <table width="100%" cellpadding="0" cellspacing="0">
        ${dealRows}
      </table>
    </div>
    ` : ''}

    <!-- Coaching Improvers -->
    ${data.topCoachingImprovers.length > 0 ? `
    <div style="background:#1e293b;border:1px solid #334155;border-radius:12px;padding:20px;margin-bottom:24px;">
      <div style="font-size:14px;font-weight:700;color:#f8fafc;margin-bottom:12px;">🏆 Coaching Improvers</div>
      <table width="100%" cellpadding="0" cellspacing="0">
        ${improverRows}
      </table>
    </div>
    ` : ''}

    <!-- Best Call of the Period -->
    ${data.bestCall ? `
    <div style="background:#1e293b;border:1px solid #334155;border-radius:12px;padding:20px;margin-bottom:24px;">
      <div style="font-size:14px;font-weight:700;color:#f8fafc;margin-bottom:12px;">🏆 Best Call of the Period — ${data.bestCall.overallScore}/5</div>
      <div style="background:#0f172a;border:1px solid #334155;border-radius:8px;padding:14px;margin-bottom:8px;">
        <div style="margin-bottom:6px;">
          <span style="font-weight:600;color:#22c55e;font-size:13px;">${data.bestCall.seEmail}</span>
          ${data.bestCall.opportunityName ? `<span style="color:#94a3b8;font-size:12px;margin-left:8px;">${data.bestCall.opportunityName}${data.bestCall.accountName ? ` (${data.bestCall.accountName})` : ''}</span>` : ''}
          ${data.bestCall.meetingDate ? `<span style="color:#64748b;font-size:11px;float:right;">${new Date(data.bestCall.meetingDate).toLocaleDateString('en-GB', { month: 'short', day: 'numeric' })}</span>` : ''}
        </div>
        ${data.bestCall.greatnessMoment ? `
          <div style="background:#1e293b;border-left:3px solid #22c55e;padding:10px 12px;border-radius:4px;margin:8px 0;">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#22c55e;margin-bottom:4px;">Standout Moment</div>
            <p style="margin:0;font-size:13px;color:#cbd5e1;font-style:italic;line-height:1.5;">"${data.bestCall.greatnessMoment}"</p>
          </div>
        ` : ''}
        ${data.bestCall.topDimensions.length > 0 ? `
          <div style="margin-top:10px;">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#94a3b8;margin-bottom:6px;">Top Dimensions</div>
            ${data.bestCall.topDimensions.map(d => `
              <div style="display:inline-block;background:#1e293b;border:1px solid #334155;border-radius:6px;padding:6px 10px;margin:2px 4px 2px 0;">
                <span style="color:#f8fafc;font-size:12px;font-weight:600;">${d.name}</span>
                <span style="color:#22c55e;font-size:12px;font-weight:700;margin-left:6px;">${d.score}/5</span>
              </div>
            `).join('')}
          </div>
        ` : ''}
        ${data.bestCall.whatWorkedWell.length > 0 ? `
          <div style="margin-top:10px;">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#94a3b8;margin-bottom:6px;">✨ Replicable Techniques</div>
            ${data.bestCall.whatWorkedWell.map(item => `
              <div style="padding:4px 0;font-size:13px;color:#cbd5e1;line-height:1.4;">
                <span style="color:#22c55e;margin-right:6px;">✓</span>${item}
              </div>
            `).join('')}
          </div>
        ` : ''}
      </div>
    </div>
    ` : ''}

    <!-- AI Situation Reports -->
    ${(data.situationReports && data.situationReports.length > 0) ? `
    <div style="background:#1e293b;border:1px solid #334155;border-radius:12px;padding:20px;margin-bottom:24px;">
      <div style="font-size:14px;font-weight:700;color:#f8fafc;margin-bottom:12px;">🤖 Deal Situation Reports (${data.situationReports.length})</div>
      ${data.situationReports.map(r => `
        <div style="background:#0f172a;border:1px solid #334155;border-radius:8px;padding:14px;margin-bottom:8px;">
          <div style="margin-bottom:4px;">
            <span style="font-weight:600;color:#3b82f6;font-size:13px;">${r.opportunityName}</span>
            <span style="color:#64748b;font-size:11px;margin-left:8px;">${r.accountName}</span>
          </div>
          <p style="margin:0 0 4px 0;font-size:13px;color:#cbd5e1;line-height:1.5;">${r.oneLiner}</p>
          ${r.nextCriticalAction ? `<p style="margin:0;font-size:12px;color:#f59e0b;font-weight:600;">⚡ ${r.nextCriticalAction}</p>` : ''}
        </div>
      `).join('')}
    </div>
    ` : ''}

    <!-- Footer -->
    <div style="text-align:center;padding:16px 0;color:#475569;font-size:11px;">
      Generated by Pendo Compass · ${new Date().toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
    </div>
  </div>
</body>
</html>`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { recipientEmail, summaryData } = await req.json();

    if (!recipientEmail || !summaryData) {
      return new Response(JSON.stringify({ error: "Missing recipientEmail or summaryData" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const html = buildEmailHtml(summaryData);

    const emailResponse = await resend.emails.send({
      from: "Pendo Compass <noreply@sependo.org>",
      to: [recipientEmail],
      subject: `📊 Your Week in Review – ${summaryData.weekLabel}`,
      html,
    });

    // Log the email
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    await supabase.from("email_log").insert({
      recipient_email: recipientEmail,
      template_key: "exec_weekly_summary",
      subject: `📊 Your Week in Review – ${summaryData.weekLabel}`,
      resend_id: emailResponse.data?.id || null,
      status: "sent",
    });

    return new Response(JSON.stringify({ success: true, id: emailResponse.data?.id }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error sending exec summary:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

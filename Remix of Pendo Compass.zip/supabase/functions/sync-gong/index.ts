import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Encryption helpers (shared with sync-momentum)
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const data = encoder.encode(keyInput);
  const bytes = new Uint8Array(32);
  for (let i = 0; i < Math.min(data.length, 32); i++) {
    bytes[i] = data[i];
  }
  return bytes;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

async function encryptValueWithIv(plaintext: string, encryptionKey: string, ivBytes: Uint8Array): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plaintext);
  const keyBytes = deriveKeyBytes(encryptionKey);
  const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['encrypt']);
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: ivBytes.buffer as ArrayBuffer }, key, data);
  return bytesToBase64(new Uint8Array(encrypted));
}

async function encryptMeetingFields(data: Record<string, any>, encryptionKey: string): Promise<Record<string, any>> {
  const fieldsToEncrypt = ['title', 'host_email', 'host_name', 'attendees', 'transcript_content'];
  const result: Record<string, any> = { ...data };
  const ivBytes = crypto.getRandomValues(new Uint8Array(12));
  const ivBase64 = bytesToBase64(ivBytes);
  let hasEncryptedFields = false;

  for (const field of fieldsToEncrypt) {
    if (data[field] !== undefined && data[field] !== null) {
      const plaintext = typeof data[field] === 'object' ? JSON.stringify(data[field]) : String(data[field]);
      result[`${field}_encrypted`] = await encryptValueWithIv(plaintext, encryptionKey, ivBytes);
      result[field] = null;
      hasEncryptedFields = true;
    }
  }

  if (hasEncryptedFields) {
    result.pii_encryption_iv = ivBase64;
    result.is_encrypted = true;
  }

  return result;
}

interface GongCall {
  id: string;
  title: string;
  started: string;
  duration: number;
  primaryUserId?: string;
  parties: Array<{
    emailAddress?: string;
    name?: string;
    userId?: string;
    affiliation?: 'INTERNAL' | 'EXTERNAL' | 'UNKNOWN';
    speakerId?: string;
  }>;
  media?: { audioUrl?: string };
  scope?: string;
  direction?: string;
  crmAssociations?: Array<{
    objectType: string;
    objectId: string;
  }>;
}

interface GongTranscriptEntry {
  speakerId: string;
  topic?: string;
  sentences: Array<{
    start: number;
    end: number;
    text: string;
  }>;
}

// Gong API client
class GongApiClient {
  private baseUrl: string;
  private authHeader: string;

  constructor(accessKey: string, accessKeySecret: string, baseUrl = 'https://api.gong.io') {
    this.baseUrl = baseUrl;
    this.authHeader = 'Basic ' + btoa(`${accessKey}:${accessKeySecret}`);
  }

  private async request(path: string, options: RequestInit = {}): Promise<any> {
    const url = `${this.baseUrl}${path}`;
    const response = await fetch(url, {
      ...options,
      headers: {
        'Authorization': this.authHeader,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`Gong API error [${response.status}]: ${body}`);
    }

    return response.json();
  }

  async listCalls(fromDateTime: string, toDateTime: string, cursor?: string): Promise<{ calls: GongCall[], cursor?: string }> {
    const params = new URLSearchParams({
      fromDateTime,
      toDateTime,
    });
    if (cursor) params.set('cursor', cursor);

    const data = await this.request(`/v2/calls?${params.toString()}`);
    return {
      calls: data.calls || [],
      cursor: data.records?.cursor,
    };
  }

  async getCallsExtensive(callIds: string[]): Promise<any[]> {
    if (callIds.length === 0) return [];
    const data = await this.request('/v2/calls/extensive', {
      method: 'POST',
      body: JSON.stringify({
        filter: { callIds },
        contentSelector: {
          exposedFields: {
            parties: true,
            content: { trackers: false },
            collaboration: { publicComments: false },
          },
        },
      }),
    });
    return data.calls || [];
  }

  async getTranscripts(callIds: string[]): Promise<Map<string, GongTranscriptEntry[]>> {
    if (callIds.length === 0) return new Map();
    const data = await this.request('/v2/calls/transcript', {
      method: 'POST',
      body: JSON.stringify({
        filter: { callIds },
      }),
    });

    const map = new Map<string, GongTranscriptEntry[]>();
    for (const entry of (data.callTranscripts || [])) {
      map.set(entry.callId, entry.transcript || []);
    }
    return map;
  }

  async getActivityStats(fromDateTime: string, toDateTime: string): Promise<any[]> {
    const data = await this.request('/v2/stats/activity', {
      method: 'POST',
      body: JSON.stringify({
        filter: { fromDateTime, toDateTime },
      }),
    });
    return data.stats || [];
  }
}

// Convert Gong speaker-diarized transcript to plain text
function convertGongTranscript(
  entries: GongTranscriptEntry[],
  parties: GongCall['parties']
): string {
  const speakerMap = new Map<string, string>();
  for (const party of parties) {
    if (party.speakerId) {
      speakerMap.set(party.speakerId, party.name || party.emailAddress || 'Unknown');
    }
  }

  const lines: string[] = [];
  for (const entry of entries) {
    const speakerName = speakerMap.get(entry.speakerId) || `Speaker ${entry.speakerId}`;
    for (const sentence of entry.sentences) {
      const timestamp = formatTimestamp(sentence.start);
      lines.push(`[${timestamp}] ${speakerName}: ${sentence.text}`);
    }
  }
  return lines.join('\n');
}

function formatTimestamp(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, serviceRoleKey);

  // Try env vars first, then fall back to data_integrations config
  let gongAccessKey = Deno.env.get('GONG_ACCESS_KEY');
  let gongAccessSecret = Deno.env.get('GONG_ACCESS_KEY_SECRET');
  const gongBaseUrl = Deno.env.get('GONG_BASE_URL') || 'https://api.gong.io';
  const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');

  // Fall back to credentials stored in data_integrations config
  if (!gongAccessKey || !gongAccessSecret) {
    const { data: integrationConfig } = await supabase
      .from('data_integrations')
      .select('config')
      .eq('provider', 'gong')
      .maybeSingle();
    
    if (integrationConfig?.config) {
      const cfg = integrationConfig.config as any;
      gongAccessKey = gongAccessKey || cfg.access_key;
      gongAccessSecret = gongAccessSecret || cfg.access_key_secret;
    }
  }

  if (!gongAccessKey || !gongAccessSecret) {
    return new Response(JSON.stringify({ 
      error: 'Gong API credentials not configured. Add them via Settings → Integrations or set GONG_ACCESS_KEY and GONG_ACCESS_KEY_SECRET.' 
    }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }

  try {
    const url = new URL(req.url);
    const fullSync = url.searchParams.get('fullSync') === 'true';

    // Get integration state
    const { data: integration } = await supabase
      .from('data_integrations')
      .select('*')
      .eq('provider', 'gong')
      .maybeSingle();

    if (!integration?.is_enabled) {
      return new Response(JSON.stringify({ message: 'Gong integration is disabled' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Update sync status
    await supabase
      .from('data_integrations')
      .update({ last_sync_status: 'syncing', updated_at: new Date().toISOString() })
      .eq('provider', 'gong');

    const gong = new GongApiClient(gongAccessKey, gongAccessSecret, gongBaseUrl);

    // Determine time range
    const now = new Date();
    let fromDate: Date;
    if (fullSync) {
      fromDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000); // 30 days
    } else if (integration?.cursor_state?.lastSyncedCallDate) {
      fromDate = new Date(integration.cursor_state.lastSyncedCallDate);
    } else {
      fromDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000); // 7 days default
    }

    console.log(`[sync-gong] Syncing calls from ${fromDate.toISOString()} to ${now.toISOString()}`);

    // Fetch all calls with pagination
    const allCalls: GongCall[] = [];
    let cursor: string | undefined;
    do {
      const result = await gong.listCalls(fromDate.toISOString(), now.toISOString(), cursor);
      allCalls.push(...result.calls);
      cursor = result.cursor;
    } while (cursor);

    console.log(`[sync-gong] Found ${allCalls.length} calls`);

    if (allCalls.length === 0) {
      await supabase
        .from('data_integrations')
        .update({ 
          last_sync_at: now.toISOString(),
          last_sync_status: 'success',
          last_sync_meetings_count: 0,
          updated_at: now.toISOString(),
        })
        .eq('provider', 'gong');

      return new Response(JSON.stringify({ newMeetings: 0, message: 'No new calls found' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Check which calls are already imported
    const gongCallIds = allCalls.map(c => c.id);
    const { data: existingMeetings } = await supabase
      .from('momentum_meetings')
      .select('momentum_id')
      .eq('source', 'gong')
      .in('momentum_id', gongCallIds);

    const existingIds = new Set((existingMeetings || []).map((m: any) => m.momentum_id));
    const newCalls = allCalls.filter(c => !existingIds.has(c.id));

    console.log(`[sync-gong] ${newCalls.length} new calls to import (${existingIds.size} already exist)`);

    if (newCalls.length === 0) {
      await supabase
        .from('data_integrations')
        .update({ 
          last_sync_at: now.toISOString(),
          last_sync_status: 'success',
          last_sync_meetings_count: 0,
          cursor_state: { lastSyncedCallDate: now.toISOString() },
          updated_at: now.toISOString(),
        })
        .eq('provider', 'gong');

      return new Response(JSON.stringify({ newMeetings: 0, message: 'All calls already synced' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Fetch transcripts and extended data in batches
    const BATCH_SIZE = 20;
    let totalImported = 0;

    // Fetch accounts for matching
    const { data: accounts } = await supabase
      .from('accounts')
      .select('id, name, salesforce_account_id, auto_import_transcripts');

    const accountsBySfId = new Map<string, any>();
    const accountsByName = new Map<string, any>();
    for (const acc of (accounts || [])) {
      if (acc.salesforce_account_id) {
        accountsBySfId.set(acc.salesforce_account_id, acc);
      }
      accountsByName.set(acc.name.toLowerCase(), acc);
    }

    for (let i = 0; i < newCalls.length; i += BATCH_SIZE) {
      const batch = newCalls.slice(i, i + BATCH_SIZE);
      const batchIds = batch.map(c => c.id);

      // Fetch extensive data and transcripts in parallel
      const [extensiveData, transcriptMap] = await Promise.all([
        gong.getCallsExtensive(batchIds),
        gong.getTranscripts(batchIds),
      ]);

      // Build extensive lookup
      const extensiveMap = new Map<string, any>();
      for (const ext of extensiveData) {
        extensiveMap.set(ext.metaData?.id || ext.id, ext);
      }

      for (const call of batch) {
        try {
          const extensive = extensiveMap.get(call.id);
          const transcriptEntries = transcriptMap.get(call.id) || [];

          // Extract parties/attendees
          const parties = extensive?.parties || call.parties || [];
          const attendees = parties.map((p: any) => ({
            name: p.name || '',
            email: p.emailAddress || '',
            isInternal: p.affiliation === 'INTERNAL',
          }));

          // Find host (primary user / internal party)
          const host = parties.find((p: any) => p.userId === call.primaryUserId) || 
                       parties.find((p: any) => p.affiliation === 'INTERNAL') || 
                       parties[0];

          // Convert transcript
          const transcriptContent = convertGongTranscript(transcriptEntries, parties);

          // Extract CRM associations
          const crmAssociations = extensive?.metaData?.crmAssociations || [];
          const sfAccountId = crmAssociations.find((a: any) => a.objectType === 'ACCOUNT')?.objectId || null;
          const sfOpportunityId = crmAssociations.find((a: any) => a.objectType === 'OPPORTUNITY')?.objectId || null;

          // Match account
          let matchedAccountId: string | null = null;
          if (sfAccountId && accountsBySfId.has(sfAccountId)) {
            matchedAccountId = accountsBySfId.get(sfAccountId).id;
          } else {
            // Try matching by external attendee domain
            const externalEmails = attendees
              .filter((a: any) => !a.isInternal && a.email)
              .map((a: any) => a.email.split('@')[1]?.toLowerCase())
              .filter(Boolean);

            for (const domain of externalEmails) {
              const domainName = domain.split('.')[0];
              const match = accountsByName.get(domainName);
              if (match) {
                matchedAccountId = match.id;
                break;
              }
            }
          }

          // Build meeting record
          const endTime = new Date(new Date(call.started).getTime() + (call.duration || 0) * 1000).toISOString();

          let meetingData: Record<string, any> = {
            momentum_id: call.id,
            title: call.title || 'Gong Call',
            start_time: call.started,
            end_time: endTime,
            host_email: host?.emailAddress || null,
            host_name: host?.name || null,
            attendees: attendees,
            transcript_content: transcriptContent || null,
            salesforce_account_id: sfAccountId,
            salesforce_opportunity_id: sfOpportunityId,
            status: 'pending',
            matched_account_id: matchedAccountId,
            source: 'gong',
            meeting_context: 'imported',
          };

          // Encrypt if key is available
          if (encryptionKey) {
            meetingData = await encryptMeetingFields(meetingData, encryptionKey);
          }

          const { error: insertError } = await supabase
            .from('momentum_meetings')
            .insert(meetingData as any);

          if (insertError) {
            // Check for duplicate key (already exists)
            if (insertError.message?.includes('duplicate') || insertError.message?.includes('unique')) {
              console.log(`[sync-gong] Call ${call.id} already exists, skipping`);
            } else {
              console.error(`[sync-gong] Failed to insert call ${call.id}:`, insertError.message);
            }
          } else {
            totalImported++;
          }
        } catch (callErr) {
          console.error(`[sync-gong] Error processing call ${call.id}:`, callErr);
        }
      }

      // Rate limiting - Gong allows 3 req/sec, be conservative
      if (i + BATCH_SIZE < newCalls.length) {
        await new Promise(r => setTimeout(r, 2000));
      }
    }

    // Update integration state
    const latestCallDate = newCalls.reduce((latest, c) => {
      const d = new Date(c.started);
      return d > latest ? d : latest;
    }, fromDate);

    await supabase
      .from('data_integrations')
      .update({
        last_sync_at: now.toISOString(),
        last_sync_status: 'success',
        last_sync_meetings_count: totalImported,
        cursor_state: { lastSyncedCallDate: latestCallDate.toISOString() },
        updated_at: now.toISOString(),
      })
      .eq('provider', 'gong');

    console.log(`[sync-gong] Successfully imported ${totalImported} calls`);

    return new Response(JSON.stringify({
      newMeetings: totalImported,
      totalCalls: allCalls.length,
      alreadyExisting: existingIds.size,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[sync-gong] Sync failed:', error);

    await supabase
      .from('data_integrations')
      .update({
        last_sync_status: 'error',
        last_sync_error: error instanceof Error ? error.message : String(error),
        updated_at: new Date().toISOString(),
      })
      .eq('provider', 'gong');

    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Sync failed' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

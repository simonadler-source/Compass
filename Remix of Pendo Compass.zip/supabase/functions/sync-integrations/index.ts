import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

/**
 * Cron-triggered edge function that checks all active data integrations
 * and triggers their respective sync functions if polling interval has elapsed.
 */
serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, serviceRoleKey);

  try {
    // Fetch all enabled integrations
    const { data: integrations, error } = await supabase
      .from('data_integrations')
      .select('*')
      .eq('is_enabled', true);

    if (error) throw error;
    if (!integrations || integrations.length === 0) {
      return new Response(JSON.stringify({ message: 'No active integrations' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const now = new Date();
    const triggered: string[] = [];
    const skipped: string[] = [];

    for (const integration of integrations) {
      const lastSync = integration.last_sync_at ? new Date(integration.last_sync_at) : null;
      const intervalMs = (integration.polling_interval_minutes || 60) * 60 * 1000;
      const elapsed = lastSync ? now.getTime() - lastSync.getTime() : Infinity;

      // Skip if not enough time has passed and last sync was successful
      if (elapsed < intervalMs && integration.last_sync_status !== 'error') {
        skipped.push(integration.provider);
        continue;
      }

      // Skip if currently syncing (prevent overlaps)
      if (integration.last_sync_status === 'syncing') {
        // But check if it's stuck (> 10 minutes)
        const stuckThreshold = 10 * 60 * 1000;
        if (lastSync && (now.getTime() - lastSync.getTime()) < stuckThreshold) {
          skipped.push(`${integration.provider} (syncing)`);
          continue;
        }
        // Stuck sync - reset and retry
        console.warn(`[sync-integrations] ${integration.provider} appears stuck, resetting`);
      }

      // Map provider to sync function
      const syncFunctionMap: Record<string, string> = {
        'momentum': 'sync-momentum',
        'gong': 'sync-gong',
        'slack': 'ingest-competitive-slack',
      };

      const functionName = syncFunctionMap[integration.provider];
      if (!functionName) {
        console.warn(`[sync-integrations] No sync function mapped for provider: ${integration.provider}`);
        skipped.push(`${integration.provider} (unmapped)`);
        continue;
      }

      // Fire-and-forget: trigger the sync function
      console.log(`[sync-integrations] Triggering ${functionName} for ${integration.provider}`);

      try {
        const syncUrl = `${supabaseUrl}/functions/v1/${functionName}`;
        
        if (integration.provider === 'slack') {
          // Slack: trigger per-channel
          const channels = (integration.config as any)?.channels || [];
          for (const ch of channels) {
            fetch(syncUrl, {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ triggered_by: 'cron', channelId: ch.id, channelPurpose: ch.purpose || 'competitive', linkedAccountId: ch.linked_account_id, linkedOpportunityId: ch.linked_opportunity_id, lookbackHours: 4 }),
            }).catch(err => {
              console.error(`[sync-integrations] Background trigger for ${functionName} channel ${ch.id} failed:`, err);
            });
          }
        } else {
          fetch(syncUrl, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${serviceRoleKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ triggered_by: 'cron' }),
          }).catch(err => {
            console.error(`[sync-integrations] Background trigger for ${functionName} failed:`, err);
          });
        }

        triggered.push(integration.provider);
      } catch (triggerErr) {
        console.error(`[sync-integrations] Failed to trigger ${functionName}:`, triggerErr);
      }
    }

    return new Response(JSON.stringify({
      triggered,
      skipped,
      total: integrations.length,
      timestamp: now.toISOString(),
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[sync-integrations] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Semantic similarity helper for deduplication - OPTIMIZED
// Pre-compute word sets for existing use cases to avoid O(n²) recomputation
function normalizeToWords(text: string): Set<string> {
  return new Set(
    text.toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 2)
  );
}

function computeWordSimilarityOptimized(words1: Set<string>, words2: Set<string>): number {
  if (words1.size === 0 || words2.size === 0) return 0;
  let matches = 0;
  for (const w of words1) {
    if (words2.has(w)) matches++;
  }
  return matches / Math.min(words1.size, words2.size);
}

// Pre-computed word sets for faster lookups
interface UseCaseWordCache {
  text: string;
  words: Set<string>;
}

function findSimilarUseCaseFast(newText: string, existingCache: UseCaseWordCache[], threshold = 0.6): string | null {
  const newWords = normalizeToWords(newText);
  for (const existing of existingCache) {
    if (computeWordSimilarityOptimized(newWords, existing.words) >= threshold) {
      return existing.text;
    }
  }
  return null;
}

// Encryption helpers
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const data = encoder.encode(keyInput);
  const bytes = new Uint8Array(32);
  for (let i = 0; i < Math.min(data.length, 32); i++) {
    bytes[i] = data[i];
  }
  return bytes;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function encryptValueWithIv(plaintext: string, encryptionKey: string, ivBytes: Uint8Array): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plaintext);
  const keyBytes = deriveKeyBytes(encryptionKey);
  const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['encrypt']);
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: ivBytes.buffer as ArrayBuffer }, key, data);
  return bytesToBase64(new Uint8Array(encrypted));
}

async function decryptValue(ciphertext: string, encryptionKey: string, ivBase64: string): Promise<string> {
  try {
    const keyBytes = deriveKeyBytes(encryptionKey);
    const key = await crypto.subtle.importKey('raw', keyBytes.buffer as ArrayBuffer, { name: 'AES-GCM' }, false, ['decrypt']);
    const iv = base64ToBytes(ivBase64);
    const encryptedBytes = base64ToBytes(ciphertext);
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: new Uint8Array(iv).buffer as ArrayBuffer }, 
      key, 
      new Uint8Array(encryptedBytes)
    );
    return new TextDecoder().decode(decrypted);
  } catch (e) {
    console.error('Decryption error:', e);
    return '';
  }
}

// Helper to encrypt momentum meeting fields - uses SINGLE IV for all fields
async function encryptMeetingFields(data: Record<string, any>, encryptionKey: string): Promise<Record<string, any>> {
  const fieldsToEncrypt = ['title', 'host_email', 'host_name', 'attendees', 'transcript_content'];
  const result: Record<string, any> = { ...data };
  
  // Generate ONE IV for all fields in this record
  const ivBytes = crypto.getRandomValues(new Uint8Array(12));
  const ivBase64 = bytesToBase64(ivBytes);
  let hasEncryptedFields = false;
  
  for (const field of fieldsToEncrypt) {
    if (data[field] !== undefined && data[field] !== null) {
      const plaintext = typeof data[field] === 'object' ? JSON.stringify(data[field]) : String(data[field]);
      result[`${field}_encrypted`] = await encryptValueWithIv(plaintext, encryptionKey, ivBytes);
      result[field] = null; // Clear plaintext
      hasEncryptedFields = true;
    }
  }
  
  if (hasEncryptedFields) {
    result.pii_encryption_iv = ivBase64;
    result.is_encrypted = true;
  }
  
  return result;
}

// Table encryption configuration matching api-gateway
const TABLE_ENCRYPTION_CONFIG: Record<string, { fields: string[], ivField: string }> = {
  'account_documents': { fields: ['content', 'name'], ivField: 'encryption_iv' },
  'account_contacts': { fields: ['name', 'email', 'phone', 'role', 'notes'], ivField: 'encryption_iv' },
  'transcript_reviews': { fields: ['transcript_content'], ivField: 'encryption_iv' },
  'account_technologies': { fields: ['owner_name', 'owner_email', 'notes', 'context'], ivField: 'encryption_iv' },
  'account_nbas': { fields: ['action', 'notes'], ivField: 'encryption_iv' },
  'account_metrics': { fields: ['metric_value', 'context'], ivField: 'encryption_iv' },
  'account_use_cases': { fields: ['use_case', 'description'], ivField: 'encryption_iv' },
  'account_pain_points': { fields: ['pain_point', 'business_impact'], ivField: 'encryption_iv' },
  'opportunity_readiness_answers': { fields: ['answer', 'notes', 'evidence'], ivField: 'encryption_iv' },
};

// Generic encryption helper for any table
async function encryptTableFields(
  table: string,
  data: Record<string, any>,
  encryptionKey: string
): Promise<Record<string, any>> {
  const config = TABLE_ENCRYPTION_CONFIG[table];
  if (!config) {
    console.warn(`[Encryption] No config for table ${table}, returning unencrypted`);
    return data;
  }

  const result: Record<string, any> = { ...data };
  const ivBytes = crypto.getRandomValues(new Uint8Array(12));
  const ivBase64 = bytesToBase64(ivBytes);
  let hasEncryptedFields = false;

  for (const field of config.fields) {
    if (data[field] !== undefined && data[field] !== null) {
      const value = data[field];
      const plaintext = typeof value === 'object' ? JSON.stringify(value) : String(value);
      result[`${field}_encrypted`] = await encryptValueWithIv(plaintext, encryptionKey, ivBytes);
      
      // For NOT NULL fields, keep a placeholder
      if (table === 'account_documents' && field === 'name') {
        result[field] = '[Encrypted]';
      } else if (table === 'account_use_cases' && field === 'use_case') {
        result[field] = '[Encrypted]';
      } else {
        result[field] = null;
      }
      hasEncryptedFields = true;
    }
  }

  if (hasEncryptedFields) {
    result[config.ivField] = ivBase64;
    result.is_encrypted = true;
  }

  return result;
}

// Search index is now ephemeral (built in-memory per search request)
// No persistent search index table - sensitive data stays encrypted at rest

// Input validation for query params
const SyncMomentumQuerySchema = z.object({
  action: z.enum(["process-pending"]).optional(),
});

interface MomentumAttendee {
  name: string;
  email: string;
  isInternal: boolean;
  id?: string;
  salesforceCaseId?: string;
  salesforceLeadId?: string;
}

interface MomentumMeeting {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  host: {
    email: string;
    name: string;
  };
  attendees: MomentumAttendee[];
  transcript: {
    entries: Array<{
      text: string;
      speaker: {
        name: string;
        attendeeId: string;
      };
      timestamp: string;
      timestampSeconds: number;
    }>;
  };
  salesforceAccountId?: string;
  salesforceOpportunityId?: string;
}

interface AccountWithAutoImport {
  id: string;
  name: string;
  salesforce_account_id: string | null;
  auto_import_transcripts: boolean | null;
}

interface TeamMember {
  member_email: string;
  manager_id: string;
}

interface TeamHierarchyEntry {
  manager_id: string;
  report_id: string;
}

interface UserProfile {
  id: string;
  email: string;
}

// Helper to extract company name from email domain
function extractCompanyFromDomain(email: string): string | null {
  const domain = email.split('@')[1]?.toLowerCase();
  if (!domain) return null;
  
  const genericDomains = ['gmail', 'yahoo', 'hotmail', 'outlook', 'icloud', 'aol', 'mail', 'protonmail'];
  const domainName = domain.split('.')[0];
  
  if (genericDomains.includes(domainName)) return null;
  
  // Capitalize first letter
  return domainName.charAt(0).toUpperCase() + domainName.slice(1);
}

// Assign team members to account and opportunity based on meeting attendees
async function assignTeamMembersFromAttendees(
  supabase: any,
  accountId: string,
  opportunityId: string | null,
  attendees: MomentumAttendee[],
  meetingDbId: string
) {
  // Fetch all three lookups in parallel
  const [{ data: allTeamMembers }, { data: hierarchyData }, { data: profilesData }, { data: account }] = await Promise.all([
    supabase.from('team_members').select('member_email').eq('is_active', true),
    supabase.from('team_hierarchy').select('manager_id, report_id'),
    supabase.from('profiles').select('id, email'),
    supabase.from('accounts').select('primary_se_email').eq('id', accountId).single(),
  ]);

  const profileEmailMap = new Map<string, string>();
  for (const p of (profilesData || []) as { id: string; email: string }[]) {
    profileEmailMap.set(p.id, p.email.toLowerCase());
  }

  // Build combined set of team emails
  const teamEmails = new Set<string>();
  for (const t of (allTeamMembers || []) as { member_email: string }[]) {
    teamEmails.add(t.member_email.toLowerCase());
  }
  for (const h of (hierarchyData || []) as { manager_id: string; report_id: string }[]) {
    const managerEmail = profileEmailMap.get(h.manager_id);
    const reportEmail = profileEmailMap.get(h.report_id);
    if (managerEmail) teamEmails.add(managerEmail);
    if (reportEmail) teamEmails.add(reportEmail);
  }
  for (const p of (profilesData || []) as { email: string }[]) {
    if (p.email) teamEmails.add(p.email.toLowerCase());
  }

  // Find internal attendees - match by isInternal flag, teamEmails set, OR @pendo.io domain
  const internalTeamAttendees = attendees
    .filter(a => {
      const emailLower = a.email.toLowerCase();
      return a.isInternal || teamEmails.has(emailLower) || emailLower.endsWith('@pendo.io');
    })
    .map(a => a.email.toLowerCase());

  if (internalTeamAttendees.length === 0) return;

  console.log(`[Team Assignment] Found ${internalTeamAttendees.length} team members in meeting`);

  // Set primary_se_email if not already set
  if (!account?.primary_se_email && internalTeamAttendees.length > 0) {
    await supabase
      .from('accounts')
      .update({ primary_se_email: internalTeamAttendees[0] })
      .eq('id', accountId);
    console.log(`[Team Assignment] Set primary_se_email to ${internalTeamAttendees[0]} for account ${accountId}`);
  }

  // Batch upsert account team members (single DB call)
  const accountTeamRows = internalTeamAttendees.map(email => ({
    account_id: accountId,
    team_member_email: email,
    role: 'contributor',
    added_from_meeting_id: meetingDbId,
  }));
  await supabase
    .from('account_team_members')
    .upsert(accountTeamRows as any, { onConflict: 'account_id,team_member_email' });

  // Batch upsert opportunity team members (single DB call)
  if (opportunityId) {
    const oppTeamRows = internalTeamAttendees.map(email => ({
      opportunity_id: opportunityId,
      team_member_email: email,
      role: 'contributor',
      added_from_meeting_id: meetingDbId,
    }));
    await supabase
      .from('opportunity_team_members')
      .upsert(oppTeamRows as any, { onConflict: 'opportunity_id,team_member_email' });
  }
}

// Async background import function
async function processAutoImport(
  supabaseUrl: string,
  serviceRoleKey: string,
  meeting: MomentumMeeting,
  transcriptContent: string,
  matchedAccountId: string,
  momentumMeetingDbId: string,
  ownerEmail?: string
) {
  console.log(`[Auto-Import] Starting async import for meeting "${meeting.title}" to account ${matchedAccountId}`);
  
  const supabase = createClient(supabaseUrl, serviceRoleKey);
  const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY');
  
  try {
    // Skip if no transcript content — nothing to import
    if (!transcriptContent || transcriptContent.trim().length === 0) {
      console.warn(`[Auto-Import] Skipping meeting "${meeting.title}" — no transcript content, marking as failed`);
      await supabase
        .from('momentum_meetings')
        .update({ status: 'failed', retry_count: 3 } as any)
        .eq('id', momentumMeetingDbId);
      return undefined;
    }
    
    // Mark as processing
    await supabase
      .from('momentum_meetings')
      .update({ status: 'processing' } as any)
      .eq('id', momentumMeetingDbId);

    // DECOUPLED: We no longer run AI analysis synchronously during import.
    // All meetings are imported first (DB ops only), then analysis is triggered
    // asynchronously one-by-one AFTER the sync function completes.
    // This prevents edge function timeouts from cascading analysis calls.
    
    let analysis: any = null; // No inline analysis - will be triggered post-import
    
    // Extract stage info from analysis (will be null for initial import)
    const preSalesStage = null;
    const salesStage = null;

    // Check if opportunity exists for this account - if not, create one
    let opportunityId: string | null = null;
    let hasSalesforceOppId = Boolean(meeting.salesforceOpportunityId);
    
    // First check if there's an existing opportunity by Salesforce ID
    if (meeting.salesforceOpportunityId) {
      console.log(`[Auto-Import] Looking up opportunity by SF ID: ${meeting.salesforceOpportunityId}`);
      
      // PRIORITY 1: Check for ALL opportunities with this SF ID (to detect duplicates)
      const { data: sfMatches } = await supabase
        .from('opportunities')
        .select('id, name, salesforce_opportunity_id, created_at')
        .eq('account_id', matchedAccountId)
        .eq('salesforce_opportunity_id', meeting.salesforceOpportunityId)
        .order('created_at', { ascending: true });
      
      // Auto-merge duplicates if multiple opportunities have same SF ID
      if (sfMatches && sfMatches.length > 1) {
        console.log(`[Auto-Import] DUPLICATE OPPORTUNITIES DETECTED: ${sfMatches.length} opportunities with same SF ID ${meeting.salesforceOpportunityId}`);
        const primaryOpp = sfMatches[0]; // Keep the oldest
        
        for (const dupOpp of sfMatches.slice(1)) {
          console.log(`[Auto-Import] Auto-merging opportunity ${dupOpp.id} ("${dupOpp.name}") into ${primaryOpp.id} ("${primaryOpp.name}")`);
          
          try {
            const mergeResponse = await fetch(`${supabaseUrl}/functions/v1/merge-opportunities`, {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                primaryOpportunityId: primaryOpp.id,
                secondaryOpportunityId: dupOpp.id,
                dryRun: false,
              }),
            });
            
            const mergeResult = await mergeResponse.json();
            if (mergeResult.success) {
              console.log(`[Auto-Import] Successfully merged opportunity ${dupOpp.id} → ${primaryOpp.id}, migrated ${mergeResult.totalMigrated} records`);
            } else {
              console.error(`[Auto-Import] Opportunity merge failed: ${mergeResult.error}`);
            }
          } catch (mergeErr) {
            console.error(`[Auto-Import] Error calling merge-opportunities:`, mergeErr);
          }
        }
      }
      
      let existingOpp: { id: any; name: any; salesforce_opportunity_id: any } | null = sfMatches?.[0] || null;
      
      // PRIORITY 2: Fallback - check description for legacy records
      if (!existingOpp) {
        const sfIdPattern = `Salesforce Opportunity ID: ${meeting.salesforceOpportunityId}`;
        
        const { data: existingOpps } = await supabase
          .from('opportunities')
          .select('id, name, description, salesforce_opportunity_id')
          .eq('account_id', matchedAccountId);
        
        const foundOpp = existingOpps?.find((opp: any) => 
          opp.description?.includes(sfIdPattern) || 
          opp.description?.includes(`SF Opp ID: ${meeting.salesforceOpportunityId}`) ||
          opp.name?.includes(meeting.salesforceOpportunityId)
        );
        existingOpp = foundOpp ? { id: foundOpp.id, name: foundOpp.name, salesforce_opportunity_id: foundOpp.salesforce_opportunity_id } : null;
        
        // If found via description, backfill the dedicated column for future lookups
        if (existingOpp && !existingOpp.salesforce_opportunity_id) {
          await supabase
            .from('opportunities')
            .update({ salesforce_opportunity_id: meeting.salesforceOpportunityId } as any)
            .eq('id', existingOpp.id);
          console.log(`[Auto-Import] Backfilled salesforce_opportunity_id on existing opportunity ${existingOpp.id}`);
        }
      }

      if (existingOpp) {
        opportunityId = existingOpp.id;
        console.log(`[Auto-Import] Found existing opportunity ${opportunityId} by SF ID`);
        
        // Update stages if AI detected them
        const updateData: Record<string, any> = { last_meeting_at: meeting.startTime };
        if (preSalesStage) updateData.pre_sales_stage = preSalesStage;
        if (salesStage) updateData.sales_stage = salesStage;
        
        await supabase
          .from('opportunities')
          .update(updateData as any)
          .eq('id', existingOpp.id);
      }
      // IMPORTANT: If meeting HAS a SF ID but no match found, do NOT fall back to 
      // any open opportunity - we must create a NEW opportunity for this SF ID
    }
    
    // ONLY fall back to existing open opportunity when there's NO SF Opportunity ID
    // This prevents incorrectly linking meetings with different SF IDs to the same opportunity
    if (!opportunityId && !hasSalesforceOppId) {
      const { data: openOpp } = await supabase
        .from('opportunities')
        .select('id')
        .eq('account_id', matchedAccountId)
        .not('stage', 'in', '("closed_won","closed_lost","pending_compliance")')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (openOpp) {
        opportunityId = openOpp.id;
        console.log(`[Auto-Import] Using existing open opportunity ${opportunityId} (no SF ID on meeting)`);
        
        // Update stages and last_meeting_at
        const updateData: Record<string, any> = { last_meeting_at: meeting.startTime };
        if (preSalesStage) updateData.pre_sales_stage = preSalesStage;
        if (salesStage) updateData.sales_stage = salesStage;
        
        await supabase
          .from('opportunities')
          .update(updateData as any)
          .eq('id', opportunityId);
      }
    }
    
    // If still no opportunity, create a new one with pending_compliance flag
    let skipOpportunityCreation = false;
    
    if (!opportunityId) {
      // Check tombstone table - if this SF ID was explicitly deleted from THIS account, skip creation
      if (meeting.salesforceOpportunityId) {
        const { data: tombstone } = await supabase
          .from('opportunity_deletion_tombstones')
          .select('id')
          .eq('account_id', matchedAccountId)
          .eq('salesforce_opportunity_id', meeting.salesforceOpportunityId)
          .maybeSingle();
        
        if (tombstone) {
          console.log(`[Auto-Import] Skipping opportunity creation - SF ID ${meeting.salesforceOpportunityId} was deleted from account ${matchedAccountId}`);
          skipOpportunityCreation = true;
        }
      }

      if (!skipOpportunityCreation) {
        const oppName = meeting.salesforceOpportunityId 
          ? `${meeting.title} (${meeting.salesforceOpportunityId})`
          : `Opportunity - ${meeting.title}`;
      
        // Build description with available insights
        const painPoints = analysis?.insights?.painPoints || [];
        const useCases = analysis?.insights?.useCases || [];
        const meetingDate = new Date(meeting.startTime).toLocaleDateString();
      
        let description = `⚠️ AUTO-CREATED - Pending Compliance Review\n\nCreated from Momentum meeting: ${meeting.title}\nMeeting Date: ${meetingDate}`;
      
        if (meeting.salesforceOpportunityId) {
          description += `\n\nSalesforce Opportunity ID: ${meeting.salesforceOpportunityId}`;
        }
        if (painPoints.length > 0) {
          description += `\n\nIdentified Pain Points:\n${painPoints.slice(0, 3).map((p: string) => `• ${p}`).join('\n')}`;
        }
        if (useCases.length > 0) {
          description += `\n\nPotential Use Cases:\n${useCases.slice(0, 3).map((u: string) => `• ${u}`).join('\n')}`;
        }
          
        const { data: newOpp, error: oppError } = await supabase
          .from('opportunities')
          .insert({
            account_id: matchedAccountId,
            name: oppName,
            description,
            stage: 'pending_compliance', // Flag for review
            priority: 'high', // High priority for visibility
            pre_sales_stage: preSalesStage || 'Discovery',
            sales_stage: salesStage,
            last_meeting_at: meeting.startTime,
            owner_email: ownerEmail || meeting.host?.email,
            salesforce_opportunity_id: meeting.salesforceOpportunityId || null, // Set the dedicated column
          } as any)
          .select('id')
          .single();

        if (oppError) {
          console.error(`[Auto-Import] Failed to create opportunity: ${oppError.message}`);
        } else {
          opportunityId = newOpp.id;
          console.log(`[Auto-Import] Created new opportunity (pending_compliance) ${opportunityId}`);
        }
      }
    }

    // Assign team members to account and opportunity
    await assignTeamMembersFromAttendees(
      supabase,
      matchedAccountId,
      opportunityId,
      meeting.attendees,
      momentumMeetingDbId
    );

    // Note: We no longer save transcript to account_documents
    // Transcript content is stored once in momentum_meetings table
    // and linked via momentum_meeting_id in transcript_reviews

    // Auto-add extracted technologies - WITH ENCRYPTION
    if (analysis?.technologies?.length > 0) {
      console.log(`[Auto-Import] Saving ${analysis.technologies.length} technologies`);
      for (const tech of analysis.technologies) {
        const techData = {
          account_id: matchedAccountId,
          name: tech.name,
          category: tech.category || 'Other',
          layer: tech.layer || 'adopt',
          status: 'pending',
          extraction_confidence: tech.confidence,
          context: tech.context,
          needs_review: tech.needsReview ?? true,
          notes: `Auto-extracted from call: ${meeting.title}`,
        };
        const encryptedTechData = encryptionKey 
          ? await encryptTableFields('account_technologies', techData, encryptionKey)
          : techData;
        
        await supabase
          .from('account_technologies')
          .upsert(encryptedTechData as any, { onConflict: 'account_id,name' });
      }
    }

    // Auto-add contacts from attendees with opportunity linkage - WITH ENCRYPTION
    // Note: email column is encrypted (NULL in DB), so we must fetch all contacts and match in memory
    const externalAttendees = meeting.attendees.filter(a => !a.isInternal);
    if (externalAttendees.length > 0) {
      // Decrypt all existing contact emails in parallel (not serially) to check for duplicates
      const { data: existingContacts } = await supabase
        .from('account_contacts')
        .select('id, email_encrypted, encryption_iv')
        .eq('account_id', matchedAccountId);
      
      const existingEmailMap = new Map<string, string>(); // email -> id
      if (existingContacts && encryptionKey) {
        const decryptResults = await Promise.allSettled(
          existingContacts
            .filter(c => c.email_encrypted && c.encryption_iv)
            .map(async c => {
              const decrypted = await decryptValue(c.email_encrypted, encryptionKey, c.encryption_iv);
              return { id: c.id, email: decrypted?.toLowerCase().trim() };
            })
        );
        for (const r of decryptResults) {
          if (r.status === 'fulfilled' && r.value.email) {
            existingEmailMap.set(r.value.email, r.value.id);
          }
        }
      }
      
      // Batch-encrypt all new contacts in parallel, then do single insert
      const newContactsToInsert: any[] = [];
      const updatePromises: Promise<any>[] = [];

      for (const attendee of externalAttendees) {
        const attendeeEmail = attendee.email?.toLowerCase().trim();
        const existingId = attendeeEmail ? existingEmailMap.get(attendeeEmail) : null;
        
        if (existingId) {
          const updateData = { opportunity_id: opportunityId, source: 'momentum' };
          const encryptedUpdate = encryptionKey && attendee.name
            ? encryptTableFields('account_contacts', { name: attendee.name, ...updateData }, encryptionKey)
            : Promise.resolve({ name: attendee.name, ...updateData });
          updatePromises.push(
            encryptedUpdate.then(data =>
              supabase.from('account_contacts').update(data as any).eq('id', existingId)
            )
          );
        } else {
          const contactData = {
            account_id: matchedAccountId,
            opportunity_id: opportunityId,
            name: attendee.name,
            email: attendee.email,
            source: 'momentum',
            created_at: meeting.startTime,
          };
          newContactsToInsert.push(
            encryptionKey
              ? encryptTableFields('account_contacts', contactData, encryptionKey)
              : Promise.resolve(contactData)
          );
        }
      }

      // Resolve encryption for new contacts in parallel, then batch insert
      const [encryptedNewContacts] = await Promise.all([
        Promise.all(newContactsToInsert),
        Promise.allSettled(updatePromises),
      ]);

      if (encryptedNewContacts.length > 0) {
        await supabase.from('account_contacts').insert(encryptedNewContacts as any);
      }
    }

    // Check if a transcript already exists for this momentum meeting (deduplication)
    const transcriptFileName = `momentum_${meeting.id}`;
    const { data: existingTranscript } = await supabase
      .from('transcript_reviews')
      .select('id')
      .eq('file_name', transcriptFileName)
      .maybeSingle();

    let transcriptReviewId: string | null = existingTranscript?.id || null;

    // Store insights in transcript_reviews WITH meeting_title and last_analyzed_at - WITH ENCRYPTION
    const transcriptReviewData = {
      transcript_content: transcriptContent,
      file_name: transcriptFileName,
      meeting_title: meeting.title,
      momentum_meeting_id: momentumMeetingDbId,
      status: 'approved',
      final_account_id: matchedAccountId,
      opportunity_id: opportunityId,
      last_analyzed_at: new Date().toISOString(),
      extracted_technologies: analysis?.technologies || null,
      extracted_insights: analysis ? {
        ...analysis.insights,
        commercialInsights: analysis.commercialInsights,
        nextBestActions: analysis.nbas ?? analysis.nextBestActions,
        people: analysis.people,
        detectionRuleMatches: analysis.detectionRuleMatches,
        preSalesStageAssessment: analysis.preSalesStageAssessment,
        salesStageAssessment: analysis.salesStageAssessment,
      } : null,
    };

    if (existingTranscript) {
      // Update existing transcript instead of creating duplicate
      console.log(`[Auto-Import] Found existing transcript ${existingTranscript.id}, updating...`);
      const encryptedTranscriptData = encryptionKey 
        ? await encryptTableFields('transcript_reviews', transcriptReviewData, encryptionKey)
        : transcriptReviewData;
      
      const { error: updateError } = await supabase
        .from('transcript_reviews')
        .update(encryptedTranscriptData as any)
        .eq('id', existingTranscript.id);

      if (updateError) {
        console.error(`[Auto-Import] Failed to update transcript review: ${updateError.message}`);
        throw updateError;
      }
      console.log(`[Auto-Import] Updated existing transcript review ${existingTranscript.id}`);
    } else {
      // Insert new transcript with created_at set to meeting time
      const insertData = {
        ...transcriptReviewData,
        created_at: meeting.startTime, // Use actual meeting time for new records
      };
      const encryptedTranscriptData = encryptionKey 
        ? await encryptTableFields('transcript_reviews', insertData, encryptionKey)
        : insertData;
      
      const { data: transcriptReview, error: transcriptError } = await supabase
        .from('transcript_reviews')
        .insert(encryptedTranscriptData as any)
        .select('id')
        .single();

      if (transcriptError) {
        console.error(`[Auto-Import] Failed to save transcript review: ${transcriptError.message}`);
        throw transcriptError;
      }
      transcriptReviewId = transcriptReview?.id;
      console.log(`[Auto-Import] Created new transcript review ${transcriptReviewId}`);
    }
    console.log(`[Auto-Import] Saved transcript review ${transcriptReviewId}`);

    // Save NBAs with transcript linkage - WITH ENCRYPTION
    const extractedNBAs = analysis?.nbas ?? analysis?.nextBestActions ?? [];
    if (extractedNBAs.length > 0) {
      for (const nba of extractedNBAs) {
        const nbaData = {
          account_id: matchedAccountId,
          opportunity_id: opportunityId,
          action: nba.action,
          action_type: nba.actionType || 'follow_up',
          priority: nba.priority || 'medium',
          delivery_method: nba.deliveryMethod || 'email',
          notes: nba.reasoning || null,
          source_transcript_id: transcriptReviewId,
          status: 'pending',
          due_date: nba.dueDate || null,
          created_at: meeting.startTime, // Use actual meeting time
        };
        const encryptedNbaData = encryptionKey 
          ? await encryptTableFields('account_nbas', nbaData, encryptionKey)
          : nbaData;
        
        await supabase.from('account_nbas').insert(encryptedNbaData as any);
      }
      console.log(`[Auto-Import] Saved ${extractedNBAs.length} NBAs`);
    }

    // Save extracted metrics to account_metrics - WITH ENCRYPTION
    // Note: metric_value is encrypted (NULL in DB), so we cannot use upsert on metric_name
    const extractedMetrics = analysis?.operationalMetrics ?? [];
    if (extractedMetrics.length > 0) {
      console.log(`[Auto-Import] Saving ${extractedMetrics.length} metrics`);
      
      // Fetch existing metrics to avoid duplicates - decrypt metric_value to compare
      const { data: existingMetrics } = await supabase
        .from('account_metrics')
        .select('id, metric_name, metric_value_encrypted, encryption_iv')
        .eq('account_id', matchedAccountId);
      
      // Build a set of existing metric names (metric_name is NOT encrypted)
      const existingMetricNames = new Set(
        (existingMetrics || []).map((m: any) => m.metric_name?.toLowerCase().trim())
      );
      
      for (const metric of extractedMetrics) {
        const metricNameNorm = metric.metricName?.toLowerCase().trim();
        
        // Skip if metric already exists
        if (metricNameNorm && existingMetricNames.has(metricNameNorm)) {
          console.log(`[Auto-Import] Skipping duplicate metric: ${metric.metricName}`);
          continue;
        }
        
        const metricData = {
          account_id: matchedAccountId,
          opportunity_id: opportunityId,
          metric_name: metric.metricName,
          metric_value: metric.metricValue,
          metric_numeric_value: metric.metricNumericValue,
          metric_category: metric.metricCategory || 'general',
          confidence_score: metric.confidence,
          needs_review: metric.needsReview ?? false,
          context: metric.context,
          mentioned_by_name: metric.mentionedByName || null,
          mentioned_by_type: metric.mentionedByType || null,
          source: 'transcript_analysis',
          source_transcript_id: transcriptReviewId,
          created_at: meeting.startTime, // Use actual meeting time
        };
        const encryptedMetricData = encryptionKey 
          ? await encryptTableFields('account_metrics', metricData, encryptionKey)
          : metricData;
        
        await supabase.from('account_metrics').insert(encryptedMetricData as any);
        existingMetricNames.add(metricNameNorm); // Track inserted
      }
    }

    // Save extracted pain points to account_pain_points - WITH ENCRYPTION
    const extractedPainPoints = analysis?.insights?.painPoints ?? [];
    if (extractedPainPoints.length > 0 && matchedAccountId) {
      console.log(`[Auto-Import] Saving ${extractedPainPoints.length} pain points`);
      
      // Fetch existing pain points to avoid duplicates
      const { data: existingPainPoints } = await supabase
        .from('account_pain_points')
        .select('id, pain_point_encrypted, encryption_iv')
        .eq('account_id', matchedAccountId);
      
      // Decrypt existing pain points for comparison
      const existingPainPointNames = new Set<string>();
      if (existingPainPoints && encryptionKey) {
        const decryptResults = await Promise.allSettled(
          existingPainPoints
            .filter(pp => pp.pain_point_encrypted && pp.encryption_iv)
            .map(pp => decryptValue(pp.pain_point_encrypted, encryptionKey, pp.encryption_iv))
        );
        for (const r of decryptResults) {
          if (r.status === 'fulfilled' && r.value) {
            existingPainPointNames.add(r.value.toLowerCase().trim());
          }
        }
      }
      
      for (const painPoint of extractedPainPoints) {
        const painPointText = typeof painPoint === 'string' 
          ? painPoint 
          : (painPoint.description || painPoint.pain_point || painPoint.name);
        const painCategory = typeof painPoint === 'object' ? (painPoint.painCategory || painPoint.pain_category || 'operational_friction') : 'operational_friction';
        const severity = typeof painPoint === 'object' ? (painPoint.severity || 'medium') : 'medium';
        const businessTheme = typeof painPoint === 'object' ? painPoint.businessTheme : null;
        
        if (!painPointText) continue;
        
        const painPointNorm = painPointText.toLowerCase().trim();
        
        // Skip if exact match exists
        if (existingPainPointNames.has(painPointNorm)) {
          console.log(`[Auto-Import] Skipping duplicate pain point: ${painPointText.substring(0, 50)}...`);
          continue;
        }
        
        existingPainPointNames.add(painPointNorm);
        
        const painPointData = {
          account_id: matchedAccountId,
          opportunity_id: opportunityId,
          pain_point: painPointText,
          pain_category: painCategory,
          severity: severity,
          business_theme: businessTheme,
          source: 'transcript_analysis',
          source_transcript_id: transcriptReviewId,
          confidence_score: typeof painPoint === 'object' ? painPoint.confidence : null,
          created_at: meeting.startTime,
        };
        const encryptedPainPointData = encryptionKey 
          ? await encryptTableFields('account_pain_points', painPointData, encryptionKey)
          : painPointData;
        
        await supabase.from('account_pain_points').insert(encryptedPainPointData as any);
      }
      console.log(`[Auto-Import] Saved pain points`);
    }

    // Save extracted use cases to account_use_cases - WITH ENCRYPTION
    // Note: use_case is encrypted (NULL in DB), so we must fetch all and match in memory
    const extractedUseCases = analysis?.insights?.useCases ?? [];
    if (extractedUseCases.length > 0) {
      console.log(`[Auto-Import] Saving ${extractedUseCases.length} use cases`);
      
      // Fetch existing use cases and decrypt to check for duplicates
      const { data: existingUseCases } = await supabase
        .from('account_use_cases')
        .select('id, use_case_encrypted, encryption_iv')
        .eq('account_id', matchedAccountId);
      
      // Decrypt all existing use cases in parallel (not serially)
      const existingUseCaseNames = new Set<string>();
      const existingUseCaseCache: UseCaseWordCache[] = [];
      if (existingUseCases && encryptionKey) {
        const decryptResults = await Promise.allSettled(
          existingUseCases
            .filter(uc => uc.use_case_encrypted && uc.encryption_iv)
            .map(uc => decryptValue(uc.use_case_encrypted, encryptionKey, uc.encryption_iv))
        );
        for (const r of decryptResults) {
          if (r.status === 'fulfilled' && r.value) {
            const normalized = r.value.toLowerCase().trim();
            existingUseCaseNames.add(normalized);
            existingUseCaseCache.push({ text: normalized, words: normalizeToWords(normalized) });
          }
        }
      }
      
      for (const useCase of extractedUseCases) {
        // Handle various field names the AI might use for the use case name
        const useCaseName = typeof useCase === 'string' 
          ? useCase 
          : (useCase.name || useCase.useCase || useCase.use_case || useCase.description);
        const functionalArea = typeof useCase === 'object' ? (useCase.functionalArea || useCase.functional_area || 'General') : 'General';
        const businessTheme = typeof useCase === 'object' ? useCase.businessTheme : null;
        const priority = typeof useCase === 'object' ? useCase.priority : 'medium';
        
        if (!useCaseName) continue;
        
        const useCaseNameNorm = useCaseName.toLowerCase().trim();
        
        // Skip if exact match exists
        if (existingUseCaseNames.has(useCaseNameNorm)) {
          console.log(`[Auto-Import] Skipping exact duplicate use case: ${useCaseName}`);
          continue;
        }
        
        // Skip if semantically similar use case exists (60% word overlap) - optimized lookup
        const similar = findSimilarUseCaseFast(useCaseName, existingUseCaseCache, 0.6);
        if (similar) {
          console.log(`[Auto-Import] Skipping similar use case: "${useCaseName.substring(0, 50)}..." (similar to: "${similar.substring(0, 50)}...")`);
          continue;
        }
        
        // Add to cache for future lookups in same batch
        existingUseCaseNames.add(useCaseNameNorm);
        existingUseCaseCache.push({ text: useCaseNameNorm, words: normalizeToWords(useCaseNameNorm) });

        const useCaseData = {
          account_id: matchedAccountId,
          opportunity_id: opportunityId,
          use_case: useCaseName,
          functional_area: functionalArea,
          business_theme: businessTheme,
          description: null, // Don't duplicate use_case in description
          status: 'identified',
          priority: priority || 'medium',
          confidence_score: typeof useCase === 'object' ? useCase.confidence : null,
          source: 'transcript_analysis',
          source_transcript_id: transcriptReviewId,
          created_at: meeting.startTime, // Use actual meeting time
        };
        const encryptedUseCaseData = encryptionKey 
          ? await encryptTableFields('account_use_cases', useCaseData, encryptionKey)
          : useCaseData;
        
        await supabase.from('account_use_cases').insert(encryptedUseCaseData as any);
        existingUseCaseNames.add(useCaseNameNorm); // Track inserted
      }
    }

    // Process detection rule matches
    const detectionRuleMatches = analysis?.detectionRuleMatches ?? [];
    if (detectionRuleMatches.length > 0 && transcriptReviewId) {
      console.log(`[Auto-Import] Processing ${detectionRuleMatches.length} detection rule matches`);
      
      for (const match of detectionRuleMatches) {
        if (!match.ruleId) continue;
        
        // Save the detection rule match
        const { data: savedMatch, error: matchErr } = await supabase
          .from('detection_rule_matches')
          .insert({
            rule_id: match.ruleId,
            transcript_id: transcriptReviewId,
            opportunity_id: opportunityId,
            confidence_score: match.confidence || 0.7,
            matched_phrases: match.matchedPhrases || [],
          } as any)
          .select('id')
          .single();
        
        if (matchErr) {
          console.error(`[Auto-Import] Failed to save detection rule match: ${matchErr.message}`);
          continue;
        }
        
        const matchId = savedMatch?.id;
        
        // Fetch the rule's unified actions from detection_rule_actions table
        const { data: ruleActions } = await supabase
          .from('detection_rule_actions')
          .select('id, action_type, action_config, target_entity, is_active, legacy_capture_field_id')
          .eq('rule_id', match.ruleId)
          .eq('is_active', true)
          .order('sort_order');
        
        // Process each action based on its type
        for (const action of ruleActions || []) {
          const config = (action as any).action_config as Record<string, any>;
          
          switch ((action as any).action_type) {
            case 'create_task': {
              // Create or update validation task from template if opportunity exists
              if (config.template_id && opportunityId) {
                const { data: template } = await supabase
                  .from('validation_task_templates')
                  .select('*')
                  .eq('id', config.template_id)
                  .single();
                
                if (template) {
                  const { data: existingTask } = await supabase
                    .from('opportunity_validation_tasks')
                    .select('id, status')
                    .eq('opportunity_id', opportunityId)
                    .eq('template_id', (template as any).id)
                    .maybeSingle();
                  
                  if (!existingTask) {
                    // Create new task
                    const initialStatus = config.auto_update_status || 'not_started';
                    await supabase.from('opportunity_validation_tasks').insert({
                      opportunity_id: opportunityId,
                      template_id: (template as any).id,
                      module: (template as any).module,
                      sub_module: (template as any).sub_module,
                      activity: (template as any).activity,
                      status: initialStatus,
                      owner: (template as any).default_owner,
                      sort_order: (template as any).sort_order,
                      completed_at: initialStatus === 'completed' ? new Date().toISOString() : null,
                    } as any);
                    console.log(`[Auto-Import] Created validation task: ${(template as any).activity} (status: ${initialStatus})`);
                  } else if (config.auto_update_status && (existingTask as any).status !== config.auto_update_status) {
                    // Update existing task status if auto_update_status is configured
                    const updateData: Record<string, any> = { status: config.auto_update_status };
                    if (config.auto_update_status === 'completed') {
                      updateData.completed_at = new Date().toISOString();
                    }
                    await supabase.from('opportunity_validation_tasks')
                      .update(updateData)
                      .eq('id', (existingTask as any).id);
                    console.log(`[Auto-Import] Updated validation task status: ${(template as any).activity} → ${config.auto_update_status}`);
                  }
                }
              }
              break;
            }
            
            case 'answer_question': {
              // Auto-populate readiness answers - WITH ENCRYPTION
              if (config.question_id && opportunityId && config.auto_answer) {
                const readinessData = {
                  opportunity_id: opportunityId,
                  question_id: config.question_id,
                  answer: config.auto_answer,
                  answer_json: config.auto_answer_json,
                  confidence_score: match.confidence || 0.7,
                  source: 'detection_rule',
                  source_transcript_id: transcriptReviewId,
                  notes: `Auto-populated from rule match: ${match.ruleName || match.ruleId}`,
                };
                const encryptedReadinessData = encryptionKey 
                  ? await encryptTableFields('opportunity_readiness_answers', readinessData, encryptionKey)
                  : readinessData;
                
                await supabase
                  .from('opportunity_readiness_answers')
                  .upsert(encryptedReadinessData as any, {
                    onConflict: 'opportunity_id,question_id',
                  });
                console.log(`[Auto-Import] Auto-answered readiness question from rule: ${match.ruleName}`);
              }
              break;
            }
            
            case 'extract_data': {
              // Save captured insights from AI extraction - WITH ENCRYPTION
              const fieldName = config.field_name;
              const capturedValue = (match as any).capturedFields?.[fieldName];
              if (capturedValue && matchId) {
                const insightData = {
                  account_id: matchedAccountId,
                  opportunity_id: opportunityId,
                  capture_field_id: (action as any).legacy_capture_field_id || (action as any).id,
                  rule_match_id: matchId,
                  source_transcript_id: transcriptReviewId,
                  value: typeof capturedValue === 'string' ? capturedValue : null,
                  value_json: typeof capturedValue === 'object' ? capturedValue : null,
                  confidence_score: match.confidence || 0.7,
                };
                await supabase.from('account_captured_insights').insert(insightData as any);
                console.log(`[Auto-Import] Captured insight: ${fieldName}`);
              }
              break;
            }
            
            case 'create_nba': {
              // Create NBA from template config - WITH ENCRYPTION
              if (config.action_text) {
                const nbaData = {
                  account_id: matchedAccountId,
                  opportunity_id: opportunityId,
                  action: config.action_text,
                  action_type: config.nba_action_type || 'follow_up',
                  priority: config.priority || 'medium',
                  status: 'pending',
                  source_transcript_id: transcriptReviewId,
                };
                const encryptedNbaData = encryptionKey 
                  ? await encryptTableFields('account_nbas', nbaData, encryptionKey)
                  : nbaData;
                await supabase.from('account_nbas').insert(encryptedNbaData as any);
                console.log(`[Auto-Import] Created NBA from rule: ${config.action_text.substring(0, 50)}...`);
              }
              break;
            }
            
            case 'update_field': {
              // Update account or opportunity field
              if (config.field_name && config.field_value) {
                const targetTable = (action as any).target_entity === 'opportunity' ? 'opportunities' : 'accounts';
                const targetId = (action as any).target_entity === 'opportunity' ? opportunityId : matchedAccountId;
                
                if (targetId) {
                  await supabase
                    .from(targetTable)
                    .update({ [config.field_name]: config.field_value } as any)
                    .eq('id', targetId);
                  console.log(`[Auto-Import] Updated ${targetTable}.${config.field_name}`);
                }
              }
              break;
            }
          }
        }
      }
    }

    // Save readiness answers extracted directly from AI - WITH ENCRYPTION
    const readinessAnswers = analysis?.readinessAnswers ?? [];
    if (readinessAnswers.length > 0 && opportunityId) {
      console.log(`[Auto-Import] Saving ${readinessAnswers.length} readiness answers`);
      for (const answer of readinessAnswers) {
        if (!answer.questionId || !answer.answer) continue;
        
        const readinessData = {
          opportunity_id: opportunityId,
          question_id: answer.questionId,
          answer: answer.answer,
          confidence_score: answer.confidence || 0.7,
          source: 'transcript_analysis',
          source_transcript_id: transcriptReviewId,
          notes: answer.context ? `Context: ${answer.context.slice(0, 500)}` : null,
        };
        const encryptedReadinessData = encryptionKey 
          ? await encryptTableFields('opportunity_readiness_answers', readinessData, encryptionKey)
          : readinessData;
        
        await supabase
          .from('opportunity_readiness_answers')
          .upsert(encryptedReadinessData as any, {
            onConflict: 'opportunity_id,question_id',
          });
      }
    }

    // Create opportunity_activity record with the actual meeting date
    if (opportunityId && transcriptReviewId) {
      console.log(`[Auto-Import] Creating opportunity activity for meeting at ${meeting.startTime}`);
      
      // Infer activity type from meeting title
      const titleLower = (meeting.title || '').toLowerCase();
      let activityTypeName = 'meeting';
      if (titleLower.includes('discovery')) activityTypeName = 'discovery';
      else if (titleLower.includes('demo')) activityTypeName = 'demo';
      else if (titleLower.includes('technical') || titleLower.includes('deep dive')) activityTypeName = 'technical_deep_dive';
      else if (titleLower.includes('poc') || titleLower.includes('proof')) activityTypeName = 'poc_review';
      else if (titleLower.includes('workshop')) activityTypeName = 'workshop';
      else if (titleLower.includes('kickoff') || titleLower.includes('kick-off')) activityTypeName = 'kickoff';
      
      const { data: activityType } = await supabase
        .from('activity_types')
        .select('id')
        .eq('name', activityTypeName)
        .single();
      
      if (activityType) {
        // Get AE/SE emails from opportunity
        const { data: oppData } = await supabase
          .from('opportunities')
          .select('owner_email, primary_se_email')
          .eq('id', opportunityId)
          .single();
        
        const { error: activityErr } = await supabase
          .from('opportunity_activities')
          .upsert({
            opportunity_id: opportunityId,
            account_id: matchedAccountId,
            transcript_id: transcriptReviewId,
            activity_type_id: activityType.id,
            activity_date: meeting.startTime, // Use actual meeting time!
            title: meeting.title,
            confidence_score: 0.8,
            detection_source: 'auto_import',
            ae_email: oppData?.owner_email || null,
            se_email: oppData?.primary_se_email || meeting.host?.email || null,
          } as any, {
            onConflict: 'transcript_id',
          });
        
        if (activityErr) {
          console.error(`[Auto-Import] Failed to create activity: ${activityErr.message}`);
        } else {
          console.log(`[Auto-Import] Created activity: ${activityTypeName} at ${meeting.startTime}`);
        }
      }
    }

    // Mark as imported ONLY after everything succeeds
    // Analysis will be triggered separately after all imports complete
    await supabase
      .from('momentum_meetings')
      .update({
        status: 'imported',
        imported_at: new Date().toISOString(),
      } as any)
      .eq('id', momentumMeetingDbId);

    console.log(`[Auto-Import] Successfully imported meeting "${meeting.title}" (analysis will be triggered separately)`);
    
    // Return the transcript review ID so the caller can queue analysis
    return { transcriptReviewId, meetingTitle: meeting.title };
  } catch (error) {
    console.error(`[Auto-Import] Failed for meeting "${meeting.title}":`, error);
    
    // Increment retry_count; if >= 3, mark as 'failed' to stop infinite loops
    try {
      const { data: currentMeeting } = await supabase
        .from('momentum_meetings')
        .select('retry_count')
        .eq('id', momentumMeetingDbId)
        .single();
      
      const newRetryCount = ((currentMeeting as any)?.retry_count || 0) + 1;
      const MAX_RETRIES = 3;
      
      if (newRetryCount >= MAX_RETRIES) {
        await supabase
          .from('momentum_meetings')
          .update({ status: 'failed', retry_count: newRetryCount } as any)
          .eq('id', momentumMeetingDbId);
        console.warn(`[Auto-Import] Meeting ${momentumMeetingDbId} failed ${newRetryCount} times, marking as 'failed'`);
      } else {
        await supabase
          .from('momentum_meetings')
          .update({ status: 'queued', retry_count: newRetryCount } as any)
          .eq('id', momentumMeetingDbId);
        console.log(`[Auto-Import] Reset meeting ${momentumMeetingDbId} to queued (retry ${newRetryCount}/${MAX_RETRIES})`);
      }
    } catch (resetErr) {
      console.error(`[Auto-Import] Failed to reset meeting status:`, resetErr);
    }
  }
}

// Process existing pending meetings that should have been auto-imported
async function processPendingAutoImports(
  supabaseUrl: string,
  serviceRoleKey: string,
  batchSize = 20
) {
  console.log('[Pending Import] Checking for pending meetings with matching accounts...');
  
  const supabase = createClient(supabaseUrl, serviceRoleKey);
  const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY') || '';
  
  // Find pending meetings — fetch encrypted fields too so we can decrypt them
  const { data: pendingMeetings, error } = await supabase
    .from('momentum_meetings')
    .select(`
      id,
      momentum_id,
      title,
      title_encrypted,
      start_time,
      end_time,
      host_email,
      host_email_encrypted,
      host_name,
      host_name_encrypted,
      attendees,
      attendees_encrypted,
      transcript_content,
      transcript_content_encrypted,
      pii_encryption_iv,
      is_encrypted,
      salesforce_account_id,
      salesforce_opportunity_id
    `)
    .eq('status', 'pending')
    .not('salesforce_account_id', 'is', null)
    .order('start_time', { ascending: true })
    .limit(batchSize);

  if (error || !pendingMeetings?.length) {
    console.log('[Pending Import] No pending meetings found or error:', error?.message);
    return { processed: 0 };
  }

  // Get matching accounts
  const { data: accounts } = await supabase
    .from('accounts')
    .select('id, name, salesforce_account_id, auto_import_transcripts');

  if (!accounts?.length) {
    console.log('[Pending Import] No accounts found');
    return { processed: 0 };
  }

  const importPromises: Promise<void>[] = [];
  let queued = 0;
  let skipped = 0;
  
  for (const meeting of pendingMeetings) {
    const matchedAccount = accounts.find(
      (a: any) => a.salesforce_account_id === meeting.salesforce_account_id && a.auto_import_transcripts !== false
    );

    if (!matchedAccount) {
      skipped++;
      continue;
    }

    // Decrypt fields if encrypted — mirrors the backlog processor pattern
    let title = meeting.title;
    let transcriptContent = meeting.transcript_content || '';
    let hostEmail = meeting.host_email;
    let hostName = meeting.host_name;
    let attendees = meeting.attendees || [];

    if (meeting.is_encrypted && meeting.pii_encryption_iv && encryptionKey) {
      try {
        if (meeting.title_encrypted) title = await decryptValue(meeting.title_encrypted, encryptionKey, meeting.pii_encryption_iv);
        if (meeting.transcript_content_encrypted) transcriptContent = await decryptValue(meeting.transcript_content_encrypted, encryptionKey, meeting.pii_encryption_iv);
        if (meeting.host_email_encrypted) hostEmail = await decryptValue(meeting.host_email_encrypted, encryptionKey, meeting.pii_encryption_iv);
        if (meeting.host_name_encrypted) hostName = await decryptValue(meeting.host_name_encrypted, encryptionKey, meeting.pii_encryption_iv);
        if (meeting.attendees_encrypted) {
          try {
            const decryptedAttendees = await decryptValue(meeting.attendees_encrypted, encryptionKey, meeting.pii_encryption_iv);
            attendees = JSON.parse(decryptedAttendees);
          } catch (e) { console.error(`[Pending Import] Failed to parse attendees for ${meeting.id}:`, e); }
        }
      } catch (e) {
        console.error(`[Pending Import] Decryption failed for meeting ${meeting.id}:`, e);
      }
    }

    if (!transcriptContent || transcriptContent.trim().length < 50) {
      console.warn(`[Pending Import] Skipping meeting ${meeting.id} ("${title}") — no transcript content, marking ignored`);
      await supabase.from('momentum_meetings').update({ status: 'ignored', ignored_at: new Date().toISOString() }).eq('id', meeting.id);
      skipped++;
      continue;
    }

    console.log(`[Pending Import] Queuing meeting "${title}" for account "${matchedAccount.name}"`);
    
    const meetingData: MomentumMeeting = {
      id: meeting.momentum_id,
      title,
      startTime: meeting.start_time,
      endTime: meeting.end_time || meeting.start_time,
      host: {
        email: hostEmail || '',
        name: hostName || '',
      },
      attendees: (attendees as MomentumAttendee[]) || [],
      transcript: { entries: [] },
      salesforceAccountId: meeting.salesforce_account_id || undefined,
      salesforceOpportunityId: meeting.salesforce_opportunity_id || undefined,
    };

    importPromises.push(
      processAutoImport(
        supabaseUrl,
        serviceRoleKey,
        meetingData,
        transcriptContent,
        matchedAccount.id,
        meeting.id
      )
    );
    
    queued++;
  }

  if (importPromises.length > 0) {
    console.log(`[Pending Import] Running ${queued} imports in parallel (${skipped} skipped)...`);
    await Promise.allSettled(importPromises);
  }

  console.log(`[Pending Import] Completed ${queued} pending meetings, ${skipped} skipped/ignored`);
  return { processed: queued, skipped };
}

// Declare EdgeRuntime for TypeScript
declare const EdgeRuntime: {
  waitUntil: (promise: Promise<any>) => void;
} | undefined;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const MOMENTUM_API_KEY = Deno.env.get("MOMENTUM_API_KEY");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    // Check for pending import action
    const url = new URL(req.url);
    if (url.searchParams.get('action') === 'process-pending') {
      const result = await processPendingAutoImports(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);
      return new Response(JSON.stringify({ success: true, ...result }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!MOMENTUM_API_KEY) {
      throw new Error("MOMENTUM_API_KEY is not configured");
    }

    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);
    
    // Get last sync time
    const { data: syncState } = await supabase
      .from('momentum_sync_state')
      .select('last_sync_at')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    // Check for custom date range or full sync
    const reqUrl = new URL(req.url);
    const forceFullSync = reqUrl.searchParams.get('fullSync') === 'true';
    const customFrom = reqUrl.searchParams.get('from'); // ISO date: 2025-01-01
    const customTo = reqUrl.searchParams.get('to'); // ISO date: 2025-01-07
    const filterSalesforceAccountId = reqUrl.searchParams.get('salesforceAccountId'); // Optional: only process meetings for this SF account
    const singleMeetingId = reqUrl.searchParams.get('meetingId'); // Optional: fetch a single meeting by Momentum ID
    
    if (filterSalesforceAccountId) {
      console.log(`[Account Filter] Will only process meetings for Salesforce Account ID: ${filterSalesforceAccountId}`);
    }
    
    if (singleMeetingId) {
      console.log(`[Single Meeting] Searching for Momentum meeting ID: ${singleMeetingId}`);
    }
    
    const now = new Date();
    let syncFromDate: Date;
    let syncToDate: Date = now;
    let singleMeetingFound = false;
    let allMeetings: MomentumMeeting[] = [];
    
    if (singleMeetingId) {
      // Try direct endpoint first: GET /v1/meetings/{id}
      try {
        const directUrl = `https://api.momentum.io/v1/meetings/${singleMeetingId}`;
        console.log(`[Single Meeting] Trying direct endpoint: ${directUrl}`);
        const directResp = await fetch(directUrl, {
          method: 'GET',
          headers: { 'X-API-Key': MOMENTUM_API_KEY },
        });
        if (directResp.ok) {
          const directData = await directResp.json();
          const directMeeting = directData.meeting || directData;
          if (directMeeting && (directMeeting.id || directMeeting.title)) {
            console.log(`[Single Meeting] Found via direct endpoint: "${directMeeting.title}"`);
            allMeetings = [directMeeting];
            singleMeetingFound = true;
          }
        } else {
          console.log(`[Single Meeting] Direct endpoint returned ${directResp.status}, falling back to pagination`);
        }
      } catch (directErr) {
        console.log(`[Single Meeting] Direct endpoint failed, falling back to pagination`);
      }
      
      if (!singleMeetingFound) {
        // Fallback: search last 30 days first (much faster than 2 years)
        syncFromDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        console.log(`[Single Meeting] Searching last 30 days: ${syncFromDate.toISOString()} to ${syncToDate.toISOString()}`);
      } else {
        // Already found, set dummy dates (won't be used)
        syncFromDate = new Date(now.getTime() - 4 * 24 * 60 * 60 * 1000);
      }
    } else if (customFrom) {
      // Custom date range - parse ISO date strings
      syncFromDate = new Date(customFrom);
      syncFromDate.setUTCHours(0, 0, 0, 0);
      if (customTo) {
        syncToDate = new Date(customTo);
        syncToDate.setUTCHours(23, 59, 59, 999);
      }
      console.log(`[Custom Range] Syncing from ${syncFromDate.toISOString()} to ${syncToDate.toISOString()}`);
    } else if (forceFullSync) {
      syncFromDate = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
      console.log(`[Full Sync] Last 14 days`);
    } else {
      // Regular sync: last 4 days
      syncFromDate = new Date(now.getTime() - 4 * 24 * 60 * 60 * 1000);
    }
    // Format as ISO8601 without milliseconds for better API compatibility
    const fromDateStr = syncFromDate.toISOString().split('.')[0] + 'Z';
    const toDateStr = syncToDate.toISOString().split('.')[0] + 'Z';

    console.log(`Syncing meetings from: ${fromDateStr} to: ${toDateStr}${forceFullSync ? ' (FULL SYNC)' : ''}`);

    // Fetch meetings from Momentum API with date range
    // allMeetings may already be populated by direct endpoint lookup above
    let pageNumber = 1;
    let hasMorePages = !singleMeetingFound; // Skip pagination if already found
    const isManualRequest = singleMeetingId || customFrom || filterSalesforceAccountId;
    // No page cap for cron runs — all meetings are inserted as 'queued' rows in the DB first.
    // Processing throughput is controlled by MAX_IMPORTS (20 per cron run) further below,
    // so pagination exhaustion is safe and won't crash analysis pipelines.
    const maxPages = singleMeetingId ? 50 : 999; // effectively unlimited; real pacing is via MAX_IMPORTS
    let foundSingleMeeting = singleMeetingFound;

    while (hasMorePages && pageNumber <= maxPages) {
      const apiUrl = new URL('https://api.momentum.io/v1/meetings');
      apiUrl.searchParams.set('pageNumber', pageNumber.toString());
      apiUrl.searchParams.set('pageSize', '50');
      apiUrl.searchParams.set('from', fromDateStr);
      apiUrl.searchParams.set('to', toDateStr);
      
      // Pass salesforceAccountId directly to the Momentum API for server-side filtering
      // BUT NOT when searching for a single meeting (it may not have the SF ID association)
      if (filterSalesforceAccountId && !singleMeetingId) {
        apiUrl.searchParams.set('salesforceAccountId', filterSalesforceAccountId);
      }

      // Always log the full resolved URI on page 1 for debugging
      if (pageNumber === 1) {
        console.log(`[API Request] Full URI: ${apiUrl.toString()}`);
      }
      if (pageNumber === 1 || pageNumber % 10 === 0) {
        console.log(`Fetching page ${pageNumber} from Momentum API...`);
      }

      let response: Response | null = null;
      for (let attempt = 0; attempt < 3; attempt++) {
        response = await fetch(apiUrl.toString(), {
          method: 'GET',
          headers: { 'X-API-Key': MOMENTUM_API_KEY },
        });

        if (response.status === 429) {
          const retryAfter = parseInt(response.headers.get('Retry-After') || '0', 10);
          const waitMs = Math.max((retryAfter || (attempt + 1) * 5) * 1000, 3000);
          console.warn(`[Rate Limit] 429 on page ${pageNumber}, waiting ${waitMs}ms (attempt ${attempt + 1}/3)`);
          await new Promise(r => setTimeout(r, waitMs));
          continue;
        }
        break;
      }

      if (!response || !response.ok) {
        const errorText = response ? await response.text() : 'no response';
        console.error(`Momentum API error: ${response?.status} - ${errorText}`);
        // On rate limit after retries, return partial results instead of crashing
        if (response?.status === 429) {
          console.warn(`[Rate Limit] Exhausted retries on page ${pageNumber}, proceeding with ${allMeetings.length} meetings collected so far`);
          break;
        }
        throw new Error(`Momentum API error: ${response?.status}`);
      }

      const data = await response.json();
      const pageMeetings: MomentumMeeting[] = data.meetings || [];
      
      if (singleMeetingId) {
        // When searching for a single meeting, only keep the match
        const match = pageMeetings.find(m => String(m.id) === String(singleMeetingId));
        if (match) {
          allMeetings = [match];
          foundSingleMeeting = true;
          console.log(`[Single Meeting] Found meeting ${singleMeetingId}: "${match.title}" on page ${pageNumber}`);
          break;
        }
      } else {
        allMeetings = allMeetings.concat(pageMeetings);
      }
      
      // Log every page for debugging
      console.log(`Page ${pageNumber}: ${pageMeetings.length} meetings (totalPages: ${data.pageCount || 1}, totalMeetings: ${data.totalCount || 'unknown'})`);
      
      // No hard safety cap — meetings are only inserted as 'queued' rows, not immediately analyzed.
      // The MAX_IMPORTS limit below controls how many get analyzed per cron run.

      
      // Throttle between pages to respect rate limits
      if (hasMorePages) {
        await new Promise(r => setTimeout(r, 500));
      }
      
      hasMorePages = pageNumber < (data.pageCount || 1);
      pageNumber++;
    }

    if (singleMeetingId && !foundSingleMeeting) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: `Meeting ID ${singleMeetingId} not found in Momentum API (searched ${pageNumber - 1} pages over last 2 years)` 
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Fetched ${allMeetings.length} total meetings from Momentum API${filterSalesforceAccountId ? ` (filtered by SF Account ${filterSalesforceAccountId})` : ''}${singleMeetingId ? ` (single meeting lookup)` : ''}`);

    // Get existing momentum IDs to avoid duplicates (paginate to avoid 1000-row limit)
    const existingIds = new Set<string>();
    const existingPageSize = 1000;
    let existingFrom = 0;

    while (true) {
      const { data: page, error: pageError } = await supabase
        .from('momentum_meetings')
        .select('momentum_id')
        .range(existingFrom, existingFrom + existingPageSize - 1);

      if (pageError) throw pageError;
      if (!page || page.length === 0) break;

      for (const m of page as any[]) existingIds.add(m.momentum_id);

      if (page.length < existingPageSize) break;
      existingFrom += existingPageSize;
    }

    console.log(`Found ${existingIds.size} existing meetings in database`);

    // Get all accounts for matching - include auto_import_transcripts flag
    const { data: accounts } = await supabase
      .from('accounts')
      .select('id, name, salesforce_account_id, auto_import_transcripts');

    const accountsTyped = (accounts || []) as AccountWithAutoImport[];

    // Get all team member emails for auto-create logic (from team_members table)
    const { data: teamMembersData } = await supabase
      .from('team_members')
      .select('member_email')
      .eq('is_active', true);
    
    const teamMemberEmails = new Set((teamMembersData || []).map((t: any) => t.member_email.toLowerCase()));

    // Also get team hierarchy to include direct reports
    const { data: hierarchyData } = await supabase
      .from('team_hierarchy')
      .select('manager_id, report_id');
    
    // Get all profiles to map user IDs to emails
    const { data: profilesData } = await supabase
      .from('profiles')
      .select('id, email');
    
    const profileEmailMap = new Map<string, string>();
    const profileIdByEmail = new Map<string, string>();
    for (const p of (profilesData || []) as UserProfile[]) {
      profileEmailMap.set(p.id, p.email.toLowerCase());
      profileIdByEmail.set(p.email.toLowerCase(), p.id);
    }

    // Build set of all users in any team hierarchy (managers and their reports)
    const hierarchyEmails = new Set<string>();
    for (const h of (hierarchyData || []) as TeamHierarchyEntry[]) {
      const managerEmail = profileEmailMap.get(h.manager_id);
      const reportEmail = profileEmailMap.get(h.report_id);
      if (managerEmail) hierarchyEmails.add(managerEmail);
      if (reportEmail) hierarchyEmails.add(reportEmail);
    }

    // Combine both: team_members table + team_hierarchy participants
    const allTeamEmails = new Set([...teamMemberEmails, ...hierarchyEmails]);
    console.log(`[Team Detection] Found ${allTeamEmails.size} team emails (${teamMemberEmails.size} from team_members, ${hierarchyEmails.size} from hierarchy)`);

    let newMeetingsCount = 0;
    let autoMatchedCount = 0;
    let autoImportQueued = 0;
    let accountsCreated = 0;
    let skippedDuplicates = 0;
    let skippedInternal = 0;
    let skippedNotTeam = 0;
    // Collect import tasks instead of promises to control concurrency
    interface ImportTask {
      supabaseUrl: string;
      serviceRoleKey: string;
      meeting: MomentumMeeting;
      transcriptContent: string;
      matchedAccountId: string;
      momentumMeetingDbId: string;
    }
    const autoImportTasks: ImportTask[] = [];
   const teamMemberMeetings: { title: string; accountName: string; accountId: string; opportunityId?: string; salesforceOpportunityId?: string | null; teamMembers: string[] }[] = [];

    for (const meeting of allMeetings) {
      // Skip if already exists - check by momentum_id
      if (existingIds.has(meeting.id)) {
        skippedDuplicates++;
        continue;
      }

      // SF Account filtering is now done during pagination (no post-filter needed)

      // Check if meeting is internal-only (no external attendees)
      const externalAttendees = (meeting.attendees || []).filter((a: MomentumAttendee) => !a.isInternal);
      const isInternalOnly = externalAttendees.length === 0;
      
      // Internal-only meetings get routed to the Pendo (Internal) account
      // instead of being skipped entirely - valuable for competitive intel
      const PENDO_INTERNAL_ACCOUNT_ID = 'faf15e54-783e-475b-a9b5-3685bb10f678';

      // Check if any team member (from team_members OR team_hierarchy) is on this meeting
      const internalAttendees = (meeting.attendees || []).filter((a: MomentumAttendee) => a.isInternal);
      const teamMembersOnCall = internalAttendees
        .filter((a: MomentumAttendee) => allTeamEmails.has(a.email.toLowerCase()))
        .map((a: MomentumAttendee) => a.name || a.email);
      
      // Check if host is a team member
      if (allTeamEmails.has(meeting.host?.email?.toLowerCase() || '')) {
        if (!teamMembersOnCall.includes(meeting.host?.name || meeting.host?.email || '')) {
          teamMembersOnCall.push(meeting.host?.name || meeting.host?.email || '');
        }
      }
      
      const hasTeamMember = teamMembersOnCall.length > 0;

      // Format transcript content
      const transcriptContent = meeting.transcript?.entries
        ?.map(e => `[${e.speaker.name}]: ${e.text}`)
        .join('\n') || '';

      // If internal-only meeting, route directly to Pendo (Internal) account
      // and skip normal account matching logic
      if (isInternalOnly) {
        console.log(`[Internal Meeting] Routing "${meeting.title}" to Pendo (Internal) account`);
        
        const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY') || '';
        const meetingData = await encryptMeetingFields({
          momentum_id: meeting.id,
          title: meeting.title,
          start_time: meeting.startTime,
          end_time: meeting.endTime,
          host_email: meeting.host?.email,
          host_name: meeting.host?.name,
          attendees: meeting.attendees,
          transcript_content: transcriptContent,
          salesforce_account_id: meeting.salesforceAccountId,
          salesforce_opportunity_id: meeting.salesforceOpportunityId,
          status: 'pending', // Internal meetings go to pending for manual review
          matched_account_id: PENDO_INTERNAL_ACCOUNT_ID,
          meeting_context: 'internal_strategy', // Default context for internal-only meetings
        }, encryptionKey);
        
        await supabase
          .from('momentum_meetings')
          .insert(meetingData as any);
        
        newMeetingsCount++;
        skippedInternal++; // Still count for reporting
        continue;
      }

      // Try to match to an existing account
      let matchedAccount: AccountWithAutoImport | null = null;

      // Method 1: Match by Salesforce Account ID - find ALL matches to detect duplicates
      if (meeting.salesforceAccountId) {
        const sfMatches = accountsTyped.filter(a => a.salesforce_account_id === meeting.salesforceAccountId);
        
        if (sfMatches.length > 1) {
          // DUPLICATE DETECTED - auto-merge into oldest account
          console.log(`[Duplicate Detection] Found ${sfMatches.length} accounts with SF ID ${meeting.salesforceAccountId}`);
          
          // Sort by created_at to find the oldest (primary) account
          // Note: we don't have created_at in the type, so use the one with more data or first found
          const primaryAccount = sfMatches[0];
          const duplicates = sfMatches.slice(1);
          
          console.log(`[Duplicate Detection] Primary account: ${primaryAccount.name} (${primaryAccount.id})`);
          
          // Call merge-accounts function for each duplicate
          for (const dupAccount of duplicates) {
            console.log(`[Duplicate Detection] Merging duplicate: ${dupAccount.name} (${dupAccount.id}) into primary`);
            
            try {
              const mergeResponse = await fetch(`${SUPABASE_URL}/functions/v1/merge-accounts`, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                },
                body: JSON.stringify({
                  primaryAccountId: primaryAccount.id,
                  secondaryAccountId: dupAccount.id,
                  dryRun: false,
                }),
              });
              
              if (mergeResponse.ok) {
                const mergeResult = await mergeResponse.json();
                console.log(`[Duplicate Detection] Merge completed: ${mergeResult.totalMigrated} records migrated`);
                
                // Remove the duplicate from our local list
                const dupIndex = accountsTyped.findIndex(a => a.id === dupAccount.id);
                if (dupIndex !== -1) {
                  accountsTyped.splice(dupIndex, 1);
                }
              } else {
                console.error(`[Duplicate Detection] Merge failed: ${await mergeResponse.text()}`);
              }
            } catch (mergeErr) {
              console.error(`[Duplicate Detection] Merge error:`, mergeErr);
            }
          }
          
          matchedAccount = primaryAccount;
        } else if (sfMatches.length === 1) {
          matchedAccount = sfMatches[0];
          console.log(`Matched meeting "${meeting.title}" to account "${sfMatches[0].name}" via Salesforce ID`);
        }
      }

      // Method 2: Match by company name in title or attendee email domains
      if (!matchedAccount) {
        const externalDomains = meeting.attendees
          .filter(a => !a.isInternal && a.email)
          .map(a => a.email.split('@')[1]?.toLowerCase())
          .filter(Boolean);

        // Common words that shouldn't trigger account name matching in titles
        const commonWords = new Set([
          'resource', 'resources', 'support', 'service', 'services', 
          'team', 'group', 'sync', 'meeting', 'call', 'demo', 'review',
          'update', 'check', 'weekly', 'daily', 'monthly', 'quarterly',
          'planning', 'strategy', 'technical', 'business', 'sales',
          'customer', 'partner', 'internal', 'external', 'general',
          'quick', 'follow', 'kickoff', 'intro', 'introduction',
          'training', 'onboarding', 'implementation', 'project',
          'platform', 'overview', 'discussion', 'incident', 'walkthrough',
          'integration', 'expansion', 'subscription', 'enterprise',
          'analytics', 'digital', 'cloud', 'data', 'solutions', 'network',
          'system', 'systems', 'global', 'connect', 'engage', 'insight',
          'studio', 'express', 'core', 'plus', 'prime', 'link', 'hub',
          'flow', 'wave', 'spark', 'pulse', 'shift', 'scale', 'edge'
        ]);

        for (const account of accountsTyped) {
          const accountNameLower = account.name.toLowerCase().trim();
          
          // Skip title matching for common/generic account names (3+ chars to avoid false matches)
          const isGenericName = accountNameLower.length <= 3 || commonWords.has(accountNameLower);
          
          // For title matching, require the account name to be a distinct word/phrase
          // Use word boundary matching to avoid partial matches like "Resource" in "Human Resources"
          if (!isGenericName && accountNameLower.length >= 4) {
            const titleLower = meeting.title.toLowerCase();
            // Check if account name appears as a word boundary match (not as part of another word)
            const wordBoundaryRegex = new RegExp(`\\b${accountNameLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`);
            if (wordBoundaryRegex.test(titleLower)) {
              matchedAccount = account;
              console.log(`Matched meeting "${meeting.title}" to account "${account.name}" via title (word boundary)`);
              break;
            }
          }

          // Domain matching is more reliable - keep this
          for (const domain of externalDomains) {
            const domainBase = domain.split('.')[0];
            // Require exact match or significant overlap (not just 3-char common words)
            if (domainBase.length >= 4 && (accountNameLower === domainBase || domainBase === accountNameLower)) {
              matchedAccount = account;
              console.log(`Matched meeting "${meeting.title}" to account "${account.name}" via domain ${domain}`);
              break;
            }
            // Partial match only if both are substantial (5+ chars)
            if (domainBase.length >= 5 && accountNameLower.length >= 5) {
              if (accountNameLower.includes(domainBase) || domainBase.includes(accountNameLower)) {
                matchedAccount = account;
                console.log(`Matched meeting "${meeting.title}" to account "${account.name}" via domain partial ${domain}`);
                break;
              }
            }
          }
          if (matchedAccount) break;
        }
      }

      // Method 3: Auto-create account if Salesforce Account ID exists but no matching account
      // This ensures meetings with valid SF IDs always get proper account attribution
      if (!matchedAccount && meeting.salesforceAccountId) {
        // SAFETY CHECK: Re-query database to ensure no account exists with this SF ID
        // This prevents race conditions from creating duplicates
        const { data: existingBysfId } = await supabase
          .from('accounts')
          .select('id, name, salesforce_account_id, auto_import_transcripts')
          .eq('salesforce_account_id', meeting.salesforceAccountId)
          .limit(1)
          .maybeSingle();

        if (existingBysfId) {
          matchedAccount = existingBysfId as AccountWithAutoImport;
          accountsTyped.push(matchedAccount); // Add to local cache
          console.log(`[Safety Check] Found existing account ${existingBysfId.name} for SF ID ${meeting.salesforceAccountId}`);
        } else {
          // Try to extract company name from meeting title or external attendee domains
          let companyName = externalAttendees
            .map(a => extractCompanyFromDomain(a.email))
            .find(name => name !== null);
          
          // If no company name from domain, try to extract from meeting title
          // Look for patterns like "Pendo + CompanyName" or "CompanyName x Pendo" or "CompanyName | Pendo"
          if (!companyName) {
            const titlePatterns = [
              /pendo\s*[+x|&]\s*([A-Z][a-zA-Z0-9\s]+?)(?:\s*[|:\-]|$)/i,
              /([A-Z][a-zA-Z0-9\s]+?)\s*[+x|&]\s*pendo/i,
              /^([A-Z][a-zA-Z0-9]+)\s+(?:meeting|sync|call|demo|review)/i,
            ];
            for (const pattern of titlePatterns) {
              const match = meeting.title.match(pattern);
              if (match && match[1]) {
                companyName = match[1].trim();
                break;
              }
            }
          }
          
          // Fallback: use a placeholder name based on SF ID
          if (!companyName) {
            companyName = `Account (${meeting.salesforceAccountId.slice(-8)})`;
          }

          console.log(`[Auto-Create] Creating account "${companyName}" for Salesforce ID ${meeting.salesforceAccountId}`);
          
          // Use upsert with salesforce_account_id as conflict target to prevent race condition duplicates
          const { data: newAccount, error: createError } = await supabase
            .from('accounts')
            .upsert({
              name: companyName,
              salesforce_account_id: meeting.salesforceAccountId,
              status: 'active',
              auto_import_transcripts: true,
            } as any, { onConflict: 'salesforce_account_id', ignoreDuplicates: false })
            .select('id, name, salesforce_account_id, auto_import_transcripts')
            .single();

          if (!createError && newAccount) {
            matchedAccount = newAccount as AccountWithAutoImport;
            accountsTyped.push(matchedAccount);
            accountsCreated++;
            console.log(`[Auto-Create] Created account "${companyName}" with ID ${newAccount.id} for SF ID ${meeting.salesforceAccountId}`);
            // Re-queue any previously-ignored meetings for this SF ID now that an account exists
            if (newAccount.auto_import_transcripts !== false && meeting.salesforceAccountId) {
              const { count: requeued } = await supabase
                .from('momentum_meetings')
                .update({ status: 'pending', matched_account_id: newAccount.id, ignored_at: null })
                .eq('salesforce_account_id', meeting.salesforceAccountId)
                .eq('status', 'ignored');
              if (requeued && requeued > 0) {
                console.log(`[Re-queue] Moved ${requeued} previously-ignored meetings back to pending for account "${newAccount.name}"`);
              }
            }
          } else {
            // Fallback: upsert failed, try to find existing account by SF ID
            console.warn(`[Auto-Create] Upsert failed (${createError?.message}), falling back to SELECT`);
            const { data: fallbackAccount } = await supabase
              .from('accounts')
              .select('id, name, salesforce_account_id, auto_import_transcripts')
              .eq('salesforce_account_id', meeting.salesforceAccountId)
              .maybeSingle();
            if (fallbackAccount) {
              matchedAccount = fallbackAccount as AccountWithAutoImport;
              console.log(`[Auto-Create] Found existing account "${fallbackAccount.name}" via fallback SELECT`);
            }
          }
        }
      }

      // Method 4: Auto-create account if team member is on meeting and still no match
      if (!matchedAccount && hasTeamMember) {
        // Try to extract company name from external attendee domains
        const companyName = externalAttendees
          .map(a => extractCompanyFromDomain(a.email))
          .find(name => name !== null);

        if (companyName) {
          console.log(`[Auto-Create] Creating account "${companyName}" for meeting with team member`);
          
          const { data: newAccount, error: createError } = await supabase
            .from('accounts')
            .insert({
              name: companyName,
              salesforce_account_id: meeting.salesforceAccountId || null,
              status: 'active',
              auto_import_transcripts: true,
            } as any)
            .select('id, name, salesforce_account_id, auto_import_transcripts')
            .single();

          if (!createError && newAccount) {
            matchedAccount = newAccount as AccountWithAutoImport;
            accountsTyped.push(matchedAccount);
            accountsCreated++;
            console.log(`[Auto-Create] Created account "${companyName}" with ID ${newAccount.id}`);
          } else {
            // Fallback: check if account with this name already exists
            console.warn(`[Auto-Create] Insert failed (${createError?.message}), falling back to name search`);
            const { data: fallbackAccount } = await supabase
              .from('accounts')
              .select('id, name, salesforce_account_id, auto_import_transcripts')
              .ilike('name', companyName)
              .maybeSingle();
            if (fallbackAccount) {
              matchedAccount = fallbackAccount as AccountWithAutoImport;
              console.log(`[Auto-Create] Found existing account "${fallbackAccount.name}" via fallback`);
            }
          }
        }
      }

      // Check if auto-import is enabled for this account (default: true)
      const shouldAutoImport = matchedAccount && (matchedAccount.auto_import_transcripts !== false);

      // Track team member meetings for notifications (including account ID for linking)
      if (hasTeamMember && matchedAccount) {
        teamMemberMeetings.push({
          title: meeting.title,
          accountName: matchedAccount.name,
          accountId: matchedAccount.id,
          teamMembers: teamMembersOnCall,
         // Include SF opportunity ID if available (will be resolved to DB ID during import)
         salesforceOpportunityId: meeting.salesforceOpportunityId || null,
        });
      }

      const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY') || '';
      
      if (matchedAccount && shouldAutoImport) {
        autoMatchedCount++;
        
        // Insert meeting with encryption
        const meetingData = await encryptMeetingFields({
          momentum_id: meeting.id,
          title: meeting.title,
          start_time: meeting.startTime,
          end_time: meeting.endTime,
          host_email: meeting.host?.email,
          host_name: meeting.host?.name,
          attendees: meeting.attendees,
          transcript_content: transcriptContent,
          salesforce_account_id: meeting.salesforceAccountId,
          salesforce_opportunity_id: meeting.salesforceOpportunityId,
          status: 'queued',
          matched_account_id: matchedAccount.id,
        }, encryptionKey);
        
        const { data: insertedMeeting, error: insertError } = await supabase
          .from('momentum_meetings')
          .insert(meetingData as any)
          .select('id')
          .single();

        if (!insertError && insertedMeeting) {
          autoImportQueued++;
          
          // Collect import task data instead of starting immediately
          autoImportTasks.push({
            supabaseUrl: SUPABASE_URL!,
            serviceRoleKey: SUPABASE_SERVICE_ROLE_KEY!,
            meeting,
            transcriptContent,
            matchedAccountId: matchedAccount.id,
            momentumMeetingDbId: insertedMeeting.id
          });
        }
      } else if (matchedAccount && !shouldAutoImport) {
        autoMatchedCount++;
        const meetingData = await encryptMeetingFields({
          momentum_id: meeting.id,
          title: meeting.title,
          start_time: meeting.startTime,
          end_time: meeting.endTime,
          host_email: meeting.host?.email,
          host_name: meeting.host?.name,
          attendees: meeting.attendees,
          transcript_content: transcriptContent,
          salesforce_account_id: meeting.salesforceAccountId,
          salesforce_opportunity_id: meeting.salesforceOpportunityId,
          status: 'pending',
          matched_account_id: matchedAccount.id,
        }, encryptionKey);
        const { data: insertedMeeting2 } = await supabase
          .from('momentum_meetings')
          .insert(meetingData as any)
          .select('id')
          .single();
        
        // Search is now ephemeral - no persistent index to update
        console.log(`Matched meeting "${meeting.title}" but auto-import disabled for account "${matchedAccount.name}"`);
      } else {
        // No account match at all — ignore immediately so they don't block the processing backlog.
        // If an account is later added with auto_import enabled and a matching SF ID,
        // the re-queue logic below will pick these up.
        const meetingData = await encryptMeetingFields({
          momentum_id: meeting.id,
          title: meeting.title,
          start_time: meeting.startTime,
          end_time: meeting.endTime,
          host_email: meeting.host?.email,
          host_name: meeting.host?.name,
          attendees: meeting.attendees,
          transcript_content: transcriptContent,
          salesforce_account_id: meeting.salesforceAccountId,
          salesforce_opportunity_id: meeting.salesforceOpportunityId,
          status: 'ignored',
          ignored_at: new Date().toISOString(),
        }, encryptionKey);
        const { data: insertedMeeting3 } = await supabase
          .from('momentum_meetings')
          .insert(meetingData as any)
          .select('id')
          .single();
        console.log(`No account match for meeting "${meeting.title}" (SF ID: ${meeting.salesforceAccountId || 'none'}) — marked ignored`);
      }

      newMeetingsCount++;
    }

    // Record sync state EARLY so it persists even if import processing times out
    await supabase
      .from('momentum_sync_state')
      .insert({
        last_sync_at: new Date().toISOString(),
        meetings_synced: newMeetingsCount,
      } as any);

    // PHASE 1: Import all meetings (DB-only, no AI analysis - fast)
    // Since we removed synchronous AI calls from processAutoImport, 
    // each import is now just DB operations (~2-5 seconds each), so we can process more.
    const MAX_IMPORTS = 60; // DB-only imports are fast - drain the backlog faster
    const BATCH_SIZE = 8; // Process 8 at a time concurrently (DB ops only)
    
    // Collect transcript IDs for post-import analysis
    const transcriptsToAnalyze: Array<{ transcriptReviewId: string; meetingTitle: string }> = [];
    
    // Process new meetings
    if (autoImportTasks.length > 0) {
      const tasksToProcess = autoImportTasks.slice(0, MAX_IMPORTS);
      console.log(`[Phase 1: Import] Processing ${tasksToProcess.length} of ${autoImportTasks.length} NEW meetings (DB-only, no AI)`);
      
      for (let i = 0; i < tasksToProcess.length; i += BATCH_SIZE) {
        const batch = tasksToProcess.slice(i, i + BATCH_SIZE);
        console.log(`[Phase 1: Import] Batch ${Math.floor(i/BATCH_SIZE) + 1}/${Math.ceil(tasksToProcess.length/BATCH_SIZE)}`);
        
        const results = await Promise.allSettled(
          batch.map(task => processAutoImport(
            task.supabaseUrl,
            task.serviceRoleKey,
            task.meeting,
            task.transcriptContent,
            task.matchedAccountId,
            task.momentumMeetingDbId
          ))
        );
        
        // Collect transcript IDs from successful imports
        for (const result of results) {
          if (result.status === 'fulfilled' && result.value?.transcriptReviewId) {
            transcriptsToAnalyze.push(result.value);
          }
        }
      }
    }
    
    // AUTOMATIC BACKLOG PROCESSING: Process existing queued meetings
    // First, auto-recover any meetings stuck in 'processing' for over 30 minutes
    // Only recover meetings that haven't exceeded the retry limit
    const { data: stuckMeetings, error: stuckErr } = await supabase
      .from('momentum_meetings')
      .update({ status: 'queued', updated_at: new Date().toISOString() } as any)
      .eq('status', 'processing')
      .lt('updated_at', new Date(Date.now() - 30 * 60 * 1000).toISOString())
      .lt('retry_count', 3)
      .select('id');
    
    if (!stuckErr && stuckMeetings && stuckMeetings.length > 0) {
      console.log(`[Backlog] Auto-recovered ${stuckMeetings.length} stuck 'processing' meetings back to 'queued'`);
    }
    
    // Mark meetings stuck in 'processing' with too many retries as 'failed'
    const { data: exhaustedMeetings } = await supabase
      .from('momentum_meetings')
      .update({ status: 'failed', updated_at: new Date().toISOString() } as any)
      .eq('status', 'processing')
      .lt('updated_at', new Date(Date.now() - 30 * 60 * 1000).toISOString())
      .gte('retry_count', 3)
      .select('id');
    
    if (exhaustedMeetings && exhaustedMeetings.length > 0) {
      console.warn(`[Backlog] Marked ${exhaustedMeetings.length} meetings as 'failed' (retry limit exceeded)`);
    }
    
    const remainingSlots = MAX_IMPORTS - Math.min(autoImportTasks.length, MAX_IMPORTS);
    if (remainingSlots > 0) {
      console.log(`[Backlog] Checking for existing queued meetings (${remainingSlots} slots available)`);
      
      const encryptionKey = Deno.env.get('TRANSCRIPT_ENCRYPTION_KEY') || '';
      
      const { data: queuedMeetings, error: queueErr } = await supabase
        .from('momentum_meetings')
        .select('id, momentum_id, title, title_encrypted, pii_encryption_iv, transcript_content, transcript_content_encrypted, matched_account_id, salesforce_opportunity_id, start_time, end_time, host_email, host_email_encrypted, host_name, host_name_encrypted, attendees, attendees_encrypted, salesforce_account_id, is_encrypted')
        .eq('status', 'queued')
        .not('matched_account_id', 'is', null)
        .order('created_at', { ascending: true })
        .limit(remainingSlots);
      
      if (queueErr) {
        console.error(`[Backlog] Error fetching queued meetings: ${queueErr.message}`);
      } else if (queuedMeetings && queuedMeetings.length > 0) {
        console.log(`[Backlog] Found ${queuedMeetings.length} queued meetings to process`);
        
        const backlogTasks: Array<{
          supabaseUrl: string;
          serviceRoleKey: string;
          meeting: MomentumMeeting;
          transcriptContent: string;
          matchedAccountId: string;
          momentumMeetingDbId: string;
        }> = [];
        
        for (const qm of queuedMeetings) {
          try {
            let title = qm.title;
            let transcriptContent = qm.transcript_content || '';
            let hostEmail = qm.host_email;
            let hostName = qm.host_name;
            let attendees = qm.attendees || [];
            
            if (qm.is_encrypted && qm.pii_encryption_iv) {
              if (qm.title_encrypted) title = await decryptValue(qm.title_encrypted, encryptionKey, qm.pii_encryption_iv);
              if (qm.transcript_content_encrypted) transcriptContent = await decryptValue(qm.transcript_content_encrypted, encryptionKey, qm.pii_encryption_iv);
              if (qm.host_email_encrypted) hostEmail = await decryptValue(qm.host_email_encrypted, encryptionKey, qm.pii_encryption_iv);
              if (qm.host_name_encrypted) hostName = await decryptValue(qm.host_name_encrypted, encryptionKey, qm.pii_encryption_iv);
              if (qm.attendees_encrypted) {
                try {
                  const decryptedAttendees = await decryptValue(qm.attendees_encrypted, encryptionKey, qm.pii_encryption_iv);
                  attendees = JSON.parse(decryptedAttendees);
                } catch (e) { console.error(`[Backlog] Failed to parse attendees for ${qm.id}:`, e); }
              }
            }
            
            // Skip meetings with no transcript content — nothing to analyze
            if (!transcriptContent || transcriptContent.trim().length === 0) {
              console.warn(`[Backlog] Skipping meeting ${qm.id} — no transcript content available, marking as 'failed'`);
              await supabase
                .from('momentum_meetings')
                .update({ status: 'failed', retry_count: 3 } as any)
                .eq('id', qm.id);
              continue;
            }
            
            backlogTasks.push({
              supabaseUrl: SUPABASE_URL!,
              serviceRoleKey: SUPABASE_SERVICE_ROLE_KEY!,
              meeting: {
                id: qm.momentum_id,
                title: title || 'Untitled Meeting',
                startTime: qm.start_time,
                endTime: qm.end_time || qm.start_time,
                host: { email: hostEmail || '', name: hostName || '' },
                attendees: attendees,
                transcript: { entries: [] },
                salesforceAccountId: qm.salesforce_account_id,
                salesforceOpportunityId: qm.salesforce_opportunity_id,
              },
              transcriptContent,
              matchedAccountId: qm.matched_account_id,
              momentumMeetingDbId: qm.id,
            });
          } catch (err) {
            console.error(`[Backlog] Error preparing meeting ${qm.id}:`, err);
          }
        }
        
        if (backlogTasks.length > 0) {
          console.log(`[Backlog] Processing ${backlogTasks.length} backlog meetings (DB-only)`);
          
          for (let i = 0; i < backlogTasks.length; i += BATCH_SIZE) {
            const batch = backlogTasks.slice(i, i + BATCH_SIZE);
            const results = await Promise.allSettled(
              batch.map(task => processAutoImport(
                task.supabaseUrl,
                task.serviceRoleKey,
                task.meeting,
                task.transcriptContent,
                task.matchedAccountId,
                task.momentumMeetingDbId
              ))
            );
            
            for (const result of results) {
              if (result.status === 'fulfilled' && result.value?.transcriptReviewId) {
                transcriptsToAnalyze.push(result.value);
              }
            }
          }
          
          autoImportQueued += backlogTasks.length;
        }
      } else {
        console.log(`[Backlog] No queued meetings found to process`);
      }
    }
    
    // PHASE 2: Trigger analysis SEQUENTIALLY as fire-and-forget
    // Each analysis runs in its own edge function invocation with its own timeout.
    // We fire them one-by-one with a small delay to avoid flooding the LLM.
    if (transcriptsToAnalyze.length > 0) {
      console.log(`[Phase 2: Analysis] Queuing ${transcriptsToAnalyze.length} transcripts for sequential analysis`);
      
      const triggerAnalysis = async () => {
        for (let i = 0; i < transcriptsToAnalyze.length; i++) {
          const { transcriptReviewId, meetingTitle } = transcriptsToAnalyze[i];
          console.log(`[Phase 2: Analysis] Triggering analysis ${i + 1}/${transcriptsToAnalyze.length}: "${meetingTitle}" (${transcriptReviewId})`);
          
          try {
            // Fire the streaming analysis - each call is its own edge function with its own timeout
            const analysisResp = await fetch(`${SUPABASE_URL}/functions/v1/analyze-transcript-streaming`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              },
              body: JSON.stringify({ transcriptReviewId }),
            });
            
            if (!analysisResp.ok) {
              console.error(`[Phase 2: Analysis] Failed for "${meetingTitle}": ${analysisResp.status}`);
            } else {
              // Consume the response to complete the request
              await analysisResp.text();
              console.log(`[Phase 2: Analysis] Completed for "${meetingTitle}"`);
            }
          } catch (analysisErr: any) {
            console.error(`[Phase 2: Analysis] Error for "${meetingTitle}":`, analysisErr.message || analysisErr);
          }
          
          // Small delay between analysis calls to avoid flooding the LLM
          if (i < transcriptsToAnalyze.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 2000)); // 2s gap between analyses
          }
        }
        
        // After all analyses complete, trigger enrichment for each
        for (const { transcriptReviewId, meetingTitle } of transcriptsToAnalyze) {
          try {
            console.log(`[Phase 2: Enrichment] Triggering enrichment for "${meetingTitle}"`);
            const enrichResp = await fetch(`${SUPABASE_URL}/functions/v1/enrich-transcript`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              },
              body: JSON.stringify({ transcriptReviewId }),
            });
            
            if (!enrichResp.ok) {
              console.error(`[Phase 2: Enrichment] Failed for "${meetingTitle}": ${enrichResp.status}`);
            } else {
              await enrichResp.text();
              console.log(`[Phase 2: Enrichment] Completed for "${meetingTitle}"`);
            }
          } catch (enrichErr: any) {
            console.error(`[Phase 2: Enrichment] Error for "${meetingTitle}":`, enrichErr.message || enrichErr);
          }
          
          // Delay between enrichment calls
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      };
      
      // Always use EdgeRuntime.waitUntil to keep function alive for background analysis.
      // The sequential triggerAnalysis() properly awaits each call before moving to the next.
      if (typeof EdgeRuntime !== 'undefined' && EdgeRuntime.waitUntil) {
        console.log(`[Phase 2: Analysis] Using EdgeRuntime.waitUntil for background analysis`);
        EdgeRuntime.waitUntil(triggerAnalysis());
      } else {
        // Fallback: fire each analysis as a standalone non-awaited fetch.
        // Do NOT use setTimeout — the runtime kills pending timers when the response is sent.
        // Each fetch triggers its own independent edge function invocation that runs to completion.
        console.log(`[Phase 2: Analysis] Firing ${transcriptsToAnalyze.length} analysis calls (independent edge function invocations)`);
        for (const { transcriptReviewId, meetingTitle } of transcriptsToAnalyze) {
          // Fire analysis — each call is its own edge function, so it runs independently
          fetch(`${SUPABASE_URL}/functions/v1/analyze-transcript-streaming`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({ transcriptReviewId }),
          }).catch(() => {});
          console.log(`[Phase 2: Analysis] Fired for "${meetingTitle}" (${transcriptReviewId})`);
        }
        // Enrichment will be triggered by retry-stuck-enrichments cron for any that need it
        console.log(`[Phase 2] Enrichment will be handled by retry-stuck-enrichments cron`);
      }
    }
    
    if (autoImportTasks.length > MAX_IMPORTS) {
      console.log(`[Auto-Import] ${autoImportTasks.length - MAX_IMPORTS} new meetings will be processed in subsequent syncs`);
    }

    // Create notification for team member meetings if any were detected
    if (teamMemberMeetings.length > 0) {
     // Group meetings by account for clearer notification
     const byAccount = teamMemberMeetings.reduce((acc, m) => {
       if (!acc[m.accountId]) {
         acc[m.accountId] = { accountName: m.accountName, count: 0 };
       }
       acc[m.accountId].count++;
       return acc;
     }, {} as Record<string, { accountName: string; count: number }>);
      
     const accountCount = Object.keys(byAccount).length;
     const accountSummary = Object.values(byAccount)
       .slice(0, 3)
       .map(a => `${a.accountName} (${a.count})`)
       .join(', ');
     
     const moreAccountsText = accountCount > 3 
       ? ` and ${accountCount - 3} more account${accountCount - 3 > 1 ? 's' : ''}` 
       : '';

      // Include first meeting's account/opportunity IDs for quick navigation
      const firstMeeting = teamMemberMeetings[0];
      
      await supabase
        .from('system_notifications')
        .insert({
          type: 'team_meeting_sync',
          title: `${teamMemberMeetings.length} Team Member Meeting${teamMemberMeetings.length > 1 ? 's' : ''} Synced`,
         message: `Accounts: ${accountSummary}${moreAccountsText}`,
          data: { 
            meetings: teamMemberMeetings,
            // Include first meeting's IDs for direct navigation when clicking notification
            account_id: firstMeeting?.accountId,
           // Total counts for display
           account_count: accountCount,
          },
          expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days
        } as any);

      console.log(`[Notifications] Created notification for ${teamMemberMeetings.length} team member meetings`);
    }

    // Sync state already recorded before import processing (see above)

    const result = {
      success: true,
      totalFetched: allMeetings.length,
      skippedDuplicates,
      skippedInternal,
      skippedNotTeam,
      newMeetings: newMeetingsCount,
      autoMatched: autoMatchedCount,
      autoImportQueued,
      accountsCreated,
      teamMemberMeetings: teamMemberMeetings.length,
      pendingReview: newMeetingsCount - autoMatchedCount,
    };

    console.log('Sync completed:', result);

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Sync error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
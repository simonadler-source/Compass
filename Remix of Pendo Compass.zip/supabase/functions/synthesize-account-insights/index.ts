import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getAIConfig } from "../_shared/ai-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Encryption helpers
function deriveKeyBytes(keyInput: string): Uint8Array {
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < raw.length && i < 32; i++) key[i] = raw[i];
  return key;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

// Generate a shared IV for a record
function generateIv(): string {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  return bytesToBase64(iv);
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

// Encrypt with a provided IV (to ensure all fields in a record use the same IV)
async function encryptWithIv(value: string, keyInput: string, ivBase64: string): Promise<string> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey(
    "raw", 
    keyBytes.buffer as ArrayBuffer, 
    "AES-GCM", 
    false, 
    ["encrypt"]
  );
  const iv = base64ToBytes(ivBase64);
  const plainBytes = new TextEncoder().encode(value);
  const cipherBytes = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv.buffer as ArrayBuffer }, 
    key, 
    plainBytes
  );
  return bytesToBase64(new Uint8Array(cipherBytes));
}

// Legacy function for backwards compatibility - generates new IV
async function encryptValue(value: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const iv = generateIv();
  const ciphertext = await encryptWithIv(value, keyInput, iv);
  return { ciphertext, iv };
}

// Decrypt a value using the encryption key and IV
async function decryptValue(ciphertext: string, keyInput: string, ivBase64: string): Promise<string> {
  try {
    const keyBytes = deriveKeyBytes(keyInput);
    const key = await crypto.subtle.importKey(
      "raw",
      keyBytes.buffer as ArrayBuffer,
      "AES-GCM",
      false,
      ["decrypt"]
    );
    const iv = base64ToBytes(ivBase64);
    const encryptedBytes = base64ToBytes(ciphertext);
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: new Uint8Array(iv).buffer as ArrayBuffer },
      key,
      new Uint8Array(encryptedBytes)
    );
    return new TextDecoder().decode(decrypted);
  } catch (e) {
    console.error("Decryption error:", e);
    return "";
  }
}

// Schema for strategic themes synthesis
const synthesisSchema = {
  type: "object",
  properties: {
    painThemes: {
      type: "array",
      items: {
        type: "object",
        properties: {
          themeName: { type: "string", description: "Short strategic theme name (3-6 words)" },
          description: { type: "string", description: "1-2 sentence executive description of this challenge area" },
          impactLevel: { type: "string", enum: ["critical", "high", "medium", "low"] },
          itemCount: { type: "integer", description: "How many raw pain points this consolidates" },
          supportingEvidence: { 
            type: "array", 
            items: { type: "string" },
            description: "2-3 specific examples from the raw data"
          }
        },
        required: ["themeName", "description", "impactLevel", "itemCount", "supportingEvidence"]
      },
      description: "3-5 strategic pain themes that consolidate all granular pain points"
    },
    initiatives: {
      type: "array",
      items: {
        type: "object",
        properties: {
          themeName: { type: "string", description: "Strategic initiative name (3-6 words)" },
          description: { type: "string", description: "1-2 sentence description of what they're trying to accomplish" },
          impactLevel: { type: "string", enum: ["critical", "high", "medium", "low"] },
          itemCount: { type: "integer", description: "How many raw use cases this consolidates" },
          supportingEvidence: { 
            type: "array", 
            items: { type: "string" },
            description: "2-3 specific use cases this encompasses"
          }
        },
        required: ["themeName", "description", "impactLevel", "itemCount", "supportingEvidence"]
      },
      description: "3-5 strategic initiatives that consolidate all granular use cases"
    },
    roiBridge: {
      type: "array",
      items: {
        type: "object",
        properties: {
          painTheme: { type: "string", description: "The challenge/pain theme this addresses" },
          useCase: { type: "string", description: "The use case or initiative that solves it" },
          metrics: { type: "array", items: { type: "string" }, description: "Relevant metrics discovered that quantify the impact (e.g., '50,000 MAUs', '3 FTE manual effort')" },
          projectedOutcome: { type: "string", description: "1 sentence projected ROI or business outcome if solved" }
        },
        required: ["painTheme", "useCase", "projectedOutcome"]
      },
      description: "2-4 Pain → Use Case → Metric bridges showing how challenges map to opportunities with quantified impact"
    },
    execSummary: {
      type: "object",
      properties: {
        narrative: { 
          type: "string", 
          description: "3-4 sentence executive summary. For PROSPECTS: lead with what they're trying to accomplish, the opportunity Pendo represents, and evaluation momentum. For CUSTOMERS: lead with relationship health, value delivered, and growth opportunities. Always balance challenges with opportunities."
        },
        healthIndicators: {
          type: "object",
          properties: {
            relationshipHealth: { type: "string", enum: ["strong", "stable", "at_risk", "critical"], description: "For prospects: based on engagement momentum and champion presence, NOT on whether they've bought yet" },
            engagementLevel: { type: "string", enum: ["high", "moderate", "low", "declining"] },
            opportunityMomentum: { type: "string", enum: ["accelerating", "steady", "stalled", "declining"] }
          }
        },
        keyRisks: {
          type: "array",
          items: { type: "string" },
          description: "Top 2-3 risks. For prospects: focus on deal execution risks (champion access, timeline, competition) NOT on 'they haven't bought yet' framing"
        },
        keyOpportunities: {
          type: "array",
          items: { type: "string" },
          description: "Top 2-3 expansion/value opportunities with quantified impact where metrics are available"
        }
      },
      required: ["narrative", "healthIndicators", "keyRisks", "keyOpportunities"]
    }
  },
  required: ["painThemes", "initiatives", "roiBridge", "execSummary"]
};

// Default prompt (used if not found in DB)
const DEFAULT_PROMPT = `You are an executive strategist synthesizing account intelligence for a Pre-Sales / Sales Engineering team at Pendo.

CRITICAL CONTEXT AWARENESS:
- The ACCOUNT TYPE field tells you whether this is a PROSPECT or CUSTOMER account.
- For PROSPECTS: These are companies evaluating Pendo. Natural caution and apprehension during a sales cycle is NORMAL, not a risk indicator. Focus on the OPPORTUNITY that exists if Pendo can solve their challenges.
- For CUSTOMERS: These are existing users. Focus on relationship health, value realization, and growth opportunities.

Given raw pain points, use cases, operational metrics, and account context, create:

## PAIN THEMES (3-5 max)
Consolidate all granular pain points into strategic themes that executives can act on.
- Each theme should represent a significant challenge area
- Merge related items (e.g., all "onboarding" related pains into one theme)
- Focus on business impact, not technical details
- Frame these as challenges the prospect/customer WANTS to solve (not as risks to us)

## STRATEGIC INITIATIVES (3-5 max)  
Consolidate all use cases into strategic initiatives they're pursuing.
- Each initiative should represent a key business objective
- Merge related use cases into coherent initiatives
- Focus on outcomes they want to achieve

## ROI BRIDGE (2-4 items)
Connect each major pain theme to the use case that addresses it, and where operational metrics have been discovered (e.g., MAU counts, headcount, time spent, costs), use those to project tangible ROI.
- Pain → Use Case → Metric → Projected Outcome
- Use real numbers from discovered metrics wherever possible
- If no metric exists for a bridge, state the qualitative outcome instead
- This is the core value narrative — make it compelling and specific

## EXECUTIVE SUMMARY
Write a "state of the account" briefing for a sales leader:

**For PROSPECT accounts:**
- Lead with what they're trying to accomplish and WHY Pendo is a compelling fit
- Highlight evaluation momentum (champion engagement, use case validation, proof progress)
- Balance risks with the scale of opportunity — a cautious prospect with 50K MAUs and 5 validated use cases is a strong opportunity, not an at-risk deal
- Natural sales cycle friction (budget concerns, stakeholder alignment, timeline uncertainty) should be framed as execution items, not health risks
- Include ROI potential based on discovered metrics

**For CUSTOMER accounts:**
- Lead with relationship health and value delivered
- Highlight expansion and growth opportunities
- Flag genuine retention risks if present

Be concise, strategic, and actionable. Avoid generic negative framing.`;

async function getPassPrompt(supabase: any, passKey: string): Promise<string> {
  try {
    // Try to fetch from active pipeline's passes
    const { data: pipeline } = await supabase
      .from("analysis_pipelines")
      .select("id")
      .eq("is_active", true)
      .eq("is_default", true)
      .maybeSingle();

    if (!pipeline) {
      console.log(`[Synthesize] No active default pipeline found, using default prompt`);
      return DEFAULT_PROMPT;
    }

    const { data: pass } = await supabase
      .from("analysis_passes")
      .select("system_prompt")
      .eq("pipeline_id", pipeline.id)
      .eq("pass_key", passKey)
      .eq("status", "active")
      .maybeSingle();

    if (pass?.system_prompt) {
      console.log(`[Synthesize] Using prompt from pipeline pass: ${passKey}`);
      return pass.system_prompt;
    }

    console.log(`[Synthesize] Pass '${passKey}' not found in pipeline, using default prompt`);
    return DEFAULT_PROMPT;
  } catch (e) {
    console.error(`[Synthesize] Error fetching pass prompt:`, e);
    return DEFAULT_PROMPT;
  }
}

async function synthesizeInsights(context: string, aiConfig: any, prompt: string): Promise<any> {
  const MAX_RETRIES = 3;
  const BACKOFF_MS = [1000, 2000, 4000];

  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    const response = await fetch(aiConfig.endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${aiConfig.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: aiConfig.model,
        messages: [
          { role: "system", content: prompt },
          { role: "user", content: context }
        ],
        tools: [{
          type: "function",
          function: {
            name: "synthesize_account_insights",
            description: "Synthesize strategic themes and executive summary from raw account data",
            parameters: synthesisSchema
          }
        }],
        tool_choice: { type: "function", function: { name: "synthesize_account_insights" } }
      }),
    });

    if (response.ok) {
      const data = await response.json();
      return JSON.parse(data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}");
    }

    const errorText = await response.text();
    console.error(`[Synthesize] AI API attempt ${attempt + 1}/${MAX_RETRIES} failed (${response.status}):`, errorText);

    // Retry on 503 (service unavailable) and 429 (rate limit)
    if ((response.status === 503 || response.status === 429) && attempt < MAX_RETRIES - 1) {
      const delay = BACKOFF_MS[attempt] || 4000;
      console.log(`[Synthesize] Retrying in ${delay}ms...`);
      await new Promise(r => setTimeout(r, delay));
      continue;
    }

    throw new Error(`AI API failed: ${response.status}`);
  }

  throw new Error("AI API failed after all retries");
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    const { accountId } = await req.json();
    
    if (!accountId) {
      return new Response(JSON.stringify({ error: "accountId required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`[Synthesize] Starting for account ${accountId}`);

    // Fetch account details
    const { data: account } = await supabase
      .from("accounts")
      .select("name, industry, status, stage")
      .eq("id", accountId)
      .single();

    // Fetch pain points - need to decrypt encrypted fields
    // Note: pain_point is encrypted (NULL in plaintext column)
    const encryptionKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || "";
    
    // Include opportunity_id so we can link themes to opportunities
    let { data: rawPainPoints } = await supabase
      .from("account_pain_points")
      .select("pain_point, pain_point_encrypted, pain_category, business_impact, business_impact_encrypted, severity, encryption_iv, opportunity_id")
      .eq("account_id", accountId);

    let { data: rawUseCases } = await supabase
      .from("account_use_cases")
      .select("use_case, use_case_encrypted, functional_area, priority, status, encryption_iv, opportunity_id")
      .eq("account_id", accountId);

    // Decrypt pain points - include opportunity_id for linking
    let painPoints: Array<{ pain_point: string; pain_category: string; business_impact: string[]; severity: string; opportunity_id?: string }> = [];
    if (rawPainPoints && encryptionKey) {
      for (const p of rawPainPoints) {
        let painText = p.pain_point;
        let impactArr = p.business_impact;
        
        if (p.pain_point_encrypted && p.encryption_iv) {
          painText = await decryptValue(p.pain_point_encrypted, encryptionKey, p.encryption_iv);
        }
        if (p.business_impact_encrypted && p.encryption_iv) {
          try {
            const decryptedImpact = await decryptValue(p.business_impact_encrypted, encryptionKey, p.encryption_iv);
            impactArr = JSON.parse(decryptedImpact);
          } catch (e) {
            // Keep original
          }
        }
        
        if (painText) {
          painPoints.push({
            pain_point: painText,
            pain_category: p.pain_category || 'general',
            business_impact: impactArr || [],
            severity: p.severity || 'medium',
            opportunity_id: p.opportunity_id || undefined,
          });
        }
      }
    } else if (rawPainPoints) {
      // No encryption key - use plaintext (legacy data)
      painPoints = rawPainPoints.filter(p => p.pain_point).map(p => ({
        pain_point: p.pain_point,
        pain_category: p.pain_category || 'general',
        business_impact: p.business_impact || [],
        severity: p.severity || 'medium',
        opportunity_id: p.opportunity_id || undefined,
      }));
    }

    // Decrypt use cases - include opportunity_id for linking
    let useCases: Array<{ use_case: string; functional_area: string; priority: string; status: string; opportunity_id?: string }> = [];
    if (rawUseCases && encryptionKey) {
      for (const u of rawUseCases) {
        let useCaseText = u.use_case;
        
        if (u.use_case_encrypted && u.encryption_iv) {
          useCaseText = await decryptValue(u.use_case_encrypted, encryptionKey, u.encryption_iv);
        }
        
        if (useCaseText) {
          useCases.push({
            use_case: useCaseText,
            functional_area: u.functional_area || 'General',
            priority: u.priority || 'medium',
            status: u.status || 'identified',
            opportunity_id: u.opportunity_id || undefined,
          });
        }
      }
    } else if (rawUseCases) {
      // No encryption key - use plaintext (legacy data)
      useCases = rawUseCases.filter(u => u.use_case).map(u => ({
        use_case: u.use_case,
        functional_area: u.functional_area || 'General',
        priority: u.priority || 'medium',
        status: u.status || 'identified',
        opportunity_id: u.opportunity_id || undefined,
      }));
    }

    console.log(`[Synthesize] Decrypted ${painPoints.length} pain points, ${useCases.length} use cases`);

    // If tables are empty, try to backfill from transcript_reviews.extracted_insights
    // OR extract directly from transcript_content if insights are null
    if ((!painPoints?.length || !useCases?.length)) {
      console.log(`[Synthesize] Tables sparse - backfilling from transcript insights`);
      
      const { data: transcripts } = await supabase
        .from("transcript_reviews")
        .select(`
          id, extracted_insights, created_at, momentum_meeting_id, opportunity_id,
          momentum_meetings (start_time, created_at)
        `)
        .eq("final_account_id", accountId)
        .eq("status", "approved");

      if (transcripts && transcripts.length > 0) {
        for (const transcript of transcripts) {
          // Derive the meeting date for accurate historical tracking
          const linkedMeeting = transcript.momentum_meetings as unknown as { start_time: string; created_at: string } | null;
          const eventOccurredAt = linkedMeeting?.start_time
            || linkedMeeting?.created_at
            || transcript.created_at
            || new Date().toISOString();
          
          const insights = transcript.extracted_insights as any;
          
          // Skip transcripts without extracted insights (content extraction removed to prevent timeouts)
          if (!insights) {
            console.log(`[Synthesize] Skipping transcript ${transcript.id} - no extracted_insights`);
            continue;
          }

          const encryptionKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || "";

          // Backfill pain points with encryption
          const transcriptPainPoints = insights.painPoints || [];
          for (const pp of transcriptPainPoints) {
            const painText = typeof pp === 'string' ? pp : (pp.description || pp.pain_point || String(pp));
            if (!painText) continue;

            const { ciphertext, iv } = await encryptValue(painText, encryptionKey);
            
            await supabase.from("account_pain_points").insert({
              account_id: accountId,
              opportunity_id: transcript.opportunity_id || null,
              pain_point: null,
              pain_point_encrypted: ciphertext,
              pain_category: typeof pp === 'object' ? pp.painCategory : 'operational_friction',
              severity: typeof pp === 'object' ? pp.severity : 'medium',
              source: 'transcript_analysis',
              source_transcript_id: transcript.id,
              confidence_score: 0.5,
              encryption_iv: iv,
              is_encrypted: true,
              created_at: eventOccurredAt,
            });
          }

          // Backfill use cases with encryption
          const transcriptUseCases = insights.useCases || [];
          for (const uc of transcriptUseCases) {
            const ucText = typeof uc === 'string' ? uc : (uc.description || uc.useCase || String(uc));
            if (!ucText) continue;

            const { ciphertext, iv } = await encryptValue(ucText, encryptionKey);
            
            await supabase.from("account_use_cases").insert({
              account_id: accountId,
              opportunity_id: transcript.opportunity_id || null,
              use_case: null,
              use_case_encrypted: ciphertext,
              functional_area: typeof uc === 'object' ? (uc.functionalArea || 'General') : 'General',
              status: 'identified',
              priority: typeof uc === 'object' ? (uc.priority || 'medium') : 'medium',
              source: 'transcript_analysis',
              source_transcript_id: transcript.id,
              confidence_score: 0.5,
              encryption_iv: iv,
              is_encrypted: true,
              created_at: eventOccurredAt,
            });
          }
        }

        // Re-fetch and decrypt after backfill
        const { data: refreshedRawPainPoints } = await supabase
          .from("account_pain_points")
          .select("pain_point, pain_point_encrypted, pain_category, business_impact, business_impact_encrypted, severity, encryption_iv")
          .eq("account_id", accountId);
        
        painPoints = [];
        if (refreshedRawPainPoints && encryptionKey) {
          for (const p of refreshedRawPainPoints) {
            let painText = p.pain_point;
            if (p.pain_point_encrypted && p.encryption_iv) {
              painText = await decryptValue(p.pain_point_encrypted, encryptionKey, p.encryption_iv);
            }
            if (painText) {
              painPoints.push({
                pain_point: painText,
                pain_category: p.pain_category || 'general',
                business_impact: p.business_impact || [],
                severity: p.severity || 'medium',
              });
            }
          }
        }

        const { data: refreshedRawUseCases } = await supabase
          .from("account_use_cases")
          .select("use_case, use_case_encrypted, functional_area, priority, status, encryption_iv")
          .eq("account_id", accountId);
        
        useCases = [];
        if (refreshedRawUseCases && encryptionKey) {
          for (const u of refreshedRawUseCases) {
            let useCaseText = u.use_case;
            if (u.use_case_encrypted && u.encryption_iv) {
              useCaseText = await decryptValue(u.use_case_encrypted, encryptionKey, u.encryption_iv);
            }
            if (useCaseText) {
              useCases.push({
                use_case: useCaseText,
                functional_area: u.functional_area || 'General',
                priority: u.priority || 'medium',
                status: u.status || 'identified',
              });
            }
          }
        }

        console.log(`[Synthesize] Backfill complete: ${painPoints?.length || 0} pains, ${useCases?.length || 0} use cases`);
      }
    }

    // ========== BACKFILL METRICS FROM EXTRACTED INSIGHTS ==========
    // Check if we have any metrics for this account
    const { data: existingMetrics } = await supabase
      .from("account_metrics")
      .select("id")
      .eq("account_id", accountId)
      .limit(1);
    
    if (!existingMetrics || existingMetrics.length === 0) {
      console.log(`[Synthesize] No metrics found - backfilling from transcript insights`);
      
      const { data: metricsTranscripts } = await supabase
        .from("transcript_reviews")
        .select(`
          id, extracted_insights, created_at, opportunity_id, momentum_meeting_id,
          momentum_meetings (start_time, created_at)
        `)
        .eq("final_account_id", accountId)
        .eq("status", "approved");
      
      let metricsBackfilled = 0;
      
      if (metricsTranscripts && metricsTranscripts.length > 0) {
        for (const transcript of metricsTranscripts) {
          const insights = transcript.extracted_insights as any;
          if (!insights) continue;
          
          // Derive the event timestamp from meeting
          const linkedMeeting = transcript.momentum_meetings as unknown as { start_time: string; created_at: string } | null;
          const eventOccurredAt = linkedMeeting?.start_time
            || linkedMeeting?.created_at
            || transcript.created_at
            || new Date().toISOString();
          
          // Extract operationalMetrics from stage_assessment pass
          const metrics = insights.operationalMetrics || [];
          
          for (const m of metrics) {
            if (!m.metricName || !m.metricValue) continue;
            
            // Check for duplicates by metric name + value
            const { data: existingMetric } = await supabase
              .from("account_metrics")
              .select("id")
              .eq("account_id", accountId)
              .eq("metric_name", m.metricName)
              .eq("metric_value", m.metricValue)
              .maybeSingle();
            
            if (existingMetric) continue;
            
            await supabase.from("account_metrics").insert({
              account_id: accountId,
              opportunity_id: transcript.opportunity_id || null,
              source_transcript_id: transcript.id,
              metric_name: m.metricName,
              metric_value: m.metricValue,
              metric_numeric_value: m.metricNumericValue || null,
              metric_category: m.metricCategory || 'general',
              confidence_score: m.confidence || 0.5,
              needs_review: m.needsReview ?? true,
              context: m.context || null,
              source: 'transcript_analysis',
              created_at: eventOccurredAt,
            });
            metricsBackfilled++;
          }
        }
        console.log(`[Synthesize] Backfilled ${metricsBackfilled} metrics from transcripts`);
      }
    }

    // Fetch opportunities with more context for health analysis
    const { data: opportunities } = await supabase
      .from("opportunities")
      .select("id, name, stage, pre_sales_stage, sales_stage, value, last_meeting_at, created_at, close_date, engagement_score, momentum_score, relationship_status, is_archived")
      .eq("account_id", accountId);

    // Fetch discovered operational metrics for ROI narrative
    const { data: accountMetrics } = await supabase
      .from("account_metrics")
      .select("metric_name, metric_value, metric_numeric_value, metric_category, context, confidence_score")
      .eq("account_id", accountId)
      .order("confidence_score", { ascending: false })
      .limit(30);

    // Fetch recent activities with more detail
    const { data: activities } = await supabase
      .from("opportunity_activities")
      .select("title, activity_date, sentiment_label, activity_type_id")
      .eq("account_id", accountId)
      .order("activity_date", { ascending: false })
      .limit(20);

    // Fetch stakeholder data for relationship health assessment
    const { data: stakeholders } = await supabase
      .from("account_contacts")
      .select("stakeholder_type, champion_score, sentiment, influence_level, is_ignored")
      .eq("account_id", accountId)
      .eq("is_ignored", false);

    // Check if we have ANY meaningful data to synthesize from
    const hasOpportunities = opportunities && opportunities.length > 0;
    const hasStakeholders = stakeholders && stakeholders.length > 0;
    const hasActivities = activities && activities.length > 0;
    const hasPainPointsOrUseCases = (painPoints?.length || 0) > 0 || (useCases?.length || 0) > 0;
    
    // Allow synthesis if we have at least SOME data to work with
    if (!hasPainPointsOrUseCases && !hasOpportunities && !hasStakeholders && !hasActivities) {
      return new Response(JSON.stringify({ 
        error: "No data to synthesize. Import some transcripts or add opportunities/contacts first.",
        painPoints: painPoints?.length || 0,
        useCases: useCases?.length || 0,
        opportunities: opportunities?.length || 0,
        stakeholders: stakeholders?.length || 0,
        activities: activities?.length || 0
      }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    
    console.log(`[Synthesize] Data available: ${painPoints?.length || 0} pains, ${useCases?.length || 0} use cases, ${opportunities?.length || 0} opps, ${stakeholders?.length || 0} contacts, ${activities?.length || 0} activities`);

    // Categorize opportunities by inferred type based on stage and value patterns
    const categorizeOpportunity = (opp: any) => {
      const stage = opp.stage?.toLowerCase() || '';
      const salesStage = opp.sales_stage?.toLowerCase() || '';
      const name = opp.name?.toLowerCase() || '';
      
      if (name.includes('renewal') || name.includes('renew')) return 'renewal';
      if (name.includes('expansion') || name.includes('upsell') || name.includes('cross-sell')) return 'expansion';
      if (name.includes('new') || stage === 'discovery' || salesStage?.includes('stage_0') || salesStage?.includes('stage_1')) return 'new_business';
      if (salesStage?.includes('stage_5') || salesStage?.includes('stage_6')) return 'existing_customer';
      return 'active_deal';
    };

    // Determine account type: PROSPECT vs CUSTOMER
    const hasRenewals = (opportunities || []).some(o => categorizeOpportunity(o) === 'renewal');
    const hasExpansions = (opportunities || []).some(o => categorizeOpportunity(o) === 'expansion');
    const hasExistingCustomer = (opportunities || []).some(o => categorizeOpportunity(o) === 'existing_customer');
    const isCustomerAccount = hasRenewals || hasExpansions || hasExistingCustomer;
    const accountType = isCustomerAccount ? 'CUSTOMER' : 'PROSPECT';

    const now = new Date();
    const getRecencyLabel = (dateStr: string | null) => {
      if (!dateStr) return 'never';
      const date = new Date(dateStr);
      const daysDiff = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
      if (daysDiff <= 7) return 'this_week';
      if (daysDiff <= 30) return 'this_month';
      if (daysDiff <= 90) return 'this_quarter';
      return 'stale';
    };

    const enrichedOpportunities = (opportunities || []).map(o => ({
      name: o.name,
      inferredType: categorizeOpportunity(o),
      stage: o.stage,
      preSalesStage: o.pre_sales_stage,
      salesStage: o.sales_stage,
      value: o.value,
      lastMeetingRecency: getRecencyLabel(o.last_meeting_at),
      lastMeetingAt: o.last_meeting_at,
      closeDate: o.close_date,
      engagementScore: o.engagement_score,
      momentumScore: o.momentum_score,
      relationshipStatus: o.relationship_status,
    }));

    const oppsByType = enrichedOpportunities.reduce((acc, o) => {
      acc[o.inferredType] = acc[o.inferredType] || [];
      acc[o.inferredType].push(o);
      return acc;
    }, {} as Record<string, typeof enrichedOpportunities>);

    const last30DaysActivities = (activities || []).filter(a => {
      const date = new Date(a.activity_date);
      return (now.getTime() - date.getTime()) < 30 * 24 * 60 * 60 * 1000;
    });
    const last7DaysActivities = last30DaysActivities.filter(a => {
      const date = new Date(a.activity_date);
      return (now.getTime() - date.getTime()) < 7 * 24 * 60 * 60 * 1000;
    });

    const stakeholderSummary = {
      total: stakeholders?.length || 0,
      champions: stakeholders?.filter(s => (s.champion_score || 0) >= 70).length || 0,
      advocates: stakeholders?.filter(s => (s.champion_score || 0) >= 40 && (s.champion_score || 0) < 70).length || 0,
      influential: stakeholders?.filter(s => (s.influence_level || 0) >= 7).length || 0,
      positiveSentiment: stakeholders?.filter(s => (s.sentiment || 0) >= 6).length || 0,
      negativeSentiment: stakeholders?.filter(s => (s.sentiment || 0) <= 4 && s.sentiment !== null).length || 0,
    };

    // Format discovered metrics for ROI context
    const metricsContext = (accountMetrics || []).map(m => 
      `- ${m.metric_name}: ${m.metric_value}${m.metric_category ? ` [${m.metric_category}]` : ''}${m.context ? ` — ${m.context}` : ''}`
    ).join('\n');

    const context = `
## ACCOUNT: ${account?.name || "Unknown"}
Industry: ${account?.industry || "Not specified"}
Status: ${account?.status || "Unknown"}
Stage: ${account?.stage || "Unknown"}
**ACCOUNT TYPE: ${accountType}** ${isCustomerAccount ? '(Existing customer with renewals/expansions)' : '(Prospect evaluating Pendo — natural sales cycle caution is EXPECTED and NORMAL)'}

## OPPORTUNITY PORTFOLIO ANALYSIS
Total Opportunities: ${opportunities?.length || 0}

### By Inferred Type:
${Object.entries(oppsByType).map(([type, opps]) => `
**${type.replace(/_/g, ' ').toUpperCase()}** (${opps.length}):
${opps.map(o => `  - ${o.name}
    Stage: ${o.stage || o.salesStage || 'unknown'} | Pre-sales: ${o.preSalesStage || 'N/A'}
    Value: ${o.value ? `$${o.value.toLocaleString()}` : 'TBD'}
    Last Engagement: ${o.lastMeetingRecency} (${o.lastMeetingAt || 'never'})
    Health: Engagement=${o.engagementScore ?? 'N/A'}, Momentum=${o.momentumScore ?? 'N/A'}, Relationship=${o.relationshipStatus ?? 'N/A'}`).join('\n')}`).join('\n')}

### Portfolio Health Signals:
- Opportunities with recent engagement (this week): ${enrichedOpportunities.filter(o => o.lastMeetingRecency === 'this_week').length}
- Stale opportunities (>90 days since meeting): ${enrichedOpportunities.filter(o => o.lastMeetingRecency === 'stale').length}
- Deals with close date this quarter: ${enrichedOpportunities.filter(o => {
  if (!o.closeDate) return false;
  const closeDate = new Date(o.closeDate);
  const quarterEnd = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3 + 3, 0);
  return closeDate <= quarterEnd;
}).length}

## DISCOVERED OPERATIONAL METRICS (${accountMetrics?.length || 0}):
${metricsContext || "No metrics discovered yet"}
USE THESE METRICS in the ROI Bridge to quantify the business impact of solving their challenges.

## ENGAGEMENT METRICS
- Activities in last 7 days: ${last7DaysActivities.length}
- Activities in last 30 days: ${last30DaysActivities.length}
- Sentiment breakdown (last 20): Positive=${activities?.filter(a => a.sentiment_label === 'positive').length || 0}, Neutral=${activities?.filter(a => a.sentiment_label === 'neutral').length || 0}, Negative=${activities?.filter(a => a.sentiment_label === 'negative').length || 0}

## STAKEHOLDER LANDSCAPE
Total Contacts: ${stakeholderSummary.total}
- Champions (score ≥70): ${stakeholderSummary.champions}
- Advocates (score 40-69): ${stakeholderSummary.advocates}
- High Influence (≥7): ${stakeholderSummary.influential}
- Positive Sentiment (≥6): ${stakeholderSummary.positiveSentiment}
- Negative Sentiment (≤4): ${stakeholderSummary.negativeSentiment}

## RAW PAIN POINTS (${painPoints?.length || 0}):
${painPoints?.map(p => `- [${p.pain_category}/${p.severity}] ${p.pain_point}`).join("\n") || "None"}

## RAW USE CASES (${useCases?.length || 0}):
${useCases?.map(u => `- [${u.priority}/${u.status}] ${u.use_case}`).join("\n") || "None"}

## RECENT ENGAGEMENT TIMELINE (${activities?.length || 0}):
${activities?.slice(0, 10).map(a => `- ${a.activity_date}: ${a.title || "Meeting"} (${a.sentiment_label || "neutral"})`).join("\n") || "None"}

## SYNTHESIS GUIDANCE
**Account type is ${accountType}.**

${isCustomerAccount ? `CUSTOMER ACCOUNT GUIDANCE:
1. Renewal opportunities: High weight for relationship health — stale renewals are critical risks
2. Expansion opportunities: Indicate successful relationship — weigh positively
3. Stakeholder coverage: Champion presence is critical for renewals
4. Engagement recency: Recent, positive engagements signal healthy momentum
5. Use discovered metrics to quantify value already delivered and expansion potential` : `PROSPECT ACCOUNT GUIDANCE:
1. DO NOT mark as "at_risk" simply because they haven't bought yet — they are evaluating
2. Natural sales cycle behaviors (budget scrutiny, multiple stakeholders, timeline uncertainty) are NORMAL, not negative signals
3. Focus on OPPORTUNITY STRENGTH: How many use cases validated? How strong are the champions? How compelling is the ROI based on discovered metrics?
4. Frame challenges as "problems Pendo can solve" not "risks to the deal"
5. Use discovered metrics (MAU counts, headcount, time spent, costs) to build a compelling ROI narrative in the ROI bridge
6. A prospect with multiple validated use cases, engaged stakeholders, and quantifiable metrics is a STRONG opportunity
7. Only flag genuine execution risks: competitor displacement threat, loss of champion, complete disengagement (>90 days no contact)`}
`;

    console.log(`[Synthesize] Context built: ${painPoints?.length || 0} pains, ${useCases?.length || 0} use cases, ${opportunities?.length || 0} opps, ${stakeholders?.length || 0} contacts`);

    // Get AI config using the shared provider framework
    const aiConfig = await getAIConfig();

    // Get the prompt from the pipeline (pass_key: account_synthesis)
    const synthesisPrompt = await getPassPrompt(supabase, "account_synthesis");

    // Call AI to synthesize
    const synthesis = await synthesizeInsights(context, aiConfig, synthesisPrompt);
    console.log(`[Synthesize] Got ${synthesis.painThemes?.length} pain themes, ${synthesis.initiatives?.length} initiatives`);

    // Clear existing themes for this account
    await supabase
      .from("account_strategic_themes")
      .delete()
      .eq("account_id", accountId);

    // Use the encryptionKey already defined above

    // Collect all unique opportunity IDs from pain points for linking to pain themes
    const painPointOpportunityIds = [...new Set(
      painPoints.filter(p => p.opportunity_id).map(p => p.opportunity_id!)
    )];
    
    // Collect all unique opportunity IDs from use cases for linking to initiative themes
    const useCaseOpportunityIds = [...new Set(
      useCases.filter(u => u.opportunity_id).map(u => u.opportunity_id!)
    )];
    
    console.log(`[Synthesize] Linking pain themes to ${painPointOpportunityIds.length} opportunities, initiatives to ${useCaseOpportunityIds.length} opportunities`);

    // Save pain themes with encryption - use shared IV for all fields in each record
    for (const theme of synthesis.painThemes || []) {
      const iv = generateIv(); // Generate one IV per record
      const nameCipher = await encryptWithIv(theme.themeName, encryptionKey, iv);
      const descCipher = await encryptWithIv(theme.description, encryptionKey, iv);
      const evidenceCipher = await encryptWithIv(JSON.stringify(theme.supportingEvidence || []), encryptionKey, iv);
      
      await supabase.from("account_strategic_themes").insert({
        account_id: accountId,
        theme_name: null,
        theme_name_encrypted: nameCipher,
        theme_type: "pain_theme",
        description: null,
        description_encrypted: descCipher,
        supporting_evidence: null,
        supporting_evidence_encrypted: evidenceCipher,
        impact_level: theme.impactLevel,
        item_count: theme.itemCount || 0,
        encryption_iv: iv,
        is_encrypted: true,
        linked_opportunity_ids: painPointOpportunityIds.length > 0 ? painPointOpportunityIds : null,
      });
    }

    // Save initiative themes with encryption - use shared IV for all fields in each record
    for (const init of synthesis.initiatives || []) {
      const iv = generateIv(); // Generate one IV per record
      const nameCipher = await encryptWithIv(init.themeName, encryptionKey, iv);
      const descCipher = await encryptWithIv(init.description, encryptionKey, iv);
      const evidenceCipher = await encryptWithIv(JSON.stringify(init.supportingEvidence || []), encryptionKey, iv);
      
      await supabase.from("account_strategic_themes").insert({
        account_id: accountId,
        theme_name: null,
        theme_name_encrypted: nameCipher,
        theme_type: "initiative",
        description: null,
        description_encrypted: descCipher,
        supporting_evidence: null,
        supporting_evidence_encrypted: evidenceCipher,
        impact_level: init.impactLevel,
        item_count: init.itemCount || 0,
        encryption_iv: iv,
        is_encrypted: true,
        linked_opportunity_ids: useCaseOpportunityIds.length > 0 ? useCaseOpportunityIds : null,
      });
    }

    // Upsert executive summary with encryption - use shared IV for all fields
    const execSummary = synthesis.execSummary || {};
    const narrativeText = execSummary.narrative || "No summary generated";
    const summaryIv = generateIv(); // Generate one IV for exec summary
    const narrativeCipher = await encryptWithIv(narrativeText, encryptionKey, summaryIv);
    const healthCipher = await encryptWithIv(JSON.stringify(execSummary.healthIndicators || {}), encryptionKey, summaryIv);
    const risksCipher = await encryptWithIv(JSON.stringify(execSummary.keyRisks || []), encryptionKey, summaryIv);
    const oppsCipher = await encryptWithIv(JSON.stringify(execSummary.keyOpportunities || []), encryptionKey, summaryIv);
    
    await supabase.from("account_exec_summaries").upsert({
      account_id: accountId,
      summary_narrative: null,
      summary_narrative_encrypted: narrativeCipher,
      health_indicators: null,
      health_indicators_encrypted: healthCipher,
      key_risks: null,
      key_risks_encrypted: risksCipher,
      key_opportunities: null,
      key_opportunities_encrypted: oppsCipher,
      engagement_summary: {},
      generated_at: new Date().toISOString(),
      encryption_iv: summaryIv,
      is_encrypted: true,
    }, { onConflict: "account_id" });

    console.log(`[Synthesize] Saved themes and exec summary for ${accountId}`);

    return new Response(JSON.stringify({
      success: true,
      painThemes: synthesis.painThemes?.length || 0,
      initiatives: synthesis.initiatives?.length || 0,
      execSummary: !!synthesis.execSummary
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("[Synthesize] Error:", error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : String(error) 
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getAIConfig } from "../_shared/ai-provider.ts";
import { 
  getDefaultPipeline, 
  FALLBACK_SCHEMAS, 
  FALLBACK_PROMPTS,
} from "../_shared/prompt-library.ts";
import {
  createInsightSnapshots,
  saveInsightSnapshots,
  addInternalTeamMembers,
  extractInternalTeamMembers,
} from "../_shared/insight-store.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const BATCH_SIZE = 5;
const MAX_ATTEMPTS = 3;

// Encryption helpers (kept for legacy table compatibility)
function deriveKeyBytes(keyInput: string): Uint8Array {
  if (/^[0-9a-fA-F]+$/.test(keyInput) && keyInput.length >= 64) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 64; i += 2) {
      bytes[i / 2] = parseInt(keyInput.substring(i, i + 2), 16);
    }
    return bytes;
  }
  const encoder = new TextEncoder();
  const raw = encoder.encode(keyInput);
  const key = new Uint8Array(32);
  for (let i = 0; i < raw.length && i < 32; i++) key[i] = raw[i];
  return key;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

async function encryptValue(value: string, keyInput: string): Promise<{ ciphertext: string; iv: string }> {
  const keyBytes = deriveKeyBytes(keyInput);
  const key = await crypto.subtle.importKey("raw", keyBytes.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plainBytes = new TextEncoder().encode(value);
  const cipherBytes = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plainBytes);
  return { ciphertext: bytesToBase64(new Uint8Array(cipherBytes)), iv: bytesToBase64(iv) };
}

// Execute analysis pass with fallback
async function executeAnalysisPass(
  passKey: string,
  transcript: string,
  context: Record<string, any>,
  aiConfig: any,
  pipeline: any
): Promise<any> {
  const pass = pipeline?.passes?.find((p: any) => p.pass_key === passKey);
  const systemPrompt = pass?.system_prompt || FALLBACK_PROMPTS[passKey as keyof typeof FALLBACK_PROMPTS] || FALLBACK_PROMPTS.core_extraction;
  const outputSchema = pass?.output_schema || FALLBACK_SCHEMAS[passKey as keyof typeof FALLBACK_SCHEMAS] || FALLBACK_SCHEMAS.core_extraction;
  
  const contextString = Object.entries(context)
    .filter(([_, v]) => v !== undefined && v !== null)
    .map(([k, v]) => `${k}: ${JSON.stringify(v)}`)
    .join('\n');

  const userMessage = contextString 
    ? `Context:\n${contextString}\n\nAnalyze:\n\n${transcript.slice(0, 100000)}`
    : `Analyze:\n\n${transcript.slice(0, 100000)}`;

  const response = await fetch(aiConfig.endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${aiConfig.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: aiConfig.model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ],
      tools: [{
        type: "function",
        function: {
          name: `extract_${passKey}`,
          description: `Extract ${passKey} analysis`,
          parameters: outputSchema
        }
      }],
      tool_choice: { type: "function", function: { name: `extract_${passKey}` } }
    }),
  });

  if (!response.ok) {
    throw new Error(`AI API failed: ${response.status}`);
  }

  const data = await response.json();
  return JSON.parse(data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}");
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    const { action, accountIds, analysisTypes } = await req.json().catch(() => ({ action: "process" }));

    // Action: prepare - Queue transcripts for reanalysis
    if (action === "prepare") {
      console.log("[UnifiedQueue] Preparing queue for accounts:", accountIds || "all");
      
      // Use the full reanalysis preparation if no specific types
      if (!analysisTypes || analysisTypes.includes("full")) {
        const { data, error } = await supabase.rpc("prepare_full_reanalysis", {
          p_account_ids: accountIds || null,
        });

        if (error) throw error;

        return new Response(JSON.stringify({
          success: true,
          transcripts_queued: data?.[0]?.transcripts_queued || 0,
          insights_deleted: data?.[0]?.insights_deleted || {},
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      } else {
        // Partial reanalysis - use the incremental queue
        const { data: count, error } = await supabase.rpc("populate_reanalysis_queue");
        if (error) throw error;

        return new Response(JSON.stringify({
          success: true,
          transcripts_queued: count || 0,
          mode: "incremental",
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    // Action: status - Get unified queue status
    if (action === "status") {
      const [fullQueue, incrementalQueue] = await Promise.all([
        supabase.from("transcript_full_reanalysis_queue").select("status, batch_number").order("batch_number"),
        supabase.from("transcript_reanalysis_queue").select("status"),
      ]);

      const fullStats = {
        pending: fullQueue.data?.filter(q => q.status === "pending").length || 0,
        processing: fullQueue.data?.filter(q => q.status === "processing").length || 0,
        completed: fullQueue.data?.filter(q => q.status === "completed").length || 0,
        failed: fullQueue.data?.filter(q => q.status === "failed").length || 0,
        total: fullQueue.data?.length || 0,
        batches: [...new Set(fullQueue.data?.map(q => q.batch_number))].length,
      };

      const incrementalStats = {
        pending: incrementalQueue.data?.filter((q: any) => q.status === "pending").length || 0,
        processing: incrementalQueue.data?.filter((q: any) => q.status === "processing").length || 0,
        completed: incrementalQueue.data?.filter((q: any) => q.status === "completed").length || 0,
        failed: incrementalQueue.data?.filter((q: any) => q.status === "failed").length || 0,
        total: incrementalQueue.data?.length || 0,
      };

      return new Response(JSON.stringify({
        full_reanalysis: fullStats,
        incremental: incrementalStats,
        combined: {
          pending: fullStats.pending + incrementalStats.pending,
          processing: fullStats.processing + incrementalStats.processing,
          completed: fullStats.completed + incrementalStats.completed,
          failed: fullStats.failed + incrementalStats.failed,
          total: fullStats.total + incrementalStats.total,
        }
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Action: process - Process next batch from either queue
    if (action === "process" || action === "process-batch") {
      console.log("[UnifiedQueue] Processing next batch...");

      // Load pipeline for database-driven prompts
      const pipeline = await getDefaultPipeline(supabaseUrl, supabaseServiceKey);
      const aiConfig = await getAIConfig();
      const encryptionKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || "";

      // Try full reanalysis queue first
      const { data: fullBatch, error: fullError } = await supabase.rpc("get_next_reanalysis_batch");
      
      if (!fullError && fullBatch && fullBatch.length > 0) {
        console.log(`[UnifiedQueue] Processing full reanalysis batch ${fullBatch[0].batch_number} with ${fullBatch.length} transcripts`);

        const results = [];
        for (const item of fullBatch) {
          try {
            const { data: transcript, error: transcriptError } = await supabase
              .from("transcript_reviews")
              .select(`
                id, transcript_content, file_name, final_account_id, opportunity_id, momentum_meeting_id, created_at,
                momentum_meetings (transcript_content, start_time, created_at)
              `)
              .eq("id", item.transcript_id)
              .single();

            // Get content from momentum_meetings if linked, otherwise from transcript_reviews
            const linkedMeeting = transcript?.momentum_meetings as unknown as { transcript_content: string; start_time: string; created_at: string } | null;
            const transcriptContent = transcript?.momentum_meeting_id && linkedMeeting?.transcript_content
              ? linkedMeeting.transcript_content
              : transcript?.transcript_content;
            
            // Derive the meeting date for accurate historical tracking
            const eventOccurredAt = linkedMeeting?.start_time
              || linkedMeeting?.created_at
              || transcript?.created_at
              || new Date().toISOString();

            if (transcriptError || !transcriptContent) {
              throw new Error(`Failed to fetch transcript: ${transcriptError?.message || "No content"}`);
            }

            // Execute core analysis pass
            const analysis = await executeAnalysisPass("core_analysis", transcript.transcript_content, {}, aiConfig, pipeline);
            console.log(`[UnifiedQueue] Extracted ${analysis.painPoints?.length || 0} pain points, ${analysis.useCases?.length || 0} use cases`);

            // Save pain points with unified taxonomy
            for (const pp of (analysis.painPoints || [])) {
              const painPointText = pp.description;
              const { ciphertext, iv } = await encryptValue(painPointText, encryptionKey);
              
              // Use upsert to prevent duplicates - ignore if already exists
              const painPointHash = await crypto.subtle.digest('MD5', new TextEncoder().encode(painPointText));
              await supabase.from("account_pain_points").insert({
                account_id: item.account_id,
                opportunity_id: item.opportunity_id,
                pain_point: painPointText, // Store plaintext for hash matching
                pain_point_encrypted: ciphertext,
                pain_category: pp.painCategory,
                business_impact: pp.businessImpact || [],
                severity: pp.severity,
                confidence_score: pp.confidence,
                source: "unified_reanalysis",
                source_transcript_id: item.transcript_id,
                encryption_iv: iv,
                is_encrypted: true,
                created_at: eventOccurredAt,
              }).then(res => {
                // Ignore duplicate key violations silently
                if (res.error?.code === '23505') {
                  console.log(`[UnifiedQueue] Skipped duplicate pain point`);
                }
              });
            }

            // Save use cases with unified taxonomy
            for (const uc of (analysis.useCases || [])) {
              const useCaseText = uc.description;
              const { ciphertext, iv } = await encryptValue(useCaseText, encryptionKey);
              
              // Use upsert to prevent duplicates - ignore if already exists
              await supabase.from("account_use_cases").insert({
                account_id: item.account_id,
                opportunity_id: item.opportunity_id,
                use_case: useCaseText, // Store plaintext for hash matching
                use_case_encrypted: ciphertext,
                functional_area: "General",
                business_theme: uc.businessTheme,
                priority: uc.priority,
                confidence_score: uc.confidence,
                status: "identified",
                source: "unified_reanalysis",
                source_transcript_id: item.transcript_id,
                encryption_iv: iv,
                is_encrypted: true,
                created_at: eventOccurredAt,
              }).then(res => {
                if (res.error?.code === '23505') {
                  console.log(`[UnifiedQueue] Skipped duplicate use case`);
                }
              });
            }

            // Save NBAs (check both field names for compatibility)
            for (const nba of (analysis.nbas || analysis.nextBestActions || [])) {
              const { ciphertext: actionCipher, iv } = await encryptValue(nba.action, encryptionKey);
              let notesCipher: string | null = null;
              if (nba.reasoning) {
                const notesEnc = await encryptValue(nba.reasoning, encryptionKey);
                notesCipher = notesEnc.ciphertext;
              }
              
              // Use upsert to prevent duplicates - ignore if already exists
              await supabase.from("account_nbas").insert({
                account_id: item.account_id,
                opportunity_id: item.opportunity_id,
                action: nba.action, // Store plaintext for hash matching
                action_encrypted: actionCipher,
                action_type: nba.actionType || "follow_up",
                assigned_to: nba.ownerEmail || nba.ownerName || nba.ownerType || "sales_engineer",
                priority: nba.priority || "medium",
                notes: null,
                notes_encrypted: notesCipher,
                status: "pending",
                source_transcript_id: item.transcript_id,
                encryption_iv: iv,
                is_encrypted: true,
                due_date: nba.dueDate || null,
                created_at: eventOccurredAt,
              }).then(res => {
                if (res.error?.code === '23505') {
                  console.log(`[UnifiedQueue] Skipped duplicate NBA`);
                }
              });
            }

            // Save internal team members discovered in the transcript
            const internalPeople = (analysis.people || []).filter((p: any) => p.isInternal);
            if (internalPeople.length > 0) {
              const { added, errors } = await addInternalTeamMembers(
                supabaseUrl,
                supabaseServiceKey,
                item.account_id,
                item.opportunity_id,
                item.transcript_id,
                internalPeople.map((p: any) => ({
                  name: p.name,
                  email: p.email,
                  role: p.role,
                }))
              );
              console.log(`[UnifiedQueue] Added ${added} internal team members from transcript ${item.transcript_id}`);
              if (errors.length > 0) {
                console.warn(`[UnifiedQueue] Team member errors:`, errors);
              }
            }

            await supabase
              .from("transcript_full_reanalysis_queue")
              .update({ status: "completed", completed_at: new Date().toISOString() })
              .eq("id", item.id);

            results.push({ id: item.transcript_id, status: "completed" });
          } catch (error) {
            console.error(`[UnifiedQueue] Failed transcript ${item.transcript_id}:`, error);
            
            await supabase
              .from("transcript_full_reanalysis_queue")
              .update({ 
                status: "failed", 
                error_message: error instanceof Error ? error.message : String(error),
                completed_at: new Date().toISOString(),
              })
              .eq("id", item.id);

            results.push({ id: item.transcript_id, status: "failed", error: String(error) });
          }
        }

        return new Response(JSON.stringify({
          success: true,
          queue: "full_reanalysis",
          batch_number: fullBatch[0].batch_number,
          processed: results.length,
          results,
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Try incremental queue
      const { data: incrementalBatch, error: incrementalError } = await supabase
        .from("transcript_reanalysis_queue")
        .select("*")
        .eq("status", "pending")
        .lt("attempts", MAX_ATTEMPTS)
        .order("created_at", { ascending: true })
        .limit(BATCH_SIZE);

      if (!incrementalError && incrementalBatch && incrementalBatch.length > 0) {
        console.log(`[UnifiedQueue] Processing incremental batch of ${incrementalBatch.length} items`);

        const batchIds = incrementalBatch.map(b => b.id);
        await supabase
          .from("transcript_reanalysis_queue")
          .update({ 
            status: "processing", 
            started_at: new Date().toISOString(),
            attempts: incrementalBatch[0].attempts + 1
          })
          .in("id", batchIds);

        const results = [];
        for (const item of incrementalBatch) {
          try {
            const { data: transcript, error: transcriptError } = await supabase
              .from("transcript_reviews")
              .select("id, transcript_content, opportunity_id")
              .eq("id", item.transcript_id)
              .single();

            if (transcriptError || !transcript) {
              throw new Error(`Transcript not found: ${item.transcript_id}`);
            }

            // Process specific analysis types
            if (item.analysis_types?.includes("readiness_answers")) {
              await processReadinessAnswers(supabase, transcript, item, aiConfig);
            }

            if (item.analysis_types?.includes("validation_tasks")) {
              await processValidationTasks(supabase, transcript, item, aiConfig);
            }

            await supabase
              .from("transcript_reanalysis_queue")
              .update({ 
                status: "completed", 
                completed_at: new Date().toISOString(),
                error_message: null
              })
              .eq("id", item.id);

            results.push({ id: item.id, success: true });
          } catch (itemError: any) {
            const errorMessage = itemError instanceof Error ? itemError.message : String(itemError);
            const newStatus = item.attempts + 1 >= MAX_ATTEMPTS ? "failed" : "pending";
            
            await supabase
              .from("transcript_reanalysis_queue")
              .update({ status: newStatus, error_message: errorMessage })
              .eq("id", item.id);

            results.push({ id: item.id, success: false, error: errorMessage });
          }
        }

        return new Response(JSON.stringify({ 
          success: true, 
          queue: "incremental",
          processed: incrementalBatch.length,
          successful: results.filter(r => r.success).length,
          results
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({
        success: true,
        message: "No pending items in either queue",
        processed: 0,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ 
      error: "Invalid action. Use: prepare, status, or process" 
    }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("[UnifiedQueue] Error:", error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : String(error) 
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

// Helper for readiness answers extraction
async function processReadinessAnswers(supabase: any, transcript: any, item: any, aiConfig: any) {
  const { data: questions } = await supabase
    .from("readiness_template_questions")
    .select("id, question, field_type, options");

  if (!questions) return;

  const prompt = `Analyze this meeting transcript and extract answers to technical readiness questions.
For each question, provide: questionIndex, answer, confidence (0-1), evidence.
Only include questions where you found evidence.

Transcript:
${transcript.transcript_content?.substring(0, 15000) || "No content"}

Questions:
${questions.map((q: any, i: number) => `${i}. ${q.question} (${q.field_type})`).join("\n")}`;

  const response = await fetch(aiConfig.endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${aiConfig.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: aiConfig.model,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    }),
  });

  if (!response.ok) return;

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) return;

  try {
    const parsed = JSON.parse(content);
    const answers = parsed.answers || parsed;
    if (!Array.isArray(answers)) return;

    for (const extracted of answers) {
      const question = questions[extracted.questionIndex];
      if (!question) continue;

      await supabase.from("opportunity_readiness_answers").upsert({
        opportunity_id: item.opportunity_id,
        question_id: question.id,
        answer: extracted.answer,
        confidence_score: extracted.confidence || 0.5,
        source_transcript_id: transcript.id,
        source: "unified_reanalysis",
        updated_at: new Date().toISOString(),
      }, { onConflict: "opportunity_id,question_id" });
    }
  } catch (e) {
    console.error("Failed to parse readiness answers:", e);
  }
}

// Helper for validation tasks extraction
async function processValidationTasks(supabase: any, transcript: any, item: any, aiConfig: any) {
  const { data: templates } = await supabase
    .from("validation_task_templates")
    .select("id, module, sub_module, activity");

  if (!templates) return;

  const { data: existing } = await supabase
    .from("opportunity_validation_tasks")
    .select("template_id")
    .eq("opportunity_id", item.opportunity_id);

  const existingIds = new Set(existing?.map((t: any) => t.template_id) || []);

  const prompt = `Analyze this transcript to identify validation tasks discussed.
Return JSON: { "relevantTemplates": [index1, index2, ...] }

Transcript:
${transcript.transcript_content?.substring(0, 15000) || "No content"}

Templates:
${templates.map((t: any, i: number) => `${i}. ${t.module} > ${t.sub_module || ""} > ${t.activity}`).join("\n")}`;

  const response = await fetch(aiConfig.endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${aiConfig.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: aiConfig.model,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    }),
  });

  if (!response.ok) return;

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) return;

  try {
    const parsed = JSON.parse(content);
    const indices = parsed.relevantTemplates || [];
    
    for (const idx of indices) {
      const template = templates[idx];
      if (template && !existingIds.has(template.id)) {
        await supabase.from("opportunity_validation_tasks").insert({
          opportunity_id: item.opportunity_id,
          template_id: template.id,
          module: template.module,
          sub_module: template.sub_module,
          activity: template.activity,
          status: "pending",
        });
      }
    }
  } catch (e) {
    console.error("Failed to parse validation tasks:", e);
  }
}

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";
import { getAIConfig, smartTruncate } from "../_shared/ai-provider.ts";
import { 
  getDefaultPipeline, 
  FALLBACK_SCHEMAS, 
  FALLBACK_PROMPTS,
  PAIN_CATEGORIES,
  BUSINESS_IMPACTS,
  BUSINESS_THEMES
} from "../_shared/prompt-library.ts";
import { 
  buildAnalysisContext, 
  formatContextForPrompt, 
  detectPotentialNBACompletions,
  type AnalysisContext 
} from "../_shared/context-builder.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// === Analysis Run Logger ===
async function logPassStart(
  supabaseUrl: string, supabaseKey: string,
  transcriptId: string, passKey: string, passName: string, phase: string, retryAttempt = 0
): Promise<string | null> {
  try {
    const sb = createClient(supabaseUrl, supabaseKey);
    const { data, error } = await sb.from('analysis_run_logs').insert({
      transcript_id: transcriptId,
      pass_key: passKey,
      pass_name: passName,
      phase,
      status: 'running',
      retry_attempt: retryAttempt,
      started_at: new Date().toISOString(),
    }).select('id').single();
    if (error) { console.error('[RunLog] Insert failed:', error.message); return null; }
    return data?.id || null;
  } catch (e) { console.error('[RunLog] Error:', e); return null; }
}

async function logPassEnd(
  supabaseUrl: string, supabaseKey: string, logId: string | null,
  status: 'completed' | 'failed' | 'skipped',
  opts: { errorMessage?: string; errorCategory?: string; inputTokens?: number; outputTokens?: number; resultSummary?: any; metadata?: any } = {}
) {
  if (!logId) return;
  try {
    const sb = createClient(supabaseUrl, supabaseKey);
    const now = new Date();
    await sb.from('analysis_run_logs').update({
      status,
      completed_at: now.toISOString(),
      error_message: opts.errorMessage || null,
      error_category: opts.errorCategory || null,
      input_tokens_estimate: opts.inputTokens || null,
      output_tokens_estimate: opts.outputTokens || null,
      result_summary: opts.resultSummary || null,
      metadata: opts.metadata || null,
    }).eq('id', logId);
  } catch (e) { console.error('[RunLog] Update failed:', e); }
}

// Input validation schema
const AnalyzeTranscriptInputSchema = z.object({
  transcript: z.string().min(1).max(500000),
  accountId: z.string().uuid().optional(),
  opportunityId: z.string().uuid().optional(),
  transcriptReviewId: z.string().uuid().optional(),
  skipEnrichment: z.boolean().optional(),
  streaming: z.boolean().optional().default(true),
  // Enable context-aware analysis with prior history
  includeContext: z.boolean().optional().default(true),
  // Retry only specific pass keys instead of the full pipeline
  retryPassKeys: z.array(z.string()).optional(),
});

// Maximum transcript length for AI processing (tokens ≈ chars/4)
const MAX_TRANSCRIPT_LENGTH = 30000;

// Detect if content is email vs meeting transcript
function detectContentType(text: string): 'email' | 'meeting' | 'unknown' {
  const emailPatterns = [
    /^(From|To|Subject|Date|Sent):/im,
    /^[-]+\s*Original Message\s*[-]+/im,
    /^On .+ wrote:/im,
    /^[\w.+-]+@[\w.-]+\.\w+/m,
    /^(Hi|Hello|Dear|Hey)\s+\w+,?\s*$/im,
  ];
  
  const meetingPatterns = [
    /^(Speaker|Participant|Host|Guest)\s*\d*:/im,
    /^\[?\d{1,2}:\d{2}(:\d{2})?\]?/m, // Timestamps
    /^[A-Z][a-z]+ [A-Z][a-z]+:/m, // "John Smith:" speaker pattern
    /\b(meeting|call|discussion|agenda)\b/i,
  ];
  
  const emailScore = emailPatterns.filter(p => p.test(text)).length;
  const meetingScore = meetingPatterns.filter(p => p.test(text)).length;
  
  if (emailScore >= 2) return 'email';
  if (meetingScore >= 2) return 'meeting';
  return 'unknown';
}

// Estimate content density for truncation decisions
function estimateContentDensity(text: string): 'low' | 'medium' | 'high' {
  const speakerTurns = (text.match(/\n[A-Z][a-z]+ [A-Z][a-z]+:/g) || []).length;
  const paragraphs = text.split(/\n\n+/).length;
  
  // Short content with few speakers = low density
  if (text.length < 10000 && speakerTurns < 10) return 'low';
  if (text.length > 40000 || speakerTurns > 30) return 'high';
  return 'medium';
}

// SSE helper to send progress events
function sendSSE(controller: ReadableStreamDefaultController, event: string, data: any) {
  const message = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  controller.enqueue(new TextEncoder().encode(message));
}

// Execute a single analysis pass with token tracking
function normalizeToolSchema(schema: any, aggressive = false): any {
  // Normalize OpenAPI-like schemas into lean JSON schema for tool calling.
  if (!schema || typeof schema !== "object") return schema;
  if (Array.isArray(schema)) return schema.map((item) => normalizeToolSchema(item, aggressive));

  const out: any = {};
  const strippedKeys = new Set([
    "nullable", "title", "examples", "default", "$schema",
    "maxItems", "minItems", "maxLength", "minLength",
    "maximum", "minimum", "exclusiveMinimum", "exclusiveMaximum",
    "multipleOf", "pattern", "format", "const"
  ]);

  // In aggressive mode, also strip description to reduce token count
  if (aggressive) strippedKeys.add("description");

  for (const [k, v] of Object.entries(schema)) {
    if (k === "description" && typeof v === "string" && !aggressive) continue;
    if (k === "description" && aggressive) continue;
    if (k === "enum") {
      // In aggressive mode, truncate long enums to reduce state explosion
      if (aggressive && Array.isArray(v) && v.length > 6) {
        out[k] = (v as any[]).slice(0, 6);
      } else {
        out[k] = v;
      }
      continue;
    }
    if (aggressive && k === "required") continue;
    if (strippedKeys.has(k)) continue;

    if ((k === "oneOf" || k === "anyOf" || k === "allOf") && Array.isArray(v)) {
      if (v.length > 0) out[k] = [normalizeToolSchema(v[0], aggressive)];
      continue;
    }

    out[k] = normalizeToolSchema(v, aggressive);
  }

  if (!out.type && Array.isArray((schema as any).enum) && (schema as any).enum.length > 0) {
    const sample = (schema as any).enum[0];
    if (sample === null) {
      out.type = ["string", "null"];
    } else if (typeof sample === "string" || typeof sample === "number" || typeof sample === "boolean") {
      out.type = typeof sample;
    }
  }

  if (schema.nullable === true) {
    const t = out.type ?? schema.type;
    if (typeof t === "string") {
      out.type = [t, "null"];
    } else if (Array.isArray(t)) {
      out.type = t.includes("null") ? t : [...t, "null"];
    }
  }

  return out;
}

function isSchemaStateExplosion(status: number, errText: string): boolean {
  const normalized = (errText || "").toLowerCase();
  return status === 400 && (
    normalized.includes("too many states") ||
    normalized.includes("schema produces a constraint") ||
    normalized.includes("invalid_argument")
  );
}

// Default timeout overrides for passes not yet configured in the DB
const PASS_TIMEOUT_DEFAULTS: Record<string, number> = {
  call_summary: 90,
  activity_detection: 120,
  enrichment_detection: 120,
  product_detection: 120,
  core_extraction: 90,
  readiness_extraction: 90,
  enrichment_readiness: 120,
};

// Get effective timeout for a pass, applying progressive escalation on retries
function getEffectiveTimeoutMs(passKey: string, dbTimeoutSeconds: number | null, attempt: number): number {
  const baseSeconds = dbTimeoutSeconds || PASS_TIMEOUT_DEFAULTS[passKey] || 45;
  // Each retry adds 50% more time: attempt 0 = 1x, attempt 1 = 1.5x, attempt 2 = 2x
  const multiplier = 1 + (attempt * 0.5);
  return Math.round(baseSeconds * multiplier * 1000);
}

// Get backoff delay based on error type
function getBackoffMs(attempt: number, errorMessage: string): number {
  const is503 = errorMessage.includes('503') || errorMessage.includes('UNAVAILABLE') || errorMessage.includes('high demand');
  if (is503) {
    // Much longer backoff for model overload: 10s, 20s, 40s
    return Math.min((attempt + 1) * 10000 * Math.pow(2, attempt), 60000);
  }
  // Standard backoff: 2s, 4s
  return (attempt + 1) * 2000;
}

async function executePass(
  passKey: string,
  systemPrompt: string,
  outputSchema: any,
  transcript: string,
  context: Record<string, any>,
  aiConfig: any,
  timeoutMs: number = 45000
): Promise<{ result: any; inputChars: number; outputChars: number }> {
  // Include today's date for NBA due date suggestions
  const todayDate = new Date().toISOString().split('T')[0];
  
  const contextString = Object.entries(context)
    .filter(([_, v]) => v !== undefined && v !== null)
    .map(([k, v]) => `${k}: ${JSON.stringify(v)}`)
    .join('\n');

  const dateContext = `Today's date: ${todayDate}`;
  const userMessage = contextString 
    ? `${dateContext}\n\nContext from previous analysis:\n${contextString}\n\nAnalyze:\n\n${transcript}`
    : `${dateContext}\n\nAnalyze:\n\n${transcript}`;

  let normalizedSchema = normalizeToolSchema(outputSchema);

  const invokeWithSchema = async (schemaForCall: any) => {
    const response = await Promise.race([
      fetch(aiConfig.endpoint, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${aiConfig.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: aiConfig.model,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userMessage }
          ],
          tools: [{
            type: "function",
            function: {
              name: `extract_${passKey}`,
              description: `Extract ${passKey} analysis`,
              parameters: schemaForCall
            }
          }],
          tool_choice: { type: "function", function: { name: `extract_${passKey}` } }
        }),
      }),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error(`Pass ${passKey} timeout after ${timeoutMs}ms`)), timeoutMs)
      )
    ]) as Response;

    if (!response.ok) {
      const errText = await response.text().catch(() => "");
      return { ok: false as const, status: response.status, errText };
    }

    const data = await response.json();
    return { ok: true as const, data };
  };

  let callResult = await invokeWithSchema(normalizedSchema);
  

  if (!callResult.ok && isSchemaStateExplosion(callResult.status, callResult.errText)) {
    console.warn(`[${passKey}] Retry 1: aggressive schema normalization`);
    normalizedSchema = normalizeToolSchema(outputSchema, true);
    callResult = await invokeWithSchema(normalizedSchema);
  }

  // With the pipeline split, aggressive normalization should suffice

  if (!callResult.ok) {
    console.error(`[${passKey}] Upstream AI error ${callResult.status}:`, callResult.errText?.slice(0, 2000));
    throw new Error(`Pass ${passKey} failed: ${callResult.status}${callResult.errText ? ` - ${callResult.errText.slice(0, 200)}` : ""}`);
  }

  const inputChars = systemPrompt.length + userMessage.length + JSON.stringify(normalizedSchema).length;
  const rawArgs = callResult.data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments || "{}";
  const outputChars = rawArgs.length;

  console.log(`[${passKey}] Input: ~${Math.round(inputChars/4)} tokens, Output: ~${Math.round(outputChars/4)} tokens`);

  return {
    result: JSON.parse(rawArgs),
    inputChars,
    outputChars
  };
}

// Persist meeting_type to transcript_reviews if available
async function persistMeetingType(
  transcriptReviewId: string | undefined,
  coreResult: any,
  supabaseUrl: string,
  supabaseKey: string
) {
  if (!transcriptReviewId) return;
  
  const meetingType = coreResult?.meetingPurpose?.meetingType;
  if (!meetingType) return;
  
  try {
    const supabase = createClient(supabaseUrl, supabaseKey);
    const updatePayload: Record<string, any> = {
      meeting_type: meetingType,
      meeting_type_confidence: coreResult.meetingPurpose.confidence ?? null,
    };
    const { error } = await supabase
      .from('transcript_reviews')
      .update(updatePayload)
      .eq('id', transcriptReviewId);
    
    if (error) {
      console.error(`[UnifiedAnalysis] Failed to persist meeting_type: ${error.message}`);
    } else {
      console.log(`[UnifiedAnalysis] Persisted meeting_type="${meetingType}" (confidence=${coreResult.meetingPurpose.confidence}) for transcript ${transcriptReviewId}`);
    }
  } catch (err) {
    console.error(`[UnifiedAnalysis] Error persisting meeting_type:`, err);
  }
}

// Persist call_summary to transcript_reviews (from separate call_summary pass)
async function persistCallSummary(
  transcriptReviewId: string | undefined,
  summaryResult: any,
  supabaseUrl: string,
  supabaseKey: string
) {
  if (!transcriptReviewId) return;
  const callSummary = summaryResult?.callSummary;
  if (!callSummary?.quickRecap) return;
  
  try {
    const supabase = createClient(supabaseUrl, supabaseKey);
    const { error } = await supabase
      .from('transcript_reviews')
      .update({ call_summary: callSummary })
      .eq('id', transcriptReviewId);
    
    if (error) {
      console.error(`[UnifiedAnalysis] Failed to persist call_summary: ${error.message}`);
    } else {
      console.log(`[UnifiedAnalysis] Persisted call_summary for transcript ${transcriptReviewId}`);
    }
  } catch (err) {
    console.error(`[UnifiedAnalysis] Error persisting call_summary:`, err);
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const rawBody = await req.json();
    const parseResult = AnalyzeTranscriptInputSchema.safeParse(rawBody);
    
    if (!parseResult.success) {
      return new Response(
        JSON.stringify({ error: "Invalid input", details: parseResult.error.errors }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    const { accountId, opportunityId, includeContext, retryPassKeys } = parseResult.data;

    const { transcript: rawTranscript, transcriptReviewId, skipEnrichment, streaming } = parseResult.data;
    const isPartialRetry = retryPassKeys && retryPassKeys.length > 0;
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
    const encryptionKey = Deno.env.get("TRANSCRIPT_ENCRYPTION_KEY") || "";
    
    // === OPTIMIZATION 1: Early content type detection ===
    const contentType = detectContentType(rawTranscript);
    const contentDensity = estimateContentDensity(rawTranscript);
    
    // For emails, auto-skip enrichment passes (no validation tasks, limited data)
    const effectiveSkipEnrichment = skipEnrichment || contentType === 'email';
    
    // === OPTIMIZATION 2: Early transcript truncation ===
    const transcript = rawTranscript.length > MAX_TRANSCRIPT_LENGTH 
      ? smartTruncate(rawTranscript, MAX_TRANSCRIPT_LENGTH)
      : rawTranscript;
    
    const truncated = rawTranscript.length > MAX_TRANSCRIPT_LENGTH;
    
    // === NEW: Build context from prior interactions ===
    let analysisContext: AnalysisContext | null = null;
    let contextPromptSection = '';
    let potentialNBACompletions: { nbaId: string; confidence: number; reason: string }[] = [];
    
    if (includeContext && accountId) {
      try {
        console.log(`[UnifiedAnalysis] Building context for account ${accountId}...`);
        analysisContext = await buildAnalysisContext(
          supabaseUrl,
          supabaseKey,
          accountId,
          opportunityId,
          encryptionKey
        );
        
        contextPromptSection = formatContextForPrompt(analysisContext, 2500);
        console.log(`[UnifiedAnalysis] Context built: ${analysisContext.recentMeetings.length} meetings, ${analysisContext.openNBAs.length} NBAs, ${analysisContext.stakeholders.length} stakeholders`);
        
        // Pre-detect potential NBA completions
        if (analysisContext.openNBAs.length > 0) {
          potentialNBACompletions = detectPotentialNBACompletions(transcript, analysisContext.openNBAs);
          console.log(`[UnifiedAnalysis] Detected ${potentialNBACompletions.length} potential NBA completions`);
        }
      } catch (err) {
        console.error("[UnifiedAnalysis] Context building failed, proceeding without:", err);
      }
    }
    
    console.log(`[UnifiedAnalysis] Starting (original: ${rawTranscript.length} chars, processed: ${transcript.length} chars, type: ${contentType}, density: ${contentDensity}, skipEnrichment: ${effectiveSkipEnrichment}, hasContext: ${!!analysisContext}${truncated ? ', TRUNCATED' : ''})`);

    // === STUCK PASS RECOVERY: Mark any stale "running" logs as failed for this transcript ===
    if (transcriptReviewId) {
      try {
        const sb = createClient(supabaseUrl, supabaseKey);
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
        const { data: stuckLogs, error: stuckErr } = await sb
          .from('analysis_run_logs')
          .select('id, pass_key')
          .eq('transcript_id', transcriptReviewId)
          .eq('status', 'running')
          .lt('started_at', fiveMinutesAgo);
        
        if (!stuckErr && stuckLogs && stuckLogs.length > 0) {
          console.warn(`[UnifiedAnalysis] Found ${stuckLogs.length} stuck 'running' logs for transcript ${transcriptReviewId}, marking as failed`);
          for (const log of stuckLogs) {
            await sb.from('analysis_run_logs').update({
              status: 'failed',
              completed_at: new Date().toISOString(),
              error_message: 'Pass was stuck in running state (edge function crash/timeout). Auto-recovered.',
              error_category: 'timeout',
            }).eq('id', log.id);
          }
        }
      } catch (e) {
        console.error('[UnifiedAnalysis] Stuck log recovery error:', e);
      }
    }

    // Get AI config - use lite model for emails (faster, cheaper)
    const aiConfig = await getAIConfig(contentType === 'email' ? 'lite' : 'standard');

    // Load pipeline from database or use fallback
    const pipeline = await getDefaultPipeline(supabaseUrl, supabaseKey);
    
    // Track total token usage
    let totalInputChars = 0;
    let totalOutputChars = 0;
    
    // Prepare enhanced transcript with context
    const enhancedTranscript = contextPromptSection 
      ? `${contextPromptSection}\n\n---\n\n## NEW MEETING TRANSCRIPT:\n\n${transcript}`
      : transcript;
    
    if (streaming) {
      // Streaming mode - return SSE stream
      const stream = new ReadableStream({
        async start(controller) {
          try {
            const passResults: Record<string, any> = {};
            const passes = pipeline?.passes || [];
            const totalPasses = effectiveSkipEnrichment ? Math.min(2, passes.length) : passes.length;

            // Use database passes or fallback
            if (passes.length > 0) {
              let passIndex = 0;
              for (const pass of passes) {
                // If skipEnrichment and past the first 2 passes, log remaining as skipped and stop
                if (effectiveSkipEnrichment && passIndex >= 2) {
                  if (transcriptReviewId) {
                    const skipLogId = await logPassStart(supabaseUrl, supabaseKey, transcriptReviewId, pass.pass_key, pass.name, 'core', 0);
                    if (skipLogId) logPassEnd(supabaseUrl, supabaseKey, skipLogId, 'skipped', { errorMessage: 'Skipped: enrichment not required for this content type' });
                  }
                  passIndex++;
                  continue;
                }

                // If partial retry, skip passes not in the retry list
                if (isPartialRetry && !retryPassKeys!.includes(pass.pass_key)) {
                  passIndex++;
                  continue;
                }
                sendSSE(controller, "progress", { 
                  pass: passIndex + 1, 
                  totalPasses,
                  stage: pass.name,
                  passKey: pass.pass_key,
                  progress: Math.round((passIndex / totalPasses) * 100)
                });

                {
                  // Build context from dependencies
                  const context: Record<string, any> = {};
                  for (const depKey of pass.dependencies || []) {
                    if (passResults[depKey]) {
                      context[depKey] = passResults[depKey];
                    }
                  }

                  const effectivePrompt = pass.system_prompt;
                  const effectiveSchema = pass.output_schema || FALLBACK_SCHEMAS[pass.pass_key as keyof typeof FALLBACK_SCHEMAS];

                  // Auto-retry logic: up to 2 retries (3 total attempts) with backoff
                  const MAX_ATTEMPTS = 3;
                  let lastError: Error | null = null;

                  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
                    // Log pass start
                    const runLogId = transcriptReviewId
                      ? await logPassStart(supabaseUrl, supabaseKey, transcriptReviewId, pass.pass_key, pass.name, 'core', attempt)
                      : null;

                    try {
                      const { result, inputChars, outputChars } = await executePass(
                        pass.pass_key,
                        effectivePrompt,
                        effectiveSchema,
                        enhancedTranscript,
                        context,
                        aiConfig,
                        getEffectiveTimeoutMs(pass.pass_key, pass.timeout_seconds, attempt)
                      );

                      totalInputChars += inputChars;
                      totalOutputChars += outputChars;
                      passResults[pass.pass_key] = result;

                      // Log pass completion
                      if (runLogId) {
                        logPassEnd(supabaseUrl, supabaseKey, runLogId, 'completed', {
                          inputTokens: Math.round(inputChars / 4),
                          outputTokens: Math.round(outputChars / 4),
                          resultSummary: { keys: Object.keys(result || {}) },
                        });
                      }

                      // Persist meeting_type / call_summary
                      if (pass.pass_key === 'core_extraction' || pass.pass_key === 'core_analysis') {
                        persistMeetingType(transcriptReviewId, result, supabaseUrl, supabaseKey);
                      }
                      if (pass.pass_key === 'call_summary') {
                        persistCallSummary(transcriptReviewId, result, supabaseUrl, supabaseKey);
                      }

                      sendSSE(controller, "pass_complete", {
                        pass: passIndex + 1,
                        passKey: pass.pass_key,
                        result,
                        progress: Math.round(((passIndex + 1) / totalPasses) * 100),
                        tokensEstimate: { input: Math.round(inputChars/4), output: Math.round(outputChars/4) }
                      });

                      lastError = null;
                      break; // Success — exit retry loop
                    } catch (retryErr) {
                      lastError = retryErr instanceof Error ? retryErr : new Error(String(retryErr));
                      const errMsg = lastError.message;
                      const errCat = errMsg.includes('timeout') ? 'timeout'
                        : errMsg.includes('schema') || errMsg.includes('400') ? 'schema_explosion'
                        : errMsg.includes('content') ? 'content_error'
                        : 'ai_error';

                      if (runLogId) {
                        logPassEnd(supabaseUrl, supabaseKey, runLogId, 'failed', {
                          errorMessage: errMsg.substring(0, 1000),
                          errorCategory: errCat,
                        });
                      }

                      if (attempt < MAX_ATTEMPTS - 1) {
                        const backoffMs = getBackoffMs(attempt, errMsg);
                        const nextTimeoutMs = getEffectiveTimeoutMs(pass.pass_key, pass.timeout_seconds, attempt + 1);
                        console.warn(`[${pass.pass_key}] Attempt ${attempt + 1} failed (${errCat}), retrying in ${backoffMs}ms with ${nextTimeoutMs}ms timeout: ${errMsg.substring(0, 200)}`);
                        await new Promise(r => setTimeout(r, backoffMs));
                      }
                    }
                  }

                  // If all attempts failed, log final error and continue to next stage
                  if (lastError) {
                    console.error(`Pass ${pass.pass_key} failed after ${MAX_ATTEMPTS} attempts:`, lastError);

                    sendSSE(controller, "pass_error", {
                      pass: passIndex + 1,
                      passKey: pass.pass_key,
                      error: lastError.message
                    });

                    // Core extraction is mandatory
                    if (pass.pass_key === "core_extraction" || pass.pass_key === "core_analysis") {
                      throw new Error(`Core extraction failed, aborting analysis: ${lastError.message}`);
                    }
                  }
                }
                passIndex++;
              }
            } else {
              // Use fallback prompts - aligned with DB pass_keys
              sendSSE(controller, "progress", { 
                pass: 1, 
                totalPasses: skipEnrichment ? 1 : 2,
                stage: "Core Extraction",
                passKey: "core_extraction",
                progress: 10
              });

              const { result: coreResult, inputChars: coreIn, outputChars: coreOut } = await executePass(
                "core_extraction",
                FALLBACK_PROMPTS.core_extraction,
                FALLBACK_SCHEMAS.core_extraction,
                enhancedTranscript, // Use context-aware transcript
                {},
                aiConfig
              );
              totalInputChars += coreIn;
              totalOutputChars += coreOut;
              passResults["core_extraction"] = coreResult;
              
              // Persist meeting_type after fallback core extraction
              persistMeetingType(transcriptReviewId, coreResult, supabaseUrl, supabaseKey);

              sendSSE(controller, "pass_complete", { 
                pass: 1,
                passKey: "core_extraction",
                result: coreResult,
                progress: 50,
                tokensEstimate: { input: Math.round(coreIn/4), output: Math.round(coreOut/4) }
              });

              if (!effectiveSkipEnrichment) {
                sendSSE(controller, "progress", { 
                  pass: 2, 
                  totalPasses: 2,
                  stage: "Stage Assessment",
                  passKey: "stage_assessment",
                  progress: 55
                });

                try {
                  const { result: stageResult, inputChars: stageIn, outputChars: stageOut } = await executePass(
                    "stage_assessment",
                    FALLBACK_PROMPTS.stage_assessment,
                    FALLBACK_SCHEMAS.stage_assessment,
                    transcript,
                    { core_extraction: coreResult },
                    aiConfig
                  );
                  totalInputChars += stageIn;
                  totalOutputChars += stageOut;
                  passResults["stage_assessment"] = stageResult;

                  sendSSE(controller, "pass_complete", { 
                    pass: 2,
                    passKey: "stage_assessment",
                    result: stageResult,
                    progress: 100,
                    tokensEstimate: { input: Math.round(stageIn/4), output: Math.round(stageOut/4) }
                  });
                } catch (err) {
                  console.error("Stage assessment failed:", err);
                }
              }
            }

            // Combine all results - use DB-aligned pass keys
            const coreData = passResults["core_extraction"] || passResults["core_analysis"] || {};
            const callSummaryData = passResults["call_summary"] || {};
            const stageData = passResults["stage_assessment"] || {};
            const enrichmentData = passResults["enrichment_detection"] || {};
            const readinessData = passResults["enrichment_readiness"] || {};
            const synthesisData = passResults["account_synthesis"] || {};
            
            // Persist NBA completions to database if detected with high confidence
            if (potentialNBACompletions.length > 0 && supabaseUrl && supabaseKey) {
              const highConfidenceCompletions = potentialNBACompletions.filter(c => c.confidence >= 0.6);
              if (highConfidenceCompletions.length > 0) {
                console.log(`[UnifiedAnalysis] Persisting ${highConfidenceCompletions.length} NBA completions...`);
                for (const completion of highConfidenceCompletions) {
                  try {
                    const updateRes = await fetch(
                      `${supabaseUrl}/rest/v1/account_nbas?id=eq.${completion.nbaId}`,
                      {
                        method: 'PATCH',
                        headers: {
                          'Authorization': `Bearer ${supabaseKey}`,
                          'apikey': supabaseKey,
                          'Content-Type': 'application/json',
                          'Prefer': 'return=minimal',
                        },
                        body: JSON.stringify({
                          auto_complete_confidence: completion.confidence,
                          auto_complete_reason: completion.reason,
                          auto_completed_by_transcript_id: transcriptReviewId || null,
                        }),
                      }
                    );
                    if (!updateRes.ok) {
                      console.error(`Failed to update NBA ${completion.nbaId}:`, await updateRes.text());
                    }
                  } catch (err) {
                    console.error(`Error updating NBA ${completion.nbaId}:`, err);
                  }
                }
              }
            }

            const combinedResult = {
              ...coreData,
              ...callSummaryData,
              ...stageData,
              ...enrichmentData,
              ...readinessData,
              ...synthesisData,
              insights: {
                painPoints: coreData.painPoints || [],
                useCases: coreData.useCases || [],
                competitorMentions: coreData.competitorMentions || [],
              },
              potentialNBACompletions,
              _meta: {
                contentType,
                contentDensity,
                truncated,
                originalLength: rawTranscript.length,
                processedLength: transcript.length,
              }
            };

            // Log total token usage
            console.log(`[UnifiedAnalysis] Complete: ~${Math.round(totalInputChars/4)} input tokens, ~${Math.round(totalOutputChars/4)} output tokens`);

            sendSSE(controller, "complete", { 
              result: combinedResult,
              pipelineUsed: pipeline?.name || "fallback",
              passesExecuted: Object.keys(passResults).length,
              potentialNBACompletions,
              tokensEstimate: { 
                input: Math.round(totalInputChars/4), 
                output: Math.round(totalOutputChars/4),
                total: Math.round((totalInputChars + totalOutputChars)/4)
              }
            });

            controller.close();
          } catch (error) {
            console.error("[UnifiedAnalysis] Stream error:", error);
            sendSSE(controller, "error", { 
              error: error instanceof Error ? error.message : String(error) 
            });
            controller.close();
          }
        }
      });

      return new Response(stream, {
        headers: {
          ...corsHeaders,
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache",
          "Connection": "keep-alive",
        },
      });
    } else {
      // Non-streaming mode - return JSON response
      const passResults: Record<string, any> = {};
      const passes = pipeline?.passes || [];
      
      if (passes.length > 0) {
        // Use database pipeline with retryPassKeys filtering
        for (const pass of passes) {
          // When doing a partial retry, ONLY run the requested passes (skip enrichment check doesn't apply)
          if (isPartialRetry) {
            if (!retryPassKeys!.includes(pass.pass_key)) continue;
          } else {
            if (effectiveSkipEnrichment && ['activity_detection', 'product_detection', 'readiness_extraction', 'account_synthesis', 'competitive_analysis', 'success_criteria', 'se_coaching'].includes(pass.pass_key)) {
              // Log skipped stages so they don't appear as perpetually pending
              if (transcriptReviewId) {
                const skipLogId = await logPassStart(supabaseUrl, supabaseKey, transcriptReviewId, pass.pass_key, pass.name, 'core', 0);
                if (skipLogId) logPassEnd(supabaseUrl, supabaseKey, skipLogId, 'skipped', { errorMessage: 'Skipped: enrichment not required for this content type' });
              }
              continue;
            }
          }

          try {
            const context: Record<string, any> = {};
            for (const depKey of pass.dependencies || []) {
              if (passResults[depKey]) context[depKey] = passResults[depKey];
            }

            const runLogId = transcriptReviewId
              ? await logPassStart(supabaseUrl, supabaseKey, transcriptReviewId, pass.pass_key, pass.name, 'core')
              : null;

            const { result, inputChars, outputChars } = await executePass(
              pass.pass_key,
              pass.system_prompt,
              pass.output_schema || FALLBACK_SCHEMAS[pass.pass_key as keyof typeof FALLBACK_SCHEMAS],
              enhancedTranscript,
              context,
              aiConfig,
              getEffectiveTimeoutMs(pass.pass_key, pass.timeout_seconds, 0)
            );
            totalInputChars += inputChars;
            totalOutputChars += outputChars;
            passResults[pass.pass_key] = result;

            if (runLogId) {
              logPassEnd(supabaseUrl, supabaseKey, runLogId, 'completed', {
                inputTokens: Math.round(inputChars / 4),
                outputTokens: Math.round(outputChars / 4),
                resultSummary: { keys: Object.keys(result || {}) },
              });
            }

            if (pass.pass_key === 'core_extraction' || pass.pass_key === 'core_analysis') {
              await persistMeetingType(transcriptReviewId, result, supabaseUrl, supabaseKey);
            }
            if (pass.pass_key === 'call_summary') {
              await persistCallSummary(transcriptReviewId, result, supabaseUrl, supabaseKey);
            }
          } catch (err) {
            const errorMessage = err instanceof Error ? err.message : String(err);
            console.error(`Pass ${pass.pass_key} failed:`, err);

            if (transcriptReviewId) {
              const failLogId = await logPassStart(supabaseUrl, supabaseKey, transcriptReviewId, pass.pass_key, pass.name, 'core');
              const errCat = errorMessage.includes('timeout') ? 'timeout'
                : errorMessage.includes('schema') || errorMessage.includes('400') ? 'schema_explosion'
                : errorMessage.includes('content') ? 'content_error'
                : 'ai_error';
              logPassEnd(supabaseUrl, supabaseKey, failLogId, 'failed', {
                errorMessage: errorMessage.substring(0, 1000),
                errorCategory: errCat,
              });
            }

            if (pass.pass_key === "core_extraction" || pass.pass_key === "core_analysis") {
              throw new Error(`Core extraction failed: ${errorMessage}`);
            }
          }
        }
      } else {
        // Fallback: execute core extraction + stage assessment
        const { result: coreResult, inputChars: coreIn, outputChars: coreOut } = await executePass(
          "core_extraction",
          FALLBACK_PROMPTS.core_extraction,
          FALLBACK_SCHEMAS.core_extraction,
          transcript,
          {},
          aiConfig
        );
        totalInputChars += coreIn;
        totalOutputChars += coreOut;
        passResults["core_extraction"] = coreResult;
        await persistMeetingType(transcriptReviewId, coreResult, supabaseUrl, supabaseKey);

        if (!effectiveSkipEnrichment) {
          try {
            const { result: stageResult, inputChars: stageIn, outputChars: stageOut } = await executePass(
              "stage_assessment",
              FALLBACK_PROMPTS.stage_assessment,
              FALLBACK_SCHEMAS.stage_assessment,
              transcript,
              { core_extraction: coreResult },
              aiConfig
            );
            totalInputChars += stageIn;
            totalOutputChars += stageOut;
            passResults["stage_assessment"] = stageResult;
          } catch (err) {
            console.error("Stage assessment failed:", err);
          }
        }
      }

      console.log(`[UnifiedAnalysis] Complete: ~${Math.round(totalInputChars/4)} input tokens, ~${Math.round(totalOutputChars/4)} output tokens`);

      const combinedResult = {
        ...passResults["core_extraction"],
        ...passResults["call_summary"],
        ...passResults["stage_assessment"],
        insights: {
          painPoints: passResults["core_extraction"]?.painPoints || [],
          useCases: passResults["core_extraction"]?.useCases || [],
          competitorMentions: passResults["core_extraction"]?.competitorMentions || [],
        },
        _meta: {
          contentType,
          contentDensity,
          truncated,
          originalLength: rawTranscript.length,
          processedLength: transcript.length,
          tokensEstimate: { 
            input: Math.round(totalInputChars/4), 
            output: Math.round(totalOutputChars/4),
            total: Math.round((totalInputChars + totalOutputChars)/4)
          }
        }
      };

      return new Response(JSON.stringify(combinedResult), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  } catch (error) {
    console.error("[UnifiedAnalysis] Error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : String(error) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

-- Create accounts table for customer accounts
CREATE TABLE public.accounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  industry TEXT,
  arr NUMERIC,
  stage TEXT DEFAULT 'discovery',
  owner_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create opportunities table for whitespace opportunities
CREATE TABLE public.opportunities (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.accounts(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  value NUMERIC,
  stage TEXT DEFAULT 'identified',
  priority TEXT DEFAULT 'medium',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create account_technologies table to store tech stack per account
CREATE TABLE public.account_technologies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.accounts(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  layer TEXT NOT NULL,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create account_documents table for plans, transcripts, screenshots
CREATE TABLE public.account_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.accounts(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT NOT NULL, -- 'plan', 'transcript', 'screenshot', 'note'
  content TEXT,
  file_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.opportunities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.account_technologies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.account_documents ENABLE ROW LEVEL SECURITY;

-- Create policies for team access (all authenticated users can view and edit)
CREATE POLICY "Team members can view all accounts" 
ON public.accounts FOR SELECT TO authenticated
USING (true);

CREATE POLICY "Team members can create accounts" 
ON public.accounts FOR INSERT TO authenticated
WITH CHECK (true);

CREATE POLICY "Team members can update accounts" 
ON public.accounts FOR UPDATE TO authenticated
USING (true);

CREATE POLICY "Team members can delete accounts" 
ON public.accounts FOR DELETE TO authenticated
USING (true);

-- Opportunities policies
CREATE POLICY "Team members can view all opportunities" 
ON public.opportunities FOR SELECT TO authenticated
USING (true);

CREATE POLICY "Team members can create opportunities" 
ON public.opportunities FOR INSERT TO authenticated
WITH CHECK (true);

CREATE POLICY "Team members can update opportunities" 
ON public.opportunities FOR UPDATE TO authenticated
USING (true);

CREATE POLICY "Team members can delete opportunities" 
ON public.opportunities FOR DELETE TO authenticated
USING (true);

-- Account technologies policies
CREATE POLICY "Team members can view all account technologies" 
ON public.account_technologies FOR SELECT TO authenticated
USING (true);

CREATE POLICY "Team members can create account technologies" 
ON public.account_technologies FOR INSERT TO authenticated
WITH CHECK (true);

CREATE POLICY "Team members can update account technologies" 
ON public.account_technologies FOR UPDATE TO authenticated
USING (true);

CREATE POLICY "Team members can delete account technologies" 
ON public.account_technologies FOR DELETE TO authenticated
USING (true);

-- Account documents policies
CREATE POLICY "Team members can view all account documents" 
ON public.account_documents FOR SELECT TO authenticated
USING (true);

CREATE POLICY "Team members can create account documents" 
ON public.account_documents FOR INSERT TO authenticated
WITH CHECK (true);

CREATE POLICY "Team members can update account documents" 
ON public.account_documents FOR UPDATE TO authenticated
USING (true);

CREATE POLICY "Team members can delete account documents" 
ON public.account_documents FOR DELETE TO authenticated
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_accounts_updated_at
BEFORE UPDATE ON public.accounts
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_opportunities_updated_at
BEFORE UPDATE ON public.opportunities
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_account_documents_updated_at
BEFORE UPDATE ON public.account_documents
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_opportunities_account_id ON public.opportunities(account_id);
CREATE INDEX idx_account_technologies_account_id ON public.account_technologies(account_id);
CREATE INDEX idx_account_documents_account_id ON public.account_documents(account_id);
CREATE INDEX idx_accounts_name ON public.accounts(name);
CREATE INDEX idx_accounts_stage ON public.accounts(stage);
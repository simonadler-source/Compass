-- Create reference architecture table for the ideal/template tech stack
CREATE TABLE public.reference_technologies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  layer TEXT NOT NULL,
  description TEXT,
  integration_type TEXT, -- 'core', 'recommended', 'optional'
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.reference_technologies ENABLE ROW LEVEL SECURITY;

-- Create policies for team access
CREATE POLICY "Team members can view reference technologies" 
ON public.reference_technologies FOR SELECT TO authenticated
USING (true);

CREATE POLICY "Team members can create reference technologies" 
ON public.reference_technologies FOR INSERT TO authenticated
WITH CHECK (true);

CREATE POLICY "Team members can update reference technologies" 
ON public.reference_technologies FOR UPDATE TO authenticated
USING (true);

CREATE POLICY "Team members can delete reference technologies" 
ON public.reference_technologies FOR DELETE TO authenticated
USING (true);

-- Add trigger for timestamp updates
CREATE TRIGGER update_reference_technologies_updated_at
BEFORE UPDATE ON public.reference_technologies
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default reference technologies for Pendo integrations
INSERT INTO public.reference_technologies (name, category, layer, description, integration_type) VALUES
-- Growth Layer - Analytics & CRM
('Salesforce', 'CRM', 'growth', 'Core CRM integration for product usage data sync', 'core'),
('HubSpot', 'CRM', 'growth', 'Marketing automation and CRM integration', 'recommended'),
('Gainsight', 'Customer Success', 'growth', 'Customer health scoring and success platform', 'recommended'),
('Segment', 'CDP', 'growth', 'Customer data platform for event routing', 'core'),
('Amplitude', 'Analytics', 'growth', 'Product analytics platform', 'optional'),
('Mixpanel', 'Analytics', 'growth', 'Product analytics and engagement', 'optional'),

-- Adopt Layer - Support & Enablement
('Zendesk', 'Support', 'adopt', 'Customer support ticketing integration', 'recommended'),
('Intercom', 'Support', 'adopt', 'In-app messaging and support', 'optional'),
('Slack', 'Communication', 'adopt', 'Team notifications and alerts', 'core'),
('Microsoft Teams', 'Communication', 'adopt', 'Enterprise communication integration', 'recommended'),

-- Build Layer - Development Tools
('Jira', 'Issue Tracking', 'build', 'Product feedback to engineering workflow', 'core'),
('GitHub', 'Source Control', 'build', 'Code repository integration', 'optional'),
('Linear', 'Issue Tracking', 'build', 'Modern issue tracking alternative', 'optional'),

-- Host Layer - Infrastructure
('AWS', 'Cloud Platform', 'host', 'Cloud infrastructure hosting', 'optional'),
('Azure', 'Cloud Platform', 'host', 'Microsoft cloud services', 'optional'),
('GCP', 'Cloud Platform', 'host', 'Google cloud platform', 'optional'),
('Okta', 'Identity', 'host', 'SSO and identity management', 'core'),
('Auth0', 'Identity', 'host', 'Authentication platform', 'optional'),

-- Ops Layer - Data & Ops
('Snowflake', 'Data Warehouse', 'ops', 'Data warehouse for analytics export', 'recommended'),
('BigQuery', 'Data Warehouse', 'ops', 'Google data warehouse', 'optional'),
('Looker', 'BI', 'ops', 'Business intelligence dashboards', 'optional'),
('Tableau', 'BI', 'ops', 'Data visualization platform', 'optional');
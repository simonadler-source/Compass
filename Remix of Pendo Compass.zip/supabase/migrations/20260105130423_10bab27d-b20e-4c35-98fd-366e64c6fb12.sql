-- Add close_date column to opportunities table
ALTER TABLE public.opportunities ADD COLUMN close_date date;

-- Create transcript_reviews table for manual review queue
CREATE TABLE public.transcript_reviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  transcript_content TEXT NOT NULL,
  file_name TEXT,
  suggested_account_id UUID REFERENCES public.accounts(id) ON DELETE SET NULL,
  suggested_account_confidence NUMERIC,
  extracted_technologies JSONB DEFAULT '[]'::jsonb,
  extracted_insights JSONB DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  reviewed_at TIMESTAMP WITH TIME ZONE,
  reviewed_by UUID,
  final_account_id UUID REFERENCES public.accounts(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.transcript_reviews ENABLE ROW LEVEL SECURITY;

-- Create policies for team access
CREATE POLICY "Team members can view transcript reviews"
ON public.transcript_reviews FOR SELECT
USING (true);

CREATE POLICY "Team members can create transcript reviews"
ON public.transcript_reviews FOR INSERT
WITH CHECK (true);

CREATE POLICY "Team members can update transcript reviews"
ON public.transcript_reviews FOR UPDATE
USING (true);

CREATE POLICY "Team members can delete transcript reviews"
ON public.transcript_reviews FOR DELETE
USING (true);

-- Add trigger for updated_at
CREATE TRIGGER update_transcript_reviews_updated_at
BEFORE UPDATE ON public.transcript_reviews
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
-- Add status column to account_technologies table
ALTER TABLE public.account_technologies 
ADD COLUMN status text NOT NULL DEFAULT 'confirmed';

-- Add comment for clarity
COMMENT ON COLUMN public.account_technologies.status IS 'Status of technology: pending (from transcript analysis), confirmed (manually added or approved), rejected';

-- Update existing technologies to be confirmed
UPDATE public.account_technologies SET status = 'confirmed' WHERE status IS NULL OR status = '';
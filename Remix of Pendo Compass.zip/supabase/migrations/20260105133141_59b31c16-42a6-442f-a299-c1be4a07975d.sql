-- Create master technology repository table
CREATE TABLE public.technology_repository (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  description text,
  logo_url text,
  website_url text,
  functional_area text NOT NULL,
  layer text NOT NULL DEFAULT 'adopt',
  capabilities text[], -- Array of capability tags
  is_competitor boolean DEFAULT false,
  competitor_overlap text, -- e.g. 'analytics', 'guides', 'feedback'
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.technology_repository ENABLE ROW LEVEL SECURITY;

-- RLS policies for technology repository (readable by all, editable by team)
CREATE POLICY "Anyone can view technology repository" 
ON public.technology_repository 
FOR SELECT 
USING (true);

CREATE POLICY "Team members can create technologies" 
ON public.technology_repository 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Team members can update technologies" 
ON public.technology_repository 
FOR UPDATE 
USING (true);

CREATE POLICY "Team members can delete technologies" 
ON public.technology_repository 
FOR DELETE 
USING (true);

-- Add updated_at trigger
CREATE TRIGGER update_technology_repository_updated_at
BEFORE UPDATE ON public.technology_repository
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add new columns to account_technologies for owner and relationship status
ALTER TABLE public.account_technologies 
ADD COLUMN owner_name text,
ADD COLUMN owner_email text,
ADD COLUMN relationship_status text DEFAULT 'neutral', -- competitor, complementary, complementary_risk, neutral
ADD COLUMN repository_tech_id uuid REFERENCES public.technology_repository(id);

-- Create functional areas table for organizing canvas
CREATE TABLE public.functional_areas (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  description text,
  layer text NOT NULL DEFAULT 'adopt',
  default_width integer DEFAULT 200,
  default_height integer DEFAULT 100,
  color text DEFAULT '#fef9c3',
  sort_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.functional_areas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view functional areas" 
ON public.functional_areas 
FOR SELECT 
USING (true);

CREATE POLICY "Team members can manage functional areas" 
ON public.functional_areas 
FOR ALL 
USING (true);

-- Seed with initial functional areas from the Pendo diagram
INSERT INTO public.functional_areas (name, description, layer, sort_order, color) VALUES
  ('Host Application', 'Web/Mobile App, SaaS Platform', 'host', 1, '#fef9c3'),
  ('Third-Party Apps', 'Browser Extension Targets', 'host', 2, '#fef9c3'),
  ('Data Capture & Delivery', 'SDK, API, Data Collection', 'host', 3, '#bbf7d0'),
  ('Analytics & Insights', 'Product Analytics, SQL, Dashboards', 'build', 1, '#fef9c3'),
  ('Roadmap & Feedback', 'Planning, Backlog, User Feedback', 'build', 2, '#fef9c3'),
  ('Issue Tracking & Agile', 'Jira, Azure DevOps, Sprint Management', 'build', 3, '#fef9c3'),
  ('Digital Adoption & Guides', 'In-App Guides, Onboarding, Walkthroughs', 'adopt', 1, '#fef9c3'),
  ('Knowledge Base & Content', 'Help Center, Documentation, FAQs', 'adopt', 2, '#fef9c3'),
  ('Learning Management (LMS)', 'Training, Certification, Enablement', 'adopt', 3, '#fef9c3'),
  ('CRM', 'Customer Source of Truth', 'growth', 1, '#fef9c3'),
  ('Back Office Processes', 'Billing, Provisioning, Operations', 'growth', 2, '#fef9c3'),
  ('Data Lake / Warehouse', 'Snowflake, Redshift, BigQuery', 'growth', 3, '#fecaca'),
  ('Financial & Planning Systems', 'ERP, FP&A, Budgeting', 'ops', 1, '#e9d5ff'),
  ('Executive Dashboards & BI', 'Tableau, PowerBI, Looker', 'ops', 2, '#e9d5ff');

-- Seed with common enterprise technologies
INSERT INTO public.technology_repository (name, functional_area, layer, is_competitor, capabilities, description) VALUES
  -- Host layer
  ('React', 'Host Application', 'host', false, ARRAY['frontend', 'spa', 'web'], 'JavaScript library for building user interfaces'),
  ('Angular', 'Host Application', 'host', false, ARRAY['frontend', 'spa', 'web'], 'Platform for building mobile and desktop web apps'),
  ('Salesforce', 'Third-Party Apps', 'host', false, ARRAY['crm', 'enterprise'], 'Enterprise CRM platform'),
  ('Workday', 'Third-Party Apps', 'host', false, ARRAY['hr', 'enterprise', 'finance'], 'Enterprise cloud for HR and finance'),
  
  -- Build layer - Analytics
  ('Google Analytics', 'Analytics & Insights', 'build', false, ARRAY['web-analytics', 'marketing'], 'Web analytics service'),
  ('Amplitude', 'Analytics & Insights', 'build', true, ARRAY['product-analytics', 'behavioral'], 'Product analytics platform'),
  ('Mixpanel', 'Analytics & Insights', 'build', true, ARRAY['product-analytics', 'events'], 'Event-based analytics'),
  ('Heap', 'Analytics & Insights', 'build', true, ARRAY['product-analytics', 'autocapture'], 'Autocapture analytics'),
  ('Fullstory', 'Analytics & Insights', 'build', true, ARRAY['session-replay', 'analytics'], 'Digital experience intelligence'),
  ('Hotjar', 'Analytics & Insights', 'build', true, ARRAY['heatmaps', 'session-replay'], 'Heatmaps and session recordings'),
  
  -- Build layer - Roadmap
  ('Jira', 'Issue Tracking & Agile', 'build', false, ARRAY['agile', 'issue-tracking', 'scrum'], 'Issue and project tracking'),
  ('Azure DevOps', 'Issue Tracking & Agile', 'build', false, ARRAY['devops', 'agile', 'ci-cd'], 'Developer collaboration platform'),
  ('Productboard', 'Roadmap & Feedback', 'build', true, ARRAY['roadmapping', 'feedback'], 'Product management platform'),
  ('Aha!', 'Roadmap & Feedback', 'build', true, ARRAY['roadmapping', 'strategy'], 'Product roadmap software'),
  ('Canny', 'Roadmap & Feedback', 'build', true, ARRAY['feedback', 'feature-voting'], 'Feature request tracking'),
  ('UserVoice', 'Roadmap & Feedback', 'build', true, ARRAY['feedback', 'roadmapping'], 'Product feedback management'),
  
  -- Adopt layer
  ('WalkMe', 'Digital Adoption & Guides', 'adopt', true, ARRAY['dap', 'guides', 'onboarding'], 'Digital adoption platform'),
  ('Whatfix', 'Digital Adoption & Guides', 'adopt', true, ARRAY['dap', 'guides', 'analytics'], 'Digital adoption and analytics'),
  ('Userlane', 'Digital Adoption & Guides', 'adopt', true, ARRAY['dap', 'guides'], 'Interactive user guidance'),
  ('Appcues', 'Digital Adoption & Guides', 'adopt', true, ARRAY['onboarding', 'guides', 'nps'], 'User onboarding platform'),
  ('Intercom', 'Digital Adoption & Guides', 'adopt', true, ARRAY['chat', 'guides', 'support'], 'Customer messaging platform'),
  ('Zendesk', 'Knowledge Base & Content', 'adopt', false, ARRAY['support', 'ticketing', 'kb'], 'Customer service platform'),
  ('Confluence', 'Knowledge Base & Content', 'adopt', false, ARRAY['wiki', 'documentation'], 'Team collaboration and docs'),
  ('Guru', 'Knowledge Base & Content', 'adopt', false, ARRAY['knowledge-management', 'ai'], 'Knowledge management platform'),
  
  -- Growth layer
  ('Salesforce CRM', 'CRM', 'growth', false, ARRAY['crm', 'sales', 'enterprise'], 'Enterprise CRM'),
  ('HubSpot', 'CRM', 'growth', false, ARRAY['crm', 'marketing', 'sales'], 'CRM and marketing platform'),
  ('Gainsight', 'CRM', 'growth', false, ARRAY['customer-success', 'health-scores'], 'Customer success platform'),
  ('ChurnZero', 'CRM', 'growth', false, ARRAY['customer-success', 'churn'], 'Customer success software'),
  ('Snowflake', 'Data Lake / Warehouse', 'growth', false, ARRAY['data-warehouse', 'cloud'], 'Cloud data platform'),
  ('Databricks', 'Data Lake / Warehouse', 'growth', false, ARRAY['data-lakehouse', 'ml'], 'Data and AI platform'),
  ('BigQuery', 'Data Lake / Warehouse', 'growth', false, ARRAY['data-warehouse', 'gcp'], 'Google Cloud data warehouse'),
  ('Redshift', 'Data Lake / Warehouse', 'growth', false, ARRAY['data-warehouse', 'aws'], 'AWS data warehouse'),
  
  -- Ops layer
  ('Tableau', 'Executive Dashboards & BI', 'ops', false, ARRAY['bi', 'visualization'], 'Business intelligence platform'),
  ('Power BI', 'Executive Dashboards & BI', 'ops', false, ARRAY['bi', 'microsoft'], 'Microsoft BI tool'),
  ('Looker', 'Executive Dashboards & BI', 'ops', false, ARRAY['bi', 'data-modeling'], 'Business intelligence platform'),
  ('NetSuite', 'Financial & Planning Systems', 'ops', false, ARRAY['erp', 'finance'], 'Cloud ERP system'),
  ('Anaplan', 'Financial & Planning Systems', 'ops', false, ARRAY['planning', 'forecasting'], 'Connected planning platform'),
  ('Workday Adaptive', 'Financial & Planning Systems', 'ops', false, ARRAY['planning', 'finance'], 'Business planning cloud');
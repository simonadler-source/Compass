-- Add status column to technology_repository for draft/approved workflow
ALTER TABLE public.technology_repository 
ADD COLUMN status text NOT NULL DEFAULT 'approved';

-- Add comment for clarity
COMMENT ON COLUMN public.technology_repository.status IS 'Status of the technology: draft, approved';

-- Create index for filtering by status
CREATE INDEX idx_technology_repository_status ON public.technology_repository(status);
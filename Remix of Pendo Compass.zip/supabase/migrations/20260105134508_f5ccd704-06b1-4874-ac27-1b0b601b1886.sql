-- Create table for capturing use cases per functional area per account
CREATE TABLE public.account_use_cases (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id uuid NOT NULL REFERENCES public.accounts(id) ON DELETE CASCADE,
  functional_area text NOT NULL,
  use_case text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'identified',
  priority text DEFAULT 'medium',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.account_use_cases ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can view account use cases"
ON public.account_use_cases FOR SELECT USING (true);

CREATE POLICY "Team members can create account use cases"
ON public.account_use_cases FOR INSERT WITH CHECK (true);

CREATE POLICY "Team members can update account use cases"
ON public.account_use_cases FOR UPDATE USING (true);

CREATE POLICY "Team members can delete account use cases"
ON public.account_use_cases FOR DELETE USING (true);

-- Create index for faster lookups
CREATE INDEX idx_account_use_cases_account ON public.account_use_cases(account_id);
CREATE INDEX idx_account_use_cases_area ON public.account_use_cases(functional_area);

-- Add trigger for updated_at
CREATE TRIGGER update_account_use_cases_updated_at
BEFORE UPDATE ON public.account_use_cases
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
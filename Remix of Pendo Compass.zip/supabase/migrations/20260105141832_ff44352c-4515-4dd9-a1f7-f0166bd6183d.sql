-- Create table for architecture versions/snapshots
CREATE TABLE public.architecture_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  snapshot JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  is_current BOOLEAN DEFAULT false,
  version_number INTEGER NOT NULL DEFAULT 1
);

-- Enable RLS
ALTER TABLE public.architecture_versions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can view architecture versions" 
ON public.architecture_versions 
FOR SELECT 
USING (true);

CREATE POLICY "Team members can create architecture versions" 
ON public.architecture_versions 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Team members can update architecture versions" 
ON public.architecture_versions 
FOR UPDATE 
USING (true);

CREATE POLICY "Team members can delete architecture versions" 
ON public.architecture_versions 
FOR DELETE 
USING (true);

-- Create index for faster queries
CREATE INDEX idx_architecture_versions_created_at ON public.architecture_versions(created_at DESC);
CREATE INDEX idx_architecture_versions_is_current ON public.architecture_versions(is_current) WHERE is_current = true;
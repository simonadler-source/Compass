-- Create a layers table to store configurable layer definitions
CREATE TABLE public.layers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  label VARCHAR(100) NOT NULL,
  subtitle VARCHAR(200),
  color VARCHAR(20) NOT NULL DEFAULT '#fef9c3',
  bg_color VARCHAR(20) NOT NULL DEFAULT '#fffbeb',
  line_color VARCHAR(20) NOT NULL DEFAULT '#eab308',
  height INTEGER NOT NULL DEFAULT 160,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.layers ENABLE ROW LEVEL SECURITY;

-- Allow read access to all authenticated users
CREATE POLICY "Layers are viewable by everyone" 
ON public.layers 
FOR SELECT 
USING (true);

-- Allow authenticated users to manage layers
CREATE POLICY "Authenticated users can insert layers" 
ON public.layers 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update layers" 
ON public.layers 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can delete layers" 
ON public.layers 
FOR DELETE 
USING (auth.uid() IS NOT NULL);

-- Insert default layers
INSERT INTO public.layers (name, label, subtitle, color, bg_color, line_color, height, sort_order) VALUES
  ('host', 'HOST ENVIRONMENT', '(Where Pendo Lives)', '#fef3c7', '#fffbeb', '#f59e0b', 160, 0),
  ('build', 'BUILD STACK', '(Product & Engineering)', '#fde68a', '#fef9c3', '#eab308', 160, 1),
  ('adopt', 'ADOPT STACK', '(Enablement & Support)', '#fed7aa', '#ffedd5', '#f97316', 160, 2),
  ('growth', 'GROWTH STACK', '(Revenue & CRM)', '#fecaca', '#fef2f2', '#ef4444', 160, 3),
  ('operations', 'BUSINESS OPS', '(C-Suite & Strategy)', '#e9d5ff', '#faf5ff', '#a855f7', 160, 4);

-- Add trigger for updated_at
CREATE TRIGGER update_layers_updated_at
  BEFORE UPDATE ON public.layers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
-- Add priority field to account_technologies to store priority from radar
ALTER TABLE public.account_technologies 
ADD COLUMN IF NOT EXISTS priority VARCHAR(20);

-- Create an index for faster priority lookups
CREATE INDEX IF NOT EXISTS idx_account_technologies_priority 
ON public.account_technologies(account_id, priority);
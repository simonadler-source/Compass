-- Create discovery_questions table linked to functional areas
CREATE TABLE public.discovery_questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  functional_area_id UUID NOT NULL REFERENCES public.functional_areas(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  category TEXT DEFAULT 'general',
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.discovery_questions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view discovery questions"
ON public.discovery_questions
FOR SELECT
USING (true);

CREATE POLICY "Team members can manage discovery questions"
ON public.discovery_questions
FOR ALL
USING (true);

-- Create trigger for updated_at
CREATE TRIGGER update_discovery_questions_updated_at
BEFORE UPDATE ON public.discovery_questions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add useful indexes
CREATE INDEX idx_discovery_questions_functional_area ON public.discovery_questions(functional_area_id);
CREATE INDEX idx_discovery_questions_category ON public.discovery_questions(category);

-- Add example use cases table linking to functional areas (if not already part of account_use_cases)
-- We'll use a template table for reusable use case definitions per functional area
CREATE TABLE public.use_case_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  functional_area_id UUID NOT NULL REFERENCES public.functional_areas(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  example_outcomes TEXT,
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for use case templates
ALTER TABLE public.use_case_templates ENABLE ROW LEVEL SECURITY;

-- Create policies for use case templates
CREATE POLICY "Anyone can view use case templates"
ON public.use_case_templates
FOR SELECT
USING (true);

CREATE POLICY "Team members can manage use case templates"
ON public.use_case_templates
FOR ALL
USING (true);

-- Create trigger for updated_at
CREATE TRIGGER update_use_case_templates_updated_at
BEFORE UPDATE ON public.use_case_templates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add index
CREATE INDEX idx_use_case_templates_functional_area ON public.use_case_templates(functional_area_id);
-- Add status column to accounts table for pending review
ALTER TABLE public.accounts 
ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';

-- Create account_contacts table for people mentioned in transcripts
CREATE TABLE public.account_contacts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.accounts(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT,
  email TEXT,
  phone TEXT,
  notes TEXT,
  source TEXT DEFAULT 'transcript',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on account_contacts
ALTER TABLE public.account_contacts ENABLE ROW LEVEL SECURITY;

-- RLS policies for account_contacts
CREATE POLICY "Team members can view account contacts" 
ON public.account_contacts FOR SELECT USING (true);

CREATE POLICY "Team members can create account contacts" 
ON public.account_contacts FOR INSERT WITH CHECK (true);

CREATE POLICY "Team members can update account contacts" 
ON public.account_contacts FOR UPDATE USING (true);

CREATE POLICY "Team members can delete account contacts" 
ON public.account_contacts FOR DELETE USING (true);

-- Create account_nbas table for Next Best Actions
CREATE TABLE public.account_nbas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.accounts(id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  action_type TEXT NOT NULL DEFAULT 'technical',
  priority TEXT DEFAULT 'medium',
  status TEXT DEFAULT 'pending',
  due_date DATE,
  assigned_to TEXT,
  source_transcript_id UUID REFERENCES public.transcript_reviews(id) ON DELETE SET NULL,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on account_nbas
ALTER TABLE public.account_nbas ENABLE ROW LEVEL SECURITY;

-- RLS policies for account_nbas
CREATE POLICY "Team members can view account NBAs" 
ON public.account_nbas FOR SELECT USING (true);

CREATE POLICY "Team members can create account NBAs" 
ON public.account_nbas FOR INSERT WITH CHECK (true);

CREATE POLICY "Team members can update account NBAs" 
ON public.account_nbas FOR UPDATE USING (true);

CREATE POLICY "Team members can delete account NBAs" 
ON public.account_nbas FOR DELETE USING (true);

-- Add trigger for updated_at on new tables
CREATE TRIGGER update_account_contacts_updated_at
BEFORE UPDATE ON public.account_contacts
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_account_nbas_updated_at
BEFORE UPDATE ON public.account_nbas
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
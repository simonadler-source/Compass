-- Create customer_stories table
CREATE TABLE public.customer_stories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.accounts(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  
  -- Situation (the context/background)
  situation TEXT,
  situation_metrics TEXT, -- Key metrics about their state before
  
  -- Behavior (what they did / the solution)
  behavior TEXT,
  technologies_used TEXT[], -- Array of technology names involved
  use_cases TEXT[], -- Array of use case names
  
  -- Impact (the results)
  impact TEXT,
  impact_metrics JSONB DEFAULT '[]', -- Array of {metric: string, before: string, after: string}
  
  -- Additional fields
  status TEXT DEFAULT 'draft', -- draft, published
  industry TEXT,
  tags TEXT[],
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID
);

-- Enable RLS
ALTER TABLE public.customer_stories ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Team members can view customer stories" 
ON public.customer_stories FOR SELECT USING (true);

CREATE POLICY "Team members can create customer stories" 
ON public.customer_stories FOR INSERT WITH CHECK (true);

CREATE POLICY "Team members can update customer stories" 
ON public.customer_stories FOR UPDATE USING (true);

CREATE POLICY "Team members can delete customer stories" 
ON public.customer_stories FOR DELETE USING (true);

-- Add trigger for updated_at
CREATE TRIGGER update_customer_stories_updated_at
BEFORE UPDATE ON public.customer_stories
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
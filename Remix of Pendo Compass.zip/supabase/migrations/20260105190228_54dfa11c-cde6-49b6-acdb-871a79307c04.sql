-- Add owner_id to opportunities table
ALTER TABLE public.opportunities 
ADD COLUMN owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;

-- Add created_by to transcript_reviews to track who uploaded
ALTER TABLE public.transcript_reviews 
ADD COLUMN created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;

-- Create index for faster owner-based queries
CREATE INDEX idx_opportunities_owner_id ON public.opportunities(owner_id);
CREATE INDEX idx_transcript_reviews_created_by ON public.transcript_reviews(created_by);
CREATE INDEX idx_accounts_owner_id ON public.accounts(owner_id);
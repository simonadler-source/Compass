-- Create competitor intelligence tables for normalized storage

-- Table for storing competitors and their overall scores
CREATE TABLE public.competitors (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL UNIQUE,
  total_score numeric,
  website_url text,
  description text,
  logo_url text,
  is_primary_competitor boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Table for feature categories (Product Analytics, Guidance, AI, etc.)
CREATE TABLE public.competitive_categories (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL UNIQUE,
  sort_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Table for feature subcategories (Funnel Analysis, User Segmentation, etc.)
CREATE TABLE public.competitive_features (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category_id uuid NOT NULL REFERENCES public.competitive_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  maturity_level_1 text, -- Fragmented & Reactive description
  maturity_level_2 text, -- Consolidating & Proving description
  maturity_level_3 text, -- Scaling & Systematic description
  maturity_level_4 text, -- Integrated & Governed description
  maturity_level_5 text, -- Predictive & Strategic description
  sort_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(category_id, name)
);

-- Table for competitor scores per feature
CREATE TABLE public.competitor_scores (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  competitor_id uuid NOT NULL REFERENCES public.competitors(id) ON DELETE CASCADE,
  feature_id uuid NOT NULL REFERENCES public.competitive_features(id) ON DELETE CASCADE,
  score integer NOT NULL CHECK (score >= 0 AND score <= 5),
  rationale text,
  source_url text,
  source_date timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(competitor_id, feature_id)
);

-- Link competitors to technology_repository entries
ALTER TABLE public.technology_repository 
ADD COLUMN IF NOT EXISTS competitor_id uuid REFERENCES public.competitors(id);

-- Enable RLS
ALTER TABLE public.competitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.competitive_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.competitive_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.competitor_scores ENABLE ROW LEVEL SECURITY;

-- RLS Policies - Allow read access to all, write to authenticated
CREATE POLICY "Anyone can view competitors" ON public.competitors FOR SELECT USING (true);
CREATE POLICY "Authenticated users can manage competitors" ON public.competitors FOR ALL USING (auth.uid() IS NOT NULL);

CREATE POLICY "Anyone can view competitive categories" ON public.competitive_categories FOR SELECT USING (true);
CREATE POLICY "Authenticated users can manage competitive categories" ON public.competitive_categories FOR ALL USING (auth.uid() IS NOT NULL);

CREATE POLICY "Anyone can view competitive features" ON public.competitive_features FOR SELECT USING (true);
CREATE POLICY "Authenticated users can manage competitive features" ON public.competitive_features FOR ALL USING (auth.uid() IS NOT NULL);

CREATE POLICY "Anyone can view competitor scores" ON public.competitor_scores FOR SELECT USING (true);
CREATE POLICY "Authenticated users can manage competitor scores" ON public.competitor_scores FOR ALL USING (auth.uid() IS NOT NULL);

-- Create trigger for updated_at
CREATE TRIGGER update_competitors_updated_at BEFORE UPDATE ON public.competitors
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_competitor_scores_updated_at BEFORE UPDATE ON public.competitor_scores
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
-- Add parent company/portfolio support for software vendors
ALTER TABLE public.competitors 
ADD COLUMN IF NOT EXISTS parent_company_id uuid REFERENCES public.competitors(id),
ADD COLUMN IF NOT EXISTS is_portfolio boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS relationship_notes text;

-- Add portfolio reference to technology_repository
ALTER TABLE public.technology_repository
ADD COLUMN IF NOT EXISTS parent_company text,
ADD COLUMN IF NOT EXISTS is_customer boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS customer_notes text;

-- Create index for portfolio lookups
CREATE INDEX IF NOT EXISTS idx_competitors_parent_company ON public.competitors(parent_company_id);
CREATE INDEX IF NOT EXISTS idx_technology_repository_parent ON public.technology_repository(parent_company);
-- Add source and sort_order fields to account_use_cases for tracking proposed vs accepted use cases
ALTER TABLE public.account_use_cases
ADD COLUMN IF NOT EXISTS source text DEFAULT 'manual',
ADD COLUMN IF NOT EXISTS source_transcript_id uuid REFERENCES public.transcript_reviews(id),
ADD COLUMN IF NOT EXISTS sort_order integer DEFAULT 0;

-- Create index for sorting
CREATE INDEX IF NOT EXISTS idx_account_use_cases_sort ON public.account_use_cases(account_id, sort_order);
-- Create table for pending Momentum meetings (unmatched to accounts)
CREATE TABLE public.momentum_meetings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  momentum_id TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  start_time TIMESTAMP WITH TIME ZONE NOT NULL,
  end_time TIMESTAMP WITH TIME ZONE,
  host_email TEXT,
  host_name TEXT,
  attendees JSONB DEFAULT '[]'::jsonb,
  transcript_content TEXT,
  salesforce_account_id TEXT,
  salesforce_opportunity_id TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, imported, ignored
  matched_account_id UUID REFERENCES public.accounts(id),
  imported_at TIMESTAMP WITH TIME ZONE,
  ignored_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.momentum_meetings ENABLE ROW LEVEL SECURITY;

-- Create policies for authenticated users
CREATE POLICY "Users can view all momentum meetings" 
ON public.momentum_meetings 
FOR SELECT 
USING (true);

CREATE POLICY "Users can insert momentum meetings" 
ON public.momentum_meetings 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Users can update momentum meetings" 
ON public.momentum_meetings 
FOR UPDATE 
USING (true);

-- Create index for faster lookups
CREATE INDEX idx_momentum_meetings_status ON public.momentum_meetings(status);
CREATE INDEX idx_momentum_meetings_salesforce_account ON public.momentum_meetings(salesforce_account_id);
CREATE INDEX idx_momentum_meetings_momentum_id ON public.momentum_meetings(momentum_id);

-- Add trigger for updated_at
CREATE TRIGGER update_momentum_meetings_updated_at
BEFORE UPDATE ON public.momentum_meetings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add salesforce_account_id column to accounts table for matching
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS salesforce_account_id TEXT;
CREATE INDEX IF NOT EXISTS idx_accounts_salesforce_id ON public.accounts(salesforce_account_id);

-- Create table to track last sync time
CREATE TABLE public.momentum_sync_state (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  last_sync_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  meetings_synced INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.momentum_sync_state ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view sync state" 
ON public.momentum_sync_state 
FOR SELECT 
USING (true);

CREATE POLICY "Users can insert sync state" 
ON public.momentum_sync_state 
FOR INSERT 
WITH CHECK (true);
-- Fix RLS policies for account_contacts table
-- Drop existing overly permissive policies
DROP POLICY IF EXISTS "Team members can view account contacts" ON public.account_contacts;
DROP POLICY IF EXISTS "Team members can create account contacts" ON public.account_contacts;
DROP POLICY IF EXISTS "Team members can update account contacts" ON public.account_contacts;
DROP POLICY IF EXISTS "Team members can delete account contacts" ON public.account_contacts;

-- Create new policies that require authentication
CREATE POLICY "Authenticated users can view account contacts"
ON public.account_contacts
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can create account contacts"
ON public.account_contacts
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update account contacts"
ON public.account_contacts
FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete account contacts"
ON public.account_contacts
FOR DELETE
TO authenticated
USING (true);

-- Fix RLS policies for account_nbas table
-- Drop existing overly permissive policies
DROP POLICY IF EXISTS "Team members can view account NBAs" ON public.account_nbas;
DROP POLICY IF EXISTS "Team members can create account NBAs" ON public.account_nbas;
DROP POLICY IF EXISTS "Team members can update account NBAs" ON public.account_nbas;
DROP POLICY IF EXISTS "Team members can delete account NBAs" ON public.account_nbas;

-- Create new policies that require authentication
CREATE POLICY "Authenticated users can view account NBAs"
ON public.account_nbas
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can create account NBAs"
ON public.account_nbas
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update account NBAs"
ON public.account_nbas
FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete account NBAs"
ON public.account_nbas
FOR DELETE
TO authenticated
USING (true);
-- Allow system to insert profiles (trigger runs as security definer)
-- This policy allows the trigger to create profiles on signup
CREATE POLICY "System can insert profiles"
ON public.profiles
FOR INSERT
WITH CHECK (true);

-- Allow admins to insert profiles if needed
CREATE POLICY "Admins can insert profiles"
ON public.profiles
FOR INSERT
TO authenticated
WITH CHECK (public.is_admin(auth.uid()));
-- Add unique constraint for account_id + name to enable upsert
ALTER TABLE public.account_technologies
ADD CONSTRAINT account_technologies_account_id_name_key UNIQUE (account_id, name);
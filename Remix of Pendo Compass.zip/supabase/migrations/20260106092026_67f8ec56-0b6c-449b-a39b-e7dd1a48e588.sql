-- Fix import: enable upsert conflict target for account contacts
ALTER TABLE public.account_contacts
ADD CONSTRAINT account_contacts_account_id_email_key UNIQUE (account_id, email);

-- Security linter: pg_net cannot be moved via ALTER EXTENSION ... SET SCHEMA, so reinstall it in a non-public schema
CREATE SCHEMA IF NOT EXISTS extensions;
DROP EXTENSION IF EXISTS pg_net;
CREATE EXTENSION pg_net WITH SCHEMA extensions;
-- Add radar position columns to account_use_cases for persisting radar placements
ALTER TABLE public.account_use_cases 
ADD COLUMN IF NOT EXISTS radar_x numeric NULL,
ADD COLUMN IF NOT EXISTS radar_y numeric NULL;

-- Add a comment explaining the columns
COMMENT ON COLUMN public.account_use_cases.radar_x IS 'X position on the priority radar (relative to center, in pixels)';
COMMENT ON COLUMN public.account_use_cases.radar_y IS 'Y position on the priority radar (relative to center, in pixels)';
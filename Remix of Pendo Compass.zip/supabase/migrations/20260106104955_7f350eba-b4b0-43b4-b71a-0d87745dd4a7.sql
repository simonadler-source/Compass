-- Add columns to support grouped NBAs with parent/sub-task structure
ALTER TABLE public.account_nbas 
ADD COLUMN IF NOT EXISTS parent_nba_id UUID REFERENCES public.account_nbas(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS delivery_method TEXT DEFAULT 'internal' CHECK (delivery_method IN ('email', 'meeting', 'internal')),
ADD COLUMN IF NOT EXISTS sub_task_order INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS auto_complete_confidence NUMERIC(3,2),
ADD COLUMN IF NOT EXISTS auto_complete_reason TEXT,
ADD COLUMN IF NOT EXISTS auto_completed_by_transcript_id UUID REFERENCES public.transcript_reviews(id);

-- Create index for faster parent-child lookups
CREATE INDEX IF NOT EXISTS idx_account_nbas_parent_id ON public.account_nbas(parent_nba_id);

-- Create index for delivery method filtering
CREATE INDEX IF NOT EXISTS idx_account_nbas_delivery_method ON public.account_nbas(delivery_method);

COMMENT ON COLUMN public.account_nbas.parent_nba_id IS 'Parent NBA ID for sub-tasks. NULL for parent NBAs';
COMMENT ON COLUMN public.account_nbas.delivery_method IS 'Suggested delivery channel: email, meeting, or internal task';
COMMENT ON COLUMN public.account_nbas.auto_complete_confidence IS 'AI confidence score (0-1) for auto-completion detection';
COMMENT ON COLUMN public.account_nbas.auto_complete_reason IS 'AI-generated reason for auto-completion suggestion';
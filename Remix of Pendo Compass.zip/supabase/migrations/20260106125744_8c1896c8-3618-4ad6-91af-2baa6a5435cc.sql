-- Drop existing overly permissive policies on account_contacts
DROP POLICY IF EXISTS "Authenticated users can view account contacts" ON public.account_contacts;
DROP POLICY IF EXISTS "Authenticated users can create account contacts" ON public.account_contacts;
DROP POLICY IF EXISTS "Authenticated users can update account contacts" ON public.account_contacts;
DROP POLICY IF EXISTS "Authenticated users can delete account contacts" ON public.account_contacts;

-- Create new policies that require authentication
CREATE POLICY "Authenticated users can view account contacts"
ON public.account_contacts
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can create account contacts"
ON public.account_contacts
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update account contacts"
ON public.account_contacts
FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete account contacts"
ON public.account_contacts
FOR DELETE
TO authenticated
USING (true);
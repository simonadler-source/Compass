-- Add auto_import_transcripts column to accounts table (enabled by default)
ALTER TABLE public.accounts 
ADD COLUMN auto_import_transcripts boolean DEFAULT true;